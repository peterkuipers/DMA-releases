# 6. Troubleshooting, questions and known limitations

## "I do not see DMA Console in the Tools menu"

1. Are the files in the **right folder**? The `.js` files must be directly in the client's `userscripts` folder, not
   in a sub-folder.
2. Did you copy **all 37 files**? Compare the folder with `pack-manifest.json`.
3. Is an **older version** of DMA or "Drunken Miner" in the folder as well? Move it out ([01-install.md](01-install.md)).
4. Restart the client once and wait for the island to be on screen.
5. Still missing: send `dma-debug-log.txt` and the list of files in `userscripts` ([07-reporting.md](07-reporting.md)).

## "Everything is off and nothing happens"

That is correct. Switch one part on ([08-first-day.md](08-first-day.md)). Look at the **actors line** of the console: it tells
you for every part whether it is off, blocked (with the reason), idle or acting.

## "I switched something on and nothing happens"

- Read the actor's reason on the console. Common reasons: *visit hold* (you were on another island; ends by itself
  after at most 2 hours, or when you are home again), *startup hold* (the first 3 minutes after start), *nothing to do*.
- The part needs another switch: Quest and Event are separate; Trade needs Chat; Buff needs the Island picture
  (Island switch on).
- The setting is empty: troops need a target, upgrades need a target level, the chat watcher needs your chat reply word.

## "How do I stop everything?"

Click every lit switch in the switch bar so that all are dark. For certainty, close the client. To start clean, close
the client and delete `dma-policy.json`.

## "Will DMA restart my client?"

**Not unless you switch it on.** The rule *Restart the client by itself when the game stops responding*
(`control.selfRestart.on`, RULES page) is **off** in a new installation. Switched on, DMA restarts only when some
automation is on **and** the stock (Stone, Plank, Tool, Coal, Iron, Gold, Bread, Sausage) has not changed for
`control.staleRestartMin` minutes (10, you can set 5 to 240) while you are at home; at most once an hour and never while
an adventure is sending. Explorers that come back at once are no longer enough on their own: the stock must also stand
still. Note that a restart needs the client to log in again by itself; if your client asks for a password after a
restart, leave this rule off.
A restart written by hand (`dma-restart-request.json`) is for developers; do not create it.

## "A guild member says DMA answered in the guild chat"

Only the Chat and Trade switches write to the chat, and round trade replies go as **whispers**. If the guild chat
shows messages from DMA you did not expect, switch **Chat**, **Trade** and **Supply** off and report it with the
`dma-chat-sent.json` file.

## "I get a refusal in red on a page"

You typed a value outside the allowed range (see the table in [04-settings-reference.md](04-settings-reference.md)). The old
value is kept.

## "It spent something I did not expect"

Open the **TX** page and find the transaction; it shows what was ordered and why. Then switch the part off and send the
report ([07-reporting.md](07-reporting.md)). Parts that spend: Build, Upgrade, Buff, Event (fill), Troops, Quest (guild
quest payment), Trade (round and help trades), Adventures, Premium. Buying at the trade office is not possible in this pack.

## Known limitations of this test version

1. **DMA checks before it starts.** A run starts only when everything the selected Mundane needs is there: the adventure
   in the star, your own generals, armies that fit their generals, every arrow and every chosen speed-up in the star.
   Otherwise the ADVS page says what is missing (`not promised: R-PLAN-ARROWS — …`) and nothing is sent.
2. **No recommended geologist builds.** The geologist skill builds of the author were removed; set skills by hand.
3. **The trade office buyer is inert** (no confirmation file in the pack) and will not buy.
4. **Adventures:** the pack carries the author's Bonaberti Business *two waves* Mundane as a shared folder (see
   [09-adventures.md](09-adventures.md)). Other adventures need your own Mundane templates.
5. **Home island only.** Parts pause on a visit and on another island.
6. **The client's script engine is old** (ES3/ES5-style). A message about a "reserved word" in a log is a developer's problem; report it.
7. **Event rules are tuned for events the author has seen** (Halloween). A new event type may need its names set on the EVENT page.
8. **Names and examples:** the examples in help texts use "Joe". Your own chat reply word is yours; nothing in DMA depends on a specific name.
9. **Restart on a stuck client** is off unless you switch it on (see above).
11. **Guild quest "buff a friend's buildings"** is not done by the quest manager; do it by hand.
10. **The values of the VALUE page** come from the game definitions DMA carries; a notice appears when they differ.
12. **Beta: Use with my generals, Optimise and Make new.** These plans are made by DMA. Their battle calculation agrees with
    the published guides in 30 of 31 checked camps. The open case is First Thief camp 2702, where the guide loses about
    27 Mounted Swordsmen and DMA counts 14. Watch the first run of such a version.
13. **A general that does not leave** after an attack order (the ADVS log repeats *the view is behind the server*) needs
    a client restart or an attack by hand. Report it with the FEEDBACK button.

## Questions

**Does DMA cost gems or use the shop?** No. No part has a path to gems or the shop.

**Can the game ban me for this?** DMA acts only through the same commands the client sends itself, at a measured pace
(`control.sendIntervalMs`, 500 to 10000 ms between server actions). Whether a script is allowed in your game rules is **your**
decision and responsibility; this test is for guild members who accept that.

**Can I run it on a second account?** Not in this test.
