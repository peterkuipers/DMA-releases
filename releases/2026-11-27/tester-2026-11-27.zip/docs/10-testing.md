# 10. How to test

Thank you for testing. This chapter says **what** to test, **in which order**, and **how to send what you find**.
You do not need to test everything: each tester has a focus, so that together we cover the whole pack without anyone
switching on more than they are comfortable with.

## The three rules of testing

1. **Start with everything off** and switch on one part at a time ([08-first-day.md](08-first-day.md)).
2. **Watch before you trust.** After switching a part on, look at the console and your island for at least half an hour.
3. **Press FEEDBACK at once** and post the text and the file in **test-corner** ([07-reporting.md](07-reporting.md)).
   A quick report the moment you see it is better than a perfect report a day later.

## Week plan

| When | Everyone |
|---|---|
| Day 1 | Install, everything off, 30 minutes of only looking (scenario T-01). Then the first-day plan up to Island. |
| Day 2–3 | Your focus area (below), one part at a time. |
| Day 4–7 | Your focus area in normal play; a second area if you like. Post a short "how did it go" in test-corner at the end of the week, also when nothing went wrong. |

## Focus per tester

| Tester | Focus | Scenarios |
|---|---|---|
| **Leroybrown** | The island parts: Island, Mail, Quest, Buff, Upgrade | T-01, T-07, T-08 |
| **SirBirk** | Chat and round trades (together with Sizzler79 as the other player) | T-01, T-02 |
| **Sizzler79** | Deposit Cycling (copper first, then iron); troops and short resources (Supply, without buying), round trades with SirBirk; your own Mundane played as written | T-01, T-11, T-02, T-05, T-09, T-13 |
| **Mickepedia** | Adventures: the shared Bonaberti Mundane, its analysis and (if your generals fit) a run; Make my Mundane | T-01, T-03, T-12 |
| **Zingu** | The RULES page, the event parts, premium and the zombie hunt | T-01, T-04, T-06, T-10, T-09 |

## The scenarios

Each scenario says what to set up, what to do, and what you should see. "Not as expected" is always worth a message.

| # | Scenario | Set up | Do | Expected |
|---|---|---|---|---|
| **T-01** | Everything is off | A fresh installation. | Start the client, open the console, wait 30 minutes at home. | Every switch dark; nothing is built, upgraded, buffed, traded, sent or said in chat. |
| **T-02** | Round trade by whisper | Chat and Trade on, your chat reply word set; *Round trades* ticked on the TRADE page. | Ask the other tester for a round trade, once in guild chat and once by whisper. | Every reply is a whisper to that player; the trade is done by the rules on the TRADE page; the TX page shows it ending "accepted". |
| **T-03** | Bonaberti Business (shared Mundane) | The adventure in your star; the shared folder as a version of kind *author's Mundane* ([09-adventures.md](09-adventures.md)). | Read the analysis. If every camp is covered and the troops are at home, press **Run once** and watch. | The analysis names what fits and what is missing. A run passes the five phases; the camps fall; before closing, loose troops are loaded; everyone comes home. |
| **T-04** | Zombie hunt (only while Halloween runs) | `zombie.auto` on (RULES page). | Leave the client at home for a hunt cycle. | During Halloween a general is sent to the crypt; outside it nothing is sent. |
| **T-05** | Troop target | Troops on; a target on the TROOPS page of your current Recruits + 50. | Wait 10 minutes. | Recruits are queued in rows of 25 until the target (plus what the next planned adventure will lose); clearing the target stops it. |
| **T-06** | Premium during an event | `premium.setting` = event (RULES page); premium items in the star. | Let premium run out while an event runs. | One premium item is applied a few minutes before the end; with "off" nothing. |
| **T-07** | Upgrade never too far | Upgrade on; a target level for one resource in the main table. | One cycle. | Mines go up to the target, never above the game's maximum; nothing for a resource without a target; never a tribute. |
| **T-08** | Buff only where wanted | Buff on; a buff chosen on the BUFF page. | One cycle. | The chosen buff on unbuffed buildings; a building already buffed is left alone. |
| **T-09** | The RULES page | — | Find three rules with the filter, change a number to a value outside its range, change it back, open the never-pay checklist and save a choice. | The out-of-range value is refused in red; the others are saved in green; the checklist remembers your choice when you open it again. |
| **T-10** | Event parts | Event on; the EVENT page. | While an event runs, let the event manager fill and buff for one round. Outside an event: read the EVENT page. | Event buildings are filled and buffed as set; outside an event nothing is sent. Tell us whether the page is clear and what you miss. |
| **T-11** | Deposit Cycling | WORKFLOWS page: copper on, Start *now*, two copper spots ticked and labelled, geologist types 76, 80, 89, reserve on. Only basic copper mines on those spots. | Watch two hours. Then the same for iron with type 59. | Per spot: a mine is built, demolished only **after** it is finished, the spot is empty, a workflow geologist searches there, the find brings loot mail. Never a demolish of a mine still under construction, never a loop, no buff on those spots; the reserve stops building when a build good runs low. Post the cycles count and the loot from the WORKFLOWS overview. |
| **T-12** | Make my Mundane, three ways (beta parts included) | An adventure you know, in your star, opened once; a few Small or Big Catapults in the star if you have them. | 1) **Use with my generals** on your own Mundane; 2) **Make new** with *quick loot* and *fewest losses*; 3) **Make new** with *only arrows*. Save one and run it. | Versions side by side; quick loot plans fewer camps; arrows stand first in the first attack; *only arrows* names camps no arrow takes. Tell us which camps were missing or extra, and every refused arrow. |
| **T-13** | Your own Mundane as written | Your own template folder as a version (one with arrows, e.g. First Thief, is best). | First start it with one arrow too few in the star, then with all of them. | Without the arrow: nothing is sent and the ADVS page names the missing arrow. With all: the log says "played as it is"; generals and arrows leave in your template's order and timings. |

The event parts are complete, and **your opinion of them is as valuable as a bug**: what is clear, what is confusing,
what you would want it to do. Post it in test-corner.

## What to post in test-corner

- **A problem:** time, pack version, which switches were on, what you expected, what happened. Add the report zip
  ([07-reporting.md](07-reporting.md)) when you can.
- **A question:** anything in this manual that is unclear.
- **An idea or an opinion:** what you would change, what you liked.
- **A daily or weekly "all fine"** also helps: it tells us what worked.

Every post is read and filed as an issue; you get an answer in the channel with what happens next.
