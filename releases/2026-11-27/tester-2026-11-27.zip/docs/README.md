# DMA for The Settlers Online — user manual (tester release 2026-11-27)

This manual is for guild members who test **DMA**, a set of scripts that run inside the *portable* Settlers Online
client and help with the routine work on your home island. You do not need to be a programmer. Everything you need is
in these pages, and every statement was taken from what the program itself does (its switches, rules and files), not
from memory.

> **Version of this manual:** pack `2026-11-27` (see [RELEASE-NOTES.md](RELEASE-NOTES.md)).
> Please read **"Safety first"** below before you switch anything on.

## What DMA is

DMA is a group of small scripts ("modules") that the client loads when it starts. Together they show a window called
**DMA Console** (in the client's **Tools** menu). On that console you decide what DMA may do for you. Each kind of work
has its own **switch**. A switch that is off means that part of DMA does **nothing**.

What DMA can do for you, when you switch it on:

- watch your island and keep a picture of it (the **Island** switch);
- send **geologists** to search for deposits and **explorers** to search for treasures and adventures (**Geo**, **Expo**);
- build, upgrade, buff and demolish your mines (**Build**, **Upgrade**, **Buff**, **Demo**);
- answer guild-chat requests for **round trades**, help trades and star trades (**Chat**, **Trade**);
- collect explorer loot from your mailbox (**Mail**);
- work through your **quest book** and pick up collectables (**Quest**);
- take up the running **event** (**Event**);
- keep your **troops** at a target strength (**Troops**), hunt **zombie camps**, keep **Premium** running;
- run **adventures** (Arctic Explosion, the Ali Baba and Tailor adventures, Gunpowder and your own) and advise which one
  fills a stock that is running out;
- buy a short resource at the **trade office** when that is really favourable (**Supply**, extra confirmation needed).

![The DMA Console: the switch bar at the top, your mines in the middle, the log and the page buttons at the bottom](images/console-main.png)

## What is ready and what is beta (pack 2026-11-27)

**Ready** means we use it every day, it is checked before it acts, and it has passed its tests and live runs.
**Beta** means it works and you may use it. It is still being measured, so watch its first runs and press FEEDBACK when
something is off.

| Part | Status | Where |
|---|---|---|
| Island, Geo, Expo, Build, Upgrade, Buff, Demolish | ready | [03-features.md](03-features.md) |
| Chat and Trade (round trades), Mail, Quest, Event, Premium, Zombie hunt | ready | [03-features.md](03-features.md) |
| Troops: keeping each unit kind at its target strength | ready | [03-features.md](03-features.md#troops) |
| Troops: the **barracks queue** (several rows at once, priority, balanced building) | new, ready | [03-features.md](03-features.md#troops) |
| Adventures: playing an existing Mundane **1:1**, exactly as written | ready | [09-adventures.md](09-adventures.md#four-ways-to-play-a-mundane-from-2026-11-27) |
| Adventures: an existing Mundane **1:1 with your own generals of the same type** | new, ready | [09-adventures.md](09-adventures.md#four-ways-to-play-a-mundane-from-2026-11-27) |
| Adventures: an existing Mundane **with your own generals of other types** (*Use with my generals*) | **beta** | [09-adventures.md](09-adventures.md#four-ways-to-play-a-mundane-from-2026-11-27) |
| Adventures: **Optimise** a Mundane, or **make your own** (*Make new*); quick loot and only-arrows plans | **beta** | [09-adventures.md](09-adventures.md#make-my-mundane-from-2026-11-26) |
| Supply: buying at the trade office | ready, extra confirmation | [03-features.md](03-features.md) |
| Workflows: deposit cycling | ready | [03-features.md](03-features.md#workflows-deposit-cycling) |

## What DMA does **not** do

- It does **not** buy anything with **gems** and has no path to the shop. Premium is extended only from items that are
  already in your star menu.
- It does **not** change your account, your password or the game files. It runs inside the client you start yourself.
- It does **not** play on islands other than your **home island** (it pauses while you are away or on a visit).
- It does **not** work without you knowing: every action is written to files next to the client (see
  [05-files.md](05-files.md)), and the console shows what each part is doing and why not.
- This is a **test version**. Things can be unfinished or wrong. That is why you test it, and why everything starts off.

## Safety first (read this)

1. **Everything is off when you start.** A new installation has **every switch off**. DMA looks at your island and shows
   its console, and that is all. Nothing is built, upgraded, buffed, demolished, sent, bought, traded or said in chat.
2. **Switch on one thing at a time.** Switch one feature on, watch the console and your island for a while, and only
   then add the next one. The first-day plan is in [08-first-day.md](08-first-day.md).
3. **How to switch everything off, right now:** open the DMA Console and click every lit switch in the switch bar
   (top of the window) so that all are dark. A switched-off part sends nothing from its next turn on. The most certain
   way is to close the game client: DMA only runs while the client runs. To start clean next time, see
   [01-install.md](01-install.md) (rollback) and [06-troubleshooting-faq.md](06-troubleshooting-faq.md).
4. **Restart behaviour.** DMA does **not** restart your client by itself unless you switch that on (RULES page,
   *Restart the client by itself when the game stops responding*, `control.selfRestart.on`, **off** in a new
   installation). Switched on, it restarts only when the stock has stood still for 10 minutes (you set the minutes)
   while some automation is on, at most once an hour, and never while an adventure is sending. See the FAQ.
5. **It only touches known buildings.** DMA upgrades, buffs and demolishes only building kinds on a verified list,
   never above their maximum level, never a building that already carries the buff, and never tributes or endless mines.
6. **You stay responsible** for your account. Look at the console now and then, especially in the first days.
7. **Anything that spends or sends something you did not expect:** switch the part off and press **FEEDBACK** on the
   console ([07-reporting.md](07-reporting.md)).

## Contents

| Page | What is in it |
|---|---|
| [01-install.md](01-install.md) | Step-by-step installation: which files, where, how to start, how to see it loaded, how to update, how to uninstall or go back. |
| [02-console-tour.md](02-console-tour.md) | A tour of the DMA Console: the switch bar, the main table and every page (SPEC, BUFF, TRADE, MAIL, QUEST, ADVS, EVENT, VALUE, TROOPS, TX, RULES). |
| [03-features.md](03-features.md) | Every feature: what it needs, what it spends, what guards it, and how to stop it. |
| [04-settings-reference.md](04-settings-reference.md) | Every setting by its key, with default, allowed values and meaning (generated from the program). |
| [05-files.md](05-files.md) | The files the client writes next to itself, and what each one is for. |
| [06-troubleshooting-faq.md](06-troubleshooting-faq.md) | Problems and questions, and the known limitations of this test version. |
| [07-reporting.md](07-reporting.md) | How to report what you found: which files to zip, what to write, to whom. |
| [08-first-day.md](08-first-day.md) | A walk through your first day, switch by switch. |
| [09-adventures.md](09-adventures.md) | Adventures in depth: the five phases, the star method, the versions, the load margin, sharing a Mundane, Bonaberti Business in two waves step by step. |
| [10-testing.md](10-testing.md) | How to test: who tests what, in which order, the test scenarios (the event included), and how to send feedback in **test-corner**. |
| [RELEASE-NOTES.md](RELEASE-NOTES.md) | What is in this pack, what is new, what is known to be open. |

## The first day in one paragraph

Install ([01](01-install.md)), start the client, open **Tools > DMA Console**, and check that the version line lists the
modules. Leave all switches off and just read the console for ten minutes. Then switch **Island** on and confirm the
table fills with your mines. Next, one by one and with at least half an hour in between: **Mail**, **Quest**, then a
building feature (**Buff**), then the guild features (**Chat**, **Trade**) with your own chat reply word set. Leave
adventures, zombies, premium, troops and supply for day two. The full plan with checks is in
[08-first-day.md](08-first-day.md).

## Words used in this manual

- **Switch** — the on/off buttons in the switch bar at the top of the console. Stored as a setting such as `buff.auto`.
- **Setting / rule** — a value you can change (a number, a word, on/off). Each has a **key** such as `trade.cap`.
  [04-settings-reference.md](04-settings-reference.md) lists them all, and the console's **RULES** page lets you set every one.
- **Star menu** — the item list of your star, where buffs, books and adventure items are kept.
- **RT** — a round trade: a guild member sends you goods, you send the same back, so both end at the same amount.
- **Client folder** — the folder with the portable client (`tso_portable`). DMA writes its files there.
