# 5. The files DMA writes

DMA writes plain text files **next to the client** (in the client folder). They are the memory and the record of DMA.
You can open them in Notepad; all are JSON (a structured text) or JSON lines (`.jsonl`, one JSON record per line).
DMA reads some of them again at start. **Never type your account details into any of them.** DMA does not write your
password or login token in any file of this pack.

Not every file appears at once: a file appears when its part first has something to record.

## Files you may change on purpose

| File | What it is | Change it? |
|---|---|---|
| `dma-policy.json` | All your switches and settings. Read at every start. | Yes, with the client closed, see [04-settings-reference.md](04-settings-reference.md). Delete it for a fresh start. |
| `dma-chat-config.json`, `dma-trade-config.json`, `dma-premium-config.json`, `dma-troops-plan.json` | Small configuration or plan files of one part (for instance the chat watcher and the troop plan). Present only when created. | Only when this manual or a developer tells you. |
| `dma-trade-office-confirmed.json` | The confirmation file that lets the trade office buyer buy. **Not in the pack; do not create it.** | No |

## The record of what happened (safe to send in a report)

| File | What it is |
|---|---|
| `dma-debug-log.txt` | The console log and the last cycle messages. The first thing to send. |
| `dma-facts-<date>.jsonl` | The facts log of the day: every act of every part, one line each (what was asked, promised, done, declined, and why). One file per day. |
| `dma-heartbeat-<date>.jsonl` | One line per minute: the client is alive and what it sees. One file per day. |
| `dma-transactions.json` | Every transaction and its status (what the TX page shows). Written at most every 5 minutes. |
| `dma-transactions-history-<date>.jsonl` | Closed transactions of the day. |
| `dma-policy-changes.jsonl` | Every change of a setting, and every refusal with its reason. |
| `dma-upgrade-ledger.json` | The upgrades that were ordered, so no order is sent twice. **Keep it.** |
| `dma-restart-log.jsonl`, `dma-restart-status.json`, `dma-stale.json` | The record of restarts DMA asked for, and the time of the last restart because of a stuck client. |

## Status files of single parts (what the console shows)

`dma-trade-status.json` (round trades), `dma-chat-sent.json` (what the chat watcher said), `dma-quest-status.json`,
`dma-quest-todo.json`, `dma-quest-help.json`, `dma-quest-watch.json` (quest manager), `dma-loot-status.json` (mail),
`dma-buff-sent.json` (buffs ordered), `dma-worklist.json` (what the managers plan), `dma-production-requests.json`
(batches the supply manager asks you to make), `dma-explorer-orders.json` (explorer search orders),
`dma-adv-status.json`, `dma-adv-run.json`, `dma-adv-ls.json`, `dma-adv-book.json` (adventures and loot spots),
`dma-troops-status.json` (troops), `dma-zombie-status.json` (zombie hunt), `dma-premium.json` (premium watch),
`dma-repair-status.json` (a building the game reports with a level above its maximum is reported, not touched),
`dma-tk31.json` (upgrade transactions), `dma-stand.json` (older settings store, read once at first start).

## Safe to delete

When the client is closed you can delete any `dma-facts-*.jsonl`, `dma-heartbeat-*.jsonl`, `dma-transactions-history-*.jsonl`
and `dma-debug-log.txt` to free space; they come back. Delete `dma-policy.json` only if you want to start with all
settings at their defaults (all switches off).

## What DMA does not write

No password, no login token, no payment data. The restart that DMA does when the game is stuck uses the running client's
own session in memory; the client folder gets no login file from this pack. (The separate "watchdog" tool, which
writes a relaunch file, is not part of this pack.)
