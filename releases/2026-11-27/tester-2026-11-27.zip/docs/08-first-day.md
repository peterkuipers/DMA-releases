# 8. Your first day: a walk through

Take your time. Switch one thing on, look, and only then the next. Between two steps give DMA at least half an hour on
a normal island. If you see anything strange, switch the last thing off and write down what you saw
([07-reporting.md](07-reporting.md)).

## Step 0: install and look (10 minutes, everything off)

1. Install ([01-install.md](01-install.md)). Start the client.
2. Open **Tools > DMA Console**. Check that the **version line** lists modules, and that **all switches are dark**.
3. Click through the pages SPEC, BUFF, TRADE, MAIL, QUEST, ADVS, EVENT, VALUE, TROOPS, TX and RULES once. Nothing happens by looking.
4. On the main screen, type **your own chat reply word** (your name, for example `Joe`). It is saved when you leave the field.

## Step 1: Island

Switch **Island** on. After a minute the main table shows your mines and deposits, the actors line shows `Island`
as idle or acting. This part only reads. If the table stays empty after five minutes, report it.

## Step 2: Mail and Quest (low risk)

1. Open the MAIL page, tick only the loot kinds you want, then switch **Mail** on. Watch "waiting" and "collected".
2. Open the QUEST page, untick the categories you do not want (for a first try keep *claim* and *collect*, untick *pay*),
   then switch **Quest** on.

## Step 3: Buff (it uses items from your star)

1. Open the BUFF page and choose a buff for the building types you care about (or leave "none").
2. Switch **Buff** on. Within a few minutes the actors line shows a buff ordered. Check that it is the buff you chose and
   that the building was not already buffed.

## Step 4: Geo and Expo

Switch **Geo** on (geologists search). Switch **Expo** on after looking at the template on the SPEC page
(`Daily` is the default).

## Step 5: The guild features: Chat and Trade

1. Check that your **chat reply word** is set and the guild chat tab is open.
2. Switch **Chat** on, then **Trade** on. Ask a friend in the guild to ask you for a **small round trade** by
   whisper (for example: "Joe, RT please" and then to send one item). Watch the TRADE page and the whispers.
3. Leave help trades and star trades off for today.

## Step 6 (only when the earlier steps were quiet): Build, Upgrade, Demo

These spend materials or remove mines. Read their sections in [03-features.md](03-features.md) first. Set a target level
and a cap on one resource only, switch **Build** on, then **Upgrade**. Leave **Demo** off until you understand the
threshold.

## What to leave for day two

Adventures, troops, zombie hunt, premium, supply and the event. Read their sections first, and set up what they need.

## At the end of the day

- Open the **TX** page and look at what DMA did.
- Copy the console log into a text file.
- Send a short note: what worked, what was strange ([07-reporting.md](07-reporting.md)).
- You can leave the switches as they are (they are kept), or switch everything off before you log out.
