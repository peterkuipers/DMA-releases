# 1. Installation

DMA is a folder of script files. You copy them into the `userscripts` folder of your portable client, start the client,
and open the console. There is nothing to install in Windows, and nothing to register.

## What you need

- The **portable Settlers Online client** you already play with (the folder is usually called `tso_portable`; it holds
  `client.exe` and a folder `userscripts`). DMA runs only in that client.
- The tester pack you were sent: a folder (or zip) with `userscripts\`, `docs\` and `pack-manifest.json`.
- A normal Windows user account that may write in the client folder. You do **not** need administrator rights.

## Step by step

1. **Close the client** if it is running.
2. **Make a safety copy.** In the client folder, copy the whole `userscripts` folder to a new folder next to it, for
   example `userscripts_before_dma`. (If it does not exist yet, skip this.) Put the copy **outside** `userscripts`;
   the client loads every `.js` file it finds inside that folder.
3. **Move other DMA or "Drunken Miner" scripts out** of `userscripts` into that backup folder if you have an older
   version. Two versions of the same module in one folder fight each other. Scripts that have nothing to do with DMA can stay.
4. **Copy the DMA files.** Open the pack's `userscripts` folder, select **all** files in it (there are 37 `.js` files),
   and copy them into your client's `userscripts` folder. Do not rename them and do not leave any out: the client loads
   them in alphabetical order, and the order is part of the design.
5. **(Optional) check the copy.** `pack-manifest.json` lists every file with its size and `sha256` checksum. In a
   command prompt, `certutil -hashfile <file> SHA256` gives the checksum of a file; it must equal the one in the manifest.
6. **Start the client** as you always do and log in. Wait until your home island is on screen.
7. **Open the console:** in the client's **Tools** menu choose **DMA Console**. What else the Tools menu shows depends on
   which scripts you have installed. From this pack two entries come: **DMA Console** and **Building buffer** (the
   `user_building_buffer.js` module: a separate small window that lists your production buildings and buffs them when
   you press its **Apply all**; it is not the BUFF page of the console, see [02-console-tour.md](02-console-tour.md)).
   **Update** and **Options** belong to the client. Any other entry (for instance *UserExample*, *Building List*,
   *Building Monitor*, *Send Explorers Event*) comes from **other scripts that you installed yourself**, not from this
   pack, and the pack does not hide, change or depend on them. A pack-only installation shows Update, Options, Building
   buffer and DMA Console.

## How you see that it is loaded

- The console has a thin **version line** under its toolbar. It names the loaded modules and their versions
  (for example `ui 0.1.98`). A module that is missing is not listed.
- The log field at the bottom of the console tells you what is happening ("refreshed", messages from modules).
  The button **Copy log** copies it, so you can paste it into a report.
- In the client folder a file `dma-debug-log.txt` appears, and `dma-heartbeat-<date>.jsonl` grows by a line every minute.
- On a fresh installation **every switch in the switch bar is dark (off)**. That is correct.

If the **DMA Console** item is missing in Tools, see [06-troubleshooting-faq.md](06-troubleshooting-faq.md).

## Your settings are kept

The switches and settings are saved in `dma-policy.json` in the client folder and read again at every start. A restart
of the client therefore does not turn switches off, and a switch you turned on stays on. If you want a clean start,
see "Starting over" below.

## Update to a new pack

1. Close the client.
2. Copy the new pack's files over the old ones (all files; a new pack may add, replace or drop files, so compare the
   file list with `pack-manifest.json` and remove files the new list no longer has).
3. Start the client and check the version line.

Your settings file stays and keeps working. A new pack's release notes say when a setting has changed its meaning.

## Uninstall or go back

- **Switch DMA off, keep the files:** switch every switch off in the console (all dark). Nothing acts any more.
- **Remove DMA:** close the client and delete the 37 DMA files from `userscripts` (the names are in
  `pack-manifest.json`). If you made the safety copy in step 2, you can also put that back instead.
- **Go back to the previous pack:** close the client, restore the previous pack's files over the new ones, start again.
- **Leftover files are harmless.** `dma-*.json`, `dma-*.jsonl` and `dma-debug-log.txt` in the client folder are only
  records. You can delete them when DMA is removed (see [05-files.md](05-files.md)).

## Starting over (fresh settings)

Close the client, then delete `dma-policy.json` (and, if you want everything forgotten, the other `dma-*.json`
files). On the next start all switches are off again and all settings are at their defaults. The upgrade ledger
(`dma-upgrade-ledger.json`) and the transaction record (`dma-transactions.json`) are memory of what DMA did; delete
them only when you also want that forgotten.

## Things DMA never does during installation

- It does not need your password, and it does not write it anywhere. Do not type account details into any file.
- It does not schedule anything in Windows. (The "watchdog" that could relaunch the client after sleep is a separate
  tool and is **not** in this pack.)
