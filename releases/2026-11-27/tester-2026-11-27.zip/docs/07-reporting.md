# 7. How to report what you found

## The quick way: the FEEDBACK button (one minute)

1. Open the DMA Console and press **FEEDBACK** (bottom row, orange).
2. Fill in a one-line **title** and, in your own words, **what you were doing**, **what you expected** and **what
   happened**. Short is fine.
3. Press **Make report**. DMA now
   - puts a **short text** on the clipboard (under 2000 characters, so it fits one Discord message): the time, the
     switches that are on, what every part is doing and why, the last problems in the console, the adventure's state,
     the versions and your own words;
   - writes a **report file** `dma-report-<date>T<time>Z.txt` in the client folder, with everything a developer needs:
     your settings that differ from the default, the last 300 console lines, the open and recent transactions, the
     status of the parts and the last restarts.
4. In Discord, in **#test-corner**: paste (**Ctrl+V**) and attach the report file (the **+** next to the message box,
   then the client folder). Send.

The report holds no password and no chat text of other players; your chat reply word and the names in trades are
replaced. Nothing is sent by DMA itself: you decide what you post. If the copy fails, the page shows the text so you can
select and copy it yourself.

Use the button **every time** something looks wrong, and also for questions and ideas (write them in "what happened").

## The long way (when the console does not open)

A good report lets a developer reproduce what happened without asking you anything. It takes ten minutes.

## 1. Write down, at once

- **When** it happened (date, time and your time zone) and **which pack version** (`2026-11-17`, from the release notes;
  the console's version line shows the module versions).
- **Which switches were on** (a screenshot of the switch bar and the actors line is perfect).
- **What you expected** and **what happened instead**, in your own words. Short is fine.
- Whether it happened **once or every time**, and what you did just before.
- Whether anything **was spent or sent that you did not expect** (a building, goods, a chat line, a trade). If so,
  switch the part off first.

## 2. Collect these files

From the client folder, copy into a new folder (name it `report-<date>`):

- `dma-debug-log.txt`
- `dma-policy.json` (your settings)
- `dma-policy-changes.jsonl`
- `dma-transactions.json`
- the `dma-facts-<date>.jsonl` and `dma-heartbeat-<date>.jsonl` of the day concerned (and the day before)
- the status file of the part concerned (see [05-files.md](05-files.md); for a trade `dma-trade-status.json` and
  `dma-chat-sent.json`)
- the console's **log**: click **Copy log** and paste it into a text file `console-log.txt`

Then **zip the folder** (right click, Send to, Compressed (zipped) folder).

## 3. What must NOT be in the zip

- No password, login token or payment details. (DMA writes none, but check that you did not add any.)
- No screenshots that show your e-mail address or account number.
- Do not include `client.exe` or other game files; the files above are enough.

## 4. Send it

Post the zip and your notes in the Discord channel **test-corner**. Put the date and a one-line title ("Round trade
accepted twice", "Mine upgraded too far") at the top of your message. One problem per message. If you are not sure
whether something is a problem, report it anyway: with a line "not sure". Ideas, questions and "this was nice" are just
as welcome there — feedback is not only bugs.

Every report in test-corner is read and filed as an issue in the project, and you get an answer in the channel with
its number and what happens next.

## Good report, short example

> 2026-11-18 21:40 CET, pack 2026-11-17. Switches: Island, Chat, Trade on. Joe asked for an RT, DMA promised but never
> answered his trades. Happened once. Nothing spent. Files in the zip. Console log pasted.
