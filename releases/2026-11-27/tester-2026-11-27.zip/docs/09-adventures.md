# 9. Adventures in depth

This chapter is for testers who want to let DMA play a whole adventure. Read [03-features.md](03-features.md#adventures)
and the ADVS page in [02-console-tour.md](02-console-tour.md#advs-adventures) first. All adventures are **off** in a new
installation; nothing on this page happens until you switch an adventure on and press **Run once**.

## The five phases of every run

Every adventure run DMA plays goes through the same five phases. The console's status line shows the phase, the log
marks every change of phase, and the run's record keeps how long each phase took.

| Phase | What happens | What you check |
|---|---|---|
| **1 Prepare at home** | The version is analysed (is the Mundane complete, does the load carry enough for every wave, no blocks in a wave version). A version whose analysis is not ok is refused. | The troops of the load template are at home; every general and marshal of the load is home and idle; the adventure is in your star. |
| **2 Start and send** | The adventure is opened from the star, every general of the load is loaded at home and sent. | All generals leave; the log says "arrived". |
| **3 Landing to the first attack** | **Everything goes to the star first**, marshals (quartermasters) included. Then the first Mundane places every general on its spot, loads its army and starts the first attack. | Nobody stays on the landing spot; the marshals' troops are free on the island. |
| **4 Attack** | Each attack Mundane (wave) is played: the camps of the wave fall; between two waves the same generals come back, recover and are loaded again from the free troops. | The camps fall in the expected order; losses fall on the cheap units in front. |
| **5 Load troops and close** | After the last camp: quests claimed, the marshals come out of the star to their spot, every loose troop is loaded into a general, the "completed" message is acknowledged and everyone goes home. After the last attack no general goes to the star any more, so the generals keep their troops and travel home loaded. With **close at once** (below) DMA does not wait for generals that are still recovering. | No troops are left behind on the island; the adventure is gone from the list. |

## The star method

DMA plays adventures with the **star method**: on arrival every general goes into the adventure's star, and the first
Mundane takes each general out onto its own spot. Because the same generals are used again in every wave, the second
wave only **loads and attacks**: there is no new placing. After the last attack the marshals are put on the island so
every remaining troop can be loaded before the adventure is closed.

## Versions and their kinds

A *version* is a folder of Mundane templates plus a kind. Open an adventure on the ADVS page (▶) and choose **New
version**:

| Kind | Use it when |
|---|---|
| **without blocks (waves)** | Each attack template is one wave; generals are reused. A camp starts as soon as no live camp watches the way of its first attacker; on each camp the main attacker leaves only when the one before is fighting there. **Recommended for Bonaberti Business.** |
| **camp by camp** | One camp at a time, in the template's order. Slow but the safest. |
| **own Mundane** | Your own Mundane folder; DMA analyses it and plays it. |
| **author's Mundane** | A shared folder with a `generals.json`. DMA compares every general of the templates with yours (see below). |
| **blocks** | Templates where a general keeps a camp busy while another passes. A failed block can lose its army; needs *allow blocks* on the RULES page. Not advised. |

**Finish camp by camp (emergency).** If anything goes wrong in a run, press **Finish camp by camp** (next to **Stop**). It
ends the open adventure one camp at a time, whatever version started it.

## The load margin (adventures that reload between waves)

A version that reloads between waves must carry, from home, every wave's armies **plus the expected losses plus a
margin**. The margin is the rule *a version that reloads between waves loads every wave plus the expected losses, plus
this margin* (`adv.waves.loadMargin`, 0.25 = 25 %, RULES page). Ranged units are counted with a small expected loss,
the units in front (Recruits, Swordsmen, Knights) with their whole army. If the load is short the analysis says
**LOAD_SHORT** and the run does not start: add carriers (quartermasters) to the load template, or raise the troops at
home.

## Sharing a Mundane: the author's Bonaberti Business in two waves

The pack contains the author's **Bonaberti Business — two waves** Mundane as a shared folder (`adventures\BB two waves`
in the pack): `BB load`, `BB attack 01` (wave 1, sectors 1–3), `BB attack 02` (wave 2, sectors 4–6) and `generals.json`.

What DMA does with it on **your** island:

1. Copy the folder somewhere on your computer, for example `Documents\SOL\BB two waves`.
2. ADVS ▶ Bonaberti Business ▶ **New version**, kind **author's Mundane**, give it a name, **Folder…** → that folder.
3. The analysis compares every general of the templates with your own:

   | Result | Meaning |
   |---|---|
   | **SAME** | You have this very general (only the author has). |
   | **EQUAL** | You have an unused general of the same type with skills at least as high. It takes the place. |
   | **SKILLS_DIFFER** | Same type, but some named skills are lower: it may lose more troops. |
   | **ALTERNATIVE** | Another type whose capacity holds the army. Not simulated: treat with care. |
   | **MISSING** | Nobody of yours can take this place. |

   Camps that nobody of yours can cover are named; the run is refused while a camp is not covered.
4. **What this pack does not do yet:** rebuild the Mundane for your generals and skills (re-simulate every camp and
   resize the armies). That comes in the first update. Until then the analysis tells you whether the author's Mundane
   fits you, and what is missing.

### What a Bonaberti run looks like (author's control run, 2026-11-18)

18 of 18 camps, no intervention, about 3 hours. Lost: wave 1 about 790 Swordsmen, 560 Recruits, 330 Knights; wave 2
about 960 Swordsmen, 560 Recruits, 160 Knights; a few Mounted Marksmen and Mounted Swordsmen (17 and 7) where a front
buffer ran out on a bad roll. Troops to have at home before the run: the totals of the load template (the console's
analysis lists them).

## Your own Mundane as written (from 2026-11-26)

- **As written.** Every version is played the way its templates say: the generals and arrows in the template's order,
  each after its own delay, arrows in their place. DMA does not re-plan, re-time or split it. The guards stay: a step is
  not sent when a camp **nobody** in it attacks watches the way, and *retreat on interception* is still your choice.
- **Changing a plan is a new version.** *Make my Mundane* (rebuild for your generals, or from scratch) and *Save my copy*
  (another player's template with your generals) each save a **new** version after you approve it. The version you
  made stays as it is. *Camp by camp* and *without blocks* are kinds you choose for a version.
- **Checked before the start.** Before DMA promises the run it checks: the adventure in the star (one per run), every
  general is yours and free, every army fits its general (skills included), every arrow of the plan is in the star
  (counted over the runs), every speed-up you chose is in the star. If one is missing the run does not start and the
  ADVS page names it, for example `not promised: R-PLAN-ARROWS — arrows missing in the star (have/need):
  BattleBuffDestroy_small_medium_camps 1/2`.
- The settings *ALL: play my own Mundane template as it is* and *ALL: play camp by camp* are gone: they are no longer needed.

## Four ways to play a Mundane (from 2026-11-27)

![An adventure opened on the ADVS page: its version, and the Make my Mundane line](images/advs-make-my-mundane.png)

| # | Way | Button | Status | What changes |
|---|---|---|---|---|
| 1 | An existing Mundane **1:1** | choose the version under **Run**, press **Start** (or **Run once** on its row) | ready | Nothing. The template is played exactly as written. |
| 2 | An existing Mundane **1:1 with my generals of the same type** | **1:1 with my generals of the same type** | ready | Only the generals. Each of the author's generals is replaced by one of yours **of the same type**: the one that can carry the author's army first, then the most skilled. Spots, armies, targets, order, delays and arrows stay the author's. |
| 3 | An existing Mundane **with my own generals, other types allowed** | **Use with my generals** | **beta** | A camp keeps the author's attack when every general on it has a stand-in of the same type and still wins; the author's losses are then named, not planned away. Other camps are planned again for your generals. |
| 4 | **My own Mundane** | **Make new**, or **Optimise for my generals** | **beta** | The camps are planned for your generals and the scenarios you tick (see below). |

Each of ways 2 to 4 saves a **new** version. The Mundane you chose stays as it is. Way 2 stops with a clear message when
you lack a type, or when one of your generals cannot carry the author's army (for example *no general of yours of the type
of the author's Resolute General is free*). Then way 3 is the one to use.

**Routes are fixed.** The spot a general starts from and the camp it walks to are part of a version. DMA keeps to them.
- For a plan **DMA made** (ways 3 and 4), the way of every step is checked against the game's own interception picture
  before it is sent. A step that would walk past a camp nobody in it attacks is **not sent**, and the ADVS page names that
  camp.
- A plan from an author (ways 1 and 2) keeps the author's own rule: some authors let a general be caught on purpose.

**Watch the first run of a new plan.** Stay with the first run of a version made by way 3 or 4, check that every general
walks the way you expect, and press FEEDBACK when one does not.

## Make my Mundane (from 2026-11-26)

At the top of the ADVS page (**Run**) you choose a version; it is played exactly as it is (see above). Every adventure row
below has a **Make my Mundane** line. Each of its buttons makes **new** versions; the Mundane you chose stays as it is. The
line says **(beta: the last three)**: *1:1 with my generals of the same type* is ready, the other three are beta.

| Button | What it does |
|---|---|
| **1:1 with my generals of the same type** | The chosen Mundane exactly as written, only its generals replaced by yours of the same type (see *Four ways* above). |
| **Use with my generals** *(beta)* | Takes the chosen Mundane (**Folder...**, or the adventure's version with a `generals.json`) and puts **your** generals in the author's places, with the author's attacks. |
| **Optimise for my generals** *(beta)* | Takes the chosen Mundane and plans its camps again for your generals and the scenarios you ticked. |
| **Make new** *(beta)* | Makes a Mundane from the adventure's camps and your generals alone, for the scenarios you ticked. |

**Scenarios** (tick one or more; each gives its own version to compare):

- **quick loot** *(beta)* — only the camps the quests ask for, and the camps that stand in their way. DMA reads the quests
  when you open the adventure once; until then every camp is planned (it says so). *Make new* only.
- **most XP**, **fastest**, **fewest losses**, **cheapest**, **quickest rebuild** (the losses your barracks train back
  quickest), **multiple runs** (generals kept free for the next run).
- **only arrows** *(beta)* — no generals: every camp is taken by a destroy arrow from your star (**Small Catapult**: an easy
  camp; **Big Catapult**: an easy or medium camp). Camps no arrow can take are named. *Make new* only.
- **loss limit** — "at most *n* *troop type*" (for example `0` `Knight`, or a quest's "lose fewer than…"). Every scenario keeps to it.

**Destroy arrows in every plan** *(beta)*: when your star holds Small or Big Catapults, *Make new* gives the camps they can
take to the arrows instead of to a general, the cheapest arrow first. The arrows stand first in the first attack.

In the background (default) or **with priority**. The versions appear side by side: camps, losses in the bad case, minutes
of fighting, rebuild minutes, XP, generals beaten, problems. **Save** adds the one you choose as a new version, named
`my <scenario> <date>` (with `beta` for quick loot and arrows plans).

**Check my versions** compares the generals each saved version was made for with your generals now, and offers to analyse
the changed ones again.

Good to know:

- The camps come from the game once you have seen the adventure; before that DMA uses tsowiki's camps (marked).
- Quick loot and the arrows are **beta**: watch the first run of such a version and press FEEDBACK when a camp was missing
  from the plan or an arrow was refused.

## First attack home, close at once, landing fields (from 2026-11-22)

Two choices per adventure, in its row on the ADVS page (and for all adventures under **Advanced**). Both are **off** for
every adventure except YWC, where they match the author's own play.

- **First attack home** (`adv.<id>.aheadHome`). The generals that only fight in the first attack go **home** as soon as
  they are free, instead of to the star. The log says `first attack done: GHOST1 sent home`. When you run the same
  adventure several times in a row, they are home early for the next run. A run that is picked up again after a restart
  leaves them home (`… home on purpose … not sent again`).
- **Close at once** (`adv.<id>.closeAtOnce`). When the last camp falls the adventure is closed right away: quests
  claimed, collectables picked up, everyone sent home. DMA does not wait for generals that are still recovering; loose
  troops still go into the generals that are free (`stow before closing: …`).
- **Landing fields are read from the game.** How many generals can land at once is a fact of each adventure, not a
  setting. The ADVS row shows the number with a colour: green = read from the game, blue = read online, grey = not
  seen yet (DMA reads it the first time you play the adventure).
- **Every general of the load must be home.** Before a run starts DMA checks that every general of the load is home
  and idle. Generals on their way home are named with their arrival time (`on their way home: GEN1 2 min, …`); the
  run starts by itself after the last one arrives.

## The ADVS page, top to bottom (from 2026-11-20)

The page reads from the top. Every block folds: click its title bar to close or open it; the console remembers.

| Block | What it does |
|---|---|
| **Run** | **Adventure** (with your star count), **Version** (the versions you made for it; *+ make a new version…* opens the adventure's row where versions are made, and the new one appears here by itself), **How many**: *once*, *keep running* or *number of runs*, and **Start** / **Stop**. *Keep running* and *number of runs* hand the run to the adventure manager and light the **Adventure** switch. |
| **Speed it up** | Ticks for every run: *make the next round ready while one fights*, and the travel speed-ups in your star (Black Vortex, Doggy Bag, horseshoes, star charts) or a free **Observatory**. A tick is kept at once; a choice that excludes another greys that one out (horseshoes exclude each other; the Observatory's boosts exclude each other). |
| **All adventures** | The rules that hold for every adventure, single runs, kept runs and series alike: retreat on interception (`adv.retreat.on`) and the load margin. |
| **Adventures** | One row per adventure: on/off, its own rules (for YWC: *play my Mundane as it is*, *retreat a general that is intercepted*), its versions (▶). |
| **Advanced** | Closed by default: retry minutes of the adventure manager, the speed-up family and match patterns. |

**Keep running.** Once a minute the adventure manager checks: no run going, you are on your home island, enough of
the adventure in the star, and the last run did not stop less than 30 minutes ago. Then it starts the next run with your
version and counts it ("3 of 5 runs"). It also tells the troop manager which adventure is next. When a run stops it tells
you once why and tries again after 30 minutes. Do not play the same adventure by hand while the Adventure switch is on.

**Make the next round ready.** While a round fights, the generals of the next round come out of the star onto their spot
and are loaded, so the next round only has to attack.

## Worked example: Ali Baba the Young Woodcutter (YWC)

YWC is the reference adventure for this release: about 430 oilseed per run, played with the author's own Mundane.

1. **Once:** ADVS → *Ali Baba the Young Woodcutter* → ▶ → **New version**, kind **own Mundane**, a name (`full`),
   **Folder…** to your YWC template folder, **Analyse** (no errors), tick **default**.
2. **YWC rules in its row:** on; *play my Mundane as it is* **on** (your order and timing kept exactly); *retreat a
   general that is intercepted* **off** (YWC intercepts some generals on purpose).
3. **Speed it up:** tick what you want, for example *make the next round ready* and Black Vortex.
4. **Run:** Adventure *Ali Baba the Young Woodcutter*, Version *full*, How many *once*, **Start**.
5. Watch the status line: `starting 1001NightsWoodcutter (… in the star)`, `send 1: … generals`,
   `arrival: all generals to the star first`, … , `home; run took N min`.

When it stops, the log says why:

| The log says | What to do |
|---|---|
| not enough troops at home for … | Train or bring home the units named. Loose troops on an adventure travel home for about 2 hours. |
| only N in the star | Get more YWC (the merchant, for map fragments, or an explorer's very long adventure search). |
| version … does not start: … | Open the version, **Analyse**, fix the error it names. |
| a run is already going | Wait for it, or **Stop** first. |
| … generals could not take their position | **Finish camp by camp**, or move the general by hand and press **Run once**. |

## Good practice

- Run an adventure for the first time while you watch it. Keep the console open on the ADVS page.
- Do not move generals by hand while a run is going; press **Stop** first.
- Keep at least the load template's troops at home; the **Troops** switch with targets on the TROOPS page can keep them up.
- If a run stops with a reason in red, write the reason down and report it ([07-reporting.md](07-reporting.md)).
