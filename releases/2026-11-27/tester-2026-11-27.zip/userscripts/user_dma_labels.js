/*
 * DMA Labels 0.1.0
 * Load this with the other userscripts, before the console.
 * Does not write tso_client settings.json.
 *
 * Slot names live in DMA_LABELS_FILE below. Edit them by hand, or change
 * them in the console and press Save policy. That downloads a new copy.
 * Until you replace the file, the console also keeps the names in
 * localStorage, so a restart does not lose them.
 */
window.DMA_LABELS_FILE = window.DMA_LABELS_FILE || {
};

(function (root) {
    "use strict";
    var KEY = "iso:dma.labels.v1";
    var FILE = root.DMA_LABELS_FILE || {};

    function readStore() {
        try {
            var raw = localStorage.getItem(KEY);
            if (raw) return JSON.parse(raw) || {};
        } catch (_) {}
        return {};
    }
    function writeStore(map) {
        try { localStorage.setItem(KEY, JSON.stringify(map)); } catch (_) {}
    }
    var store = readStore();
    function adopt() {
        var file = root.DMA_LABELS_FILE || {};
        var n = 0, key;
        for (key in file) {
            if (!file.hasOwnProperty(key)) continue;
            if (file[key] == null || file[key] === "") continue;
            store[key] = String(file[key]);
            n += 1;
        }
        if (n) writeStore(store);
        return n;
    }
    adopt();

    function get(key) {
        if (!key) return "";
        var v = store[String(key)];
        return v == null ? "" : String(v);
    }
    function set(key, value) {
        if (!key) return "";
        store[String(key)] = value == null ? "" : String(value);
        writeStore(store);
        return store[String(key)];
    }
    function all() {
        var out = {}, i;
        for (i in store) if (store.hasOwnProperty(i)) out[i] = store[i];
        return out;
    }
    function fileText() {
        return "/*\n * DMA Labels 0.1.0\n * Replace this file in the scripts folder. Loaded at client start.\n * Does not write tso_client settings.json.\n */\nwindow.DMA_LABELS_FILE = " + JSON.stringify(all(), null, 2) + ";\n";
    }

    root.DMA_Labels = {
        version: "0.1.0",
        get: get,
        set: set,
        all: all,
        adopt: adopt,
        fileText: fileText
    };
})(typeof window !== "undefined" ? window : this);
