/*
 * Stable client filename: user_dma_zombies.js
 * DMA Zombie manager 0.1.9 — actor role "zombie hunt manager" (AR76, self-activating, TK76) that has every zombie crypt on
 * the home island cleared by a general (crypt clearer, AR77, TK77 "[zombie crypt] is cleared"). Decision 0043.
 *
 * Author, 2026-11-02 12:44 local: "Het aanvallen van de zombies is ook iets wat ik wil dat je automatiseert bij event
 * halloween: plaatsen van de vier gens vol met mounted marksmen en de vier kampen aanvallen zodra ze er zijn. Dat totdat
 * je er 120 gekilled hebt" — "ik heb al vier gens in de buurt gezet" — the count is the event's "achievements".
 *
 * Read live (src/tools/user_dma_probe_zombie.js 0.1.0–0.1.1, 2026-11-02): a crypt is a building "ZombieCrypt" whose army
 * holds "HalloweenZombieInvader" (100); generals are loaded with dRaiseArmyVO (1031) the way user_dma_adventure.js loads
 * them; an attack is server action 95 subtask 5 on the camp's grid with the general as the cursor's specialist (the
 * adventure executor's call); the free army is the Mundane script's armyFreeInfo; the island grid is 128 wide.
 *
 * RED (what the player decides, policy keys):
 *   zombie.auto      switch (default off since 0.1.7)
 *   zombie.target    kills to reach (default 120); compared with the event achievement once DMA has learned which
 *                    achievement trigger counts a cleared crypt, until then with the crypts DMA cleared itself
 *   zombie.generals  the generals of the hunt (unique ids or names, comma separated); empty = the four generals nearest
 *                    to the first crypt seen, chosen once and kept (dma-zombie-status.json) so they do not change
 *   zombie.unit      the unit they are filled with (default MountedMarksman)
 * COMPUTING (I, green): which crypts hold zombies, which generals are idle and full, the kill count.
 * THE CRYPT CLEARER (AR77, executor of TK77 — original production): loading a general and sending the attack; the
 *   server sends are its implementation. The status file is documental (D, blue).
 *
 * TK77, one instance per crypt case (caseId "crypt@<grid>#<n>"): request (zombie hunt manager) -> promise (the general:
 * the attack order is sent) -> execute (the attack runs) -> declare (the crypt holds no zombies any more) -> accept
 * (the manager, tacit). An attack that ends with the crypt still standing: revoke promise + allow (tacit): the case is
 * requested again and the next idle full general takes it. No idle full general: nothing is promised (it waits).
 * The achievement trigger is LEARNED, never guessed: before an attack all trigger values are kept; when the crypt is
 * cleared, the triggers that rose are candidates; the trigger that rose on every clear so far is the count.
 *
 * 0.1.11 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C3 of the migration): the zombie hunt does
 *   not send itself. Its gateway's three sends — raise army (1031), attack the camp (95/5), move a general (95/4) — go through the
 *   Game Interface Adapter by registered name (RAISE_ARMY, SPECIALIST_TASK): start-up and visit holds, pace per class, control's
 *   permit opened by the adapter for the one call. The gateway answers true/false as before and keeps the adapter's refusal in
 *   G.refusal ({ reason, retry }). The executor records the answer: the TK77 promise only on ok; on a transient refusal (retry: a
 *   hold or the pace) the case stays requested and the hunt waits; on any other refusal the case is declined with the adapter's
 *   reason. No adapter loaded = refused "game interface adapter not loaded". This is the fix of
 *   kf-zombies-attack-blocked-by-control, which moves into the suite as tests/integration/zombies-attack-through-adapter.test.js.
 *   Unit: tests/unit/dma-zombies.test.js (an adapter refusal: no promise; retry keeps the case, a hard refusal declines).
 *   Integration: tests/integration/zombies-attack-through-adapter.test.js (real control + adapter + zombies).
 * 0.1.10 (2026-11-16, architect on PR #387; agents 0.4.28 makes "could not read" distinguishable): an events picture
 *   that says NOT READABLE (no event manager found in the client) no longer reads as "Halloween is not running". The hunt
 *   waits with "could not read events" (and the picture's why), requests nothing and declines nothing — a case is
 *   declined only when the picture is readable and Halloween is not in it. Nothing else changes.
 *   Unit: tests/unit/dma-zombies.test.js (an unreadable picture: "could not read events", a requested case stays
 *   requested). Integration: tests/integration/dma-zombies-halloween.test.js (agents' wake with no event manager in the
 *   client: the zombie manager says "could not read events" and declines nothing).
 * 0.1.9 (2026-11-16, author: the zombie hunt is tied to the Halloween event; model PR #384: DFS-48 "an event of [event
 *   name] is running", ARS-76-11 truth "an event of Halloween is running for [period]", ARS-77-02 truth "the event of
 *   [event item] is Halloween and an event of Halloween is running when [event item] is acted on"): the hunt runs ONLY
 *   while Halloween runs, in addition to the switch zombie.auto (still default off). Whether Halloween runs is read
 *   from the location manager's events picture (DMA_Demo.eventRunning, agents 0.4.27; ADR 0040) with the prefixes of the
 *   player's rule event.halloween.gameNames, else "Halloween, HW". Outside Halloween the manager requests nothing
 *   (ARS-76-11) and the crypt clearer DECLINES every case still only requested, with the reason "Halloween is not
 *   running" (ARS-77-02); an attack already promised runs to its end as before. Without the picture (agents older than
 *   0.4.27, or not loaded) the hunt waits ("no events picture") — fail closed.
 *   Unit: tests/unit/dma-zombies.test.js (+ Halloween not running: no request, a requested case declined by the crypt
 *   clearer; no picture: waits). Integration: tests/integration/dma-zombies-halloween.test.js (agents' events picture +
 *   the real policy + the zombie manager on its real gateway: Halloween running and switched on -> it acts; Halloween
 *   over -> it declines and requests nothing).
 * 0.1.8 (2026-11-16, tester report 2026-11-16 (PR #373) item D9, known-failing kf-initiator-acts-actor; EO2 ch. 8 —
 *   request, accept, reject, revoke request, revoke accept and revoke reject are the INITIATOR's acts): the writer chose
 *   the actor as "request or accept -> manager, else the general", so "revoke request" (the crypt is gone) was recorded
 *   with the general as actor (live: actor "general "). Every initiator act is now recorded as the zombie hunt manager's;
 *   the executor's acts (promise, decline, declare, revoke promise, revoke declare, execute) as the general's; an
 *   explicit actor (the tacit allow) still wins. Nothing that is sent changes.
 *   Unit: tests/unit/dma-zombies.test.js (the crypt gone: revoke request by the zombie hunt manager, allow by the general;
 *   the attack failed: revoke promise by the general, allow by the manager). Integration:
 *   tests/integration/dma-zombies-default.test.js (+ the tester's static check: every initiator act a writer records
 *   without an explicit actor is on the initiator side).
 * 0.1.7 (2026-11-16, architecture review 2026-11-16 findings #12/§5.2, #17 and #19): (#12) the switch zombie.auto
 *   falls back to OFF when no policy answers ("not in the testers' pack" is no reason for a default on: a pack built by
 *   globbing would ship it); policy 0.2.58 registers it, default off. (#19) The title line said 0.1.5 while VERSION was
 *   0.1.6; both now say 0.1.7. (#17) The header no longer calls loading and attacking "BLUE": that is the crypt clearer's
 *   original production. No other behaviour change.
 *   Unit: tests/unit/dma-zombies.test.js (the switch unset -> "off"; the hunt runs only when the player switched it on).
 *   Integration: tests/integration/dma-zombies-default.test.js (real policy + zombie manager on its real gateway: fresh
 *   policy -> "off", nothing sent; a stored zombie.auto true -> the hunt ticks past the switch).
 * 0.1.5 (live 2026-11-11 02:39: the 17 Bonaberti generals left, the hunt kept GHOST1, YGG2, STEAD3, STEAD2 and nobody
 *   took their places — the hunt was the player's list zombie.generals, which 0.1.4 never replaced): the player's list
 *   is the hunt's starting set with their spots; a listed general that leaves is replaced like any other.
 * 0.1.4 (author 2026-11-10 19:08: "als je de gens naar bonaberti hebt gestuurd zet je andere gens voor de zombies terug op
 *   die plek voor alle vier de zombies" — almost any general will do with Mounted Marksmen, also generals in the star):
 *   every hunt general keeps its spot (the grid it stood on when chosen). A hunt general that left the island (an
 *   adventure, the star) is replaced by another general: idle at home nearest the spot first, else one from the star;
 *   it is moved to the spot (server action 95/4, the adventure executor's move) and loaded there as usual. Not while
 *   an adventure run is still loading or sending its generals (dma-adv-status.json state PRECHECK, START, LOAD,
 *   LOADR, SEND), so a general of that run is never taken. Fact "zombie hunt general replaced". The player's own list
 *   (zombie.generals) is not replaced.
 * 0.1.6 (live 2026-11-15, author: "4e zombie still stands"): the status read "target reached: 1210 of 120 (achievement
 *   (best seen, tier finished))" with 112 crypts cleared by DMA, so the last crypt (12913) was left standing. Two rules:
 *   with no live achievement tier the count is the crypts DMA cleared itself (the best seen is no longer trusted); and
 *   a trigger is only a candidate when it rose by exactly one on a clear (one crypt = one count), and when it is
 *   learned its value replaces the best. A state with a stale best counts its own clears again. ADR 0068.
 * 0.1.3 (live 2026-11-10, probe 0.1.51: 1958 = 0/20, 1959 = 0/60, 1960 = 100/120 while the status said "0 of 120
 *   (achievement 1959:0)"): a finished tier reads 0. All tiers are now kept; the count is the highest tier value and
 *   never falls below the best count seen; a tier that falls below it is finished and dropped; with no tier left the
 *   count is learned again at the next clear (meanwhile the best count, or the crypts DMA cleared). A state from 0.1.2
 *   (one trigger, no tiers) is learned again.
 * 0.1.2 (2026-11-04, author: "van de zombie crypt worden er telkens maar 3 van de 4 aangevallen"): crypt 8349 was given
 *   442 times to the same general (STEAD3, the nearest); his attack never started and the crypt kept its 100 zombies.
 *   Now a general is only sent when Mundane's own check finds a path from the crypt to him, and a general whose attack did
 *   not start is not sent to that crypt again — the next nearest takes it (all tried: start over).
 * 0.1.1 (live, first clear 12:18 UTC: three triggers rose together, 1958/1959/1960, each from 19 to 20 — the tiers of one
 *   count, marked finished, so the probe's unfinished list did not show them): candidates that had the same value before
 *   and the same value after on every clear are one count; the first is taken (fact "zombie kill count learned", with
 *   the tiers). The count is then the achievement's (20 at that moment), compared with zombie.target.
 * Unit expectation:        tests/unit/dma-zombies.test.js — four generals nearest the crypt chosen once; a general
 *                          that is not full of the unit is loaded (once a minute at most); a full idle general attacks a
 *                          crypt; the crypt gone -> declare + accept and the count rises; a lost attack -> revoke promise
 *                          + allow and another attack; the target reached -> no new request; the trigger is learned; the
 *                          state survives a reload; switch off or away -> nothing.
 * Integration expectation: live, a crypt that appears is attacked within a minute by a general of the hunt, and the
 *                          facts hold the full TK77 pattern; dma-zombie-status.json shows the count and the learned trigger.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.11";
    if (root.DMA_Zombies && root.DMA_Zombies.version) return;
    var STATUS = "dma-zombie-status.json", TICK_MS = 15000, LOAD_GAP = 60000, ATTACK_LOST_MS = 90000, ATTACK_MAX_MS = 25 * 60000, W = 128;
    var QM_TYPES = { 12: 1, 27: 1, 54: 1, 82: 1 };   // quartermasters carry, they do not fight (ADR 0033)

    /* ---------------- gateway: the game, the files, the facts (replaced in the tests) ---------------- */
    function gameGateway() {
        var R = root;
        function g() { return R.game; }
        function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
        function me() { try { return g().player.GetPlayerId(); } catch (_) { return null; } }
        var refusal = null;   // 0.1.11 (ADR 0073): the adapter's answer to the last send that was refused
        function viaAdapter(fn) {
            var A = R.GCAF_GameInterface, r = null; refusal = null;
            if (!A) { refusal = { reason: "game interface adapter not loaded", retry: false }; return false; }
            try { r = fn(A); } catch (e) { r = { ok: false, reason: "send failed: " + e }; }
            if (r && r.ok) return true;
            refusal = { reason: (r && r.reason) || "no answer from the adapter", retry: !!(r && r.retry) }; return false;
        }
        function spec(key) { try { return R.armyGetSpecialistFromID(String(key)); } catch (_) { return null; } }
        function units(army) {
            var out = {}, v; try { v = army.GetSquadsCollection_vector(); } catch (_) { return out; }
            for (var i = 0; v && i < v.length; i++) {
                var s = v[i]; if (!s) continue;
                var n = null, a = null;   /* the probe read the type and amount through one of these (0.1.0 armyUnits) */
                try { n = typeof s.GetUnitType === "function" ? s.GetUnitType() : null; } catch (_) {}
                try { if (n == null && typeof s.GetType === "function") n = s.GetType(); } catch (_) {}
                try { if (n == null && typeof s.GetUnitBase === "function") n = s.GetUnitBase().GetType(); } catch (_) {}
                try { a = typeof s.GetAmount === "function" ? s.GetAmount() : (s.amount != null ? s.amount : (typeof s.GetUnitCount === "function" ? s.GetUnitCount() : null)); } catch (_) {}
                if (n == null || !(Number(a) > 0)) continue;
                out[String(n)] = (out[String(n)] || 0) + Number(a);
            }
            return out;
        }
        return {
            refusal: function () { return refusal; },
            now: function () { return Date.now(); },
            /* 0.1.9: DFS-48 for Halloween from the location manager's events picture; undefined = no picture */
            halloween: function () {
                try { var D = R.DMA_Demo; if (!D || typeof D.eventRunning !== "function" || typeof D.events !== "function" || !D.events()) return undefined;
                      var pic = D.events(); if (!pic.readable) return { unreadable: true, why: String(pic.why || "") };   // 0.1.10
                      var P = R.GCAF_PlayerPolicyInstance, pre = P && P.get ? P.get("event.halloween.gameNames") : null;
                      return D.eventRunning(pre ? String(pre) : "Halloween, HW") || null; } catch (_) { return undefined; }
            },
            atHome: function () { try { var C = R.DMA_Control; if (C && typeof C.atHome === "function") return !!C.atHome(); } catch (_) {} try { return !!g().gi.isOnHomzone(); } catch (_) { return false; } },
            rule: function (k, d) { try { var P = R.GCAF_PlayerPolicyInstance, v = P && P.get ? P.get(k) : undefined; return v == null || v === "" ? d : v; } catch (_) { return d; } },
            crypts: function () {
                var out = [], v; try { v = g().gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector(); } catch (_) { return out; }
                for (var i = 0; v && i < v.length; i++) {
                    var b = v[i]; if (!b) continue;
                    var nm = ""; try { nm = String(b.GetBuildingName_string()); } catch (_) {}
                    if (!/^ZombieCrypt/.test(nm)) continue;
                    var a = null, n = 0; try { a = b.GetArmy(); n = a && a.HasUnits() ? Number(a.GetUnitsCount()) : 0; } catch (_) {}
                    out.push({ grid: Number(b.GetGrid()), name: nm, zombies: n });
                }
                return out;
            },
            generals: function () {
                var out = [], mine = me();
                try { g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) {
                    try {
                        if (!s || s.getPlayerID() !== mine || !R.armySPECIALIST_TYPE.IsGeneral(s.GetType())) return;
                        var gr = Number(s.GetGarrisonGridIdx()), star = !(gr > 0);   /* 0.1.4: grid 0 = in the star */
                        var nm = ""; try { nm = String(s.getName(false)).replace(/<[^>]*>/g, ""); } catch (_) {}
                        out.push({ key: s.GetUniqueID().toKeyString(), name: nm, type: Number(s.GetType()), grid: star ? 0 : gr, star: star,
                                   idle: s.GetTask() == null && !s.IsInUse(), cap: Number(s.GetMaxMilitaryUnits()) || 0, army: units(s.GetArmy()) });
                    } catch (_) {}
                }); } catch (_) {}
                return out;
            },
            free: function (unit) { try { if (typeof R.updateFreeArmyInfo === "function") R.updateFreeArmyInfo(true); return Number(R.armyFreeInfo && R.armyFreeInfo[unit]) || 0; } catch (_) { return 0; } },
            load: function (key, army) {   /* the adventure executor's direct path (user_dma_adventure.js G.load) */
                var s = spec(key); if (!s) return false;
                var VO = R.dRaiseArmyVODef || R.swmmo.getDefinitionByName("Communication.VO::dRaiseArmyVO"),
                    RVO = R.dResourceVODef || R.swmmo.getDefinitionByName("Communication.VO::dResourceVO");
                var vo = new VO(); vo.armyHolderSpecialistVO = s.CreateSpecialistVOFromSpecialist();
                Object.keys(army).forEach(function (u) { var r = new RVO(); r.name_string = u; r.amount = army[u]; vo.unitSquads.addItem(r); });
                return viaAdapter(function (A) { return A.sendMessage("RAISE_ARMY", vo); });
            },
            attack: function (key, grid) {   /* the adventure executor's call: server action 95, subtask 5, on the camp */
                var s = spec(key); if (!s) return false;
                g().gi.mCurrentCursor.mCurrentSpecialist = s;
                var t = new R.armySpecTaskDef(); t.uniqueID = s.GetUniqueID(); t.subTaskID = 0;
                return viaAdapter(function (A) { return A.sendAction("SPECIALIST_TASK", 5, Number(grid), 0, t); });
            },
            /* 0.1.4: move a general (at home or in the star) to a grid: the adventure executor's move (95/4) */
            move: function (key, grid) {
                var s = spec(key); if (!s) return false;
                g().gi.mCurrentCursor.mCurrentSpecialist = s;
                var t = new R.armySpecTaskDef(); t.uniqueID = s.GetUniqueID(); t.subTaskID = 0;
                return viaAdapter(function (A) { return A.sendAction("SPECIALIST_TASK", 4, Number(grid), 0, t); });
            },
            /* 0.1.4: an adventure run still loading or sending its generals (its generals must not be taken) */
            advSending: function () {
                try { var a = airApi(), f = new a.File(a.File.applicationDirectory.resolvePath("dma-adv-status.json").nativePath); if (!f.exists) return false;
                      var st = new a.FileStream(); st.open(f, a.FileMode.READ); var d = JSON.parse(st.readUTFBytes(st.bytesAvailable)); st.close();
                      return /^(PRECHECK|START|LOAD|LOADR|SEND)$/.test(String(d.state || "")) && Date.now() - Date.parse(d.since || 0) < 30 * 60000; } catch (_) { return false; }
            },
            /* 0.1.2: Mundane's own attack check (5-battle.js battlecheckCanAttack): a path from the camp's street entry to
               the general's grid. Unknown (no path finder) counts as reachable. */
            reach: function (key, grid) {
                try { var s = spec(key), b = g().zone.mStreetDataMap.GetBuildingByGridPos(Number(grid)); if (!s || !b) return true;
                      var p = g().gi.mPathFinder.CalculatePath(b.GetStreetGridEntry(), s.GetGarrisonGridIdx(), null, true);
                      return !!(p && p.pathLenX10000 > 0); } catch (_) { return true; }
            },
            triggers: function () {
                var out = {};
                try { var m = g().gi.getCurrentUserAchievementManager(), v = m.getAllActiveTriggers();
                      for (var i = 0; v && i < v.length; i++) { var t = v[i]; if (t && t.getType() === "progress") out[t.getAchievementId() + ":" + t.getTriggerId()] = Number(t.getValue()) || 0; } } catch (_) {}
                return out;
            },
            fileRead: function (name) {
                try { var a = airApi(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
                      var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
            },
            fileWrite: function (name, obj) {
                try { var a = airApi(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath), st = new a.FileStream();
                      st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); return true; } catch (_) { return false; }
            },
            record: function (kind, data) { try { if (R.DMA_Demo && R.DMA_Demo.record) R.DMA_Demo.record(kind, data); } catch (_) {} },
            log: function (m) { try { if (typeof R.debug === "function") R.debug("DMA Zombies " + VERSION + ": " + m); } catch (_) {} }
        };
    }

    /* ---------------- the manager ---------------- */
    function createManager(G) {
        G = G || gameGateway();
        var st = G.fileRead(STATUS) || {};
        var state = { version: VERSION, hunt: st.hunt || null, cleared: Number(st.cleared) || 0, cases: st.cases || {}, n: Number(st.n) || 0,
                      trigger: st.tiers ? (st.trigger || null) : null, tiers: st.tiers || null, best: Number(st.best) || 0,
                      candidates: st.tiers ? (st.candidates || null) : null, done: !!st.done, loadAt: st.loadAt || {}, last: st.last || "", listSig: st.listSig || null, lastCrypt: Number(st.lastCrypt) || 0 };
        var dirty = false;
        function save() { state.at = new Date(G.now()).toISOString(); G.fileWrite(STATUS, state); dirty = false; }
        function say(m) { if (state.last !== m) { state.last = m; dirty = true; G.log(m); } }
        function c(act, cs, extra) {
            var o = { tk: "TK77", act: act, caseId: cs.id, grid: cs.grid, actor: act === "request" || act === "accept" || act === "reject" || act === "revoke request" || act === "revoke accept" || act === "revoke reject" ? "zombie hunt manager" : "general " + (cs.gname || cs.general || "") }, k;   /* 0.1.8: every initiator act (EO2 ch. 8) */
            for (k in (extra || {})) o[k] = extra[k];
            G.record("c", o);
        }
        function unit() { return String(G.rule("zombie.unit", "MountedMarksman")); }
        function target() { return Number(G.rule("zombie.target", 120)) || 120; }
        function full(gen) {
            var u = unit(), keys = Object.keys(gen.army || {});
            return gen.cap > 0 && (gen.army[u] || 0) >= gen.cap && keys.length === 1;
        }
        function dist(a, b) { var ax = a % W, ay = Math.floor(a / W), bx = b % W, by = Math.floor(b / W); return Math.sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by)); }
        /* the generals of the hunt: the player's list, else the four nearest the first crypt seen (kept) */
        function hunt(gens, crypts) {
            var list = String(G.rule("zombie.generals", "") || "").split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, ""); }).filter(Boolean);
            if (list.length) {   /* 0.1.5: the player's list starts the hunt; its generals keep spots and are replaced when they leave */
                var sig = list.join(",");
                if (state.listSig !== sig) {
                    var picked = gens.filter(function (g) { return list.indexOf(g.key) >= 0 || list.indexOf(g.name) >= 0 || list.some(function (x) { return g.name.indexOf(x) === 0; }); });
                    if (picked.length || !state.hunt) { state.hunt = picked.map(function (g) { return { key: g.key, name: g.name, spot: g.star ? 0 : g.grid }; }); state.listSig = sig; dirty = true; }
                }
            }
            if (!state.hunt && crypts.length) {
                var c0 = crypts[0].grid;
                state.hunt = gens.filter(function (g) { return !QM_TYPES[g.type] && g.cap > 0 && !g.star; })
                    .sort(function (a, b) { return dist(a.grid, c0) - dist(b.grid, c0); }).slice(0, 4)
                    .map(function (g) { return { key: g.key, name: g.name, spot: g.grid }; });
                dirty = true;
                G.record("p", { tk: "TK76", fact: "zombie hunt generals chosen", generals: state.hunt.map(function (h) { return h.name; }).join(", "), nearCrypt: c0 });
            }
            var byK = {}; gens.forEach(function (g) { byK[g.key] = g; });
            (state.hunt || []).forEach(function (h) { var g = byK[h.key]; if (!h.spot && g && !g.star) { h.spot = g.grid; dirty = true; } });   /* a 0.1.3 hunt learns its spots */
            replace(gens, byK);
            var keys = (state.hunt || []).map(function (h) { return h.key; });
            return gens.filter(function (g) { return keys.indexOf(g.key) >= 0 && !g.star; });
        }
        /* 0.1.4: a hunt general that left the island is replaced on its spot by another general (home first, then star) */
        function replace(gens, byK) {
            var now0 = G.now();
            (state.hunt || []).forEach(function (h) { var g = byK[h.key]; if (h.moving && g && !g.star) { delete h.moving; delete h.movedAt; dirty = true; } });
            var gone = (state.hunt || []).filter(function (h) { var g = byK[h.key]; return (h.spot || state.lastCrypt) && (!g || (g.star && !(h.moving && now0 - (h.movedAt || 0) < 5 * 60000))); });
            if (!gone.length) return;
            if (G.advSending && G.advSending()) { say("waiting: an adventure run is still sending its generals"); return; }
            var inHunt = {}; state.hunt.forEach(function (h) { inHunt[h.key] = true; });
            gone.forEach(function (h) {
                var cands = gens.filter(function (g) { return !inHunt[g.key] && !QM_TYPES[g.type] && g.cap > 0 && g.idle; })
                    .sort(function (a, b) { var to = h.spot || state.lastCrypt; return (a.star - b.star) || (a.star ? 0 : dist(a.grid, to) - dist(b.grid, to)); });
                var g = cands[0];
                if (!g) { say("no general left to stand on spot " + h.spot + " (" + h.name + " left)"); return; }
                if (h.spot) { if (!G.move || !G.move(g.key, h.spot)) return; }
                else if (g.star) return;   /* 0.1.5: no spot known (it left before one was learned): the nearest general at home to the last crypt takes over where it stands */
                G.record("p", { tk: "TK76", fact: "zombie hunt general replaced", left: h.name, by: g.name, spot: h.spot, from: g.star ? "star" : "grid " + g.grid });
                h.key = g.key; h.name = g.name; if (h.spot) { h.moving = true; h.movedAt = now0; } else h.spot = g.grid; inHunt[g.key] = true; dirty = true;
            });
        }
        function count() {
            if (state.trigger && state.tiers) {   /* 0.1.3: a finished tier reads 0 */
                var tv = G.triggers(), live = [], v = -1;
                state.tiers.forEach(function (k) { var x = tv[k]; if (x == null) return; x = Number(x); if (x >= state.best) { live.push(k); if (x > v) v = x; } });
                if (live.length !== state.tiers.length) {
                    G.record("p", { tk: "TK76", fact: "zombie kill count tier finished", finished: state.tiers.filter(function (k) { return live.indexOf(k) < 0; }).join(", "), best: state.best });
                    state.tiers = live.length ? live : null; state.trigger = live.length ? live[0] : null; if (!live.length) state.candidates = null; dirty = true;
                }
                if (v > state.best) { state.best = v; dirty = true; }
                if (state.trigger) return { n: Math.max(v, state.best), via: "achievement " + state.trigger };
            }
            /* 0.1.6: with no live achievement tier the count is the crypts DMA cleared itself — a best seen earlier is not
               trusted any more (live 2026-11-15: "1210 of 120 (best seen, tier finished)" stopped the hunt at 112 own clears) */
            return { n: state.cleared, via: "crypts cleared by DMA" };
        }
        function learn(before, after) {
            /* 0.1.6: one cleared crypt raises the count by exactly one (0.1.1 live: 19 -> 20); a trigger that rose by more counts something else */
            var rose = Object.keys(after).filter(function (k) { return before[k] != null && Number(after[k]) - Number(before[k]) === 1; });
            state.candidates = state.candidates ? state.candidates.filter(function (k) { return rose.indexOf(k) >= 0; }) : rose;
            var c0 = state.candidates, same = c0.length > 1 && c0.every(function (k) { return after[k] === after[c0[0]] && before[k] === before[c0[0]]; });
            if ((c0.length === 1 || same) && !state.trigger) {   /* 0.1.1: tiers of one count rise together */
                state.trigger = c0[0]; state.tiers = c0.slice(); state.best = Number(after[c0[0]]);   /* 0.1.6: the learned value, not an older best */
                G.record("p", { tk: "TK76", fact: "zombie kill count learned", trigger: state.trigger, value: after[state.trigger], tiers: c0.join(", ") });
            }
            dirty = true;
        }
        function tick() {
            var now = G.now();
            var zon = G.rule("zombie.auto", false);   // 0.1.7: default off (review #12)
            if (!(zon === true || String(zon) === "true")) { say("switched off"); if (dirty) save(); return "off"; }
            if (!G.atHome()) { say("away"); if (dirty) save(); return "away"; }
            /* 0.1.9 (ARS-76-11 / ARS-77-02): only while Halloween runs */
            var hw = typeof G.halloween === "function" ? G.halloween() : undefined;
            if (hw === undefined) { say("waiting for the location manager's events picture"); if (dirty) save(); return "no events picture"; }
            if (hw && hw.unreadable) { say("could not read events" + (hw.why ? " (" + hw.why + ")" : "")); if (dirty) save(); return "could not read events"; }   // 0.1.10: not "not running"
            if (!hw) {
                Object.keys(state.cases).forEach(function (k) {
                    var cs = state.cases[k]; if (cs.state !== "requested") return;
                    c("decline", cs, { actor: "crypt clearer", reason: "Halloween is not running" }); delete state.cases[k]; dirty = true;
                });
                say("Halloween is not running"); if (dirty) save(); return "no Halloween";
            }
            var crypts = G.crypts(), gens = G.generals(), byGrid = {}, i;
            crypts.forEach(function (x) { byGrid[x.grid] = x; if (state.lastCrypt !== x.grid) { state.lastCrypt = x.grid; dirty = true; } });
            var mine = hunt(gens, crypts), byKey = {};
            gens.forEach(function (g) { byKey[g.key] = g; });
            var cnt = count(), tgt = target();
            /* open cases first: did the crypt go, or did the attack end without it? */
            Object.keys(state.cases).forEach(function (k) {
                var cs = state.cases[k], cr = byGrid[cs.grid], gen = byKey[cs.general];
                if (cs.state === "promised") {
                    if (!cr || !(cr.zombies > 0)) {
                        c("declare", cs, { reason: "the crypt holds no zombies" }); c("accept", cs, {});
                        state.cleared += 1; delete state.cases[k]; dirty = true;
                        if (cs.before) learn(cs.before, G.triggers());
                        return;
                    }
                    if (!cs.executing && gen && !gen.idle) { cs.executing = true; c("execute", cs, { general: cs.gname }); dirty = true; return; }
                    if ((gen && gen.idle && now - cs.at > ATTACK_LOST_MS) || now - cs.at > ATTACK_MAX_MS) {
                        /* 0.1.2: an attack that never started (the general stayed idle) does not count as fought: that general
                           is not sent to this crypt again; the next one takes it */
                        var started = !!cs.executing;
                        c("revoke promise", cs, { reason: started ? "the attack ended and the crypt still holds " + cr.zombies + " zombies" : "the attack did not start (the general stayed idle)" }); c("allow", cs, { actor: "zombie hunt manager (tacit)" });
                        if (!started && cs.general) { cs.skip = cs.skip || {}; cs.skip[cs.general] = true; }
                        cs.state = "requested"; cs.general = null; cs.gname = null; cs.executing = false; dirty = true;
                    }
                } else if (cs.state === "requested" && (!cr || !(cr.zombies > 0))) {
                    c("revoke request", cs, { reason: "the crypt is gone" }); c("allow", cs, { actor: "general (tacit)" }); delete state.cases[k]; dirty = true;
                }
            });
            if (cnt.n >= tgt) {
                if (!state.done) { state.done = true; G.record("p", { tk: "TK76", fact: "zombie kill target reached", count: cnt.n, target: tgt, via: cnt.via }); dirty = true; }
                say("target reached: " + cnt.n + " of " + tgt + " (" + cnt.via + ")"); if (dirty) save(); return "done";
            }
            if (state.done) { state.done = false; dirty = true; }   // the target was raised
            /* the generals of the hunt: fill an idle one that is not full (once a minute at most per general) */
            var u = unit(), free = null;
            mine.forEach(function (g) {
                if (!g.idle || full(g) || now - (Number(state.loadAt[g.key]) || 0) < LOAD_GAP) return;
                if (free == null) free = G.free(u);
                var have = g.army[u] || 0, n = Math.min(g.cap, have + free);
                if (!(n > 0)) { say("no " + u + " left to load " + g.name); return; }
                var army = {}; army[u] = n;
                if (G.load(g.key, army)) { state.loadAt[g.key] = now; free -= Math.max(0, n - have); dirty = true; }
            });
            /* a crypt with zombies and no case: request; a requested case: the next idle full general promises and attacks */
            crypts.forEach(function (cr) {
                if (!(cr.zombies > 0)) return;
                var open = null; for (var k in state.cases) if (state.cases.hasOwnProperty(k) && state.cases[k].grid === cr.grid) open = state.cases[k];
                if (!open) {
                    state.n += 1; open = state.cases["crypt@" + cr.grid] = { id: "crypt@" + cr.grid + "#" + state.n, grid: cr.grid, state: "requested", at: now };
                    c("request", open, { zombies: cr.zombies, count: cnt.n, target: tgt }); dirty = true;
                }
                if (open.state !== "requested") return;
                var busy = {}; Object.keys(state.cases).forEach(function (k) { if (state.cases[k].general) busy[state.cases[k].general] = true; });
                var skip = open.skip || {};
                var ready = mine.filter(function (g) { return g.idle && full(g) && !busy[g.key] && !skip[g.key] && (!G.reach || G.reach(g.key, cr.grid)); })   // 0.1.2
                    .sort(function (a, b) { return dist(a.grid, cr.grid) - dist(b.grid, cr.grid); });
                if (!ready.length) { if (Object.keys(skip).length >= mine.length && mine.length) { open.skip = {}; dirty = true; } return; }   // 0.1.2: all tried: start over
                var gen = ready[0], before = G.triggers();
                if (!G.attack(gen.key, cr.grid)) {   // 0.1.11 (ADR 0073): the adapter refused
                    var rf = (G.refusal && G.refusal()) || null;
                    if (rf && !rf.retry) { c("decline", open, { reason: rf.reason }); delete state.cases["crypt@" + cr.grid]; dirty = true; }
                    else say("waits: " + ((rf && rf.reason) || "the attack was not sent"));
                    return;
                }
                open.state = "promised"; open.general = gen.key; open.gname = gen.name; open.at = now; open.before = before; open.executing = false;
                c("promise", open, { general: gen.name, army: gen.army });
                dirty = true;
            });
            var open2 = Object.keys(state.cases).length;
            say(crypts.length + " crypt(s), " + open2 + " open, " + cnt.n + " of " + tgt + " (" + cnt.via + "); hunt: " + mine.map(function (g) { return g.name + (g.idle ? (full(g) ? " full" : " loading") : " busy"); }).join(", "));
            if (dirty) save();
            return "ok";
        }
        return { tick: tick, state: function () { return JSON.parse(JSON.stringify(state)); } };
    }

    var mgr = null, timer = null;
    function start() {
        if (root.DMA_ZOMBIES_NO_TIMER) return;
        mgr = createManager();
        timer = setInterval(function () { try { mgr.tick(); } catch (e) { try { if (typeof root.debug === "function") root.debug("DMA Zombies tick: " + e); } catch (_) {} } }, TICK_MS);
    }
    root.DMA_Zombies = { version: VERSION, createManager: createManager, gameGateway: gameGateway, status: function () { return mgr ? mgr.state() : null; } };
    start();
})(typeof window !== "undefined" ? window : this);
