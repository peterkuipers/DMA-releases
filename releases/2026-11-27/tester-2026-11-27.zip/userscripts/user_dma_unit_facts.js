/*
 * user_dma_unit_facts.js — the game's combat facts for the battle simulator in the client (PBC adventure management, ADR 0094)
 * 0.1.0 (2026-11-22, ADR 0094 increment 2; ADR 0042: every fact has a source and a watcher): the reader of the temporary probe
 *   src/tools/user_dma_probe_units.js 0.1.2, promoted to the pack. Source: the client itself — every unit description
 *   (MilitarySystem::cMilitaryUnitBase.GetAllUnit), every specialist description (Specialists::cSpecialist, base capacity,
 *   time bonus, traits), every skill and skill tree with its modifiers per level (global.skills_vector / skillTrees_vector),
 *   every buff with combat modifiers (global.map_BuffName_BuffDefinition). Watcher: the client version (defines.VERSION_NR);
 *   the facts are read once per client version and kept in dma-unit-stats.json next to the client; at start and every 6 hours
 *   the version is compared and a new client is read again (read only: static getters and fields, never a setter).
 *   API: DMA_UnitFacts.stats() (the file's object), facts() (a DMA_BattleSim.Facts, built once), status(), refresh(why).
 *   Unit expectation:        tests/unit/dma-unit-facts.test.js — needsRefresh: no file, other client, older format -> read;
 *                            same client -> keep; facts() builds a Facts from the stats with DMA_BattleSim.
 *   Integration expectation: live — a minute after the client start dma-unit-stats.json holds > 300 units, > 50 specialists,
 *                            and DMA_UnitFacts.facts().capacity("GhostGeneral", {}) is 215.
 */
(function (root) {
    "use strict";
    if (root.DMA_UnitFacts) return;
    var VERSION = "0.1.0", FILE = "dma-unit-stats.json", FORMAT = "dma-unit-stats/1", CHECK_MS = 6 * 3600000;
    var stats = null, factsObj = null, last = { at: null, why: null, ok: null, client: null };
    function A() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
    function file(name) { var a = A(); return new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); }
    function readFile(name) { try { var a = A(), f = file(name); if (!f.exists) return null; var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; } }
    function writeFile(name, text) { try { var a = A(), st = new a.FileStream(); st.open(file(name), a.FileMode.WRITE); st.writeUTFBytes(text); st.close(); return true; } catch (_) { return false; } }
    function def(n) { try { return root.swmmo.getDefinitionByName(n); } catch (_) { return null; } }
    function call(o, fn) { try { if (o && typeof o[fn] === "function") return o[fn].apply(o, Array.prototype.slice.call(arguments, 2)); } catch (_) {} return undefined; }
    function arr(v) {
        var out = [], i, n; if (!v) return out;
        try { if (typeof v.forEach === "function") { v.forEach(function (x) { out.push(x); }); return out; } } catch (_) {}
        try { if (typeof v.toArray === "function") return arr(v.toArray()); } catch (_) {}
        n = Number(v.length) || 0; for (i = 0; i < n; i++) { try { out.push(v.getItemAt ? v.getItemAt(i) : v[i]); } catch (_) {} }
        return out;
    }
    function res(list) { return arr(list).map(function (r) { return [String(r.name_string), Number(r.amount)]; }); }
    function enumConsts(name) {
        var out = {}, d = def(name); if (!d) return out;
        try { var x = String(root.runtime.flash.utils.describeType(d)), re = /<constant name="([^"]+)" type="int"/g, m;
              while ((m = re.exec(x)) !== null) { try { out[m[1]] = d[m[1]]; } catch (_) {} } } catch (_) {}
        return out;
    }
    function modifier(m) {
        if (!m) return null;
        var o = {};
        ["modifier_string", "id_string", "rules_string", "property_string", "channel", "chance", "type_string", "item_string",
         "name_string", "replace_string", "adder", "multiplier", "value"].forEach(function (k) { try { o[k.replace(/_string$/, "")] = m[k]; } catch (_) {} });
        try { var ef = arr(m.effects_vector); if (ef.length) o.effects = ef.map(function (e) { try { return String(e); } catch (_) { return null; } }); } catch (_) {}
        try { var ct = arr(m.concernedTasks_vector); if (ct.length) o.tasks = ct.map(Number); } catch (_) {}
        return o;
    }
    function unitBase(u) {
        var o = { type: call(u, "GetType"), id: call(u, "GetId"), cls: null, hp: call(u, "GetHitPoints"), combatPriority: call(u, "GetCombatPriority"),
                  sequencePrio: call(u, "GetSequencePrio"), uiPriority: call(u, "GetUIPriority"), defensePriority: call(u, "GetDefensePriority"),
                  category: call(u, "GetUnitCategory"), baseType: call(u, "GetBaseType"), elite: call(u, "GetIsElite"), boss: call(u, "IsBoss"),
                  npc: call(u, "IsNPC"), specialist: call(u, "IsSpecialist"), attackable: call(u, "IsAttackable"), canAttack: call(u, "CanAttack"),
                  producible: call(u, "IsProducible"), combat3: call(u, "IsCombatThree"), xp: call(u, "GetXP"), pvpXp: call(u, "GetPvPXP"),
                  productionTime: call(u, "GetProductionTime"), costs: res(call(u, "GetCosts_vector")) };
        try { o.cls = String(root.runtime.flash.utils.getQualifiedClassName(u)); } catch (_) {}
        if (typeof u.GetHitPercentage === "function") {                                       // classic description
            o.accuracy = call(u, "GetHitPercentage"); o.maxDamage = call(u, "GetHitDamage"); o.minDamage = call(u, "GetMissDamage");
            o.combatantType = call(u, "GetCombatantType");
            o.skills = arr(call(u, "GetSkills")).map(function (s) { return [call(s, "GetType"), call(s, "GetData")]; });
        }
        if (typeof u.GetBaseDamage === "function") {                                          // combat 3
            o.baseDamage = call(u, "GetBaseDamage"); o.armorType = call(u, "GetArmorType"); o.tier = call(u, "GetTier");
            o.group = call(u, "GetGroup"); o.batchSize = call(u, "GetCombatBatchSize");
            o.abilities = arr(call(u, "GetAbilities")).map(function (b) { try { return String(b); } catch (_) { return null; } });
        }
        return o;
    }
    function specialists() {
        var out = [], C = def("Specialists::cSpecialist"), t, d;
        if (!C) return out;
        for (t = 0; t <= 600; t++) {
            d = call(C, "GetSpecialistDescriptionForType", t); if (!d) continue;
            var o = { type: call(d, "GetType"), baseType: call(d, "getBaseType"), name: call(d, "getName_string"), maxUnits: call(d, "GetMaxUnits"),
                      militaryUnitType: call(d, "GetMilitaryUnitType_string"), skillType: call(d, "GetSkillType_string"), general: call(d, "isGeneral"),
                      transport: call(d, "isTransportGeneral"), canAttack: call(d, "isCanAttack"), speed: call(d, "getSpeed"), timeBonus: call(d, "GetTimeBonus"),
                      diceBonus: call(d, "GetDiceBonus"), recruitable: call(d, "IsRecruitable"), adventureMapLimit: call(d, "GetAdventureMapLimitCount"),
                      travelTo: call(d, "GetTimeOverwriteTravelToZone"), travelFrom: call(d, "GetTimeOverwriteTravelFromZone"), recover: call(d, "GetTimeOverwriteRecover") };
            try { o.traits = arr(call(d, "getTraits")).map(function (s) { return [s.id, s.level]; }); } catch (_) {}
            out.push(o);
        }
        return out;
    }
    function skillTrees() {
        var g = def("global"), out = [];
        arr(g && g.skillTrees_vector).forEach(function (tr) {
            var t = { id: tr.id, name: String(tr.name_string), maxPoints: tr.maxPoints, items: [] };
            arr(tr.items_vector).forEach(function (s) {
                var it = { id: s.id, name: String(s.name_string), pointType: String(s.skillPointType_string || ""), minimumLevel: s.minimumLevel,
                           pointsAccumulated: s.numPointsAccumulated, unlocks: arr(s.unlockedTreeItemIds).map(Number),
                           accumulatedFrom: arr(s.pointsAccumulatedReferenceIds).map(Number), levels: [] };
                try { it.position = s.position ? [s.position.x, s.position.y] : null; } catch (_) {}
                arr(s.level_vector).forEach(function (lv) { it.levels.push(arr(lv).map(modifier)); });
                t.items.push(it);
            });
            out.push(t);
        });
        return out;
    }
    function skillDef(s) {
        var it = { id: s.id, name: String(s.name_string), pointType: String(s.skillPointType_string || ""), levels: [] };
        arr(s.level_vector).forEach(function (lv) { it.levels.push(arr(lv).map(modifier)); });
        return it;
    }
    function allSkills() { var g = def("global"), out = []; arr(g && g.skills_vector).forEach(function (s) { if (s) { try { out.push(skillDef(s)); } catch (_) {} } }); return out; }
    function combatBuffs() {
        var g = def("global"), map = g && g.map_BuffName_BuffDefinition, out = [], k;
        if (!map) return out;
        for (k in map) {
            try { var d = map[k], cm = d && d.GetCombatModifiers ? d.GetCombatModifiers() : null; if (!cm) continue;
                  var list = arr(cm.asVector ? cm.asVector() : cm.list); if (!list.length) continue;
                  out.push({ name: String(k), id: call(d, "GetId"), target: call(d, "GetTargetDescription_string"), type: call(d, "GetType"), group: call(d, "GetGroup_string"),
                             modifiers: list.map(modifier) }); } catch (_) {}
        }
        return out;
    }
    function clientVersion() { try { var d = def("defines"); return d ? String(d.VERSION_NR) : null; } catch (_) { return null; } }
    function readGame(why) {
        var B = def("MilitarySystem::cMilitaryUnitBase"), D = def("MilitarySystem::cMilitaryUnitData");
        var o = { format: FORMAT, version: "unit-facts " + VERSION, at: new Date().toISOString(), why: why, client: clientVersion(), units: [], unitData: [], specialists: [], skillTrees: [], enums: {} };
        try { o.units = arr(call(B, "GetAllUnit", false)).map(unitBase); } catch (e) { o.unitsError = String(e).slice(0, 200); }
        try { o.specialists = specialists(); } catch (e) { o.specialistsError = String(e).slice(0, 200); }
        try { o.skills = allSkills(); } catch (e) { o.skillsError = String(e).slice(0, 200); }
        try { o.combatBuffs = combatBuffs(); } catch (e) { o.combatBuffsError = String(e).slice(0, 200); }
        try { o.skillTrees = skillTrees(); } catch (e) { o.skillTreesError = String(e).slice(0, 200); }
        return o;
    }
    /* pure: must the facts be read from the game again? */
    function needsRefresh(stored, client) {
        if (!stored || stored.format !== FORMAT || !stored.units || stored.units.length < 50) return "no facts kept yet";
        if (client && stored.client && String(stored.client) !== String(client)) return "the client changed (" + stored.client + " -> " + client + ")";
        if (!stored.skills || !stored.combatBuffs) return "facts of an older reader";
        return "";
    }
    function log(s) { try { if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log("unit facts: " + s); } catch (_) {} }
    function refresh(why, force) {
        var kept = stats || readFile(FILE), cv = clientVersion(), need = force ? "asked" : needsRefresh(kept, cv);
        last = { at: new Date().toISOString(), why: why, ok: true, client: cv };
        if (!need) { if (stats !== kept) { stats = kept; factsObj = null; } return { read: false, client: cv }; }
        if (!def("MilitarySystem::cMilitaryUnitBase")) { last.ok = false; stats = kept; return { read: false, error: "the game is not loaded" }; }
        var o = readGame(why + ": " + need);
        if (o.units.length < 50 || o.specialists.length < 20) { last.ok = false; log("read failed (" + o.units.length + " units)"); stats = kept; return { read: false, error: "too few units read" }; }
        stats = o; factsObj = null; writeFile(FILE, JSON.stringify(o));
        log("read " + o.units.length + " units, " + o.specialists.length + " specialists, " + (o.skills || []).length + " skills, " + (o.combatBuffs || []).length + " combat buffs (" + need + ")");
        return { read: true, client: cv, reason: need };
    }
    function facts() {
        if (factsObj) return factsObj;
        var S = root.DMA_BattleSim, st = stats || readFile(FILE); if (!S || !st) return null;
        stats = st; factsObj = new S.Facts(st); return factsObj;
    }
    var api = { version: VERSION, stats: function () { return stats || (stats = readFile(FILE)); }, facts: facts, refresh: refresh, needsRefresh: needsRefresh,
                status: function () { var s = stats; return { last: last, units: s ? s.units.length : 0, specialists: s ? s.specialists.length : 0, client: s ? s.client : null, at: s ? s.at : null }; },
                _setStats: function (s) { stats = s; factsObj = null; } };
    root.DMA_UnitFacts = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    try { if (A() && typeof setTimeout !== "undefined") {
        setTimeout(function () { try { refresh("start"); } catch (e) { log("start " + String(e).slice(0, 160)); } }, 45000);
        setInterval(function () { try { refresh("watch"); } catch (_) {} }, CHECK_MS);
    } } catch (_) {}
})(typeof window !== "undefined" ? window : this);
