/*
 * Stable client filename: user_dma_unit_inputs.js
 * DMA Unit inputs 0.1.0 — what one unit of a unit kind takes to train (settlers and weapons), read from the client, with
 * the registered copy and its watcher (backbone v3.17, ADR 0072 T-3; UNIT INPUT: AT80 unit kind, AT81 resource, AT82
 * amount per unit — "given externally"; ADR 0042 "every fact has a source and a watcher").
 *
 * 0.1.1 (2026-11-16, author-requested TROOPS page groups; coordinator): the UNIT GROUP of a unit kind — normal, elite or expedition — read from the game, not typed
 *   (ADR 0042). SOURCE: the same unit lists the units probe reads: MilitarySystem::cMilitaryUnitBase.GetAllUnit(false) for the classic barracks units (a producible
 *   player unit with GetIsElite() true is "elite", else "normal": the Barracks trains the normal ones, the Elite Barracks the elite ones) and
 *   MilitarySystem::cMilitaryUnitData.GetAllUnitData(false, false) for the expedition units (a producible, non-NPC combat-3 unit). REGISTERED COPY:
 *   REGISTERED_GROUPS = docs/05-ontology/dma/facts/unit-groups.yaml (read from docs/06-adventures/tactical/data/unit-stats.json, probe 0.1.2, 2026-11-04);
 *   tests/unit/unit-groups-registered.test.js keeps the two equal. WATCHER: watch() also reads the groups; a kind whose game group differs from the copy, or a kind the
 *   copy does not know, is one P-fact "reference fact differs" {what: "unit group"} (once per difference) and the game's group is used. Unreadable game -> the copy.
 *   unit.<Kind>.targetStrength still accepts only the kinds inputs() knows (the 16 barracks units): the expedition units are NOT in the inputs, so the policy refuses a target for them.
 *   API: groups() -> { Kind: "normal" | "elite" | "expedition" }; group(unit); the status file names the groups' source. Unit: tests/unit/unit-groups-registered.test.js
 *   (the table equals the yaml) and tests/unit/dma-unit-groups.test.js (game read: elite flag, expedition from the combat-3 list, NPC left out; a difference -> one fact;
 *   unreadable -> the copy). Integration: tests/integration/unit-groups-with-policy.test.js (real policy: a target is accepted for a barracks unit, refused for an expedition
 *   unit, and the groups are the same set the page filters).
 * 0.1.0 (2026-11-16, ADR 0072, model PR #388, reconciliation R-21: "a unit-recipe source: read the unit costs from the
 *   client … and register a copy with a watcher (ADR 0042)"): the first version.
 *   SOURCE: the game — MilitarySystem::cMilitaryUnitBase.GetAllUnit(false); per unit GetType() and GetCosts_vector()
 *   ([{name_string, amount}]; settlers are "Population"). Read 30 s after load and then once an hour (no game event
 *   exists for it; the recipes change only with a client update). Only the unit kinds of the registered copy and every
 *   other classic unit the game marks producible (IsProducible, not IsNPC) with Population in its costs are kept.
 *   REGISTERED COPY: REGISTERED below = docs/05-ontology/dma/facts/unit-inputs.yaml (read by the units probe 0.1.2,
 *   2026-11-04); tests/unit/unit-inputs-registered.test.js keeps the two equal.
 *   WATCHER: when the game's inputs of a unit kind differ from the registered copy (or the game has a kind the copy does
 *   not), one P-fact "reference fact differs" {what: "unit inputs", unit, game, registered} is recorded per kind and
 *   difference, and the game's value is used — the game decides; the copy is what the model was validated with.
 *   When the game cannot be read the registered copy is used (source "registered").
 *   API: inputs(unit) -> {resource: amount per unit} or null; all(); registered(); source(); watch(now) (the read, for
 *   the tests); status(). Status file dma-unit-inputs.json.
 *   Unit: tests/unit/unit-inputs-registered.test.js (REGISTERED equals the yaml) and tests/unit/dma-unit-inputs.test.js
 *   (game read; a difference -> one fact, the game's value used; unreadable game -> the registered copy; NPC and
 *   non-producible units left out). Integration: tests/integration/dma-unit-inputs-watch.test.js (with the C-fact
 *   memory / facts path DMA_Demo.record: a client whose Recruit costs changed gives one "reference fact differs" fact
 *   in the facts log, inputs("Recruit") follows the game, the status file names the source).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.1";
    if (root.DMA_UnitInputs && root.DMA_UnitInputs.version) return;
    var STATUS = "dma-unit-inputs.json", WATCH_MS = 3600000;
    /* the registered copy: docs/05-ontology/dma/facts/unit-inputs.yaml (ADR 0042) */
    var REGISTERED = {
        Recruit: { Population: 1, Beer: 5, BronzeSword: 10 },
        Bowman: { Population: 1, Beer: 10, Bow: 10 },
        Militia: { Population: 1, Beer: 10, IronSword: 10 },
        Cavalry: { Population: 1, Beer: 30, Horse: 40 },
        Longbowman: { Population: 1, Beer: 20, Longbow: 10 },
        Soldier: { Population: 1, Beer: 15, SteelSword: 10 },
        Crossbowman: { Population: 1, Beer: 50, Crossbow: 10 },
        EliteSoldier: { Population: 1, Beer: 50, TitaniumSword: 10 },
        Cannoneer: { Population: 1, Beer: 50, Cannon: 10 },
        Swordsman: { Population: 1, Beer: 50, PlatinumSword: 1 },
        MountedSwordsman: { Population: 1, Beer: 50, PlatinumSword: 2, BattleHorse: 2 },
        Knight: { Population: 1, Beer: 50, BattleHorse: 1 },
        Marksman: { Population: 1, Beer: 50, Archebuse: 1 },
        ArmoredMarksman: { Population: 1, Beer: 50, Archebuse: 1, PlatinumSword: 1 },
        MountedMarksman: { Population: 1, Beer: 50, Archebuse: 2, BattleHorse: 2 },
        Besieger: { Population: 1, Beer: 50, Mortar: 1 }
    };
    /* the registered copy of the unit groups: docs/05-ontology/dma/facts/unit-groups.yaml (ADR 0042) */
    var REGISTERED_GROUPS = {
        Recruit: "normal", Bowman: "normal", Militia: "normal", Cavalry: "normal", Longbowman: "normal", Soldier: "normal", Crossbowman: "normal", EliteSoldier: "normal", Cannoneer: "normal",
        Swordsman: "elite", MountedSwordsman: "elite", Knight: "elite", Marksman: "elite", ArmoredMarksman: "elite", MountedMarksman: "elite", Besieger: "elite",
        ExpeditionSwordsman: "expedition", ExpeditionCuirassier: "expedition", ExpeditionCrossbowman: "expedition", ExpeditionKnight: "expedition", ExpeditionTank: "expedition",
        ExpeditionPikeman: "expedition", ExpeditionArcher: "expedition"
    };
    var game_ = null, gameGroups_ = null, readAt = 0, readErr = "", told = {};
    function clone(o) { return o == null ? o : JSON.parse(JSON.stringify(o)); }
    function arr(v) {
        var out = [], i, n; if (!v) return out;
        try { if (typeof v.forEach === "function") { v.forEach(function (x) { out.push(x); }); return out; } } catch (_) {}
        n = Number(v.length) || 0; for (i = 0; i < n; i++) { try { out.push(v[i]); } catch (_) {} }
        return out;
    }
    function call(o, fn) { try { if (o && typeof o[fn] === "function") return o[fn].apply(o, Array.prototype.slice.call(arguments, 2)); } catch (_) {} return undefined; }
    function def(n) { try { var sw = (typeof swmmo !== "undefined") ? swmmo : root.swmmo; return sw && sw.getDefinitionByName ? sw.getDefinitionByName(n) : null; } catch (_) { return null; } }
    function record(kind, d) { try { if (root.DMA_Demo && typeof root.DMA_Demo.record === "function") root.DMA_Demo.record(kind, d); } catch (_) {} }
    function fileWrite(name, obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath), st = new a.FileStream();
              st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (_) {}
    }
    function same(a, b) {
        var k; a = a || {}; b = b || {};
        for (k in a) if (a.hasOwnProperty(k) && Number(a[k]) !== Number(b[k])) return false;
        for (k in b) if (b.hasOwnProperty(k) && Number(a[k]) !== Number(b[k])) return false;
        return true;
    }
    /* the source: the game's unit list */
    function readGame() {
        var B = def("MilitarySystem::cMilitaryUnitBase"), list, out = {}, n = 0;
        if (!B || typeof B.GetAllUnit !== "function") { readErr = "MilitarySystem::cMilitaryUnitBase not readable"; return null; }
        try { list = arr(B.GetAllUnit(false)); } catch (e) { readErr = "GetAllUnit: " + String(e).slice(0, 80); return null; }
        list.forEach(function (u) {
            var t = call(u, "GetType"); if (t == null) return; t = String(t);
            if (call(u, "IsNPC") === true) return;
            if (!REGISTERED[t] && call(u, "IsProducible") !== true) return;
            var c = {}, pop = false;
            arr(call(u, "GetCosts_vector")).forEach(function (r) { try { var nm = String(r.name_string), am = Number(r.amount); if (nm && am > 0) { c[nm] = (c[nm] || 0) + am; if (nm === "Population") pop = true; } } catch (_) {} });
            if (!pop && !REGISTERED[t]) return;
            out[t] = c; n += 1;
        });
        if (!n) { readErr = "no producible unit read"; return null; }
        readErr = ""; return out;
    }
    /* 0.1.1: the unit groups from the game's two unit lists */
    function readGroups() {
        var B = def("MilitarySystem::cMilitaryUnitBase"), D = def("MilitarySystem::cMilitaryUnitData"), out = {}, n = 0;
        if (!B || typeof B.GetAllUnit !== "function") return null;
        try { arr(B.GetAllUnit(false)).forEach(function (u) { var t = call(u, "GetType"); if (t == null || call(u, "IsNPC") === true || call(u, "IsProducible") !== true) return;
            out[String(t)] = call(u, "GetIsElite") === true ? "elite" : "normal"; n += 1; }); } catch (_) { return null; }
        try { if (D && typeof D.GetAllUnitData === "function") arr(D.GetAllUnitData(false, false)).forEach(function (u) { var t = call(u, "GetType"); if (t == null || call(u, "IsNPC") === true || call(u, "IsProducible") !== true) return;
            out[String(t)] = "expedition"; n += 1; }); } catch (_) {}
        return n ? out : null;
    }
    /* the watcher (ADR 0042) */
    function watch(now) {
        now = now || Date.now();
        var g = readGame(), k, diffs = 0;
        if (g) {
            game_ = g; readAt = now;
            for (k in g) {
                if (!g.hasOwnProperty(k) || same(g[k], REGISTERED[k])) continue;
                var sig = k + "=" + JSON.stringify(g[k]);
                diffs += 1;
                if (told[sig]) continue;
                told[sig] = true;
                record("p", { fact: "reference fact differs", what: "unit inputs", unit: k, game: clone(g[k]), registered: clone(REGISTERED[k] || null), source: "game", file: "docs/05-ontology/dma/facts/unit-inputs.yaml", by: "unit inputs watcher" });
            }
        }
        var gg = readGroups();   // 0.1.1
        if (gg) {
            gameGroups_ = gg;
            for (k in gg) {
                if (!gg.hasOwnProperty(k) || REGISTERED_GROUPS[k] === gg[k]) continue;
                var sg = "group:" + k + "=" + gg[k]; diffs += 1;
                if (told[sg]) continue;
                told[sg] = true;
                record("p", { fact: "reference fact differs", what: "unit group", unit: k, game: gg[k], registered: REGISTERED_GROUPS[k] || null, source: "game", file: "docs/05-ontology/dma/facts/unit-groups.yaml" });
            }
        }
        fileWrite(STATUS, status(diffs));
        return { read: !!g, differs: diffs, error: readErr };
    }
    function source() { return game_ ? "game" : "registered"; }
    function inputs(unit) {
        var u = String(unit || "");
        if (game_ && game_[u]) return clone(game_[u]);
        return REGISTERED[u] ? clone(REGISTERED[u]) : null;
    }
    function groups() { var out = clone(REGISTERED_GROUPS), k; if (gameGroups_) for (k in gameGroups_) if (gameGroups_.hasOwnProperty(k)) out[k] = gameGroups_[k]; return out; }   // 0.1.1
    function group(unit) { var g = groups()[String(unit || "")]; return g || null; }
    function all() { var out = clone(REGISTERED), k; if (game_) for (k in game_) if (game_.hasOwnProperty(k)) out[k] = clone(game_[k]); return out; }
    function status(diffs) {
        return { format: "dma-unit-inputs/1", version: VERSION, at: new Date().toISOString(), source: source(), readAt: readAt ? new Date(readAt).toISOString() : null,
                 error: readErr || null, differs: diffs || 0, groupSource: gameGroups_ ? "game" : "registered", groups: groups(), units: all() };
    }
    root.DMA_UnitInputs = { version: VERSION, inputs: inputs, all: all, groups: groups, group: group, registeredGroups: function () { return clone(REGISTERED_GROUPS); }, registered: function () { return clone(REGISTERED); }, source: source, watch: watch,
                            status: function () { return status(); } };
    try {
        if (!root.DMA_UNIT_INPUTS_NO_TIMER && typeof root.setTimeout === "function") {
            root.setTimeout(function () { try { watch(); } catch (_) {} }, 30000);
            if (typeof root.setInterval === "function") root.setInterval(function () { try { watch(); } catch (_) {} }, WATCH_MS);
        }
    } catch (_) {}
})(typeof window !== "undefined" ? window : this);
