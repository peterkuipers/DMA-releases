/*
 * user_dma_report.js — the feedback report (tester pack, author 2026-11-18: "Nee de knop is het belangrijkste, maak dat
 *   nu eerst"; asked: "een feedbackknop ... die alle belangrijke informatie verzameld zodat de speler dat in discord kan
 *   plakken").
 * 0.1.0 (2026-11-18): one press of FEEDBACK on the console makes two things from what DMA already knows:
 *   1. a SHORT text for the clipboard, at most MAX_SUMMARY characters (a Discord message holds 2000): time, module
 *      versions, the switches that are on, every self-starter's state and reason, the last errors of the console log, the
 *      adventure's state, and the player's own words (what were you doing, what did you expect, what happened);
 *   2. a FULL report file next to the client, dma-report-<UTC time>.txt, to drag into the same Discord message: the same
 *      plus every setting that differs from its default, the last 300 console lines, the open and the last 40 closed
 *      transactions with their steps, the status files of the parts and the last 20 restarts.
 *   Privacy: no chat text of other players is read; the chat reply word is masked; a transaction's key and the names in
 *   its data are replaced when the data names another player (fields player / sender / from / to / who / name of a trade
 *   or help kind). Nothing is sent anywhere: the player copies and posts it himself.
 *   Reads only (no game call, no server send): the globals' .version, GCAF_PlayerPolicy(.RULES/Instance), DMA_Demo.actors,
 *   DMA_ConsoleUI.logLines, DMA_Tx.list, and files next to the client.
 *   Unit: tests/unit/dma-report.test.js (summary under the limit with long notes and many actors; the sections of the file;
 *   only non-default settings; the chat word masked; trade names replaced; errors picked from the log).
 *   Integration: tests/integration/dma-report-real-modules.test.js (the real policy, transactions and console: a report
 *   with the real version line, a non-default setting, an open transaction, and the file written next to the client).
 * GLOBAL: DMA_Report = { version, collect, summary, full, make, MAX_SUMMARY }.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.0", MAX_SUMMARY = 1900, LOG_LINES = 300, CLOSED_TX = 40;
    var STATUS_FILES = ["dma-adv-status.json", "dma-restart-status.json", "dma-troops-status.json", "dma-supply-status.json", "dma-mail-status.json", "dma-quest-watch.json", "dma-zombie-status.json", "dma-premium.json"];
    var PEOPLE_FIELDS = { player: 1, sender: 1, from: 1, to: 1, who: 1, name: 1, partner: 1, requester: 1, member: 1 };
    var PEOPLE_KINDS = /^(TK19|TK2[3-9]|TK3[0-3]|TK6[7-9])$/;   // loot spots, trades (TK23-25), help, star and guild-purchase kinds: their keys and data name players

    function air_() { return (typeof air !== "undefined") ? air : root.air; }
    function file(name) { var A = air_(); return new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); }
    function readText(name) {
        try { var A = air_(), f = file(name); if (!f.exists) return null; var st = new A.FileStream(); st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return t; } catch (_) { return null; }
    }
    function writeText(name, text) {
        try { var A = air_(), f = file(name), st = new A.FileStream(); st.open(f, A.FileMode.WRITE); st.writeUTFBytes(text); st.close(); return f.nativePath || name; } catch (e) { return null; }
    }
    function iso(t) { try { return new Date(t).toISOString().replace(/\.\d+Z$/, "Z"); } catch (_) { return String(t); } }
    function ago(t, now) { var m = Math.round((now - t) / 60000); return m < 60 ? m + " min" : m < 2880 ? Math.round(m / 60) + " h" : Math.round(m / 1440) + " d"; }
    function trim(s, n) { s = String(s == null ? "" : s).replace(/\s+/g, " ").trim(); return s.length > n ? s.slice(0, n - 1) + "…" : s; }

    /* every DMA_ / GCAF_ global with a version */
    function versions() {
        var out = [], seen = {};
        try { Object.keys(root).forEach(function (k) {
            if (!/^(DMA_|GCAF_)/.test(k)) return; var v = null; try { v = root[k] && root[k].version; } catch (_) {}
            if (typeof v === "string" && !seen[k]) { seen[k] = 1; out.push(k.replace(/^(DMA_|GCAF_)/, "") + " " + v); }
        }); } catch (_) {}
        return out.sort();
    }
    function policy() { try { return root.GCAF_PlayerPolicyInstance || null; } catch (_) { return null; } }
    function switchesOn() {
        var P = root.GCAF_PlayerPolicy, p = policy(), out = [];
        try { (P.SWITCHES || []).forEach(function (s) { if (p.get(s.key) === true) out.push(s.short || s.key.replace(/\.auto$/, "")); }); } catch (_) {}
        try { if (p.get("zombie.auto") === true) out.push("zombie"); var pr = p.get("premium.setting"); if (pr && pr !== "off") out.push("premium:" + pr);
              ["ae", "ywc", "vlt", "ft", "own", "gp"].forEach(function (a) { if (p.get("adv." + a + ".on") === true) out.push("adv." + a); }); } catch (_) {}
        return out;
    }
    function same(a, b) { try { return JSON.stringify(a) === JSON.stringify(b); } catch (_) { return a === b; } }
    /* every setting that differs from its registered default, and every pattern setting (no default registered) */
    function changedSettings() {
        var P = root.GCAF_PlayerPolicy, p = policy(), out = {}, dflt = {};
        try { (P.RULES || []).forEach(function (r) { dflt[r.ruleId] = r.value; }); } catch (_) {}
        var all = {}; try { all = (p && p.getPolicy && p.getPolicy()) || {}; } catch (_) {}
        Object.keys(all).sort().forEach(function (k) {
            var v = all[k]; if (v === null || v === undefined || v === "") return;
            if (dflt.hasOwnProperty(k) && same(v, dflt[k])) return;
            out[k] = k === "chat.words" ? "(set, " + String(v).split(",").length + " word(s))" : v;
        });
        return out;
    }
    function actors() {
        var list = []; try { list = (root.DMA_Demo && root.DMA_Demo.actors && root.DMA_Demo.actors()) || []; } catch (_) {}
        return list.map(function (a) { return { label: a.label || a.actor, state: a.state, reason: a.reason || "" }; });
    }
    function logLines() { try { return (root.DMA_ConsoleUI && root.DMA_ConsoleUI.logLines && root.DMA_ConsoleUI.logLines()) || []; } catch (_) { return []; } }
    function errorLines(lines) { return lines.filter(function (l) { return /error|fail|refus|declin|exception|not respond|stuck|short|cannot|could not/i.test(String(l)); }); }
    function txOut(t, now) {
        var people = PEOPLE_KINDS.test(String(t.tk)), d = t.data || {}, data = {};
        Object.keys(d).forEach(function (k) { var v = d[k]; if (typeof v === "object") return; data[k] = people && PEOPLE_FIELDS[k] ? "(player)" : v; });
        var h = (t.history || []).slice(-6).map(function (x) { return (x.act || "?") + (x.actor ? " by " + x.actor : "") + (x.reason ? " (" + trim(x.reason, 100) + ")" : "") + " " + iso(x.at); });
        return { tk: t.tk, key: people ? "(player)" : String(t.key), state: t.state, since: t.since ? ago(t.since, now) : "", data: data, steps: h };
    }
    function transactions(now) {
        var T = root.DMA_Tx, open = [], closed = [];
        try { open = T.list({ open: true }).map(function (t) { return txOut(t, now); }); } catch (_) {}
        try { closed = T.list({ open: false }).slice(0, CLOSED_TX).map(function (t) { return txOut(t, now); }); } catch (_) {}
        return { open: open, closed: closed };
    }
    function json(name) { var t = readText(name); if (t == null) return null; try { return JSON.parse(t); } catch (_) { return trim(t, 400); } }
    function restarts() { var t = readText("dma-restart-log.jsonl"); return t ? t.trim().split("\n").slice(-20) : []; }

    function collect(now) {
        now = now || Date.now();
        var lines = logLines(), adv = json("dma-adv-status.json");
        return { at: now, versions: versions(), switches: switchesOn(), actors: actors(), errors: errorLines(lines).slice(-8), log: lines.slice(-LOG_LINES),
                 adventure: adv && typeof adv === "object" ? { name: adv.adventure, state: adv.state, phase: adv.phase, round: adv.round, of: adv.of, reason: adv.reason, since: adv.since, last: (adv.log || []).slice(-3) } : null,
                 settings: changedSettings(), tx: transactions(now), status: STATUS_FILES.map(function (n) { return { file: n, value: json(n) }; }).filter(function (s) { return s.value != null; }),
                 restarts: restarts() };
    }
    function notesText(n) {
        n = n || {}; var out = [];
        if (n.doing) out.push("Doing: " + trim(n.doing, 400)); if (n.expected) out.push("Expected: " + trim(n.expected, 400)); if (n.happened) out.push("Happened: " + trim(n.happened, 400));
        return out;
    }
    /* the clipboard text: the most useful first; shortened from the bottom until it fits */
    function summary(c, notes, fileName) {
        var head = ["**DMA feedback** " + iso(c.at) + (notes && notes.title ? " — " + trim(notes.title, 80) : "")].concat(notesText(notes));
        var parts = [
            "Switches on: " + (c.switches.length ? c.switches.join(", ") : "none"),
            c.adventure ? "Adventure: " + [c.adventure.name, c.adventure.state, c.adventure.phase ? "phase " + c.adventure.phase : "", c.adventure.round != null ? "round " + c.adventure.round + "/" + c.adventure.of : "", c.adventure.reason].filter(Boolean).join(" · ") : "",
            "Parts: " + c.actors.filter(function (a) { return a.state !== "off"; }).map(function (a) { return a.label + " " + a.state + (a.reason ? " (" + trim(a.reason, 60) + ")" : ""); }).join("; "),
            c.errors.length ? "Last problems:\n" + c.errors.slice(-5).map(function (l) { return "- " + trim(l, 140); }).join("\n") : "",
            "Open transactions: " + c.tx.open.length,
            "Versions: " + c.versions.join(", "),
            fileName ? "Full report: " + fileName + " (attached)" : ""
        ].filter(Boolean);
        var text = head.concat(parts).join("\n");
        while (text.length > MAX_SUMMARY && parts.length > 1) { parts.splice(parts.length - (fileName ? 2 : 1), 1); text = head.concat(parts).join("\n"); }
        return text.length > MAX_SUMMARY ? text.slice(0, MAX_SUMMARY - 1) + "…" : text;
    }
    function full(c, notes) {
        var L = [], j = function (o) { try { return JSON.stringify(o); } catch (_) { return String(o); } };
        L.push("DMA feedback report " + iso(c.at), "format: dma-report/1", "");
        L.push("== The player's words"); L = L.concat(notesText(notes).length ? notesText(notes) : ["(none)"]); if (notes && notes.title) L.push("Title: " + notes.title); L.push("");
        L.push("== Versions"); L = L.concat(c.versions); L.push("");
        L.push("== Switches on"); L.push(c.switches.join(", ") || "none"); L.push("");
        L.push("== Parts (self-starters)"); c.actors.forEach(function (a) { L.push(a.label + ": " + a.state + (a.reason ? " - " + a.reason : "")); }); L.push("");
        L.push("== Adventure"); L.push(c.adventure ? j(c.adventure) : "none"); L.push("");
        L.push("== Settings that differ from the default"); Object.keys(c.settings).forEach(function (k) { L.push(k + " = " + j(c.settings[k])); }); if (!Object.keys(c.settings).length) L.push("(none)"); L.push("");
        L.push("== Open transactions (" + c.tx.open.length + ")"); c.tx.open.forEach(function (t) { L.push(j(t)); }); L.push("");
        L.push("== Last closed transactions (" + c.tx.closed.length + ")"); c.tx.closed.forEach(function (t) { L.push(j(t)); }); L.push("");
        L.push("== Status files"); c.status.forEach(function (s) { L.push(s.file + ": " + j(s.value)); }); L.push("");
        L.push("== Last restarts"); L = L.concat(c.restarts.length ? c.restarts : ["(none)"]); L.push("");
        L.push("== Console log (last " + c.log.length + " lines)"); L = L.concat(c.log); L.push("");
        return L.join("\n");
    }
    function copy(text) {
        try { var A = air_(), cb = A.Clipboard.generalClipboard; cb.clear(); cb.setData(A.ClipboardFormats.TEXT_FORMAT, text); return true; } catch (_) { return false; }
    }
    /* the button: collect, write the file, put the summary on the clipboard */
    function make(notes, now) {
        var c = collect(now), name = "dma-report-" + iso(c.at).replace(/[:]/g, "").replace(/-/g, "") + ".txt";
        var path = writeText(name, full(c, notes)), s = summary(c, notes, path ? name : null);
        return { summary: s, file: path ? name : null, path: path, copied: copy(s), length: s.length };
    }
    var api = { version: VERSION, MAX_SUMMARY: MAX_SUMMARY, collect: collect, summary: summary, full: full, make: make, copy: copy };
    root.DMA_Report = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : this);
