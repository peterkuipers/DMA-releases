/*
 * DMA Deposit search manager 0.1.0 — actor role AR10 "deposit search manager" (case kind DEPOSIT, TK10; it requests TK11), ADR 0074 step 4.
 *
 * 0.1.2 (2026-11-19, ADR 0084, live): leaving the workflow's spots out of the facts was not enough — the proven capacity still counted
 *   them, so R-GAP saw "occupied 3, empty 3" and sent three ordinary copper searches the moment the workflow cleared its spots, filling
 *   them before the workflow's own geologists could search. The capacity and the empty count now leave out the spots a workflow holds,
 *   and the workflow's own searches out are not counted as this manager's. Unit: tests/unit/dma-workflows-deposit-cycling.test.js.
 *   Integration: tests/integration/dma-workflows-dsm-capacity.test.js.
 * 0.1.1 (2026-11-18, ADR 0084 Workflows / Deposit Cycling, point 7): the spots of a workflow that is on are no production spots: facts() leaves them out, so
 *   R-GAP / R-DUE / R-LF and the capacity picture do not count them and send no search for them (the workflow searches with its own allocated geologists;
 *   control's isReserved keeps those out of the idle count). Without user_dma_workflows.js nothing changes.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.1.0 (2026-11-16, ADR 0074 step 4): the AR10 decisions that lived in green 0.8.29 / 0.9.x, moved VERBATIM: the request rules R-GAP (the searches a resource needs: empty spots + mines that run out within the
 *   lead time - searches under way), R-DUE (a replacement for a mine that runs out; "every spot occupied" waits for a demolition) and R-LF (one Lucky Find geologist for the extra deposit), the review tk11Review
 *   (a search that is over: declare + accept; an unanswered one: promise or revoke) and the hand-off of the orders to control (sendSearch). The observed declare of the executor (AR11, control) — verifySearch,
 *   30 s after a send the geologist must have a task — is control's now (0.2.107); the hold after a refused search is read from control (searchHeld). R-CAP stays green: it is computing (capacity of a
 *   resource), green still emits its "capacity 0" row. The manager reads green only through its interface (DMA_Green.facts / live / pictureOf / param), the demolitions of this cycle from the construction
 *   manager (demolished()), does not scan (ADR 0040), sends through control (ADR 0073) and is ticked by the agents' cycle after the construction manager, under the same "game not responding" pause.
 *   Presence and readiness (ADR 0074 section 3): check() is true when green's interface and control's sendSearch / verifySearch / searchHeld are there; green 0.9.3 then emits no search row and runs no
 *   tk11Review; without this file, or while check() is false, green decides as before (rollback = remove the file).
 *   GLOBAL: DMA_DepositSearchManager = { version, owner "deposit search manager", actor, ready, check, tick, assess, last, sendingMs }.
 *   Unit: tests/unit/dma-deposit-search-manager.test.js (R-GAP / R-DUE / R-LF rows through the real policy, the hold, not ready without control's verifySearch). Integration:
 *   tests/integration/dma-deposit-search-handover.test.js (real transactions, agents, green, construction manager, search manager and control: one search for an empty spot, request -> promise by the observed declare,
 *   green emits no search row; rollback without the manager).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.2";
    var last = [], seqAt = 0, seqMs = 0, ready = false;
    function G() { return root.DMA_Green || null; }
    function note(s) {
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
            if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200);
            root.__DMA_CYCLE_AT = Date.now();
        } catch (_) {}
    }
    function pol(k, d) {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; }
        } catch (_) {}
        return d;
    }
    function param(id, name) { var g = G(); return g && typeof g.param === "function" ? g.param(id, name) : undefined; }
    function ctrl() { return root.DMA_Control || null; }
    function cmem() { return root.DMA_Tx || null; }
    function wfOwns(grid) { try { var W = root.DMA_Workflows; return !!(W && typeof W.ownsGrid === "function" && W.ownsGrid(grid)); } catch (_) { return false; } }   // ADR 0084
    function facts() { var g = G(), s = g && typeof g.facts === "function" ? g.facts() : []; return (s || []).filter(function (x) { return !(x && wfOwns(x.grid)); }); }   // 0.1.1 (ADR 0084)
    function live(grid) { var g = G(); return g && typeof g.live === "function" ? g.live(grid) : null; }
    function picture(slots) {   // 0.1.2 (ADR 0084, live 2026-11-19): the spots a workflow holds are not this manager's to fill
        var g = G(), pic = g && typeof g.pictureOf === "function" ? g.pictureOf(slots) : {};
        try {
            var W = root.DMA_Workflows; if (!W || typeof W.config !== "function" || !W.resources) return pic;
            W.resources.forEach(function (r) {
                var q = pic[r]; if (!q) return;
                var held = (W.config(r).grids || []).filter(function (gr) { return wfOwns(gr); }).length; if (!held) return;
                var out = 0; try { out = W.stats ? Number(W.stats("deposit-cycling", r).out) || 0 : 0; } catch (_) {}
                q.capacity = Math.max(0, Number(q.capacity) - held); q.empty = Math.max(0, Number(q.empty) - held); q.open = Math.max(0, Number(q.open) - out);
                q.workflowSpots = held;
            });
        } catch (_) {}
        return pic;
    }
    function isMineSlot(s) { return !!(s && (s.mine || /mine|mason|quarry/i.test(String(s.name || ""))) && !s.depleted); }
    function geologists() { try { return (ctrl() && ctrl().geologists && ctrl().geologists()) || []; } catch (_) { return []; } }
    function island() {
        try { if (root.DMA_Demo && root.DMA_Demo.island) return root.DMA_Demo.island(); } catch (_) {}
        return { lfWanted: function () { return false; } };
    }
    function busy(grid) {   // the order's owner knows: the construction manager, else green
        try { var CM = root.DMA_ConstructionManager; if (CM && CM.ready && typeof CM.busy === "function") return CM.busy(grid) || ""; } catch (_) {}
        try { var Gr = root.DMA_Green; if (Gr && typeof Gr.busy === "function") return Gr.busy(grid) || ""; } catch (_) {}
        return "";
    }
    function record(kind, data) {
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {}
    }
    var ARS_TK = { search: "TK11" };
    var declineSeen = {}, DECLINE_REPEAT_MS = 3600000;   // decline recorded on change, else hourly

    function row(rule, ars, fact, s, r, reason, extra) {
        var o = { rule: rule, ars: ars, fact: fact, grid: s ? s.grid : "", resource: r, reason: reason, slot: s || null };
        if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        return o;
    }

    /* ---------- TK11 — one transaction per search ---------- */
    var searchSeq = 0;
    function tk11Act(act, search, extra) {
        var o = { tk: "TK11", act: act, search: search }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    function tk11Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now(), geos = geologists(), byId = {};
        geos.forEach(function (g) { if (g && g.id != null) byId[String(g.id)] = g; });
        M.list({ tk: "TK11", open: true }).forEach(function (t) {
            if (!M.inProgress("TK11", t.key) || t.revoking) return;
            var d = t.data || {}, g = d.geo != null ? byId[String(d.geo)] : null;
            var out = !!(g && !g.idle && (!g.taskResource || g.taskResource === d.resource));
            if (t.state === "promised" && !out) {
                tk11Act("declare", t.key, { actor: "game (observed)", resource: d.resource, geo: d.geo, reason: g ? "the geologist is back" : "the geologist is no longer listed" });
                tk11Act("accept", t.key, { actor: "specialist manager (geo)", resource: d.resource });
                return;
            }
            if (t.state === "requested" && now - t.since >= 10 * 60000) {
                if (out) tk11Act("promise", t.key, { actor: "game (observed)", resource: d.resource, geo: d.geo });
                else { tk11Act("revoke request", t.key, { actor: "specialist manager (geo)", resource: d.resource, reason: "no answer within 10 min" }); tk11Act("allow", t.key, { actor: "game (tacit)" }); }
            }
        });
    }


    /* ---------- self-correcting pace ---------- */
    var pace = { ms: null, clean: 0, errors: 0 };
    function paceMs() {
        if (pace.ms == null) pace.ms = Number(pol("control.sendIntervalMs", 1500)) || 1500;
        return pace.ms;
    }
    function paceResult(ok, what) {
        var floor = Number(pol("control.sendIntervalMinMs", 700)) || 700;
        if (ok) {
            pace.clean += 1;
            if (pace.clean >= 20 && pace.ms > floor) { pace.ms = Math.max(floor, Math.round(pace.ms * 0.9)); pace.clean = 0; note("pace faster: " + pace.ms + " ms"); record("pace", { ms: pace.ms, why: "20 clean actions" }); }
        } else {
            pace.errors += 1;
            pace.clean = 0;
            pace.ms = Math.min(6000, paceMs() * 2);
            note("pace slower: " + pace.ms + " ms after " + what);
            record("pace", { ms: pace.ms, why: what });
        }
    }
    function trouble(out) {
        var e = out && (out.error || out.reason);
        return e && /zone|ready|connect|server|timeout|socket|lost/i.test(String(e)) ? String(e) : "";
    }


    /* ---------- assess: the search rules (ARS-10-11) ---------- */
    function assess() {
        var slots = facts(), i, j, s, r, q, rows = [];
        var on = { geo: pol("geo.auto", false) === true };
        note("deposit search manager " + VERSION + " assess slots=" + slots.length + " geo=" + on.geo);
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!isMineSlot(s)) continue;
            var lv = live(s.grid);
            if (lv) { if (lv.level) s.level = lv.level; s.upgrading = lv.upgrading; s.buffed = lv.buffed; }
            s.busy = busy(s.grid);
        }
        var pic = picture(slots);
        tk11Review();
        var demolished = {};
        try { var CMd = root.DMA_ConstructionManager; if (CMd && CMd.ready && typeof CMd.demolished === "function") demolished = CMd.demolished() || {}; } catch (_) { demolished = {}; }
        if (on.geo) {
            var operational = null;
            try { if (root.DMA_Demo && root.DMA_Demo.operational) operational = root.DMA_Demo.operational(); } catch (_) {}
            var wants = [];
            for (r in pic) {
                if (!pic.hasOwnProperty(r)) continue;
                if (operational && pol("search.inPlayOnly", true) !== false && operational.indexOf(r) < 0) continue;
                q = pic[r];
                if (q.capacity <= 0) continue;   // R-CAP is green's computing (it emits the "capacity 0" row)
                var held = ctrl() && typeof ctrl().searchHeld === "function" ? ctrl().searchHeld(r) : null;                                                          // 0.6.7
                if (held) { rows.push(row("R-GAP", "search", "dc", null, r, "the game refused " + held.n + " search(es); retry after " + new Date(held.at + held.holdMs).toISOString().slice(11, 16) + " UTC")); continue; }
                var cleared = q.mines.filter(function (m) { return demolished[m.grid]; }).length;   // 0.7.3: demolished this cycle = free
                var dueUncovered = Math.max(0, q.due.filter(function (m) { return !demolished[m.grid]; }).length - q.free.length);
                if (q.empty + cleared <= 0 && dueUncovered > 0) {                                  // 0.7.0 / 0.7.2
                    rows.push(row("R-DUE", "search", "dc", null, r, "every spot occupied: the game refuses a search until a mine is demolished (at the threshold " + (Number(pol("demolish.threshold", 20)) || 20) + ")"));
                    dueUncovered = 0;
                }
                var need = q.empty + cleared + dueUncovered - q.open;
                var why = "capacity " + q.capacity + (q.proven ? " (proven)" : " (" + q.spots + " spots seen, seed " + q.seed + ")") +
                          ", occupied " + q.occupied + ", empty " + q.empty + ", due " + q.due.length + " (lead " + Math.round(q.lead / 60) + " min)" +
                          ", free " + q.free.length + ", open " + q.open + (cleared ? ", demolished now " + cleared : "");
                if (need <= 0) {
                    // 0.6.4: iron / marble at the proven limit — one Lucky Find geologist at a time for the extra deposit
                    var lfw = false; try { var islG = island(); lfw = !!(islG && islG.lfWanted && islG.lfWanted(r)); } catch (_) {}
                    if (lfw && q.open === 0) { wants.push({ r: r, need: 1, why: "limit " + q.capacity + " reached; Lucky Find geologist for the one extra deposit", replacement: false, lf: true }); continue; }
                    rows.push(row("R-GAP", "search", "dc", null, r, "covered: " + why + (lfw ? "; Lucky Find search open" : ""))); continue;
                }
                wants.push({ r: r, need: need, why: why, replacement: dueUncovered > 0 });
            }
            wants.sort(function (a, b) { return b.need - a.need; });
            var c = ctrl();
            var idle = geologists().filter(function (g) { return g && g.idle && !(c && c.isReserved && c.isReserved(g.id)); }).length;
            var seq = 1;
            for (i = 0; i < wants.length; i++) {
                if (idle <= 0) { rows.push(row("R-GAP", "search", "dc", null, wants[i].r, "no idle geologist; need " + wants[i].need + ": " + wants[i].why)); continue; }
                var n = Math.min(wants[i].need, idle);
                for (j = 0; j < n; j++) {
                    rows.push(row(wants[i].lf ? "R-LF" : wants[i].replacement ? "R-DUE" : "R-GAP", "search", "pm", null, wants[i].r, "send " + (j + 1) + "/" + n + ": " + wants[i].why, { grid: "s" + seq, replacement: true, lf: !!wants[i].lf }));
                    seq += 1;
                }
                idle -= n;
            }
        }


        last = rows;
        rows.forEach(function (x) {
            var tk = ARS_TK[x.ars] || x.ars;
            if (x.fact === "pm") return;   // a search records its request with the send
            var key = tk + "|" + x.rule + "|" + x.resource + "|" + (x.grid == null ? "" : x.grid);
            var seen = declineSeen[key], now = Date.now();
            if (!seen || seen.reason !== x.reason || now - seen.at >= DECLINE_REPEAT_MS) {
                record("c", { tk: tk, act: "assess", outcome: "not now", rule: x.rule, resource: x.resource, grid: x.grid, reason: x.reason, repeats: seen ? seen.n : 0 });
                declineSeen[key] = { reason: x.reason, at: now, n: 0 };
            } else { seen.n += 1; }
        });
        rows.forEach(function (x) { note("deposit search manager [" + x.rule + "] " + x.ars + " " + x.resource + " " + x.fact + " " + x.reason); });
        return rows;
    }

    /* ---------- execute: one paced sequence of searches ---------- */
    function execute(rows) {
        var c = ctrl();
        rows = rows || last;
        if (!c) return;
        var actions = [];
        function pushA(kind, fn) { actions.push(fn); }
        var maxSearch = Number(pol("control.maxActionsPerCycle", 5)) || 5, nSearch = 0;
        rows.forEach(function (job) {
            if (job.fact !== "pm") return;
            if (job.ars === "search" && nSearch++ < maxSearch) pushA(job.ars, function () {
                var out = c.sendSearch(job.resource, true, { replacement: !!job.replacement, luckyFind: !!job.lf });   // 0.6.4
                note("search [" + job.rule + "] " + job.resource + " " + ((out && (out.error || out.reason || (out.ok ? "sent" : ""))) || ""));
                var sid = job.resource + "#" + Date.now() + "#" + (++searchSeq);   // 0.8.10: one transaction per search
                tk11Act("request", sid, { actor: "specialist manager (geo)", initiator: "specialist manager (geo)", rule: job.rule, resource: job.resource, reason: job.reason, geo: out && out.geo, geoName: out && out.geoName, lf: job.lf ? true : null });
                if (!(out && out.ok)) tk11Act("decline", sid, { actor: "game / blue", resource: job.resource, reason: String(out && (out.error || out.reason) || "refused") });
                if (out && out.ok && out.geo) c.verifySearch(job.resource, out.geo, out.geoName, sid);   // 0.6.7
                return out;
            });

        });
        if (!actions.length) return;
        var interval = paceMs();
        note("search send sequence " + actions.length + " actions, " + interval + " ms apart");
        var startAt = 0; try { var CMs = root.DMA_ConstructionManager; if (CMs && CMs.ready && typeof CMs.sendingMs === "function") startAt = Number(CMs.sendingMs()) || 0; } catch (_) {}   // after the construction manager's sequence (and its 5 s after a demolition)
        seqAt = Date.now(); seqMs = startAt + actions.length * interval;
        actions.forEach(function (fn, k) {
            setTimeout(function () {
                try {
                    if (c && typeof c.atHome === "function" && !c.atHome()) { note("away from home: action skipped"); return; }
                    var out = fn();
                    var t = trouble(out);
                    paceResult(!t, t);
                } catch (e) { note("send err " + e); paceResult(false, "exception " + e); record("i", { what: "send error", reason: String(e) }); }
            }, startAt + k * interval);
        });
    }

    function tick() {
        try {
            var rows = assess();
            execute(rows);
            return rows;
        } catch (e) {
            note("deposit search manager tick err " + (e && e.message ? e.message : e));
            return [];
        }
    }
    /* readiness (ADR 0074 section 3): green's interface and control's search functions */
    function check() {
        var g = G(), c = ctrl(), ok = false;
        try { ok = !!(g && typeof g.pictureOf === "function" && typeof g.param === "function" && typeof g.facts === "function" &&
                      c && typeof c.sendSearch === "function" && typeof c.verifySearch === "function" && typeof c.searchHeld === "function"); } catch (_) { ok = false; }
        ready = ok; if (api) api.ready = ok;
        return ok;
    }
    var api = {
        version: VERSION, owner: "deposit search manager", actor: "deposit search manager", ready: false, check: check, tick: tick, assess: assess,
        last: function () { return last.slice(); },
        sendingMs: function () { return Math.max(0, seqAt + seqMs - Date.now()); }
    };
    root.DMA_DepositSearchManager = api;
    check();
    note("deposit search manager " + VERSION + " loaded, ready=" + api.ready);
})(typeof window !== "undefined" ? window : this);
