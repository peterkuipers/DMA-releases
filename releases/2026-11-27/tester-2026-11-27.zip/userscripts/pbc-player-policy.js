/*
 * 0.2.92 (2026-11-27, construction review F1; C-2026-11-27-A): troops.queueMax withdrawn (the game gives no barracks queue maximum).
 *   The B15 rules are the backbone's attributes: troops.queueRows = AT131 open troop order limit, troops.priority = AT132 troop
 *   priority, troops.balanced = AT133 balanced switch (ARS-62-11 R-TROOP-OPEN-LIMIT, R-TROOP-PRIORITY, R-TROOP-BALANCED).
 * 0.2.91 (2026-11-27; author 12:09): troops.queueMax (off) - fill every barracks up to its maximum (withdrawn in 0.2.92).
 * 0.2.90 (2026-11-27, change-set B15, tester SirBirk; author 11:46): the troop manager's barracks queue as rules - troops.queueRows (1),
 *   troops.rowSize (25), troops.priority (empty) and troops.balanced (on), owner troop-manager, shown on the TROOPS page.
 *   Unit: tests/unit/dma-troops-queue-depth.test.js. Integration: tests/integration/dma-troops-queue-depth.test.js.
 * 0.2.89 (2026-11-26, change-set B13, backbone v3.39; author: "If the setting doesnt change anything, it should be removed"):
 *   the rules adv.asIs, adv.ywc.asIs and adv.campByCamp are removed — every plan is played as written (R-PLAN-AS-WRITTEN,
 *   adventure 0.2.169); camp by camp stays a version kind the player chooses. Unit: tests/unit/adventure-per-adv-rules.test.js.
 * 0.2.88 (2026-11-22, adventure 0.2.120): the close-at-once labels say what it does — no wait, but loose troops still go into the
 *   free generals. Labels only. Unit: tests/unit/adventure-ahead-home.test.js (rules present).
 * 0.2.87 (2026-11-21, ADR 0091): run rules adv.aheadHome and adv.closeAtOnce (ALL, off) with YWC's own adv.ywc.aheadHome and
 *   adv.ywc.closeAtOnce (on, the author's play). Unit: tests/unit/adventure-ahead-home.test.js.
 * 0.2.86 (2026-11-21, ADR 0092, author: "8 landingsplekken ... die zijn spelfeiten ... niet een instelling die de speler
 *   bepaalt"): the rule adv.mundane.landingSpots is removed — the landing fields of each adventure are read from the game.
 *   Unit: tests/integration/dma-mundane-advisor.test.js (the rule is gone).
 * 0.2.85 (2026-11-20, tester feedback ZG-01): the demo.auto switch is labelled "Demolish" (was "Demo", read as demonstration); key unchanged.
 * 0.2.84 (2026-11-20, author: "ik weet niet of de sluit uit functie al werkt"): adv.travel.exclusive — the families of speed-ups that exclude
 *   each other, as the game gives them no exclusivity group (default: one horseshoe, one star chart).
 * 0.2.83 (2026-11-20, author: "Settings als keep it running is typisch iets dat je boven alle settings wil, want je gaat het toch maar
 *   voor 1 moment instellen"): one Run setting for any adventure — adv.keep.res, adv.keep.version, adv.keep.runs — replaces adv.ft.keep and
 *   adv.ywc.keep (retired).
 * 0.2.82 (2026-11-20, author: "Ook het retract all generals when intercepted is een keuze voor de speler"): adv.retreat.on (on), the general
 *   choice the adventure completer already read (0.2.59) but the player could not set; adv.ywc.retreat stays YWC's own override.
 * 0.2.81 (2026-11-20, author: "het is geen keuze per avontuur, het is een algemene instelling bij enkele avonturen en bij runs en zelfs bij
 *   chains"): one setting adv.travel for every adventure DMA starts (single, kept runs, series); adv.ywc.travel and adv.ft.travel (0.2.80,
 *   never live) are gone.
 * 0.2.80 (2026-11-20, author: "dat moet de speler aan kunnen zetten" — "selecties die elkaar uitsluiten kun je niet combineren"): adv.ywc.travel,
 *   adv.ft.travel (sets of star buffs, pick "travelBuffs"; a choice with two buffs of one exclusivity group is declined, reason "exclusive",
 *   asked of DMA_Adventure.exclusive) and adv.travel.match.
 * 0.2.79 (2026-11-20, author: "we gaan over op ywc"; "de mijne sloten precies op elkaar aan"): adv.ywc.asIs (on) and adv.ywc.retreat (off) —
 *   per-adventure overrides of the ALL rules, read by the adventure completer 0.2.96.
 * 0.2.78 (2026-11-20, author on FT: "je kunt de generaal van de tweede aanval al uit de star halen en plaatsen"): adv.prestage (on) — the
 *   adventure completer (0.2.95) makes the next round ready while the current one fights, for every adventure.
 * 0.2.77 (2026-11-20, ADR 0088 S-3/S-4): the supply manager's forecast rules supply.forecast.on (off), supply.forecast.horizonHours (48),
 *   supply.forecast.windowHours (6), and supply.adventure.on (on).
 * 0.2.76 (2026-11-20, ADR 0088 S-5): the Adventure switch (adv.auto, the adventure manager AR17, default off) and its rules adv.ft.keep,
 *   adv.ywc.keep (default off), adv.keep.retryMin (30), adv.keep.planRuns (3).
 * 0.2.75 (2026-11-18, ADR 0084 addendum): workflow.dc.<R>.start, a choice "empty" (default: wait until the player's mine on a
 *   picked spot runs out) or "now" (demolish it at once). Unit: tests/unit/dma-workflows-deposit-cycling.test.js.
 * 0.2.74 (2026-11-18, ADR 0084 Workflows / Deposit Cycling): per mine resource (BronzeOre, IronOre, GoldOre, Coal, TitaniumOre,
 *   Salpeter) the rules workflow.dc.<R>.on (default OFF), .grids (set of spots), .geoTypes (set of geologist type numbers),
 *   .geoCount (0 = all), .keepFree (1), .reserve.on (on) and .reserve (1000). Shown on the WORKFLOWS page and the RULES page.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js
 *   and tests/integration/pack-fresh-policy-nothing-acts.test.js (off for a new player).
 * 0.2.73 (2026-11-18, ADR 0083 addendum, author: "Alles wat je hier instelt, moet flexibel zijn voor de speler"):
 *   every condition of the trade-office rule is a business rule the player switches on or off and sets:
 *   supply.office.afterMin(.on) (30 min), supply.guild.afterMin(.on) (120 min), supply.office.minMarketRatio.on,
 *   supply.office.neverPay.on; supply.office.neverPay is a set (a checklist of resources) instead of text. A "set"
 *   value is stored as a list of distinct names (a comma-separated text is accepted).
 *   Unit: tests/unit/player-policy-supply-rules.test.js. Integration: tests/integration/dma-supply-rules-flow.test.js.
 * 0.2.72 (2026-11-18, ADR 0083 point 3): rules control.selfRestart.on (bool, default OFF) and control.staleRestartMin
 *   (5 - 240, default 10) registered, so a player sees and sets them. Unit: tests/unit/player-policy-self-restart.test.js.
 *   Integration: tests/integration/dma-self-restart-off.test.js (fresh policy: neither the stale watch nor a "game not
 *   responding" suspicion restarts the client).
 * PBC Player Policy 0.2.70
 *
 * 0.2.70 (2026-11-17, UAT 2026-11-17 finding F2; the manual says "Without a target nothing is upgraded"): the default of building.upgradeLevel.<Resource> (shown as upg.<Resource>, the "UPG" column of the console)
 *   was 2, so a FRESH install showed a target of 2 for every resource and the first switch of Upgrade upgraded 48 level-1 mines. The default is 0 now: no target (the console shows "—"), and nothing is upgraded for a
 *   resource without one (green 0.9.4, control 0.2.112, demo agents 0.4.39, construction manager 0.1.3 read 0 as no target). A policy that stores a value keeps it - an explicit 2 stays 2; the range 0 - 8 is unchanged.
 *   Unit: tests/unit/player-policy-upgrade-default.test.js (a fresh policy: upg.<R> and building.upgradeLevel.<R> are 0 for every resource; a stored 3 is kept; a value the player sets is kept; 0 clears a target).
 *   Integration: tests/integration/green-no-target-nothing-upgraded.test.js (real policy, fresh: green's target is 0, an explicit target works) and tests/integration/pack-fresh-policy-nothing-acts.test.js (the whole pack: no upgrade target).
 * 0.2.69 (2026-11-17, tester release, author: nothing may fit only his island): the default of expo.template was "Event" - the author's instruction of 2026-10-26 for the event then running (0.2.21), i.e. every
 *   explorer on a SHORT search. A new player's default is the first built-in template, "Daily" (the specialist manager's own DEFAULT_TEMPLATE). A policy that stores a value keeps it. Nothing else changes.
 *   Unit: tests/unit/player-policy-expo-default.test.js (a fresh policy reads Daily; a stored Event is kept). Integration: tests/integration/pack-fresh-policy-nothing-acts.test.js (the whole pack: the default is Daily).
 * 0.2.67 (2026-11-16, ADR 0075 / backbone v3.19, author "ok voor alles"; reconciliation: policy switches and limits of the ADR 0075 follow-up): the switches and limits of obtaining a short resource.
 *   Switch supply.auto = the self-starting actor role "resource supply manager" (AR66, TK66 resource supply managing), short "supply", default OFF, needs nothing. Rules, in the author's order of
 *   means: supply.make.on (make it, TK64; default on), supply.produce.on (raise production, read by the construction manager; default on), supply.office.on (buy at the trade office when favourable
 *   in value; default OFF) with supply.office.maxPricePct (pay at most this share of the value list, 50 - 200, default 100) and supply.office.maxPerDay (0 - 50, default 3), supply.guild.on (ask a guild
 *   member to sell, the LAST resort; default OFF) with supply.guild.maxPerDay (0 - 20, default 2) and supply.guild.everyMin (at most one ask per N minutes, 15 - 1440, default 120). trade.rt.ask.on
 *   (ask the guild for a round trade ourselves, TK25 asked round trade; default OFF) with trade.rt.ask.everyMin (15 - 1440, default 120) and trade.rt.ask.maxPerDay (0 - 20, default 2). Nothing is on for a new player.
 *   Unit: tests/unit/player-policy-supply-switch.test.js (the Supply switch, off; the rules' defaults and ranges; out-of-range declined). Integration: tests/integration/dma-policy-supply-keys.test.js (saved through the real
 *   policy into dma-policy.json, a restarted policy reads them back).
 * 0.2.66 (2026-11-16, author: "where is the troops auto switch?"): troops.auto was a registered rule but not an actor switch, so the console's switch bar (built from switches()) had no
 *   Troops switch. It is now the switch of the self-starting actor role "troop manager" (AR62): key troops.auto, short "troops", label "Troops", initiates "troop training", default OFF,
 *   needs nothing. The same key is no longer listed twice (the RULES line of 0.2.58 is replaced by the switch's own rule). The console renders every switch the policy lists, so the bar gets it
 *   without a console change. Unit: tests/unit/player-policy-troops-switch.test.js (switches() lists troops.auto, off by default, a change is saved and read back, the rule appears once).
 *   Integration: tests/integration/console-troops-switch-bar.test.js (the real policy and the console: the switch bar has a Troops switch, off, and a click-equivalent change turns the troop manager on).
 * 0.2.65 (2026-11-16, console 0.1.92; author: the TROOPS group toggles did not hold): a CONSOLE VIEW preference is stored in the policy store — dma-policy.json survives a restart; the client's
 *   localStorage does not (the 0.1.9 note of the console). New rules console.troops.<normal|elite|expedition>.show (bool; absent = shown): which unit groups the TROOPS page shows. They are
 *   view settings of the console, not business rules: no actor reads them (ownerPbc "console"). Unit: tests/unit/player-policy-console-view.test.js (the three keys are accepted as bool, any
 *   other group or a non-bool is declined, absent = no value). Integration: tests/integration/console-troops-groups-policy.test.js (saved through the real policy, written to dma-policy.json and read back by a new policy instance, i.e. after a restart).
 * 0.2.64 (2026-11-16, architect on PR #396, low): a misspelled unit kind is no longer accepted silently. A change to
 *   unit.<UnitKind>.targetStrength is checked against the unit kinds the unit inputs source knows (DMA_UnitInputs.all(),
 *   user_dma_unit_inputs.js 0.1.0: the game's producible units, else the registered copy): an unknown kind is declined
 *   "unknown-unit-kind" with the known kinds listed. When that module is not loaded the change is accepted as before and
 *   the answer says unitKindChecked: false. Setting a target to 0 (removing it) is never refused.
 *   Unit: tests/unit/player-policy-unit-target.test.js (with the unit inputs loaded: "Recriut" declined, "Recruit"
 *   accepted; without them: accepted, unchecked). Integration: tests/integration/dma-policy-unit-target.test.js (a
 *   DMA_UnitInputs stand-in shaped as user_dma_unit_inputs.js 0.1.0 (#397) beside the policy: a misspelled kind is
 *   declined and not written to dma-policy.json; the module is not on this branch).
 * 0.2.63 (2026-11-16, backbone v3.17 — ADR 0072 T-1, model PR #388, reconciliation R-21): the UNIT POLICY. Per unit kind
 *   the player sets a TARGET STRENGTH: rule unit.<UnitKind>.targetStrength (AT79; the unit kind AT78 is the key part),
 *   number 0 … 1,000,000, owner troop-manager, slot ASSESS. Nothing is registered by default: a unit kind without a
 *   target has none (default empty = nothing to do). unitPolicies() returns { <UnitKind>: <target strength> } of every
 *   unit kind with a target above 0, for the troop manager (DFS-49 the troop shortfall of [unit policy]).
 *   Unit: tests/unit/player-policy-unit-target.test.js (no targets by default; a target accepted, out of range declined,
 *   0 means no target; unitPolicies()). Integration: tests/integration/dma-policy-unit-target.test.js (set on the TROOPS
 *   page: written to dma-policy.json, a restarted client reads the same unitPolicies()).
 * 0.2.62 (2026-11-16, architect verdict on PR #385 — adventure 0.2.81/0.2.82 reads adv.stowLoose through its gateway's
 *   rule(), default on, but the policy did not know the rule, so the player could not switch it off: requestChange said
 *   "unknown-rule"): adv.stowLoose is registered with the general adventure rules ("ALL: before closing, load the loose
 *   troops into the generals still on the map"), bool, default ON (an assess rule inside a run the player started, like
 *   collect / claim — not a self-starter switch, so "everything off for a new player" does not apply), owner
 *   adventure-manager, slot ASSESS. Nothing else changes.
 *   Unit: tests/unit/player-policy-stow-loose.test.js (known, default true, bool only, switched off and back).
 *   Integration: tests/integration/dma-policy-stow-loose.test.js (switched off on the ADVS page it is written to
 *   dma-policy.json, a restarted client reads it back false, and the adventure gateway's reading (v == null ? d : v)
 *   gives false; listed among the adventure manager's ALL rules).
 * 0.2.61 (2026-11-16, the author rejected CL-51a (D-6; model PR #383, reconciliation R-18): the corrupt-mine repair is
 *   retired in control 0.2.96): the rule control.repairCorrupt (registered in 0.2.59, default off) is RETIRED. It is no
 *   longer a rule: requestChange declines it "retired-rule"; a stored value is dropped at load; get() answers false, so a
 *   control that still reads it (0.2.93…0.2.95) never repairs — safe in either merge order. No other change.
 *   Unit: tests/unit/player-policy-auto-defaults.test.js (repairCorrupt retired: declined, false, dropped from the
 *   store). Integration: tests/integration/dma-fresh-policy-repair.test.js (with control: nothing demolished, also when a
 *   stored policy still says true).
 *
 * 0.2.60 (2026-11-16, backbone v3.16, ADR 0071 — the author's decisions D-2, D-4, D-5 of 2026-11-16; reconciliation
 *   R-05, R-12, R-13 in docs/05-ontology/dma/model-code-reconciliation.md): the policy's keys follow the fact model.
 *   (1) premium.setting (AT72 "the premium setting of [policy]", value type VT23 PREMIUM SETTING): "off" (default) |
 *   "always" | "event" (during an event) — replaces the boolean premium.autoExtend. A stored premium.autoExtend true
 *   becomes "always", false "off", once at load. premium.autoExtend stays readable for the modules that still ask it
 *   (premium 0.1.x): it reads true only for "always"; writing it sets "always" / "off".
 *   (2) The construction type policy (ET28, D-4): ctype.<ConstructionType>.targetLevel (AT70, number 0..20) and
 *   ctype.<ConstructionType>.buffKind (AT71, the buff's game name). A stored building.upgradeLevel.<Name> for a name
 *   that is not a resource (the per-building target level green's R-BUFF-PROD reads today) is copied to
 *   ctype.<Name>.targetLevel once at load; the old key stays until green reads the new one.
 *   (3) The event keys name their fact types: event.<type>.buff.on = AT73 event buff switch, event.<type>.fill.on =
 *   AT74 fill switch (it was registered as a "counter on" by mistake), event.<type>.fill.rateX = AT75 fill rate (it was
 *   not registered at all: requestChange declined it "unknown-rule").
 *   Every rule carries factType where the model has one; entries() returns it, for the console's page per transaction kind.
 *   A "choice" rule (premium.setting) declines a value outside its list ("value-not-allowed").
 *   Unit: tests/unit/player-policy-v316-keys.test.js. Integration: tests/integration/dma-policy-v316-modules.test.js
 *   (policy + premium + event: premium follows the setting through the legacy key; the event manager stops filling when
 *   the fill switch is off and reads the fill rate the player set).
 *
 * 0.2.59 (2026-11-16, tester report 2026-11-16 (PR #373) on proposal #358: FAIL, items D10 and A2 / §5.2):
 *   (1) control.repairCorrupt (control's corrupt-mine repair R-REPAIR-CORRUPT, a DEMOLITION, control 0.2.71) is
 *   registered, bool, default FALSE — unregistered, control's fallback true decided, so a fresh policy still demolished.
 *   (2) A bool rule no longer acknowledges a value it does not store: true / "true" / "on" / "yes" / 1 / "1" are true,
 *   false / "false" / "off" / "no" / 0 / "0" are false, anything else is declined "value-not-bool" (0.2.58 answered "ac"
 *   to "on" and stored false). A stored string of a registered bool rule ("on", "off", "true", "false") is read as the
 *   bool at load, so earlier files mean what they said. Not changed: control.allowExecute stays always true (it is a
 *   gate behind the switches, not an actor; the architect's item A2).
 *   Unit: tests/unit/player-policy-auto-defaults.test.js (repairCorrupt off; "on" -> true, "off" -> false, "maybe" ->
 *   dc; a stored "on" is read as true). Integration: tests/integration/dma-fresh-policy-repair.test.js (the tester's
 *   known-failing case: a fresh policy with control loaded demolishes nothing; switched on, the corrupt mine goes).
 *
 * 0.2.58 (2026-11-16, architecture review 2026-11-16 finding #12 and §5.2, packaging blocker: "every automation switch
 *   defaults off for a new player, as the pack README promises"): the policy owns the default of every automatic switch.
 *   (1) Rules troops.auto (troop manager, TK62/TK63), zombie.auto (zombie-hunt manager), premium.autoExtend (premium
 *   extension), control.watchdog and control.keepAwake (the opt-in tool user_dma_watchdog.js) are registered, bool,
 *   default FALSE — until now they were not registered, so the modules' own fallback (true / "on") decided, and the
 *   player could not set them through requestChange. (2) The 0.2.48 migration that wrote event.auto = true into every
 *   policy that lacked it is removed: a new player's Event switch is off like every other switch. A policy that
 *   already stores a value keeps it (the author's island keeps event.auto as stored).
 *   Unit: tests/unit/player-policy-auto-defaults.test.js (fresh policy: every *.auto / *.autoExtend / *.autoEnabled
 *   key and every switch reads false; the new rules accept a change). Integration:
 *   tests/integration/dma-auto-defaults.test.js (fresh policy + troops, zombies, premium, event, buff manager loaded:
 *   none of them acts).
 *
 * 0.2.57 (2026-11-15, ADR 0069): rule adv.campByCamp (bool, default off) — the adventure executor (0.2.79) plays any
 *   template, the player's own Mundane included, one camp at a time: the next attacker on a camp leaves only when the one
 *   before fights there, the next camp only when this one fell.
 * 0.2.56 (2026-11-14, author: "Voor mundane wil ik voorlopig werken met hun eigen mundanes"): rule adv.asIs (bool, default
 *   off) — the adventure executor (0.2.71) plays the player's own Mundane template as it is, with its guards.
 * 0.2.55 (2026-11-13, ADR 0066): rule adv.blocks.on (bool, default off) — the player's permission for templates with blocks;
 *   the adventure executor (0.2.51) stops before sending when a template uses blocks and this is off.
 * 0.2.54 (2026-11-10, ADR 0058 addendum): spec.<expo|geo|gen>.renameScope ("new" | "unnamed" | "all") and
 *   spec.<type>.renameAllConfirmedAt (the player's confirmation of "all", an ISO time).
 * 0.2.53 (2026-11-10, ADR 0058, agents 0.4.21): rules spec.use (object: per specialist id "first" = skill before use;
 *   absent = use until the books are there), spec.<expo|geo|gen>.skill / name ("manual" | "auto"), .prefix / .suffix
 *   (the player's text), .skillStandard (bool). Unit: player-policy-entries.test.js; integration: the Specialists screen.
 * 0.2.52 (2026-11-10, console 0.1.81 — the player's settings next to the rules of a transaction kind): entries(patterns)
 *   — every registered rule and every stored dynamic value (event.<type>.*, building.upgradeLevel.<Building>) whose id
 *   matches one of the regular expressions, with label, ARS slot and current value. Read-only.
 * 0.2.51 (2026-11-09, The Dark Gate needs YGG2, one of the four zombie-hunt generals): rule zombie.generals (text,
 *   default empty = the zombie manager keeps the four it chose) — the hunt's generals by name or id, comma separated;
 *   read by the zombie manager since 0.1.0 but never registered, so it could not be set.
 * 0.2.50 (2026-11-09, console 0.1.78 — the quest manager's screen selects every part): rules quest.pay.on (pay a guild
 *   quest from storage, default on) and quest.pickup.on (pick up finished productions, default on), read by the quest
 *   manager since 0.1.17 / 0.1.13 but never registered, so the screen could not change them.
 * 0.2.49 (2026-11-09, quest manager 0.1.21): rule quest.do.building (default on) — the building-bonus loops (BuiBonus_*)
 *   are their own category of the quest book.
 * 0.2.48 (2026-11-09, author: "adjust the console so event and quest book kan be selected, inclusding all
 *   subselections"): switch Event (event.auto, event manager), on after a restore that never had it (the event manager
 *   ran without a switch until now).
 * 0.2.47 (2026-11-09, ADR 0053, author: "Within the quest book the player can choose what to do and what not to do"):
 *   rules quest.do.guild / daily / weekly / ghostship / starfall / event / main / side (default on), read by the quest
 *   manager 0.1.18.
 * 0.2.46 (2026-11-05, ADR 0048, author: "maak er maar een business rule van"): rules adv.loot.* for R-ADV-LOOT (the
 *   adventure manager advises an adventure when a stock runs out): on (default on), horizonHours (48), windowHours (6),
 *   from (star | star or book | any; default star). Owner adventure-manager; shown on the ADVS page.
 *   Unit expectation:        the four rules exist with these defaults; adv.loot.horizonHours 0 is refused.
 *   Integration expectation: the ADVS page lists them under "Short stock -> adventure" and saves a change.
 * 0.2.27 (2026-10-29): event counter rules event.<type>.<counter>.on (bool) / .when / .give (text), e.g.
 *   event.halloween.trick.* — answer a trick with a Treat.
 * 0.2.26 (2026-10-29, live): rule event.<type>.gameNames (text) — which of the game's event names count for the type.
 * 0.2.25 (2026-10-29, ADR 0029): event rules event.<type>.buff.on (the event manager orders the buffer to buff the
 *   type's buildings; default off) and event.<type>.buff.exclude (buffs green may not choose for them). They belong to the
 *   event, not to the buff manager; buff.event.on / buff.event.exclude (0.2.23) are no longer read.
 * 0.2.24 (2026-10-29, ADR 0028): rules event.<type>.buffable — the player's seconds per unit for the buildings an event
 *   type brings (object { buildingName: seconds }), owner event-manager, set on the EVENT page.
 * 0.2.23 (2026-10-29, decision 0026, author: "settings in het betreffende scherm behorende bij de juiste knop van de
 *   gelieerde actor roles"): buff manager rules buff.event.on (buff the buildings the running event declares
 *   buffable, default off) and buff.event.exclude (buffs green may not choose for them, a list; default empty).
 * 0.2.22 (2026-10-27, decision 0022, author: "business rules every player decides for himself; keep the DEMO pattern as
 *   the basis"): the adventure rules adv.<id>.* for Arctic Explosion (ae) and Gunpowder (gp), owner adventure-manager.
 *   Defaults are the procedures in docs/06-adventures; loot spots 1 by default, GP 2. All off until the player switches.
 * 0.2.21 (2026-10-26, author: "today a new event starts, set the explorer template to event"): rule expo.template
 *   (Daily | Event | Adventure), set to Event; switch back with the template selector on the SPEC page.
 * 0.2.20 (2026-10-26, quest 0.1.5): rules quest.select.on (pick up the icons over buildings: hearts, gifts, telescope)
 *   and quest.select.names (which building names; empty = every name with an icon).
 * 0.2.19 (2026-10-25, quest 0.1.1): rule quest.start.on (start a new quest as selecting it does; default on).
 * 0.2.18 (2026-10-25, ADR 0016, author: Q-1 and Q-2 "ok"; collectables "simple, carry it through"): the Quest
 *   switch quest.auto (quest manager, default off) and rules quest.claim.on, quest.start.on, quest.collect.on (default on, under the
 *   switch) and quest.collectEveryMin (10).
 * 0.2.17 (2026-10-25, author: "what I have plenty of can always go ahead regardless of the level"): rule help.plentyPct
 *  (default 90): a resource whose storage is at least this % of the maximum is given without the level limits.
 * 0.2.16 (2026-10-25, author: "make it so" — small gifts below the floor): rule help.smallPct (default 1, 0 - 10).
 * 0.2.15 (2026-10-25, author: ask a star trade ourselves when a storage is full): trade.ask.on (default false), the
 *  fourth kind of trade, and trade.ask.everyMin (default 60: at most one ask per hour).
 * 0.2.14 (2026-10-25, author: a safety margin for round trades): rule trade.marginPct — we must hold what an RT makes
 *  us pay plus this percentage (default 100), without counting what it brings in.
 * 0.2.13 (2026-10-25, author: "star trade is part of trade, same as help trade"): no Help and Star switches — the Trade
 *  switch covers all trading, and the TRADE page has one rule per kind: trade.rt.on (round trades, default true),
 *  trade.help.on and trade.star.on (default false). help.auto / star.auto migrate into them once.
 * 0.2.12 (2026-10-25, author: settings for the waiting time before the mails are emptied again): rule mail.everyMin
 *  (collect every N minutes, default 1, 1 - 1440).
 * 0.2.11 (2026-10-25, author: "no maximum to a star trade but your stock"): rule star.max removed.
 * 0.2.10 (2026-10-25, author: "we help each other in the guild ... the lower the player's level, the more he may ask"
 *  and "a third form of trade is a star trade"): switches help.auto (helper, TK26 resource giving) and star.auto
 *  (star trader, TK27), both default OFF and needing chat.auto. Rules per level tier (help.t1 below 30, t2 30-59,
 *  t3 60-79, t4 80 and up): times per day, times per week, max amount per request; help.perHourPlayer, help.floor
 *  (minimum own stock), help.floorPct (never more than this share of the stock in one gift), help.costRes / help.costAmount (what the receiver pays, default 1 Fish);
 *  star.max, star.perDay, star.waitHours (how long both trades may stay open), star.returnCostMax. Defaults: the
 *  author's "ruimer" choice (double the first proposal).
 * 0.2.9 (2026-10-25, author: "it is part of mail automation; during an event you may have to save the loot, so you
 *  must be able to switch it off. Mail automation gets one general switch and a separate page with settings based on
 *  facts"): the switch is mail.auto ("Mail", actor mail manager; loot.auto migrates to it). Per kind of loot mail a
 *  rule: mail.loot.treasure, mail.loot.adventure, mail.loot.fragment, mail.loot.expedition (default true), and
 *  mail.loot.toStorage (default false; loot.toStorage migrates to it). Set on the console's MAIL page.
 *
 * 0.2.8 (2026-10-25, author: "emptying the loot mails can be automated too? also with a switch"): switch loot.auto
 *  (actor role loot collector, default OFF) and rule loot.toStorage (collect into the storage instead of the star
 *  menu, default false — the two places the game's own "collect" dialog offers).
 *
 * 0.2.7 (2026-10-25, author: "RTs per uur slaat nergens op"): rule trade.perHour removed.
 *
 * 0.2.6 (2026-10-25, author: "all these values must be adjustable by the player in a screen"): the round-trade rules
 *  are policy rules (owner trade-acceptor), edited in the console's TRADE screen: trade.cap, trade.waitMin,
 *  trade.graceMin, trade.extensions, trade.expireMin, trade.acceptMin, trade.perHour, trade.perSenderHour.
 *
 * 0.2.45 (2026-11-02, ADR 0039 change A, class [impl]): the Trade switch's "initiates" text named TK26 help and TK27 star
 *   trades; the backbone (model v3.2) has them as kinds of TK25 trade set completing. Text only.
 *   Unit: player-policy-ls-words.test.js (version); integration: the console's switch title.
 * 0.2.44 (2026-11-01, test day: "bobsie: i can" got no spot): adv.ls.requestWords default adds "i can" and
 *   "take one"; a stored value equal to an earlier default is raised to the new default once.
 * 0.2.43 (2026-10-31, author: verify a withdrawal): adv.ls.textRevokeAsk, revokeConfirmMin, yesWords, noWords.
 * 0.2.42 (2026-10-31, author: "hij begrijpt yuup niet"): adv.ls.requestWords default adds yes, yup, yep, ya, ja, +.
 * 0.2.41 (2026-10-31, author: one setting for all loot-spot adventures): adv.ls.* — invite mode, waits, last call,
 *   texts (offer, last call, invited, invited one with spots open, withdrawn) and the request / revoke / declare words.
 *   Unit: the rules exist with their defaults; integration: the ADVS page shows them on top.
 * 0.2.40 (2026-10-31, author: "Instellingen worden nog steeds niet onthouden"; live: no dma-policy-changes.jsonl and
 *   dma-policy.json unchanged after an hour with 0.2.39): file errors are kept (lastIoError) and diag() reports
 *   version, started, lastFileWrite, lastIoError and the last change result, for the console to log.
 *   Unit expectation:        a FileStream that throws leaves diag().lastIoError naming the file.
 *   Integration expectation: the console logs every ADVS change with diag(); the cause becomes visible.
 *
 * 0.2.39 (2026-10-31, author: "YWC stands for Young WoodCutter, however you should always check the online information"):
 *   label of adv.ywc.on names "Ali Baba the Young Woodcutter". Unit: the label; integration: shown on the ADVS page.
 *
 * 0.2.38 (2026-10-31, author: "De geselecteerde waarden worden weer niet onthouden ... Deze waarden dienen zelfs buiten de
 *   client bewaard te worden en gelezen zodra de client start"): dma-policy.json (next to the client, outside it) is
 *   written at once on every accepted change instead of after a 1 s timer (its callback never ran in the client, so the
 *   file stayed at 2026-10-30 14:21 and every later change was lost at restart). Every change request, accepted or
 *   declined, is appended to dma-policy-changes.jsonl with the reason, so a lost value can be traced.
 *   Unit expectation:        requestChange("adv.ft.on", true) writes dma-policy.json synchronously with adv.ft.on = true
 *                            and appends one journal line; a new instance reading that file has adv.ft.on = true.
 *   Integration expectation: change a rule on the ADVS page, restart the client: the value is still there.
 *
 * 0.2.37 (2026-10-31, ADR 0033; author: "Bedenk welke keuzes een speler in het algemeen en per adventure en per mundane
 *   template dient te maken. Die moeten dan in de console worden opgenomen"): general Mundane rules adv.mundane.* (starMethod,
 *   landingSpots, topUp, sendVerify, twoStep, advice) and a generic adventure adv.own.* by folder (on, name, repeat, folder
 *   pick "folder", load, order, minStock, buffs, lootSpots, lootBefore, waitCamp, collect, claim). Per-template choices
 *   (role, park-only generals) are the advisor's proposals, confirmed through adv.own.load / adv.own.order.
 *   Unit expectation:        the rules exist with the defaults above; adv.own.folder has pick "folder"; adv.own.on is false.
 *   Integration expectation: tests/integration/dma-mundane-advisor.test.js (policy part).
 *
 * 0.2.36 (2026-10-30, author: "Volgende is het automatiseren van FT" — FT = Ali Baba and the First Thief): adventure rules
 *   adv.ft.* shaped like VLT's (on, repeat, templates, minStock, checkArmy, collect, claim, lootSpots) plus adv.ft.buffs
 *   (instant-destroy buffs the chosen template uses, checked in the star before the start). Off / empty for a new player.
 *   Unit expectation:        adv.ft.templates exists, empty, pick "files"; adv.ft.on is false; adv.ft.buffs is 0.
 *   Integration expectation: the ADVS page lists FT with its rules (tests/integration/dma-advs-templates.test.js).
 * 0.2.35 (2026-10-30, ADR 0030 addendum 4; author: "het hoeft dus niet periodiek. Het kan ook adhoc"): mail.everyMin is the
 *   least time between two mail rounds (default 30, was 1); a round only starts at a quiet moment (the blue manager).
 *   Unit expectation: get("mail.everyMin") === 30. Integration expectation: dma-mail-round.test.js.
 * 0.2.34 (2026-10-30, ADR 0030 addendum 3): rule location.startup.holdSec (default 180; 0 = off) — at start all blue work
 *   waits until the home island has loaded (author: "het eiland bevriest weer, dat moet eerst opgelost worden").
 *   Unit expectation: get("location.startup.holdSec") === 180. Integration expectation: dma-startup-hold.test.js.
 * 0.2.33 (2026-10-30, ADR 0030 addendum 2): rule location.visit.auto (default true) — any trip to another island requests
 *   the visit hold by itself (author: "als iemand naar een andere eiland gaat, stopt de scan automatisch").
 *   Unit expectation: get("location.visit.auto") === true. Integration expectation: dma-visit-hold-auto.test.js.
 * 0.2.32 (2026-10-30, author: "Begin nog niet aan vlt04, want voor die tijd moet je twee ls uitnodigen"): adv.vlt.lootSpots
 *   defaults to 2, offered before VLT04.
 * 0.2.31 (2026-10-30, ADR 0030): rule location.visit.maxMin (default 120) — the failsafe end of a visit hold.
 * 0.2.30 (2026-10-30, author: "wanneer je naar een eiland wil gaan om wat voor een reden dan ook, dan je het scannen van het
 *   home eiland tijdelijk opschort, tot dat je weer terug bent ... als business rule bij de location manager"): rules
 *   location.scan.pauseAway (default on) and location.scan.resumeSec (default 60), owner location management.
 * 0.2.29 (2026-10-30, author: "Ja net als YWC want die stond er ook nog niet op en kijk maar of je in staat bent VLT uit
 *   te voeren"): adventure rules for YWC (Your Wish Come) and VLT (The Valiant Little Tailor), shaped like AE's: on,
 *   repeat, templates (the player's own Mundane files, chooser), minStock, checkArmy, collect, claim, lootSpots.
 *   Every value is off / empty for a new player.
 *   Unit expectation:        adv.ywc.templates and adv.vlt.templates exist, empty, pick "files"; adv.vlt.on is false.
 *   Integration expectation: the ADVS page lists YWC and VLT with their rules (tests/integration/dma-advs-templates.test.js).
 * 0.2.28 (2026-10-29, author: "voor de advs geldt dus dat ze hun eigen mundane templates moeten kunnen selecteren" — the
 *   scripts are exported for another player): adv.ae.templates has no default (it held the author's own "AE01/AE02"),
 *   is marked pick "files" so the console offers a file chooser for the player's own Mundane Warfare template files,
 *   and a text rule may carry maxLength (here 1000, for full paths; the default stays 120).
 *   Unit expectation:        a new policy has adv.ae.templates = ""; a 300-character path list is kept whole.
 *   Integration expectation: the ADVS page shows a "Choose..." button for it (tests/integration/dma-advs-templates.test.js).
 * 0.2.5 (2026-10-25, author): chat.words is labelled "Chat reply word"; the key is unchanged.
 *
 * 0.2.4 (2026-10-25, author: another player will test the scripts without Claude watching): chat.auto and
 *  trade.auto default OFF for a new player (on this island they are already stored ON); new rule chat.words —
 *  the words in a guild message the chat watcher reacts to (the player's own name, e.g. "Peter"), set in the
 *  console. valueType "text": a plain string, control characters removed, at most 120 characters.
 *
 * 0.2.3 (2026-10-25, author: "make sure the actor roles are reflected in the switches of our console: chat watch
 *  and trading"): two more self-starting actor roles get a switch —
 *  chat.auto  (chat watcher: replies to a "Peter" mention, takes in an RT request) and
 *  trade.auto (trade acceptor, TK25: promises, accepts and declares round trades; needs chat.auto).
 *  Both default ON (dflt), because both were running before they had a switch; an explicit OFF is remembered.
 * Owns business rules and the player's self-starter switches. No game execute.
 *
 * 0.2.0 (2026-10-24)
 *  - One switch per self-starting actor role (SWITCHES). The player decides which
 *    self-starters self-activate; there is no separate Exec switch and no cycle flag:
 *    the cycle always runs, and control.allowExecute / control.cycleRunning read true.
 *  - Single store: the switches live in dma.playerPolicy.v1 like every other rule.
 *    The 0.1.x side store localStorage "dma.switches" is migrated once and removed.
 *  - Legacy keys (search/building/buff/demolish.autoEnabled, autoBuild, ...) are
 *    canonicalised to the switch keys, so older readers see the same value.
 *  - persist() no longer writes dma.cycleRunning (it clobbered the cycle on every change).
 *
 * 0.2.1 (2026-10-24, from the live test): localStorage of the TSO (Adobe AIR) client does NOT
 *  survive a client restart — the switches, caps and explorer preferences were lost on every
 *  restart, which was the reported "switches not persistent".
 *  - The policy is now persisted to a file, dma-policy.json, in the client's application
 *    directory (air.File), next to dma-stand.json. Never settings.json. Writes are coalesced (1 s).
 *  - Restore order: defaults <- dma-stand.json (first start only, no switches) <- localStorage
 *    (same session) <- dma-policy.json (wins).
 *  - First start without dma-policy.json: caps, buff names, upgrade targets, labels and slots are
 *    taken from dma-stand.json; switches stay off, so no self-starter starts without the player.
 *  - New rule "expo.prefs" (object): the player's explorer task per explorer type.
 *
 * 0.2.2 (2026-10-24): the player's settings for green 0.5.0's rule table.
 *  - "buff.prefs" (object): the player's buff per building type (BUFF screen).
 *  - "rule.<ruleId>.<setting>" (number | bool): a setting of a named rule in green's table.
 *  - "control.sendIntervalMs" (number, 500..10000): pace of server actions within a cycle.
 *  - "control.sendIntervalMinMs" (number, 300..10000): the fastest pace green may adapt to.
 */
(function (root) {
    "use strict";
    var ID = "pbc.player-policy";
    var NAME = "Player Policy";
    var VERSION = "0.2.92";
    var CATALOG_R = ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];
    var DEFAULT_CAPS = {
        Stone: 9, BronzeOre: 6, Marble: 10, IronOre: 22, GoldOre: 11,
        Coal: 6, Granite: 7, TitaniumOre: 6, Salpeter: 6
    };

    /*
     * Self-starter switches. One row per self-starting actor role of the island model.
     * key      the policy fact (bool) the actor reads before it self-activates
     * actor    the actor role (DEMO); the specialist manager carries two specialist types
     * initiates what the actor requests when it self-activates
     * needs    switches whose facts this actor reads (shown as "blocked" when off)
     */
    var SWITCHES = [
        { key: "island.auto",  short: "island",  label: "Island",  actor: "location-manager",          initiates: "island scan",           needs: [],              title: "Location manager: observe the island" },
        { key: "geo.auto",     short: "geo",     label: "Geo",     actor: "specialist-manager/geo",    initiates: "deposit search",        needs: ["island.auto"], title: "Specialist manager: send geologists" },
        { key: "expo.auto",    short: "expo",    label: "Expo",    actor: "specialist-manager/expo",   initiates: "exploration",           needs: [],              title: "Specialist manager: send explorers" },
        { key: "build.auto",   short: "build",   label: "Build",   actor: "building-manager",          initiates: "mine construction",     needs: ["island.auto"], title: "Building manager: build mines" },
        { key: "upgrade.auto", short: "upgrade", label: "Upgrade", actor: "upgrade-manager",           initiates: "mine upgrade",          needs: ["island.auto"], title: "Upgrade manager: upgrade mines" },
        { key: "buff.auto",    short: "buff",    label: "Buff",    actor: "buff-manager",              initiates: "buff application",      needs: ["island.auto"], title: "Buff manager: buff mines" },
        { key: "demo.auto",    short: "demo",    label: "Demolish",    actor: "demolish-manager",          initiates: "mine demolition",       needs: ["island.auto"], title: "Demolish manager: demolish low mines" },
        // 0.2.3: the guild-facing actor roles
        { key: "chat.auto",    short: "chat",    label: "Chat",    actor: "chat-watcher",              initiates: "reply to a mention",    needs: [], title: "Chat watcher: reply when your chat reply word is used, take in RT requests" },
        { key: "mail.auto",    short: "mail",    label: "Mail",    actor: "mail-manager",              initiates: "mail handling",         needs: [], title: "Mail manager: handle mails by the rules on the MAIL page (loot collecting)" },
        { key: "quest.auto",   short: "quest",   label: "Quest",   actor: "quest-manager",             initiates: "quest reward claiming, collectibles (TK71, TK72)", needs: [], title: "Quest manager: claim finished quests and pick up collectibles, by the rules on the QUEST page" },
        { key: "event.auto",   short: "event",   label: "Event",   actor: "event-manager",             initiates: "event filling, event buffs, event counters, event quests first", needs: [], title: "Event manager: the running event's rules (fill, buffs, counters) and its quests first in the quest book" },   // 0.2.48
        { key: "trade.auto",   short: "trade",   label: "Trade",   actor: "trade-acceptor",            initiates: "trading (TK25 trade sets: round trades, help, star trades)", needs: ["chat.auto"], title: "Trade: round trades, help trades and star trades, by the rules on the TRADE page" },
        { key: "troops.auto",  short: "troops",  label: "Troops",  actor: "troop manager",             initiates: "troop training",        needs: [], title: "Troop manager: keep the troop stock at the targets of the TROOPS page (TK62, TK63)" },   // 0.2.66
        { key: "supply.auto", short: "supply", label: "Supply", actor: "resource supply manager", initiates: "resource supply managing", needs: [], title: "Resource supply manager: obtain a short resource - make it, raise production, then the trade office, the guild chat last (ADR 0075, TK66)" },   // 0.2.67
        { key: "adv.auto", short: "adv", label: "Adventure", actor: "adventure-manager", initiates: "adventure completing (TK18) of the adventures you keep running", needs: [], title: "Adventure manager: start the next run of every adventure whose keep rule is on (ADR 0088, TK17)" },   // 0.2.76
    ];
    var LEGACY_SWITCH = {
        "search.autoEnabled": "geo.auto", autoSearch: "geo.auto",
        "building.autoEnabled": "build.auto", autoBuild: "build.auto",
        "buff.autoEnabled": "buff.auto", autoBuff: "buff.auto",
        "demolish.autoEnabled": "demo.auto", autoDemolish: "demo.auto"
    };
    var RETIRED = { "control.repairCorrupt": "the corrupt-mine repair is retired (CL-51a rejected, control 0.2.96)",
                    "adv.ft.keep": "replaced by the Run setting adv.keep.res (0.2.83)", "adv.ywc.keep": "replaced by the Run setting adv.keep.res (0.2.83)" };   // 0.2.61
    var ALWAYS_TRUE = { "control.allowExecute": 1, allowExecute: 1, "control.cycleRunning": 1 };
    function isSwitch(k) {
        var i;
        for (i = 0; i < SWITCHES.length; i++) if (SWITCHES[i].key === k) return true;
        return false;
    }

    var RULES = [
        { ruleId: "search.inPlayOnly", label: "Search only resources of operational sectors", valueType: "bool", value: true, ownerPbc: "pbc.geologist-search", arsSlot: "ASSESS" },
        { ruleId: "search.resourcesEnabled", label: "Searchable resources", valueType: "set", value: CATALOG_R.slice(), ownerPbc: "pbc.geologist-search", arsSlot: "EVENT" },
        { ruleId: "search.preferredType", label: "Preferred geologist type", valueType: "enum", value: "", ownerPbc: "pbc.geologist-search", arsSlot: "ASSESS" },
        { ruleId: "demolish.threshold", label: "Demolish remaining threshold", valueType: "number", value: null, ownerPbc: "pbc.demolish-management", arsSlot: "ASSESS", allowedRange: { min: 0, max: 5000 } },
        { ruleId: "resource.requireFullBasket", label: "Require full resource basket", valueType: "bool", value: true, ownerPbc: "pbc.resource-management", arsSlot: "ASSESS" },
        { ruleId: "control.maxActionsPerCycle", label: "Max actions per cycle", valueType: "number", value: 5, ownerPbc: "dma-control", arsSlot: "ASSESS", allowedRange: { min: 1, max: 20 } },
        { ruleId: "trade.cap", label: "Max per item in a round trade", valueType: "number", value: 100, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 1, max: 10000 } },
        { ruleId: "trade.waitMin", label: "Minutes to wait for the trades before the time is up", valueType: "number", value: 3, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 1, max: 30 } },
        { ruleId: "trade.graceMin", label: "Minutes after 'time is up' before declining", valueType: "number", value: 1, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 1, max: 10 } },
        { ruleId: "trade.extensions", label: "How often a player may ask for more time", valueType: "number", value: 3, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 0, max: 10 } },
        { ruleId: "trade.expireMin", label: "Minutes a promise stays open", valueType: "number", value: 30, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 5, max: 240 } },
        { ruleId: "trade.acceptMin", label: "Minutes of silence after 'RT done' that count as accepted", valueType: "number", value: 30, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 1, max: 240 } },
        { ruleId: "trade.marginPct", label: "Safety margin: hold what an RT pays plus ... %", valueType: "number", value: 100, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000 } },
        { ruleId: "trade.perSenderHour", label: "Requests per player per hour", valueType: "number", value: 2, ownerPbc: "trade-acceptor", arsSlot: "ASSESS", allowedRange: { min: 1, max: 20 } },
        { ruleId: "mail.loot.treasure", label: "Collect treasure loot mails", valueType: "bool", value: true, ownerPbc: "mail-manager", arsSlot: "ASSESS" },
        { ruleId: "mail.loot.adventure", label: "Collect found-adventure mails", valueType: "bool", value: true, ownerPbc: "mail-manager", arsSlot: "ASSESS" },
        { ruleId: "mail.loot.fragment", label: "Collect map-fragment mails", valueType: "bool", value: true, ownerPbc: "mail-manager", arsSlot: "ASSESS" },
        { ruleId: "mail.loot.expedition", label: "Collect found-expedition mails", valueType: "bool", value: true, ownerPbc: "mail-manager", arsSlot: "ASSESS" },
        // 0.2.30: location manager (author 2026-10-30: "wanneer je naar een eiland wil gaan ... het scannen van het home eiland tijdelijk opschort, tot dat je weer terug bent")
        { ruleId: "location.scan.pauseAway", label: "Pause the island scan while travelling to / on another island", valueType: "bool", value: true, ownerPbc: "pbc.location-management", arsSlot: "EVENT" },
        { ruleId: "location.scan.resumeSec", label: "Resume the scan ... seconds after being home again", valueType: "number", value: 60, ownerPbc: "pbc.location-management", arsSlot: "EVENT", allowedRange: { min: 0, max: 600 } },
        { ruleId: "location.visit.maxMin", label: "A visit hold ends by itself after ... minutes", valueType: "number", value: 120, ownerPbc: "pbc.location-management", arsSlot: "EVENT", allowedRange: { min: 5, max: 720 } },   // 0.2.31
        { ruleId: "location.visit.auto", label: "Travelling to another island puts all blue work at home on hold automatically", valueType: "bool", value: true, ownerPbc: "pbc.location-management", arsSlot: "EVENT" },   // 0.2.33
        { ruleId: "location.startup.holdSec", label: "At start, all blue work waits ... seconds for the home island to load", valueType: "number", value: 180, ownerPbc: "pbc.location-management", arsSlot: "EVENT", allowedRange: { min: 0, max: 900 } },   // 0.2.34
        { ruleId: "mail.everyMin", label: "Open the mailbox at most every ... minutes (at a quiet moment)", valueType: "number", value: 30, ownerPbc: "mail-manager", arsSlot: "EVENT", allowedRange: { min: 1, max: 1440 } },
        { ruleId: "mail.loot.toStorage", label: "Collect loot into the storage (else the star menu)", valueType: "bool", value: false, ownerPbc: "mail-manager", arsSlot: "ASSESS" },
        // 0.2.22: adventures (decision 0022) — owner adventure-manager; the player decides every value
        { ruleId: "adv.ae.on", label: "AE: run Arctic Explosion", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.ae.repeat", label: "AE: runs in a row (0 = one on request)", valueType: "number", value: 0, ownerPbc: "adventure-manager", arsSlot: "EVENT", allowedRange: { min: 0, max: 50 } },
        { ruleId: "adv.ae.templates", label: "AE: Mundane templates (armies, alternating)", valueType: "text", value: "", maxLength: 1000, pick: "files", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.28: the player's own files, no default
        { ruleId: "adv.ae.minStock", label: "AE: keep at least ... in the star", valueType: "number", value: 0, ownerPbc: "adventure-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 500 } },
        { ruleId: "adv.ae.collect", label: "AE: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ae.claim", label: "AE: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ae.lootSpots", label: "AE: loot spots offered to the guild", valueType: "number", value: 1, ownerPbc: "adventure-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 2 } },
        { ruleId: "adv.ae.checkArmy", label: "AE: send only when every general is full", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ae.topUpRS", label: "AE: top up recruits / soldiers on the island", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ae.minRecruits", label: "AE: below ... recruits, queue recruits", valueType: "number", value: 1000, ownerPbc: "adventure-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 100000 } },
        // 0.2.29: YWC = Ali Baba the Young Woodcutter (name corrected 0.2.39; author 2026-10-30: "Ja net als YWC want die stond er ook nog niet op")
        { ruleId: "adv.ywc.on", label: "YWC: run Ali Baba the Young Woodcutter", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.ywc.repeat", label: "YWC: runs in a row (0 = one on request)", valueType: "number", value: 0, allowedRange: { min: 0, max: 50 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.ywc.templates", label: "YWC: Mundane templates (your own files)", valueType: "text", value: "", maxLength: 1000, pick: "files", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.minStock", label: "YWC: keep at least ... in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 500 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.checkArmy", label: "YWC: send only when every general is full and the troops cover the whole adventure", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.collect", label: "YWC: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.claim", label: "YWC: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.lootSpots", label: "YWC: loot spots offered to the guild", valueType: "number", value: 0, allowedRange: { min: 0, max: 2 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ywc.retreat", label: "YWC: retreat a general that is intercepted (off: YWC intercepts some generals on purpose)", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.79
        { ruleId: "adv.ywc.aheadHome", label: "YWC: after the first attack its generals go home, not to the star (the next run can start with them)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "RESPONSE" },
        { ruleId: "adv.ywc.closeAtOnce", label: "YWC: close the adventure as soon as the last camp falls (no wait for recovering generals; loose troops still go into the free generals)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "RESPONSE" },
        { ruleId: "adv.travel", label: "ALL adventures (single runs, kept runs and series): travel speed-ups put on before sending, when not already running (buffs of one group exclude each other)", valueType: "set", value: [], pick: "travelBuffs", exclusive: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.81
        { ruleId: "adv.retreat.on", label: "ALL adventures: retreat every general whose fight has not begun when one is intercepted, and stop the run (off: intercepted generals fight on)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.82
        { ruleId: "adv.travel.exclusive", label: "ALL adventures: speed-up families that exclude each other (name prefixes, separated by ;) — the game gives these buffs no exclusivity group", valueType: "text", value: "GeneralSpeedBuff_;Observatory:", maxLength: 200, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.84
        { ruleId: "adv.travel.match", label: "ALL: which star buffs count as travel speed-ups (a name pattern)", valueType: "text", value: "TravelBoost|StarChart|GeneralSpeedBuff|TravelDocuments", maxLength: 200, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.80
        // 0.2.29: The Valiant Little Tailor (author 2026-10-30: "Ja net als YWC want die stond er ook nog niet op")
        { ruleId: "adv.vlt.on", label: "VLT: run The Valiant Little Tailor", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.vlt.repeat", label: "VLT: runs in a row (0 = one on request)", valueType: "number", value: 0, allowedRange: { min: 0, max: 50 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.vlt.templates", label: "VLT: Mundane templates (your own files)", valueType: "text", value: "", maxLength: 1000, pick: "files", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.vlt.minStock", label: "VLT: keep at least ... in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 500 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.vlt.checkArmy", label: "VLT: send only when every general is full and the troops cover the whole adventure", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.vlt.collect", label: "VLT: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.vlt.claim", label: "VLT: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.vlt.lootSpots", label: "VLT: loot spots offered to the guild (before VLT04)", valueType: "number", value: 2, allowedRange: { min: 0, max: 2 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        // 0.2.36: Ali Baba and the First Thief (author 2026-10-30: "Volgende is het automatiseren van FT")
        { ruleId: "adv.ft.on", label: "FT: run Ali Baba and the First Thief", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.ft.repeat", label: "FT: runs in a row (0 = one on request)", valueType: "number", value: 0, allowedRange: { min: 0, max: 50 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.ft.templates", label: "FT: Mundane templates (your own files)", valueType: "text", value: "", maxLength: 1000, pick: "files", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.minStock", label: "FT: keep at least ... in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 500 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.buffs", label: "FT: instant-destroy buffs (small/medium camps) the template needs in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 10 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.checkArmy", label: "FT: send only when every general is full and the troops cover the whole adventure", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.collect", label: "FT: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.claim", label: "FT: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.ft.lootSpots", label: "FT: loot spots offered to the guild", valueType: "number", value: 0, allowedRange: { min: 0, max: 2 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.keep.res", label: "Run: the adventure the adventure manager keeps running (its star name; empty = none)", valueType: "text", value: "", maxLength: 80, ownerPbc: "adventure-manager", arsSlot: "EVENT" },   // 0.2.83
        { ruleId: "adv.keep.version", label: "Run: the version it plays (empty = the adventure's default version)", valueType: "text", value: "", maxLength: 80, ownerPbc: "adventure-manager", arsSlot: "EVENT" },   // 0.2.83
        { ruleId: "adv.keep.runs", label: "Run: how many runs (0 = until you stop it)", valueType: "number", value: 0, allowedRange: { min: 0, max: 500 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },   // 0.2.83
        { ruleId: "adv.keep.retryMin", label: "Kept adventures: after a stopped run, try again after ... minutes", valueType: "number", value: 30, allowedRange: { min: 5, max: 1440 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.76
        { ruleId: "adv.keep.planRuns", label: "Kept adventures: the troop manager plans troops for ... runs ahead", valueType: "number", value: 3, allowedRange: { min: 1, max: 20 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.76
        { ruleId: "adv.prestage", label: "Every adventure: while a round fights, place the next round's generals from the star and load them", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.78 (author 2026-11-20, FT)
        /* 0.2.41 (author 2026-10-31: "voor alle ls adventures bepaal je bovenaan 1 keer, hoe je uitnodigt, hoe je dat
           bevestigt, of twee tegelijkertijd, of 1 en tevens aangeven dat er nog 1 open staat, dan een maximale tijd om te
           wachten. 2 minuten voor verstrijken van die tijd een last call ..."): the loot-spot rules for every adventure */
        { ruleId: "adv.ls.inviteMode", label: "LS: invite both together, or one by one (and say how many spots are still open)", valueType: "text", value: "together", allowedValues: ["together", "one by one"], ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.waitMin", label: "LS: minutes to wait for requests", valueType: "number", value: 5, allowedRange: { min: 1, max: 60 }, ownerPbc: "loot-spot-granting", arsSlot: "EVENT" },
        { ruleId: "adv.ls.lastCallMin", label: "LS: last call ... minutes before the wait ends", valueType: "number", value: 2, allowedRange: { min: 0, max: 30 }, ownerPbc: "loot-spot-granting", arsSlot: "EVENT" },
        { ruleId: "adv.ls.killWaitMin", label: "LS: minutes to wait for the reported kills", valueType: "number", value: 15, allowedRange: { min: 1, max: 120 }, ownerPbc: "loot-spot-granting", arsSlot: "EVENT" },
        { ruleId: "adv.ls.textOffer", label: "LS: offer ({n} spots, {adv} short name)", valueType: "text", value: "{n}x ls {adv}", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.textLastCall", label: "LS: last call", valueType: "text", value: "last call: {n}x ls {adv}", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.textInvited", label: "LS: invited (together; {names})", valueType: "text", value: "{names} invited, make a kill and report it in the adv chat, we close after the kills", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.textInvitedOne", label: "LS: invited one ({name}, {open} still open)", valueType: "text", value: "{name} invited, make a kill and report it in the adv chat, we close after the kills. {open}x ls {adv} still open", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.textRevoked", label: "LS: a request withdrawn ({name})", valueType: "text", value: "{name}: ok, your spot is withdrawn", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.requestWords", label: "LS: words that count as a request", valueType: "text", value: "pls, plz, please, me, yes, yup, yep, ya, ja, +, i can, take one", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.revokeWords", label: "LS: words that withdraw a request", valueType: "text", value: "cancel, nvm, never mind, cant, can't, have to go, gotta go, out", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.textRevokeAsk", label: "LS: question when someone seems to withdraw ({name})", valueType: "text", value: "{name}, do I understand correctly that you cancel your ls?", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.revokeConfirmMin", label: "LS: minutes without an answer after which the withdrawal stands", valueType: "number", value: 2, allowedRange: { min: 1, max: 15 }, ownerPbc: "loot-spot-granting", arsSlot: "EVENT" },
        { ruleId: "adv.ls.yesWords", label: "LS: words that confirm the withdrawal", valueType: "text", value: "yes, yup, yep, ya, ja, correct, indeed, right, ok, sure, y", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.noWords", label: "LS: words that keep the spot", valueType: "text", value: "no, nope, nee, not, nah, n, stay, keep", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        { ruleId: "adv.ls.declareWords", label: "LS: words that report the kill", valueType: "text", value: "kd, done, killed", ownerPbc: "loot-spot-granting", arsSlot: "ASSESS" },
        /* 0.2.37 (ADR 0033): the general Mundane choices, for every adventure */
        { ruleId: "adv.loot.on", label: "LOOT: advise an adventure when a stock runs out (R-ADV-LOOT)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "EVENT" },   // 0.2.46
        { ruleId: "adv.loot.horizonHours", label: "LOOT: a stock runs out when it is gone within ... hours at its current pace", valueType: "number", value: 48, allowedRange: { min: 1, max: 336 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.loot.windowHours", label: "LOOT: pace measured over the last ... hours", valueType: "number", value: 6, allowedRange: { min: 1, max: 36 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.loot.from", label: "LOOT: advise from the adventures in", valueType: "text", value: "star", allowedValues: ["star", "star or book", "any"], ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.mundane.starMethod", label: "ALL: star method (send all, return to the star after landing, place each round's attackers)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.mundane.topUp", label: "ALL: top up Recruits / Soldiers from the star on the island (they are spent)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.mundane.sendVerify", label: "ALL: after Send, check every general left; reload and send again", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.mundane.twoStep", label: "ALL: load in two steps when a general must give back troops first", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.aheadHome", label: "ALL: after the first attack its generals go home, not to the star (an adventure's own rule wins)", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "RESPONSE" },
        { ruleId: "adv.closeAtOnce", label: "ALL: close an adventure as soon as its last camp falls, without waiting for recovering generals (loose troops still go into the free generals; an adventure's own rule wins)", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "RESPONSE" },
        { ruleId: "adv.waves.loadMargin", label: "ALL: a version that reloads between waves loads every wave plus the expected losses, plus this margin (0.25 = 25 %); short → it does not start (ADR 0080)", valueType: "number", value: 0.25, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.71 (adventure 0.2.88)
        { ruleId: "adv.stowLoose", label: "ALL: before closing, load the loose troops into the generals still on the map (empty generals, or the unit types a general already holds)", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.62 (adventure 0.2.81/0.2.82)
        { ruleId: "adv.blocks.on", label: "ALL: allow blocks (a general keeps a watching camp busy while another passes; a failed block can lose its army)", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },   // 0.2.55 (ADR 0066)
        { ruleId: "adv.mundane.advice", label: "ALL: show improvement proposals for my templates", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        /* 0.2.37 (ADR 0033): any adventure of the player's own, by folder */
        { ruleId: "adv.own.on", label: "OWN: run this adventure", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.own.name", label: "OWN: adventure name (as in the Send menu)", valueType: "text", value: "", maxLength: 80, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.own.repeat", label: "OWN: runs in a row (0 = one on request)", valueType: "number", value: 0, allowedRange: { min: 0, max: 50 }, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.own.folder", label: "OWN: folder with your Mundane templates for it", valueType: "text", value: "", maxLength: 400, pick: "folder", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.load", label: "OWN: load template (empty = the advisor's choice)", valueType: "text", value: "", maxLength: 120, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.order", label: "OWN: run order, \" / \" between (empty = the advisor's order)", valueType: "text", value: "", maxLength: 1000, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.minStock", label: "OWN: keep at least ... in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 500 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.buffs", label: "OWN: instant-destroy buffs the templates need in the star", valueType: "number", value: 0, allowedRange: { min: 0, max: 20 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.lootSpots", label: "OWN: loot spots offered to the guild", valueType: "number", value: 0, allowedRange: { min: 0, max: 2 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.lootBefore", label: "OWN: offer the loot spots before round (0 = at the start)", valueType: "number", value: 0, allowedRange: { min: 0, max: 30 }, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.waitCamp", label: "OWN: start the next round only when the previous round's camps are gone", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.collect", label: "OWN: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.own.claim", label: "OWN: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.on", label: "GP: run Gunpowder", valueType: "bool", value: false, ownerPbc: "adventure-manager", arsSlot: "EVENT" },
        { ruleId: "adv.gp.repeat", label: "GP: runs in a row (0 = one on request)", valueType: "number", value: 0, ownerPbc: "adventure-manager", arsSlot: "EVENT", allowedRange: { min: 0, max: 50 } },
        { ruleId: "adv.gp.minStock", label: "GP: keep at least ... in the star", valueType: "number", value: 0, ownerPbc: "adventure-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 500 } },
        { ruleId: "adv.gp.collect", label: "GP: press C for collectables", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.claim", label: "GP: claim the quests and complete", valueType: "bool", value: true, ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.lootSpots", label: "GP: loot spots offered to the guild", valueType: "number", value: 2, ownerPbc: "adventure-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 2 } },
        { ruleId: "adv.gp.arrowFirst", label: "GP: first arrow on the castle", valueType: "text", value: "Rain of Flaming Arrows", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.arrowThen", label: "GP: arrow when the castle still stands", valueType: "text", value: "Cupid's Arrow", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.pleaseWaitMin", label: "GP: minutes to wait for a request (pls)", valueType: "number", value: 5, ownerPbc: "adventure-manager", arsSlot: "EVENT", allowedRange: { min: 1, max: 60 } },
        { ruleId: "adv.gp.offerRepeat", label: "GP: repeat the offer when it scrolled out of the chat (times)", valueType: "number", value: 1, ownerPbc: "adventure-manager", arsSlot: "EVENT", allowedRange: { min: 0, max: 3 } },
        { ruleId: "adv.gp.onTimeout", label: "GP: too few requests: ask / wait / one / none", valueType: "text", value: "ask", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.killWaitMin", label: "GP: minutes to wait for a declared kill (kd)", valueType: "number", value: 15, ownerPbc: "adventure-manager", arsSlot: "EVENT", allowedRange: { min: 1, max: 120 } },
        { ruleId: "adv.gp.requestWords", label: "GP: words that count as a request", valueType: "text", value: "pls, plz, please, me", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.declareWords", label: "GP: words that count as a declared kill", valueType: "text", value: "kd, done, killed", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.textOffer", label: "GP: guild text of the offer", valueType: "text", value: "{n}x ls GP", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.textPromise", label: "GP: guild text of the promise", valueType: "text", value: "{names} invited, just make a kill and report it on adv chat, I'll close", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "adv.gp.textRevoke", label: "GP: guild text when a spot frees up", valueType: "text", value: "{n}x ls GP", ownerPbc: "adventure-manager", arsSlot: "ASSESS" },
        { ruleId: "buff.event.on", label: "Buff the buildings the running event brings (pumpkin cemeteries)", valueType: "bool", value: false, ownerPbc: "buff-manager", arsSlot: "ASSESS" },
        { ruleId: "buff.event.exclude", label: "Buffs green may not choose for event buildings", valueType: "object", value: [], ownerPbc: "buff-manager", arsSlot: "ASSESS" },
        { ruleId: "quest.do.guild", label: "Quest book: do Guild quest", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.daily", label: "Quest book: do Daily quests", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.weekly", label: "Quest book: do Weekly challenges", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.ghostship", label: "Quest book: do Ghost ship quests", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.starfall", label: "Quest book: do Starfall quests", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.event", label: "Quest book: do Event quests (the Quest switch must be on too)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.main", label: "Quest book: do Main quests", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.side", label: "Quest book: do Side quests", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.47 (ADR 0053)
        { ruleId: "quest.do.building", label: "Quest book: do Building-bonus quests (BuiBonus loops)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.49
        { ruleId: "quest.claim.on", label: "Claim the reward of a finished quest", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },
        { ruleId: "quest.start.on", label: "Start a new quest (as selecting it in the Quest Book does)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },
        { ruleId: "expo.template", label: "Explorer template (Daily, Event, Adventure)", valueType: "text", value: "Daily", ownerPbc: "specialist-manager/expo", arsSlot: "ASSESS" },
        { ruleId: "quest.select.on", label: "Pick up the icons over buildings (hearts, gifts, telescope)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },
        { ruleId: "quest.select.names", label: "Only these building names (comma separated; empty = all with an icon)", valueType: "text", value: "", ownerPbc: "quest-manager", arsSlot: "ASSESS" },
        { ruleId: "quest.collect.on", label: "Pick up collectibles on the island", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },
        { ruleId: "quest.pay.on", label: "Pay a guild quest from storage (as the Quest Book's pay button)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.50
        { ruleId: "quest.pickup.on", label: "Pick up finished productions (Pick-up button)", valueType: "bool", value: true, ownerPbc: "quest-manager", arsSlot: "ASSESS" },   // 0.2.50
        // 0.2.58 (review 2026-11-16 #12): every automatic switch is registered here and defaults off for a new player
        // troops.auto: a switch since 0.2.66 (SWITCHES)
        // 0.2.90 (change-set B15, tester SirBirk 2026-11-27): the barracks queue of the troop manager (troops 0.1.10)
        { ruleId: "troops.queueRows", label: "Troops: rows of one unit kind that may wait in the barracks at once (1 = one at a time)", valueType: "number", value: 1, ownerPbc: "troop-manager", arsSlot: "ASSESS", allowedRange: { min: 1, max: 20 } },
        { ruleId: "troops.rowSize", label: "Troops: units per row (short rows stay changeable)", valueType: "number", value: 25, ownerPbc: "troop-manager", arsSlot: "ASSESS", allowedRange: { min: 1, max: 500 } },
        { ruleId: "troops.priority", label: "Troops: unit kinds first, in this order (comma separated; empty = by name)", valueType: "text", value: "", ownerPbc: "troop-manager", arsSlot: "ASSESS" },
        { ruleId: "troops.balanced", label: "Troops: balanced building (a row of each short unit kind in turn; off = by priority, one kind's rows first)", valueType: "bool", value: true, ownerPbc: "troop-manager", arsSlot: "ASSESS" },
        { ruleId: "zombie.auto", label: "Zombie hunt: attack zombie camps when they appear", valueType: "bool", value: false, ownerPbc: "zombie-hunt-manager", arsSlot: "EVENT" },
        { ruleId: "premium.setting", label: "Premium: extend from the star — off, always, or during an event", valueType: "choice", allowed: ["off", "always", "event"], value: "off", ownerPbc: "premium", arsSlot: "EVENT", factType: "AT72" },   // 0.2.60 (v3.16 D-2): replaces premium.autoExtend
        // 0.2.72 (ADR 0083 point 3, author 2026-11-18: "Geef ook de speler de mogelijkheid dat aan of uit te zetten. Standaard uit bij andere spelers"):
        // a self-restart of the client (stale stock, explorers that do not leave) is the player's choice, off by default.
        { ruleId: "control.selfRestart.on", label: "Restart the client by itself when the game stops responding", valueType: "bool", value: false, ownerPbc: "control", arsSlot: "EVENT" },
        { ruleId: "control.staleRestartMin", label: "Self-restart: the stock must stand still for at least ... minutes", valueType: "number", value: 10, ownerPbc: "control", arsSlot: "ASSESS", allowedRange: { min: 5, max: 240 } },
        { ruleId: "control.watchdog", label: "Watchdog tool: relaunch the client after sleep (Windows scheduled task)", valueType: "bool", value: false, ownerPbc: "watchdog-tool", arsSlot: "EVENT" },
        { ruleId: "control.keepAwake", label: "Watchdog tool: keep the computer awake while the client runs", valueType: "bool", value: false, ownerPbc: "watchdog-tool", arsSlot: "EVENT" },
        { ruleId: "zombie.generals", label: "Zombie hunt: its generals (names or ids, comma separated; empty = the four it chose)", valueType: "text", value: "", ownerPbc: "zombie-hunt-manager", arsSlot: "ASSESS" },   // 0.2.51
        { ruleId: "quest.collectEveryMin", label: "Look for collectibles every ... minutes", valueType: "number", value: 10, ownerPbc: "quest-manager", arsSlot: "EVENT", allowedRange: { min: 1, max: 1440 } },
        { ruleId: "trade.rt.on", label: "Round trades", valueType: "bool", value: true, ownerPbc: "trade-acceptor", arsSlot: "ASSESS" },
        { ruleId: "trade.help.on", label: "Help trades", valueType: "bool", value: false, ownerPbc: "trade-acceptor", arsSlot: "ASSESS" },
        { ruleId: "trade.star.on", label: "Star trades", valueType: "bool", value: false, ownerPbc: "trade-acceptor", arsSlot: "ASSESS" },
        { ruleId: "trade.ask.on", label: "Ask a star trade when a storage is full", valueType: "bool", value: false, ownerPbc: "trade-acceptor", arsSlot: "EVENT" },
        { ruleId: "trade.ask.everyMin", label: "Ask at most once per ... minutes", valueType: "number", value: 60, ownerPbc: "trade-acceptor", arsSlot: "EVENT", allowedRange: { min: 15, max: 1440 } },
        { ruleId: "supply.make.on", label: "Short resource: make it myself (resource producing)", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.67
        { ruleId: "supply.produce.on", label: "Short resource: raise production (build, upgrade or buff a maker)", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },
        { ruleId: "supply.office.on", label: "Short resource: buy at the trade office when favourable in value", valueType: "bool", value: false, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },
        { ruleId: "supply.office.maxPricePct", label: "Guild purchase: pay at most this % of the value list", valueType: "number", value: 100, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 50, max: 200 } },
        { ruleId: "supply.office.minMarketRatio", label: "Trade office: the offer must be at least this many times better than the market price", valueType: "number", value: 1.5, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 1, max: 10 } },   // 0.2.68
        { ruleId: "supply.office.neverPay", label: "Trade office: never pay with these resources", valueType: "set", value: ["Oilseed", "Oil"], ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", pick: "resources" },   // 0.2.73: a checklist (was text)
        { ruleId: "supply.office.neverPay.on", label: "Trade office: apply the never-pay list", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.73
        { ruleId: "supply.office.minMarketRatio.on", label: "Trade office: apply the market-price ratio (off = the price is not checked)", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.73
        { ruleId: "supply.office.afterMin.on", label: "Trade office: wait until a resource has been short for a while", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.73
        { ruleId: "supply.office.afterMin", label: "Trade office: a resource must be short for at least ... minutes", valueType: "number", value: 30, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1440 } },   // 0.2.73
        { ruleId: "supply.guild.afterMin.on", label: "Guild chat: wait until own making has had its time", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.73
        { ruleId: "supply.guild.afterMin", label: "Guild chat: own making gets ... minutes before the guild is asked", valueType: "number", value: 120, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 2880 } },   // 0.2.73
        { ruleId: "supply.office.keepPayStock", label: "Trade office: keep at least this much of the paid resource beyond what is reserved", valueType: "number", value: 0, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000000 } },
        { ruleId: "supply.office.maxPerDay", label: "Trade office: at most this many purchases per day", valueType: "number", value: 3, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 50 } },
        { ruleId: "supply.guild.on", label: "Short resource: ask a guild member to sell it (last resort)", valueType: "bool", value: false, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },
        { ruleId: "supply.guild.maxPerDay", label: "Guild chat: at most this many purchase requests per day", valueType: "number", value: 2, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 0, max: 20 } },
        { ruleId: "supply.guild.everyMin", label: "Guild chat: at most one purchase request per ... minutes", valueType: "number", value: 120, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 15, max: 1440 } },
        { ruleId: "supply.forecast.on", label: "Forecast: a stock that runs out within the horizon is short, also without an order (resources and star items)", valueType: "bool", value: false, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.77 (ADR 0088)
        { ruleId: "supply.forecast.horizonHours", label: "Forecast: horizon in hours", valueType: "number", value: 48, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 1, max: 336 } },   // 0.2.77
        { ruleId: "supply.forecast.windowHours", label: "Forecast: measure the consumption over the last ... hours", valueType: "number", value: 6, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS", allowedRange: { min: 1, max: 36 } },   // 0.2.77
        { ruleId: "supply.adventure.on", label: "Short resource: name the adventure in the star that yields it (for the adventure manager)", valueType: "bool", value: true, ownerPbc: "resource-supply-manager", arsSlot: "ASSESS" },   // 0.2.77
        { ruleId: "trade.rt.ask.on", label: "Ask the guild for a round trade myself (both trades net to zero)", valueType: "bool", value: false, ownerPbc: "trade-acceptor", arsSlot: "EVENT" },
        { ruleId: "trade.rt.ask.everyMin", label: "Ask a round trade at most once per ... minutes", valueType: "number", value: 120, ownerPbc: "trade-acceptor", arsSlot: "EVENT", allowedRange: { min: 15, max: 1440 } },
        { ruleId: "trade.rt.ask.maxPerDay", label: "Ask a round trade at most this many times per day", valueType: "number", value: 2, ownerPbc: "trade-acceptor", arsSlot: "EVENT", allowedRange: { min: 0, max: 20 } },
        { ruleId: "help.t1.perDay", label: "Level below 30: times per day", valueType: "number", value: 6, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 50 } },
        { ruleId: "help.t1.perWeek", label: "Level below 30: times per week", valueType: "number", value: 42, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 350 } },
        { ruleId: "help.t1.max", label: "Level below 30: max amount per request", valueType: "number", value: 40000, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000 } },
        { ruleId: "help.t2.perDay", label: "Level 30-59: times per day", valueType: "number", value: 4, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 50 } },
        { ruleId: "help.t2.perWeek", label: "Level 30-59: times per week", valueType: "number", value: 28, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 350 } },
        { ruleId: "help.t2.max", label: "Level 30-59: max amount per request", valueType: "number", value: 20000, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000 } },
        { ruleId: "help.t3.perDay", label: "Level 60-79: times per day", valueType: "number", value: 2, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 50 } },
        { ruleId: "help.t3.perWeek", label: "Level 60-79: times per week", valueType: "number", value: 14, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 350 } },
        { ruleId: "help.t3.max", label: "Level 60-79: max amount per request", valueType: "number", value: 10000, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000 } },
        { ruleId: "help.t4.perDay", label: "Level 80+: times per day", valueType: "number", value: 1, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 50 } },
        { ruleId: "help.t4.perWeek", label: "Level 80+: times per week", valueType: "number", value: 2, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 350 } },
        { ruleId: "help.t4.max", label: "Level 80+: max amount per request", valueType: "number", value: 4000, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000 } },
        { ruleId: "help.perHourPlayer", label: "Requests per player per hour", valueType: "number", value: 1, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 10 } },
        { ruleId: "help.floor", label: "Keep at least this much of a resource in stock", valueType: "number", value: 100000, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 2000000 } },
        { ruleId: "help.floorPct", label: "Never give more than this % of the stock in one gift", valueType: "number", value: 20, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 100 } },
        { ruleId: "help.smallPct", label: "A small gift is always allowed: up to this % of the stock", valueType: "number", value: 1, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 0, max: 10 } },
        { ruleId: "help.plentyPct", label: "Plenty: storage at least this % full — given without the level limits", valueType: "number", value: 90, ownerPbc: "helper", arsSlot: "ASSESS", allowedRange: { min: 50, max: 101 } },
        { ruleId: "help.costRes", label: "The receiver pays (resource)", valueType: "text", value: "Fish", ownerPbc: "helper", arsSlot: "RESPONSE" },
        { ruleId: "help.costAmount", label: "The receiver pays (amount)", valueType: "number", value: 1, ownerPbc: "helper", arsSlot: "RESPONSE", allowedRange: { min: 1, max: 100 } },
        { ruleId: "star.perDay", label: "Star trades per player per day", valueType: "number", value: 2, ownerPbc: "star-trader", arsSlot: "ASSESS", allowedRange: { min: 0, max: 20 } },
        { ruleId: "star.waitHours", label: "Star trade: hours the other player has to accept both trades", valueType: "number", value: 24, ownerPbc: "star-trader", arsSlot: "ASSESS", allowedRange: { min: 1, max: 168 } },
        { ruleId: "star.returnCostMax", label: "Star trade return: accept when it costs at most", valueType: "number", value: 10, ownerPbc: "star-trader", arsSlot: "ASSESS", allowedRange: { min: 1, max: 1000 } },
        { ruleId: "chat.words", label: "Chat reply word (comma separated for several)", valueType: "text", value: "", ownerPbc: "chat-watcher", arsSlot: "EVENT" },
        { ruleId: "safety.settingsMustStayClean", label: "Decline if settings.json grows", valueType: "bool", value: true, ownerPbc: "dma-control", arsSlot: "ASSESS" }
    ];
    (function () {
        var i;
        for (i = 0; i < SWITCHES.length; i++) {
            RULES.push({ ruleId: SWITCHES[i].key, label: SWITCHES[i].label, valueType: "bool", value: SWITCHES[i].dflt === true, ownerPbc: SWITCHES[i].actor, arsSlot: "EVENT" });
        }
    })();
    (function () {   // 0.2.74 (ADR 0084): the workflow Deposit Cycling, per resource; off by default
        var WFR = { BronzeOre: "copper", IronOre: "iron", GoldOre: "gold", Coal: "coal", TitaniumOre: "titanium", Salpeter: "saltpetre" }, r, n, o = "workflow-deposit-cycling";
        for (r in WFR) {
            if (!WFR.hasOwnProperty(r)) continue; n = "Deposit cycling (" + WFR[r] + "): ";
            RULES.push({ ruleId: "workflow.dc." + r + ".on", label: n + "on", valueType: "bool", value: false, ownerPbc: o, arsSlot: "EVENT" });
            RULES.push({ ruleId: "workflow.dc." + r + ".start", label: n + "start: when your mine on a spot runs empty or is demolished, or now (demolish your mine on the spot at once)", valueType: "choice", allowed: ["empty", "now"], value: "empty", ownerPbc: o, arsSlot: "ASSESS" });   // 0.2.75
            RULES.push({ ruleId: "workflow.dc." + r + ".grids", label: n + "the spots (grids from the location list)", valueType: "set", value: [], ownerPbc: o, arsSlot: "ASSESS" });
            RULES.push({ ruleId: "workflow.dc." + r + ".geoTypes", label: n + "geologist types (type numbers)", valueType: "set", value: [], ownerPbc: o, arsSlot: "ASSESS" });
            RULES.push({ ruleId: "workflow.dc." + r + ".geoCount", label: n + "at most this many geologists (0 = all of those types)", valueType: "number", value: 0, ownerPbc: o, arsSlot: "ASSESS", allowedRange: { min: 0, max: 100 } });
            RULES.push({ ruleId: "workflow.dc." + r + ".keepFree", label: n + "build-queue places kept free for regular building", valueType: "number", value: 1, ownerPbc: o, arsSlot: "ASSESS", allowedRange: { min: 0, max: 10 } });
            RULES.push({ ruleId: "workflow.dc." + r + ".reserve.on", label: n + "stop while a build-cost good is below the reserve", valueType: "bool", value: true, ownerPbc: o, arsSlot: "ASSESS" });
            RULES.push({ ruleId: "workflow.dc." + r + ".reserve", label: n + "reserve: keep at least this much of every good of the build cost", valueType: "number", value: 1000, ownerPbc: o, arsSlot: "ASSESS", allowedRange: { min: 0, max: 1000000 } });
        }
    })();

    function defaults() {
        var out = {};
        var i, r;
        for (i = 0; i < RULES.length; i++) out[RULES[i].ruleId] = RULES[i].value;
        for (i = 0; i < CATALOG_R.length; i++) {
            r = CATALOG_R[i];
            out["location.caps." + r] = DEFAULT_CAPS[r];
            out["building.upgradeLevel." + r] = 0;   // 0.2.70 (UAT F2): no target until the player sets one (0 = "—" in the console)
            out["buff.name." + r] = "SmokedFishSteak";
            out["search.preferredType." + r] = "";
        }
        out["buff.defaultName"] = "SmokedFishSteak";
        return out;
    }

    /* 0.2.59: the bool a player's value means, or null */
    function boolOf(v) {
        if (v === true || v === false) return v;
        var t = String(v == null ? "" : v).trim().toLowerCase();
        if (t === "true" || t === "on" || t === "yes" || t === "1") return true;
        if (t === "false" || t === "off" || t === "no" || t === "0") return false;
        return null;
    }
    function meta(ruleId) {
        var i;
        for (i = 0; i < RULES.length; i++) if (RULES[i].ruleId === ruleId) return RULES[i];
        if (ruleId.indexOf("location.caps.") === 0) {
            return { ruleId: ruleId, label: "Cap " + ruleId.slice(14), valueType: "number", ownerPbc: "pbc.location-management", arsSlot: "ASSESS", allowedRange: { min: 0, max: 99 } };
        }
        if (ruleId.indexOf("building.upgradeLevel.") === 0) {
            return { ruleId: ruleId, label: "Upgrade max " + ruleId.slice(22), valueType: "number", ownerPbc: "pbc.building-management", arsSlot: "ASSESS", allowedRange: { min: 0, max: 8 } };
        }
        if (ruleId.indexOf("buff.name.") === 0) {
            return { ruleId: ruleId, label: "Buff " + ruleId.slice(10), valueType: "enum", ownerPbc: "pbc.buff-management", arsSlot: "ASSESS" };
        }
        if (ruleId === "buff.defaultName") {
            return { ruleId: ruleId, label: "Default buff", valueType: "enum", ownerPbc: "pbc.buff-management", arsSlot: "ASSESS" };
        }
        if (ruleId === "search.preferredType" || ruleId.indexOf("search.preferredType.") === 0) {
            return { ruleId: ruleId, label: "Preferred geo", valueType: "enum", ownerPbc: "pbc.geologist-search", arsSlot: "ASSESS" };
        }
        if (ruleId.indexOf("location.label.") === 0) {
            return { ruleId: ruleId, label: "Slot label", valueType: "enum", ownerPbc: "pbc.location-management", arsSlot: "ASSESS" };
        }
        if (ruleId.indexOf("location.slot.") === 0) {
            return { ruleId: ruleId, label: "Slot grid", valueType: "enum", ownerPbc: "pbc.location-management", arsSlot: "ASSESS" };
        }
        if (ruleId === "buff.prefs") {
            return { ruleId: ruleId, label: "Buff per building type", valueType: "object", ownerPbc: "buff-manager", arsSlot: "ASSESS" };
        }
        if (ruleId.indexOf("rule.") === 0 && ruleId.split(".").length === 3) {
            return { ruleId: ruleId, label: "Rule setting " + ruleId.slice(5), valueType: "scalar", ownerPbc: "green", arsSlot: "ASSESS" };
        }
        if (ruleId === "control.sendIntervalMs") {
            return { ruleId: ruleId, label: "Pace of server actions (ms)", valueType: "number", ownerPbc: "dma-control", arsSlot: "ASSESS", allowedRange: { min: 500, max: 10000 } };
        }
        if (ruleId === "control.sendIntervalMinMs") {
            return { ruleId: ruleId, label: "Fastest pace of server actions (ms)", valueType: "number", ownerPbc: "dma-control", arsSlot: "ASSESS", allowedRange: { min: 300, max: 10000 } };
        }
        if (/^event\.[a-z0-9]+\.buff\.on$/.test(ruleId)) {   // 0.2.25
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": buff its buildings (event buff switch)", valueType: "bool", ownerPbc: "event-manager", arsSlot: "ASSESS", factType: "AT73" };
        }
        if (/^event\.[a-z0-9]+\.buff\.exclude$/.test(ruleId)) {   // 0.2.25
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": buffs not to use", valueType: "object", ownerPbc: "event-manager", arsSlot: "ASSESS" };
        }
        if (/^event\.[a-z0-9]+\.fill\.on$/.test(ruleId)) {   // 0.2.60 (v3.16 D-5): was matched as a counter below
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": fill its buildings (fill switch)", valueType: "bool", ownerPbc: "event-manager", arsSlot: "ASSESS", factType: "AT74" };
        }
        if (/^event\.[a-z0-9]+\.fill\.rateX$/.test(ruleId)) {   // 0.2.60 (v3.16 D-5): was not registered
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": fill rate (times the event's base rate)", valueType: "number", ownerPbc: "event-manager", arsSlot: "ASSESS", factType: "AT75", allowedRange: { min: 0, max: 100 } };
        }
        if (/^unit\.[A-Za-z0-9_]+\.targetStrength$/.test(ruleId)) {   // 0.2.63 (v3.17 T-1): UNIT POLICY, target strength (AT79)
            return { ruleId: ruleId, label: ruleId.split(".")[1] + ": target strength (units)", valueType: "number", ownerPbc: "troop-manager", arsSlot: "ASSESS", factType: "AT79", allowedRange: { min: 0, max: 1000000 } };
        }
        if (/^ctype\.[A-Za-z0-9_]+\.targetLevel$/.test(ruleId)) {   // 0.2.60 (v3.16 D-4): construction type policy
            return { ruleId: ruleId, label: ruleId.split(".")[1] + ": target level", valueType: "number", ownerPbc: "construction-manager", arsSlot: "ASSESS", factType: "AT70", allowedRange: { min: 0, max: 20 } };
        }
        if (/^ctype\.[A-Za-z0-9_]+\.buffKind$/.test(ruleId)) {   // 0.2.60 (v3.16 D-4)
            return { ruleId: ruleId, label: ruleId.split(".")[1] + ": buff kind", valueType: "text", ownerPbc: "construction-manager", arsSlot: "ASSESS", factType: "AT71", maxLength: 80 };
        }
        if (/^event\.[a-z0-9]+\.[a-z0-9]+\.on$/.test(ruleId) && !/\.buff\.on$/.test(ruleId)) {   // 0.2.27 counters
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": " + ruleId.split(".")[2] + " counter on", valueType: "bool", ownerPbc: "event-manager", arsSlot: "ASSESS" };
        }
        if (/^event\.[a-z0-9]+\.[a-z0-9]+\.(when|give)$/.test(ruleId)) {   // 0.2.27 counters
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": " + ruleId.split(".")[2] + " counter " + ruleId.split(".")[3], valueType: "text", ownerPbc: "event-manager", arsSlot: "ASSESS" };
        }
        if (/^event\.[a-z0-9]+\.gameNames$/.test(ruleId)) {   // 0.2.26
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": game event names that count (prefixes, comma separated)", valueType: "text", ownerPbc: "event-manager", arsSlot: "ASSESS" };
        }
        if (/^event\.[a-z0-9]+\.buffable$/.test(ruleId)) {   // 0.2.24
            return { ruleId: ruleId, label: "Event " + ruleId.split(".")[1] + ": seconds per unit of its buildings", valueType: "object", ownerPbc: "event-manager", arsSlot: "ASSESS" };
        }
        if (ruleId === "spec.use") {   // 0.2.53 (ADR 0058): per specialist "first" (skill before use); absent = use until the books are there
            return { ruleId: ruleId, label: "Specialists: skill first before use (per specialist)", valueType: "object", ownerPbc: "specialist-manager", arsSlot: "ASSESS" };
        }
        if (/^spec\.(expo|geo|gen)\.(skill|name|prefix|suffix|renameScope|renameAllConfirmedAt)$/.test(ruleId)) {   // 0.2.53 (ADR 0058)
            return { ruleId: ruleId, label: "Specialists (" + ruleId.split(".")[1] + "): " + ruleId.split(".")[2], valueType: "text", ownerPbc: "specialist-manager", arsSlot: "ASSESS" };
        }
        if (/^spec\.(expo|geo|gen)\.skillStandard$/.test(ruleId)) {   // 0.2.53 (ADR 0058)
            return { ruleId: ruleId, label: "Specialists (" + ruleId.split(".")[1] + "): follow the online standard", valueType: "bool", ownerPbc: "specialist-manager", arsSlot: "ASSESS" };
        }
        if (/^console\.troops\.(normal|elite|expedition)\.show$/.test(ruleId)) {   // 0.2.65: console view preference
            return { ruleId: ruleId, label: "TROOPS page: show the " + ruleId.split(".")[2] + " troops", valueType: "bool", ownerPbc: "console", arsSlot: "ASSESS" };
        }
        if (ruleId === "expo.prefs") {
            return { ruleId: ruleId, label: "Explorer task per type", valueType: "object", ownerPbc: "specialist-manager/expo", arsSlot: "ASSESS" };
        }
        return null;
    }

    function create() {
        var values = defaults();
        var started = false;
        var last = null;
        var STORE_KEY = "DMA_PLAYER_POLICY";

        function durableSlice() {
            var o = {}, k;
            for (k in values) {
                if (!values.hasOwnProperty(k)) continue;
                if (k.indexOf("obs.") === 0) continue;
                o[k] = values[k];
            }
            return o;
        }

        /* ---------- file persistence (AIR): the only store that survives a client restart ---------- */
        var FILE_NAME = "dma-policy.json";
        var STAND_NAME = "dma-stand.json";
        function appFile(name) {
            try {
                var A = (typeof air !== "undefined") ? air : (root && root.air);
                if (!A || !A.File || !A.File.applicationDirectory) return null;
                return new A.File(A.File.applicationDirectory.resolvePath(name).nativePath);
            } catch (_) { return null; }
        }
        function readJson(name) {
            try {
                var A = (typeof air !== "undefined") ? air : root.air;
                var f = appFile(name);
                if (!f || !f.exists) return null;
                var st = new A.FileStream();
                st.open(f, A.FileMode.READ);
                var txt = st.readUTFBytes(st.bytesAvailable);
                st.close();
                return JSON.parse(txt);
            } catch (_) { return null; }
        }
        var lastIoError = null;
        function writeJson(name, obj) {
            try {
                var A = (typeof air !== "undefined") ? air : root.air;
                var f = appFile(name);
                if (!f) return false;
                var st = new A.FileStream();
                st.open(f, A.FileMode.WRITE);
                st.writeUTFBytes(JSON.stringify(obj, null, 1));
                st.close();
                return true;
            } catch (e) { lastIoError = name + ": " + String(e); return false; }   // 0.2.40
        }
        /* 0.2.38: written at once. The 1 s timer of 0.2.4 left fileTimer set when its callback never ran in the client,
           and from then on no change reached the file (dma-policy.json stayed at 2026-10-30 14:21 while the player kept
           changing rules). */
        var lastFileWrite = null;
        function persistFile() {
            lastFileWrite = writeJson(FILE_NAME, { format: "dma-policy/1", savedAt: new Date().toISOString(), policy: durableSlice() }) ? new Date().toISOString() : "failed";
        }
        function journal(entry) {
            try {
                var A = (typeof air !== "undefined") ? air : root.air, f = appFile("dma-policy-changes.jsonl"); if (!A || !f) return;
                var st = new A.FileStream(); st.open(f, A.FileMode.APPEND); st.writeUTFBytes(JSON.stringify(entry) + "\n"); st.close();
            } catch (e) { lastIoError = "journal: " + String(e); }
        }

        function persist() {
            var payload = durableSlice();
            persistFile();
            try {
                if (typeof DM_IsolatedSettings !== "undefined" && DM_IsolatedSettings && typeof DM_IsolatedSettings.store === "function") {
                    DM_IsolatedSettings.store(STORE_KEY, payload);
                }
            } catch (_) {}
            try {
                if (typeof window !== "undefined") window.__GCAF_POLICY_MEM__ = payload;
                else if (typeof root !== "undefined") root.__GCAF_POLICY_MEM__ = payload;
            } catch (_) {}
            try {
                if (typeof localStorage !== "undefined" && localStorage) {
                    localStorage.setItem("dma.playerPolicy.v1", JSON.stringify(payload));
                }
            } catch (_) {}
        }

        /* 0.1.x stored switches in a side store and under legacy keys; fold both into the switch keys once. */
        function migrateSwitches(saved) {
            var k, nk;
            if (saved["loot.auto"] !== undefined && saved["mail.auto"] === undefined) saved["mail.auto"] = saved["loot.auto"] === true;   // 0.2.9
            for (k in RETIRED) if (RETIRED.hasOwnProperty(k)) delete saved[k];   // 0.2.61
            if (saved["premium.autoExtend"] !== undefined) { if (saved["premium.setting"] === undefined) saved["premium.setting"] = boolOf(saved["premium.autoExtend"]) === true ? "always" : "off"; delete saved["premium.autoExtend"]; }   // 0.2.60
            for (k in saved) if (saved.hasOwnProperty(k) && k.indexOf("building.upgradeLevel.") === 0) {   // 0.2.60: per-building target levels -> construction type policy
                nk = k.slice(22);
                if (CATALOG_R.indexOf(nk) < 0 && /^[A-Za-z0-9_]+$/.test(nk) && saved["ctype." + nk + ".targetLevel"] === undefined) saved["ctype." + nk + ".targetLevel"] = Number(saved[k]) || 0;
            }
            // 0.2.58: the 0.2.48 line that set event.auto = true where it was missing is removed (review 2026-11-16 #12)
            if (saved["loot.toStorage"] !== undefined && saved["mail.loot.toStorage"] === undefined) saved["mail.loot.toStorage"] = saved["loot.toStorage"] === true;
            delete saved["loot.auto"]; delete saved["loot.toStorage"];
            if (saved["help.auto"] !== undefined && saved["trade.help.on"] === undefined) saved["trade.help.on"] = saved["help.auto"] === true;   // 0.2.13
            if (saved["star.auto"] !== undefined && saved["trade.star.on"] === undefined) saved["trade.star.on"] = saved["star.auto"] === true;
            delete saved["help.auto"]; delete saved["star.auto"];
            for (k in LEGACY_SWITCH) {
                if (!LEGACY_SWITCH.hasOwnProperty(k)) continue;
                nk = LEGACY_SWITCH[k];
                if (saved[k] !== undefined && saved[nk] === undefined) saved[nk] = saved[k] === true;
                delete saved[k];
            }
            var lsOld = ["pls, plz, please, me", "pls, plz, please, me, yes, yup, yep, ya, ja, +"];   // 0.2.44: earlier defaults
            if (lsOld.indexOf(saved["adv.ls.requestWords"]) >= 0) saved["adv.ls.requestWords"] = "pls, plz, please, me, yes, yup, yep, ya, ja, +, i can, take one";
            delete saved["control.allowExecute"];
            delete saved["control.cycleRunning"];
            delete saved["search.autoEnabled"];
            try {
                if (typeof localStorage === "undefined" || !localStorage) return;
                var raw = localStorage.getItem("dma.switches");
                if (!raw) return;
                var sw = JSON.parse(raw) || {};
                for (k in sw) {
                    if (!sw.hasOwnProperty(k)) continue;
                    nk = LEGACY_SWITCH[k] || k;
                    if (isSwitch(nk)) saved[nk] = sw[k] === true || sw[k] === "true";
                }
                localStorage.removeItem("dma.switches");
                localStorage.removeItem("dma.cycleRunning");
            } catch (_) {}
        }

        function restore() {
            var saved = {};
            function take(obj) {
                var k;
                if (!obj || typeof obj !== "object") return;
                for (k in obj) {
                    if (!obj.hasOwnProperty(k) || String(k).indexOf("obs.") === 0) continue;
                    saved[k] = obj[k];
                }
            }
            var fromFile = readJson(FILE_NAME);
            if (!fromFile) {
                /* first start on file persistence: player settings from the stand file, never its switches */
                var stand = readJson(STAND_NAME);
                var sp = stand && (stand.policy || stand);
                if (sp && typeof sp === "object") {
                    var sk0, keep = {};
                    for (sk0 in sp) {
                        if (!sp.hasOwnProperty(sk0)) continue;
                        if (/^(location\.caps\.|building\.upgradeLevel\.|buff\.name\.|buff\.defaultName$|location\.label\.|location\.slot\.|search\.preferredType|demolish\.threshold$)/.test(sk0)) keep[sk0] = sp[sk0];
                    }
                    take(keep);
                }
            }
            try {
                if (typeof localStorage !== "undefined" && localStorage) {
                    var rawSession = localStorage.getItem("dma.playerPolicy.v1");
                    if (rawSession) take(JSON.parse(rawSession));
                }
            } catch (_) {}
            if (fromFile) take(fromFile.policy || fromFile);
            try { take(root.DMA_POLICY_FILE || (typeof window !== "undefined" && window.DMA_POLICY_FILE)); } catch (_) {}
            migrateSwitches(saved);
            var nk = 0, sk;
            for (sk in saved) { if (saved.hasOwnProperty(sk)) nk += 1; }
            if (nk < 1) return;
            var k;
            for (k in saved) {
                if (saved.hasOwnProperty(k)) values[k] = saved[k];
            }
        }
        restore();
        (function () { var i, r, b; for (i = 0; i < RULES.length; i++) { r = RULES[i]; if (r.valueType !== "bool" || typeof values[r.ruleId] !== "string") continue; b = boolOf(values[r.ruleId]); if (b !== null) values[r.ruleId] = b; } })();   // 0.2.59
        var cr, design;
        for (cr in DEFAULT_CAPS) {
            if (!DEFAULT_CAPS.hasOwnProperty(cr)) continue;
            design = DEFAULT_CAPS[cr];
            if (Number(values["location.caps." + cr] || 0) < design) {
                values["location.caps." + cr] = design;
            }
        }
        persist();

        function canon(ruleId) {
            ruleId = String(ruleId);
            if (isSwitch(ruleId)) return ruleId;
            if (LEGACY_SWITCH[ruleId]) return LEGACY_SWITCH[ruleId];
            var map = {
                inPlayOnly: "search.inPlayOnly",
                threshold: "demolish.threshold",
                defaultBuff: "buff.defaultName"
            };
            if (map[ruleId]) return map[ruleId];
            if (ruleId.indexOf("cap.") === 0) return "location.caps." + ruleId.slice(4);
            if (ruleId.indexOf("upg.") === 0) return "building.upgradeLevel." + ruleId.slice(4);
            if (ruleId.indexOf("buff.") === 0 && ruleId.indexOf("buff.name.") !== 0 && ruleId !== "buff.autoEnabled" && ruleId !== "buff.defaultName") {
                return "buff.name." + ruleId.slice(5);
            }
            if (ruleId.indexOf("geo.") === 0) return "search.preferredType." + ruleId.slice(4);
            return ruleId;
        }

        function requestChange(ruleId, value) {
            var incoming = ruleId;
            if (RETIRED[ruleId]) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "retired-rule" }); return last = { fact: "dc", reason: "retired-rule", ruleId: ruleId, why: RETIRED[ruleId] }; }   // 0.2.61
            if (ruleId === "premium.autoExtend") {   // 0.2.60: the legacy boolean writes the premium setting
                var pb = boolOf(value); if (pb === null) return last = { fact: "dc", reason: "value-not-bool", ruleId: ruleId };
                ruleId = "premium.setting"; value = pb ? "always" : "off";
            }
            ruleId = canon(ruleId);
            if (incoming.indexOf("upg.") === 0 && (value === true || value === false || value === "true" || value === "false")) {
                value = (value === true || value === "true") ? 5 : 0;
            }
            if (!started) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "not-started" }); return last = { fact: "dc", reason: "not-started" }; }
            var m = meta(ruleId);
            if (!m) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "unknown-rule" }); return last = { fact: "dc", reason: "unknown-rule", ruleId: ruleId }; }
            var unitKindChecked = null, uk = /^unit\.([A-Za-z0-9_]+)\.targetStrength$/.exec(ruleId);   // 0.2.64: a misspelled unit kind
            if (uk && Number(value) !== 0) {
                var known = null; try { var UI = root.DMA_UnitInputs; known = UI && typeof UI.all === "function" ? Object.keys(UI.all() || {}) : null; } catch (_) { known = null; }
                if (known && known.length) {
                    if (known.indexOf(uk[1]) < 0) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "unknown-unit-kind" }); return last = { fact: "dc", reason: "unknown-unit-kind", ruleId: ruleId, known: known.sort() }; }
                    unitKindChecked = true;
                } else unitKindChecked = false;
            }
            if (m.valueType === "bool") {   // 0.2.59: no "ac" for a value that is not stored as given
                var bv = boolOf(value);
                if (bv === null) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "value-not-bool" }); return last = { fact: "dc", reason: "value-not-bool", ruleId: ruleId }; }
                value = bv;
            }
            if (m.valueType === "choice") {   // 0.2.60
                value = String(value == null ? "" : value).trim().toLowerCase();
                if ((m.allowed || []).indexOf(value) < 0) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "value-not-allowed" }); return last = { fact: "dc", reason: "value-not-allowed", ruleId: ruleId, allowed: (m.allowed || []).slice() }; }
            }
            if (m.valueType === "text") value = String(value == null ? "" : value).replace(/[\u0000-\u001f]/g, " ").slice(0, Number(m.maxLength) > 0 ? Number(m.maxLength) : 120);   // 0.2.4; 0.2.28: maxLength per rule
            if (m.valueType === "object" && (value === null || typeof value !== "object")) return last = { fact: "dc", reason: "value-not-object" };
            if (m.valueType === "set") {   // 0.2.73: a list of names; a comma-separated text is accepted
                if (typeof value === "string") value = value.split(",");
                if (!value || typeof value.length !== "number") return last = { fact: "dc", reason: "value-not-list" };
                var sv = [], si; for (si = 0; si < value.length; si++) { var nm = String(value[si] == null ? "" : value[si]).trim(); if (nm && sv.indexOf(nm) < 0) sv.push(nm); }
                value = sv;
                if (m.exclusive) {   // 0.2.80: choices that exclude each other (the game's exclusivity groups) cannot be combined
                    var ex = null; try { ex = root.DMA_Adventure && typeof root.DMA_Adventure.exclusive === "function" ? root.DMA_Adventure.exclusive(value) : null; } catch (_) { ex = null; }
                    if (ex && ex.ok === false) { journal({ at: new Date().toISOString(), rule: ruleId, fact: "dc", reason: "exclusive" }); return last = { fact: "dc", reason: "exclusive", ruleId: ruleId, why: ex.conflict.join(" and ") + " exclude each other" }; }
                }
            }
            if (m.valueType === "scalar") {
                if (value === "true" || value === "false") value = value === "true";
                else if (value !== true && value !== false) { value = Number(value); if (isNaN(value)) return last = { fact: "dc", reason: "value-not-scalar" }; }
            }
            if (m.valueType === "number") {
                if (value === "" || value === null || typeof value === "undefined") value = null;
                else {
                    value = Number(value);
                    if (isNaN(value)) return last = { fact: "dc", reason: "value-out-of-range" };
                    if (m.allowedRange) {
                        if (value < m.allowedRange.min || value > m.allowedRange.max) {
                            return last = { fact: "dc", reason: "value-out-of-range" };
                        }
                    }
                }
            }
            values[ruleId] = value;
            last = { fact: "ac", ruleId: ruleId, value: value };
            if (unitKindChecked !== null) last.unitKindChecked = unitKindChecked;   // 0.2.64
            persist();
            journal({ at: new Date().toISOString(), rule: ruleId, fact: "ac", value: value, file: lastFileWrite });   // 0.2.38
            return last;
        }

        function projectFor(pbcId) {
            var out = {};
            var k, m;
            for (k in values) {
                if (!values.hasOwnProperty(k)) continue;
                m = meta(k);
                if (!m || m.ownerPbc === pbcId || (pbcId === "pbc.location-management" && k.indexOf("location.caps.") === 0)) {
                    out[k] = values[k];
                }
                if (pbcId === "pbc.geologist-search" && k.indexOf("location.caps.") === 0) out[k] = values[k];
                if (pbcId === "pbc.geologist-search" && k.indexOf("search.") === 0) out[k] = values[k];
            }
            return out;
        }

        function bumpObs(key, n) {
            n = Number(n);
            if (isNaN(n) || n < 0) return;
            var cur = Number(values[key]);
            if (isNaN(cur) || n > cur) values[key] = n;
        }

        function observeScan(snap) {
            snap = snap || {};
            var i, b, d, r, name, lvl;
            var deposits = snap.deposits || [];
            var buildings = snap.buildings || [];
            var counts = (snap.counts && snap.counts.depositAll) || {};
            for (r in counts) {
                if (counts.hasOwnProperty(r)) bumpObs("obs.depositCount." + r, counts[r]);
            }
            for (i = 0; i < deposits.length; i++) {
                d = deposits[i];
                if (d && d.name) bumpObs("obs.depositCount." + d.name, null);
            }
            var mineByR = {};
            for (i = 0; i < buildings.length; i++) {
                b = buildings[i] || {};
                name = b.name || "";
                lvl = b.uiLevel != null ? b.uiLevel : b.level;
                if (lvl != null) bumpObs("obs.maxLevel." + name, lvl);
                if (b.upgradeAllowed === false && lvl != null) bumpObs("obs.maxLevel." + name, lvl);
            }
            var depAll = (snap.counts && snap.counts.buildingAll) || {};
            for (name in depAll) {
                if (!depAll.hasOwnProperty(name)) continue;
                bumpObs("obs.buildingCount." + name, depAll[name]);
            }
            last = { fact: "ac", ruleId: "observeScan", at: snap.scannedAt || null };
            return last;
        }

        function effectiveCap(r) {
            var authored = Number(values["location.caps." + r]);
            var seenDep = Number(values["obs.depositCount." + r] || 0);
            var seenBld = 0;
            var k;
            for (k in values) {
                if (k.indexOf("obs.buildingCount.") === 0 && values[k]) {
                    /* floor only; mapping name→R is Location's job when it calls with pre-aggregated mines */
                }
            }
            if (values["obs.mines." + r] != null) seenBld = Number(values["obs.mines." + r]);
            var floor = Math.max(seenDep || 0, seenBld || 0);
            if (isNaN(authored)) authored = floor;
            return Math.max(authored, floor);
        }

        function effectiveUpgradeMax(buildingName) {
            var seen = Number(values["obs.maxLevel." + buildingName] || 0);
            var authored = 6;
            return Math.max(authored, seen);
        }

        function caps() {
            var c = {};
            var i, r;
            for (i = 0; i < CATALOG_R.length; i++) {
                r = CATALOG_R[i];
                c[r] = effectiveCap(r);
            }
            return c;
        }

        return {
            id: ID, name: NAME, version: VERSION,
            catalogR: CATALOG_R,
            load: function () { restore(); return true; },
            reload: function () { restore(); return true; },
            start: function () { started = true; return true; },
            stop: function () { started = false; return true; },
            getStatus: function () {
                return { id: ID, name: NAME, version: VERSION, started: started, last: last };
            },
            diag: function () { return { version: VERSION, started: started, lastFileWrite: lastFileWrite, lastIoError: lastIoError, last: last }; },   // 0.2.40
            getPolicy: function () {
                var out = JSON.parse(JSON.stringify(values));
                var lk;
                for (lk in LEGACY_SWITCH) {
                    if (LEGACY_SWITCH.hasOwnProperty(lk)) out[lk] = values[LEGACY_SWITCH[lk]] === true;
                }
                out.inPlayOnly = values["search.inPlayOnly"];
                out.allowExecute = true;
                out["control.allowExecute"] = true;
                out["control.cycleRunning"] = true;
                out.threshold = values["demolish.threshold"];
                out.defaultBuff = values["buff.defaultName"];
                var i, r;
                for (i = 0; i < CATALOG_R.length; i++) {
                    r = CATALOG_R[i];
                    out["cap." + r] = values["location.caps." + r];
                    out["upg." + r] = Number(values["building.upgradeLevel." + r] || 0);
                    out["buff." + r] = values["buff.name." + r];
                    out["geo." + r] = values["search.preferredType." + r] || values["search.preferredType"] || "";
                }
                out["search.preferredType"] = values["search.preferredType"] || "";
                return out;
            },
            get: function (ruleId) {
                if (ALWAYS_TRUE[ruleId]) return true;
                if (RETIRED[ruleId]) return false;   // 0.2.61
                if (ruleId === "premium.autoExtend") return values["premium.setting"] === "always";   // 0.2.60: legacy read
                var c = canon(ruleId);
                if (isSwitch(c)) return values[c] === true;
                return values[c] !== undefined ? values[c] : values[ruleId];
            },
            switches: function () {
                var i, out = [], s;
                for (i = 0; i < SWITCHES.length; i++) {
                    s = SWITCHES[i];
                    out.push({ key: s.key, short: s.short, label: s.label, actor: s.actor, initiates: s.initiates, needs: s.needs.slice(), title: s.title, on: values[s.key] === true });
                }
                return out;
            },
            getRulesFor: function (pbcId, slot) {
                var i, m, out = [];
                for (i = 0; i < RULES.length; i++) {
                    m = RULES[i];
                    if (pbcId && m.ownerPbc !== pbcId) continue;
                    if (slot && m.arsSlot !== slot) continue;
                    out.push({ ruleId: m.ruleId, label: m.label, arsSlot: m.arsSlot, ownerPbc: m.ownerPbc, value: values[m.ruleId] });
                }
                return out;
            },
            unitPolicies: function () {   // 0.2.63 (v3.17 T-1): { unit kind: target strength > 0 }
                var out = {}, k, m;
                for (k in values) if (values.hasOwnProperty(k) && (m = /^unit\.([A-Za-z0-9_]+)\.targetStrength$/.exec(k)) && Number(values[k]) > 0) out[m[1]] = Number(values[k]);
                return out;
            },
            entries: function (patterns) {   // 0.2.52
                var res = (patterns || []).map(function (p) { try { return new RegExp(p); } catch (_) { return null; } }).filter(function (r) { return !!r; });
                function hit(id) { for (var j = 0; j < res.length; j++) if (res[j].test(id)) return true; return false; }
                var out = [], seen = {}, i, m, k;
                for (i = 0; i < RULES.length; i++) { m = RULES[i]; if (!hit(m.ruleId)) continue; seen[m.ruleId] = true; out.push({ ruleId: m.ruleId, label: m.label, arsSlot: m.arsSlot, factType: m.factType || "", value: values[m.ruleId] !== undefined ? values[m.ruleId] : m.value }); }
                for (k in values) if (values.hasOwnProperty(k) && !seen[k] && hit(k)) { var dm = meta(k) || {}; out.push({ ruleId: k, label: dm.label || "", arsSlot: dm.arsSlot || "", factType: dm.factType || "", value: values[k] }); }   // 0.2.60: factType
                out.sort(function (a, b) { return a.ruleId < b.ruleId ? -1 : a.ruleId > b.ruleId ? 1 : 0; });
                return out;
            },
            requestChange: requestChange,
            projectFor: projectFor,
            caps: caps,
            observeScan: observeScan,
            effectiveCap: effectiveCap,
            effectiveUpgradeMax: effectiveUpgradeMax,
            compareDesignToRuntime: function () {
                return [{ rules: Object.keys(values).length, last: last }];
            }
        };
    }

    var api = { id: ID, name: NAME, version: VERSION, create: create, RULES: RULES, SWITCHES: SWITCHES };
    root.GCAF_PlayerPolicy = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
