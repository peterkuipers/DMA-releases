/*
 * G-CAF SOL OS — Loot Spot Granting (application PBC)  user_dma_lootspots.js
 *
 * DEMO: one transaction kind, TK "loot spot granting" (docs/06-adventures/gunpowder-loot-spots.md):
 *   initiator = a guild member, executor = us (the host of the adventure).
 *   rq  the member asks ("pls") after our offer in the guild chat
 *   pm  we invite him and say so in the guild chat            (dc: no spot left -> he is not invited)
 *   ex  he accepts the invitation and makes a kill on our adventure
 *   da  he reports the kill in the adventure chat ("kd")
 *   ac  we close the adventure once every promised spot has declared
 *   revoke of the request (he withdraws): before pm -> confirmed, dropped; after pm while the invitation is pending ->
 *   confirmed, invitation cancelled, the next requester is invited; after he accepted -> confirmed, we no longer wait
 *   for his kill and close when the others have declared.
 * This PBC remembers only loot-spot facts (one case per member and adventure). It reaches the game through the
 * gateway it is given (chat lines, sayLs, invite, cancel invitation, the adventure's player list).
 *
 * 0.1.0 (2026-10-31, author: "voor alle ls adventures bepaal je bovenaan 1 keer, hoe je uitnodigt, hoe je dat
 *   bevestigt, of twee tegelijkertijd, of 1 en tevens aangeven dat er nog 1 open staat, dan een maximale tijd om te
 *   wachten. 2 minuten voor verstrijken van die tijd een last call, als je mensen hebt uitgenodigd duidelijk aangeven
 *   dat ze een kill moeten maken en dit melden in de adv chat en dat wij afsluiten. Als tussendoor een verzoek wordt
 *   ingetrokken, bevestig je dat en cancel je de uitnodiging als dat nog mogelijk is en nodig je iemand anders uit,
 *   zo niet dan wacht je niet op die persoon zijn kill en sluit je af wanneer de anderen de kill hebben gemaakt." —
 *   "demo patroon").
 * 0.1.9 (2026-11-09, author: "Ja" — repair what the TX page showed: 11 TK19 instances of this morning's GP runs still
 *   open): a case ends in the book when we close. A spot invited but not reported is revoke promise + allow (tacit)
 *   and then DECLINE ("closed before the kill"): the revocation alone put it back to requested, open for ever. A request
 *   still waiting when we close is declined ("we close"). abandon(snapshot, why): the same closing for the cases of a
 *   loot-spot snapshot whose run ended without closing (a client restart; called by the adventure runner).
 *   Unit: tests/unit/dma-lootspots-close.test.js; integration: live, the TX page holds no TK19 of a finished GP run.
 * 0.1.8 (2026-11-02, live: the client did not load 0.1.7 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.1.7 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   the loot-spot cases are recorded as C-facts (TK19 "loot spot granting", one instance per member and offer, case
 *   ls:<adv>@<offer ms>:<member>), so the C-fact memory knows them like every other kind: request (member) -> promise
 *   (invited) | decline (no spot left, invite failed) -> execute (he accepted the invitation) -> declare (kill reported,
 *   seen in the game, or he left after accepting) -> accept (we close). A withdrawal (confirmed, or the invitation
 *   declined) is revoke request + allow; a spot that did not report when the kill wait ended is revoke promise + allow
 *   (tacit). Behaviour and chat texts unchanged.
 *   Unit: dma-lootspots.test.js (the C-facts of a GP round); tests/unit/dma-demo4-acts.test.js.
 * 0.1.6 (2026-11-01, test day proposals P1/P7; author: "Voer alle verbeteringen maar door"):
 *   - the kill wait runs per player from the moment he accepted (or was invited, if he never accepts), not from the end
 *     of the request wait (live: SettlingNippster accepted 07:52 and we closed 07:56 "did not report");
 *   - a kill is also seen in the game: G.guestGenerals(zone) -> {name: busyCount}; a guest whose general was busy on
 *     our adventure and is idle again (the attack is through) counts as declared ("fought on the island"); the
 *     adventure chat is often missing in the game ("no addy chat here");
 *   - "kd" counts from any channel (guild, adventure, whisper), as before;
 *   - opts.restore: a snapshot (state()) taken before a restart continues the case without a new offer.
 *   Unit: dma-lootspots.test.js (per-player kill wait, a guest's attack counts, restore skips the offer).
 * 0.1.5 (2026-10-31, author: "the withdrawing of a request has to be verified, so after that ask the question; {name}
 *   do I understand correct you cancel your ls? A acknowledgement of that, or no reaction in {n} minutes, leads to
 *   cancellation of the invite."): a revoke word opens a question (textRevokeAsk); yes (or another revoke word) or no
 *   answer within revokeConfirmMin -> the withdrawal is carried out; no -> the spot stays.
 * 0.1.4 (2026-10-31, live: "hij sluit niet af" — the kill was reported before our invitation; the report was not
 *   counted): every report since the offer counts for a promised spot.
 * 0.1.3 (2026-10-31, author: "hij begrijpt yuup niet"): letters said longer count (yuup = yup, plsss = pls); the
 *   default request words add yes, yup, yep, ya, ja, +.
 * 0.1.2 (2026-10-31, live GP: SettlingNippster accepted, made her kill and closed without "kd" — "Peter, I already
 *   closed"): a player who accepted and then left the adventure counts as done; we do not wait for his report.
 * 0.1.1 (2026-10-31, live: GP closed without loot spots because the chat could not send right after a restart): the
 *   offer is retried for 3 minutes; failing that, the case ends with failed = true (the run keeps the adventure open).
 *   Unit expectation:        tests/unit/dma-lootspots.test.js — together and one-by-one, last call, a revoke before
 *                            and after acceptance, the kill wait ends when every remaining promise has declared.
 *   Integration expectation: a Gunpowder arrows run offers, invites, announces, waits for kd and closes.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.9";

    var DEFAULTS = {
        "adv.ls.inviteMode": "together", "adv.ls.waitMin": 5, "adv.ls.lastCallMin": 2, "adv.ls.killWaitMin": 15,
        "adv.ls.textOffer": "{n}x ls {adv}", "adv.ls.textLastCall": "last call: {n}x ls {adv}",
        "adv.ls.textInvited": "{names} invited, make a kill and report it in the adv chat, we close after the kills",
        "adv.ls.textInvitedOne": "{name} invited, make a kill and report it in the adv chat, we close after the kills. {open}x ls {adv} still open",
        "adv.ls.textRevoked": "{name}: ok, your spot is withdrawn",
        "adv.ls.requestWords": "pls, plz, please, me, yes, yup, yep, ya, ja, +",
        "adv.ls.revokeWords": "cancel, nvm, never mind, cant, can't, have to go, gotta go, out",
        "adv.ls.declareWords": "kd, done, killed",
        "adv.ls.textRevokeAsk": "{name}, do I understand correctly that you cancel your ls?",
        "adv.ls.revokeConfirmMin": 2,
        "adv.ls.yesWords": "yes, yup, yep, ya, ja, correct, indeed, right, ok, sure, y",
        "adv.ls.noWords": "no, nope, nee, not, nah, n, stay, keep"
    };
    function words(s) { return String(s || "").split(/\s*,\s*/).filter(Boolean); }
    /* 0.1.3 (author: "hij begrijpt yuup niet"): letters said longer still count — "yuup" = "yup", "plsss" = "pls",
       "pleeease" = "please": every letter of a word may repeat */
    function stretch(w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/([a-z])/gi, "$1+"); }
    function wordRe(list) { return new RegExp("(^|[^a-z0-9'])(" + list.map(stretch).join("|") + ")([^a-z0-9']|$)", "i"); }
    function wordReOld(list) { return new RegExp("(^|[^a-z0-9'])(" + list.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|") + ")([^a-z0-9']|$)", "i"); }
    function fill(t, o) { var k; t = String(t); for (k in o) if (o.hasOwnProperty(k)) t = t.split("{" + k + "}").join(String(o[k])); return t; }

    /* opts: { n, adv (short name, e.g. "GP"), zone, texts: {offer, invited} learned overrides }
       G:    { now, say(text) -> {ok}, chatSince(at) -> [{at, sender, text, channel}], ownName(), rule(k, d),
               invite(name, zone) -> {ok}, cancelInvite(name, zone) -> {ok}, players(zone) -> {name: status 0 pending/1 accepted/...},
               log(m) } */
    function create(opts, G) {
        function rule(k) { var d = DEFAULTS[k]; try { var v = G.rule(k, d); return v == null || v === "" ? d : v; } catch (_) { return d; } }
        var ls = { n: Number(opts.n) || 0, adv: opts.adv || "", zone: opts.zone, state: "OFFER", since: G.now(), seenAt: 0, offerAt: 0,
                   cases: [], lastCall: false, log: [], done: false, result: "" };
        if (opts.restore && opts.restore.state && opts.restore.state !== "OFFER" && !opts.restore.done) {   // 0.1.6 (P7)
            ls = JSON.parse(JSON.stringify(opts.restore)); ls.log = (ls.log || []).slice(-20);
        }
        function cf(c, act, extra) {   // 0.1.7: TK19 C-facts, one instance per member and offer
            try { var o = { tk: "TK19", act: act, caseId: "ls:" + ls.adv + "@" + ls.offerAt + ":" + c.who, member: c.who, actor: "host" }, k; for (k in (extra || {})) o[k] = extra[k]; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
        }
        function withdrawn(c, why) { cf(c, "revoke request", { actor: c.who, reason: why }); cf(c, "allow", { actor: "host" }); }
        function say(m) { ls.log.push(new Date(G.now()).toISOString().slice(11, 19) + " " + m); if (ls.log.length > 40) ls.log.shift(); try { G.log("ls: " + m); } catch (_) {} }
        function post(t) { var r = G.say(t); if (!r || !r.ok) say("not posted: " + ((r && r.reason) || "?") + " — " + t); else say("posted: " + t); return r && r.ok; }
        function go(st, m) { ls.state = st; ls.since = G.now(); if (m) say(m); }
        function late(ms) { return G.now() - ls.since > ms; }
        function caseOf(name) { var w = String(name).toLowerCase(); return ls.cases.filter(function (c) { return c.who.toLowerCase() === w; })[0] || null; }
        function promised() { return ls.cases.filter(function (c) { return c.st === "pm" || c.st === "ex" || c.st === "da"; }); }
        function open() { return ls.n - promised().length; }
        function waiting() { return ls.cases.filter(function (c) { return c.st === "rq"; }); }
        function invite(c) {
            var r = G.invite(c.who, ls.zone);
            if (!r || !r.ok) { c.st = "dc"; say("invite " + c.who + " failed: " + ((r && r.reason) || "?")); cf(c, "decline", { reason: "invite failed: " + ((r && r.reason) || "?") }); return false; }
            c.st = "pm"; c.at = G.now(); cf(c, "promise", { reason: "invited" }); return true;
        }
        function announce(list) {
            if (!list.length) return;
            if (String(rule("adv.ls.inviteMode")) === "one by one" && open() > 0)
                post(fill(rule("adv.ls.textInvitedOne"), { name: list.join(" and "), open: open(), adv: ls.adv, n: open() }));
            else post(fill(opts.texts && opts.texts.invited ? opts.texts.invited : rule("adv.ls.textInvited"), { names: list.join(" and "), adv: ls.adv }));
        }
        /* the chat since the last look: requests, revokes, declared kills */
        function read() {
            var reqRe = wordRe(words(rule("adv.ls.requestWords"))), revRe = wordRe(words(rule("adv.ls.revokeWords"))), decRe = wordRe(words(rule("adv.ls.declareWords")));
            var own = String(G.ownName() || "").toLowerCase(), lines = G.chatSince(Math.max(ls.offerAt, ls.seenAt));
            lines.forEach(function (l) {
                ls.seenAt = Math.max(ls.seenAt, l.at);
                var who = String(l.sender || ""), c = caseOf(who); if (!who || who.toLowerCase() === own) return;
                /* 0.1.5 (author: "the withdrawing of a request has to be verified ... {name} do I understand correct you cancel
                   your ls? A acknowledgement of that, or no reaction in {n} minutes, leads to cancellation of the invite") */
                if (c && c.ask && c.ask.open) {
                    if (wordRe(words(rule("adv.ls.noWords"))).test(l.text)) { c.ask.open = false; say(c.who + " keeps the spot"); return; }
                    if (wordRe(words(rule("adv.ls.yesWords"))).test(l.text) || revRe.test(l.text)) { c.ask.open = false; revoke(c); return; }
                }
                if (c && revRe.test(l.text) && ["rq", "pm", "ex"].indexOf(c.st) >= 0 && !(c.ask && c.ask.open)) { askRevoke(c); return; }
                if (c && decRe.test(l.text) && (c.st === "pm" || c.st === "ex")) { c.st = "da"; say(who + " reported the kill"); cf(c, "declare", { actor: c.who, reason: "kill reported" }); return; }
                if (!c && l.channel === "guild" && reqRe.test(l.text) && ls.state !== "KILLS_ONLY") { var nc = { who: who, st: "rq", at: l.at }; ls.cases.push(nc); say(who + " asks for a spot"); cf(nc, "request", { actor: who, text: String(l.text || "").slice(0, 100) }); }
            });
            /* 0.1.4 (live: RiddarBengt reported "kd ty" before our invitation reached the KILLS phase, the run waited for a
               report it had already seen): a promised spot also counts every report since the offer */
            G.chatSince(ls.offerAt).forEach(function (l) { var c2 = caseOf(l.sender); if (c2 && (c2.st === "pm" || c2.st === "ex") && decRe.test(l.text)) { c2.st = "da"; say(c2.who + " reported the kill"); cf(c2, "declare", { actor: c2.who, reason: "kill reported" }); } });
            var gg = {}; try { gg = G.guestGenerals ? (G.guestGenerals(ls.zone) || {}) : {}; } catch (_) { gg = {}; }   // 0.1.6: kills seen in the game
            ls.cases.forEach(function (c) {
                if (c.st !== "pm" && c.st !== "ex") return;
                var k, b = null; for (k in gg) if (gg.hasOwnProperty(k) && k.toLowerCase() === c.who.toLowerCase()) b = gg[k];
                if (b > 0) c.sawBusy = true;
                else if (c.sawBusy && b === 0) { c.st = "da"; say(c.who + " fought on the island: counted as the kill"); cf(c, "declare", { actor: c.who + " (observed)", reason: "fought on the island" }); }
            });
            var pl = G.players ? G.players(ls.zone) : {};   // accepted invitations: execution under way
            ls.cases.forEach(function (c) { var s = pl[c.who]; if (c.st === "pm" && s === 1) { c.st = "ex"; c.acceptedAt = G.now(); say(c.who + " accepted"); cf(c, "execute", { actor: c.who, reason: "accepted the invitation" }); } if (c.st === "pm" && (s === 2 || s === 3)) { c.st = "rv"; say(c.who + " declined or left"); withdrawn(c, "declined the invitation or left"); }
                if (c.st === "ex" && (s === 3 || s === undefined)) { c.st = "da"; say(c.who + " left the adventure after accepting: counted as done"); cf(c, "declare", { actor: c.who + " (observed)", reason: "left after accepting" }); } });   // 0.1.2 (live: "Peter, I already closed")
        }
        function askRevoke(c) {
            c.ask = { open: true, at: G.now() };
            post(fill(rule("adv.ls.textRevokeAsk"), { name: c.who, adv: ls.adv, n: rule("adv.ls.revokeConfirmMin") }));
        }
        function askTimeouts() {   // no reaction within the minutes: the withdrawal stands
            var ms = Number(rule("adv.ls.revokeConfirmMin")) * 60000;
            ls.cases.forEach(function (c) { if (c.ask && c.ask.open && G.now() - c.ask.at >= ms) { c.ask.open = false; say(c.who + " did not answer: the withdrawal stands"); revoke(c); } });
        }
        function revoke(c) {
            var was = c.st;
            post(fill(rule("adv.ls.textRevoked"), { name: c.who, adv: ls.adv }));
            if (was === "rq") { c.st = "rv"; withdrawn(c, "withdrew the request"); return; }
            if (was === "pm") {   // invitation still pending: cancel it, the spot goes to the next requester
                var r = G.cancelInvite ? G.cancelInvite(c.who, ls.zone) : null;
                if (r && r.ok) { c.st = "rv"; say(c.who + ": invitation cancelled"); withdrawn(c, "withdrew; invitation cancelled"); fillSpots(); return; }
                c.st = "rv-late"; say(c.who + ": invitation could not be cancelled; not waiting for a kill"); withdrawn(c, "withdrew; the invitation could not be cancelled"); return;
            }
            c.st = "rv-late"; say(c.who + " accepted already; not waiting for the kill"); withdrawn(c, "withdrew after accepting");   // after acceptance
        }
        function fillSpots() {   // the next requesters get the free spots
            var newly = [];
            waiting().forEach(function (c) { if (open() > 0 && invite(c)) newly.push(c.who); });
            ls.cases.forEach(function (c) { if (c.st === "rq" && open() <= 0) { c.st = "dc"; cf(c, "decline", { reason: "no spot left" }); } });
            announce(newly);
            if (newly.length && open() > 0 && ls.state === "COLLECT") say(open() + " spot(s) still open");
            return newly;
        }
        function closeCases(why) { closeAll(ls, why); }   // 0.1.7; 0.1.9: one closing for a run and for an abandoned snapshot
        function tick() {
            if (ls.done) return ls.state;
            switch (ls.state) {
            case "OFFER":
                if (ls.n <= 0) { ls.done = true; ls.result = "no spots"; return go("DONE", "no loot spots"); }
                ls.offerAt = Date.now(); ls.seenAt = ls.offerAt;
                /* 0.1.1 (live: after a restart the chat could not send yet; the run closed GP without loot spots): retry for
                   3 minutes; then fail — the adventure run stops and leaves the adventure open for the player */
                if (!post(fill(opts.texts && opts.texts.offer ? opts.texts.offer : rule("adv.ls.textOffer"), { n: ls.n, adv: ls.adv }))) {
                    if (G.now() - ls.since < 180000) return ls.state;
                    ls.done = true; ls.failed = true; ls.result = "offer not posted"; return go("DONE");
                }
                return go("COLLECT");
            case "COLLECT": {
                read(); askTimeouts();
                var mode = String(rule("adv.ls.inviteMode")), waitMs = Number(rule("adv.ls.waitMin")) * 60000, lcMs = Number(rule("adv.ls.lastCallMin")) * 60000;
                if (mode === "one by one") fillSpots();
                else if (waiting().length >= open() && open() > 0) fillSpots();
                if (open() <= 0) return go("KILLS", "all " + ls.n + " spots promised");
                if (!ls.lastCall && lcMs > 0 && late(waitMs - lcMs)) { ls.lastCall = true; post(fill(rule("adv.ls.textLastCall"), { n: open(), adv: ls.adv })); }
                if (late(waitMs)) {
                    if (mode !== "one by one") fillSpots();   // together: whoever asked gets a spot now
                    if (!promised().length) { ls.done = true; ls.result = "nobody asked"; return go("DONE", "nobody asked within " + rule("adv.ls.waitMin") + " min"); }
                    return go("KILLS", promised().length + " of " + ls.n + " spots promised; the wait is over");
                }
                return ls.state;
            }
            case "KILLS": {
                read(); askTimeouts();
                if (waiting().length && open() > 0) fillSpots();   // a revoked spot went to the next requester
                var wait = ls.cases.filter(function (c) { return c.st === "pm" || c.st === "ex" || (c.ask && c.ask.open); });
                if (!wait.length) { ls.done = true; ls.result = "kills reported"; closeCases(); return go("DONE", "every remaining spot reported the kill; we close"); }
                /* 0.1.6 (P1): per player, from his acceptance (else his invitation, else the start of this phase) */
                var killMs = Number(rule("adv.ls.killWaitMin")) * 60000;
                var still = wait.filter(function (c) { if (c.ask && c.ask.open) return true; var from = c.acceptedAt || c.at || ls.since; return G.now() - Math.max(from, ls.since) < killMs; });
                if (!still.length) { ls.done = true; ls.result = "kill wait over"; closeCases("kill wait over"); return go("DONE", "kill wait over (" + wait.map(function (c) { return c.who; }).join(", ") + " did not report); we close"); }
                return ls.state;
            }
            }
            return ls.state;
        }
        return { tick: tick, state: function () { return JSON.parse(JSON.stringify(ls)); }, done: function () { return ls.done; }, failed: function () { return !!ls.failed; } };
    }

    /* 0.1.9: we close — reported spots accepted; invited but silent ones: revoke promise, allow, decline; waiting requests declined */
    function closeAll(ls, why) {
        function cf(c, act, extra) {
            try { var o = { tk: "TK19", act: act, caseId: "ls:" + ls.adv + "@" + ls.offerAt + ":" + c.who, member: c.who, actor: "host" }, k; for (k in (extra || {})) o[k] = extra[k]; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
        }
        (ls.cases || []).forEach(function (c) {
            if (c.st === "da") { cf(c, "accept", { actor: "host", reason: "we close" }); c.st = "ac"; }
            else if (c.st === "pm" || c.st === "ex") { cf(c, "revoke promise", { actor: "host", reason: why || "we close" }); cf(c, "allow", { actor: c.who + " (tacit)" }); cf(c, "decline", { actor: "host", reason: "closed before the kill" }); c.st = "dc"; }
            else if (c.st === "rq") { cf(c, "decline", { actor: "host", reason: why || "we close" }); c.st = "dc"; }
        });
    }
    function abandon(snapshot, why) { if (!snapshot || snapshot.done) return 0; var n = (snapshot.cases || []).filter(function (c) { return c.st === "da" || c.st === "pm" || c.st === "ex" || c.st === "rq"; }).length; closeAll(snapshot, why || "the run ended without closing"); snapshot.done = true; return n; }
    root.DMA_LootSpots = { version: VERSION, create: create, DEFAULTS: DEFAULTS, abandon: abandon };
})(typeof window !== "undefined" ? window : this);
