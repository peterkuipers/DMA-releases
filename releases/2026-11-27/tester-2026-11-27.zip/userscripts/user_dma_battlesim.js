/*
 * user_dma_battlesim.js 0.1.3 (2026-11-22, ADR 0094): the simulator moves from docs/06-adventures/tactical/battlesim.js into
 *   the pack, unchanged in its rules, so the Mundane generator (user_dma_mundane_gen.js) can simulate the player's own generals
 *   in the client. The old path re-exports this file, so the repository tools (search.js, mundane.js, validate.js, the
 *   series planner) keep working. In the client it registers window.DMA_BattleSim; the facts it needs (unit-stats) are
 *   passed in by the caller.
 *   Unit: tests/unit/dma-battlesim.test.js (unchanged expectations, now on this file). Integration: tests/integration/
 *   dma-mundane-gen-bb.test.js loads it in a vm context as the client does.
 * battlesim.js 0.1.2 (2026-11-07) — our own battle simulator for The Settlers Online's classic combat (tactical advisor
 * phase 2, README.md). Plain JS (Node CLI and module; ES5-style so it can later run inside the client too).
 *
 * Facts and their source (ADR 0042): every unit stat, general base value and skill effect comes from
 * data/unit-stats.json, written by the client probe src/tools/user_dma_probe_units.js (the game's own unit
 * descriptions, specialist descriptions and skill definitions). Nothing about units is typed in here.
 * The modifier arithmetic follows the client's MilitarySystem::cSquad (read from client.swf): adders first, then
 * multipliers relative to the base (applyDamageMultiplier), accuracy adder -> multiplier -> replace, capped 0..100,
 * unit HP = base + adders + (int(base * m) - base), at least 1.
 *
 * The battle rules (the server decides them; the client only replays results) are the model under test. They are
 * named switches in RULES so each one can be checked against tsowiki's per-battle losses (validate.js):
 *   - a battle is rounds; a round is three initiative phases: first strike, normal, last strike;
 *   - in a phase every living squad of both sides with that initiative attacks; casualties count from the phase start
 *     (units killed in the phase still strike in it) and are applied at the phase end;
 *   - each unit rolls 1..100: <= accuracy hits for max damage, else min damage;
 *   - targets: the enemy squads in ascending combat priority (sequencePrio); a flanking unit (attack weakest target)
 *     takes the squad with the lowest unit HP first; a squad's front unit keeps its wounds between attacks and rounds;
 *   - without splash one attack hits one unit and the excess is lost; with splash the excess runs on to the next units;
 *   - the defender is beaten as soon as nothing of it is left; the attacker is beaten at the end of a round in which
 *     only its general (or nothing) is left — the general retreats; a general at 0 HP ends the battle as lost;
 *   - zone buffs (0.1.1): opts.zoneMods, the combat modifiers of the zone's active buffs (ZoneBuffManager.
 *     getActiveCombatModifiers_vector; facts in data/unit-stats.json combatBuffs), join the general's for both sides —
 *     the client's cArmy.AddCombatModifiersToSquads applies one list with the same side and type rules;
 *   - 0.1.2: RULES.endAttackerPerPhase (see there): live decoys wiped by first strike kill nothing; tsowiki's corpus
 *     disagrees, so it is a switch the planners turn on (templates/TPotM/plan-2026-11-07.md).
 *   - battle frenzy: +adder % damage per round after the first; double attack: the general strikes twice.
 */
(function (root) {
    "use strict";

    var RULES = {
        targetOrder: "prio",          // targets in ascending sequencePrio; flanking units take the lowest unit HP first
        simultaneous: true,           // both sides strike in a phase; kills fall at the phase end (validated 99.6 %; false: 46.8 %)
        generalTargetable: false,     // false: enemy units never strike the general (his HP plays no part)
        endAttackerWhenOnlyGeneral: true,
        generalFightsBossAlone: false,
        endAttackerPerPhase: false,   // 0.1.2 switch: true = the attacker is beaten at the end of the PHASE in which only his
                                      // general is left ("first" = only after the first-strike phase). Live 2026-11-07: Recruit
                                      // decoys wiped by first strike killed nothing (10 of 11 recorded decoy battles match with
                                      // true, 8 with false). tsowiki corpus: false 99.7 %, true 94.4 %, "first" 94.1 %.
                                      // Default stays false; planners set true for decoys (the cautious reading).// true would let the general fight a lone boss on (fits Tropical Sun, breaks Looming Danger)
        frenzyFromRound: 2,
        maxRounds: 500
    };
    var PHASES = 3;                   // 0 first strike, 1 normal, 2 last strike

    function applyMult(base, cur, m) { var s = Math.floor(base * 1000 * (m * 1000) / 1000000); return m > 1 ? cur + s - base : Math.floor(cur * 1000 * (m * 1000) / 1000000); }

    /* ---------- facts from the probe file ---------- */
    function Facts(stats) {
        var self = this;
        this.units = {}; this.skills = {}; this.specialists = {}; this.generalOfType = {};
        (stats.units || []).forEach(function (u) { self.units[u.type] = u; });
        (stats.skills || []).forEach(function (s) { self.skills[s.name.replace(/^Skill_/, "")] = s; self.skills["#" + s.id] = s; });
        (stats.skillTrees || []).forEach(function (t) { t.items.forEach(function (s) { var k = s.name.replace(/^Skill_/, ""); if (!self.skills[k]) self.skills[k] = s; if (!self.skills["#" + s.id]) self.skills["#" + s.id] = s; }); });
        (stats.specialists || []).forEach(function (s) { self.specialists[s.name] = s; });
        this.version = stats.client;
    }
    Facts.prototype.unit = function (type) { var u = this.units[type]; if (!u) throw new Error("unknown unit " + type); return u; };
    // the modifiers a general brings into battle: his skills {name: level} plus his kind's traits
    Facts.prototype.generalModifiers = function (kind, skills) {
        var out = [], self = this, sp = this.specialists[kind];
        Object.keys(skills || {}).forEach(function (k) {
            var lv = skills[k], s = self.skills[k.replace(/^Skill_/, "")];
            if (!s || !lv) return;
            (s.levels[Math.min(lv, s.levels.length) - 1] || []).forEach(function (m) { out.push(m); });
        });
        if (sp && sp.traits) sp.traits.forEach(function (t) { var s = self.skills["#" + t[0]]; if (s && s.levels[t[1] - 1]) s.levels[t[1] - 1].forEach(function (m) { out.push(m); }); });
        return out;
    };
    Facts.prototype.capacity = function (kind, skills) {
        var sp = this.specialists[kind], cap = sp ? sp.maxUnits : 0;
        this.generalModifiers(kind, skills).forEach(function (m) { if (/unitcapacity/i.test(m.modifier)) cap += m.adder; });
        return cap;
    };

    /* ---------- a squad with its modifiers applied ---------- */
    function modsFor(mods, u, side) {
        return mods.filter(function (m) {
            if (!/^combatmodifier$/i.test(m.modifier)) return false;
            var n = (m.name || "").toLowerCase();
            var sideOk = !n || (n === "player" && (side === "att")) || (n === "enemy" && side === "def" && !u.specialist);
            var typeOk = !m.type || m.type.toLowerCase() === u.type.toLowerCase() || (u.combatantType && m.type.toLowerCase() === u.combatantType.toLowerCase());
            return sideOk && typeOk;
        });
    }
    function byItem(ms, item) { return ms.filter(function (m) { return (m.item || "").toLowerCase() === item.toLowerCase(); }); }
    function makeSquad(facts, type, n, mods, side, isGeneral) {
        var u = facts.unit(type), ms = modsFor(mods, u, side), sk = {};
        (u.skills || []).forEach(function (s) { sk[s[0]] = s[1]; });
        var hp = u.hp, maxD = u.maxDamage, minD = u.minDamage, acc = u.accuracy;
        byItem(ms, "UnitHP").forEach(function (m) { if (m.adder > 0) hp += m.adder; });
        byItem(ms, "UnitHP").forEach(function (m) { if (m.multiplier !== 1) hp += Math.floor(u.hp * m.multiplier) - u.hp; });
        hp = Math.max(1, hp);
        byItem(ms, "MaxAttackDamage").forEach(function (m) { maxD += m.adder; });
        byItem(ms, "MaxAttackDamage").forEach(function (m) { if (m.multiplier !== 1) maxD = applyMult(u.maxDamage, maxD, m.multiplier); });
        byItem(ms, "MinAttackDamage").forEach(function (m) { minD += m.adder; });
        byItem(ms, "MinAttackDamage").forEach(function (m) { if (m.multiplier !== 1) minD = applyMult(u.minDamage, minD, m.multiplier); });
        var accMs = byItem(ms, "Accuracy");
        accMs.forEach(function (m) { if (m.rules !== "replace") acc += m.adder; });
        accMs.forEach(function (m) { if (m.rules !== "replace") acc *= m.multiplier; });
        accMs.forEach(function (m) { if (m.rules === "replace") acc = m.value; });
        acc = Math.min(100, Math.max(0, acc));
        var totAdd = 0, totMul = [];
        byItem(ms, "TotalDamage").forEach(function (m) { if (m.adder > 0) totAdd += m.adder; if (m.multiplier !== 1) totMul.push(m.multiplier); });
        var splash = sk[3] !== undefined || byItem(ms, "GainSkill_Splash").length > 0 || byItem(ms, "AddSplash").length > 0;
        var flank = (sk[2] !== undefined || byItem(ms, "AddFlanking").length > 0 || byItem(ms, "GainSkill_Flanking").length > 0) && byItem(ms, "LoseSkill_Flanking").length === 0 && byItem(ms, "LoseFlanking").length === 0;
        var frenzy = 0; byItem(ms, "BattleFrenzy").forEach(function (m) { frenzy += m.adder; });
        return { type: type, n: n, n0: n, dead: 0, pend: 0, hp: hp, front: hp, acc: acc, maxD: Math.max(0, maxD), minD: Math.max(0, minD),
                 bonusUnits: sk[1] || 0, totAdd: totAdd, totMul: totMul, prio: u.sequencePrio, init: sk[5] !== undefined ? 0 : (sk[6] !== undefined ? 2 : 1),
                 splash: splash, flank: flank, frenzy: frenzy, general: !!isGeneral, twice: isGeneral && byItem(ms, "DoubleAttack").length > 0,
                 boss: u.combatantType === "Boss" || !!u.boss, canAttack: u.canAttack !== false, attackable: u.attackable !== false, side: side };
    }

    /* ---------- the battle ---------- */
    function rng(seed) { var s = seed >>> 0 || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }

    function unitDamage(sq, round, r) {
        var d = (Math.floor(r() * 100) + 1) <= sq.acc ? sq.maxD : sq.minD, base = d;
        if (sq.bonusUnits) d = Math.floor(d + base * sq.bonusUnits / 100);
        d += sq.totAdd;
        for (var i = 0; i < sq.totMul.length; i++) d = applyMult(base, d, sq.totMul[i]);
        if (sq.frenzy && round >= RULES.frenzyFromRound) d = Math.floor(d * (1 + sq.frenzy * (round - 1) / 100));
        return Math.max(0, d);
    }
    function targetList(enemy, flank) {
        var t = enemy.filter(function (s) { return s.attackable && (RULES.generalTargetable || !s.general); });
        t.sort(flank ? function (a, b) { return a.hp - b.hp || a.prio - b.prio; } : function (a, b) { return a.prio - b.prio; });
        return t;
    }
    function hit(targets, d, splash) {
        for (var i = 0; i < targets.length && d > 0; i++) {
            var t = targets[i];
            while (d > 0 && t.n - t.pend > 0) {
                if (d >= t.front) { d -= t.front; t.pend++; t.front = t.hp; if (!splash) return; }
                else { t.front -= d; return; }
            }
        }
    }
    function settle(side) { side.forEach(function (s) { if (s.pend) { s.n -= s.pend; s.dead += s.pend; s.pend = 0; if (s.n <= 0) { s.n = 0; s.front = s.hp; } } }); }
    function alive(side, withGeneral) { for (var i = 0; i < side.length; i++) if (side[i].n > 0 && (withGeneral || !side[i].general)) return true; return false; }

    // att, def: arrays of squads (makeSquad). Returns {win, rounds, lost: {type: n}, defLost: {type: n}}.
    function fight(att, def, r) {
        var round = 0, win = null;
        att.sort(function (a, b) { return a.prio - b.prio; }); def.sort(function (a, b) { return a.prio - b.prio; });   // strike order: combat priority
        var tA = { 0: targetList(def, false), 1: targetList(def, true) }, tD = { 0: targetList(att, false), 1: targetList(att, true) };
        while (win === null && round < RULES.maxRounds) {
            round++;
            for (var ph = 0; ph < PHASES && win === null; ph++) {
                [[att, tA], [def, tD]].forEach(function (pair) {
                    var side = pair[0], tl = pair[1];
                    for (var i = 0; i < side.length; i++) {
                        var sq = side[i]; if (sq.init !== ph || sq.n <= 0 || !sq.canAttack) continue;
                        var targets = tl[sq.flank ? 1 : 0], times = sq.twice ? 2 : 1;
                        for (var k = 0; k < sq.n * times; k++) hit(targets, unitDamage(sq, round, r), sq.splash);
                    }
                    if (!RULES.simultaneous) settle(side === att ? def : att);
                });
                settle(att); settle(def);
                if (!alive(def, true)) win = true;
                else if (att.some(function (s) { return s.general && s.n <= 0; })) win = false;
                else if (RULES.endAttackerPerPhase && (RULES.endAttackerPerPhase !== "first" || ph === 0) && !alive(att, false) && (!RULES.generalFightsBossAlone || def.some(function (s) { return s.n > 0 && !s.boss; }))) win = false;
            }
            if (win === null && (RULES.endAttackerWhenOnlyGeneral ? !alive(att, false) && (!RULES.generalFightsBossAlone || def.some(function (s) { return s.n > 0 && !s.boss; })) : !alive(att, true))) win = false;
        }
        var lost = {}, defLost = {};
        att.forEach(function (s) { if (!s.general) lost[s.type] = (lost[s.type] || 0) + s.dead; });
        def.forEach(function (s) { defLost[s.type] = (defLost[s.type] || 0) + s.dead; });
        return { win: !!win, rounds: round, lost: lost, defLost: defLost, defLeft: def.map(function (s) { return [s.type, s.n, s.front]; }) };
    }

    // One battle: general {kind, skills}, units {type: n}, enemy [[type, n] or {type: n}], opts {iterations, seed}.
    // Returns per unit type {min, max, avg} of the attacker's losses, per enemy type the same, and the win rate.
    function simulate(facts, general, units, enemy, opts) {
        opts = opts || {}; var N = opts.iterations || 200, r = rng(opts.seed || 12345), res = { win: 0, lost: {}, defLost: {}, rounds: { min: 1e9, max: 0, avg: 0 } };
        var mods = facts.generalModifiers(general.kind, general.skills).concat(opts.zoneMods || []), eList = Array.isArray(enemy) ? enemy : Object.keys(enemy).map(function (k) { return [k, enemy[k]]; });
        var gType = (facts.specialists[general.kind] || {}).militaryUnitType || general.kind;
        for (var it = 0; it < N; it++) {
            var att = [makeSquad(facts, gType, 1, mods, "att", true)];
            Object.keys(units).forEach(function (t) { if (units[t] > 0) att.push(makeSquad(facts, t, units[t], mods, "att", false)); });
            var def = eList.filter(function (e) { return e[1] > 0; }).map(function (e) { var s = makeSquad(facts, e[0], e[1], mods, "def", false); if (e[2]) s.front = e[2]; return s; });
            var o = fight(att, def, r);
            if (o.win) res.win++;
            [["lost", o.lost], ["defLost", o.defLost]].forEach(function (p) {
                Object.keys(p[1]).forEach(function (t) { var a = res[p[0]][t] || (res[p[0]][t] = { min: 1e9, max: 0, sum: 0 }); a.min = Math.min(a.min, p[1][t]); a.max = Math.max(a.max, p[1][t]); a.sum += p[1][t]; });
            });
            res.rounds.min = Math.min(res.rounds.min, o.rounds); res.rounds.max = Math.max(res.rounds.max, o.rounds); res.rounds.avg += o.rounds / N;
            if (opts.keepLast) res.last = o;
        }
        ["lost", "defLost"].forEach(function (k) { Object.keys(res[k]).forEach(function (t) { var a = res[k][t]; a.avg = a.sum / N; delete a.sum; }); });
        res.win /= N;
        return res;
    }

    var api = { RULES: RULES, Facts: Facts, makeSquad: makeSquad, fight: fight, simulate: simulate, rng: rng, VERSION: "0.1.3" };
    if (typeof module !== "undefined" && module.exports) module.exports = api; else root.DMA_BattleSim = api;
})(typeof window !== "undefined" ? window : this);
