/*
 * 00_dma_window.js — Window role (kernel; ADR 0051) 0.1.0
 * 0.1.0 (2026-11-08, author: "voor het laatste adventure ga je multi windows uitproberen en dus het thuis eiland op orde
 *   houden tijdens het avontuur"): with the client's experimental multi-window option on, visiting an adventure starts a
 *   second client process (index.html runNewApplication) that sets the global expZone and loads every userscript again.
 *   Two copies of every DMA manager on one account and one set of files froze the client on 10-26 and 10-27
 *   (docs/04-testing/restore-plan-2026-10-27.md). This module decides the window's role before any other userscript loads:
 *   - home (expZone == null): nothing changes; it only offers DMA_WINDOW.advAlive() so others can see an adventure window.
 *   - adventure (expZone set): every userscript outside ADV_ALLOW is switched off for this load (the client's own
 *     enabledScripts switch, checked per file inside reloadScripts; jQuery 3.6 loads script src synchronously, so this
 *     file, sorted first, runs before the loop reaches the others). The switches are restored right after the loop, so
 *     a settings save in that window never writes them to the shared settings.json. The window gets a read-only policy
 *     (dma-policy.json, re-read every 60 s) instead of the policy PBC, which writes its file at start. It writes a
 *     heartbeat dma-window-adv.json every 30 s (the source of the fact "an adventure window is alive", ADR 0042).
 *   Files per window: DMA_WINDOW.file("dma-ld-cmd.json") -> "dma-ld-cmd-adv.json" in the adventure window.
 *   Unit expectation: tests/unit/dma-window-role.test.js — home: no switch changes; adventure: only ADV_ALLOW stays on,
 *   switches restored after the loop, file() suffixes, advAlive() follows the heartbeat age.
 *   Integration expectation: with experimental on, the adventure window logs to dma-probe-ld-adv.jsonl and runs no home
 *   manager (no second writer in dma-facts / dma-heartbeat), while the home window keeps its managers running.
 */
(function (root) {
    "use strict";
    if (root.DMA_WINDOW && root.DMA_WINDOW.version) return;
    var VERSION = "0.1.0", HEART = "dma-window-adv.json", ALIVE_MS = 120000;
    var ADV_ALLOW = { "00_dma_window.js": 1, "user_dma_probe_ld.js": 1, "user_dma_adventure.js": 1, "user_dma_mundane.js": 1,
                      "user_dma_adv_catalogue.js": 1, "user_dma_lootspots.js": 1 };
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function zoneArg() { try { var z = (typeof expZone !== "undefined") ? expZone : root.expZone; return (z == null || z === "") ? null : Number(z); } catch (_) { return null; } }
    var zone = zoneArg(), role = zone == null ? "home" : "adventure";
    function file(name) { if (role === "home") return name; var s = String(name), i = s.lastIndexOf("."); return i < 0 ? s + "-adv" : s.slice(0, i) + "-adv" + s.slice(i); }
    function appFile(name) { var A = air_(); if (!A) return null; return new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); }
    function readJson(name) {
        try { var A = air_(), f = appFile(name); if (!f || !f.exists) return null; var st = new A.FileStream(); st.open(f, A.FileMode.READ);
              var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function writeJson(name, obj) {
        try { var A = air_(), f = appFile(name); if (!f) return false; var st = new A.FileStream(); st.open(f, A.FileMode.WRITE);
              st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    function advAlive(now) { var h = readJson(HEART); now = now || Date.now(); return !!(h && h.atMs && now - Number(h.atMs) < ALIVE_MS) ? h : null; }
    /* pure: which switches the adventure window turns off (exported for the unit expectation) */
    function gate(names, switches) {
        var saved = {}, off = [];
        (names || []).forEach(function (n) {
            if (!/\.js$/i.test(n) || ADV_ALLOW[n]) return;
            saved[n] = switches.hasOwnProperty(n) ? { v: switches[n] } : null;
            switches[n] = false; off.push(n);
        });
        return { off: off, restore: function () { Object.keys(saved).forEach(function (n) { if (saved[n]) switches[n] = saved[n].v; else delete switches[n]; }); } };
    }
    var state = { version: VERSION, role: role, zone: zone, off: [], startedAt: new Date().toISOString() };
    if (role === "adventure") {
        try {
            var names = [], A = air_();
            A.File.applicationDirectory.resolvePath("userscripts").getDirectoryListing().forEach(function (it) { if (!it.isDirectory) names.push(it.name); });
            var sw = (typeof enabledScripts !== "undefined") ? enabledScripts : root.enabledScripts;
            if (sw) { var g = gate(names, sw); state.off = g.off; setTimeout(g.restore, 0); }
        } catch (e) { state.error = String(e).slice(0, 200); }
        var pol = {};
        var loadPol = function () { var p = readJson("dma-policy.json"); if (p && p.policy) pol = p.policy; };
        loadPol();
        root.GCAF_PlayerPolicyInstance = { readOnly: true, get: function (k) { return pol.hasOwnProperty(k) ? pol[k] : undefined; },
                                           requestChange: function () { return { fact: "dc", reason: "read-only in the adventure window" }; } };
        var beat = function () { writeJson(HEART, { zone: zone, at: new Date().toISOString(), atMs: Date.now(), version: VERSION, off: state.off.length }); };
        beat();
        try { setInterval(function () { try { beat(); } catch (_) {} }, 30000); setInterval(function () { try { loadPol(); } catch (_) {} }, 60000); } catch (_) {}
    }
    root.DMA_WINDOW = { version: VERSION, role: role, zone: zone, file: file, advAlive: advAlive, gate: gate, ADV_ALLOW: ADV_ALLOW,
                        status: function () { return JSON.parse(JSON.stringify(state)); } };
})(typeof window !== "undefined" ? window : this);
