/*
 * Stable client filename: user_dma_buff_applier.js (was user_dma_buff_manager.js, git mv; the old file must be deleted on the client in the same deploy)
 * DMA Buff applier 0.1.0 — actor role AR41 "buff applier", the executor of TK41 (ADR 0074 step 2; author 2026-11-16: "separation of concerns, een buffer bufft").
 *
 * 0.1.1 (2026-11-16, ADR 0074 step 3b; the author: "filling a deposit is the same transaction as a buff", D-5): applyFill(order) — the EXECUTION of a deposit fill, moved from the event module (event 0.2.17 sent EVENT_FILL
 *   itself and recorded this role's acts). The order { id, grid, amount, uid, event } is the construction manager's request (AR20, TK41 buff sort "deposit filler", rule R-EV-FILL); the applier sends it through
 *   the Game Interface Adapter, GCAF_GameInterface.sendAction("EVENT_FILL", 0, grid, amount, uid), and records promise + execute on ok, decline with the adapter's reason on a refusal; a transient refusal
 *   (retry: true) records nothing and answers { fact: "wait", reason } so the requester decides (it revokes its request when the hold outlasts its tries). Nothing else changes.
 *   Unit: tests/unit/dma-buff-applier-fill.test.js (promise + execute, decline with the reason, wait without a fact, no adapter). Integration: tests/integration/dma-buff-applier-fill-tx.test.js.
 * 0.1.0 (2026-11-16, ADR 0074 step 2): the renamed buff manager. It is the buff applier and nothing else: it carries out an order and records its TK41 acts (promise, decline) — the
 *   decision that a building needs a buff is the construction manager's (AR20), the choice of the buff is green's computing (TK85). Gone: wake() and its timers (the loop that decided that
 *   a mine needs a buff), the queue and pump. Moved here VERBATIM from green 0.8.29: applyBuff (R-BUFF-CHOICE promise act on an order { grid, buff, by, why }), startLoveTree (R-ZONE-LOVETREE) and the
 *   three choice rules as one act, applyChosen(job): R-BUFF-CHOICE / R-BUFF-PROD-CHOICE / R-EV-BUFF-CHOICE pick the buff of DMA_Green.compute.buffChoice (green computes, the applier promises) and
 *   apply it; with no accepted buff the promise is declined "no accepted buff in the star menu" and the grid is held 10 min (refused). It also keeps what only the applier can know: the buffs it sent
 *   (onItsWay(grid), dma-buff-sent.json: a buff sent less than 10 min ago), the grids the game refused (refused(grid)) and when the Love Tree was last started (loveTreeSentAt()); green's rules read them from here.
 *   The old applyOne (a job -> TK41 case with the ADR 0067 / 0009 truth clauses) stays as apply(job) with settle(list); it is the entry of the building buffer's path.
 *   GLOBAL: DMA_Buffer = { version, owner: "buff applier", actor, tk, ready, applyBuff, startLoveTree, applyChosen, apply, settle, onItsWay, refused, loveTreeSentAt, open }. The old DMA_BuffManager is gone; the
 *   console's version line reads DMA_Buffer. READINESS: ready becomes true when the applier has what it acts through — the game interface adapter (sendAction / sendMessage), green's compute interface
 *   and control — checked at load and by check(); green keeps executing TK41 itself until it sees ready (ADR 0074 section 3: presence and readiness, never two actors, never none; removing this file is the rollback).
 *   Unit: tests/unit/dma-buff-applier.test.js (applyBuff declines and promises, the Love Tree, the choice rule, onItsWay and refused, ready, no timers). Integration: tests/integration/green-buff-through-adapter.test.js
 *   (real control + adapter + applier: a free production building, a tribute, a buffed one, a retry) and tests/integration/dma-buff-applier-handover.test.js (green 0.9.1 hands TK41 to the applier when it is ready, not before).
 *
 * Autonomous. Does not scan. Reads location status only (the location manager's picture, DMA_Demo.memory()).
 * The buff applier sends through the Game Interface Adapter (0.1.7, ADR 0073), never itself and never with control's permit;
 * its own truth clauses below stay (the executor checks the picture when it acts), the adapter's guard is the second lock.
 *
 * 0.1.8 (2026-11-16, tester batch on ADR 0073; coordinator): a TRANSIENT refusal is not a decline. When the adapter answers retry: true (a hold or the
 *   pace), applyOne does not decline and does not promise: the initiator revokes its request ("revoke request", reason = the
 *   adapter's), nothing is held open, and the next wake (20 s) queues the building again; the answer is { ok: false, fact: "wait",
 *   reason }. Any other refusal still declines with the adapter's reason. Integration:
 *   tests/integration/buff-manager-retry-waits.test.js (moved from tests/known-failing/kf-retry-declines-buff-manager).
 * 0.1.7 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C6 of the migration): the buff applier no longer
 *   calls game.gi.SendServerAction and no longer opens control's permit. applyOne sends GCAF_GameInterface.sendAction("APPLY_BUFF",
 *   0, grid, 0, uniqueID); the adapter decides (a verified kind with a buff column, never a tribute, never a buffed building,
 *   holds, pace) and answers { ok } or { ok: false, reason }. The TK41 promise is recorded only on ok — the send now comes BEFORE
 *   the promise — and a refusal is a decline with the adapter's reason (no adapter = "game interface adapter not loaded").
 *   Unit: tests/unit/dma-buff-manager.test.js (a refusal by the adapter -> decline with its reason, no promise). Integration:
 *   tests/integration/dma-buff-manager-tx.test.js (the manager's send reaches the game through the real adapter and control).
 * 0.1.6 (2026-11-16, tester report 2026-11-16 (PR #373) on proposal #364, item D2; ADR 0009 verified building kinds):
 *   the buff applier also refuses what ADR 0009 forbids on every path to the server — "the scripts upgrade, BUFF or
 *   demolish only building kinds on the verified list": before the send it reads the building's game name and asks
 *   control's verified list (DMA_Control.kinds()); a tribute (*_Mini) is declined "tribute: <name>", any other kind not
 *   on the list "not a verified kind: <name>", and without the list (control not loaded) "verified kinds unknown" —
 *   fail closed. An endless mine (BronzeMineEndless, "buff only") may be buffed. An unreadable building stays a decline
 *   (0.1.5). The check sits in applyOne, so DMA_BuffManager.apply is guarded too.
 *   Unit: tests/unit/dma-buff-manager.test.js (tribute, unknown kind, no list, unreadable -> decline, nothing sent;
 *   endless mine and verified mine -> sent). Integration: tests/integration/dma-buff-manager-tx.test.js (with control's
 *   real verified list: a mini mine and an unknown kind in the picture get no buff, the verified mine does).
 *
 * 0.1.5 (2026-11-16, architecture review 2026-11-16 finding #14 (Medium), packaging §5.6 "ADR 0067 in every buff path that
 *   ships", and #12/§5.2): NEVER BUFF A BUFFED BUILDING (ADR 0067). applyOne — also exported as DMA_BuffManager.apply —
 *   reads the building at the moment it acts (its truth clause, ADR 0040 §3) and declines with the reason "already
 *   buffed" and the name of the active buff when productionBuff is set; it fails closed: a building it cannot read is a
 *   decline ("no building" / "building not readable"), never a send. Every job is now a TK41 buff applying case
 *   (caseId "buff@<grid>@<ms>", actor names as the backbone: construction manager AR20 initiates, buff applier AR41
 *   executes): request -> promise (then SA 61) | decline ("already buffed: <name>", "no building", "no stock <buff>",
 *   "send failed"); a promised case is declared and accepted when the location manager's picture shows the slot
 *   buffed, and revoked (revoke request + allow) when it does not within 10 min — the TK41 rule of ADR 0038 step 2.
 *   buff.autoEnabled falls back to OFF when no policy answers.
 *   Unit: tests/unit/dma-buff-manager.test.js (buffed -> decline with the name, nothing sent; unreadable -> decline;
 *   free -> promise + send; the picture shows it -> declare + accept; default off). Integration:
 *   tests/integration/dma-buff-manager-tx.test.js (policy + C-fact memory + buff manager: a buffed and a free mine in
 *   the picture — one send, one TK41 accepted, one declined "already buffed", nothing foreign).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.1";
    var INIT = "construction manager", EXEC = "buff applier", LOST_MS = 10 * 60000, open = {};
    function note(s) {
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
            root.__DMA_CYCLE_AT = Date.now();
        } catch (_) {}
    }
    function pol(k, d) {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && p.get) {
                var v = p.get(k);
                if (v != null && v !== "") return v;
            }
        } catch (_) {}
        return d;
    }
    function slots() {
        var mem = root.DMA_Demo && root.DMA_Demo.memory && root.DMA_Demo.memory();
        return (mem && mem.slots) || [];
    }
    function pickBuff() {
        try { if (typeof DM_refreshBuffInventory === "function") DM_refreshBuffInventory(); } catch (_) {}
        var bag = (typeof DM_buffsAvailable === "object") ? DM_buffsAvailable : {};
        var k, prod = null;
        for (k in bag) {
            if (!bag.hasOwnProperty(k) || !bag[k] || !bag[k].id) continue;
            var n = String(k).toLowerCase();
            if (n.indexOf("smoked") >= 0 && n.indexOf("fish") >= 0) return { name: k, id: bag[k].id, count: bag[k].count };
            if (!prod && n.indexOf("productivity") >= 0) prod = { name: k, id: bag[k].id, count: bag[k].count };
        }
        if (prod) return prod;
        try {
            var vec = game.gi.mCurrentPlayer.getAvailableBuffs_vector();
            var i, def, nm, u;
            for (i = 0; vec && i < vec.length; i++) {
                def = vec[i].GetBuffDefinition && vec[i].GetBuffDefinition();
                nm = def && def.GetName_string ? String(def.GetName_string()) : "";
                if (nm.toLowerCase().indexOf("productivity") < 0) continue;
                u = vec[i].GetUniqueId();
                return { name: nm, id: u.uniqueID1 + "_" + u.uniqueID2, count: vec[i].GetAmount ? vec[i].GetAmount() : 1 };
            }
        } catch (_) {}
        return null;
    }
    function cf(act, job, actor, extra) {
        try {
            var o = { tk: "TK41", act: act, caseId: job.caseId, grid: Number(job.grid), resource: job.resource, actor: actor, initiator: INIT, rule: "R-BUFF-WHEN" }, k;
            for (k in (extra || {})) o[k] = extra[k];
            if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o);
        } catch (_) {}
    }
    /* 0.1.5 (ADR 0067): the building's current buff, read when the buff applier acts; null = unreadable (fail closed) */
    function buildingAt(grid) {
        try { var b = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(grid)); return b ? { b: b } : { none: true }; } catch (_) { return null; }
    }
    function activeBuffName(b) {
        try { var pb = b.productionBuff; if (pb == null) return null; var def = (pb.GetBuffDefinition && pb.GetBuffDefinition()) || pb.buffDefinition || null;
              var n = def && def.GetName_string ? def.GetName_string() : ""; return n ? String(n) : "a buff"; } catch (_) { return "a buff"; }
    }
    /* 0.1.6 (ADR 0009): only verified kinds; fail closed */
    function kindRefusal(b) {
        var name = "";
        try { name = String(b.GetBuildingName_string()).replace(/^\s+|\s+$/g, ""); } catch (_) { return "building not readable"; }
        if (!name) return "building not readable";
        if (/_Mini$/i.test(name)) return "tribute: " + name;
        var list = null;
        try { var C = root.DMA_Control; if (C && typeof C.kinds === "function") list = C.kinds(); } catch (_) { list = null; }
        if (!list) return "verified kinds unknown";
        if (!Object.prototype.hasOwnProperty.call(list, name)) return "not a verified kind: " + name;
        return null;
    }
    function decline(job, why) { cf("decline", job, EXEC, { reason: why }); delete open[job.caseId]; note("buff " + job.resource + " @" + job.grid + " dc " + why); return { ok: false, fact: "dc", reason: why }; }
    function applyOne(job) {
        if (!job.caseId) { job.caseId = "buff@" + job.grid + "@" + Date.now(); cf("request", job, INIT, { level: job.level }); }
        var name = pol("buff.name." + job.resource, pol("buff.defaultName", "SmokedFishSteak"));
        var at = buildingAt(job.grid);
        if (!at) return decline(job, "building not readable");
        if (at.none) return decline(job, "no building");
        var kindWhy = kindRefusal(at.b);   // 0.1.6: ADR 0009
        if (kindWhy) return decline(job, kindWhy);
        var active = activeBuffName(at.b);
        if (active) return decline(job, "already buffed: " + active);   // ADR 0067
        try { if (typeof DM_refreshBuffInventory === "function") DM_refreshBuffInventory(); } catch (_) {}
        var bag = (typeof DM_buffsAvailable === "object") ? DM_buffsAvailable : {};
        var entry = bag[name];
        if (!entry || !entry.id || !(entry.count > 0)) return decline(job, "no stock " + name);
        var A = root.GCAF_GameInterface;   // 0.1.7 (ADR 0073): the adapter owns the send; the promise follows its answer
        if (!A) return decline(job, "game interface adapter not loaded");
        var res;
        try {
            var parts = String(entry.id).split("_");
            var uniqueID = game.def("Communication.VO::dUniqueID").Create(parts[0], parts[1]);
            res = A.sendAction("APPLY_BUFF", 0, Number(job.grid), 0, uniqueID);
        } catch (e) { return decline(job, "send failed: " + e); }
        if (res && !res.ok && res.retry) {   // 0.1.8: transient — wait, do not decline
            cf("revoke request", job, INIT, { reason: res.reason }); delete open[job.caseId]; note("buff " + job.resource + " @" + job.grid + " waits: " + res.reason);
            return { ok: false, fact: "wait", reason: res.reason };
        }
        if (!res || !res.ok) return decline(job, (res && res.reason) || "no answer from the adapter");
        cf("promise", job, EXEC, { buff: name });
        open[job.caseId] = { job: job, at: Date.now() };
        note("buff " + job.resource + " @" + job.grid + " pm " + name);
        return { ok: true, fact: "pm" };
    }
    /* 0.1.5: a promised case ends by what the location manager's picture shows (declare, observed) or after 10 min */
    function settle(list) {
        var byGrid = {}, k, o, s;
        (list || []).forEach(function (x) { if (x && x.grid != null) byGrid[String(x.grid)] = x; });
        for (k in open) {
            if (!open.hasOwnProperty(k)) continue;
            o = open[k]; s = byGrid[String(o.job.grid)];
            if (s && s.buffed) { cf("declare", o.job, EXEC, { observed: true }); cf("accept", o.job, INIT, {}); delete open[k]; }
            else if (Date.now() - o.at >= LOST_MS) { cf("revoke request", o.job, INIT, { reason: "the buff did not show within 10 min" }); cf("allow", o.job, EXEC, { tacit: true }); delete open[k]; }
        }
    }
    /* ---------- ADR 0074 step 2: moved VERBATIM from green 0.8.29 (applyBuff, startLoveTree); the state only the applier can know ---------- */
    var BUFF_SENT_MS = 10 * 60 * 1000, REFUSE_MS = 10 * 60 * 1000, buffSent = {}, buffRefused = {}, loveTreeSentAt = 0;
    function airF() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function fileRead(name) {
        try { var a = airF(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function fileWrite(name, obj) {
        try { var a = airF(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath), st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    try { buffSent = (fileRead("dma-buff-sent.json") || {}).sent || JSON.parse(localStorage.getItem("dma.buffSent.v1") || "{}") || {}; } catch (_) { buffSent = {}; }
    function saveBuffSent() { try { localStorage.setItem("dma.buffSent.v1", JSON.stringify(buffSent)); } catch (_) {} fileWrite("dma-buff-sent.json", { format: "dma-buff-sent/1", sent: buffSent }); }
    function onItsWay(grid) {
        var at = buffSent[String(grid)];
        if (at && Date.now() - at < BUFF_SENT_MS) return true;
        if (at) { delete buffSent[String(grid)]; saveBuffSent(); }
        return false;
    }
    function refused(grid) { var at = buffRefused[String(grid)]; return at && Date.now() - at < REFUSE_MS ? at : null; }
    function ctrl() { return root.DMA_Control || null; }
    function mapBuilding(grid) {
        try { var m = ctrl() && ctrl().map && ctrl().map(), bs = (m && m.buildings) || [], i; for (i = 0; i < bs.length; i++) if (String(bs[i].grid) === String(grid)) return bs[i]; } catch (_) {}
        return null;
    }
    /* an order in progress on the grid (a build or upgrade order sent lately): the order's owner knows (the construction manager, until then green), else control's own list */
    function busy(grid) {
        try { var CM = root.DMA_ConstructionManager; if (CM && CM.ready && typeof CM.busy === "function") return CM.busy(grid) || ""; } catch (_) {}
        try { var Gr = root.DMA_Green; if (Gr && typeof Gr.busy === "function") return Gr.busy(grid) || ""; } catch (_) {}
        try { var c = ctrl(); if (c && c.hasBuildOrder && c.hasBuildOrder(grid)) return "build"; } catch (_) {}
        return "";
    }
    function tk41Act(act, grid, extra) {
        var o = { tk: "TK41", act: act, grid: Number(grid) }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function ldef(n) { return root.swmmo.getDefinitionByName(n); }
    function viaAdapter(fn) {
        var A = root.GCAF_GameInterface;
        if (!A) return { ok: false, reason: "game interface adapter not loaded" };
        try { return fn(A) || { ok: false, reason: "no answer from the adapter" }; } catch (e) { return { ok: false, reason: "send failed: " + e }; }
    }
    function loveTreePlan() { try { var G = root.DMA_Green; return G && G.compute && G.compute.loveTreePlan ? G.compute.loveTreePlan() : { ok: false, reason: "green's compute interface not loaded" }; } catch (e) { return { ok: false, reason: "plan failed: " + e }; } }
    function startLoveTree(order) {
        var lt = loveTreePlan();
        if (!lt.ok) { note("buffer Love Tree dc " + lt.reason); tk41Act("decline", order.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", reason: lt.reason }); return { fact: "dc", reason: lt.reason }; }
        var gi = game.gi, vo = new (ldef("Communication.VO::dTimedProductionVO"))();
        vo.productionType = lt.type; vo.type_string = lt.recipeName; vo.amount = 1; vo.stacks = 1; vo.buildingGrid = lt.grid;
        var sLT = viaAdapter(function (A) { return A.sendMessage("START_TIMED_PRODUCTION", vo); });   // 0.8.25
        if (!sLT.ok && sLT.retry) { note("buffer Love Tree waits: " + sLT.reason); return { fact: "wait", reason: sLT.reason }; }   // 0.8.26
        if (!sLT.ok) { note("buffer Love Tree dc " + sLT.reason); tk41Act("decline", order.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", reason: sLT.reason }); return { fact: "dc", reason: sLT.reason }; }
        loveTreeSentAt = Date.now();
        note("buffer Love Tree @" + lt.grid + " ex " + lt.recipeName + " (level " + lt.level + ")");
        tk41Act("promise", lt.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", zone: true, buff: lt.effect, recipe: lt.recipeName, level: lt.level, by: order.by });   // 0.8.8: was "execute"
        return { fact: "ex" };
    }
    function applyBuff(order) {
        var grid = Number(order.grid), want = String(order.buff || "");
        var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone);
        var bld = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(grid);
        function dc(reason) { note("buffer @" + grid + " " + want + " dc " + reason); tk41Act("decline", grid, { actor: "buff applier", rule: order.rule, resource: order.resource, buff: want, reason: reason, by: order.by }); return { fact: "dc", reason: reason }; }
        if (!bld) return dc("no building");
        var mbA = bld.productionBuff != null ? mapBuilding(grid) : null, GAf = root.GCAF_GameInterface;   // 0.8.28: the exception is the buff KIND (adapter 0.2.4, buff-actions.yaml), not a flag on the order
        var acts = mbA && GAf && typeof GAf.buffAction === "function" ? GAf.buffAction(want, String(mbA.buffName || "")) : null;
        if (bld.productionBuff != null && !acts) return dc("already buffed");
        if (bld.IsUpgradeInProgress && bld.IsUpgradeInProgress()) return dc("upgrading");
        if (busy(grid)) return dc("order in progress");
        if (onItsWay(grid)) return dc("buff on its way");
        if (game.gi && game.gi.isOnHomzone && !game.gi.isOnHomzone()) return dc("not home");
        var stack = null;
        try {
            (game.gi.mCurrentPlayer.getBuffsSortedForStarMenu() || []).forEach(function (b) {
                if (stack || !b || b.IsExhausted || (b.GetWaitingForServer && b.GetWaitingForServer())) return;
                var d = b.GetBuffDefinition && b.GetBuffDefinition();
                if (!d || !d.GetName_string || typeof b.GetUniqueId !== "function") return;
                var dn = String(d.GetName_string()), shown = dn;
                try { shown = String(loca.GetText("RES", dn) || dn); } catch (_) {}
                if (dn === want || dn.toLowerCase() === want.toLowerCase() || shown.toLowerCase() === want.toLowerCase()) stack = b;   // 0.7.8: by name or shown name
            });
        } catch (_) {}
        if (!stack) { buffRefused[String(grid)] = Date.now(); return dc("buff not in the star menu"); }
        var was = null;
        if (acts) { was = String(mbA.buffName || ""); }   // 0.8.8: the declare is the buff changing
        var sAB = viaAdapter(function (A) { return A.sendAction("APPLY_BUFF", 0, grid, 0, stack.GetUniqueId(), { stack: stack }); });   // 0.8.25
        if (!sAB.ok && sAB.retry) { note("buffer @" + grid + " " + want + " waits: " + sAB.reason); return { fact: "wait", reason: sAB.reason }; }   // 0.8.26: transient, not a decline
        if (!sAB.ok) { buffRefused[String(grid)] = Date.now(); return dc(sAB.reason); }
        buffSent[String(grid)] = Date.now(); saveBuffSent();
        note("buffer @" + grid + " ex " + want + " (order by " + (order.by || "?") + (order.why ? ", " + order.why : "") + ")");
        tk41Act("promise", grid, { actor: "buff applier", rule: order.rule, resource: order.resource, buff: want, by: order.by, why: order.why, how: order.how, replace: acts ? true : null, was: was });   // 0.8.8: was "execute"
        return { fact: "ex" };
    }
    /* the three choice rules (R-BUFF-CHOICE, R-BUFF-PROD-CHOICE, R-EV-BUFF-CHOICE) as the applier's promise act: green computes the buff (compute.buffChoice), the applier promises it, or declines */
    function applyChosen(job) {
        var grid = Number(job.grid), rule = job.rule || "R-BUFF-CHOICE", pick = null;
        try { var G = root.DMA_Green; pick = G && G.compute && G.compute.buffChoice ? G.compute.buffChoice(grid, job.name || "", job.request || null) : null; } catch (_) { pick = null; }
        if (!pick) { buffRefused[String(grid)] = Date.now(); note("buff [" + rule + "] @" + grid + " dc no accepted buff in the star menu"); tk41Act("decline", grid, { actor: "buff applier", rule: rule, resource: job.resource, reason: "no accepted buff in the star menu (retry after 10 min)" }); return { fact: "dc", reason: "no accepted buff" }; }
        return applyBuff({ grid: grid, buff: pick.def, by: job.by || "construction manager", why: job.why || (rule + " " + pick.how), rule: rule, resource: job.resource, how: pick.how });
    }
    /* ADR 0074 step 3b: the execution of a deposit fill (TK41, buff sort "deposit filler"); the request is the construction manager's */
    function fillAct(act, order, extra) {
        var o = { tk: "TK41", act: act, caseId: order.id, grid: order.grid, actor: EXEC, initiator: INIT, rule: "R-EV-FILL", buffSort: "deposit filler", event: order.event }, k;
        if (extra) for (k in extra) o[k] = extra[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function applyFill(order) {
        var A = root.GCAF_GameInterface, r;
        if (!A) { fillAct("decline", order, { reason: "game interface adapter not loaded" }); return { ok: false, fact: "dc", reason: "game interface adapter not loaded" }; }
        try { r = A.sendAction("EVENT_FILL", 0, order.grid, order.amount, order.uid); }
        catch (e) { fillAct("decline", order, { reason: "send failed: " + e }); return { ok: false, fact: "dc", reason: "send failed: " + e }; }
        if (r && !r.ok && r.retry) return { ok: false, fact: "wait", reason: r.reason };
        if (!r || !r.ok) { var why = (r && r.reason) || "no answer from the adapter"; fillAct("decline", order, { reason: why }); return { ok: false, fact: "dc", reason: why }; }
        fillAct("promise", order, {}); fillAct("execute", order, { amount: order.amount });
        return { ok: true, fact: "ex" };
    }
    /* readiness: the applier has what it acts through (ADR 0074 section 3) */
    var ready = false;
    function check() {
        try { var A = root.GCAF_GameInterface, G = root.DMA_Green; ready = !!(A && typeof A.sendAction === "function" && typeof A.sendMessage === "function" && G && G.compute && typeof G.compute.buffChoice === "function" && ctrl()); } catch (_) { ready = false; }
        api.ready = ready; return ready;
    }
    var api = { version: VERSION, owner: "buff applier", actor: "buff applier", tk: "TK41", ready: false, check: check, applyBuff: applyBuff, startLoveTree: startLoveTree, applyChosen: applyChosen, applyFill: applyFill,
                apply: applyOne, settle: settle, onItsWay: onItsWay, refused: refused, loveTreeSentAt: function () { return loveTreeSentAt; }, open: function () { return JSON.parse(JSON.stringify(open)); } };
    root.DMA_Buffer = api;   // the old DMA_BuffManager is gone (ADR 0074)
    check();
    note("buff applier " + VERSION + " loaded, ready=" + api.ready);
})(typeof window !== "undefined" ? window : this);
