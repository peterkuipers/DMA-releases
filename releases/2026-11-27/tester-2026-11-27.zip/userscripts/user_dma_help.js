/*
 * user_dma_help.js — Helper (DEMO TK26 "resource giving") and Star trader (TK27 "star trading") 0.1.0
 * 0.1.20 (2026-11-20, ADR 0089; the author's words 2026-11-20: "Stop asking in guild chat without my permission"): DMA never ASKS the guild on its own
 *   any more. The three asks this module could start itself — the PURCHASE ("Who sells me N X?"), the ASKED ROUND TRADE and the ASKED STAR TRADE —
 *   are held for the player: no chat line, no trade. Instead one fact (at most once per 2 h per kind and resource) says what DMA wanted to ask, with
 *   heldBy "player" and the reason "asking the guild needs the player's permission — the player's help is asked", so the player is told. An ask goes
 *   out only with a permission the player gave for it: an entry {kind, res, until} in dma-guild-ask-permit.json, or permitGuildAsk(kind, res, minutes);
 *   each permission is used once. ANSWERS to someone who addressed the player (help, star trade) are unchanged: they are replies, not asks.
 *   Why now: on 2026-11-19 two purchases of 136K Beer were "asked" while the chat bridge refused guild lines (whisperOnly), yet ordinary guild chat was
 *   read as a yes and real trade offers (1,970 Carriage for 136K Beer) went to Minotaurus2 and zwie, who had never seen a question.
 *   Unit: tests/unit/dma-help-guild-permission.test.js (no permission: no line, no trade, one held fact with heldBy player; a permission lets exactly one
 *   ask out; an expired or used permission does not). Integration: tests/integration/dma-help-asked-trades.test.js (the purchase and the round trade run
 *   end to end only after a permission; without one the supply manager's last resort ends at the held fact).
 * 0.1.19 (2026-11-17, tester release, author: nothing may fit only his island): parseAsk() took the word "peter" (the author's chat word) as
 *   noise when it looked for the word where a resource should be, so a player called Joe answered "joe help 5k bred" with "I have no Joe".
 *   The noise now holds the player's OWN names, read at run time (DMA_Chat.words(), DMA_Chat.ownName()); "peter" is no longer typed into the code.
 *   Unit: tests/unit/dma-help-own-name.test.js (with the chat word Joe, "joe help 5k bred" names "bred" as the unknown word; "peter" is not special).
 *   Integration: tests/integration/dma-help-star.test.js (a request with the chat word is answered as before).
 * 0.1.18 (2026-11-16, ADR 0075 R-1 / R-2 / R-4, backbone v3.19; the author's words 2026-11-16: "mag je een guild chat gebruiken om je RT verzoek kenbaar te maken. Ben ruim in het interpreteren van mensen die akkoord gaan. Als je twijfelt
 *   kun je het altijd vragen en anders maak je de RTs voor de specifieke speler. En je geeft aan als je ze verstuurd hebt."; coordinator batch item 3.7): two new kinds of trade set under TK25.
 *   PURCHASE from a guild member, the LAST resort of the resource supply manager (AR66): askPurchase(resource, amount, { maxPricePct }) says "Who sells me N X? I pay with M Y (same value)" in the guild chat, one open purchase per
 *   resource, and returns { ok, caseId } (the supply manager records the TK25 request, set PURCHASE, market guild chat). A guild member's reply is read generously (yes / sure / I can / ja ... = agrees; no / sorry / nee = declines;
 *   anything else, or a question, is asked back once: "did you mean you sell me X? yes or no"); the first who agrees gets the trade made FOR HIM (what we pay is priced by the value list, never above maxPricePct of what we buy, paid with a
 *   resource the stock holds plenty of); the chat says when it has been sent. The purchase is accepted when the stock has grown by the amount (observed), withdrawn (revoke request, allow) after 2 h unanswered or 3 h unaccepted.
 *   ASKED ROUND TRADE (R-1; the trade manager AR29 asks, for the trade itself, e.g. a quest that counts trades): wantRoundTrade(reason) marks it wanted; with trade.auto and trade.rt.ask.on on, at most trade.rt.ask.everyMin and
 *   trade.rt.ask.maxPerDay, a line asks the guild; whoever agrees (same reading) gets BOTH trades, which cancel each other out (1 Fish for 1 Coin, and 1 Coin for 1 Fish); the chat says they are sent; the case is accepted when our stock is
 *   back to what it was (both accepted), withdrawn after 1 h otherwise. askRoundTrade(opts) asks at once. Record: TK25 with setKind PURCHASE / ASKED ROUND TRADE.
 *   Unit: tests/unit/dma-help-purchase.test.js (reading of replies, the pay amount by value, one open per resource, the trade made for the one who agrees, withdraw). Integration: tests/integration/dma-help-asked-trades.test.js (real policy,
 *   transactions, chat double and control's trade double: a purchase and an asked round trade from the ask to the accept; the limits).
 * 0.1.17 (2026-11-10, backbone v3.14, ADR 0056): the actor names follow the model — trade completer (TK25 trade completing) and trade
 *   payer (TK24 trade paying), both about [set of trade]. Text only. Unit: dma-help tests (version); integration: the
 *   TX page shows "trade completer" on a gift or star trade.
 * 0.1.16 (2026-11-02, ADR 0039 change A — an implementation change, class [impl]: the essence is unchanged since
 *   model v3.2): the module recorded its own transaction kinds TK26 (helper), TK27 (star trader) and TK28 (star asker),
 *   which the backbone folded into TK25 trade set completing (a gift, a star trade and an asked star trade are kinds of
 *   TRADE SET) with TK24 trade set paying (what is owed back). Every fact is now recorded as TK25 — or TK24 for a debt
 *   case — with `setKind` (gift / star trade / asked star trade / return) and the backbone's role names; an asked star
 *   trade carries `initiator: storage relief manager`. Case ids, acts and behaviour are unchanged.
 *   Unit: tests/unit/dma-ontology-guard.test.js (no drift left: C1 passes without TK26/27/28).
 *   Integration: dma-help-star.test.js and dma-star-ask.test.js read TK25 / TK24 with setKind.
 * 0.1.15 (2026-11-02, live: the client did not load 0.1.14 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.1.14 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   only DEMO 4 acts are recorded as C-facts, one instance per CASE (gift:, star:, debt:, return:, ask: + who@time):
 *   - TK26 gift / TK27 star trade: the request is recorded first, for every request; a request that is off, unclear,
 *     not from a guild member or over the limits is declined (was "rq-off" / "rq-unclear"); a send that fails after the
 *     promise is revoke promise + allow (tacit) + decline; the trades sent are the execute, then declare; the outcome
 *     mails are the requester's accept | reject (TK27: second without the first, first without the second, or no answer
 *     within star.waitHours are rejects with their reason — was "check", "owed", "expired").
 *   - A debt (first star trade accepted, second not) is its own transaction debt:<case>: request (star trader asks it
 *     back) -> promise (tacit) -> execute (each return trade accepted) -> declare + accept when it is paid; the player
 *     settling or explaining it is revoke request + allow (was "owed", "returned", "settled", "explained").
 *   - Undo by the receiver: before the result is accepted, revoke request + allow (he declines our trade); after it,
 *     a counter-transaction return:<case> (request by him, promise by us, execute + declare + accept when his return
 *     trade is accepted) (was "revoke-request", "revoke-result", "returned"). A star trade "revoke" likewise.
 *   - TK28 (we ask a star trade): request -> promise (his first trade) -> execute (first, second) -> accept (declare
 *     tacit); no answer, expiry, storage no longer full, or our side failing: revoke request + allow (was "closed",
 *     "expired", "revoke-request", "decline", "fail").
 *   - Not coordination, so information (kind "i"): name, counter, check-asked, outcome-unread, return-refused,
 *     nothing-to-undo, undo asked.
 *   What is said in the chat and sent in the game is unchanged.
 *   Unit/integration expectation: the help tests read the new acts; tests/unit/dma-demo4-acts.test.js.
 * 0.1.13 (2026-10-25, author: "the game gets slower and slower; analyse and improve"): the tick every 15 s instead of 5 s
 *   (the chat holds a request for an hour, nothing is lost), and a star-trade ask nobody answered is closed after 2 h
 *   (the 16:29 Stone ask was still "asked" at 19:10 and kept every trade mail being read each tick).
 * 0.1.12 (2026-10-25, author: "when I go to another island the orders carry on; they must stop"): no tick while the
 *   player is on another island (DMA_Control.atHome() false); requests wait until he is home.
 *
 * 0.1.11 (2026-10-25, live: Bets333 "peter star trade 400k brew" was answered "I have no Brew" while brew is full;
 *   the reader's name for a resource is not always the game's): when the read name holds nothing, the word is matched
 *   to the game's own resources (control trade.resourceList: game name and the name the game shows), and the game's
 *   name is used. The list is written once to dma-resources.json, so every name the game uses is on record.
 * 0.1.10 (2026-10-25, author: "he asks a star trade of 1250K gold bars, you don't have that, so you can offer a round
 *   amount you do have, for example 200K gold bars"): a star trade for more than the stock is no longer declined; the
 *   star trader offers the largest ROUND amount the stock covers — the 1-2-5 series (…, 100K, 200K, 500K, 1M …), so
 *   392,888 gives 200K — sends both trades for that amount and says so (fact TK27 counter). Below 1 it still declines.
 * 0.1.9 (2026-10-25, live: Zingu asked a star trade for 1250K gold bars and was refused "the last star trade is still
 *   open" — the 5K plank star trade of an hour earlier stood at first-accepted / second-open, while Zingu had nothing
 *   pending. Cause: an outcome mail whose trade could not be read was attributed BY ORDER (first unread mail = the
 *   first trade), so an unrelated outcome — very likely the author's own manual 20K Stone gift — was booked as trade 1,
 *   and the real outcomes were never matched. Author: "ja" to the fix):
 *   - No guessing: an outcome mail is attributed to a star trade only when its trade reads (offer / costs match).
 *     An unreadable one gets one body request, then is set aside with a fact (TK27 outcome-unread) — never booked.
 *   - A star trade that blocks a new one while it is still undetermined ("sent") is NOT explained to the requester as
 *     an instruction he cannot follow; he is told it cannot be confirmed yet and that the player will check it; the
 *     case is flagged for the player (peter: true, fact TK27 check-asked) and the new request is kept waiting.
 *   - Settled (the player's word) now also closes a "sent" case; a request kept waiting (at most 1 h old) is then
 *     handled at once, without the requester asking again. The requester's own word never settles a case.
 * 0.1.8 (2026-10-25, author: "Zingu tries a help trade for stone; I have plenty of that, so that can always go ahead
 *   regardless of the level"): a resource we have PLENTY of — its storage at least help.plentyPct % of the maximum
 *   (default 90; control storageOf) — is given without the level limits (times per hour, day, week and the max per
 *   request); only the share of the stock in one gift (help.floorPct) still bounds it.
 * 0.1.7 (2026-10-25, author: "see the different ways people pass amounts"): the reader takes 10, 1, 5k, 3.5m, 3500k,
 *   2.4 million / mill / mil / mio, kk, 20.000 / 20,000 / 20 000, 1,5k; more resource words (brew, beer, saltp, salt,
 *   powder, log(s), swords, bows, cannons ...); an unknown resource word is named back ("I don't know the resource
 *   'x'") instead of "how much of what?".
 * 0.1.6 (2026-10-25, live: Zingu asked 10 hardwood logs, we hold 69,393 — refused "short of Real Wood myself" by the
 *   100K floor; author: "make it so"): a small gift is always allowed — at most help.smallPct % of the stock (default 1),
 *   also below the floor; a larger request is cut to what may be given. Resources are named as the game shows them
 *   (Hardwood, Pinewood plank, Copper ore, Saltpeter ...), not by their internal names.
 * 0.1.5 (2026-10-25, author: "now an RT we need ourselves: which resource is at its maximum so production stands still;
 *   ask an RT for it in the guild chat — which resource and how much ... someone may answer 'I only have x' (a decline
 *   with a counter-proposal) ... accept the trade that sends what you asked and then send the same amount back, or if
 *   he sent two trades accept them after that. Make sure they never pass each other"). TK28 star trade ASKING (we are
 *   the initiator; a guild member executes), the kind trade.ask.on (default off), at most once per trade.ask.everyMin.
 *   - The ask: a resource whose storage is full (control storageOf), one at a time, no ask while one is open; the
 *     text the author approved: "Who can do a star trade please? <Resource>, max <N>k. Let me know if you send two
 *     trades or want me to send the resources back" — N = the stock in whole thousands (empty the stock).
 *   - The answer is read from the trades, not from words: a trade from a guild member that offers that resource (at
 *     most N, costing at most star.returnCostMax) is his promise; "I only have x" simply arrives as a smaller trade.
 *     A second trade from him asking the same amount back makes it two-trade mode; otherwise (after 2 minutes, or at
 *     once when he says "send back" / "return") one-trade mode.
 *   - Execution never lets the trades pass each other: his first trade is accepted (it lands in our star, our storage
 *     being full) and must be gone from the inbox before anything else; THEN his second trade is accepted (paying from
 *     our storage — production runs again) or our own trade sends the same amount back (for 1 Fish).
 *   - Declared in the chat ("thanks, done"); every step a TK28 fact; the case is kept in the ledger file.
 * 0.1.4 (2026-10-25, live: the AIR client's localStorage does not survive a restart): gifts and star trades are kept in
 *   the file dma-help-ledger.json (localStorage stays as a fallback), so limits, debts and open star trades survive.
 * 0.1.3 (2026-10-25, author: "voor alle trade geldt de demo gedachte. als iemand zich bedenkt moet je het altijd terug
 *   kunnen draaien"): DEMO revocation for help and star trades, and the outcome of a gift.
 *   - A gift's outcome is read like a star trade's (TRADE_ACCEPTED / TRADE_DECLINED mails): declined = the receiver
 *     cancelled it (the resource came back by itself; it no longer counts against his limits).
 *   - "cancel / undo / never mind / changed my mind / take back / laat maar / terugdraaien" from the receiver within
 *     24 h: a gift not yet accepted — he is asked to decline it in his inbox (that returns it); a gift accepted — he is
 *     asked to send it back with a trade (1 fish is fine) and that return trade is accepted (the counter-transaction).
 *     A star trade not yet accepted — decline both; the first accepted — the return flow (owed) applies; both done —
 *     nothing to undo (net zero), said so.
 * 0.1.2 (2026-10-25, author: "star trade is part of trade, same as help trade"): no own switches — help needs the Trade
 *   switch and trade.help.on, a star trade the Trade switch and trade.star.on (TRADE page).
 * 0.1.1 (2026-10-25, author: "aan star trade zit in principe geen maximum, buiten het feit dat jouw voorraad het maximum
 *   is"): no star.max and no floor for a star trade — the stock is the only limit (net zero for us when both trades
 *   are accepted). The requester must name the resource and the amount (unchanged).
 * 0.1.0 (2026-10-25), the author:
 *  - "het is normaal dat we elkaar helpen in de guild. Je kunt elkaar vragen om het geven van een bepaalde grondstof.
 *    Hoe lager de speler qua level, hoe gemakkelijker we bereid zijn deze persoon te helpen ... bedrijfsregels met
 *    spelers level, aantal maal per dag, uur, max hoeveelheid, minimum dat ik zelf op voorraad wil hebben."
 *  - "Een derde vorm van trade is een star trade ... stuur je eerst de gevraagde hoeveelheid, zodat deze in de star
 *    wordt gezet omdat de voorraad vol zit en de tweede trade maakt de voorraad weer leeg ... de ander moet ze in de
 *    juiste volgorde accepteren. Soms stuurt de speler zelf de grondstoffen terug ... met een vis, of 1 van een
 *    goedkopere grondstof ... Iemand die de grondstoffen niet terug stuurt kan hier een goede reden voor hebben. Blijf
 *    hiermee gewoon in gesprek. Echter ga geen tweede star trade aan, voordat duidelijk is waarom."
 *  - Confirmed 2026-10-25: trade 1 = we give N R for 1 Fish (lands in the other player's star), trade 2 = we give
 *    1 Fish for N R (empties his storage); net zero for us. Defaults "ruimer". The script sends within the rules
 *    itself, behind its switches (help.auto, star.auto), default OFF.
 *
 * DEMO: a guild member (initiator) requests; the helper / star trader (executor, an agent for the player, who stays
 * accountable) promises or declines by the rules (policy help.* / star.*), executes (sends the friend trade through
 * the control gateway), and declares in the chat. TK27's result is accepted when both trades are accepted; a first
 * trade accepted without the second leaves a DEBT (a fact of TK27) that blocks a new star trade with that player until
 * the resource is returned (a return trade is accepted) or the player marks it explained on the HELP page.
 * A guild message is data: only the amount and the resource are read from it, and only the rules decide.
 */
(function (root) {
    "use strict";
    if (root.DMA_Help && root.DMA_Help.version) return;
    var VERSION = "0.1.20";
    var waiting = {};        // 0.1.9: who(lowercase) -> a star request kept while an earlier case is being checked
    var TICK_MS = 15000, HEADERS_MS = 30000, STATUS_MS = 30000, LS_KEY = "dma.help.v1";
    var purchases = [], rts = [], rtWanted = null;   // 0.1.18
    var permUsed = {}, permAskedAt = {}, permGrants = [];   // 0.1.20 (ADR 0089): the player's permissions to ask the guild
    var asks = [];           // 0.1.5 TK28: { res, n, at, status: asked|promised|first|done|closed, from, t1, t2, mode, seenAt }
    var gifts = [];          // { to, level, res, amount, at }
    var stars = [];          // { to, res, amount, at, status: sent|done|owed|returned|declined|expired|check, t1, t2, debt, explained, outcomeIds }
    var seenRq = {}, lastHeadersAt = 0, lastStatusAt = 0, timer = null;
    var state = { startedAt: null, ticks: 0, lastError: "", requests: 0, given: 0, starSent: 0, declined: 0 };

    function note(s) { state.lastError = String(s).slice(0, 300); }
    function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function writeJson(name, obj) {
        try {
            var a = airApi(); if (!a) return;
            var f = a.File.applicationDirectory.resolvePath(name), file = new a.File(f.nativePath);
            var st = new a.FileStream(); st.open(file, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close();
        } catch (e) { note("write " + name + ": " + e); }
    }
    function airF() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function fileRead(name) {
        try { var a = airF(); if (!a) return null; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function fileWrite(name, obj) {
        try { var a = airF(); if (!a) return false; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    function load() {
        var o = fileRead("dma-help-ledger.json");                              // 0.1.4: the file first
        if (!o) { try { o = JSON.parse(root.localStorage.getItem(LS_KEY) || "{}") || {}; } catch (_) { o = {}; } }
        gifts = o.gifts || []; stars = o.stars || []; asks = o.asks || []; purchases = o.purchases || []; rts = o.rts || []; permUsed = o.permUsed || {};   // 0.1.20 permUsed
    }
    function save() {
        var wk = Date.now() - 8 * 86400000;
        gifts = gifts.filter(function (g) { return g.at >= wk; });
        stars = stars.filter(function (c) { return c.at >= Date.now() - 60 * 86400000 || c.status === "owed" || c.status === "sent"; });
        try { root.localStorage.setItem(LS_KEY, JSON.stringify({ gifts: gifts, stars: stars })); } catch (_) {}
        fileWrite("dma-help-ledger.json", { format: "dma-help-ledger/1", gifts: gifts, stars: stars, asks: asks.slice(-20), purchases: purchases.slice(-20), rts: rts.slice(-20), permUsed: permUsed });   // 0.1.4, 0.1.5 asks
    }
    function pol(k, d) { try { var p = root.GCAF_PlayerPolicyInstance; if (p && typeof p.get === "function") { var v = p.get(k); if (v !== undefined && v !== null && v !== "") return v; } } catch (_) {} return d; }
    function num(k, d) { var v = Number(pol(k, d)); return isNaN(v) ? d : v; }
    function on(k) { return pol(k, false) === true; }
    function gw() { return root.DMA_Control && root.DMA_Control.trade; }
    /* 0.1.16 (ADR 0039, change A): the backbone has one ontological model for trading between two parties (model
       v3.1/v3.2): a gift, a star trade and an asked star trade are kinds of TRADE SET under TK25 trade set completing;
       what the other party owes back is TK24 trade set paying. The module's kinds map onto them here, once. */
    var SET_KIND = { gift: "gift", star: "star trade", ask: "asked star trade", purchase: "PURCHASE", rt: "ASKED ROUND TRADE" };
    function ontoTk(kind, cs) {
        if (cs && /^debt:/.test(String(cs))) return "TK24";      // the payment of a star trade still owed: trade set paying
        return "TK25";                                           // every other case: trade set completing
    }
    function setKind(kind, cs) {
        if (cs && /^return:/.test(String(cs))) return "return";
        if (cs && /^debt:/.test(String(cs))) return SET_KIND[kind] || kind;
        return SET_KIND[kind] || kind;
    }
    function record(kind, act, data, cs) {                     // 0.1.14: cs = the case id (one instance per case)
        var tk = ontoTk(kind, cs);
        var o = { tk: tk, act: act, setKind: setKind(kind, cs),
                  actor: tk === "TK24" ? "trade payer" : kind === "ask" ? "trade completer (guild member)" : "trade completer" }, k;   // 0.1.17: v3.14 role names (RM-TO)
        if (kind === "ask") o.initiator = "storage relief manager";
        if (kind === "purchase") { o.initiator = "resource supply manager"; o.actor = "trade completer (guild member)"; o.set = "PURCHASE"; o.market = "guild chat"; }   // 0.1.18
        if (kind === "rt") { o.initiator = "trade manager"; o.actor = "trade completer (guild member)"; o.set = "ASKED ROUND TRADE"; }
        if (cs) o.caseId = cs;
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function info(kind, what, data, cs) {                      // 0.1.14: not a coordination act
        var o = { tk: ontoTk(kind, cs), setKind: setKind(kind, cs), what: what }, k;
        if (cs) o.caseId = cs;
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", o); } catch (_) {}
    }
    function giveUp(tk, cs, data) {                            // 0.1.14: the executor withdraws its promise and declines
        record(tk, "revoke promise", data, cs); record(tk, "allow", { actor: "requester (tacit)" }, cs); record(tk, "decline", data, cs);
    }
    function withdraw(tk, cs, data, executor) {                // 0.1.14: the initiator revokes its request; the executor allows
        record(tk, "revoke request", data, cs); record(tk, "allow", { actor: executor || "executor (tacit)" }, cs);
    }
    function caseOf(c, kind) { return c.caseId || (kind + ":" + (c.to || c.res) + "@" + c.at); }
    function say(text, tag) { try { return !!(root.DMA_Chat && root.DMA_Chat.say && root.DMA_Chat.say(text, tag)); } catch (e) { note("say " + e); return false; } }
    function clean(n) { return String(n || "").replace(/[^A-Za-z0-9_ .-]/g, ""); }
    function owner() { try { return (root.DMA_Chat && root.DMA_Chat.ownerName && root.DMA_Chat.ownerName()) || "I"; } catch (_) { return "I"; } }
    function hhmm(ms) { var d = new Date(ms); return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2); }   // 0.1.9: the player's clock, as the chat shows it
    function roundDown(n) {                                                           // 0.1.10: 1-2-5 series, at most n
        n = Math.floor(Number(n) || 0); if (n < 1) return 0;
        var p = Math.pow(10, Math.floor(Math.log(n) / Math.LN10)), best = 0;
        [1, 2, 5, 10].forEach(function (f) { if (f * p <= n) best = f * p; });
        return best;
    }
    function kfmt(n) { n = Number(n) || 0; if (n < 1000) return String(n); var k = Math.round(n / 100) / 10; return (k % 1 === 0 ? String(k) : k.toFixed(1)) + "K"; }
    var NAMES = { RealWood: "Hardwood", RealPlank: "Hardwood plank", Wood: "Pinewood", Plank: "Pinewood plank", ExoticWood: "Exotic wood", ExoticPlank: "Exotic plank",
                  MahoganyWood: "Mahogany wood", MahoganyPlank: "Mahogany plank", BronzeOre: "Copper ore", Bronze: "Bronze", Salpeter: "Saltpeter", Tool: "Tools" };   // 0.1.6
    NAMES.Brew = "Brew"; NAMES.BronzeSword = "Bronze sword"; NAMES.IronSword = "Iron sword"; NAMES.SteelSword = "Steel sword"; NAMES.Gold = "Gold bar";   // 0.1.10 Gold
    function label(res) { return NAMES[res] || String(res).replace(/([a-z])([A-Z])/g, "$1 $2"); }

    /* ---------- reading a request: amount and resource only ---------- */
    /* 0.1.7 (live 2026-10-25): the ways guild members write amounts and resources — "10", "1 stone", "5k", "3.5m",
       "3500k", "2.4 million", "2.4 mill", "20.000", "20,000", "20 000", "1,5k", "brew", "saltp", "hardwood log" */
    var ALIASES = [
        ["hardwood planks", "RealPlank"], ["hardwood plank", "RealPlank"], ["exotic planks", "ExoticPlank"], ["exotic plank", "ExoticPlank"],
        ["mahogany planks", "MahoganyPlank"], ["mahogany plank", "MahoganyPlank"], ["pinewood planks", "Plank"], ["pinewood plank", "Plank"], ["pine planks", "Plank"], ["pine plank", "Plank"],
        ["mahogany wood", "MahoganyWood"], ["mahogany log", "MahoganyWood"], ["exotic wood", "ExoticWood"], ["exotic log", "ExoticWood"], ["hardwood", "RealWood"], ["hard wood", "RealWood"],
        ["pinewood", "Wood"], ["pine wood", "Wood"], ["pine log", "Wood"], ["copper ore", "BronzeOre"], ["iron ore", "IronOre"], ["gold ore", "GoldOre"], ["coal ore", "Coal"],
        ["titanium ore", "TitaniumOre"], ["platinum ore", "PlatinumOre"], ["saltpetre", "Salpeter"], ["saltpeter", "Salpeter"], ["salpeter", "Salpeter"], ["saltp", "Salpeter"], ["salt", "Salpeter"],
        ["gunpowder", "Gunpowder"], ["powder", "Gunpowder"], ["bronze swords", "BronzeSword"], ["bronze sword", "BronzeSword"], ["iron swords", "IronSword"], ["iron sword", "IronSword"],
        ["steel swords", "SteelSword"], ["steel sword", "SteelSword"], ["longbows", "Longbow"], ["longbow", "Longbow"], ["crossbows", "Crossbow"], ["crossbow", "Crossbow"],
        ["bows", "Bow"], ["bow", "Bow"], ["cannons", "Cannon"], ["cannon", "Cannon"],
        ["planks", "Plank"], ["plank", "Plank"], ["logs", "Wood"], ["log", "Wood"], ["wood", "Wood"], ["stones", "Stone"], ["stone", "Stone"], ["marble", "Marble"],
        ["granite", "Granite"], ["tools", "Tool"], ["tool", "Tool"], ["copper", "BronzeOre"], ["bronze", "Bronze"], ["iron", "Iron"],
        ["steel", "Steel"], ["coal", "Coal"], ["gold", "Gold"], ["coins", "Coin"], ["coin", "Coin"], ["fish", "Fish"], ["meat", "Meat"],
        ["sausages", "Sausage"], ["sausage", "Sausage"], ["bread", "Bread"], ["flour", "Flour"], ["wheat", "Corn"], ["corn", "Corn"],
        ["water", "Water"], ["brew", "Brew"], ["beer", "Brew"], ["horses", "Horse"], ["horse", "Horse"], ["titanium", "Titanium"], ["platinum", "Platinum"],
        ["wheels", "Wheel"], ["wheel", "Wheel"], ["carriages", "Carriage"], ["carriage", "Carriage"]
    ];
    var MULT = { k: 1e3, thousand: 1e3, m: 1e6, mil: 1e6, mill: 1e6, million: 1e6, millions: 1e6, mio: 1e6, kk: 1e6 };
    var NOISE = /^(help|star|trade|trades|rt|me|for|please|pls|plz|can|could|you|u|i|have|give|send|spare|need|a|an|some|of|the|my|is|full|storage|thanks|thx|ty|max|about|around)$/;
    function ownNoise(w) {   // 0.1.19: the player's own names (chat reply words, in-game name) are noise, whoever the player is
        var C = root.DMA_Chat, out = [];
        try { if (C && C.words) (C.words() || []).forEach(function (n) { out.push(String(n).toLowerCase()); }); } catch (_) {}
        try { if (C && C.ownName) out.push(String(C.ownName() || "").toLowerCase()); } catch (_) {}
        return out.indexOf(w) >= 0;
    }
    function parseAsk(text) {
        var raw = String(text || "").toLowerCase();
        var t = " " + raw.replace(/[^a-z0-9.,\s]/g, " ").replace(/(\d)\s+(?=\d{3}\b)/g, "$1") + " ", res = null, i;   // "20 000" -> "20000"
        for (i = 0; i < ALIASES.length && !res; i++) if (new RegExp("[^a-z]" + ALIASES[i][0] + "s?[^a-z]").test(t)) res = ALIASES[i][1];
        var amount = null, m = /(\d+(?:[.,]\d+)?)\s*(kk|k|thousand|millions|million|mill|mil|mio|m)(?![a-z])/.exec(t);
        if (m) {
            var num = m[1];
            if (/^\d{1,3}[.,]\d{3}$/.test(num) && m[2] !== "m" && m[2].indexOf("mil") !== 0) num = num.replace(/[.,]/, "");   // "1.500k" read as 1500k
            amount = Math.round(parseFloat(num.replace(",", ".")) * MULT[m[2]]);
        } else { m = /(\d{1,3}(?:[.,]\d{3})+|\d+)/.exec(t); if (m) amount = parseInt(m[1].replace(/[.,]/g, ""), 10); }
        if (!(amount > 0)) amount = null;
        var unknown = "";                                                                // the word where a resource should be
        if (!res && amount) {
            var words = t.trim().split(/\s+/).filter(function (w) { return /^[a-z]{3,}$/.test(w) && !NOISE.test(w) && !MULT[w] && !ownNoise(w); });
            unknown = words[0] || "";
        }
        return { res: res, amount: amount, unknown: unknown };
    }

    /* ---------- the rules ---------- */
    function tierOf(level) { level = Number(level) || 0; return level < 30 ? "t1" : level < 60 ? "t2" : level < 80 ? "t3" : "t4"; }
    function givenTo(who, sinceMs) { var w = String(who).toLowerCase(), t = Date.now() - sinceMs; return gifts.filter(function (g) { return g.to.toLowerCase() === w && g.at >= t && g.status !== "declined" && g.status !== "returned" && !g.plenty; }); }   // 0.1.8: plenty gifts do not count
    /* 0.1.11: the game's own name for what was asked, when the reader's name holds nothing */
    var resListWritten = false;
    function gameRes(ask) {
        if (!ask || !ask.res || stock(ask.res) > 0) return ask;
        var G = gw(), L = []; try { L = G && G.resourceList ? G.resourceList() : []; } catch (_) { L = []; }
        if (!L.length) return ask;
        if (!resListWritten) { resListWritten = true; writeJson("dma-resources.json", { format: "dma-resources/1", at: new Date().toISOString(), resources: L }); }
        var words = [String(ask.res).toLowerCase(), label(ask.res).toLowerCase()], i, e, hit = null;
        for (i = 0; i < L.length && !hit; i++) { e = L[i]; if (words.indexOf(String(e.name).toLowerCase()) >= 0 || words.indexOf(String(e.label || "").toLowerCase()) >= 0) hit = e; }
        if (hit && hit.name !== ask.res) { info("star", "name", { asked: ask.res, game: hit.name, label: hit.label }); ask.res = hit.name; if (hit.label) NAMES[hit.name] = hit.label; }
        return ask;
    }
    function stock(res) { var G = gw(); try { return G && G.have ? Number(G.have(res)) || 0 : 0; } catch (_) { return 0; } }
    /* returns { amount, why } — amount 0 means decline with why; a smaller amount than asked carries why too */
    function plenty(res) {                                                             // 0.1.8
        var G = gw(); if (!G || !G.storageOf) return false;
        try { var s = G.storageOf(res); return !!(s && s.max > 0 && s.amount >= s.max * num("help.plentyPct", 90) / 100); } catch (_) { return false; }
    }
    function assessHelp(who, level, ask) {
        var tier = tierOf(level), max = num("help." + tier + ".max", 0);
        if (plenty(ask.res)) {                                                           // 0.1.8: plenty — no level limits
            var hv = stock(ask.res), cap = Math.floor(hv * num("help.floorPct", 20) / 100), am = Math.floor(Math.min(ask.amount, cap)), wy = am < ask.amount ? "that is what I give at once" : "";
            return am >= 1 ? { amount: am, why: wy, floor: Math.max(0, hv - cap), plenty: true } : { amount: 0, why: "I am short of " + label(ask.res) + " myself" };
        }
        if (givenTo(who, 3600000).length >= num("help.perHourPlayer", 1)) return { amount: 0, why: "you already asked this hour, try again later" };
        if (givenTo(who, 86400000).length >= num("help." + tier + ".perDay", 0)) return { amount: 0, why: "that is the most I give per day at your level, try tomorrow" };
        if (givenTo(who, 7 * 86400000).length >= num("help." + tier + ".perWeek", 0)) return { amount: 0, why: "that is the most I give per week at your level" };
        var amount = ask.amount, why = "";
        if (amount > max) { amount = max; why = "max " + kfmt(max) + " at your level"; }
        var have = stock(ask.res), floor = num("help.floor", 100000), pct = num("help.floorPct", 20);
        var room = Math.min(have - floor, Math.floor(have * pct / 100));
        var small = Math.floor(have * num("help.smallPct", 1) / 100);                    // 0.1.6: a small gift is always allowed
        if (small > room) room = small;
        if (room <= 0) return { amount: 0, why: "I am short of " + label(ask.res) + " myself" };
        if (amount > room) { amount = room; why = "that is what I can spare of " + label(ask.res); }
        amount = Math.floor(amount);
        if (amount < 1) return { amount: 0, why: "I am short of " + label(ask.res) + " myself" };
        return { amount: amount, why: why, floor: Math.max(0, have - room) };   // 0.1.6: the gateway keeps the same line
    }
    function costFor(res) {
        var c = String(pol("help.costRes", "Fish") || "Fish"), n = Math.max(1, Math.floor(num("help.costAmount", 1)));
        if (c === res) c = res === "Fish" ? "Stone" : "Fish";
        return { name: c, amount: n };
    }
    function openStar(who) { var w = String(who).toLowerCase(); return stars.filter(function (c) { return c.to.toLowerCase() === w && (c.status === "sent" || c.status === "check" || (c.status === "owed" && !c.explained)); }); }

    /* ---------- TK26: on request ---------- */
    function onHelp(rq) {
        state.requests += 1;
        var who = clean(rq.sender), G = gw(), cs = "gift:" + who + "@" + Date.now();
        record("gift", "request", { sender: who, actor: "requester", text: String(rq.text || "").slice(0, 200) }, cs);   // 0.1.14: every request first
        if (!(on("trade.auto") && on("trade.help.on"))) { record("gift", "decline", { sender: who, reason: "help is switched off; the player will get back to you" }, cs); say("@" + who + ": got it, " + owner() + " will get back to you soon.", "help-off"); return; }
        var ask = gameRes(parseAsk(rq.text));
        if (!ask.res && ask.unknown) { record("gift", "decline", { sender: who, reason: "unknown resource " + ask.unknown }, cs); say("@" + who + ": I don't know the resource \"" + ask.unknown + "\" — use its name in the game, e.g. \"" + owner() + " help 5K stone\"", "help-unk"); return; }   // 0.1.7
        if (!ask.res || !ask.amount) { record("gift", "decline", { sender: who, reason: "unclear: how much of what" }, cs); say("@" + who + ": how much of what? e.g. \"" + owner() + " help 5K stone\"", "help-ask"); return; }
        var mb = G && G.guildMember ? G.guildMember(rq.sender) : null;
        if (!mb) { decline("gift", who, ask, "I can't find you in the guild list", cs); return; }
        var a = assessHelp(who, mb.level, ask);
        if (!a.amount) { decline("gift", who, ask, a.why, cs); return; }
        record("gift", "promise", { sender: who, level: mb.level, res: ask.res, amount: a.amount, asked: ask.amount, why: a.why }, cs);
        var out = G.sendFriendTrade(rq.sender, { name: ask.res, amount: a.amount }, costFor(ask.res), { floor: a.floor != null ? a.floor : num("help.floor", 100000), tag: "help" });
        if (!out || !out.ok) { decline("gift", who, ask, "the trade could not be sent (" + ((out && out.reason) || "no gateway") + ")", cs, true); return; }
        var before0 = []; try { before0 = (G.tradeOutcomes ? G.tradeOutcomes(rq.sender) : []).map(function (o) { return o.id; }); } catch (_) {}
        gifts.push({ to: who, level: mb.level, res: ask.res, amount: a.amount, at: Date.now(), status: "sent", outcomeIds: before0, plenty: !!a.plenty, caseId: cs }); save();
        state.given += 1;
        record("gift", "execute", { sender: who, res: ask.res, amount: a.amount }, cs);
        var c = costFor(ask.res);
        say("@" + who + ": sent you " + kfmt(a.amount) + " " + label(ask.res) + " (for " + c.amount + " " + label(c.name) + ")" + (a.why ? " — " + a.why : "") + ". Have fun!", "help-da");
        record("gift", "declare", { sender: who }, cs);
    }
    function decline(tk, who, ask, why, cs, promised) {        // 0.1.14: after a promise it is revoke promise + allow + decline
        state.declined += 1;
        var d = { sender: who, res: ask && ask.res, amount: ask && ask.amount, reason: why };
        if (promised) giveUp(tk, cs, d); else record(tk, "decline", d, cs);
        say("@" + who + ": sorry, " + why + ".", tk === "gift" ? "help-dc" : "star-dc");
    }

    /* ---------- TK27: on request ---------- */
    function onStar(rq) {
        state.requests += 1;
        var who = clean(rq.sender), G = gw(), scs = rq.caseId || ("star:" + who + "@" + Date.now());
        if (!rq.caseId) record("star", "request", { sender: who, actor: "requester", text: String(rq.text || "").slice(0, 200) }, scs);   // 0.1.14: every request first; a waiting one keeps its case
        if (!(on("trade.auto") && on("trade.star.on"))) { record("star", "decline", { sender: who, reason: "star trades are switched off; the player will get back to you" }, scs); say("@" + who + ": got it, " + owner() + " will get back to you soon.", "star-off"); return; }
        var ask = gameRes(parseAsk(rq.text));
        if (!ask.res && ask.unknown) { record("star", "decline", { sender: who, reason: "unknown resource " + ask.unknown }, scs); say("@" + who + ": I don't know the resource \"" + ask.unknown + "\" — use its name in the game, e.g. \"" + owner() + " star trade 20K plank\"", "star-unk"); return; }   // 0.1.7
        if (!ask.res || !ask.amount) { record("star", "decline", { sender: who, reason: "unclear: how much of what" }, scs); say("@" + who + ": a star trade of how much of what? e.g. \"" + owner() + " star trade 20K plank\"", "star-ask"); return; }
        var open = openStar(who);
        if (open.length) {
            var o = open[0];
            if (o.status === "owed") record("star", "decline", { sender: who, res: ask.res, amount: ask.amount, reason: "open star trade " + o.status }, scs);
            if (o.status === "owed") { say("@" + who + ": before a new star trade — " + kfmt(o.debt) + " " + label(o.res) + " of the last one has not come back yet. Is something wrong? Let's sort that out first.", "star-owed"); return; }
            // 0.1.9: undetermined — say so, flag it for the player, keep the request
            o.peter = true; save();
            waiting[who.toLowerCase()] = { sender: rq.sender, text: rq.text, kind: "star", at: Date.now(), caseId: scs };   // 0.1.14: the request stays requested
            info("star", "check-asked", { sender: who, res: o.res, amount: o.amount, t1: o.t1, t2: o.t2, of: caseOf(o, "star") }, scs);
            say("@" + who + ": I can't confirm yet that the star trade of " + hhmm(o.at) + " (" + kfmt(o.amount) + " " + label(o.res) + ") is finished. " + owner() + " will check it, then I'll do yours.", "star-open");
            return;
        }
        var mb = G && G.guildMember ? G.guildMember(rq.sender) : null;
        if (!mb) { decline("star", who, ask, "I can't find you in the guild list", scs); return; }
        var day = stars.filter(function (c) { return c.to.toLowerCase() === who.toLowerCase() && c.at >= Date.now() - 86400000; }).length;
        if (day >= num("star.perDay", 2)) { decline("star", who, ask, "that is the most star trades per day, try tomorrow", scs); return; }
        var amount = ask.amount, why = "";   // 0.1.1: no maximum but the stock
        if (stock(ask.res) < amount) {                                                   // 0.1.10: offer a round amount we have
            amount = roundDown(stock(ask.res));
            if (amount < 1) { decline("star", who, ask, "I have no " + label(ask.res), scs); return; }
            why = "I don't have " + kfmt(ask.amount) + ", so " + kfmt(amount);
            info("star", "counter", { sender: who, res: ask.res, asked: ask.amount, amount: amount, stock: stock(ask.res) }, scs);
        }
        var fish = costFor(ask.res);
        if (stock(fish.name) < fish.amount) { decline("star", who, ask, "I have no " + label(fish.name) + " to pay the second trade", scs); return; }
        record("star", "promise", { sender: who, level: mb.level, res: ask.res, amount: amount, asked: ask.amount, why: why }, scs);
        var t1 = G.sendFriendTrade(rq.sender, { name: ask.res, amount: amount }, fish, { floor: 0, tag: "star 1" });
        if (!t1 || !t1.ok) { decline("star", who, ask, "the trade could not be sent (" + ((t1 && t1.reason) || "no gateway") + ")", scs, true); return; }
        var t2 = G.sendFriendTrade(rq.sender, fish, { name: ask.res, amount: amount }, { floor: 0, tag: "star 2" });
        var before = []; try { before = (G.tradeOutcomes ? G.tradeOutcomes(rq.sender) : []).map(function (o) { return o.id; }); } catch (_) {}   // older outcome mails are not ours
        var cs = { to: who, res: ask.res, amount: amount, at: Date.now(), status: "sent", t1: "open", t2: t2 && t2.ok ? "open" : "unsent", debt: 0, explained: false, outcomeIds: before, caseId: scs };
        stars.push(cs); save();
        state.starSent += 1;
        record("star", "execute", { sender: who, res: ask.res, amount: amount, second: !!(t2 && t2.ok) }, scs);
        if (t2 && t2.ok) record("star", "declare", { sender: who }, scs);   // 0.1.14: both trades sent and said
        if (!(t2 && t2.ok)) { info("star", "second trade not sent", { sender: who }, scs); cs.status = "check"; say("@" + who + ": I sent the first trade (" + kfmt(amount) + " " + label(ask.res) + ") but the second could not be sent — " + owner() + " will fix it.", "star-half"); return; }
        say("@" + who + ": star trade sent" + (why ? " (" + why + ")" : "") + ". Accept FIRST the trade that gives you " + kfmt(amount) + " " + label(ask.res) + " (it goes to your star), THEN the one that asks " + kfmt(amount) + " back.", "star-pm");
    }

    /* ---------- TK27: watching the outcome, the debt and the return ---------- */
    function whichTrade(cs, o) {
        if (o.offer && o.offer.name === cs.res && o.offer.amount === cs.amount) return "t1";   // we offered the resource
        if (o.costs && o.costs.name === cs.res && o.costs.amount === cs.amount) return "t2";   // we asked it back
        return null;            // 0.1.9: another trade of ours, or unreadable — never guessed by order
    }
    function watch(cs, now, G) {
        if (cs.status === "sent") {
            (G.tradeOutcomes ? G.tradeOutcomes(cs.to) : []).forEach(function (o) {
                if (cs.outcomeIds.indexOf(o.id) >= 0) return;
                var readable = !!(o.offer || o.costs);                                          // 0.1.9
                if (!readable && G.requestMailBody && !cs["asked" + o.id]) { cs["asked" + o.id] = 1; G.requestMailBody(o.id); return; }
                cs.outcomeIds.push(o.id);
                if (!readable) { info("star", "outcome-unread", { sender: cs.to, mail: o.id, outcome: o.outcome }, caseOf(cs, "star")); return; }
                var w = whichTrade(cs, o); if (w) cs[w] = o.outcome;
            });
            var hours = num("star.waitHours", 24) * 3600000, late = now - cs.at > hours;
            var sc = caseOf(cs, "star");
            if (cs.t1 === "accepted" && cs.t2 === "accepted") { cs.status = "done"; record("star", "accept", { sender: cs.to, actor: "requester", res: cs.res, amount: cs.amount }, sc); say("@" + cs.to + ": star trade complete, thanks!", "star-ac"); }
            else if (cs.t1 === "declined" && cs.t2 !== "accepted") { cs.status = "declined"; record("star", "reject", { sender: cs.to, actor: "requester", reason: "first trade declined" }, sc); }
            else if (cs.t1 !== "accepted" && cs.t2 === "accepted") { cs.status = "check"; record("star", "reject", { sender: cs.to, actor: "requester", reason: "second trade accepted without the first: the player owes it" }, sc); say("@" + cs.to + ": you accepted only the second trade, so " + owner() + " owes you " + kfmt(cs.amount) + " " + label(cs.res) + " — he will sort it out.", "star-chk"); }
            else if (cs.t1 === "accepted" && (cs.t2 === "declined" || late)) {
                cs.status = "owed"; cs.debt = cs.amount;
                record("star", "reject", { sender: cs.to, actor: "requester", reason: "first trade accepted, second not: " + cs.amount + " " + cs.res + " owed" }, sc);   // 0.1.14
                record("star", "request", { sender: cs.to, actor: "star trader", res: cs.res, amount: cs.amount, reason: "send it back" }, "debt:" + sc);   // the debt is its own transaction
                say("@" + cs.to + ": the second trade (" + kfmt(cs.amount) + " " + label(cs.res) + " back) was not accepted. Could you send the " + label(cs.res) + " back when you can? One fish or another small thing as payment is fine.", "star-owed");
            } else if (late && cs.t1 !== "accepted") { cs.status = "expired"; record("star", "reject", { sender: cs.to, actor: "requester", tacit: true, reason: "no answer within " + num("star.waitHours", 24) + " h" }, sc); }
            save();
        } else if (cs.status === "owed") {
            (G.mails ? G.mails() : []).forEach(function (m) {
                var t = G.tradeOfMail ? G.tradeOfMail(m) : null;
                if (!t || t.needsBody || !t.sender || t.sender.toLowerCase() !== cs.to.toLowerCase() || cs.outcomeIds.indexOf(t.id) >= 0) return;
                if (!t.offer || t.offer.name !== cs.res) return;
                var r = G.acceptReturnTrade(t, cs.res, num("star.returnCostMax", 10));
                cs.outcomeIds.push(t.id);
                var dc = "debt:" + caseOf(cs, "star");
                if (!r || !r.ok) { info("star", "return-refused", { sender: cs.to, trade: t.id, reason: r && r.reason }, dc); return; }
                cs.debt = Math.max(0, cs.debt - t.offer.amount);
                record("star", "execute", { sender: cs.to, actor: "requester", res: cs.res, amount: t.offer.amount, debt: cs.debt }, dc);   // 0.1.14: was "returned"
                if (cs.debt <= 0) { record("star", "declare", { sender: cs.to, actor: "requester (observed)" }, dc); record("star", "accept", { sender: cs.to, actor: "star trader" }, dc); }
                if (cs.debt <= 0) { cs.status = "returned"; say("@" + cs.to + ": got the " + label(cs.res) + " back, thank you!", "star-ret"); }
            });
            save();
        }
    }

    /* ---------- 0.1.3: outcome of a gift, and revocation (DEMO) for gifts and star trades ---------- */
    var REVOKE = /\b(cancel+(ed)?|undo|never\s*mind|nvm|changed my mind|reverse|take (it )?back|laat maar|terugdraaien|annuleer|niet meer nodig)\b/i;
    var revokeSeen = {};
    function revokeLine(who, since) {
        var lines = [];
        try { if (root.DMA_Chat && root.DMA_Chat.linesFrom) lines = root.DMA_Chat.linesFrom(who, since) || []; } catch (_) {}
        for (var i = 0; i < lines.length; i++) {
            var key = who + "|" + (lines[i].at || "") + "|" + lines[i].text;
            if (revokeSeen[key] || !REVOKE.test(String(lines[i].text || ""))) continue;
            revokeSeen[key] = true; return String(lines[i].text);
        }
        return "";
    }
    function watchGift(g, now, G) {
        if (g.status === "sent" || g.status === "revoke-asked") {
            (G.tradeOutcomes ? G.tradeOutcomes(g.to) : []).forEach(function (o) {
                if ((g.outcomeIds || []).indexOf(o.id) >= 0) return;
                if (o.offer && !(o.offer.name === g.res && o.offer.amount === g.amount)) return;   // another trade of ours
                if (!o.offer && G.requestMailBody && !g["asked" + o.id]) { g["asked" + o.id] = 1; G.requestMailBody(o.id); return; }
                (g.outcomeIds = g.outcomeIds || []).push(o.id);
                if (!o.offer) return;                                    // 0.1.9: unreadable — never guessed
                if (o.costs && o.costs.name === g.res) return;           // 0.1.9: a trade asking it back is not this gift
                var gc = caseOf(g, "gift");
                if (o.outcome === "declined") { var wasRv = g.status === "revoke-asked"; g.status = "declined"; if (wasRv) info("gift", "trade declined: undone", { sender: g.to }, gc); else record("gift", "reject", { sender: g.to, actor: "requester", res: g.res, amount: g.amount }, gc); if (wasRv) say("@" + g.to + ": declined, so it's undone. Thanks!", "help-cxd"); }
                else { var wasRv2 = g.status === "revoke-asked"; g.status = wasRv2 ? "return-open" : "accepted";
                       if (wasRv2) { record("gift", "request", { sender: g.to, actor: "requester", reason: "undo after all: send it back" }, "return:" + gc); record("gift", "promise", { sender: g.to, actor: "helper" }, "return:" + gc); }
                       else record("gift", "accept", { sender: g.to, actor: "requester", res: g.res, amount: g.amount }, gc);
                       if (g.status === "return-open") say("@" + g.to + ": you accepted it after all — send the " + kfmt(g.amount) + " " + label(g.res) + " back with a trade when you can (1 fish is fine).", "help-ret"); }
            });
        }
        if (g.status === "return-open") {
            (G.mails ? G.mails() : []).forEach(function (m) {
                var t = G.tradeOfMail ? G.tradeOfMail(m) : null;
                if (!t || t.needsBody || !t.sender || t.sender.toLowerCase() !== g.to.toLowerCase() || (g.outcomeIds || []).indexOf(t.id) >= 0 || !t.offer || t.offer.name !== g.res) return;
                var r = G.acceptReturnTrade(t, g.res, num("star.returnCostMax", 10));
                (g.outcomeIds = g.outcomeIds || []).push(t.id);
                if (r && r.ok) { g.status = "returned"; var rc = "return:" + caseOf(g, "gift"); record("gift", "execute", { sender: g.to, res: g.res, amount: t.offer.amount }, rc); record("gift", "declare", { sender: g.to }, rc); record("gift", "accept", { sender: g.to, actor: "requester (tacit)" }, rc); say("@" + g.to + ": got it back, thanks — undone.", "help-back"); }
            });
        }
        if (now - g.at < 86400000 && (g.status === "sent" || g.status === "accepted")) {
            var tx = revokeLine(g.to, g.at);
            if (tx) {
                var gc2 = caseOf(g, "gift");   // 0.1.14: before the accept a revocation of the request; after it a counter-transaction
                if (g.status === "sent") withdraw("gift", gc2, { sender: g.to, actor: "requester", text: tx.slice(0, 200) }, "helper");
                else { record("gift", "request", { sender: g.to, actor: "requester", text: tx.slice(0, 200), reversalOf: gc2 }, "return:" + gc2); record("gift", "promise", { sender: g.to, actor: "helper" }, "return:" + gc2); }
                if (g.status === "sent") { g.status = "revoke-asked"; say("@" + g.to + ": no problem — decline my trade in your inbox and it's undone.", "help-cx"); }
                else { g.status = "return-open"; say("@" + g.to + ": no problem — send the " + kfmt(g.amount) + " " + label(g.res) + " back with a trade (1 fish is fine) and I'll accept it.", "help-un"); }
            }
        }
    }
    function revokeStar(cs, now) {
        if (now - cs.at > 86400000 || cs.status === "returned" || cs.status === "settled" || cs.status === "declined" || cs.status === "expired") return;
        var tx = revokeLine(cs.to, cs.at); if (!tx) return;
        var vc = caseOf(cs, "star");   // 0.1.14: was "revoke"
        if (cs.status === "done") info("star", "nothing to undo", { sender: cs.to, text: tx.slice(0, 200) }, vc);
        else if (cs.status === "sent" && cs.t1 !== "accepted") withdraw("star", vc, { sender: cs.to, actor: "requester", text: tx.slice(0, 200) }, "star trader");
        else info("star", "undo asked", { sender: cs.to, status: cs.status, text: tx.slice(0, 200) }, vc);
        if (cs.status === "done") say("@" + cs.to + ": nothing to undo — both star trades are complete, we are even.", "star-un0");
        else if (cs.status === "sent" && cs.t1 !== "accepted") say("@" + cs.to + ": no problem — decline both of my trades in your inbox and it's undone.", "star-cx");
        else say("@" + cs.to + ": no problem — send the " + kfmt(cs.status === "owed" ? cs.debt : cs.amount) + " " + label(cs.res) + " back with a trade (1 fish is fine) and I'll accept it.", "star-un");
        save();
    }

    /* ---------- 0.1.5 TK28: a star trade we ask for ourselves ---------- */
    var ASK_RES = ["Stone", "Plank", "Wood", "Marble", "Corn", "Water", "Flour", "Bread", "Sausage", "Fish", "Meat", "Coal", "Tool", "Granite", "RealPlank", "RealWood",
                   "ExoticPlank", "MahoganyPlank", "IronOre", "Iron", "Steel", "BronzeOre", "Bronze", "GoldOre", "Gold", "Coin", "Horse", "Salpeter", "TitaniumOre", "Titanium"];
    var SEND_BACK = /send (it |them |the resources? )?back|return (it|them)|you send back|send me back/i;
    function openAsk() {
        var now = Date.now();
        asks.forEach(function (a) { if (a.status === "asked" && now - a.at > 2 * 3600000) { a.status = "closed"; a.reason = "no answer within 2 h"; withdraw("ask", caseOf(a, "ask"), { res: a.res, reason: a.reason }, "guild (tacit)"); save(); } });   // 0.1.13
        return asks.filter(function (a) { return a.status !== "done" && a.status !== "closed"; })[0] || null;
    }
    function askTick(now, G) {
        var a = openAsk();
        if (!a) {
            if (!(on("trade.auto") && on("trade.ask.on")) || !G.storageOf) return;
            var last = asks.length ? asks[asks.length - 1].at : 0;
            if (now - last < num("trade.ask.everyMin", 60) * 60000) return;
            var full = ASK_RES.map(function (r) { try { return G.storageOf(r); } catch (_) { return null; } }).filter(function (s) { return s && s.full && s.amount >= 1000; });
            if (!full.length) return;
            full.sort(function (x, y) { return y.amount - x.amount; });
            var s = full[0], k = Math.floor(s.amount / 1000);
            var text = "Who can do a star trade please? " + label(s.name) + ", max " + k + "k. Let me know if you send two trades or want me to send the resources back";
            var pm = permitFor("ask", s.name, now);                                                                  // 0.1.20 (ADR 0089)
            if (!pm) { holdForPlayer("ask", s.name, k * 1000, text, now); return; }
            if (!say(text, "ask-" + now)) return;
            usePermit(pm, now);
            var before = []; try { before = (G.mails ? G.mails() : []).map(function (m) { return Number(m.id); }); } catch (_) {}
            asks.push({ res: s.name, n: k * 1000, at: now, status: "asked", seen: before, caseId: "ask:" + s.name + "@" + now }); save();
            record("ask", "request", { res: s.name, amount: k * 1000, stock: s.amount, max: s.max }, "ask:" + s.name + "@" + now);
            return;
        }
        if (now - lastHeadersAt >= HEADERS_MS) { lastHeadersAt = now; try { if (G.ensureMailPanel) G.ensureMailPanel(); if (G.requestInboxHeaders) G.requestInboxHeaders(); } catch (_) {} }
        var trades = (G.mails ? G.mails() : []).map(function (m) { return G.tradeOfMail ? G.tradeOfMail(m) : null; })
            .filter(function (t) { return t && !t.needsBody && t.offer && t.costs && (a.seen || []).indexOf(Number(t.id)) < 0; });
        var maxCost = num("star.returnCostMax", 10);
        if (a.status === "asked") {
            if (now - a.at > 6 * 3600000) { a.status = "closed"; withdraw("ask", caseOf(a, "ask"), { res: a.res, reason: "no answer within 6 h" }, "guild (tacit)"); save(); return; }
            try { if (G.storageOf && !G.storageOf(a.res).full && !trades.length) { a.status = "closed"; withdraw("ask", caseOf(a, "ask"), { res: a.res, reason: "storage no longer full" }, "guild (tacit)"); save(); return; } } catch (_) {}
            var first = trades.filter(function (t) { return t.offer.name === a.res && t.offer.amount <= a.n && t.costs.amount <= maxCost && (t.lots || 1) === 1; })[0];
            if (!first) return;
            if (!(G.guildMember && G.guildMember(first.sender))) return;   // only a guild member
            a.status = "promised"; a.from = first.sender; a.t1 = first.id; a.amount = first.offer.amount; a.seenAt = now; a.mode = "";
            record("ask", "promise", { sender: first.sender, actor: first.sender, res: a.res, amount: first.offer.amount, asked: a.n }, caseOf(a, "ask"));
            save();
        }
        var from = String(a.from || "").toLowerCase();
        var mine = trades.filter(function (t) { return String(t.sender || "").toLowerCase() === from; });
        if (a.status === "promised") {
            var t1 = mine.filter(function (t) { return t.id === a.t1; })[0];
            if (!t1) { a.status = "asked"; delete a.from; save(); return; }                 // withdrawn: wait for another
            var t2 = mine.filter(function (t) { return t.id !== a.t1 && t.costs.name === a.res && t.costs.amount === a.amount && t.offer.amount <= maxCost; })[0];
            var saysBack = false; try { saysBack = (root.DMA_Chat && root.DMA_Chat.linesFrom ? root.DMA_Chat.linesFrom(a.from, a.at) : []).some(function (l) { return SEND_BACK.test(String(l.text || "")); }); } catch (_) {}
            if (t2) a.mode = "two", a.t2 = t2.id; else if (saysBack || now - a.seenAt >= 120000) a.mode = "one";
            if (!a.mode) return;
            var r1 = G.acceptOneTrade(t1, maxCost);                                          // his first trade: into our star
            if (!r1 || !r1.ok) { withdraw("ask", caseOf(a, "ask"), { sender: a.from, reason: "his trade could not be accepted: " + (r1 && r1.reason) }, a.from + " (tacit)"); a.status = "closed"; save(); return; }
            a.status = "first"; a.firstAt = now; save();
            record("ask", "execute", { sender: a.from, step: "first", trade: t1.id, res: a.res, amount: a.amount, mode: a.mode }, caseOf(a, "ask"));
            return;
        }
        if (a.status === "first") {
            if (mine.some(function (t) { return t.id === a.t1; })) {                          // never pass: the first must be gone
                if (now - a.firstAt > 180000) { a.status = "closed"; withdraw("ask", caseOf(a, "ask"), { sender: a.from, reason: "first trade still in the inbox" }, a.from + " (tacit)"); say("@" + clean(a.from) + ": your trade did not go through on my side, " + owner() + " will check.", "ask-fl"); save(); }
                return;
            }
            if (now - a.firstAt < 8000) return;                                               // let the first settle
            var ok = false;
            if (a.mode === "two") {
                var t2b = mine.filter(function (t) { return t.id === a.t2; })[0];
                if (t2b) { var r2 = G.acceptOneTrade(t2b, null); ok = !!(r2 && r2.ok); }
                if (!t2b) a.mode = "one";                                                     // he withdrew it: send back ourselves
            }
            if (a.mode === "one") {
                var back = G.sendFriendTrade(a.from, { name: a.res, amount: a.amount }, costFor(a.res), { floor: 0, tag: "star back" });
                ok = !!(back && back.ok);
            }
            a.status = ok ? "done" : "closed"; a.doneAt = now; save();
            if (ok) record("ask", "execute", { sender: a.from, step: "second", mode: a.mode, res: a.res, amount: a.amount }, caseOf(a, "ask"));
            else withdraw("ask", caseOf(a, "ask"), { sender: a.from, reason: "our side could not be completed (" + a.mode + ")" }, a.from + " (tacit)");   // 0.1.14: was "fail"
            if (ok) { record("ask", "accept", { sender: a.from, actor: "star asker" }, caseOf(a, "ask")); say("@" + clean(a.from) + ": thanks a lot! " + (a.mode === "one" ? "I sent the " + kfmt(a.amount) + " " + label(a.res) + " back." : "both trades done."), "ask-da"); }
            else say("@" + clean(a.from) + ": I couldn't complete my side, " + owner() + " will check.", "ask-fl2");
        }
    }

    /* ---------- 0.1.20 (ADR 0089): asking the guild needs the player's permission ---------- */
    var PERMIT_FILE = "dma-guild-ask-permit.json", HELD_EVERY_MS = 2 * 3600000;
    function permitList() { var o = fileRead(PERMIT_FILE), l = (o && o.permits) || []; return (Array.isArray(l) ? l : []).concat(permGrants); }
    function permitKey(p) { return String(p.kind) + "|" + String(p.res || "") + "|" + String(p.until); }
    function permitFor(kind, res, now) {
        var l = permitList(), i, p, until;
        for (i = 0; i < l.length; i++) {
            p = l[i]; if (!p || p.kind !== kind) continue;
            if (p.res && res && String(p.res).toLowerCase() !== String(res).toLowerCase()) continue;
            if (p.res && !res) continue;
            until = typeof p.until === "number" ? p.until : Date.parse(p.until);
            if (!(until > now) || permUsed[permitKey(p)]) continue;
            return p;
        }
        return null;
    }
    function usePermit(p, now) { permUsed[permitKey(p)] = now; save(); }
    /* no permission: nothing is said and nothing is sent; the player is told what DMA wanted to ask (at most once per 2 h per kind and resource) */
    function holdForPlayer(kind, res, amount, line, now) {
        var k = kind + "|" + (res || ""); state.held = (state.held || 0) + 1;
        if (permAskedAt[k] && now - permAskedAt[k] < HELD_EVERY_MS) return;
        permAskedAt[k] = now;
        info(kind, "guild ask held for the player", { res: res || null, amount: amount || null, line: line, heldBy: "player",
            reason: "asking the guild needs the player's permission — the player's help is asked" });
    }
    function permitGuildAsk(kind, res, minutes) {
        if (!SET_KIND[kind] || kind === "gift" || kind === "star") return { ok: false, reason: "not an ask: " + kind };
        var p = { kind: kind, res: res || "", until: Date.now() + Math.max(1, Number(minutes) || 60) * 60000, by: "player" };
        permGrants.push(p); return { ok: true, permit: p };
    }

    /* ---------- 0.1.18: PURCHASE from a guild member (last resort) and ASKED ROUND TRADE ---------- */
    var YES = /\b(yes|yep|yeah|yup|sure|ok|okay|oke|deal|ja|jep|prima|goed|i can|i will|i'll|can do|will do|kan|doe ik|ik heb|i have|got it|here|mine|send it|go ahead)\b/i;
    var NO = /\b(no|nope|nee|sorry|can't|cant|cannot|don't|dont|won't|wont|none|niet)\b/i;
    function reading(text) { var t = String(text || ""); if (NO.test(t) && !YES.test(t)) return "no"; if (YES.test(t) && !/\?/.test(t) && !NO.test(t)) return "yes"; return "unclear"; }
    function chatLines(since) { try { return (root.DMA_Chat && root.DMA_Chat.recent) ? root.DMA_Chat.recent(since) : []; } catch (_) { return []; } }
    function valueOf(r) { try { var s = root.DMA_Value && root.DMA_Value.state && root.DMA_Value.state(), x = s && s.result && s.result.by && s.result.by[r]; return x && x.seconds > 0 ? x.seconds : null; } catch (_) { return null; } }
    function stockOf() { try { return (root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow()) || {}; } catch (_) { return {}; } }
    /* what we pay: a resource the stock holds plenty of, priced by the value list: M of it is worth what N of the bought resource is worth, never above maxPricePct % */
    function payFor(res, amount, maxPct) {
        var vb = valueOf(res), st = stockOf(), best = null; if (!vb) return null;
        Object.keys(st).forEach(function (r) {
            if (r === res) return; var v = valueOf(r); if (!v) return;
            var m = Math.ceil(amount * vb * Math.min(100, Number(maxPct) || 100) / 100 / v); if (m < 1) m = 1;
            if (Number(st[r]) < 2 * m) return;
            var plenty = Number(st[r]) / m; if (!best || plenty > best.plenty) best = { resource: r, amount: m, plenty: plenty };
        });
        return best;
    }
    function memberOk(G, who) { try { return !!(G && G.guildMember && G.guildMember(who)); } catch (_) { return false; } }
    function mineLine(sender) { return String(sender || "").toLowerCase() === String(owner()).toLowerCase(); }
    function askPurchase(res, amount, opts) {
        opts = opts || {}; amount = Math.ceil(Number(amount) || 0);
        if (!res || !(amount > 0)) return { ok: false, reason: "nothing to buy" };
        if (purchases.some(function (p) { return p.res === res && (p.status === "asked" || p.status === "agreed" || p.status === "sent"); })) return { ok: false, reason: "already asked for " + res };
        var pay = payFor(res, amount, opts.maxPricePct); if (!pay) return { ok: false, reason: "nothing to pay with (no value or no plenty in stock)" };
        var at = Date.now(), cs = "purchase:" + res + "@" + at;
        var text = "Who sells me " + kfmt(amount) + " " + label(res) + "? I pay with " + kfmt(pay.amount) + " " + label(pay.resource) + " (same value). Say yes and I send you the trade";
        var pm = permitFor("purchase", res, at);                                                                   // 0.1.20 (ADR 0089)
        if (!pm) { holdForPlayer("purchase", res, amount, text, at); return { ok: false, held: true, reason: "asking the guild needs the player's permission" }; }
        if (!say(text, "purchase-" + at)) return { ok: false, reason: "the guild chat did not take the line" };
        usePermit(pm, at);
        purchases.push({ res: res, n: amount, pay: pay, at: at, status: "asked", caseId: cs, clarified: {} }); save();
        return { ok: true, caseId: cs };
    }
    function stockBefore(G, r) { try { return G && G.have ? Number(G.have(r)) || 0 : 0; } catch (_) { return 0; } }
    function purchaseTick(now, G) {
        purchases.forEach(function (p) {
            if (p.status === "asked") {
                if (now - p.at > 2 * 3600000) { p.status = "closed"; withdraw("purchase", p.caseId, { res: p.res, reason: "no one agreed within 2 h" }, "guild (tacit)"); save(); return; }
                var ls = chatLines(p.at).filter(function (l) { return !mineLine(l.sender) && memberOk(G, l.sender); }), i, l, r;
                for (i = 0; i < ls.length; i++) {
                    l = ls[i]; r = reading(l.text);
                    if (r === "yes") { p.status = "agreed"; p.from = l.sender; record("purchase", "promise", { sender: l.sender, actor: l.sender, res: p.res, amount: p.n }, p.caseId); break; }
                    if (r === "unclear" && !p.clarified[String(l.sender).toLowerCase()]) { p.clarified[String(l.sender).toLowerCase()] = true; say("@" + clean(l.sender) + ": do you mean you sell me " + kfmt(p.n) + " " + label(p.res) + "? yes or no", "purchase-q-" + now); save(); }
                }
                if (p.status !== "agreed") return;
            }
            if (p.status === "agreed") {
                p.before = stockBefore(G, p.res);
                var t = G.sendFriendTrade ? G.sendFriendTrade(p.from, { name: p.pay.resource, amount: p.pay.amount }, { name: p.res, amount: p.n }, { floor: 0, tag: "purchase" }) : { ok: false, reason: "no trade gateway" };
                if (!t || !t.ok) { p.status = "closed"; giveUp("purchase", p.caseId, { sender: p.from, res: p.res, reason: "the trade could not be made: " + (t && t.reason) }); say("@" + clean(p.from) + ": I couldn't make the trade (" + clean((t && t.reason) || "?") + "), " + owner() + " will check.", "purchase-fl-" + now); save(); return; }
                p.status = "sent"; p.sentAt = now; record("purchase", "execute", { sender: p.from, res: p.res, amount: p.n, pay: p.pay.resource, payAmount: p.pay.amount }, p.caseId);
                say("@" + clean(p.from) + ": I sent you the trade: " + kfmt(p.pay.amount) + " " + label(p.pay.resource) + " for " + kfmt(p.n) + " " + label(p.res) + ". Please accept", "purchase-s-" + now); save(); return;
            }
            if (p.status === "sent") {
                if (stockBefore(G, p.res) >= (p.before || 0) + p.n * 0.99) { p.status = "done"; record("purchase", "declare", { sender: p.from, actor: p.from + " (observed)", res: p.res, amount: p.n }, p.caseId); record("purchase", "accept", { actor: "resource supply manager" }, p.caseId); say("@" + clean(p.from) + ": received, thanks!", "purchase-d-" + now); save(); }
                else if (now - p.sentAt > 3 * 3600000) { p.status = "closed"; withdraw("purchase", p.caseId, { sender: p.from, res: p.res, reason: "not accepted within 3 h" }, p.from + " (tacit)"); save(); }
            }
        });
    }
    var RT_GIVE = { name: "Fish", amount: 1 }, RT_GET = { name: "Coin", amount: 1 };
    function askRoundTrade(opts) {
        opts = opts || {}; var now = Date.now();
        if (rts.some(function (r) { return r.status === "asked" || r.status === "agreed" || r.status === "sent"; })) return { ok: false, reason: "a round trade is already asked" };
        var at = now, cs = "rt:" + at;
        var text = "Who is up for a round trade? I send you two trades that cancel each other out (" + RT_GIVE.amount + " " + label(RT_GIVE.name) + " for " + RT_GET.amount + " " + label(RT_GET.name) + " and back). Say yes and I send them";
        var pm = permitFor("rt", null, at);                                                                        // 0.1.20 (ADR 0089)
        if (!pm) { holdForPlayer("rt", null, null, text, at); return { ok: false, held: true, reason: "asking the guild needs the player's permission" }; }
        if (!say(text, "rt-" + at)) return { ok: false, reason: "the guild chat did not take the line" };
        usePermit(pm, at);
        rts.push({ at: at, status: "asked", caseId: cs, reason: opts.reason || "", clarified: {} }); rtWanted = null; save();
        record("rt", "request", { reason: opts.reason || "" }, cs);
        return { ok: true, caseId: cs };
    }
    function dayN(list, now) { return list.filter(function (r) { return now - r.at < 86400000; }).length; }
    function rtTick(now, G) {
        if (rtWanted && on("trade.auto") && on("trade.rt.ask.on") && dayN(rts, now) < num("trade.rt.ask.maxPerDay", 2) && (!rts.length || now - rts[rts.length - 1].at >= num("trade.rt.ask.everyMin", 120) * 60000)) askRoundTrade({ reason: rtWanted.reason });
        rts.forEach(function (r) {
            if (r.status === "asked") {
                if (now - r.at > 2 * 3600000) { r.status = "closed"; withdraw("rt", r.caseId, { reason: "no one agreed within 2 h" }, "guild (tacit)"); save(); return; }
                var ls = chatLines(r.at).filter(function (l) { return !mineLine(l.sender) && memberOk(G, l.sender); }), i, l, x;
                for (i = 0; i < ls.length; i++) {
                    l = ls[i]; x = reading(l.text);
                    if (x === "yes") { r.status = "agreed"; r.from = l.sender; record("rt", "promise", { sender: l.sender, actor: l.sender }, r.caseId); break; }
                    if (x === "unclear" && !r.clarified[String(l.sender).toLowerCase()]) { r.clarified[String(l.sender).toLowerCase()] = true; say("@" + clean(l.sender) + ": do you want the round trade (two trades that cancel each other out)? yes or no", "rt-q-" + now); save(); }
                }
                if (r.status !== "agreed") return;
            }
            if (r.status === "agreed") {
                r.before = { give: stockBefore(G, RT_GIVE.name), get: stockBefore(G, RT_GET.name) };
                var t1 = G.sendFriendTrade ? G.sendFriendTrade(r.from, RT_GIVE, RT_GET, { floor: 0, tag: "rt 1" }) : { ok: false, reason: "no trade gateway" };
                var t2 = t1 && t1.ok ? G.sendFriendTrade(r.from, RT_GET, RT_GIVE, { floor: 0, tag: "rt 2" }) : null;
                if (!t1 || !t1.ok || !t2 || !t2.ok) { r.status = "closed"; giveUp("rt", r.caseId, { sender: r.from, reason: "the trades could not be made: " + clean((t1 && !t1.ok ? t1.reason : t2 && t2.reason) || "?") }); say("@" + clean(r.from) + ": I couldn't make the trades, " + owner() + " will check.", "rt-fl-" + now); save(); return; }
                r.status = "sent"; r.sentAt = now; record("rt", "execute", { sender: r.from, trades: 2 }, r.caseId);
                say("@" + clean(r.from) + ": both trades are sent (they cancel each other out). Please accept both", "rt-s-" + now); save(); return;
            }
            if (r.status === "sent") {
                if (stockBefore(G, RT_GIVE.name) >= r.before.give && stockBefore(G, RT_GET.name) >= r.before.get) { r.status = "done"; record("rt", "declare", { sender: r.from, actor: r.from + " (observed)" }, r.caseId); record("rt", "accept", { actor: "trade manager" }, r.caseId); say("@" + clean(r.from) + ": thanks, both done!", "rt-d-" + now); save(); }
                else if (now - r.sentAt > 3600000) { r.status = "closed"; withdraw("rt", r.caseId, { sender: r.from, reason: "not accepted within 1 h" }, r.from + " (tacit)"); save(); }
            }
        });
    }

    function away() { try { var C = root.DMA_Control; return !!(C && typeof C.atHome === "function" && !C.atHome()); } catch (_) { return false; } }   // 0.1.12
    function tick(now) {
        if (away()) return;
        now = now || Date.now();
        state.ticks += 1;
        try {
            var reqs = (root.DMA_Chat && root.DMA_Chat.helpRequests) ? root.DMA_Chat.helpRequests(3900000) : [];
            reqs.forEach(function (r) {
                var key = r.sender + "|" + r.at + "|" + r.kind;
                if (seenRq[key]) return; seenRq[key] = true;
                if (r.kind === "star") onStar(r); else onHelp(r);
            });
            var G = gw(), live = stars.filter(function (c) { return c.status === "sent" || c.status === "owed"; });
            var liveGifts = gifts.filter(function (g) { return now - g.at < 2 * 86400000 && (g.status === "sent" || g.status === "accepted" || g.status === "revoke-asked" || g.status === "return-open"); });
            if (G && (live.length || liveGifts.length)) {
                if (now - lastHeadersAt >= HEADERS_MS) { lastHeadersAt = now; try { if (G.ensureMailPanel) G.ensureMailPanel(); if (G.requestInboxHeaders) G.requestInboxHeaders(); } catch (_) {} }
                live.forEach(function (c) { watch(c, now, G); });
                liveGifts.forEach(function (g) { watchGift(g, now, G); });
                if (liveGifts.length) save();
            }
            if (G) stars.forEach(function (c) { revokeStar(c, now); });   // 0.1.3
            if (G) askTick(now, G);                                        // 0.1.5
            if (G) { purchaseTick(now, G); rtTick(now, G); }               // 0.1.18
        } catch (e) { note("tick " + e); }
        if (now - lastStatusAt >= STATUS_MS) {
            lastStatusAt = now;
            writeJson("dma-help-status.json", { format: "dma-help-status/1", version: VERSION, at: new Date(now).toISOString(), state: state, gifts: gifts.slice(-30), stars: stars.slice(-20) });
        }
    }
    function start() {
        if (timer) return;
        state.startedAt = new Date().toISOString();
        load();
        if (root.DMA_HELP_NO_TIMER) return;
        timer = root.setInterval(function () { try { tick(); } catch (e) { note("tick " + e); } }, TICK_MS);
    }
    root.DMA_Help = {
        version: VERSION,
        tick: tick,
        parseAsk: parseAsk,
        askPurchase: askPurchase, askRoundTrade: askRoundTrade, wantRoundTrade: function (reason) { rtWanted = { at: Date.now(), reason: String(reason || "") }; return true; },   // 0.1.18
        permitGuildAsk: permitGuildAsk,   // 0.1.20 (ADR 0089)
        purchases: function () { return JSON.parse(JSON.stringify(purchases)); }, roundTrades: function () { return JSON.parse(JSON.stringify(rts)); },
        tierOf: tierOf,
        status: function () { return JSON.parse(JSON.stringify(state)); },
        gifts: function () { return JSON.parse(JSON.stringify(gifts)); },
        stars: function () { return JSON.parse(JSON.stringify(stars)); },
        /* the player marks an unreturned star trade as explained: a new star trade may follow (the debt stays on record) */
        asks: function () { return JSON.parse(JSON.stringify(asks)); },
        explain: function (who) { var n = 0; stars.forEach(function (c) { if (c.status === "owed" && c.to.toLowerCase() === String(who).toLowerCase()) { c.explained = true; n++; } }); if (n) { save(); stars.forEach(function (c) { if (c.explained && c.status === "owed" && c.to.toLowerCase() === String(who).toLowerCase()) info("star", "explained by the player", { sender: clean(who) }, "debt:" + caseOf(c, "star")); }); } return n; },
        /* the player closes a debt by hand (settled outside the script) */
        /* 0.1.9: also a "sent" case (undetermined); a request kept waiting (at most 1 h) is then handled at once */
        settle: function (who) {
            var w = String(who).toLowerCase(), n = 0;
            stars.forEach(function (c) { if ((c.status === "owed" || c.status === "check" || c.status === "sent") && c.to.toLowerCase() === w) {
                if (c.status === "owed") withdraw("star", "debt:" + caseOf(c, "star"), { sender: clean(who), actor: "player", reason: "settled by the player" }, c.to + " (tacit)");   // 0.1.14: was "settled"
                else info("star", "settled by the player", { sender: clean(who) }, caseOf(c, "star"));
                c.status = "settled"; c.debt = 0; c.peter = false; n++; } });
            if (n) save();
            var q = waiting[w]; delete waiting[w];
            if (n && q && Date.now() - q.at <= 3600000) { try { onStar(q); } catch (e) { note("settle " + e); } }
            return n;
        }
    };
    start();
})(typeof window !== "undefined" ? window : this);
