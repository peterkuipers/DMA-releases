/*
 * GCAF app boot 0.2.1
 * Wires Policy + green PBCs + blue Overview.
 *
 * 0.2.1 (2026-11-01, test day: after every restart the console logs "policy instance made by the console: the boot
 *   script had not made it"): each boot step (create, load, start) is tried separately; a failure is kept in
 *   GCAF_AppBootError {step, error, at, tries} (and in dma-debug-log.txt) and the boot is retried every 5 s for 2 minutes, unless the console
 *   made the instance meanwhile. Unit: tests/unit/gcaf-app-boot.test.js; integration: after a restart the console
 *   log no longer shows the console-made line, or shows the boot error.
 * 0.2.0 (2026-10-24): boot only. The cycle (cycle flag, resume, 30 s cycle timer, 20 s scan
 * timer) and the second search path (autoSearchTick) are removed: DMA_Control's manager loop
 * ticks DMA_Demo, whose self-starters are switched by the player. One decider per act.
 * Load after: user_dma_control.js, user_gcaf_geologist_search.js,
 *             user_gcaf_management_suite.js, user_gcaf_overview.js, pbc-player-policy.js
 */
(function (root) {
    "use strict";

    if (root.GCAF_AppBooted) return;

    var policy = null, bootTries = 0;
    function note(line) {   // 0.2.1: one line in dma-debug-log.txt (read by the player and by the test report)
        try {
            var f = air.File.applicationDirectory.resolvePath("dma-debug-log.txt"), fs = new air.FileStream();
            fs.open(new air.File(f.nativePath), air.FileMode.APPEND);
            fs.writeUTFBytes(new Date().toISOString().slice(11, 19) + " " + line + "\n"); fs.close();
        } catch (_) {}
    }
    function bootPolicy() {
        if (root.GCAF_PlayerPolicyInstance) { policy = root.GCAF_PlayerPolicyInstance; return true; }   // the console made it
        bootTries += 1;
        var step = "missing GCAF_PlayerPolicy", p = null;
        try {
            if (!root.GCAF_PlayerPolicy || typeof root.GCAF_PlayerPolicy.create !== "function") throw new Error("pbc-player-policy.js not loaded yet");
            step = "create"; p = root.GCAF_PlayerPolicy.create();
            step = "load"; p.load();
            step = "start"; p.start();
            policy = p; root.GCAF_PlayerPolicyInstance = p; root.GCAF_AppBootError = null;
            return true;
        } catch (e) {
            root.GCAF_AppBootError = { step: step, error: String(e && e.message || e), at: Date.now(), tries: bootTries };
            if (bootTries === 1 || bootTries === 24) note("app boot: policy " + step + " failed (try " + bootTries + "): " + root.GCAF_AppBootError.error);
            return false;
        }
    }
    if (!bootPolicy() && typeof setInterval === "function") {
        var bootTimer = setInterval(function () {
            if (bootPolicy() || bootTries >= 24) { clearInterval(bootTimer); try { applyPolicyToGreen(); } catch (_) {} }
        }, 5000);
    }

    function applyPolicyToGreen() {
        if (!policy) return;
        var loc = root.GCAF_LocationManagementInstance;
        if (loc && policy.caps) {
            try {
                var c = policy.caps();
                var snap = loc.getSnapshot && loc.getSnapshot();
                if (snap) snap.caps = c;
            } catch (_) {}
        }
    }

    function policyHtml() {
        if (!policy) return "<div>Policy not loaded</div>";
        var v = policy.getPolicy();
        var html = "<div style='padding:8px;font:12px sans-serif'>";
        html += "<b>DMA Policy " + policy.version + "</b> — EVENT / ASSESS rules (no server send)<br/><br/>";
        var sw = policy.switches ? policy.switches() : [];
        var si;
        for (si = 0; si < sw.length; si++) html += sw[si].label + " (" + sw[si].actor + "): " + sw[si].on + "<br/>";
        html += "Operational sectors only: " + v["search.inPlayOnly"] + "<br/>";
        html += "Demolish threshold: " + v["demolish.threshold"] + "<br/>";
        html += "<br/>Caps: ";
        var i, r, caps = policy.caps();
        for (i = 0; i < policy.catalogR.length; i++) {
            r = policy.catalogR[i];
            html += r + "=" + caps[r] + " ";
        }
        html += "<br/><br/>Toggle in console: GCAF_PlayerPolicyInstance.requestChange('geo.auto', true)";
        html += "</div>";
        return html;
    }

    function showPolicy() {
        applyPolicyToGreen();
        try {
            if (typeof createModalWindow === "function") {
                createModalWindow("DMA_PlayerPolicy", "DMA Policy");
                if (typeof $ !== "undefined") $("#DMA_PlayerPolicy").html(policyHtml());
            }
        } catch (_) {}
        try {
            var v = policy ? policy.getPolicy() : {};
            game.showAlert("DMA Policy island=" + v["island.auto"] + " geo=" + v["geo.auto"] + " expo=" + v["expo.auto"] + " build=" + v["build.auto"] + " upgrade=" + v["upgrade.auto"] + " buff=" + v["buff.auto"] + " demo=" + v["demo.auto"]);
        } catch (_) {}
    }

    /* DMA Policy menu item removed — console is the only UI */

    applyPolicyToGreen();

    root.GCAF_App = {
        version: "0.2.1",
        bootError: function () { return root.GCAF_AppBootError || null; },
        showPolicy: showPolicy,
        applyPolicy: applyPolicyToGreen
    };
    root.GCAF_AppBooted = true;
    root.GCAF_SuiteVersion = "0.1.0";
})(typeof window !== "undefined" ? window : this);
