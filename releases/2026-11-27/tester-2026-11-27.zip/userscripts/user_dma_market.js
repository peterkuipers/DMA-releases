/*
 * DMA Market price keeper 0.1.0 — learns the MARKET PRICE of a resource from every read of the Trade Office (ADR 0076, backbone v3.20, DFS-55). It is the keeper of one derived fact: the market price in coin.
 *
 * 0.1.1 (2026-11-16, first live start): no dma-market.json appeared after the buyer read 450 offers. The fit built its matrix rows with Array.prototype.fill, an ES2015 method the
 *   client's embedded engine does not offer, so observe() threw inside the buyer's try and nothing was learned. Rows are now built with a plain loop. Nothing else changes.
 *   Unit: tests/unit/dma-market.test.js (the source uses no ES2015 array/string methods: fill, includes, find, from, assign, values; the fit still reproduces the fixture). Integration: unchanged.
 * 0.1.0 (2026-11-16, ADR 0076; author: the own-cost value list called oil offers "very favourable" and he judged them not favourable: "olie is onbetaalbaar", "you have to develop a good sense for that, what is cheap
 *   and what is expensive"): NEW.
 *   OBSERVES (it never scans: ADR 0040): the buyer feeds observe(offers, now) with the list it has just read from the panel. Each offer that gives a resource for a resource (no buff, not our own, get != pay,
 *     amounts > 0) is kept by tradeID (deduplicated; refreshed when seen again; at most MAX_KEPT = 2000, the oldest dropped; an offer not seen for 7 days is dropped).
 *   FITS a price per resource: each offer says  price(get) * amount(get) ~ price(pay) * amount(pay), i.e. ln P(get) - ln P(pay) = ln(amount(pay) / amount(get)). A weighted least-squares fit of ln P with Coin
 *     anchored at 1 (ln 0); 5 iterations; after each, an offer whose residual is beyond 2.5 times the robust spread (1.48 * the median |residual|) gets weight 0.1 (outliers are down-weighted, not removed). Only
 *     resources connected to Coin through the offers get a price.
 *   price(res) -> { coin, n, at } or null: n = the number of offers the price rests on; fewer than MIN_N = 3 counts as unknown (null). Coin is always 1.
 *   value(res, amount) -> coin or null; ratio(getRes, getAmt, payRes, payAmt) -> value(get) / value(pay), or null when either side has no price.
 *   PERSISTS to dma-market.json (the kept offers and the fitted prices, written at most once a minute) and reads it back on start, so the prices survive a restart.
 *   GLOBAL: DMA_Market = { version, owner "market price keeper", ready, observe, price, value, ratio, state }.
 *   The own-cost value list (DMA_Value, ADR 0047) stays for its own job, deciding what to make ourselves; it is no longer used for judging an offer.
 *   Unit: tests/unit/dma-market.test.js (the fit over the live offers of 2026-11-16 gives Oilseed far above its own cost and the four evidence ratios within 15 %; n < 3 is unknown; dedupe, age and cap; persistence).
 *   Integration: tests/integration/dma-trade-office-buy.test.js (the buyer feeds the keeper when it reads the panel, and the supply manager buys only an offer that is at least 1.5 times better at the market price).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.1", FILE = "dma-market.json", MAX_KEPT = 2000, MAX_AGE_MS = 7 * 86400000, MIN_N = 3, ITER = 5, OUTLIER_K = 2.5, OUTLIER_W = 0.1, WRITE_EVERY_MS = 60000, ANCHOR = "Coin";
    var kept = {}, prices = {}, fittedAt = 0, lastWrite = 0, dirty = false;
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function readJson(name) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new A.FileStream(); st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function writeJson(name, obj) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath), st = new A.FileStream(); st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    function median(a) { var s = a.slice().sort(function (x, y) { return x - y; }), n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : 0; }

    /* solve the normal equations A x = b by Gaussian elimination with partial pivoting */
    function solve(A, b) {
        var n = b.length, i, j, k, p, t, f;
        for (i = 0; i < n; i++) {
            p = i; for (j = i + 1; j < n; j++) if (Math.abs(A[j][i]) > Math.abs(A[p][i])) p = j;
            t = A[i]; A[i] = A[p]; A[p] = t; t = b[i]; b[i] = b[p]; b[p] = t;
            if (Math.abs(A[i][i]) < 1e-12) A[i][i] = 1e-12;
            for (j = i + 1; j < n; j++) { f = A[j][i] / A[i][i]; if (f === 0) continue; for (k = i; k < n; k++) A[j][k] -= f * A[i][k]; b[j] -= f * b[i]; }
        }
        var x = new Array(n); for (i = n - 1; i >= 0; i--) { t = b[i]; for (j = i + 1; j < n; j++) t -= A[i][j] * x[j]; x[i] = t / A[i][i]; }
        return x;
    }
    /* the fit: ln P per resource connected to the anchor */
    function fit() {
        var es = [], ids = Object.keys(kept), i, e, adj = {}, reach = {}, queue, r, nodes, idx = {};
        for (i = 0; i < ids.length; i++) { e = kept[ids[i]]; es.push({ g: e[0], d: Math.log(e[3] / e[1]), p: e[2], at: e[4], w: 1 }); }
        es.forEach(function (x) { (adj[x.g] = adj[x.g] || []).push(x.p); (adj[x.p] = adj[x.p] || []).push(x.g); });
        if (!adj[ANCHOR]) { prices = {}; fittedAt = Date.now(); return; }
        reach[ANCHOR] = true; queue = [ANCHOR];
        while (queue.length) { r = queue.shift(); (adj[r] || []).forEach(function (q) { if (!reach[q]) { reach[q] = true; queue.push(q); } }); }
        nodes = Object.keys(reach).filter(function (n) { return n !== ANCHOR; }); nodes.forEach(function (n, k) { idx[n] = k; });
        es = es.filter(function (x) { return reach[x.g] && reach[x.p]; });
        var x = {}, it, m = nodes.length;
        x[ANCHOR] = 0;
        for (it = 0; it < ITER; it++) {
            var A = [], b = [], a, c;
            for (a = 0; a < m; a++) { var row = []; for (c = 0; c < m; c++) row.push(0); A.push(row); b.push(0); A[a][a] = 1e-9; }
            es.forEach(function (o) {   // residual = x[g] - x[p] - d ; minimise sum w * residual^2
                var gi = o.g === ANCHOR ? -1 : idx[o.g], pi = o.p === ANCHOR ? -1 : idx[o.p];
                if (gi >= 0) { A[gi][gi] += o.w; b[gi] += o.w * o.d; if (pi >= 0) { A[gi][pi] -= o.w; } }
                if (pi >= 0) { A[pi][pi] += o.w; b[pi] -= o.w * o.d; if (gi >= 0) { A[pi][gi] -= o.w; } }
            });
            var sol = m ? solve(A, b) : []; nodes.forEach(function (n, k) { x[n] = sol[k]; });
            var res = es.map(function (o) { return (x[o.g] || 0) - (x[o.p] || 0) - o.d; });
            var spread = Math.max(1.4826 * median(res.map(Math.abs)), 1e-6);
            es.forEach(function (o, k) { o.w = Math.abs(res[k]) > OUTLIER_K * spread ? OUTLIER_W : 1; });
        }
        var cnt = {}, at = {}; es.forEach(function (o) { [o.g, o.p].forEach(function (n) { cnt[n] = (cnt[n] || 0) + 1; at[n] = Math.max(at[n] || 0, o.at); }); });
        var out = {}; Object.keys(reach).forEach(function (n) { var coin = Math.exp(x[n] || 0); if (isFinite(coin) && coin > 0) out[n] = { coin: coin, n: cnt[n] || 0, at: at[n] || 0 }; });
        prices = out; fittedAt = Date.now();
    }
    function persist(now, force) {
        if (!dirty && !force) return; if (!force && now - lastWrite < WRITE_EVERY_MS) return;
        var ok = writeJson(FILE, { format: "dma-market/1", version: VERSION, at: new Date(now).toISOString(), offers: kept, prices: prices });
        if (ok) { lastWrite = now; dirty = false; }
    }
    function observe(list, now) {
        now = now || Date.now(); var added = 0, ids, i;
        (list || []).forEach(function (o) {
            if (!o || o.own || o.buff || !o.offer || !o.costs || o.id == null) return;
            var g = o.offer[0], ga = Number(o.offer[1]), p = o.costs[0], pa = Number(o.costs[1]);
            if (!g || !p || g === p || !(ga > 0) || !(pa > 0)) return;
            var id = String(o.id); if (!kept[id]) added += 1;
            kept[id] = [String(g), ga, String(p), pa, now];
        });
        ids = Object.keys(kept);
        for (i = 0; i < ids.length; i++) if (now - kept[ids[i]][4] > MAX_AGE_MS) delete kept[ids[i]];
        ids = Object.keys(kept);
        if (ids.length > MAX_KEPT) { ids.sort(function (a, b) { return kept[a][4] - kept[b][4]; }); for (i = 0; i < ids.length - MAX_KEPT; i++) delete kept[ids[i]]; }
        fit(); dirty = true; persist(now, false);
        return { kept: Object.keys(kept).length, added: added };
    }
    function price(res) {
        if (res == null) return null; res = String(res);
        if (res === ANCHOR) return { coin: 1, n: Math.max(prices[ANCHOR] ? prices[ANCHOR].n : 0, MIN_N), at: prices[ANCHOR] ? prices[ANCHOR].at : 0 };
        var p = prices[res]; if (!p || p.n < MIN_N) return null;
        return { coin: p.coin, n: p.n, at: p.at };
    }
    function value(res, amount) { var p = price(res), a = Number(amount); return p && a > 0 ? p.coin * a : null; }
    function ratio(getRes, getAmt, payRes, payAmt) {
        var vg = value(getRes, getAmt), vp = value(payRes, payAmt);
        return vg != null && vp != null && vp > 0 ? vg / vp : null;
    }
    function state() {
        var out = {}; Object.keys(prices).forEach(function (n) { var p = price(n); if (p) out[n] = p; });
        return { version: VERSION, kept: Object.keys(kept).length, fittedAt: fittedAt, prices: out };
    }
    var api = { version: VERSION, owner: "market price keeper", ready: true, observe: observe, price: price, value: value, ratio: ratio, state: state };
    /* the learnt prices survive a restart */
    (function () {
        var s = readJson(FILE); if (!s || !s.offers) return;
        Object.keys(s.offers).forEach(function (id) { var e = s.offers[id]; if (e && e.length === 5 && e[1] > 0 && e[3] > 0) kept[id] = [String(e[0]), Number(e[1]), String(e[2]), Number(e[3]), Number(e[4]) || 0]; });
        fit();
    })();
    root.DMA_Market = api;
})(typeof window !== "undefined" ? window : this);
