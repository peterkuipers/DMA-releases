/*
 * user_dma_adventure.js — adventure executor (PBC adventure management, ADR 0034)
 * 0.2.183 (2026-11-27, review 2026-11-27-adventure-stale-view-loop-r5 CR-C1/CR-B3/CR-E3): an attack task once seen in the view is remembered.
 *   untakenFight marks a general seen while its task is in view (as 0.2.177 did), so an interception won without losses no longer turns
 *   into "got no task" and an untimed solo send. In CAMP and CAMPS the camp of an interception is remembered (noteIntercept); a general
 *   intercepted there and without a task later is not re-sent: the step stops and names the interception camp and its own camp. Unit:
 *   tests/unit/dma-adv-stale-view.test.js (an interception won without losses in all three steps). Integration:
 *   tests/integration/dma-adv-repair-emergency-sticks.test.js.
 * 0.2.182 (2026-11-27, review 2026-11-27-adventure-stale-view-loop-r4 CR-C1/CR-B4/CR-B3/CR-E3): 0.2.181's tookAttack (false for a task on
 *   another camp) also reached untakenFight (layers, the last layer, one-layer steps, "as it is"), where an intercepted general fighting at
 *   another camp was then re-sent to a busy general and stopped the step. untakenFight now leaves out a general with an attack task in
 *   the view on any camp, as CAMP and CAMPS do: the order was taken. Unit: tests/unit/dma-adv-stale-view.test.js ("as it is" with an
 *   intercepted general, retreat off and on). Integration: tests/integration/dma-adv-repair-emergency-sticks.test.js.
 * 0.2.181 (2026-11-27, review 2026-11-27-adventure-stale-view-loop-r3 CR-C1/CR-D3/CR-E4/CR-B3): tookAttack returns false for a task on another
 *   camp (it fell through to "any task" and losses, so a general busy elsewhere counted as attacking its own camp); the stop names the camp
 *   the view shows the task on and the general's own camp, and says what is known ("its attack was not seen"). Unit:
 *   tests/unit/dma-adv-stale-view.test.js (stubs with anyTask and units; an adapter that answers busy). Integration:
 *   tests/integration/dma-adv-repair-emergency-sticks.test.js.
 * 0.2.180 (2026-11-27, review 2026-11-27-adventure-stale-view-loop-r2 CR-C1/CR-B4/CR-D3): 0.2.179's "seen" for every stale task is
 *   withdrawn - it hid attacks that never happened and sent the next attacker into an unweakened camp. "Seen" comes only from tookAttack
 *   (its own or via camp). A stale task taken as ended that is NOT the general's own attack (another camp: the game has it busy) stops the
 *   step and names it for the player; its own attack's stale task lets the step go on as in 0.2.178. Unit: tests/unit/dma-adv-stale-view.test.js
 *   (two attackers: no MAIN order in CAMP and CAMPS). Integration: tests/integration/dma-adv-repair-emergency-sticks.test.js.
 * 0.2.179 (2026-11-27, withdrawn in 0.2.180; review 2026-11-27-adventure-stale-view-loop CR-B4/CR-C1): a general whose stale task is taken as ended counts
 *   as having attacked (seen), so the untaken-attack resend never sends it again while the game still has it busy (its stale task could
 *   be on another camp). Unit: tests/unit/dma-adv-stale-view.test.js (CAMP, CAMPS, a stale task on another camp). Integration:
 *   tests/integration/dma-adv-repair-emergency-sticks.test.js.
 * 0.2.178 (2026-11-27, live FT 2026-11-27 10:35-10:37 camp 1870, finish camp by camp: "the view is behind the server (1 tasks past their
 *   end): refreshed" every 30 s until the player stopped the run - the task stayed past its end after every refresh): in the camp-by-camp
 *   step (CAMP) and the waves / emergency step (CAMPS) a general's task past its end is refreshed at most STALE_REFRESHES (3) times;
 *   then it is taken as ended, said once, and the step goes on (the camp stands: the next attacker or the judgement; it fell: the next
 *   camp). [impl]: how the run reads the game view, no rule changes. Unit: tests/unit/dma-adv-stale-view.test.js. Integration:
 *   tests/integration/dma-adv-repair-emergency-sticks.test.js (the emergency step still finishes).
 * 0.2.177 (2026-11-27, live FT 05:47-06:12Z, B14 §13): YGG1 was sent from 1516 to 1870 through camp 1132, which the plan never
 *   attacks; FT's rule "retreat on interception off" (the author's: his plans are caught on purpose) made the executor log
 *   "interception accepted" and send him, twice. (1) A version whose source is "made by DMA" plays with retreat on interception:
 *   a camp nobody attacks that watches the way stops the step before it is sent. (2) api.way(from, to): the camps watching the
 *   way from a spot to a camp, from the interception picture, so the Mundane generator (0.8.5) can choose a spot whose way is
 *   clear. Unit: tests/unit/adventure-dma-plan-no-interception.test.js. Integration: dma-mundane-gen-ft-standin (a way given).
 * 0.2.176 (2026-11-27, live FT 04:38-05:30Z, B14 §12): a 1-unit wave that is recovering while a later step attacks its camp again is left
 *   out of the step like a blocker; the step no longer waits up to 4.5 h for a general whose part is done. Unit:
 *   adventure-wave-done.
 * 0.2.175 (2026-11-27, author 06:07 + live FT 04:18:56Z, B14 §11): the gateway carries the time of every packet entry Mundane will not
 *   send (canAttack false) onto the next entry it does send - Mundane drops a left-out entry with its time, so an author's
 *   "arrow, attack, arrow, attack" lost the generals' waits and the arrows went all at once. Integration:
 *   adventure-ft-as-written-arrows (part 5).
 * 0.2.174 (2026-11-27, live FT 2026-11-26 19:34-20:30Z, B14 §9): a run started while its open adventure is shown resumes there only
 *   when a general of the plan stands on it; with none there it goes home first and resumes the open adventure from home (the
 *   generals still home are loaded and sent). Before, "Finish camp by camp" waited 55 minutes for generals sent home.
 *   Unit + integration: adventure-resume-home-first.
 * 0.2.173 (2026-11-26, live FT 18:08-19:06Z on 0.2.172: "VAR may not stand on 2873 ... RES2 may not stand on 3144 ... VAR has no
 *   placeable spot (2873) and nothing of the plan comes before it", then four self-repairs over 40 minutes saying the same):
 *   - played as written, what stands before a general without a spot and still has a camp to take is played first also when it
 *     is only an ARROW (0.2.172 counted generals only): the arrow goes as a step of its own, the general's spot is judged again
 *     when its camp has fallen - a spot on land an arrow opens is reached this way;
 *   - before a spot is called "not placeable" it is cleared: an idle general of ours standing on it or within 2 tiles, and not
 *     on a spot of its own in this step, goes to the star first (live: RES2 stood on VAR's spot 2873 as a substitute for its own
 *     3144; generals of earlier stopped runs stood next to the plan's spots);
 *   - when nothing before the general has a camp left, the step stops AT ONCE (no self-repair ladder: waiting opens no land) and
 *     the reason carries the game's own answer for the spot (gateway placeCode, CheckIfGarrisonIsPlacableInGame).
 *   Mundane itself (5-battle.js battleMove / battleAttack) places every general when "move" is pressed and never at its send
 *   time; a general not on its spot is left out of the attack. Unit: adventure-arrow-no-task (part 3). Integration:
 *   adventure-as-written-arrow-opens-spot.
 * 0.2.172 (2026-11-26, live FT 2026-11-26 16:37-17:02Z on the author's account: Sizzler79's First Thief route "used with my
 *   generals", played as written - the arrows did not take their camps, three generals walked into camps their plan clears first,
 *   and the step hung at "1 camps, 2 busy"; change-set B14 section 7). Read from Mundane's own source (tso_client 5-battle.js,
 *   6-buffs.js, 0-common.js) and from the run's log:
 *   - ARROWS AT THE SEND (gateway attack). Mundane sends a packet in the order of its KEYS, not of its "order" fields; and it
 *     takes an arrow's id from a table it fills from its own variable buffVector, which is only set when Mundane's battle or buff
 *     window was opened - on a client where it never was, every arrow went out with an empty id (no arrow, nothing used). The
 *     packet is handed over with its keys in the plan's order (sendOrder); the star is read and handed to Mundane, and an id
 *     still missing is filled from the star. An arrow of a standing camp that cannot be put on it (none in the star, no id)
 *     holds the whole packet: nothing is sent and the step stops naming it. An arrow whose camp already fell is not sent.
 *   - AN ARROW HAS NO TASK (untakenFight). An arrow was taken for a general without a task and sent again alone every 30 s (up
 *     to 16 times; camp by camp too). Now an arrow is judged by its camp and by the star's count before and after: in flight for 30 s after its
 *     place in the plan, nothing is sent; the camp stands and the star shows it was not used -> put on the camp once more by
 *     the gateway's own applyArrow (at most 2 sends per camp); used, or not known -> never again, said in the log, and a replay
 *     of the step (self-repair) leaves that arrow out.
 *   - AS WRITTEN KEEPS ITS ORDER (MOVE). A general without a placeable spot no longer waits alone "for the next step" while the
 *     generals after it in the plan go first: it waits with everything after it in the plan; when it is the plan's first general
 *     the step stops naming it and its spot.
 *   - A BUSY GENERAL IS WAITED FOR (ATTACK). 0.2.169 let a general that could not attack yet through when an arrow came before it
 *     in the plan; Mundane leaves such a general out of its queue without a word ("0 of 3 on their way"). Only an idle general
 *     is let through; what Mundane queued is said ("queued n of m - left out: ...").
 *   - FIGHT ENDS (FIGHT). Beaten generals recover for hours and counted as "busy", so FIGHT waited 40 minutes for nothing. When
 *     camps stand and every non-idle general of the step is recovering for 90 s, the step is judged at once: "n camp(s) survived
 *     the attack (grids): X, Y beaten and recovering, no general on its way or fighting" (then the self-repair ladder, as for
 *     "generals idle").
 *   Unit: tests/unit/adventure-arrow-no-task.test.js (an arrow in flight is not sent again; not used -> once more through
 *   applyArrow; used -> never again; the star not read -> never again; beaten generals end FIGHT in 90 s; the plan keeps its
 *   order when a general has no spot). Integration: tests/integration/adventure-ft-as-written-arrows.test.js (the gateway with
 *   Mundane's queue as its source reads: key order, buffVector, the held packet; the generated FT attack 01 through the run).
 * 0.2.171 (2026-11-26, live FT 15:49Z): T7 does not count "not on the home island" against a general while an adventure of this kind
 *   is open (ownAdventure): the run goes on in it and its generals stand there. Before, a stopped FT with its generals on the map
 *   could not be started again ("not promised: R-PLAN-GENERALS - RES2 (not on the home island), ..."). Travelling and recovering
 *   still count. Integration: adventure-plan-check-request.
 * 0.2.170 (2026-11-26, architect review 2026-11-26-b13-b14-own-mundane F1-F4, author B13-Q3): ARS-18-02.T6-T10 are assessed in
 *   assess(), before the promise - a failed clause is a decline naming it, never a promise revoked later (F1); a gateway case is not
 *   checked a second time in startRun. T7 reads availability: travelling, recovering, not on the home island; with a run going or
 *   promised before it the request waits unpromised until its turn (F2). The request carries the runs selected (o.runs; the
 *   adventure manager passes what is left of adv.keep.runs) and T6/T9 count with it (F3). T6 reads the star stock through
 *   starStock() as T3 does; T9/T10 read the star from the picture, else the game's starRead(), and a star not read is "not read":
 *   the request waits, it is never declined on it (F4). Unit: adventure-plan-as-written. Integration: adventure-plan-check-request.
 *   F5: saveVersion keeps a plan's source and origin (AT129, PT42). F7: the arrow run observes each destroy arrow (taken / not
 *   taken per camp size) in dma-arrow-facts.json - the watcher of docs/05-ontology/dma/facts/destroy-arrows.yaml - and records
 *   "the facts of destroy arrows changed" on a contradiction. Integration: dma-arrow-facts-watch.
 * 0.2.169 (2026-11-26, change-set B13, backbone v3.39; tester Sizzler79, FT "1st_thief_attack": three destroy buffs went out at
 *   once and no general followed; author: "if they select their own mundanes they expect them to be run accordingly" and "only
 *   when a player says analyse this and approve, it can be changed, but that should be saved as a new version"):
 *   - R-PLAN-AS-WRITTEN (ARS-18-03-NEXT): every attack plan is played as written — its steps in their order, each after its own
 *     delay, its arrows in their place. The interception layers and the re-timing are no longer a default; they run only for a
 *     version whose kind the player chose for that (camp by camp, without blocks, blocks) and in the self-repair. The rules
 *     adv.asIs / adv.<id>.asIs / adv.campByCamp no longer change how a plan is played (retired: a changed plan is a new version,
 *     made by Make my Mundane or Save my copy after the player's approval).
 *   - Played as written, a general whose camp cannot be attacked yet does not hold the step back when an arrow comes before it in
 *     the plan (the arrow opens its way).
 *   - ARS-18-02.T6-T10 (B13-Q3, author 06:49: "before the promise is made to execute it, everything needs to be checked"): before
 *     the run is promised, planCheck() reads what the selected plan needs — the adventure in the star (R-PLAN-ADVENTURES), every
 *     general the player's own (R-PLAN-GENERALS), each army within its general's capacity (R-PLAN-CAPACITY), every arrow in the
 *     star counted (R-PLAN-ARROWS), every chosen travel buff in the star (R-PLAN-BUFFS). A failing clause declines the run with
 *     its name and what is missing.
 *   - Played as written, a general the template sends later (its own delay) is not taken for "no task" while the send queue still
 *     sends (live FT 2026-11-26: the self-repair replayed a step too early).
 *   - B14 beta: an arrows-only version made by the generator names its camps by grid ("#<grid>" in its plan): those camps are
 *     the targets of the arrows run; starBuffs() gives the console the star's arrows.
 *   Unit: tests/unit/adventure-plan-as-written.test.js (the tester's template is sent as one packet with its own order and
 *   delays; planCheck names a missing arrow, a foreign general and an army over capacity).
 *   Integration: tests/integration/adventure-plan-check-start.test.js (startRun declines with R-PLAN-ARROWS and starts once the
 *   arrows are in the star).
 * 0.2.168 (2026-11-25, live test Castaway): ARS-18-02.T3 R-ADV-IN-STAR read "no reading" as "none in the star". Three minutes
 *   after a load the location picture had no stock sample yet (DMA_Demo.stockNow() = {}), so AR18 declined the quest completer's
 *   TK18 request for 1001NightsWoodcutter while 39 were in the star. starStock now reads the picture only when it carries a star
 *   reading (any "star:" key); otherwise it asks the game through the gateway, as before when the picture was absent. No clause
 *   changes; the truth clause is read correctly.
 *   Unit expectation:        stockNow() = {} and the gateway counting 39 -> starStock = 39 and assess promises; stockNow() with a
 *                            star reading lacking the item -> 0 and the decline names T3.
 *   Integration expectation: live, right after a restart a TK18 request for an adventure in the star is promised, not declined.
 * 0.2.167 (2026-11-25, change-set B12 quest parts, backbone v3.34; author's decisions 2026-11-25: "AR71 always requests; AR18
 *   judges", first come, first served; 22:53: "het uitzetten van de schakelaar geldt als revoke request van de manager", model
 *   v3.35 pending): AR18 adventure completer takes TK18 requests in.
 *   - request(id, {by, quest, task, version}) records the initiator's request (AR17 adventure manager or AR71 quest completer)
 *     through the G-CAF gateway (GCAF_Transactions.act, gate C8) under the case key adv:<star name>@<task> (caseKey) and
 *     assesses it at once by ARS-18-02 (AR18 does not read adv.auto: per author 22:53, model v3.35 pending, ARS-18-02.R3 and
 *     ARS-18-03.R2 are not applied - switching a manager off is that manager's revoke request; a quest's request follows
 *     quest.auto): T3 R-ADV-IN-STAR (the location picture's star stock), T4 R-ADV-ATTACK-PLAN (a version in
 *     the adventure book whose analysis is not failed; an "arrows only" version needs no folder) or T5 R-ADV-LOCATION-ACTIVE
 *     failing -> a decline whose reason names the clause; else a promise that names its turn.
 *   - The promised requests wait in the order of their promises (dma-adv-requests.json, kept over a restart). ARS-18-03 starts
 *     the first when it is its turn (T2 R-ADV-FIRST-COME: no run going and no run waiting to be resumed), the general is idle
 *     (T3 R-ADV-GENERAL-IDLE); re-assessed when a run ends and every 30 s. runOnce of an initiator (AR17) waits behind
 *     promised requests (AR17's own revoke on its switch-off is the adventure manager's next change); the player's own
 *     Run once and AR17's runOnce keep their direct TK18 records (the player is no TK18 initiator in the backbone).
 *   - withdraw(caseKey, {by, reason}): the initiator's revoke request (ARS-71-01-LEAVE, ARS-71-06), allowed by AR18 while
 *     the adventure has not started (DFS-78); a started run is finished.
 *   - The run file names the initiator (by, role, via), also after a resume, so the answers are the initiator's: on a gateway
 *     case DONE -> execute, declare (AR18), AR17's accept on its behalf, AR71's accept its own (ARS-18-05-AR71, when the game
 *     counts the task); stopped -> revoke promise (AR18), allow (initiator), then decline (AR18, "the run stopped: ...") or,
 *     lost, revoke request (initiator, ARS-18-07/-AR71) and allow (AR18). The direct records name the initiator too (no
 *     "player (tacit)" for a case the player did not request). A resume that cannot start ends its case.
 *   - resumePending() tells an initiator that the run before a restart waits to be resumed; requests(), pump(), caseKey().
 *   - A star name not in RES is taken as it is (resOf); the run's per-adventure rules then fall to "own" as before (0.2.108).
 *   r2 (tester kf-adv-queue-stale-second-window, ADR 0051): the queue file is read fresh before every reading and change
 *   (two windows load this module); a request is taken off the file before its start, and one the book no longer has as
 *   promised is dropped, never started. Integration: tests/integration/adv-queue-second-window.test.js.
 *   r3 (tester kf-adv-queue-dropped-by-adventure-window): only a window with the gateway and the transaction book serves the
 *   queue (the adventure window has neither, ADR 0051); a case the book does not know is kept, not dropped.
 *   Integration: tests/integration/adv-queue-adventure-window.test.js.
 *   0.2.166's self-repair is untouched (the run engine is not changed).
 *   Unit: tests/unit/dma-adv-request-intake.test.js. Integration: tests/integration/dma-adv-request-queue.test.js and
 *   tests/integration/tk18-initiator-accepts.test.js (moved from tests/known-failing/).
 * 0.2.166 (2026-11-25, ADR 0102; author 10:59: "alleen als de belofte echt niet nagekomen kan worden en tot nu toe trek je
 *   die conclusie iets te snel ... Dat moet ingebakken worden in de scripts dat je er alles aan doet om het eerst zelf op te
 *   lossen, waarbij je de speler maximaal op de hoogte houdt"): with the rule adv.selfRepair (default on) a stop is no longer
 *   the first answer to trouble. stop(reason) first climbs a ladder of self-repairs, each said in the log and shown in the
 *   status (fix: step, of, reason, what, until):
 *     1. look again: refresh the zone and play the step again from what still stands;
 *     2. refresh and play the step again camp by camp (the emergency mode);
 *     3. wait 10 minutes (generals recover, troops train, the view catches up), refresh, camp by camp again;
 *     4. wait 30 minutes, refresh, camp by camp again.
 *   Only after the ladder, or when the promise truly cannot be kept, the run stops, naming every reason it met.
 *   Stop at once (truly cannot be kept, or not ours to repair): the game marks the adventure lost; the player stopped the
 *   run; the player's rules forbid it (blocks not allowed, star stock rule); no adventure item or it was refused; the
 *   adventure did not open (a retry could open a second one); not on the home island; nothing to resume; a template error
 *   (block entries in a version without blocks); the previous adventure still open. Each step gets a fresh ladder.
 *   Outside the playing states (before the adventure opened, after the last round) a repair retries the same state.
 *   r2 (tester): a replay sends no general whose camp already fell; camp by camp only for the repaired step, never for "as
 *   it is" or block templates (they keep their own timing); a restart during a repair resumes as fighting and keeps the
 *   ladder count (status fix); no repair before the adventure is open (PRECHECK, START: a second item); a repaired SEND sends
 *   only the generals still at home; a failed repair (an error in FIX) takes the next step; an adventure closed during a
 *   repair ends the run (DONE).
 *   r3 (tester): the player's Emergency is never undone by a repair; the ladder count stays in the status while the step is
 *   played again (status fix.active tells whether a repair is under way), so a restart never starts a fresh ladder; a pruned
 *   entry's delay goes to the next entry in send order (r4), so a template's timing holds.
 *   Unit: tests/unit/dma-adv-self-repair.test.js. Integration: tests/integration/dma-adv-self-repair-run.test.js and the ten
 *   tests/integration/dma-adv-repair-*.test.js.
 * 0.2.165 (2026-11-25, ADR 0101 rule 3; author on live FT 02:28: "je zet alles terug naar star en 1 generaal dichtbij het aan
 *   te vallen kamp, maar je valt het kamp aan met een generaal die er mijlen ver vanaf staat. Het rijmt niet met elkaar"):
 *   a general attacks only from its template spot or close to it (6 tiles), never from far away.
 *   (1) A general placed from the star on a landing field because its own spot was refused keeps its spot as walkTo; once
 *       it stands on the landing field it walks on to its spot before the step counts as in position.
 *   (2) Camp by camp, a general whose spot is held by a busy general attacks from where it stands only when that is
 *       within 6 tiles of its spot; otherwise it takes a placeable spot near its own, or waits for its spot.
 *   (3) A general that already stands on its spot for the round is not sent to the star (on arrival and between rounds);
 *       the star method itself stays the player's rule (0.2.116, author: "door alles naar star te zenden, kun je ze
 *       daarna direct op hun goede plaats zetten").
 *   New gateway reading G.dist(a, b): Chebyshev distance of two grids on the viewed zone (null when unknown: nothing is
 *   blocked, as before 0.2.165).
 *   r2 (tester): the 0.2.134 path (spot = camp grid) attacks from where it stands only within 6 tiles of the camp; an island
 *   general never takes a far "may not stand" substitute (it waits for a free spot); a walkTo spot counts as taken.
 *   Unit: tests/unit/dma-adv-walk-to-spot.test.js. Integration: tests/integration/dma-adv-no-far-attack.test.js,
 *   dma-adv-far-attack-camp-grid, dma-adv-far-substitute-on-island, dma-adv-walkto-spot-not-reserved.
 * 0.2.164 (2026-11-25, ADR 0101, live FT: three runs stopped with "survived all its attackers" 16 s after an attack the game
 *   never started): an attack counts only once the game gives the general its AttackBuilding task. A general just placed from
 *   the star gets none for a few minutes; the run sends the attack again every 30 s (up to 8 minutes) and says so, in the
 *   camp-by-camp step and in the waves / emergency step; a camp is judged to have survived only when each attacker had a task
 *   and has none any more. Unit: tests/unit/dma-adv-attack-confirm.test.js. Integration: tests/integration/dma-adv-camp-untaken-retry.test.js; tester: dma-adv-next-attacker-before-task (a wave without a task is not "fighting"), dma-adv-double-attack-unseen-task (fewer units or a Recover task = the attack happened), dma-adv-layer-survived-untaken (a layer without any task is sent again, not judged); r2: dma-adv-anytask-before-order (a task the general had before the order proves nothing), dma-adv-layer-partly-untaken (per attacker in every layer, the last one included); r3: dma-adv-resend-unguarded-path (a lone resend checks its path first); architect: dma-adv-untaken-stop-ends-tick (a stop ends the tick).
 * 0.2.163 (2026-11-24, live GP 01:22Z; author: "het is 2x ls GP, je schrijft G"): the loot-spot offer named Gunpowder "G" (the
 *   catalogue's initials of a one-word name). lsTag takes the console's short key first (gp -> GP, ft, ywc, ae, vlt), then the
 *   catalogue. Unit: adventure-ls-tag (Gunpowder -> GP, short id kept, unknown adventure -> initials).
 *   Integration: the next GP run posts "2x ls GP".
 * 0.2.162 (2026-11-23, live IP 10:28Z): an attack the game does not take because the general is still busy (or not yet on its
 *   spot) is tried again for up to 2 minutes before it counts as waiting. Unit: adventure-wave-only-step.
 * 0.2.161 (2026-11-23, live IP 10:15Z): a camp attacked only by 1-Recruit attackers counts as "weakened, the main follows" only
 *   when a later step attacks it again — a general that takes a camp alone with 1 Recruit is a real attack. Unit: adventure-wave-only-step.
 * 0.2.160 (2026-11-23, live IP 09:56Z): an error inside a run tick is logged once a minute and written to dma-adv-error.json
 *   instead of being swallowed. Unit: adventure-wave-only-step.
 * 0.2.159 (2026-11-23): the camps on a camp's path (the game's interception picture) are learned into the book (map.blocks)
 *   so the generator plans blockers first (generator 0.7.1). Unit: adventure-wave-only-step.
 * 0.2.158 (2026-11-23, generator 0.7.0's field plan): an entry with home: true sends its general home once and needs no spot;
 *   entries with grid -1 go to the star as Mundane moves them; MOVE's own "to the star first" leaves planned entries to the plan.
 *   Unit: adventure-wave-only-step.
 * 0.2.157 (2026-11-23): dma-adv-cmd.json "move" {keys, grid} and "tostar" {keys} for one general by hand. Unit: adventure-wave-only-step.
 * 0.2.156 (2026-11-23): the probe visits the adventure first (it ran on the home island after a restart). Unit: adventure-wave-only-step.
 * 0.2.155 (2026-11-23): dma-adv-cmd.json "probe" answers where the generals are, which camps stand and what the game says about
 *   placing star generals on the landing fields. Unit: adventure-wave-only-step.
 * 0.2.154 (2026-11-23): dma-adv-cmd.json — "finish" (camp by camp) or "stop" by file, once per id, answered in
 *   dma-adv-cmd-done.json. Unit: adventure-wave-only-step.
 * 0.2.153 (2026-11-23, live IP 07:50Z): "cannot move" (the game's check: the field is not free) sends the idle general holding the
 *   field to the star; generals whose camp fell need no spot; remembered unusable fields (0.2.147) switched off — their marks were
 *   wrong when a field was only held. Unit: adventure-wave-only-step.
 * 0.2.152 (2026-11-23, live IP 07:37Z): MOVE leaves generals whose camp has already fallen where they are.
 *   Unit: adventure-wave-only-step.
 * 0.2.151 (2026-11-23, live IP 07:19-07:25Z): "blockers first" says what waited and why; a second one with no camp fallen since
 *   the first stops the run with the game's reasons. Unit: adventure-wave-only-step.
 * 0.2.150 (2026-11-23, live IP 07:19Z): a spot is remembered as unusable only when the stuck general could move and nobody stood
 *   there; a remembered spot a general does reach is usable again. Unit: adventure-wave-only-step.
 * 0.2.149 (2026-11-23, live IP 07:01Z): an attack the game does not queue counts as waiting (with the game's reason), not as
 *   fought; when the blockers are unknown, any later general whose camp is reachable now comes forward. Unit: adventure-wave-only-step.
 * 0.2.148 (2026-11-23, live IP 06:43Z: "1 attacks cannot start" — YGG3's camp 3905 lay behind 5402): played camp by camp or in
 *   waves, ATTACK always hands over to the camp scheduler, whose "blockers first" brings the right generals forward.
 *   Unit: adventure-wave-only-step.
 * 0.2.147 (2026-11-23, live IP 06:35Z): a spot a general never reached is remembered for the adventure (book map.badFields) and
 *   swapped at once for a free landing field in later steps and runs. Unit: adventure-wave-only-step.
 * 0.2.146 (2026-11-23, live IP 06:16Z): a stuck general in the star for which the placement check finds nothing tries the
 *   learned landing fields in turn. Unit: adventure-wave-only-step.
 * 0.2.145 (2026-11-23, live IP 06:03Z: "no other placeable spot" for FR01 — the spots of BROM and FR03, whose camps had fallen,
 *   still counted as taken): a respot keeps clear only of the spots of generals whose camp still stands. Unit: adventure-wave-only-step.
 * 0.2.144 (2026-11-23, live IP 05:42Z): MOVE waits for generals that are recovering instead of stopping; "move" names each
 *   general's spot and state (star, recovering, busy, cannot move, not here); a failed respot is said. Unit: adventure-wave-only-step.
 * 0.2.143 (2026-11-23, live IP 05:24Z: the respot never fired — the step still listed BROM and FR03, whose camps had fallen):
 *   stuck and deferral checks count only generals whose camp still stands. Unit: adventure-wave-only-step.
 * 0.2.142 (2026-11-23, live IP 05:08Z): a step whose every general is stuck gives them another placeable spot, away from the one
 *   they could not reach (remembered as bad for the run). Unit: adventure-wave-only-step.
 * 0.2.141 (2026-11-23, live IP 04:54Z): blockers first no longer skips MOVE's "to the star first" for idle generals without a
 *   spot; a step whose every general is stuck sends idle generals off the landing fields once. Unit: adventure-wave-only-step.
 * 0.2.140 (2026-11-23, live IP 04:28-04:35Z): blockers first brings forward only generals whose own camp is reachable now, at most
 *   four; played camp by camp or in waves, ATTACK no longer waits for a blocked camp's general (the camp scheduler does).
 *   Unit: adventure-wave-only-step.
 * 0.2.139 (2026-11-23, live IP 03:50Z: "move 5" for minutes, none deferred): deferral compares with the step's attacking generals,
 *   not its camps; "move N" names the generals it moves (up to 6). Unit: adventure-wave-only-step.
 * 0.2.138 (2026-11-23, live IP 03:36Z, ADR 0094 lesson 3): when no camp of the step can be reached, the generals of later steps that
 *   attack the camps standing in the way come forward; the step's unsent generals go to the star and follow after them.
 *   Unit: adventure-wave-only-step.
 * 0.2.137 (2026-11-23, live IP 03:23Z): a general that does not reach its spot after 4 moves (not walking), while others of the
 *   round stand ready, waits for the next step too. Unit: adventure-wave-only-step.
 * 0.2.136 (2026-11-23, live IP 03:10Z): generals of a round that find no placeable spot and are not on the island (in the star)
 *   wait for a step of their own right after this one ("<round> (rest)"); the others attack now. Unit: adventure-wave-only-step.
 * 0.2.135 (2026-11-23, live IP 02:59Z: "no placeable spot" every 2 s for 7 generals): after a client restart the run resumed in
 *   MOVE while the client showed the home island, so every spot was checked on the wrong map. MOVE, ATTACK, CAMPS and FIGHT now
 *   visit the adventure first, as LOADR does; "no placeable spot" is said once per general with the grid it stands on. Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.134 (2026-11-23, live IP 02:24Z): a general with a spot on its camp and no placeable spot found attacks from where it stands
 *   on the island. Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.133 (2026-11-23, live IP 02:10Z): nearPlaceable widens its search ring by ring (up to 70 tiles) until it finds a placeable
 *   spot — on some islands a general may only stand on held land, far from the camps. Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.132 (2026-11-23, live IP 01:53Z): a general whose spot is its target camp's own grid (a version made from scratch) gets
 *   the nearest placeable spot next to that camp, away from the step's other spots. Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.131 (2026-11-22, live ToW 18:34Z; author: "ToW was finished just not closed"): when the game still marks the adventure
 *   active after the last camp, the run refreshes the zone (F2) and claims the quests again every 20 s for up to 4 minutes
 *   before Return; at home with the adventure still listed it refreshes and returns again, up to three times.
 *   Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.130 (2026-11-22, live ToW 16:54Z): after a step with a wave-only camp the run waited in FIGHT for that camp to fall; a camp
 *   whose attackers in the step are all 1R waves is not waited for (waveOnly). Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.129 (2026-11-22, live ToW 15:42-16:00Z: a run resumed on an open adventure waited in TRAVEL for "all generals arrived"
 *   while three beaten generals were recovering on the island — never idle, so never counted): a recovering general that is on
 *   the island counts as arrived. Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.128 (2026-11-22, live ToW 15:08Z): in the camp scheduler a camp whose attackers in this step are all 1R waves (at most one
 *   unit each) is meant to stand — it is left for a later step with its main instead of stopping the run ("survived all its
 *   attackers"). Unit: tests/unit/adventure-wave-only-step.test.js.
 * 0.2.127 (2026-11-22, author: "De troop manager moet ze altijd op orde houden"; live: Bonaberti refused, 1 983 Swordsman missing,
 *   and nothing trained them): a start refused for want of troops tells the troop manager what it needs loose at home
 *   (DMA_Troops.want, troops 0.1.8); a start that passes the check clears it. Unit: tests/unit/dma-troops-want.test.js.
 * 0.2.126 (2026-11-22, live: Make my Mundane on Bonaberti, with the YWC adventure in view, stored YWC's camps under Bonaberti, so
 *   no Bonaberti camp was simulated — 0/18): campMap() names the adventure in view (res, from the adventure manager); learnMap
 *   keeps an army only when the map names this adventure (as before for names and units); an army is kept with armyRes, and campArmies(res) gives only armies read on that adventure
 *   (the polluted Bonaberti entries, without armyRes, are ignored). Unit: tests/unit/adventure-camp-armies.test.js.
 * 0.2.125 (2026-11-22, ADR 0094: the Mundane generator simulates the camps with the player's generals and needs their armies as a
 *   game fact): campMap() reads each camp's army by unit type (GetSquadsCollection_vector, as campArmy does); learnMap keeps the
 *   fullest army seen per camp in the book (map.camps[grid].army); campArmies(res) gives {camps: {grid: [[type, n]]}, names,
 *   count, at} for the generator. Unit: tests/unit/adventure-camp-armies.test.js.
 * 0.2.124 (2026-11-22, live YWC 00:28-00:33Z: Black Tree was put on twice and never taken from the star while the travel documents
 *   and the Observatory boost ran; the run stopped "the speed-ups do not run"): a speed-up the game does not take while another of
 *   the run's speed-ups runs does not stack — the run goes on and says so; with none running it still stops.
 *   Unit: tests/unit/adventure-travel-confirm.test.js (case 5).
 * 0.2.123 (2026-11-22, live YWC 2026-11-21 16:01Z: a resumed run re-loaded and re-sent GHOST1, the first-attack general the run
 *   had sent home on purpose): with adv.<id>.aheadHome a resumed open adventure leaves a first-attack-only general that is home
 *   (while others are away) at home. Integration: tests/integration/adventure-resume-ahead-home.test.js.
 * 0.2.122 (2026-11-21, live YWC 17:13Z, measured with 0.2.121: no troop was loose during the whole fight; at "camps gone" of the
 *   last attack the idle generals were sent to the star, and the star empties a general — 2 569 troops loose, only the 7 recovering
 *   generals kept theirs): after the last round no general goes to the star. Root cause of the loose troops at home.
 *   Integration: tests/integration/adventure-ahead-close-run.test.js.
 * 0.2.121 (2026-11-21, live YWC 16:21Z: the MM of the first eleven generals ended loose, the last five kept theirs): in the fight
 *   every change (camp falls, general idle) is measured, at most every 30 s — each general's army and the loose troops — so the
 *   moment an army leaves its general is in the book. Unit: tests/integration/adventure-ahead-close-run.test.js (version pin).
 * 0.2.120 (2026-11-21, live YWC 16:21Z: closing at once left 1 780 MM, 507 Sw, 105 AM and more loose on the adventure; they went
 *   home on their own): closing at once still stows the loose troops into the idle generals with room (stowLoose), it only skips the
 *   waits (recovering generals, marshals from the star). Integration: tests/integration/adventure-ahead-close-run.test.js.
 * 0.2.119 (2026-11-21, live YWC 08:18-08:20Z: after "closing at once" the run waited 2 minutes for the game to mark the adventure
 *   won, while it was already gone — status null): an adventure that is no longer in the list is not waited for; Return follows at
 *   once. Integration: tests/integration/adventure-ahead-close-run.test.js.
 * 0.2.118 (2026-11-21, live probe 07:31-07:35Z; author: "Je kunt zelf ook zien dat generaals onderweg zijn, zelfs welke en wat voor
 *   troepen erin zitten"): the start check reads from the game who of the load is on the way home (TravelToZone to this zone,
 *   remaining time, army) and waits until the last one lands plus 2 minutes; one neither home nor on its way is named as still on an
 *   adventure (at most 45 minutes). Integration: tests/integration/adventure-wait-generals-home.test.js.
 * 0.2.117 (2026-11-21, live YWC 06:27Z; author: "de controle erop moet kloppen en niet een run stoppen om de verkeerde redenen"):
 *   before the adventure is opened every general of the load must be home and idle; generals on their way home from the last
 *   run are waited for and named (at most 45 minutes). With mundane 0.1.6 (generals once seen stay the player's) the run keeps
 *   all its rounds. Integration: tests/integration/adventure-wait-generals-home.test.js.
 * 0.2.116 (2026-11-21, ADR 0091, author: "door alles naar star te zenden, kun je ze daarna direct op hun goede plaats zetten
 *   zonder te verplaatsen ... dat is goed. Waar je moet wijzigen is na aanval 1 Ghost niet naar star sturen, maar naar home. En
 *   zodra aanval 2 het laatste kamp heeft verslagen, het avontuur afsluiten. Dat stuurt alle generaals direct naar huis, met
 *   alle troepen nog geladen"): (1) the star method is the player's rule again, whatever the landing fields — they stay a read
 *   and registered game fact (0.2.115) for Analyse and the log; (2) rule adv.<id>.aheadHome (ALL default adv.aheadHome, off):
 *   when the first attack's camps are gone, its generals that the next attack does not use go HOME instead of to the star, as
 *   soon as they are idle and no attack is being sent; (3) rule adv.<id>.closeAtOnce (ALL default adv.closeAtOnce, off): when
 *   the last attack's camps are gone the run claims, collects and closes at once — no wait for recovering generals, no stowing
 *   of loose troops. Unit: tests/unit/adventure-ahead-home.test.js. Integration: tests/integration/adventure-ahead-close-run.test.js.
 * 0.2.115 (2026-11-21, ADR 0092, author: "8 landingsplekken is een instelling die jij algemeen hebt neergezet, eigenlijk moet je
 *   dat voor elk avontuur los bepalen ... die zijn spelfeiten"; "laat de speler zien of het een vastgesteld aantal is uit de
 *   praktijk, of dat je het ergens online hebt kunnen lezen (misschien met een kleurcode?)"): the landing fields of an
 *   adventure are read from the game (the adventure's street map, GetAllLandingFieldsPositions_vector) whenever it is in view,
 *   registered in the book (map.landing {n, grids, source "game", at}) and watched — a change is logged and the copy follows.
 *   landing(res) gives the count with its source ("game" = seen in practice, "online" = map.landingOnline {n, url, at} read
 *   from a public source, or none). Analyse passes it to the advisor instead of 8. A run reads the fields on arrival, before
 *   any general goes to the star, and uses the star method only when more generals must land than there are fields.
 *   Unit: tests/unit/adventure-landing-fields.test.js. Integration: tests/integration/adventure-landing-star.test.js.
 * 0.2.114 (2026-11-21, live YWC 03:14Z: the main attack fought but "the last general of the attack has left" never came, the send
 *   queue still read "sending"): a general that has shown an attack task once has left; when all have, the attack is sent, whatever
 *   the queue says; the queue is waited for at most the attack's sending time plus one minute. Unit: tests/unit/adventure-attack-sent.test.js.
 * 0.2.113 (2026-11-21, live: at 03:04Z the Black Vortex and the Observatory's star chart ran together, so 0.2.112's family is
 *   withdrawn; the Vortex put on at 02:53Z showed as running only minutes later): a speed-up is put on again only when its star
 *   count did not go down after 90 s, and the run waits up to 5 minutes for it to show as running. Unit: tests/unit/adventure-travel-confirm.test.js.
 * 0.2.112 (2026-11-21, live 02:53Z: the Observatory's star chart and the Black Vortex were both put on; the Vortex never ran and the run
 *   stopped): the Observatory and the Black Vortex are one family — the game keeps one adventure-zone travel boost at a time — so a
 *   tick on one greys out the other and only one is put on. Unit: tests/unit/adventure-travel-buffs.test.js.
 * 0.2.111 (2026-11-21, live YWC 2026-11-20 14:35Z: the closing step read the home island — 62 329 loose troops, 58 generals, "sending 78
 *   generals home"): stowing loose troops and sending the generals home happen only while the adventure is in view; otherwise the
 *   run waits a minute and closes without stowing. Unit: tests/unit/adventure-finish-own-zone.test.js.
 * 0.2.110 (2026-11-20, live YWC 14:07Z: the as-is guard stopped first ghost because GHOST1 would be intercepted — which YWC does on
 *   purpose): with retreat on interception off for the adventure (adv.ywc.retreat false), an interception is intended; the guard
 *   logs it and sends. Unit: tests/unit/adventure-asis-intercept.test.js.
 * 0.2.109 (2026-11-20, live YWC 13:50Z and 14:00Z: a STOPPED run picked up again has no previous state; that was taken for "was
 *   fighting", so the general the arrival step sent to the star counted as fighting and the run stopped on "1 camp survived"):
 *   a resume counts as a fight only when the previous state was one (3 places). Unit: tests/unit/adventure-resume-stopped.test.js.
 * 0.2.108 (2026-11-20, live YWC 13:54Z: still camp by camp — runOnce itself chose the rules of "own" for a star name before rulesFor
 *   saw it): runOnce reads a star name as its short key too (1 place). Unit: tests/unit/adventure-per-adv-rules.test.js.
 * 0.2.107 (2026-11-20, live YWC 13:44Z: a run started with the star name read none of the YWC rules — asIs off, camp by camp on — and
 *   stopped on GHOST1, meant to be intercepted): rulesFor reads a star name as its short key. Unit: tests/unit/adventure-per-adv-rules.test.js.
 * 0.2.106 (2026-11-20, live YWC 13:44Z: the horseshoe was not put on — the first attack is round 1, round 0 is the load): the
 *   adventure speed-ups go on before the run's first MOVE, whatever its round. Unit: tests/unit/adventure-zone-buffs.test.js.
 * 0.2.105 (2026-11-20, author: "hoefijzer moet op het adventure geactiveerd worden, niet hier"; live 13:24Z the run stopped because the
 *   horseshoe did not run at home): a speed-up whose game definition targets only the adventure zone goes on at the adventure, after
 *   the arrival and before the first round moves, and is confirmed there (2 minutes at most; the run does not stop on the island).
 *   Home speed-ups (Vortex, Doggy Bag, travel documents, star charts) still run before the start. Unit: tests/unit/adventure-zone-buffs.test.js.
 * 0.2.104 (2026-11-20, live YWC: the game took about 7 minutes to open the adventure; the run gave up after 2 and the next try
 *   was refused): after the star item the run waits up to 8 minutes for the adventure to open and says once after 2 minutes that
 *   the game is still opening it. Unit: tests/unit/adventure-open-wait.test.js.
 * 0.2.103 (2026-11-20, author: the troops are probably in the generals — after an earlier YWC they come back loaded): the check
 *   before the start counts the loose troops AND what the template's own idle generals carry beyond their part (the load's first
 *   pass gives that back); it stops only on a real gap and names that gap. Unit: tests/unit/adventure-precheck-carried.test.js.
 * 0.2.102 (2026-11-20, author: see when the last general of an attack has been sent, because then orders can be given again): an
 *   attack counts as sent when the client's send queue is empty and every general of it has an attack task; the run says so once
 *   ("the last general of the attack has left … — free for new orders") and only then pre-stages the next round. Unit:
 *   tests/unit/adventure-attack-sent.test.js.
 * 0.2.101 (2026-11-20, live YWC after a restart: the start-up hold refused four loads on the island, the run took that for "another
 *   version's troops" and recalled all 21 generals; after the recall they were loaded and would have left without speed-ups): while the
 *   start-up hold lasts the run does nothing and counts nothing (its clock moves on by the time held); after a recall, the chosen
 *   speed-ups are put on and confirmed running again before the generals leave home. Unit: tests/unit/adventure-startup-hold.test.js.
 * 0.2.100 (2026-11-20, author: every speed-up must run before the first adventure starts; live YWC: on a resume no speed-up was
 *   put on, and on a fresh start the speed-ups were sent but never ran): the chosen speed-ups are put on, then confirmed running (the
 *   zone buff runs, or its star count went down; the Observatory's accepted order) before the adventure opens — and before the generals
 *   of a resumed open adventure leave home. Not running after 30 s: put on again; after 120 s: stop. A speed-up
 *   already running is not put on again. Unit: tests/unit/adventure-travel-confirm.test.js.
 * 0.2.99 (2026-11-20, author: "in de speed it up overzicht mis ik vortex en obs en ik weet niet of de sluit uit functie al werkt"): (1) the
 *   OBSERVATORY: its star charts (the game's recipe list of the Observatory, e.g. PropagationBuff_AdventureZoneTravelBoostLow/Medium/High)
 *   are speed-ups too, offered as "Observatory:<recipe>" with the number of Observatories ready (no cooldown); chosen, one ready
 *   Observatory starts the chart (START_TIMED_PRODUCTION, as the Love Tree) unless its buff already runs. (2) The speed-ups go on in phase
 *   1, just before the adventure is opened from the star — a star chart only counts for an adventure started while it runs. (3)
 *   EXCLUSIVITY: the game gives these buffs no exclusivity group (live read 2026-11-20: GetExclusivityGroup "" for Black Vortex, Doggy Bag
 *   and the horseshoes), so the player's rule adv.travel.exclusive names the families that exclude each other (default
 *   "GeneralSpeedBuff_;Observatory:" — one horseshoe, one star chart); a game group, when there is one, still wins. Black Vortex and Doggy
 *   Bag stack (tsowiki: "Stacks with other buffs of the same type").
 *   Unit: tests/unit/adventure-travel-buffs.test.js.
 * 0.2.98 (2026-11-20, author: "het is geen keuze per avontuur, het is een algemene instelling bij enkele avonturen en bij runs en zelfs bij
 *   chains"): the travel speed-ups are one general setting, adv.travel, used by every run whatever started it (Run once, the adventure
 *   manager's kept runs, a series). Unit: tests/unit/adventure-travel-buffs.test.js.
 * 0.2.97 (2026-11-20, author: "Als vortex aangevinkt is, heb je twee uur lang versnelde reistijd van de generaals en zo zijn er nog meer
 *   mogelijkheden om dat te versnellen, dat moet de speler aan kunnen zetten" — "selecties die elkaar uitsluiten kun je niet combineren"):
 *   TRAVEL SPEED-UPS, per adventure (rule adv.<id>.travel, a list of star buffs; default empty). Phase 2, before the first send at home,
 *   each chosen buff is put on the zone from the star unless it — or another buff of its exclusivity group — is already running; the
 *   exclusivity group is the game's (BuffSystem::cBuffDefinition.GetByName(name).GetExclusivityGroup()). exclusive(list) tells whether a
 *   choice holds two buffs of one group (the policy refuses such a choice); travelBuffs() lists the star's buffs whose name matches the
 *   player's rule adv.travel.match (default "TravelBoost|StarChart|GeneralSpeedBuff|TravelDocuments"), with count and group.
 *   Unit: tests/unit/adventure-travel-buffs.test.js. Integration: live, a YWC run with Black Vortex chosen logs "travel: ... applied" once
 *   and not again while it runs.
 * 0.2.96 (2026-11-20, author: "Als ywc meer oil seed oplevert dan gaan we over op ywc" — "de marge tussen de generaals bij de aanvallen
 *   is veranderd ten opzichte van mijn mundanes ... de mijne sloten precies op elkaar aan"): per adventure the player may override the
 *   ALL rules: adv.<id>.asIs (play this adventure's Mundane as it is, with its own order and times, even when ALL camp by camp is on) and
 *   adv.<id>.retreat (retreat on interception for this adventure). YWC intercepts some generals on purpose, so the policy defaults are
 *   adv.ywc.asIs on and adv.ywc.retreat off. Without an override the ALL rules decide, as before.
 *   Unit: tests/unit/adventure-per-adv-rules.test.js.
 * 0.2.95 (2026-11-20, live FT; author: "op het moment dat alle generaals weggestuurd zijn voor de eerste aanval, dan kun je al beginnen
 *   met het klaar zetten van de tweede aanval, sterker nog dat kun je doen bij het verplaatsen van de generaals van de eerste aanval naar
 *   de locatie van de eerste aanval, je kunt de generaal van de tweede aanval al uit de star halen en plaatsen" — "Leer van deze avontuur,
 *   hoe je dat in het algemeen kunt toepassen bij alle avonturen, ongeacht welke generaals het betreft"): PRE-STAGING, for every adventure
 *   and every template (rule adv.prestage, default on). While a round moves, attacks or fights, the generals of the NEXT round that are
 *   not in the current round are made ready: an idle general of the next round in the star is placed on its own spot when that spot is
 *   free and placeable; an idle general of the next round standing on its spot gets its army loaded. Nothing attacks early: the next round
 *   still starts when the current one is done, and then finds its generals in place and loaded. A general that the current round also
 *   uses is left alone. At most one placing and one loading pass every 20 s.
 *   Unit: tests/unit/adventure-prestage.test.js. Integration: live, the next run's log shows "<next>: n generals of the next attack placed
 *   from the star" during the fight, and its LOADR goes straight to MOVE / ATTACK.
 * 0.2.94 (2026-11-20, ADR 0088 S-5): runOnce(id, source, version, resumeOnly, how) takes how.by, the initiator of TK18 (the adventure
 *   manager, user_dma_adventure_manager.js); without it the request is the player's, as before. Nothing else changes.
 *   Unit: tests/unit/adventure-manager.test.js (the manager passes by). Integration: tests/integration/adventure-manager-keeps-ft.test.js.
 * 0.2.44 (2026-11-09, author: "Ja" — repair what the TX page showed: TK18 adv:gp@1794198813279 promised since 04:33 and
 *   TK19 loot spots of GP runs open, both cut off by a client restart; the next run started as a new case): a run that
 *   starts while the run file still says a run is active (it was cut off) first ends that run's TK18 (revoke promise,
 *   allow, decline: "the client restarted during this run; a new run took over"). At LS_OFFER a kept loot-spot case
 *   that cannot be continued (another zone, or older than an hour) is closed through DMA_LootSpots.abandon (lootspots
 *   0.1.9) instead of being left. Unit: tests/unit/dma-adventure-orphans.test.js; integration: live, after a restart
 *   during a GP run the TX page holds neither the old TK18 nor its loot spots.
 * 0.2.43 (2026-11-08, ADR 0051, author: "multi windows uitproberen en dus het thuis eiland op orde houden tijdens het
 *   avontuur"): with the client's multi-window option, the run belongs to the adventure window. The home window does not
 *   resume an active run after a restart while an adventure window is alive (DMA_WINDOW.advAlive(), its heartbeat);
 *   it logs that it left the run to that window. Without 00_dma_window.js nothing changes.
 *   Unit: tests/unit/dma-adventure-window.test.js. Integration: after a client restart only the adventure window
 *   resumes the run (one executor status writer).
 * 0.2.42 (2026-11-04, live AtFotM: the next set stopped at once — "still open: all its quests are done" — because the
 *   0.2.41 DONE with open quests still put the zone on the done list): a run that leaves the adventure open
 *   (keepOpen) does not mark its zone done.
 * 0.2.41 (2026-11-04, live At the Foot of the Mountain: a set that cleared only sector 2 ended with "all rounds
 *   played", and FINISH sent 26 generals home although the adventure had open quests and three more sectors): FINISH
 *   sends the generals home and presses Return only when the last quest is rewarded or no quest is open; otherwise the
 *   run ends DONE with the generals left on the island for the next set.
 * 0.2.40 (2026-11-04, live At the Foot of the Mountain: while the client was on the home island, LOADR judged the
 *   round's camp "already gone", skipped every round, and FINISH sent all 50 generals home with three camps still
 *   standing): camps are judged only while the adventure is the viewed zone; elsewhere LOADR first visits it.
 * 0.2.39 (2026-11-04, live At the Foot of the Mountain, twice: from a fallback grid the attack hit ANOTHER camp — OGG
 *   for 2856 hit 3205, RES for 5103 hit 5461 — and lost; author: "daar wordt aangegeven van waaruit je aanvalt. De
 *   generaal moet vanuit die plek gestart worden"): a fallback grid must lie on the target's side — no other camp with
 *   units may be as near to it as the target — and its path to the target may be at most 1.5 x the path from the
 *   template grid. When no grid qualifies the general stays where he is and MOVE gives up as before.
 * 0.2.38 (2026-11-04, live At the Foot of the Mountain round 3: after a restart the two decoys of the round were
 *   busy RECOVERING from their defeat in round 2 (cSpecialistTask_Recover, about an hour), the resume rule took them for
 *   "already attacking" and sent the main wave alone, which lost): a general whose task is Recover is not part of an
 *   attack. LOADR waits for recovering generals (up to 3 hours, logged once) instead of resuming an attack, and the
 *   resume rule counts only busy generals that are not recovering.
 * 0.2.37 (2026-11-04, live At the Foot of the Mountain, rounds 1 and 2: a template grid the game would not let the
 *   general stand on — the grids came from one placement scan for another general earlier on — kept him where he was
 *   until MOVE gave up): before a move the executor asks the game whether the general may stand on his round grid
 *   (CheckIfGarrisonIsPlacableInGame, the check the Mundane window's placement uses). When he may not, it takes the
 *   placeable grid within 6 tiles that is not next to another general of the round and has the shortest path to his
 *   camp, keeps it for the rest of the round and logs the swap. Without a target: the nearest placeable grid.
 * 0.2.36 (2026-11-04, live At the Foot of the Mountain: "AtFotM sim attack 01.txt: 1 generals could not take their
 *   position" — Champion Nusala was walking from his landing field 56 rows south, a Move task of about 13 minutes,
 *   and MOVE gave up after its fixed 5 minutes and re-sent the move every 30 s): a general with a Move task to his round
 *   grid is walking, not stuck. MOVE does not re-send the move to a walking general and gives up only when no general is
 *   walking after 5 minutes, or after 30 minutes in any case.
 * 0.2.35 (2026-11-03, live Sleepy Reef from generated templates: "send 1: 5 generals" -> "all 5 generals on their way"
 *   two seconds later, but three stayed home, loaded and idle, and the run stopped 30 min later with "3 generals did not
 *   arrive"): a sent general is busy for a moment even when the send does not take; SEND now judges who stayed home only
 *   15 s after its last send, and sends those again (up to 3 sends, as before).
 *   Unit/integration expectation: dma-adventure-run.test.js (a general busy for a moment after the send, then idle at
 *   home, is sent again and the run reaches DONE); live: the next run leaves with every general.
 * 0.2.34 (2026-11-02, live: the client did not load 0.2.33 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.2.33 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   playing an adventure is a DEMO transaction (TK18), one instance per run (case adv:<id>@<start ms>, kept in the run
 *   file so a resume after a restart continues the same case): request (the player, Run once) -> promise (the adventure
 *   runner starts) -> execute (the run) -> declare (DONE: home) -> accept (the player, tacit); a run that STOPPED is
 *   revoke promise + allow (tacit) + decline, with the reason. Behaviour unchanged.
 *   Unit/integration expectation: dma-adventure-run (DONE gives request, promise, declare, accept; a stop gives the
 *   decline); tests/unit/dma-demo4-acts.test.js.
 * 0.2.32 (2026-11-01, live FT resume: "FT05: resuming the attack, 5 generals not yet sent" three rounds after the resume):
 *   the resume flag only concerns the round that was going on at the restart. A round whose camps are gone ends it,
 *   so a later round with a general still recovering is played as a normal round, not as a cut-off attack.
 *   Integration: dma-adventure-run.test.js (the flag is cleared after the first round played after a resume).
 * 0.2.31 (2026-11-01, test-day proposals P1/P7; author: "Voer alle verbeteringen maar door"):
 *   - gateway guestGenerals(zone): per invited player, how many of his generals are busy on our adventure (the loot-spot
 *     PBC 0.1.6 counts a guest's finished attack as his kill);
 *   - the loot-spot case is kept in dma-adv-ls.json at every step; after a restart the same adventure (same zone, under
 *     60 min old) continues it instead of posting the offer again.
 *   Unit/integration: dma-adventure-arrows.test.js (a kept case is restored: no second offer).
 * 0.2.30 (2026-11-01, test day: a restart while the 17 FT generals travelled; the resume took 3 generals still walking
 *   for "fighting", went to FIGHT and stopped 13 min later with "3 camp(s) survived the attack" — FT02 was never sent):
 *   a resume reads the state the run had before the restart (dma-adv-status.json, same adventure). Was it START, LOAD
 *   or TRAVEL, the run goes on as if there had been no restart (arrival = here AND idle); only a restart in LOADR,
 *   MOVE, ATTACK or FIGHT (or an unknown state) resumes the way 0.2.7-0.2.8 do.
 *   Unit/integration: dma-adventure-run.test.js (resume after a restart in TRAVEL waits for idle generals and attacks).
 * 0.1.0 (2026-10-31, author: "ik heb hem aangevinkt, gaat hij FT nu automatisch uitvoeren? kun je ook een button maken,
 *   eenmalig uitvoeren?" — "ja"): plays one adventure from the star to home, round by round, with the player's own
 *   Mundane Warfare templates in the order the advisor (user_dma_mundane.js, ADR 0033) finds:
 *     PRECHECK  at home: the adventure is in the star (above adv.<id>.minStock), none of ours is open, the load
 *               template's troops are available (adv.<id>.checkArmy)
 *     START     use the adventure from the star (server action 61 with the star item's id); wait for its zone
 *     LOAD      load the load template's armies at home (the client's own Mundane functions, 5-army.js)
 *     SEND      send every template general to the adventure; reload and send again what stayed home (max 3x)
 *     TRAVEL    visit the adventure; wait until every general has arrived; with the star method
 *               (adv.mundane.starMethod) idle generals on the island go back to the star
 *     ROUND n   per round template: load army (up to 3 passes: units given back count only on the next pass) →
 *               move (from the star too) → attack when every target is reachable → wait until the round's camps are
 *               gone and its generals idle; then idle generals not in the next round go back to the star
 *     FINISH    collect (adv.<id>.collect), claim finished quests (adv.<id>.claim), send the generals home, go home
 *   Never gems, no speed-ups, no buys: only load, send, move, attack, return to star, quest claim and collect.
 *   Any step that does not reach its goal in time STOPS the run with the reason (status dma-adv-status.json and the
 *   console); the player can stop at any time.
 *   Game calls go through the client's own army/battle layer (scripts/5-army.js, 5-battle.js: battlePacket,
 *   armyLoadDataCheck, armyLoadGenerals, battleLoadDataCheck, battleMove, battleAttack, armySendGeneralToStar,
 *   armyServices) — the same functions the Mundane window uses — in one gateway object (G) that the tests replace.
 * 0.1.1 (2026-10-31, live run 1: "error in LOAD: battleWindow is not an object" after the adventure opened): loading
 *   sends the client's dRaiseArmyVO itself (armyLoadGenerals(true) needs the Mundane window); an open adventure of ours
 *   whose generals are all still home is resumed at LOAD instead of stopping.
 * 0.1.2 (2026-10-31, live run 2: the client restarted while the generals were travelling and the run was lost): the
 *   run is kept in dma-adv-run.json and resumes 90 s after a restart; PRECHECK resumes at TRAVEL when the generals have
 *   left (or when the client is already on the adventure); a round whose camps are all gone is skipped; arrival means
 *   present and idle (travelling generals are already listed in the zone).
 * 0.1.3 (2026-10-31, live run 3: "error in TRAVEL: s.GetTask is not a function" while generals were landing): a
 *   specialist object without methods counts as not here yet; every read of it is guarded.
 * 0.1.4 (2026-10-31, live run 3: "FT02: 3 generals could not take their position" — the Mundane window showed their
 *   objective red: its canMove check is false for a general in the star): moves are sent directly (95/4 on the template
 *   grid, 1.2 s apart) for every template general that is idle and not on its grid.
 * 0.1.5 (2026-10-31, live FT04: three load passes 2 s apart, "armies still differ"): repeated attempts are spaced
 *   from the previous attempt (load 15 s, move 30 s, send 20 s), not from the state's start; up to 4 load passes, so
 *   units a general gives back are in the pool before the next pass.
 * 0.1.6 (2026-10-31, live FT: all camps gone at 08:13, then "error in FINISH: GetQuest_vector().forEach is not a
 *   function"): the quest vector is walked by index.
 * 0.1.7 (2026-10-31, first automatic FT done 08:21; its icon stayed in the list): at DONE the adventure is removed
 *   from the client's list; a later run removes a listed adventure it finished before instead of resuming it.
 * 0.1.8 (2026-10-31, ADR 0034 step 1; run 4 left "Following the Trail" unclaimed and the adventure listed): quests
 *   are handled during the fights every 30 s the way the quest book does it — OK new quests, reward finished ones with
 *   the book shown — and the reward of the quest marked lastQuest is reported (it ends the adventure). probe() writes a
 *   read-only inventory of the star's adventures and the adventure objects (dma-adv-probe.json) for the catalogue.
 * 0.2.0 (2026-10-31, ADR 0035 step 2): any adventure of the catalogue can be run by its star item name; the adventure
 *   book (dma-adv-book.json) keeps per adventure its versions (name, way of playing: full / quick loot / hybrid /
 *   arrows only, template folder), the default version and the last 10 results; starCounts() for the overview.
 * 0.2.1 (2026-10-31): versions carry their analysis; watch() re-analyses changed folders (every 10 min and when the
 *   ADVS page opens), adopts a found template folder as version "full" when its analysis has a load and rounds, and
 *   lists star adventures unknown to the catalogue.
 * 0.2.2 (2026-10-31, live: after 0.1.7 removed the finished FT from the client's list a new FT did not open — the old
 *   one was still open on the server; author: "het programma onderkende niet dat het runnende programma nog niet
 *   afgesloten is"): a finished-but-listed adventure is never hidden; PRECHECK stops and asks to close it; the probe also
 *   lists the game's quest and adventure methods, to find how the game closes an adventure.
 * 0.2.3 (2026-10-31): the resume after a restart only continues an adventure of ours that is open (never uses a new
 *   one from the star) and only for a run started in the last 6 hours.
 * 0.2.4 (2026-10-31, author: "I want the restart recognize a adv is running and continue because it was given to the
 *   program"): a run handed to the program (Run once, still active in dma-adv-run.json) always continues after any
 *   restart, whatever its age — 90 s after load it goes to the open adventure and plays on from the first round whose
 *   camps still stand. It never starts a new adventure from the star, and stops if no adventure of ours is open.
 * 0.2.29 (2026-10-31, author: "waarom wordt het ywc nu niet gesloten?" — last quest rewarded, status null): Return as
 *   the client does it: the finished adventure is looked up by zone and by the home player's id, and any finished
 *   adventure of ours in the list is dropped before going home.
 * 0.2.28 (2026-10-31, export for other players): no automatic approval of loot-spot lines for anyone; a player approves
 *   his own with the ADVS checkbox (the author's approval is already in his book).
 * 0.2.27 (2026-10-31, author: "hybrid heeft een groene vink en learned een rood kruis" — same folder; learned was
 *   analysed at 18:39 while generals were on TT): the watch also re-analyses a version whose analysis has an error.
 * 0.2.26 (2026-10-31, live TT demonstration check): learning reads the chat from its own start (ms; the client cannot
 *   parse the ISO date, so the GP chat of earlier became the TT loot spots); a saved demonstration keeps every action
 *   and only the last 150 chat lines (250 chat lines had pushed the attacks after 18:21 out of the 300 kept); loot spots
 *   are kept only when someone was invited; a wrong loot-spot record from before is dropped at load.
 * 0.2.25 (2026-10-31, live TT demonstration): a demonstration in which generals moved is saved as a "hybrid" version
 *   on the default version's template folder (its Mundane rounds give the generals, the learned arrows its plan);
 *   arrows alone stay "arrows only". Unit: a demo with moves becomes hybrid with the folder.
 * 0.2.24 (2026-10-31, author: TT like YWC — the Suspicious Boulder first, with a Rain of Flaming Arrows): buff entries
 *   of a template are rounds of their own: their camps are targets, the attack fills the buff stock first.
 * 0.2.23 (2026-10-31, author: "gewoon altijd c laten drukken"): collecting presses the client's own pick-up-all (C)
 *   on arrival, after every camp that falls and before the quests; the 0.2.22 search is the fallback.
 * 0.2.22 (2026-10-31, author: "nog steeds geen collectables"): collect as the client's own pick-up-all: collectible
 *   buildings plus, on an adventure, the quest-trigger buildings without units (not enemy camps), one per second.
 * 0.2.21 (2026-10-31, author: "hij vergeet de collectables"): the arrows run collects on arrival and again before the
 *   quests (rule adv.<id>.collect). Unit: fake run collects; integration: GP.
 * 0.2.20 (2026-10-31, live GP with two loot spots: the last quest was claimed, the status stayed "started", the run
 *   stopped instead of returning): after the last quest the arrows run presses Return within 1 minute.
 * 0.2.19 (2026-10-31, live: GP closed without loot spots): a loot-spot phase that could not offer stops the run and
 *   leaves the adventure open. Unit: lootspots test (offer retried, then failed); integration: next GP.
 * 0.2.18 (2026-10-31, author: one loot-spot setting for every adventure, revoke handling, "demo patroon"): the loot
 *   spots of a run are played by the loot-spot PBC (user_dma_lootspots.js) with the global rules; cancelInvite for a
 *   pending invitation. Unit: the arrows test runs the PBC; integration: GP Run once.
 * 0.2.17 (2026-10-31, author: "nee met ls uitnodiging en alles"): after the arrows the run replays the learned loot
 *   spots when approved: offer (learned text) in the guild chat, the first who ask (request words), invite them as the
 *   adventure panel does, announce (learned text, names filled in), wait for their kd, then quests and Return. GP rules
 *   give the waits and words. Unit: fake run with chat and invites to DONE; integration: GP Run once.
 * 0.2.16 (2026-10-31, author: "run once werkt nog niet"): the console's short keys gp / ae / vlt resolve to their star
 *   item names. Unit: resOf("gp") = "Gunpowder"; integration: Run once on Gunpowder starts the arrows run.
 * 0.2.15 (2026-10-31, author: "Het zou toch allebei het Dark Castle moeten zijn?"): an arrow goes to a target camp
 *   first (quest-named, else castle), then the previous arrow's camp; an arrow on a non-target camp within 30 s of one
 *   on a target belongs to that target; a quest trigger naming a camp on the map is a target; the announcement replaces
 *   names in any case; learned versions are re-planned once at load. Unit: the live GP steps give Dark_Castle_01:
 *   Flaming x1 > Cupid x1.
 * 0.2.14 (2026-10-31, author: "de demo actiehandelingen moeten ondersteund worden"): learning also records the chat
 *   (own lines and others', with channel) and the invited players (invite / joined / left); saving derives the
 *   loot-spot communication (offer text, request words, invited, announcement with {player1}.., kills) — its replay in the
 *   guild chat waits for the author's approval (ls.approved). onOwnAdventure() for the RT. Unit: learnLs from a GP demo.
 * 0.2.13 (2026-10-31, live: the GP demonstration recorded 0 actions): learning observes — arrow counts in the star
 *   and units per camp every 1.5 s (an arrow used goes to the camp that loses most units), generals' grid and busy
 *   state; the camps to destroy fall back to the castles on the map ("Defeat all black castles"); the quest triggers
 *   are kept in the map for diagnosis. Unit: fake observation (Flaming, then Cupid on the castle) -> plan.
 * 0.2.12 (2026-10-31, author: "een leerfunctie ... voorgedaan ... opgeslagen en nagedaan ... vervangen, of ... een
 *   tweede versie"): startLearning(res, name, replace) / stopLearning(save) record the player's actions on our open
 *   adventure (arrows decoded: arrow, camp, units) and save them as a version: the arrows become the plan per camp.
 *   Unit: a recorded demo (Flaming once, Cupid twice on the castle) becomes that plan; integration: GP demo.
 * 0.2.11 (2026-10-31, author: "als je alleen arrows selecteert, hoeft hij niet naar een template te zoeken"): an
 *   "arrows only" version has no folder; its analysis is the camps to destroy (from the learned map) and a plan per camp
 *   (default: Rain of Flaming Arrows once, then Cupid's Arrow up to 5); the arrow run starts the adventure, goes there,
 *   applies the plan camp by camp (waits until the unit count settles), claims the quests and presses Return.
 *   Unit: fake world plays an arrows-only run to DONE; integration: GP.
 * 0.2.10 (2026-10-31, author: "herkent welke kampen vernietigd moeten worden ... per kamp aangeven hoe hij dat wil"):
 *   campMap() reads the adventure's camps and the camps its quests ask to destroy; runs (and visits, see below) keep
 *   them in book[res].map. A run whose adventure was closed by the player ends DONE. Unit: learnMap merges; integration: GP.
 * 0.2.9 (2026-10-31, live: "now return home button need to be pressed"): no camp left -> the last round goes on to
 *   FINISH without waiting for recovering generals; other rounds wait at most 3 min. Unit: fake world; integration: next run.
 * 0.2.78 (2026-11-15, author: "Maak de test variant zo dat de speler de mogelijkheid heeft per avontuur meerdere varianten
 *   aan te maken met een naam en nummer. De folder waar het in vastgelegd wordt heeft dezelfde naam"): mode "test";
 *   addTest(res, name, base) gives the version "test NN <name>" (NN = next free number for that adventure) and makes the
 *   folder <base>\test NN <name>. Unit: dma-adventure-test-variants.test.js (numbers 01, 02; folder = name; a third
 *   after removing the first is 03). Integration: ADVS ▶ New version, mode test, name "blocks" -> folder made, row shown.
 * 0.2.77 (2026-11-14, live 17:41Z: "error in TRAVEL: spec.GetGarrison is not a function" while 70 generals arrived):
 *   sending a general to the star is tried per general; one the game cannot send is logged, not fatal.
 * 0.2.76 (2026-11-14, author: "je hebt normaal 1 generaal per kamp, ook een block"): attackers with queue: true are sent
 *   2 s apart — the main follows the wave and waits at the leader while the wave fights — and a block covers only their
 *   passage through the watched streets, not the fight at the leader (where a waiting general cannot be caught).
 * 0.2.75 (2026-11-14, live: the v4 load of 70 generals was still filling after 4 passes and the run stopped; a minute
 *   later all 70 matched): the load gets one pass per 8 generals, at least 4.
 * 0.2.74 (2026-11-14, blocks v4 with 50 new spots): a blocker that is sent and whose own way a live camp other than its
 *   target watches, with no chain on that camp, refuses the layer — it would be caught there and leave its camp unblocked.
 * 0.2.73 (2026-11-14, ADR 0066 plan v4, author: normal blocks first, 1R only where they cannot): a block with keep: true
 *   is the tail of its chain, timed to be fighting when the leader falls (last attacker's arrival + fightMs), starting at
 *   least the margin before and lasting at least the margin after; 1R blocks only before it. If the 1R head cannot bring
 *   it there, the chain is 1R to the end. The foe guard retreats a normal block still walking with the later attackers.
 *   Waiting for recovering blockers (0.2.70) and for recovering generals now lasts up to 4.5 h (a 1R block recovers 4 h).
 * 0.2.72 (2026-11-14, live BB 13:41-13:51Z: all six blockers of step 01 were left out while recovering and MOUTH was sent
 *   alone through the watch of 1.2, caught three times and retreated three times): planSends refuses an attacker whose way a
 *   live camp watches that no blocker in the layer takes ("crosses the watch of … and no blocker in the layer takes …");
 *   while blockers recover the run waits for them (0.2.70) instead. Blocker twins (author: "naast elke block generaal komt
 *   er nog 1 die de 2e aanval de block verzorgt"): a step may list more blockers per camp than the chain needs; the ones
 *   recovering are left out (0.2.58) and the chain is built from the ready ones.
 * 0.2.93 (2026-11-18, author: "Hoe kan het dat er nog steeds MM en MS verliezen zijn?"): the troop count before every
 *   round and at the end also keeps every general's army, so the losses per wave can be put on the general and its camp.
 * 0.2.92 (2026-11-18, ADR 0082; author: "Dus je hebt fases voor elk avontuur: 1. prepare op je home island voordat je het
 *   avontuur start 2. start avontuur en sturen troepen 3. handelingen na landing troepen tot aan 1e aanval 4. aanval (kan
 *   meerdere mundanes zijn inclusief verplaatsen) 5. laden troepen en afronden avontuur"): every state of the run belongs to
 *   one of the five phases (phaseOf); the status shows the phase, the log marks each change, and the book keeps the phases
 *   with their times per run. Unit: tests/unit/dma-adventure-reliability.test.js (phases).
 * 0.2.91 (2026-11-18, author: "De oplossing zit hem in het mundane script en hoe je dat aanvliegt. Als je weet dat alle
 *   generaals geplaatst gaan worden vanuit star, dan breng je alles naar star inclusief de marshalls ... Na alle aanvallen
 *   (het avontuur geeft zelf aan dat het completed is), zet je de marshalls op het eiland en laad je alle troepen. Als alle
 *   troepen geladen zijn, hoef je alleen maar het avontuur af te melden door de completed te acknowledgen."): THE STAR FLOW.
 *   On arrival every general and marshal goes to the star once, before round 1; each round moves its generals from the star
 *   to their spots, loads and attacks; the next round only loads and attacks with the same generals. The marshals keep their
 *   cargo in the star (0.2.89's unloading is replaced). At the end the marshals come out of the star onto their load spots,
 *   the loose troops are stowed into them, then the adventure is acknowledged as before.
 *   Unit: tests/unit/dma-adventure-reliability.test.js (star flow at arrival and at the end).
 * 0.2.90 (2026-11-18, author: "Ga je gang" — step 2 of the plan: measure the real losses): the troops on the island (our
 *   generals plus loose) are counted before every round and at the end, logged, and kept with the run in the book
 *   (runs[].troops), so the losses per wave can be compared with the simulation and the margin set per adventure.
 *   Unit: tests/unit/dma-adventure-reliability.test.js (troop count).
 * 0.2.89 (2026-11-18, author: "Je hebt QM-Q, Njoern en the smugler nog over, kies maar"): CARRIERS. Generals of the load
 *   template that fight in no round (quartermasters, transporters) are emptied before round 1 — a carrier in the star is
 *   first moved to its load spot — so their cargo lies free for every round's load (two-waves risk 2: a transporter in the
 *   star was never unloaded). At most 5 minutes. Unit: tests/unit/dma-adventure-reliability.test.js (carriers).
 * 0.2.88 (2026-11-18, author: "pas alle lessen toe om het meer betrouwbaar te maken — een goede template is er juist voor
 *   om een run herhaaldelijk foutloos te kunnen afdraaien en daar zijn we nog niet"; the Bonaberti "two waves" run of
 *   2026-11-17; ADR 0080):
 *   F10  the status file follows the log during a step (at most every 10 s), not only on a state change.
 *   F16a before a short load, idle generals on the map that hold more of a short type than their packet (or are not in
 *        the round) give it back first (shedPlan: only the short type is reduced, no new type, no zero amount).
 *   F16b a version without blocks with more than one wave: waveLoadCheck — per unit type the load carries every wave plus
 *        the expected losses of the waves before it (ranged 10 %, all others 100 %) times 1 + adv.waves.loadMargin (0.25);
 *        short → finding LOAD_SHORT (error), analysis not ok. runOnce refuses a version whose analysis is not ok.
 *   F17  FINISH waits (at most 8 min) while troops lie loose and generals on the map are recovering, then stows them.
 *   F18  Finish camp by camp finishes an open adventure with the version its last run played, never with a version whose
 *        analysis is not ok (live: the default "full" ran a stray test template).
 *   F19  in waves / camp by camp / emergency, a general whose spot is held by a busy general attacks from where it stands
 *        or from the nearest placeable spot (the generals of a camp go one after the other there).
 *   Unit: tests/unit/dma-adventure-reliability.test.js, tests/unit/dma-adventure-move-rules.test.js case 5.
 *   Integration: the next Bonaberti "two waves" refuses to start with the shortage per unit, or plays both waves without a
 *   stop and leaves nothing loose.
 * 0.2.87 (2026-11-17, UAT finding F15; live BB 12:50-12:55Z: GHOST3 stood on SYL3's spot 6001 and SYL3 on GHOST3's spot
 *   5454 — both share their camp, so neither took a substitute spot and the round stopped at the move time-out): a waiting
 *   general whose own spot is held by an idle general that is not on its own spot (of this round or none) sends that holder
 *   to the star once; the next move brings both to their spots. mapGenerals() reports each general's grid.
 * 0.2.86 (2026-11-17, UAT finding F12; live BB 09:16Z): a resumed run (0.2.85) whose first step cannot load because the
 *   generals on the island carry another version's troops, and before any camp of the version has fallen, goes to RECALL: loose troops are
 *   stowed, every general goes home with its troops, and once all are idle at home the run loads its own load template and
 *   sends again (LOAD → SEND → TRAVEL). Once per run; after an attack the stop stays as before.
 * 0.2.85 (2026-11-17, UAT finding F11; live BB 07:56-08:26Z): a resumed open adventure whose template generals are partly
 *   home (another version had sent some of them) no longer goes straight to TRAVEL — the ones still idle at home are loaded
 *   and sent first (run.part), the others are taken to be on the adventure. The arrival stop names the missing generals.
 * 0.2.84 (2026-11-17, ADR 0079; author: "de speler heeft meerdere mogelijkheden bij het aanmaken van een nieuwe versie op
 *   een avontuur: block, zonder block, kamp voor kamp" — "De kamp voor kamp opzet ... is een noodgreep, een modus die je
 *   altijd beschikbaar moet hebben om een avontuur te kunnen beeindigen" — "een versie zonder blocks in twee waves waarbij we
 *   de gens hergebruiken" — "Wellicht zelfs het advies bij dit avontuur geen blocks te gebruiken"):
 *   (1) MODES gains the version kinds "blocks", "without blocks", "camp by camp", "shared Mundane"; the version's kind sets
 *       the way it is played: "camp by camp" = rule campByCamp for this run; "without blocks" = waves: each attack template
 *       is a wave, block entries stop the step, every camp starts as soon as its next attacker's way crosses no live camp
 *       other than its own target, a camp's next attacker leaves when the one before is fighting there, the next wave is the
 *       next round (the same generals come back, recover and are loaded again).
 *   (2) finishCampByCamp(id, source, version): the emergency mode, for any version: a run going on switches to camp by camp
 *       (a step under way is waited for, then loaded again); with no run going, the open adventure is resumed camp by camp.
 *       In this mode a camp whose way is still watched waits while another camp whose way is clear goes first; the run
 *       stops only when no remaining camp can be reached or a camp survives every attacker.
 *   (3) analyse(folder, res, mode) counts block entries; where the catalogue advises no blocks (Bonaberti) a version with
 *       blocks gets the warning NO_BLOCKS_ADVISED; a "without blocks" version with blocks gets the error BLOCKS_IN_WAVES;
 *       analysis.advice carries the catalogue's advice for the ADVS page.
 *   Unit: tests/unit/dma-adventure-kinds.test.js (waves: two camps in parallel, a watched camp waits for the camp that
 *   watches it, main after wave; emergency on a running run with reorder; analysis warnings). Integration: Bonaberti
 *   "two waves" (docs/06-adventures/bonaberti-business-two-waves.md) — no main reaches its camp before its wave; wave 2
 *   starts after wave 1's camps fell and its generals are back and loaded; Finish camp by camp ends a stopped run.
 * 0.2.83 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C4 of the migration): the executor does not
 *   send itself. Its gateway's seven sends go through the Game Interface Adapter by registered name: raise army 1031 (twice:
 *   the planned raises and the packet load) = RAISE_ARMY; the star item that opens the adventure, the horseshoe (zone buff) and
 *   the arrows = STAR_ITEM (61); the move out of the star = SPECIALIST_TASK (95/4); the zone refresh 1037 = ZONE_REFRESH. The
 *   adapter owns the guard, the holds and the pace and opens control's permit for the one call; the adventure passes
 *   ctx { away: true } whenever it is not on the home island, so that the visit hold (which the travel itself raises) does not
 *   stop its own run — only the start-up hold applies there (ADR 0073 open point). The gateway answers { ok, reason, retry } where it
 *   answered { ok } and keeps true/false where it answered a boolean (the reason is then in G.refusal()). Opening the adventure
 *   (the star item) is the executor's promise: on a refusal it does not go to START — a transient refusal (hold, pace) waits, any
 *   other stops the run with the adapter's reason. The deferred sends (setTimeout, 1 s apart) keep their schedule; a refusal there
 *   is recorded by the adapter as the fact "send refused" and the existing re-check of the state machine re-sends. No adapter
 *   loaded = refused "game interface adapter not loaded". This is the fix of kf-adventure-sends-blocked-by-control, which moves
 *   into the suite as tests/integration/adventure-sends-through-adapter.test.js.
 *   Unit: tests/unit/dma-adventure-gateway-adapter.test.js (each gateway send reaches the adapter by its name with away set off
 *   home; a refusal comes back as { ok: false, reason }). Integration: tests/integration/adventure-sends-through-adapter.test.js
 *   (real control + adapter + adventure gateway).
 * 0.2.82 (2026-11-16, architect verdict on PR #385; standing rule "Loading armies" in project memory — E:1008 on 1031
 *   closes the client; probe 0.1.37): stowPlan loads only an EMPTY general (any loose types) or a general that already
 *   holds a unit type, and then only that type — never a raise that adds a new type to a loaded general. A general's army
 *   is sent without zero amounts. Loaded generals are filled first (with their own types), the empty ones after them, so an
 *   empty general is kept for the types no loaded general holds. Loose units no fitting general can take stay loose and
 *   are counted ("no fitting general or capacity").
 *   Unit: tests/unit/dma-adventure-stow.test.js (a loaded general takes only its own types; an empty one takes any; no
 *   new type and no zero amount in any raise). Integration: tests/integration/dma-adventure-stow-run.test.js (in a whole
 *   run every raise keeps each loaded general's types; a loose type no general holds goes into an empty general or
 *   stays loose).
 * 0.2.81 (2026-11-16, author: "before an adventure is closed, every loose troop is loaded into the generals still on the
 *   map" — project memory "Closing an adventure: load the troops first"; seen after Bonaberti Business: 1 341 MS + 393
 *   others travelled home loose, 1 h 39 min left): STOW BEFORE CLOSING, for every adventure and both runners. Before the
 *   main executor's FINISH sends its generals home, and before the loot-spot runner's QUESTS presses Return, the loose
 *   troops on the adventure map (the client's armyFreeInfo on the viewed adventure zone) are raised into the idle
 *   generals and marshals still on the map, each up to its capacity (dRaiseArmyVO 1031 with the general's own army plus
 *   the added units, 1 s apart, as the probe's raisehere does); then the run waits for the raises (n + 3 s) and goes on
 *   as before. Loaded troops return with their general at once; loose ones travel about two hours. Order: the largest
 *   loose stack first; a general in the star, travelling or busy is not used; nothing is unloaded. Rule
 *   adv.stowLoose (default on; a run's rules may say false). A gateway without the three reads/acts skips it.
 *   Unit: tests/unit/dma-adventure-stow.test.js (the plan: capacity respected, own army kept, largest stack first, busy
 *   and star generals skipped, nothing to stow -> no raise). Integration: tests/integration/dma-adventure-stow-run.test.js
 *   (a fake run reaches FINISH with loose troops: the raises go out before any general is sent home, then the run ends
 *   DONE; with the rule off or nothing loose no raise). The loot-spot runner uses the same stowLoose before Return.
 * 0.2.80 (2026-11-15, ADR 0069): camp by camp — before an attacker leaves, its path may cross no live camp other than its
 *   own target (else the run stops and names the camps); where a general stands matters only for that.
 * 0.2.79 (2026-11-15, ADR 0069): rule adv.campByCamp — any template, the player's own Mundane included, is played one camp
 *   at a time in its own order; a camp's next attacker leaves only when the one before is fighting there; the next camp only
 *   when this one fell; a view that lags the server (tasks past their end) is refreshed. G.tasks also gives remaining and lost.
 * 0.2.71 (2026-11-14, author: "Voor mundane wil ik voorlopig werken met hun eigen mundanes"): rule adv.asIs plays the
 *   player's own Mundane template as it is (its order and times; no layers, no re-timing), refuses a step in which a live
 *   camp that nobody attacks or blocks watches a general's way, and keeps the guards (retreat on interception without
 *   retries, camp read before later attackers). The plain send path now arms the guards too.
 *   Unit: dma-adventure-blocks.test.js (as-is: refused when an unattacked camp watches the way; sent otherwise).
 * 0.2.70 (2026-11-14): a layer whose chains are short only because blockers are still recovering is not stopped: the run
 *   goes back to LOADR and tries again (at most 3 h) with the whole step, the recovered blockers included.
 * 0.2.69 (2026-11-14, author: "Doe wat jij denkt dat het beste is om vanaf nu alle avonturen BB foutloos uit te voeren
 *   met blocks"; twice the main lost 128 MM at 1.3 after a wave the simulator overrated): (1) the next attacker on a camp
 *   arrives 10 s after the one ahead has fought (fightMs), so it is still walking when that fight ends; (2) then the camp
 *   is read and logged, and an attacker with "maxFoe"/"foeOnly" that would meet more is retreated with every later one
 *   on that camp before its fight; the run stops. Unit: dma-adventure-blocks.test.js (spacing by fightMs).
 * 0.2.68 (2026-11-14): a chain is made of 1-unit blocks when they cover the need; a long block (an army that is lost
 *   round by round) goes in, longest first, only when they fall short. Unit: dma-adventure-blocks.test.js.
 * 0.2.67 (2026-11-14, author: "maak een goede mundane ervan"): every layer sent is also written as a Mundane template
 *   (send order, "time" = delay before each general, via-blocks aimed at their via camp) under dma-mundane\<adventure>\.
 *   Unit: unchanged (file write is a no-op outside the client).
 * 0.2.66 (2026-11-14, BB test, 1R wave through two block chains under a Blackened Titanium horseshoe — passed): walking
 *   2.67 s a step (+25 %), but the 1R blocks fought as long as without a horseshoe (Generals 19-21 s, YGG/SYL/MG 9-17 s,
 *   Ghosts 7-8 s) and followed each other in the same second. 0.2.57's "the horseshoe shortens fight rounds" is reverted:
 *   blockMs is used as it is. Unit: dma-adventure-blocks.test.js (the horseshoe shortens the need, not the blocks).
 * 0.2.65 (2026-11-14, author: "Test verder"): the interception picture of a step is written to the log once (per general:
 *   target, steps, each watching camp with its first and last watched step), to set beside what the game does.
 * 0.2.64 (2026-11-14, author: "Dat kun je dus bepalen met de test aanval die de cliënt zelf biedt"): the interception
 *   picture is the game's own rule, read from client.swf: the attack path runs from the general's garrison street entry
 *   (not its spot grid — another path) to the target's street entry; a street counts when a ready, visible camp watches it
 *   and the target does not (cSpecialistTask_AttackBuilding.PerformTaskPhase: IsWatchedByTowers && !IsBuildingWatching).
 *   Reverts 0.2.60's "target's own streets count". Unit: unchanged (gateway); integration: the next block step.
 * 0.2.63 (2026-11-14, author: "Soms moet je een generaal naar een ander kamp sturen om onderschept te worden. Als je hem
 *   direct naar dat kamp stuurt verandert het pad"): a block entry may carry "via": the general is sent to that camp and
 *   blocks its own camp (target) by being caught on the way. The interception picture follows the path to the via camp;
 *   the plan starts its fight at its first watched dot plus 4 s to walk to the camp (APPROACH, measured once: MOUTH caught
 *   three steps from 1.2, fighting 3 s later); a via-block whose path the camp does not watch is refused. Still to measure
 *   live. Unit: dma-adventure-blocks.test.js (a via-block is timed by its dot, not by its path to the via camp).
 * 0.2.62 (2026-11-14, live: after the retreat LOADR took the walking-back generals for a resumed fight): the retry is no
 *   resume — LOADR waits for the generals to come back, then loads and attacks again.
 * 0.2.61 (2026-11-14, live BB step 04 again: the picture still named no camp, YGG2 was caught by 4.1 and all six were
 *   retreated without a loss): an interception the game shows is learned — that camp joins the general's picture, over
 *   its whole path — and the step is tried again once the generals are back (at most 3 times; rule adv.relearn.on). The
 *   layers then put the interceptor first. Unit: dma-adventure-blocks.test.js (a caught general's camp becomes an earlier
 *   layer on the next try).
 * 0.2.60 (2026-11-14, live BB step 04: the picture named no camp on the paths to 4.3, the game intercepted by 4.1 and
 *   4.2): the interception picture counts every street a ready camp watches, also the streets the target watches itself
 *   (the Combat Preview leaves those out; the game does not). Unit: unchanged (gateway); integration: the next BB step.
 * 0.2.59 (2026-11-14, author: "Als je ziet dat het fout gaat kunt je met 1 commando de generaals terug trekken voor die
 *   generals waarvoor de strijd nog niet begonnen is"): while a step is fought, an attacker whose task heads for another
 *   camp than its own has been intercepted; every general of the step not yet fighting (walking, at the camp, waiting) is
 *   retreated with the game's RETREAT (cSpecialistTask_AttackBuilding.Retreat, command 1033 — the general panel's button)
 *   and the run stops. Rule adv.retreat.on (default on). Unit: dma-adventure-blocks.test.js (an intercepted main makes
 *   the not-yet-fighting generals retreat; the one fighting is left).
 * 0.2.58 (2026-11-14, live BB: each step waited for 1-Recruit blockers still recovering from the step before): a blocker
 *   whose camp is gone or who is recovering is left out of the round; the send plan works with the others and refuses the
 *   layer if they are too few. Unit: dma-adventure-blocks.test.js via the run (play) — unchanged expectations.
 * 0.2.57 (2026-11-14, live BB step 02 failed: under a Blackened Titanium horseshoe the wave (GHOST5) and the main (STEAD1)
 *   were caught by the blocked camps 2.1/2.2 and beat them; the leader 2.3 stood. Step 01 had worked with the plan made
 *   at normal speed under the same horseshoe. Reading: the horseshoe speeds up the generals' fight rounds as much as
 *   their walking (forum: "it does speed up the attack speed"; "it does not affect blocks"), so a 1R block of a General
 *   lasts 20 s / 1.25 — step 02's plan scaled the walking but not the blocks, and its chains were 20 % short): blockMs is
 *   divided by the same factor. Unit: dma-adventure-blocks.test.js (the horseshoe no longer shortens the need relative to
 *   the blocks: chains as at normal speed).
 * 0.2.56 (2026-11-14, live BB step 01: the horseshoe was applied three times, 2 s apart, before the zone showed it — the
 *   server takes a few seconds): one apply, then up to 20 s waiting for the zone to show it. Unit: as 0.2.55.
 * 0.2.55 (2026-11-14, Adelgerta's Bonaberti guide, supplied by the author: "all blocks work with minimum bronze horseshoe
 *   on"): a step with blocks is played under a horseshoe (zone buff, all generals walk faster): the one on the zone, else
 *   rule adv.blocks.speedBuff from the star (default Blackened Titanium, +25 %, 6 h; "none" = no horseshoe). The send plan
 *   uses the faster step (+p: a step takes 1/(1+p)), the way out taken 3 % slower still until measured. Unit:
 *   dma-adventure-blocks.test.js (a horseshoe shortens the stretch: fewer blocks).
 * 0.2.54 (2026-11-14, 1R rehearsal of BB blocks step 01; author: "je ziet precies wanneer een generaal onderschept wordt",
 *   "daar waar je de marge te gevaarlijk vindt kun je kijken naar de maximale lengte van een block aanval"): the rehearsal
 *   showed the 1R chain on 1.2 running without gaps (05:20-06:13) and MOUTH caught by 1.2 at 06:13, three steps before
 *   1.3 — on streets 1.3 watches too, which the interception picture left out (as the Combat Preview does), so the plan
 *   ended the chain too early. (1) The watch stretch of a camp now runs to the last step it watches, those streets
 *   included. (2) Stretches are taken wide (3.30 s per step in, 3.40 s out; measured 3.31-3.40) and, when the camp
 *   watches up to the target, last until the passer has won there. (3) Chains put the longest blocks first and must
 *   cover every stretch with a margin on both sides (rule adv.blocks.marginSec, default 5 s); short of it the layer is not
 *   sent and the log names the seconds missing and the longer block that closes it. (4) The log gives each chain's
 *   slack. Unit: dma-adventure-blocks.test.js (tail streets count; longest block first; margin).
 * 0.2.53 (2026-11-13, live BB blocks step 01: a restart at 20:40 fell inside the attack queue — the estimate "sum of the
 *   send gaps + 15 s" had passed while Mundane was still sending; the main left without its wave and was intercepted): the
 *   run is not restart-safe while Mundane's own battleTimedQueue still holds unsent items (index < length), whatever the
 *   estimate says. Unit: dma-adventure-blocks.test.js (restartSafe false while the queue runs).
 * 0.2.52 (2026-11-13, live BB blocks step 01: "15 generals on 3824" was logged but nobody left — Mundane's battleAttack
 *   silently skips every general its battleLoadDataCheck marks canAttack false): the attack reports what Mundane queued —
 *   per general canAttack, onSameGrid, units, task — the log says "queued n of m" and names the ones left out; when none is
 *   queued the run stops with those reasons instead of waiting 40 minutes. Unit: dma-adventure-blocks.test.js.
 * 0.2.51 (2026-11-13, ADR 0066; author: "doe alles wat nodig is om te komen tot een tweede oplossing met toestemming van de
 *   speler voor blocks om BB te doen met blocks en het minimale verlies van MS"): (1) PERMISSION — a template with block
 *   entries is only played when the player allows blocks (policy adv.blocks.on, default off); otherwise the run stops
 *   before anything is sent. (2) BLOCK CHAINS — several block entries on the same camp queue there one after the other, so
 *   the camp keeps fighting and its watch area stays off for the sum of their blockMs (a 1R block of a General lasts one
 *   round, 20 s; three of them 60 s, each costing at most 1 Recruit). Only as many as the passage needs are sent; the rest
 *   stay home. (3) BLOCKS ARE TIMED TO THE PASSERS — the attackers are timed first (wave before main, 10 s apart at the
 *   camp), then each chain is sent so its first block arrives 1 s before the first passer enters the watch area (the next
 *   blocks 1 s apart behind it), and every passer must leave the area 2 s before the chain ends (and, with fightMs, have
 *   won its camp by then). A blocker whose own path crosses another blocked area is a passer of that area too. If a window
 *   cannot be met the layer is not sent and the run stops, naming the general and the seconds missing.
 *   Unit: tests/unit/dma-adventure-blocks.test.js. Integration: Bonaberti "blocks" version — each leader falls while its
 *   watching camps are blocked; no attacker is intercepted.
 * 0.2.50 (2026-11-13, ADR 0063 addendum; author: "legers die je gebruikt bij een succesvolle block verlies je niet, doordat
 *   het hoofdkamp eerder verslagen wordt"): a general passing a blocked camp's area that carries "fightMs" (its own fight,
 *   from the planner) must also have won its camp before the block ends (arrival + fightMs <= block end - 2 s) — then
 *   the leader falls first, the blocked camp goes with it and the block army comes home whole.
 * 0.2.49 (2026-11-13, ADR 0063; author: "maak de mogelijkheid voor de speler om blocks te gebruiken"): blocks. A
 *   template entry with "block": true sends its general to keep a camp busy (TSO "block": a fighting camp's watch area is
 *   off) instead of beating it; "blockMs" is how long it keeps the camp busy (from the planner: rounds x round time),
 *   default 3 s (a 1R block). A blocked camp does not hold back a layer; the generals whose paths it watches are timed to
 *   enter its watch area at least 1 s after the block arrives and to leave it at least 2 s before the block ends
 *   (3 000 path units/s, one path step = 10 000 units). If no send time fits, the layer is not sent and the run stops.
 *   Camps only blocked are not waited for (they fall with their leader). Unit: tests/unit/dma-adventure-blocks.test.js.
 *   Integration: a block attack where the main reaches its camp while the block fights, no main intercepted.
 * 0.2.48 (2026-11-13, ADR 0062; author: "Zodra alle generaals verstuurd zijn kun je de tijd uitrekenen"): within a
 *   layer the send times come from the path lengths — each general reaches its camp at least 10 s after the general
 *   before it there (waves in template order, the main last) — instead of the template's fixed delays.
 *   Unit: tests/unit/dma-adventure-layers.test.js (main sent after its far wave). Integration: every wave fights before
 *   its main in a Bonaberti round.
 * 0.2.47 (2026-11-13, ADR 0062; author: "Doe de aanval eerst handmatig en time de aanvallen", "Is er een manier om te
 *   zien of een eiland stil staat?"): a round is played in interception layers. At ATTACK the run asks the path finder,
 *   from every general's spot to its camp, which living camps watch the path (as the Combat Preview's interception) and
 *   orders the camps into layers: a camp only after every camp that intercepts it. Layer 0 is sent; FIGHT waits until
 *   the island stands still (no general of ours has an AttackBuilding task — walking, fighting, waiting or walking
 *   back), refreshes the zone, and sends the next layer only when every camp of the layer is gone; a camp that survived
 *   stops the run. The expected still time (last send + way there + way back at 3 000 path units/s) is logged.
 *   Unit: tests/unit/dma-adventure-layers.test.js (layer order from intercepts, still check). Integration: a Bonaberti
 *   round 2 shows no general changing target while walking.
 * 0.2.46 (2026-11-11, ADR 0060 finding 3): a general still travelling to the island (task TravelToZone) has not
 *   arrived, also on a resume — live, the adventure window resumed "the fight (15 generals busy)" while the generals
 *   were on their way. Unit: tests/unit/dma-adventure-move-rules.test.js (travelling). Integration: a run resumed in the
 *   adventure window right after the send waits in TRAVEL until all generals stand on the island.
 * 0.2.45 (2026-11-11, ADR 0060 evaluation; author: "evalueer zodat het niet meer voorkomt" after Bonaberti run 4 lost
 *   STEAD1 and STEAD2): (1) before a round moves, every idle general on the island that has no spot in that round
 *   (quartermasters, generals of other rounds) goes to the star first — live, BIG and QM-Q had landed on template spots
 *   and seven generals blocked each other; (2) a general that shares its camp with another general (lure order) never
 *   takes a substitute spot — it waits for its own spot, and the round stops at the move time-out instead (live, STEAD1
 *   took 4771 for 5109, arrived before the lure YGG1 and lost); (3) a fight whose picture does not change for 10 minutes
 *   gets one zone refresh (message 1037) — live, the adventure window showed two attacks for 36 minutes that the server
 *   had not carried out. createRun(opts.start) lets a unit test enter a state.
 *   Unit: tests/unit/dma-adventure-move-rules.test.js. Integration: Bonaberti run 5 loses only template lures.
 * 0.2.8 (2026-10-31): after a restart with every attack already sent the run goes straight back to FIGHT (it waited in
 *   LOADR, where the RT does not run). Unit: fake world unchanged; integration: live YWC.
 * 0.2.7 (2026-10-31, live: "je was te vroeg de laatste generaals waren nog niet weggestuurd"): restartSafe() is false
 *   while generals are loaded/sent/moved or the spread attack queue runs; after a restart fighting generals count as
 *   arrived and idle generals whose camp stands attack at once. Unit: fake world resumes a cut attack; integration: live.
 * 0.2.6 (2026-10-31, author: "het enige dat vergeten was, is de laatste return knop te drukken"): FINISH presses
 *   Return the client's way (drop the finished adventure from the list, load home) once the game marks it finished;
 *   still listed at home -> the log says restart, else log out 20 min. Unit: fake world closes the adventure; integration: next FT.
 * 0.2.5 (2026-10-31): status() names the version that runs (for the green "Running" button).
 * Unit expectation:        with a fake gateway the state machine walks PRECHECK → … → DONE for a load template and two
 *                          rounds, resends a general that stayed home, and stops with a reason when a camp never falls.
 * Integration expectation: "Run once" on the ADVS page plays one Ali Baba and the First Thief from the star to home.
 */
(function (root) {
    "use strict";
    var VERSION = "0.2.183";
    var RES = { ft: "1001NightsFirstThief", ywc: "1001NightsWoodcutter", gp: "Gunpowder", ae: "MiadArcticExplosion", vlt: "TheValiantLittleTailor" };   // 0.2.16: the console's short keys (live: Run once on Gunpowder found "no star item name known for gp")   // star item names (checked online / in the client)
    /* 0.2.163 (live GP 2026-11-24, author: "het is 2x ls GP, je schrijft G"): the adventure tag in the loot-spot texts is the
       console's short key when the adventure has one (Gunpowder -> GP); only then the catalogue's initials (which give "G") */
    function lsTag(id, res, cat, Cc) {
        if (id && String(id).length <= 4) return String(id).toUpperCase();
        var k; for (k in RES) if (RES.hasOwnProperty(k) && (RES[k] === res || RES[k] === id)) return k.toUpperCase();
        return (cat && Cc && Cc.abbr) ? Cc.abbr(cat.name) : id;
    }
    var ARROW_FLIGHT_MS = 30000, ARROW_SENDS = 2;   // 0.2.172: an arrow is in flight for 30 s after it is put on a camp (the arrows run sees its result within 25 s); at most 2 sends per camp
    var T = { start: 8 * 60000, load: 60000, send: 60000, arrive: 30 * 60000, move: 5 * 60000, walk: 30 * 60000, recover: 4.5 * 3600000, round: 40 * 60000, finish: 5 * 60000 };

    /* ---------------- gateway: the only place that touches the game ---------------- */
    /* 0.2.99: the exclusivity family of a speed-up: the game's group when it has one, else the player's rule adv.travel.exclusive */
    function arr(v) { var o = []; if (!v) return o; for (var i = 0; i < v.length; i++) o.push(v[i] !== undefined ? v[i] : (v.getItemAt ? v.getItemAt(i) : null)); return o; }   // 0.2.99
    function exclusiveGroup(name, gameGroup) {
        if (gameGroup != null && String(gameGroup) !== "") return "game:" + gameGroup;
        var P = root.GCAF_PlayerPolicyInstance, rule = "GeneralSpeedBuff_;Observatory:"; try { var v = P && P.get ? P.get("adv.travel.exclusive") : null; if (v != null) rule = String(v); } catch (_) {}
        /* 0.2.112 (live 2026-11-21 02:53Z: the Observatory's star chart was ordered, then the Black Vortex did not run — both are
           adventure-zone travel boosts and the game keeps one at a time): observed families are always kept, whatever the rule; within
           a family, alternatives are separated by "|" (the rule may use that too) */
        var fams = rule.split(";"), fam = null;   // 0.2.113: the observed Vortex/Observatory family of 0.2.112 is withdrawn — at 03:04Z both ran together
        fams.map(function (x) { return x.trim(); }).filter(Boolean).forEach(function (f) { if (fam) return; f.split("|").map(function (a) { return a.trim(); }).filter(Boolean).forEach(function (a) { if (!fam && String(name).indexOf(a) === 0) fam = f.split("|")[0].trim(); }); });
        return fam;
    }
    function gameGateway() {
        var R = root;
        function g() { return R.game; }
        function me() { return g().player.GetPlayerId(); }
        function spec(id) { try { return R.armyGetSpecialistFromID(String(id)); } catch (_) { return null; } }
        function advMgr() { return R.swmmo.getDefinitionByName("com.bluebyte.tso.adventure.logic::AdventureManager").getInstance(); }
        function copy(p) { return JSON.parse(JSON.stringify(p)); }
        var refusal = null;   // 0.2.83 (ADR 0073): the adapter's answer to the last send that was refused
        function via(fn) {
            var A = R.GCAF_GameInterface, h = true, r;
            try { h = !!g().gi.isOnHomzone(); } catch (_) {}
            refusal = null;
            if (!A) r = { ok: false, reason: "game interface adapter not loaded" };
            else { try { r = fn(A, { away: !h }) || { ok: false, reason: "no answer from the adapter" }; } catch (e) { r = { ok: false, reason: "send failed: " + e }; } }
            if (!r.ok) refusal = { reason: r.reason, retry: !!r.retry };
            return r;
        }
        return {
            refusal: function () { return refusal; },
            now: function () { return Date.now(); },
            atHome: function () { return !!g().gi.isOnHomzone(); },
            /* 0.2.81: stow before closing — the loose troops on the viewed zone, our generals on its map, a raise */
            looseTroops: function () { var out = {}, k; try { if (typeof R.updateFreeArmyInfo === "function") R.updateFreeArmyInfo(true); var fi = R.armyFreeInfo || {}; for (k in fi) if (fi.hasOwnProperty(k) && Number(fi[k]) > 0) out[k] = Number(fi[k]); } catch (_) {} return out; },
            /* 0.2.118 (live 2026-11-21 07:31-07:35Z, probe task/dump; author: "Je kunt zelf ook zien dat generaals onderweg zijn, zelfs
               welke en wat voor troepen erin zitten"): a general on its way home stands in the home zone's list with a TravelToZone task
               (grid -1, GetDestinationZoneID, GetRemainingTime) and its army. The generals of the given keys on their way to the viewed
               zone: { key: { ms, army } } */
            travellers: function (keys) {
                var out = {}, here = g().gi.mCurrentViewedZoneID;
                (keys || []).forEach(function (k) { try { var s = spec(k), t = s ? s.GetTask() : null; if (!t || !/TravelToZone/.test(String(t))) return;
                    var dest = typeof t.GetDestinationZoneID === "function" ? Number(t.GetDestinationZoneID()) : null; if (dest != null && dest !== Number(here)) return;
                    var army = {}; try { var a = s.GetArmy(); if (a && a.GetSquadsCollection_vector) a.GetSquadsCollection_vector().forEach(function (q) { var n = Number(q.GetAmount()); if (n > 0) army[String(q.GetType())] = (army[String(q.GetType())] || 0) + n; }); } catch (_) {}
                    out[k] = { ms: Number(t.GetRemainingTime()) || 0, army: army }; } catch (_) {} });
                return out;
            },
            capacities: function (keys) {   // 0.2.169 (B13, R-PLAN-CAPACITY): the game's capacity of each general, skills included
                var out = {}; (keys || []).forEach(function (k) { try { var sp = spec(k); if (sp) out[k] = Number(sp.GetMaxMilitaryUnits()) || null; } catch (_) {} }); return out;
            },
            mapGenerals: function () {
                var out = [];
                try { g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) {
                    try { if (!s || s.getPlayerID() !== me() || !R.armySPECIALIST_TYPE.IsGeneral(s.GetType())) return;
                          var army = {}, a = s.GetArmy(); if (a && a.GetSquadsCollection_vector) a.GetSquadsCollection_vector().forEach(function (q) { try { var n = Number(q.GetAmount()); if (n > 0) army[String(q.GetType())] = (army[String(q.GetType())] || 0) + n; } catch (_) {} });
                          out.push({ key: String(s.GetUniqueID().toKeyString()), cap: Number(s.GetMaxMilitaryUnits()) || 0, army: army,
                                     onMap: s.GetGarrisonGridIdx() > 0, grid: Number(s.GetGarrisonGridIdx()), idle: s.GetTask() == null && !(s.IsInUse && s.IsInUse()) }); } catch (_) {} }); } catch (_) {}
                return out;
            },
            raise: function (key, army, n) {
                var s = spec(key); if (!s) return false;
                var VO = R.dRaiseArmyVODef || R.swmmo.getDefinitionByName("Communication.VO::dRaiseArmyVO"), RVO = R.dResourceVODef || R.swmmo.getDefinitionByName("Communication.VO::dResourceVO"), vo = new VO();
                vo.armyHolderSpecialistVO = s.CreateSpecialistVOFromSpecialist();
                Object.keys(army || {}).forEach(function (u) { if (Number(army[u]) > 0) { var r = new RVO(); r.name_string = u; r.amount = Number(army[u]); vo.unitSquads.addItem(r); } });
                setTimeout(function () { try { via(function (A, cx) { return A.sendMessage("RAISE_ARMY", vo, null, cx); }); } catch (_) {} }, 1000 * (n || 0));
                return true;
            },
            homeZone: function () { return g().player.GetHomeZoneId(); },
            viewedZone: function () { return g().gi.mCurrentViewedZoneID; },
            starItem: function (res) {
                var found = null, n = 0;
                g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) {
                    try { if (b.GetResourceName_string() === res && b.GetBuffDefinition().GetName_string() === "Adventure") { n += Number(b.amount) || 1; if (!found) found = b.GetUniqueId(); } } catch (_) {}
                });
                return found ? { id: found, count: n } : null;
            },
            ownAdventure: function (res) {
                var z = null;
                advMgr().getAdventures().forEach(function (a) { if (a && a.ownerPlayerID === me() && (!res || a.adventureName === res)) z = a.zoneID; });
                return z;
            },
            starCounts: function () {   // 0.2.0: res -> how many in the star
                var out = {};
                g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) {
                    try { if (b.GetBuffDefinition().GetName_string() === "Adventure") { var r = b.GetResourceName_string(); out[r] = (out[r] || 0) + (Number(b.amount) || Number(b.GetAmount && b.GetAmount()) || 1); } } catch (_) {}
                });
                return out;
            },
            useStarItem: function (id) { return via(function (A, cx) { return A.sendAction("STAR_ITEM", 0, 0, 0, id, cx); }); },
            /* 0.2.11: arrows (battle buffs) in the star, by game name or shown name; applied on a camp grid like
               Mundane's sendBuffPacket: SendServerAction(61 APPLY_BUFF, 0, grid, 0, uniqueId) */
            arrows: function () {
                var out = {};
                g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) {
                    try { var d = b.GetBuffDefinition().GetName_string(); if (d.indexOf("BattleBuff") !== 0) return;
                          if (!out[d]) out[d] = { def: d, name: String(b.getName ? b.getName() : d), count: 0, id: b.GetUniqueId() };
                          out[d].count += Number(b.GetAmount()) || 0; } catch (_) {}
                });
                return out;
            },
            /* 0.2.59: phase and target of each general's attack task (phase 0 walking, 1 at the camp, 2 fighting, 3 back,
               4 waiting for orders — cSpecialistTask_AttackBuilding), and the general panel's own retreat (task.Retreat()) */
            tasks: function (keys) {
                var out = {}; (keys || []).forEach(function (k) { try { var sp = R.armyGetSpecialistFromID(String(k)), t = sp ? sp.GetTask() : null;
                    if (t && t.GetTargetBuildingGridIdx) { out[k] = { phase: t.GetTaskPhase ? Number(t.GetTaskPhase()) : null, target: Number(t.GetTargetBuildingGridIdx()) };   // 0.2.79: remaining, lost
                        try { out[k].remaining = t.GetRemainingTime ? Number(t.GetRemainingTime()) : null; } catch (_) {} try { out[k].lost = t.hasLostBattle ? !!t.hasLostBattle() : false; } catch (_) {} } } catch (_) {} });
                return out;
            },
            dist: function (a, b) {   // 0.2.165 (ADR 0101 rule 3): Chebyshev distance of two grids on the viewed zone
                try { var W = Number(g().gi.mCurrentPlayerZone.mMapWidth) || 0; if (!W || !(a > 0) || !(b > 0)) return null;
                      return Math.max(Math.abs(a % W - b % W), Math.abs(Math.floor(a / W) - Math.floor(b / W))); } catch (_) { return null; }
            },
            units: function (keys) {   // 0.2.164 (ADR 0101, tester): the general's unit count — a fight that ended between two ticks shows as fewer units
                var out = {}; (keys || []).forEach(function (k) { try { var sp = R.armyGetSpecialistFromID(String(k)), a = sp && sp.GetArmy ? sp.GetArmy() : null; if (a && a.GetUnitsCount) out[k] = Number(a.GetUnitsCount()); } catch (_) {} });
                return out;
            },
            anyTask: function (keys) {   // 0.2.164 (ADR 0101, tester): any task of a general — an attack, or the Recover a beaten one gets
                var out = {}; (keys || []).forEach(function (k) { try { var sp = R.armyGetSpecialistFromID(String(k)), t = sp ? sp.GetTask() : null; if (t) { var cn = ""; try { cn = R.runtime ? String(R.runtime.flash.utils.getQualifiedClassName(t)) : ""; } catch (_) {} out[k] = (cn || String(t)).slice(0, 60); } } catch (_) {} });   // the class name (cSpecialistTask_Move, _Recover, _AttackBuilding), as attacking() reads it
                return out;
            },
            retreat: function (k) {
                try { var sp = R.armyGetSpecialistFromID(String(k)), t = sp ? sp.GetTask() : null; if (!t || typeof t.Retreat !== "function") return { ok: false, reason: "no attack task" };
                      t.Retreat(); return { ok: true }; } catch (e) { return { ok: false, reason: String(e) }; }
            },
            /* 0.2.55: the horseshoe on the viewed zone (ZoneBuffManager, as probe zonebuffs) — its definition name, or null */
            speedBuff: function () {
                try { var zbm = g().gi.mZoneBuffManager, pers = zbm.getZoneBuffsForPersistence(), n = pers ? (pers.length || 0) : 0;
                      for (var i = 0; i < n; i++) { var b = pers.getItemAt ? pers.getItemAt(i) : pers[i], d = null;
                          try { d = String(R.swmmo.getDefinitionByName("BuffSystem::cBuffDefinition").GetById(b.buffID).GetName_string()); } catch (_) {}
                          if (d && d.indexOf("GeneralSpeedBuff") === 0) return d; } } catch (_) {}
                return null;
            },
            applyZoneBuff: function (def) {   // 0.2.55: a zone buff from the star on the viewed zone, as Mundane's battleMove (grid 0)
                var hit = null, cnt = 0; try { g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) { try { if (b.GetBuffDefinition().GetName_string() === def) { cnt += Number(b.GetAmount()) || 0; if (!hit) hit = b; } } catch (_) {} }); } catch (_) {}
                if (!hit || cnt <= 0) return { ok: false, reason: "no " + def + " in the star" };
                var rz = via(function (A, cx) { return A.sendAction("STAR_ITEM", 0, 0, 0, hit.GetUniqueId(), cx); });
                return rz.ok ? { ok: true, left: cnt - 1 } : { ok: false, reason: rz.reason, retry: rz.retry };
            },
            /* 0.2.97: the game's exclusivity group of a buff, and whether it (or one of its group) runs on the viewed zone */
            buffZones: function (name) { try { var bd = R.swmmo.getDefinitionByName("BuffSystem::cBuffDefinition").GetByName(String(name)); return bd ? Number(bd.getTargetZoneTypes()) || 0 : 0; } catch (_) { return 0; } },   // 0.2.105: 1 home island, 4 adventure (game definition)
            buffGroup: function (name) { return exclusiveGroup(name, (function () { try { var bd = R.swmmo.getDefinitionByName("BuffSystem::cBuffDefinition").GetByName(String(name).replace(/^Observatory:/, "")); return bd ? bd.GetExclusivityGroup() : null; } catch (_) { return null; } })()); },   // 0.2.99
            observatories: function () {   // 0.2.99: [{ grid, cooldownMs, recipes: [{ name, effect, costs }] }]
                var out = []; try { var tp = R.swmmo.getDefinitionByName("global").timedProductions_vector;
                    arr(g().gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector()).forEach(function (b) { try { if (!b || String(b.GetBuildingName_string()) !== "Observatory") return;
                        var q = b.productionQueue, type = q ? q.mProductionType : null, cd = 0; try { cd = Number(b.getRemainingCooldown()) || 0; } catch (_) {}
                        var rs = []; arr(type != null && tp ? tp[type] : null).forEach(function (r) { try { var ef = ""; try { ef = String(r.effects_vector[0].name_string); } catch (_) {} rs.push({ name: String(r.GetType()), effect: ef || String(r.GetType()), type: type, costs: arr(r.GetCosts_vector()).map(function (c) { return [String(c.name_string), Number(c.amount)]; }) }); } catch (_) {} });
                        out.push({ grid: b.GetGrid(), cooldownMs: cd, busy: !!(q && q.mTimedProductions_vector && q.mTimedProductions_vector.length), recipes: rs }); } catch (_) {} }); } catch (_) {}
                return out;
            },
            startObservatory: function (recipe) {   // 0.2.99: one ready Observatory starts the chart
                var obs = this.observatories().filter(function (o) { return o.cooldownMs <= 0 && !o.busy; }), hit = null, rec = null;
                obs.forEach(function (o) { if (hit) return; o.recipes.forEach(function (r) { if (r.name === recipe) { hit = o; rec = r; } }); });
                if (!hit) return { ok: false, reason: "no Observatory ready (cooldown) for " + recipe };
                try { var res = g().gi.mCurrentPlayerZone.GetResources(g().gi.mCurrentPlayer), short = rec.costs.filter(function (c) { return !res.HasPlayerResource(c[0], c[1]); });
                      if (short.length) return { ok: false, reason: "not in stock: " + short.map(function (c) { return c[1] + " " + c[0]; }).join(", ") }; } catch (_) {}
                var vo = new (R.swmmo.getDefinitionByName("Communication.VO::dTimedProductionVO"))(); vo.productionType = rec.type; vo.type_string = rec.name; vo.amount = 1; vo.stacks = 1; vo.buildingGrid = hit.grid;
                var rz = via(function (A) { return A.sendMessage("START_TIMED_PRODUCTION", vo); });
                return rz.ok ? { ok: true, grid: hit.grid, left: obs.length - 1 } : { ok: false, reason: rz.reason, retry: rz.retry };
            },
            zoneBuffActive: function (name) {
                try { var zb = g().gi.mZoneBuffManager; if (zb.isBuffRunning && zb.isBuffRunning(String(name))) return true;
                      var bd = R.swmmo.getDefinitionByName("BuffSystem::cBuffDefinition").GetByName(String(name)), o = bd ? zb.getBuffInExclusivityGroup_vector(bd.GetExclusivityGroup()) : null;
                      return !!(o && o.length); } catch (_) { return false; }
            },
            starRead: function () {   // 0.2.170 (architect F4): the star, or null when it could not be read (never {} for a failed read)
                var out = {}; try { var v = g().gi.mCurrentPlayer.getAvailableBuffs_vector(); if (!v) return null;
                    v.forEach(function (b) { try { var n = String(b.GetBuffDefinition().GetName_string()); out[n] = (out[n] || 0) + (Number(b.GetAmount()) || 0); } catch (_) {} }); } catch (_) { return null; }
                return out;
            },
            starBuffs: function (rx) {
                var out = {}; try { g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) { try { var n = String(b.GetBuffDefinition().GetName_string()); if (rx && !rx.test(n)) return; out[n] = (out[n] || 0) + (Number(b.GetAmount()) || 0); } catch (_) {} }); } catch (_) {}
                return out;
            },
            applyArrow: function (defOrName, grid) {
                var a = this.arrows(), k, hit = null;
                for (k in a) if (a.hasOwnProperty(k) && (k === defOrName || a[k].name === defOrName)) hit = a[k];
                if (!hit || hit.count <= 0) return { ok: false, reason: "no " + defOrName + " in the star" };
                var ra = via(function (A, cx) { return A.sendAction("STAR_ITEM", 0, grid, 0, hit.id, cx); });
                if (!ra.ok) return { ok: false, reason: ra.reason, retry: ra.retry };
                return { ok: true, def: hit.def, name: hit.name, left: hit.count - 1 };
            },
            invite: function (name, zone) {   // 0.2.17: as the adventure panel's own invitation (AddInvitedPlayer -> INVITE_TO_ADVENTURE 92)
                try { var gui = R.globalFlash.gui, fl = gui.mFriendsList, nm = String(name).toLowerCase();
                      var m = (fl.GetGuildMemberByName_string && fl.GetGuildMemberByName_string(nm)) || (fl.GetFriendByName_string && fl.GetFriendByName_string(nm));
                      if (!m) return { ok: false, reason: name + " is not a guild member or friend" };
                      var a = advMgr().getAdventure(zone); if (!a) return { ok: false, reason: "adventure not found" };
                      gui.mAdventurePanel.AddInvitedPlayer(m, a); return { ok: true, id: m.id }; } catch (e) { return { ok: false, reason: String(e) }; }
            },
            cancelInvite: function (name, zone) {   // 0.2.18: CANCEL_ADVENTURE_INVITATION (168) for a pending invitation, as the adventure panel does
                try { var a = advMgr().getAdventure(zone), pl = a && a.players, n = pl ? (pl.length || 0) : 0, id = null;
                      for (var i = 0; i < n; i++) { var p = pl.getItemAt ? pl.getItemAt(i) : pl[i]; if (p && String(p.username).toLowerCase() === String(name).toLowerCase()) { if (Number(p.status) !== 0) return { ok: false, reason: "not pending" }; id = p.id; } }
                      if (id == null) return { ok: false, reason: "not invited" };
                      var gui = R.globalFlash.gui; gui.mAdventurePanel.SetData(a); gui.mAdventurePanel.CancelAdventureInvitation(id); return { ok: true }; } catch (e) { return { ok: false, reason: String(e) }; }
            },
            say: function (text) { try { return root.DMA_Chat.sayLs(text); } catch (e) { return { ok: false, reason: String(e) }; } },
            chatSince: function (at) { try { return root.DMA_Chat.recent(at); } catch (_) { return []; } },
            ownName: function () { try { return String(root.DMA_Chat.ownName() || ""); } catch (_) { return ""; } },
            rule: function (k, d) { try { var P = root.GCAF_PlayerPolicyInstance, v = P && P.get ? P.get(k) : undefined; return v == null ? d : v; } catch (_) { return d; } },
            advPlayers: function (zone) {   // 0.2.14: invited players of our adventure: name -> status (0 pending, 1 accepted, 2 declined, 3 left, 4 cancelled)
                var out = {};
                try { var a = advMgr().getAdventure(zone), pl = a && a.players, n = pl ? (pl.length || 0) : 0;
                      for (var i = 0; i < n; i++) { var p = pl.getItemAt ? pl.getItemAt(i) : pl[i]; if (p && p.id !== me()) out[String(p.username)] = Number(p.status); } } catch (_) {}
                return out;
            },
            guestGenerals: function (zone) {   // 0.2.31: invited players' generals on our adventure: name -> busy count
                var out = {};
                try { if (g().gi.mCurrentViewedZoneID !== zone) return out;
                      var a = advMgr().getAdventure(zone), pl = a && a.players, n = pl ? (pl.length || 0) : 0, byId = {};
                      for (var i = 0; i < n; i++) { var p = pl.getItemAt ? pl.getItemAt(i) : pl[i]; if (p && p.id !== me()) { byId[p.id] = String(p.username); out[String(p.username)] = 0; } }
                      g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (sp) {
                          try { var pid = sp.getPlayerID(); if (pid !== me() && byId[pid] && R.armySPECIALIST_TYPE.IsGeneral(sp.GetType()) && sp.GetTask() != null) out[byId[pid]] += 1; } catch (_) {}
                      }); } catch (_) {}
                return out;
            },
            generalsHere: function () {   // 0.2.13: our generals on the viewed zone: grid, busy, name
                var out = {};
                try { g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) {
                    try { if (s && s.getPlayerID() === me() && R.armySPECIALIST_TYPE.IsGeneral(s.GetType())) { var nm = ""; try { nm = String(s.getName ? s.getName(false) : ""); } catch (_) {}
                          out[s.GetUniqueID().toKeyString()] = { grid: s.GetGarrisonGridIdx(), busy: s.GetTask() != null, name: nm.replace(/<[^>]*>/g, "") }; } } catch (_) {}
                }); } catch (_) {}
                return out;
            },
            campUnits: function (grid) { try { var b = g().zone.mStreetDataMap.GetBuildingByGridPos(grid); if (!b) return 0; var a = b.GetArmy(); return a && a.HasUnits() ? a.GetUnitsCount() : 0; } catch (_) { return 0; } },
            /* 0.1.7: a finished adventure can stay in the client's list (seen live after the first automatic FT); the
               community script removes it the same way once home */
            forget: function (zone) { try { advMgr().removeAdventure(zone); return true; } catch (_) { return false; } },
            visit: function (zone) { g().gi.visitZone(zone); },
            /* 0.2.6 (author: "het enige dat vergeten was, is de laatste return knop te drukken"): the client's own Return
               button (cAdventurePanel.doReturnHome) drops a FINISHED adventure (status 2 won / 3 lost) from the list and
               loads the home zone. Only a finished adventure is dropped — an open one is never touched (0.2.2). */
            advStatus: function (zone) { try { var a = advMgr().getAdventure(zone); return a ? a.status : null; } catch (_) { return null; } },
            returnHome: function (zone) {
                var st = null, dropped = false;
                /* 0.2.29 (live YWC: last quest rewarded, status read "null", the adventure stayed listed): the client's own
                   Return (cAdventurePanel.doReturnHome) looks the finished adventure up by the home player's id; do both,
                   and also scan the list for our finished one */
                try { var am = advMgr(), ids = [zone]; try { ids.push(R.game.gi.mHomePlayer.GetPlayerId()); } catch (_) {}
                      ids.forEach(function (id) { var a = am.getAdventure(id); if (a && st == null) st = a.status; if (a && (a.status === 2 || a.status === 3)) { am.removeAdventure(id); dropped = true; } });
                      if (!dropped) am.getAdventures().forEach(function (a) { try { if (a && a.ownerPlayerID === me() && (a.status === 2 || a.status === 3)) { am.removeAdventure(a.zoneID); dropped = true; } } catch (_) {} });
                } catch (_) {}
                try { var P = R.globalFlash && R.globalFlash.gui && R.globalFlash.gui.mAdventurePanel; if (P && P.IsVisible && P.IsVisible()) P.Hide(); } catch (_) {}
                g().gi.visitZone(g().player.GetHomeZoneId());
                return { status: st, dropped: dropped };
            },
            /* per template general: exists here, idle, army matches, on its grid, can move, can attack */
            inspect: function (packet) {
                var p = copy(packet), out = { generals: {}, needs: {}, canLoad: false };
                R.battlePacket = p;
                try { R.updateFreeArmyInfo(true); } catch (_) {}
                var c = R.armyLoadDataCheck(p);
                var d = R.battleLoadDataCheck(p);
                Object.keys(p).forEach(function (k) {
                    if (p[k].type === "buff" || p[k].type === "speedbuff") return;
                    var s = d[k] && d[k].spec;
                    if (s && typeof s.GetTask !== "function") s = null;   // 0.1.3: an arriving general can be a bare object without methods
                    var task = null; try { task = s ? s.GetTask() : null; } catch (_) { s = null; }
                    var recov = false; try { recov = !!(task && ((typeof task.GetType === "function" && task.GetType() === 6) || /Recover/.test(String(task)))); } catch (_) {}   // 0.2.38
                    var walkTo = -1; try { if (task && typeof task.GetNewGarrisonGridIdx === "function") walkTo = Number(task.GetNewGarrisonGridIdx()); } catch (_) {}   // 0.2.36
                    var trav = false; try { trav = !!(task && /TravelToZone/.test(String(task))); } catch (_) {}   // 0.2.46
                    out.generals[k] = { here: !!s, idle: !!(s && task == null), recovering: recov, travelling: trav, walking: walkTo >= 0 && walkTo === Number(p[k].grid), match: !!(R.armyPacketMatches && R.armyPacketMatches[k]),
                                        onGrid: !!(d[k] && d[k].onSameGrid), canMove: !!(d[k] && d[k].canSubmitMove), canAttack: !!(d[k] && d[k].canSubmitAttack),
                                        target: p[k].target || 0, grid: p[k].grid, star: (function () { try { return !!(s && s.GetGarrisonGridIdx() === -1); } catch (_) { return false; } })() };
                });
                out.needs = c.army || {};
                out.canLoad = !!c.canSubmit;
                /* 0.2.103: the loose troops, and what the template's own idle generals carry beyond their part (they give it back in
                   the load's first pass) — Mundane's check counts only the loose troops */
                out.free = {}; out.surplus = {};
                try { var fi = R.armyFreeInfo || {}; Object.keys(fi).forEach(function (u) { out.free[u] = Number(fi[u]) || 0; }); } catch (_) {}
                try { var ai = R.armyInfo || {}; Object.keys(p).forEach(function (k) { if (p[k].type === "buff" || p[k].type === "speedbuff") return; var has = (ai[k] && ai[k].army) || {}, want = p[k].army || {};
                    Object.keys(has).forEach(function (u) { var x = (Number(has[u]) || 0) - (Number(want[u]) || 0); if (x > 0) out.surplus[u] = (out.surplus[u] || 0) + x; }); }); } catch (_) {}
                out.canFree = !!c.canFree;
                return out;
            },
            /* 0.1.1: armyLoadGenerals(true) still touches the Mundane window (battleWindow) and fails when it was never
               opened; this is its direct path: one dRaiseArmyVO per general that does not match yet, 1 s apart */
            load: function (packet) {
                var p = copy(packet); R.battlePacket = p;
                try { R.updateFreeArmyInfo(true); } catch (_) {}
                R.armyLoadDataCheck(p);
                var VO = R.dRaiseArmyVODef || R.swmmo.getDefinitionByName("Communication.VO::dRaiseArmyVO"),
                    RVO = R.dResourceVODef || R.swmmo.getDefinitionByName("Communication.VO::dResourceVO"), n = 0;
                Object.keys(p).forEach(function (k) {
                    if (p[k].type === "buff" || p[k].type === "speedbuff" || (R.armyPacketMatches && R.armyPacketMatches[k])) return;
                    var s = spec(k); if (!s) return;
                    var vo = new VO(); vo.armyHolderSpecialistVO = s.CreateSpecialistVOFromSpecialist();
                    Object.keys(p[k].army || {}).forEach(function (u) { var r = new RVO(); r.name_string = u; r.amount = p[k].army[u]; vo.unitSquads.addItem(r); });
                    setTimeout(function () { try { via(function (A, cx) { return A.sendMessage("RAISE_ARMY", vo, null, cx); }); } catch (_) {} }, 1000 * (n++));
                });
                return n;
            },
            send: function (ids, zone) { ids.forEach(function (id) { var s = spec(id); if (s) R.armyServices.specialist.sendToZone(s, zone); }); },
            /* 0.1.4: battleMove only sends generals whose canMove is true, and the Mundane check says false for a general
               in the star (live: FT02's RES, MOUTH, GHOST2 never left the star). Send the move order directly, as the
               star menu / community script does: server action 95 subtask 4 on the template grid; grid -1 = to the star. */
            move: function (packet) {
                var p = R.battleLoadDataCheck(copy(packet)), n = 0;
                Object.keys(p).forEach(function (k) {
                    var d = p[k]; if (!d || d.type === "buff" || d.type === "speedbuff" || !d.spec || d.onSameGrid) return;
                    var sp = d.spec; try { if (sp.GetTask() != null) return; } catch (_) { return; }
                    setTimeout(function () {
                        try {
                            if (d.grid > 0) {
                                g().gi.mCurrentCursor.mCurrentSpecialist = sp;
                                var t = new R.armySpecTaskDef(); t.uniqueID = sp.GetUniqueID(); t.subTaskID = 0;
                                via(function (A, cx) { return A.sendAction("SPECIALIST_TASK", 4, d.grid, 0, t, cx); });
                            } else R.armySendGeneralToStar(sp);
                        } catch (_) {}
                    }, 1200 * (n++));
                });
                return n;
            },
            /* 0.2.37: may general k stand on grid? null when the game cannot say */
            placeCode: function (k, grid) {   // 0.2.173: the game's own answer to "may this general stand here" (0 = yes), for the log
                var sp0 = spec(k); if (!sp0 || !(grid > 0)) return null; var mc0 = g().gi.mMouseCursor, r0 = null;
                try { mc0.SetCursorEditMode(86); g().gi.mCurrentCursor.mCurrentSpecialist = sp0; r0 = mc0.CheckIfGarrisonIsPlacableInGame(grid, true); } catch (_) { r0 = null; }
                finally { try { mc0.SetToLastEditMode(); } catch (_) {} }
                return r0 == null ? null : (r0 === false ? 0 : (r0 === true ? 1 : Number(r0)));
            },
            placeable: function (k, grid) {
                var sp = spec(k); if (!sp || !(grid > 0)) return null;
                var mc = g().gi.mMouseCursor, r = null;
                try { mc.SetCursorEditMode(86); g().gi.mCurrentCursor.mCurrentSpecialist = sp; r = mc.CheckIfGarrisonIsPlacableInGame(grid, true); } catch (_) { r = null; }
                finally { try { mc.SetToLastEditMode(); } catch (_) {} }
                return r == null ? null : (r === 0 || r === false);
            },
            /* 0.2.37: the placeable grid near grid for general k, away from the round's other grids, shortest to target.
               0.2.133 (live IP 2026-11-23 02:10Z: "no placeable spot near camp" for all 11 generals — on that island a general may
               only stand on land the player holds, 17 to 47 tiles from the camps in the author's own IotP template): the search
               widens ring by ring up to 70 tiles until a ring holds a placeable spot, then looks two rings further and takes the
               shortest path to the target; the path-length cap and the "on the target's side" filter hold within 6 tiles only,
               and the side filter is dropped when nothing else is placeable */
            nearPlaceable: function (k, grid, target, others) {
                var sp = spec(k), z = g().gi.mCurrentPlayerZone, W = Number(z.mMapWidth) || 0, H = Number(z.mMapHeight) || 0; if (!sp || !W) return -1;
                var mc = g().gi.mMouseCursor, x0 = grid % W, y0 = Math.floor(grid / W), best = -1, bestV = Infinity, entry = null, camps = [], maxL = Infinity;
                try { var b = target > 0 ? z.mStreetDataMap.GetBuildingByGridPos(target) : null; entry = b ? b.GetStreetGridEntry() : null; } catch (_) {}
                try { z.mStreetDataMap.GetBuildings_vector().forEach(function (bb) { try { var ar = bb.GetArmy(), gg = bb.GetGrid(); if (gg !== target && ar && ar.HasUnits()) camps.push(gg); } catch (_) {} }); } catch (_) {}   // 0.2.39
                function cheb(a1, a2) { return Math.max(Math.abs(a1 % W - a2 % W), Math.abs(Math.floor(a1 / W) - Math.floor(a2 / W))); }
                if (entry != null) { try { var L0 = g().gi.mPathFinder.CalculatePath(entry, grid, null, true).pathLenX10000; if (L0 > 0) maxL = L0 * 1.5; } catch (_) {} }
                var spare = null, spareV = Infinity, foundAt = 0;
                try {
                    mc.SetCursorEditMode(86); g().gi.mCurrentCursor.mCurrentSpecialist = sp;
                    for (var r = 0; r <= 70; r++) {
                        if (foundAt && r > foundAt + 2) break;
                        for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) {
                            if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
                            var x = x0 + dx, y = y0 + dy; if (x < 0 || y < 0 || x >= W || y >= H) continue;
                            var gr = y * W + x;
                            if ((others || []).some(function (o) { return Math.max(Math.abs(o % W - x), Math.abs(Math.floor(o / W) - y)) < 2; })) continue;
                            var pl = null; try { pl = mc.CheckIfGarrisonIsPlacableInGame(gr, true); } catch (_) { pl = null; }
                            if (pl !== 0 && pl !== false) continue;
                            var v = r * 1e9, L = -1;
                            if (entry != null) { try { L = g().gi.mPathFinder.CalculatePath(entry, gr, null, true).pathLenX10000; } catch (_) {} if (!(L > 0) || (r <= 6 && L > maxL)) continue; v = L; }
                            var side = true;
                            if (target > 0) { var dT = cheb(gr, target); side = !camps.some(function (cg) { return cheb(gr, cg) <= dT; }); }   // 0.2.39: on the target's side
                            if (!side) { if (r > 6 && v < spareV) { spareV = v; spare = gr; } continue; }
                            if (!foundAt) foundAt = r;
                            if (v < bestV) { bestV = v; best = gr; }
                        }
                    }
                } finally { try { mc.SetToLastEditMode(); } catch (_) {} }
                return best > 0 ? best : (spare != null ? spare : -1);
            },
            /* 0.2.172 (live FT 2026-11-26; read from Mundane's own source, tso_client 5-battle.js / 6-buffs.js / 0-common.js):
               - Mundane sends a packet in the order of its KEYS (battleAttack: $.each(battlePacket)); the "order" field is only
                 kept in the file. A plan's order is its "order" field (R-PLAN-AS-WRITTEN), so the packet is handed over with its
                 keys in that order (sendOrder).
               - Mundane takes an arrow's id from buffsAvailable[name].id, filled by getBuffAvailableCount() from its own variable
                 buffVector - which is only set when Mundane's battle or buff window has been opened. On a client where the
                 player never opens them the read throws after writing { count: 0, id: "" }, and every arrow of the packet goes
                 out with an empty id: no arrow. The star is read here and handed to Mundane (buffVector), and an id still
                 missing is filled from the star itself.
               - an arrow that cannot be put on its camp (none in the star, its id not known to Mundane) holds the whole packet:
                 nothing is sent, the answer says why (held, arrows) - generals never walk on without the arrow of their plan. */
            attack: function (packet) {
                var star = null; try { star = g().gi.mCurrentPlayer.getAvailableBuffs_vector(); } catch (_) { star = null; }
                try { if (star) R.buffVector = star; } catch (_) {}
                var arrowsOf = [], badArrow = [], goneArrow = [];
                Object.keys(packet).forEach(function (k) { var v = packet[k]; if (!v || (v.type !== "buff" && v.type !== "speedbuff")) return;
                    try { R.getBuffAvailableCount(v.name); } catch (_) {}   // 0.2.24: fills buffsAvailable for the buff entries
                    if (v.type !== "buff" || !(Number(v.target) > 0)) return;
                    var ba = null; try { ba = R.buffsAvailable ? R.buffsAvailable[v.name] : null; } catch (_) { ba = null; }
                    if ((!ba || !ba.id || !(Number(ba.count) > 0)) && star) { try { var cnt = 0, id = "";
                        star.forEach(function (b) { try { if (String(b.GetBuffDefinition().GetName_string()) !== String(v.name)) return; cnt += Number(b.GetAmount()) || 0;
                            if (!id) { var u = b.GetUniqueId(); id = u.uniqueID1 + "_" + u.uniqueID2; } } catch (_) {} });
                        if (cnt > 0 && id && R.buffsAvailable) { R.buffsAvailable[v.name] = { count: cnt, id: id }; ba = R.buffsAvailable[v.name]; } } catch (_) {} }
                    var alive = false; try { var tb = g().zone.mStreetDataMap.GetBuildingByGridPos(Number(v.target)), ta = tb ? tb.GetArmy() : null; alive = !!(ta && ta.HasUnits()); } catch (_) { alive = false; }
                    if (!alive) { goneArrow.push(k); return; }   // its camp is gone: the arrow is not needed and is not sent (never used on a camp that fell)
                    arrowsOf.push(k);
                    if (!ba || !ba.id || !(Number(ba.count) > 0)) badArrow.push(String(v.name) + " on camp " + v.target + ": " + (ba && Number(ba.count) > 0 ? "its id is not known to Mundane" : "none in the star (or the star could not be read)")); });
                /* 0.2.63 (author: "Soms moet je een generaal naar een ander kamp sturen om onderschept te worden. Als je hem direct
                   naar dat kamp stuurt verandert het pad"): a block with "via" is sent to that camp and blocks its own camp by
                   being caught on the way */
                var cp1 = copy(packet), cp0 = {}; sendOrder(cp1).forEach(function (k) { cp0[k] = cp1[k]; });   // 0.2.172: Mundane sends in key order
                Object.keys(cp0).forEach(function (k) { var v = cp0[k]; if (v && v.block && Number(v.via) > 0) v.target = Number(v.via); });
                R.battlePacket = R.battleLoadDataCheck(cp0);
                var bp = R.battlePacket || {}, out = { queued: 0, of: 0, left: [], arrows: arrowsOf.length };   // 0.2.52: what Mundane will really send
                Object.keys(bp).forEach(function (k) { var v = bp[k]; if (!v || !(v.target > 0)) return;
                    if (v.type === "buff") { if (goneArrow.indexOf(k) >= 0) { v.canAttack = false; return; }
                        if (arrowsOf.indexOf(k) >= 0 && !v.canAttack) badArrow.push(String(v.name) + " on camp " + v.target + ": Mundane does not take it (the key of an arrow must start with \"buff\")"); return; }   // 0.2.172: an arrow is no general
                    out.of++; if (v.canAttack) { out.queued++; return; }
                    var sp = v.spec || null, why = [];
                    try { if (!sp) why.push("no specialist"); else { if (!v.onSameGrid) why.push("not on its spot (" + sp.GetGarrisonGridIdx() + " vs " + v.grid + ")"); if (sp.GetTask() != null) why.push("busy"); if (!sp.HasUnits()) why.push("no units"); } } catch (e) { why.push(String(e).slice(0, 60)); }
                    out.left.push(String(v.name || k).replace(/<[^>]*>/g, "").split(" ")[0] + ": " + (why.join(", ") || "no path / no camp")); });
                /* 0.2.175 (author 2026-11-27 06:07: "jouw mundane ... 1e arrow, aanval 1, 2e arrow, aanval 2, 3e arrow, aanval 3"; live FT
                   04:18:56Z: the three camps of the arrows fell at the same moment): Mundane's battleAttack leaves out an entry with
                   canAttack false TOGETHER WITH ITS TIME (tso_client 5-battle.js: "if(!canAttack) return" before queue.add(fn, time)).
                   In an author's plan the waits stand on the generals (VAR 35 s, RES2 130 s) and the arrows have 1 s, so one general
                   left out made the arrows after him leave seconds after the first - before the attacks they were to open the way
                   for. The time of every entry Mundane will not send is carried onto the next entry it does send, so each arrow
                   and attack keeps its moment in the plan. */
                var carryT = 0; Object.keys(bp).forEach(function (k) { var v = bp[k]; if (!v) return;
                    if (!v.canAttack) { carryT += Number(v.time) || 0; return; }
                    if (carryT) { v.time = (Number(v.time) || 0) + carryT; carryT = 0; } });
                if (badArrow.length) { out.held = true; out.queued = 0; out.badArrows = badArrow; badArrow.forEach(function (b) { out.left.push("arrow " + b); }); return out; }
                if (!out.of && out.arrows) { out.of = out.arrows; out.queued = out.arrows; }   // a packet of arrows only (an arrow sent alone)
                R.battleAttack(true);
                return out;
            },
            /* 0.2.47 (ADR 0062): interception as the client's Combat Preview decides it — which living camps watch the path
               from a general's spot to its camp (StreetDataMap.GetReadyTowerGridIdxs along the path), and the path length */
            intercepts: function (packet) {
                var zone = g().zone, sm = zone.mStreetDataMap, pf = g().gi.mPathFinder, byEntry = {}, out = {};
                sm.GetBuildings_vector().forEach(function (b) { try { var a = b.GetArmy(); if (!a || !a.HasUnits()) return; byEntry[b.GetStreetGridEntry()] = b.GetGrid(); } catch (_) {} });
                Object.keys(packet).forEach(function (k) {
                    var v = packet[k]; if (!v || !(v.target > 0) || v.type === "buff" || v.type === "speedbuff") return;
                    var dest = v.block && Number(v.via) > 0 ? Number(v.via) : v.target;   // 0.2.63: a via-block walks to its via camp
                    var r = out[k] = { target: dest, by: [], len: null };
                    try {
                        var tb = sm.GetBuildingByGridPos(dest), te = tb ? tb.GetStreetGridEntry() : null; if (te == null) return;
                        /* 0.2.64 (author: "dat kun je dus bepalen met de test aanval die de cliënt zelf biedt"; read from client.swf,
                           cSpecialistTask_AttackBuilding and cStreetDataMap): the game's own attack path starts at the general's
                           GARRISON STREET ENTRY — CalculatePath(target.GetStreetGridEntry(), garrison.GetStreetGridEntry(), null, true) —
                           not at the spot's grid, which gave another path; and a general is caught on a street that some camp
                           watches (IsWatchedByTowers) and that its own target does NOT watch (IsBuildingWatching), by a ready camp
                           (GetReadyTowerGridIdxs; hidden camps never). 0.2.60's "the target's own streets count too" was wrong. */
                        var st = null; try { var sp0 = R.armyGetSpecialistFromID(String(k)), gar = sp0 && sp0.GetGarrison ? sp0.GetGarrison() : null; if (gar) st = gar.GetStreetGridEntry(); } catch (_) {}
                        if (st == null) { try { var gb = sm.GetBuildingByGridPos(Number(v.grid)); if (gb) st = gb.GetStreetGridEntry(); } catch (_) {} }
                        if (st == null) st = Number(v.grid);
                        var p = pf.CalculatePath(te, st, null, true), dv = p ? p.dest_vector : null, n = dv ? Number(dv.length) : 0;
                        r.len = p ? Number(p.pathLenX10000) : null;
                        r.steps = n; r.watch = {}; r.from = st;   // step i = dest_vector[i]: path pos i x 10 000 from the garrison street
                        for (var i = 0; i < n; i++) {
                            var sg = dv[i].streetGridIdx; if (sm.IsBuildingWatching(sg, tb)) continue;
                            var tw = sm.GetReadyTowerGridIdxs(sg); if (!tw) continue;
                            for (var j = 0; j < tw.length; j++) { var cg = byEntry[tw[j]]; if (cg == null || cg === dest) continue;
                                if (r.by.indexOf(cg) < 0) r.by.push(cg); var wv = r.watch[cg] || (r.watch[cg] = [i, i]); wv[1] = Math.max(wv[1], i); }
                        }
                    } catch (_) {}
                });
                return out;
            },
            attacking: function () {   // 0.2.47: generals of ours with an attack task (walking, fighting, waiting, walking back)
                var n = 0; try { g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) { try { if (s && s.getPlayerID() === me()) { var t = s.GetTask(); if (t && /AttackBuilding/.test(String(R.runtime ? R.runtime.flash.utils.getQualifiedClassName(t) : t) + String(t))) n++; } } catch (_) {} }); } catch (_) {}
                return n;
            },
            campArmy: function (grid) {   // 0.2.69: {units, by type, engaged} of a camp, or null when it is gone
                try { var b = g().zone.mStreetDataMap.GetBuildingByGridPos(grid); if (!b) return null; var a = b.GetArmy(); if (!a || !a.HasUnits()) return null;
                      var o = { units: 0, by: {}, engaged: !!(b.IsEngagedInCombat && b.IsEngagedInCombat()) }, v = a.GetSquads_vector ? a.GetSquads_vector() : null, n = v ? (v.length || 0) : 0;
                      for (var i = 0; i < n; i++) { var q = v.getItemAt ? v.getItemAt(i) : v[i]; if (!q) continue; var ty = String(q.GetType()), am = Number(q.GetAmount()) || 0; if (am > 0) { o.by[ty] = (o.by[ty] || 0) + am; o.units += am; } }
                      return o; } catch (_) { return null; }
            },
            campAlive: function (grid) {
                try { var b = g().zone.mStreetDataMap.GetBuildingByGridPos(grid); if (!b) return false; var a = b.GetArmy(); return !!(a && a.HasUnits()); } catch (_) { return false; }
            },
            idleOnIsland: function () {
                var out = [];
                g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) {
                    try { if (s && s.getPlayerID() === me() && R.armySPECIALIST_TYPE.IsGeneral(s.GetType()) && s.GetGarrisonGridIdx() > 0 && s.GetTask() == null && !s.IsInUse())
                          out.push(s.GetUniqueID().toKeyString()); } catch (_) {}
                });
                return out;
            },
            toStar: function (ids) { ids.forEach(function (id) { var s = spec(id); if (!s) return; try { R.armySendGeneralToStar(s); } catch (e) { try { if (R.DMA_Control && R.DMA_Control.log) R.DMA_Control.log("adv: to the star failed for " + id + ": " + String(e).slice(0, 80)); } catch (_) {} } }); },   // 0.2.77: one general the game cannot send (no garrison) does not stop the run
            refresh: function () { try { return via(function (A, cx) { return A.sendMessage("ZONE_REFRESH", null, null, cx); }).ok; } catch (_) { return false; } },   // 0.2.45
            /* 0.2.22 (author: "nog steeds geen collectables"): the way the client's own "pick up all" (8-shortcuts) does
               it — collectible buildings, and on an adventure the quest-trigger buildings without units that are not
               enemy camps — one selection per second */
            /* 0.2.23 (author: "gewoon altijd c laten drukken"): press the client's own pick-up-all (shortcutsPickupAll,
               the C / menu entry) when it is there; our own search only as the fallback */
            pressC: function () { try { if (typeof R.shortcutsPickupAll === "function") { R.shortcutsPickupAll(); return true; } } catch (_) {} return false; },
            collect: function () {
                if (this.pressC && this.pressC()) return "C";
                var gi = g().gi, cm = R.swmmo.getDefinitionByName("Collections::CollectionsManager").getInstance(), trig = {}, list = [];
                try { if (gi.mCurrentPlayer.mIsAdventureZone) { var qs = gi.mNewQuestManager.GetQuestPool().GetQuest_vector();
                      for (var i = 0; qs && i < qs.length; i++) { var q = qs[i]; try { if (q.isFinished() || !q.IsQuestActive()) continue; var tv = q.mQuestDefinition.questTriggers_vector, n = tv ? tv.length : 0;
                          for (var j = 0; j < n; j++) { var t = tv.getItemAt ? tv.getItemAt(j) : tv[j]; if (t && t.name_string) trig[String(t.name_string)] = 1; } } catch (_) {} } } } catch (_) {}
                gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector().forEach(function (b) {
                    try { if (!b) return; var nm = String(b.GetBuildingName_string()), go = b.GetGOContainer(), army = b.GetArmy();
                          if (cm.getBuildingIsCollectible(nm) || (trig[nm] && b.mIsSelectable && go.mIsAttackable && !go.mIsLeaderCamp && go.ui !== "enemy" && (army == null || !army.HasUnits()))) list.push(b); } catch (_) {}
                });
                list.forEach(function (b, k) { setTimeout(function () { try { gi.SelectBuilding(b); } catch (_) {} }, 1000 * (k + 1)); });
                return list.length;
            },
            /* 0.1.8 (ADR 0034, step 1b): the quest chain the way the game's own quest book does it (and the community
               script): refresh, OK every new quest (mode 2), reward every finished one with the quest book shown, and
               report when the quest marked "lastQuest" is rewarded — that ends the adventure. */
            claimQuests: function () {
                var r = { claimed: 0, accepted: 0, open: 0, last: false }, qm = g().gi.mNewQuestManager, book = R.globalFlash && R.globalFlash.gui && R.globalFlash.gui.mQuestBook;
                try { g().gi.mQuestClientCallbacks.JustRefresh(); } catch (_) {}
                var qv = qm.GetQuestPool().GetQuest_vector(), qn = Number(qv && qv.length) || 0;
                for (var qi = 0; qi < qn; qi++) {
                    var q = qv[qi]; if (!q) continue;
                    try {
                        var mode = String(q.GetQuestMode()), special = "";
                        try { special = String(q.GetQuestDefinition().specialType_string); } catch (_) {}
                        if (mode === "2") { if (book) book.SetPreselectedQuest(q); if (book) book.Show(); g().gi.mQuestClientCallbacks.QuestOkButtonPressedFromGui(q); if (book) book.Hide(); r.accepted++; continue; }
                        if (q.isFinished()) {
                            if (book) { book.SetPreselectedQuest(q); book.Show(); }
                            qm.RewardOkButtonPressedFromGui(q);
                            if (book) book.Hide();
                            r.claimed++; if (special === "lastQuest" || special === "firstQuestlastQuest") r.last = true;
                        } else if (q.IsQuestActive()) r.open++;
                    } catch (_) {}
                }
                return r;
            },
            /* 0.1.8 (step 1a): read-only inventory of the adventures in the star and of the adventure objects, for the
               catalogue (type, players, loot spots) — getters without parameters only */
            /* 0.2.10 (author: "herkent welke kampen vernietigd moeten worden ... kan de speler per kamp aangeven hoe hij dat
               wil?"): the camps of the viewed adventure (grid, name, units) and the camps its quests ask to destroy
               (quest trigger actionType "buildingdestroyed": name_string, amount) */
            /* 0.2.115 (ADR 0092): the landing fields of the viewed zone, from the game; null when they cannot be read */
            landingFields: function () { try { var lf = g().zone.mStreetDataMap.GetAllLandingFieldsPositions_vector(), li = [], q, n = lf ? (lf.length || 0) : 0;
                for (q = 0; q < n; q++) li.push(Number(lf.getItemAt ? lf.getItemAt(q) : lf[q])); return li; } catch (_) { return null; } },
            campMap: function () {
                var out = { zone: g().gi.mCurrentViewedZoneID, camps: [], destroy: [] };
                try { advMgrList().forEach(function (a) { if (a.zoneID === out.zone) out.res = a.res; }); } catch (_) {}   // 0.2.126: which adventure this map is
                try { g().zone.mStreetDataMap.GetBuildings_vector().forEach(function (b) {
                    try { var a = b.GetArmy && b.GetArmy(); if (!a) return; var n = 0; try { n = a.GetUnitsCount(); } catch (_) {}
                          var army = {}; try { if (a.GetSquadsCollection_vector) a.GetSquadsCollection_vector().forEach(function (q) { try { var k = Number(q.GetAmount()); if (k > 0) army[String(q.GetType())] = (army[String(q.GetType())] || 0) + k; } catch (_) {} }); } catch (_) {}   // 0.2.125 (ADR 0094)
                          out.camps.push({ grid: b.GetGrid(), name: String(b.GetBuildingName_string()), units: n, alive: !!a.HasUnits(), army: army }); } catch (_) {}
                }); } catch (_) {}
                try { var qs = g().gi.mNewQuestManager.GetQuestPool().GetQuest_vector(); for (var i = 0; qs && i < qs.length; i++) {
                    try { var d = qs[i].GetQuestDefinition(), tv = d.questTriggers_vector, n2 = tv ? (tv.length || 0) : 0;
                          for (var j = 0; j < n2; j++) { var t = tv.getItemAt ? tv.getItemAt(j) : tv[j];
                              if (t) (out.triggers = out.triggers || []).push(String(t.actionType_string) + ":" + String(t.name_string) + "x" + t.amount);   // 0.2.13: diagnosis
                              var campNamed = t && out.camps.some(function (c) { return c.name === String(t.name_string) && c.units > 0; });   // 0.2.15 (GP: ":Dark_Castle_01x1")
                              if (t && (campNamed || /buildingdestroyed|destroybuilding|defeat/i.test(String(t.actionType_string)))) out.destroy.push({ quest: String(d.questName_string), name: String(t.name_string), amount: Number(t.amount) || 1 }); } } catch (_) {}
                } } catch (_) {}
                return out;
            },
            probe: function () {
                var rt = R.runtime, dt = rt && rt.flash && rt.flash.utils && rt.flash.utils.describeType, out = { at: new Date().toISOString(), star: [], adventures: [], members: {} };
                function members(o) { try { var x = String(dt(o)), m, re = /<(method|accessor|variable|constant)\s+name="([^"]+)"[^>]*?(?:returnType="([^"]*)")?[^>]*>/g, list = []; while ((m = re.exec(x)) !== null) list.push(m[1] + ":" + m[2]); var c = /<type\s+name="([^"]+)"/.exec(x); return { type: c ? c[1] : "", members: list }; } catch (e) { return { error: String(e) }; } }
                function values(o) {
                    var v = {}, x = ""; try { x = String(dt(o)); } catch (_) { return v; }
                    var re = /<method\s+name="((?:Get|get|is|Is|has|Has)[A-Za-z_]*)"[^>]*returnType="(int|uint|Number|String|Boolean)"[^>]*\/>/g, m;
                    while ((m = re.exec(x)) !== null) { try { v[m[1]] = o[m[1]](); } catch (_) {} }
                    var re2 = /<(?:accessor|variable)\s+name="([A-Za-z_]+)"[^>]*type="(int|uint|Number|String|Boolean)"/g;
                    while ((m = re2.exec(x)) !== null) { try { v[m[1]] = o[m[1]]; } catch (_) {} }
                    return v;
                }
                var first = true;
                g().gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) {
                    try {
                        var def = b.GetBuffDefinition(); if (def.GetName_string() !== "Adventure") return;
                        var res = b.GetResourceName_string(), e = { res: res, name: "", buff: values(b), def: values(def) };
                        try { e.name = R.loca.GetText("ADN", res); } catch (_) {}
                        if (first) { out.members.buff = members(b); out.members.def = members(def); first = false; }
                        out.star.push(e);
                    } catch (_) {}
                });
                try { out.members.gi = members(g().gi); out.members.gi.members = out.members.gi.members.filter(function (m) { return /adventure|leave|finish|quest|complete|zone/i.test(m); }); } catch (_) {}   // 0.2.2: how the game closes an adventure
                try { out.members.questManager = members(g().gi.mNewQuestManager); out.members.questBook = members(R.globalFlash.gui.mQuestBook); out.members.callbacks = members(g().gi.mQuestClientCallbacks); } catch (_) {}
                try { var am = advMgr(); out.members.manager = members(am); am.getAdventures().forEach(function (a, i) { if (!a) return; if (i === 0) out.members.adventure = members(a); out.adventures.push(values(a)); }); } catch (e) { out.managerError = String(e); }
                return out;
            },
            allGeneralIds: function () {
                var out = [];
                g().gi.mCurrentPlayerZone.GetSpecialists_vector().forEach(function (s) {
                    try { if (s && s.getPlayerID() === me() && R.armySPECIALIST_TYPE.IsGeneral(s.GetType())) out.push(s.GetUniqueID().toKeyString()); } catch (_) {}
                });
                return out;
            },
            attackQueue: function () { try { var q = R.battleTimedQueue; if (!q || typeof q.len !== "function") return { sending: false }; return { sending: q.index < q.len(), index: q.index, len: q.len() }; } catch (_) { return { sending: false }; } },   // 0.2.102
            startupHold: function () { try { var C = R.DMA_Control; if (!C || !C.visit || typeof C.visit.held !== "function" || !C.visit.held()) return false; return ((C.visit.state && C.visit.state().by) || "") === "startup"; } catch (_) { return false; } },   // 0.2.101
            log: function (msg) { try { if (R.DMA_Control && R.DMA_Control.log) R.DMA_Control.log("adv: " + msg); } catch (_) {} try { if (typeof R.debug === "function") R.debug("adv: " + msg); } catch (_) {} },
            status: function (obj) {
                try { var A = R.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-adv-status.json").nativePath), st = new A.FileStream();
                      st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (_) {}
            }
        };
    }

    /* ---------------- templates: plain packets in run order ---------------- */
    function toPacket(text) {
        var d = JSON.parse(String(text)), out = {}, c, k;
        if (d && d.content && d.tree) { for (c in d.content) if (d.content.hasOwnProperty(c)) for (k in d.content[c]) if (d.content[c].hasOwnProperty(k)) out[k] = d.content[c][k]; return out; }
        return d;
    }
    /* 0.2.47 (ADR 0062): camps ordered into interception layers: a camp goes after every camp of this round that
       intercepts its path; a blocker this round does not attack cannot be waited for; a cycle ends in one last layer */
    function layersOf(ic, tg) {
        var by = {}; tg.forEach(function (t) { by[t] = []; });
        Object.keys(ic).forEach(function (k) { var r = ic[k]; if (!by[r.target]) by[r.target] = []; r.by.forEach(function (b) { if (by[r.target].indexOf(b) < 0) by[r.target].push(b); }); });
        var done = [], plan = [], left = Object.keys(by).map(Number);
        while (left.length) {
            var now = left.filter(function (t) { return by[t].every(function (b) { return left.indexOf(b) < 0 || b === t; }); });   // blockers this round does not attack cannot be waited for
            if (!now.length) { plan.push(left.slice()); break; }
            plan.push(now); done = done.concat(now); left = left.filter(function (t) { return now.indexOf(t) < 0; });
        }
        return plan;
    }
    function layerPacket(pk, camps, ic, first) {
        var o = {}; Object.keys(pk).forEach(function (k) { if (pk[k] && !pk[k].block && camps.indexOf(pk[k].target) >= 0) o[k] = pk[k]; });
        Object.keys(pk).forEach(function (b) { if (!pk[b] || !pk[b].block) return;   // 0.2.49: a block goes with the layer whose paths its camp watches
            var need = Object.keys(o).some(function (k) { return ic && ic[k] && ic[k].watch && ic[k].watch[pk[b].target]; });
            var anyone = Object.keys(pk).some(function (k) { return !pk[k].block && ic && ic[k] && ic[k].watch && ic[k].watch[pk[b].target]; });
            if (need || (first && !anyone)) o[b] = pk[b]; });
        return o;
    }
    /* 0.2.172 (live FT 2026-11-26): the order in which a packet is sent - its "order" fields, an entry without one in its key
       place (as the self-repair reads it). Mundane's queue sends in KEY order, so a packet is handed over with its keys in this order. */
    function sendOrder(pk) { var ks = Object.keys(pk || {}); return ks.slice().sort(function (a, b) { var oa = pk[a] && pk[a].order != null ? Number(pk[a].order) : ks.indexOf(a), ob = pk[b] && pk[b].order != null ? Number(pk[b].order) : ks.indexOf(b); return oa - ob || ks.indexOf(a) - ks.indexOf(b); }); }
    function generalIds(p) { return Object.keys(p).filter(function (k) { return p[k] && p[k].type !== "buff" && p[k].type !== "speedbuff"; }); }
    function genLive(p, Gx) { return Object.keys(p || {}).filter(function (k) { return p[k] && p[k].target > 0 && !p[k].block && (!Gx || !Gx.campAlive || Gx.campAlive(Number(p[k].target))); }).length; }   // 0.2.143
    function genCount(p) { return Object.keys(p || {}).filter(function (k) { return p[k] && p[k].target > 0 && !p[k].block; }).length; }   // 0.2.139
    function targets(p) { var t = []; Object.keys(p).forEach(function (k) { if (p[k] && p[k].target > 0 && !p[k].block && t.indexOf(p[k].target) < 0) t.push(p[k].target); }); return t; }   // 0.2.24: buff targets count too; 0.2.49: a camp only blocked is no target
    /* 0.2.130: a camp whose attackers in this step all carry at most one unit (1R waves): weakened here, taken in a later step */
        /* 0.2.161 (live IP 10:15Z: YGG3 and YGG1 each took a camp alone with 1 Recruit — the general's own strike — the run called both
           camps "weakened" and went on while they stood): only a camp that a LATER step attacks again is wave-only here */
        function waveOnly(p, t, later) { if (later && !later.some(function (q) { return Object.keys(q || {}).some(function (k) { return q[k] && Number(q[k].target) === Number(t); }); })) return false;
            var ks = Object.keys(p || {}).filter(function (k) { return p[k] && Number(p[k].target) === Number(t); });
            return ks.length > 0 && ks.every(function (k) { var a = p[k].army || {}, n = 0; Object.keys(a).forEach(function (u) { n += Number(a[u]) || 0; }); return n <= 1; }); }
        function blockIds(p) { return Object.keys(p).filter(function (k) { return p[k] && p[k].block && p[k].target > 0; }); }

    /* 0.2.51 (ADR 0066): send times of one layer. Attackers first (template order; a general reaches its camp at least 10 s
       after the one before it there; sends at least 2 s apart), then per blocked camp the chain. 0.2.54 (rehearsal
       2026-11-14; author: "daar waar je de marge te gevaarlijk vindt kun je kijken naar de maximale lengte van een block
       aanval"): a passer is interceptable on every step of its path the camp watches, from the first (the preview's dot)
       to the last — streets the target watches too included (MOUTH was caught by 1.2 three steps before 1.3, when the
       chain ended). Its stretch is taken wide: entry at 3.30 s per step, exit at 3.40 s per step (measured 3.31–3.40), and
       when the camp watches up to the target, until the passer has won there (fightMs). The chain must cover every
       stretch with MARGIN on both sides; the LONGEST blocks go first (fewest junctions; a long block over a row of 1R
       blocks). When it cannot, the layer is not sent and the log names the seconds missing and that a longer block
       (blockms.js --pick: the longest the general can hold) is what closes it. Returns {order, send, bad, span, still,
       chains: per camp {n, from, until, need, slack}}. */
    var APPROACH = 4000, STEP_MS = 10000 / 3000 * 1000, WALK = 3000, STEP_FAST = 3300, STEP_SLOW = 3400, MARGIN = 5000, JOIN = 1000;
    var SPEED = { GeneralSpeedBuff_Bronze: 0.15, GeneralSpeedBuff_Platinum: 0.20, GeneralSpeedBuff_Blackened_Titanium: 0.25, GeneralSpeedBuff_Obsidian: 0.30, GeneralSpeedBuff_Mystical: 0.40 };   // 0.2.55: tsowiki combat buffs
    function planSends(lp, ic, opt) {
        ic = ic || {}; opt = opt || {};
        var margin = opt.marginMs != null ? Number(opt.marginMs) : MARGIN;
        /* 0.2.55: under a horseshoe (+p movement speed) a step takes 1/(1+p); unmeasured, so the way out is taken 3 % slower still */
        var f = 1 + (Number(opt.speed) || 0), SF = STEP_FAST / f, SS = STEP_SLOW / f * (f > 1 ? 1.03 : 1);
        var keys = Object.keys(lp), send = {}, bad = [], used = {};
        keys.forEach(function (k) { var v = lp[k]; if (v.block && Number(v.via) > 0 && ic[k] && !(ic[k].watch && ic[k].watch[v.target])) bad.push(String(v.name || k).replace(/<[^>]*>/g, "").split(" ")[0] + ": sent via " + v.via + " it is not caught by " + v.target); });   // 0.2.63
        function tr(k) { var v = lp[k], w = v && v.block && Number(v.via) > 0 && ic[k] && ic[k].watch && ic[k].watch[v.target];
            if (w) return (w[0] * STEP_MS + APPROACH) / f;   // 0.2.63: a via-block starts its fight when caught at its first watched dot, plus the walk to the camp
            var L = ic[k] && ic[k].len; return L ? L / WALK * 1000 / f : 0; }
        function trSlow(k) { var L = ic[k] && ic[k].len; return L ? L / 10000 * SS : 0; }
        function nm(k) { return String(lp[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0]; }
        var att = keys.filter(function (k) { return !lp[k].block; }).sort(function (a, b) { return (lp[a].order || 0) - (lp[b].order || 0); });
        var prev = null, lastAt = {};
        att.forEach(function (k) { var tg = lp[k].target, x = prev == null ? 0 : prev + 2000;
            /* 0.2.76 (author: "je hebt normaal 1 generaal per kamp, ook een block"): an attacker with queue: true follows the one
               ahead 2 s behind and waits at the leader while it fights — both cross the watched streets together, so one
               block covers them */
            if (tr(k) && lastAt[tg] != null && !lp[k].queue) x = Math.max(x, lastAt[tg] + 10000 - tr(k));
            send[k] = x; prev = x; if (tr(k)) lastAt[tg] = x + tr(k) + Number(lp[k].fightMs || 0); });   // 0.2.69: the next one arrives 10 s after this one's fight (fightMs), still walking when it ends
        var fallAt = null; att.forEach(function (k) { if (tr(k) && lp[k].fightMs) fallAt = Math.max(fallAt == null ? 0 : fallAt, send[k] + tr(k) + Number(lp[k].fightMs)); });   // 0.2.73: the leader falls when the last attacker's fight ends
        var chains = {}; keys.forEach(function (k) { if (lp[k].block) (chains[lp[k].target] = chains[lp[k].target] || []).push(k); });
        /* 0.2.72 (live BB 13:41-13:51Z: every blocker of step 01 was left out while recovering, and MOUTH went alone through
           the watch of 1.2 — caught three times): an attacker whose way a camp watches that no blocker in the layer takes is
           not sent */
        att.forEach(function (k) { var w = ic[k] && ic[k].watch; if (!w) return; Object.keys(w).forEach(function (b) {
            if (String(b) === String(lp[k].target) || chains[b] || (opt.alive && !opt.alive(b))) return;
            bad.push(nm(k) + " crosses the watch of " + b + " and no blocker in the layer takes " + b); }); });

        Object.keys(chains).forEach(function (b) { chains[b].sort(function (x, y) { return Number(lp[y].blockMs || 3000) - Number(lp[x].blockMs || 3000) || (lp[x].order || 0) - (lp[y].order || 0); }); });
        function passes(b) {   // [enter, end] of every general (attacker or active blocker) whose path the camp b watches
            var out = [];
            keys.forEach(function (k) { if (send[k] == null || (lp[k].block && String(lp[k].target) === String(b))) return; var w = ic[k] && ic[k].watch && ic[k].watch[b]; if (!w) return;
                var end = send[k] + (w[1] + 1) * SS, steps = ic[k].steps || (ic[k].len ? Math.round(ic[k].len / 10000) : 0);
                if (!lp[k].block && !lp[k].queue && tr(k) && (lp[k].fightMs || (steps && w[1] >= steps - 3))) end = Math.max(end, send[k] + trSlow(k) + Number(lp[k].fightMs || 0));
                out.push({ k: k, enter: send[k] + w[0] * SF, end: end }); });
            return out;
        }
        for (var pass = 0; pass < 3; pass++) Object.keys(chains).forEach(function (b) {
            var ps = passes(b); if (!ps.length) { chains[b].forEach(function (k) { delete send[k]; }); used[b] = 0; return; }
            var first = Math.min.apply(null, ps.map(function (p) { return p.enter; })), last = Math.max.apply(null, ps.map(function (p) { return p.end; }));
            var from = first - margin, need = last + margin - from, sum = 0, n = 0;
            chains[b].forEach(function (k) { delete send[k]; });
            /* 0.2.68: the cheap chain first — only 1-unit blocks; a long (costly) block only when they fall short */
            var units = function (k) { var a = lp[k].army || {}, t = 0; Object.keys(a).forEach(function (u) { t += Number(a[u]) || 0; }); return t; };
            /* 0.2.73 (ADR 0066 plan v4, author: "elk block dat met een normaal blok gedaan kan worden, waarbij het hoofdkamp
               verslagen wordt voordat dat block is afgelopen heeft de voorkeur. Alleen daar waar dat niet kan, gebruik je
               1R"): a normal block (keep: true) is the tail of the chain — fighting when the leader falls, so the camp goes
               with the leader and the blocker comes home whole, without recovery; 1R blocks only before it. When the 1R
               head cannot bring it there in time, the chain is 1R to the end (keeps stay home). */
            var keeps = chains[b].filter(function (k) { return lp[k].keep; }).sort(function (x, y) { return Number(lp[y].blockMs || 0) - Number(lp[x].blockMs || 0) || units(x) - units(y); });
            if (keeps.length) {
                var K = keeps[0], bmK = Number(lp[K].blockMs || 0), F = fallAt != null ? fallAt : last, E = Math.max(last, F) + margin;
                var heads = chains[b].filter(function (k) { return !lp[k].keep && units(k) <= 1; }), need1 = Math.max(0, E - bmK - from), raw1 = 0, sum1 = 0, n1 = 0;
                while (n1 < heads.length && sum1 < need1) { var h = heads[n1], bh = Number(lp[h].blockMs || 3000); send[h] = from + (n1 ? raw1 - 2000 : 0) - tr(h); raw1 += bh; sum1 += bh - (n1 ? JOIN : 0); n1++; }
                var startK = from + sum1;
                if (sum1 >= need1 && startK <= F - margin && startK + bmK - (n1 ? JOIN : 0) >= E) {
                    send[K] = from + (n1 ? raw1 - 2000 : 0) - tr(K);
                    used[b] = { n: n1 + 1, from: from, until: startK + bmK - (n1 ? JOIN : 0), need: need, slack: Math.round((startK + bmK - last) / 100) / 10, keep: K, keepFrom: startK, fall: F }; return; }
                heads.forEach(function (k) { delete send[k]; });
            }
            var cheap = chains[b].filter(function (k) { return units(k) <= 1 && !lp[k].keep; }), cs = 0; cheap.forEach(function (k, i) { cs += Number(lp[k].blockMs || 3000) - (i ? JOIN : 0); });
            var list = cs >= need || keeps.length ? cheap : chains[b];   // 0.2.73: with normal blocks on hand, a chain without one at its tail is 1R only
            var raw = 0; while (n < list.length && sum < need) { var k = list[n], bm = Number(lp[k].blockMs || 3000); send[k] = from + (n ? raw - 2000 : 0) - tr(k); raw += bm; sum += bm - (n ? JOIN : 0); n++; }   // 0.2.66: a horseshoe does not shorten the fight rounds (measured; 0.2.57 reverted)   // a next block arrives 2 s before the one ahead ends and queues; each junction counts 1 s lost
            used[b] = { n: n, from: from, until: from + sum, need: need, slack: Math.round((from + sum - last) / 100) / 10 };
        });
        /* 0.2.74 (blocks v4: 50 new spots): a blocker that is sent and whose own way a live camp other than its target
           watches, with no chain on that camp, would be caught there and leave its own camp unblocked */
        keys.forEach(function (k) { if (!lp[k].block || send[k] == null || Number(lp[k].via) > 0) return; var w = ic[k] && ic[k].watch; if (!w) return;
            Object.keys(w).forEach(function (b) { if (String(b) === String(lp[k].target) || chains[b] || (opt.alive && !opt.alive(b))) return;
                bad.push(nm(k) + " (block on " + lp[k].target + ") crosses the watch of " + b + " and no blocker in the layer takes " + b); }); });
        Object.keys(used).forEach(function (b) { var u = used[b]; if (!u) return;
            passes(b).forEach(function (p) { if (p.enter < u.from + margin - 1 || p.end > u.until - margin + 1) bad.push(nm(p.k) + " misses the block window of " + b + " by " + Math.round(Math.max(u.from + margin - p.enter, p.end - (u.until - margin)) / 1000) + " s"); });
            if (u.until - u.from < u.need) bad.push("the block chain on " + b + " is " + Math.round((u.need - (u.until - u.from)) / 1000) + " s too short (" + u.n + " blocks, margin " + Math.round(margin / 1000) + " s) — a longer block closes it (blockms.js --pick)"); });
        var order = Object.keys(send).sort(function (a, b) { return send[a] - send[b] || (lp[a].block ? 0 : 1) - (lp[b].block ? 0 : 1); });
        var t0 = order.length ? send[order[0]] : 0; order.forEach(function (k) { send[k] -= t0; });
        var span = order.length ? send[order[order.length - 1]] : 0, still = 0; order.forEach(function (k) { still = Math.max(still, send[k] + 2 * tr(k)); });
        return { order: order, send: send, bad: bad, span: span, still: still, chains: used };
    }

    /* ---------------- the run: a state machine ticked every 2 s ---------------- */
    /* 0.2.81: stow before closing — pure plan: which general gets which loose units (its own army kept, up to its cap) */
    function stowPlan(loose, gens) {
        var left = {}, u, out = [];
        for (u in (loose || {})) if (loose.hasOwnProperty(u) && Number(loose[u]) > 0) left[u] = Number(loose[u]);
        var units = Object.keys(left).sort(function (a, b) { return left[b] - left[a] || (a < b ? -1 : 1); });
        function held(gn) { var k, n = 0; for (k in (gn.army || {})) if (gn.army.hasOwnProperty(k) && Number(gn.army[k]) > 0) n += 1; return n; }
        (gens || []).filter(function (gn) { return gn && gn.onMap && gn.idle && gn.cap > 0; })
            .sort(function (a, b) { return (held(a) ? 0 : 1) - (held(b) ? 0 : 1) || b.cap - a.cap || (a.key < b.key ? -1 : 1); })   // 0.2.82: loaded generals first (own types), then the empty ones
            .forEach(function (gn) {
                var army = {}, have = 0, k, add = 0;
                for (k in (gn.army || {})) if (gn.army.hasOwnProperty(k) && Number(gn.army[k]) > 0) { army[k] = Number(gn.army[k]); have += army[k]; }   // 0.2.82: no zero amounts
                var space = gn.cap - have, empty = have === 0;
                units.forEach(function (x) {
                    if (space <= 0 || !(left[x] > 0)) return;
                    if (!empty && !(army[x] > 0)) return;   // 0.2.82: E:1008 — a loaded general takes only the types it holds
                    var n = Math.min(space, left[x]); army[x] = (army[x] || 0) + n; left[x] -= n; space -= n; add += n;
                });
                if (add > 0) out.push({ key: gn.key, army: army, added: add });
            });
        var rest = 0; for (u in left) if (left.hasOwnProperty(u)) rest += left[u];
        return { raises: out, left: rest };
    }
    /* 0.2.88 (F16a, live BB 2026-11-17 15:10Z: wave 2 stopped with GHOST6 89 MountedMarksman short while SYL3 held 40 and
       CLOAKED 66 more than wave 2 gave them — the load check counts a general holding more than its packet as matching, so the
       surplus never came loose): pure plan — which idle generals on the map give back how many of each unit the load is short
       of. Generals of this round give back what they hold above their packet, others what they hold; only the short types
       are reduced (no new type, no zero amount — rule 0.2.82). Returns { raises: [{key, army, freed}], left: {unit: n} }. */
    function shedPlan(needs, packet, gens) {
        var left = {}, u, out = {}, order = [];
        for (u in (needs || {})) if (needs.hasOwnProperty(u) && Number(needs[u]) > 0) left[u] = Number(needs[u]);
        var inP = function (k) { return !!(packet && packet[k] && packet[k].army); };
        (gens || []).filter(function (gn) { return gn && gn.onMap && gn.idle; })
            .sort(function (a, b) { return (inP(a.key) ? 0 : 1) - (inP(b.key) ? 0 : 1) || (a.key < b.key ? -1 : 1); })
            .forEach(function (gn) {
                Object.keys(left).forEach(function (x) {
                    if (!(left[x] > 0)) return;
                    var have = Number((gn.army || {})[x]) || 0, keep = inP(gn.key) ? (Number(packet[gn.key].army[x]) || 0) : 0, spare = have - keep;
                    if (spare <= 0) return;
                    var n = Math.min(spare, left[x]);
                    if (!out[gn.key]) { out[gn.key] = { key: gn.key, army: JSON.parse(JSON.stringify(gn.army || {})), freed: 0 }; order.push(gn.key); }
                    out[gn.key].army[x] -= n; if (!(out[gn.key].army[x] > 0)) delete out[gn.key].army[x]; out[gn.key].freed += n; left[x] -= n;
                });
            });
        var rest = {}; Object.keys(left).forEach(function (x) { if (left[x] > 0) rest[x] = left[x]; });
        return { raises: order.map(function (k) { return out[k]; }), left: rest };
    }
    /* 0.2.92 (ADR 0082, author 2026-11-18): the five phases of every adventure, and which states of the run belong to each */
    var PHASES = ["", "1 prepare at home", "2 start and send", "3 landing to the first attack", "4 attack", "5 load troops and close"];
    function phaseOf(state, round) {
        if (state === "PRECHECK") return 1;
        if (state === "START" || state === "LOAD" || state === "SEND" || state === "TRAVEL" || state === "RECALL") return 2;
        if ((state === "LOADR" || state === "MOVE") && round <= 1) return 3;
        if (state === "FINISH" || state === "QUESTS" || state === "DONE") return 5;
        if (state === "STOPPED") return 0;
        return 4;
    }
    /* 0.2.89: carriers — generals of the load template (packets[0]) with an army that are in no later round */
    function carrierIds(packets) {
        var load = (packets || [])[0] || {}, inRound = {};
        (packets || []).slice(1).forEach(function (p) { Object.keys(p || {}).forEach(function (k) { inRound[k] = true; }); });
        return Object.keys(load).filter(function (k) { var e = load[k]; return e && e.type !== "buff" && e.type !== "speedbuff" && !inRound[k] && Object.keys(e.army || {}).some(function (u) { return Number(e.army[u]) > 0; }); });
    }
    /* raise the plan's armies; returns how many raises went out (0 when the gateway cannot, or nothing is loose) */
    function stowLoose(G, say) {
        if (typeof G.looseTroops !== "function" || typeof G.mapGenerals !== "function" || typeof G.raise !== "function") return 0;
        var loose = G.looseTroops(), plan = stowPlan(loose, G.mapGenerals()), n = 0;
        plan.raises.forEach(function (r) { if (G.raise(r.key, r.army, n)) n += 1; });
        var total = 0, u; for (u in loose) if (loose.hasOwnProperty(u)) total += loose[u];
        if (total > 0) say("stow before closing: " + (total - plan.left) + " of " + total + " loose troops into " + n + " general(s)" + (plan.left ? ", " + plan.left + " stay loose (no fitting general or capacity)" : ""));   // 0.2.82
        return n;
    }

    function createRun(opts, G) {
        G = G || gameGateway();
        var FIGHTING = ["LOADR", "MOVE", "ATTACK", "CAMP", "CAMPS", "FIGHT", "FIX"];   // 0.2.166 r2: a repair under way may have generals fighting   // 0.2.30: states after which a resume may find generals fighting
        var run = { prevState: opts.prevState || null, resumeOnly: !!opts.resumeOnly, id: opts.id, res: opts.res || RES[opts.id], packets: opts.packets, names: opts.names, rules: opts.rules || {}, doneZones: opts.doneZones || [],
                    state: (opts.start && opts.start.state) || "PRECHECK", since: G.now(), round: (opts.start && opts.start.round) || 0, zone: (opts.start && opts.start.zone != null) ? opts.start.zone : null, tries: 0, pass: 0, reason: "", log: [], startedAt: G.now(), stopped: false };
        function say(m) { var line = new Date(G.now()).toISOString().slice(11, 19) + " " + m; run.log.push(line); if (run.log.length > 60) run.log.shift(); G.log(m);
            if (!(run.pubAt > 0) || G.now() - run.pubAt >= 10000) publish(); }   // 0.2.88 (F10): the status follows the log, at most every 10 s
        function go(s, m) { run.state = s; run.since = G.now(); run.lastAt = 0; run.tries = 0; run.pass = 0; run.quietAt = 0;
            var ph = phaseOf(s, run.round); if (ph && ph !== run.phase) { run.phases = run.phases || []; var pv = run.phases[run.phases.length - 1]; if (pv && !pv.to) pv.to = new Date(G.now()).toISOString();
                run.phase = ph; run.phases.push({ phase: ph, name: PHASES[ph], from: new Date(G.now()).toISOString() }); say("phase " + PHASES[ph]); }   // 0.2.92 (ADR 0082)
            if (m) say(m); publish(); }
        function gap(ms) { return !run.lastAt || G.now() - run.lastAt >= ms; }   // 0.1.5: time since the last attempt in this state
        function stop(reason) {
            if (run.state !== "STOPPED" && selfRepair(String(reason))) return;   // 0.2.166 (ADR 0102): repair first (from FIX too: a failed repair takes the next step)
            if (run.fix && run.fix.log && run.fix.log.length) reason = reason + " — not kept after " + run.fix.log.length + " self-repairs (" + run.fix.log.join(" | ") + ")";
            run.reason = reason; run.stopped = true; go("STOPPED", "stopped: " + reason); }
        /* 0.2.166 (ADR 0102): what is not ours to repair, or truly cannot be kept */
        var KEEP_STOP = [/stopped by the player/, /not allowed blocks/, /rule keeps/, / in the star$/, /star item was refused/, /did not open within/,
            /not on the home island/, /nothing to resume/, /a version without blocks has block entries/, /is still open/, /no camps to destroy known/,
            /loot spots could not be offered/, /the game marks the adventure lost/, /the plan is not played out of its order/];
        var LADDER = [{ wait: 0, emergency: false, what: "look again: refresh and play the step again from what still stands" },
                      { wait: 0, emergency: true, what: "refresh and play the step again camp by camp" },
                      { wait: 600000, emergency: true, what: "wait 10 minutes (recovery, training, the view), then camp by camp again" },
                      { wait: 1800000, emergency: true, what: "wait 30 minutes, then camp by camp again" }];
        var PLAY = ["LOADR", "MOVE", "ATTACK", "CAMP", "CAMPS", "FIGHT"];
        function selfRepair(reason) {
            if (!run.rules || run.rules.selfRepair !== true || run.fixOff) return false;
            if (KEEP_STOP.some(function (re) { return re.test(reason); })) return false;
            try { if (run.zone != null && G.advStatus && G.advStatus(run.zone) === 3) return false; } catch (_) {}   // lost: the promise cannot be kept
            if (!run.fix || run.fix.round !== run.round) run.fix = { round: run.round, n: 0, log: [] };
            if (run.fix.n >= LADDER.length) return false;
            var from = run.state === "FIX" && run.fix.step ? run.fix.step.from : run.state;
            if (run.zone == null || from === "PRECHECK" || from === "START") return false;   // 0.2.166 r2 (tester): before the adventure is open a retry could use a second item
            var st = LADDER[run.fix.n]; run.fix.n += 1; run.fix.log.push(reason);
            var play = PLAY.indexOf(from) >= 0 && run.round >= 1 && run.round < (run.packets || []).length;
            var pkE = (run.packets || [])[run.round] || {}, canCbc = !run.rules.asIs && !blockIds(pkE).length;   // 0.2.166 r2 (tester): "as it is" and block templates keep their own timing
            run.fix.step = { n: run.fix.n, of: LADDER.length, reason: reason, what: st.emergency && !canCbc ? "refresh and play the step again (as the template has it)" + (st.wait ? " after " + Math.round(st.wait / 60000) + " minutes" : "") : st.what, from: from, play: play, emergency: st.emergency && play && canCbc, until: G.now() + st.wait, refAt: 0 };
            say("solving it myself (" + run.fix.n + "/" + LADDER.length + "): " + reason + " — " + st.what + (st.wait ? " (until " + new Date(G.now() + st.wait).toISOString().slice(11, 16) + " UTC)" : ""));
            go("FIX");
            return true;
        }
        if (opts.prevFix && opts.prevFix.n > 0) run.fix = { round: Number(opts.prevFix.round) || 0, n: Number(opts.prevFix.n), log: ["before a restart: " + String(opts.prevFix.reason || "")] };   // 0.2.166 r2 (tester): the ladder count survives a restart
        if (opts.emergency) run.emergency = true;   // 0.2.84 (ADR 0079)
        function late(ms) { return G.now() - run.since > ms; }
        /* 0.2.90 (author 2026-11-18: measure what is really lost and feed it back): the troops on the island — in our generals
           and loose — before every round and before closing, so the book holds the real losses per wave next to the plan */
        function troopCount(label) {
            if (typeof G.mapGenerals !== "function") return; run.troopAt = run.round;
            var t = {}, per = {}, add = function (a) { Object.keys(a || {}).forEach(function (u) { var n = Number(a[u]) || 0; if (n > 0) t[u] = (t[u] || 0) + n; }); };
            try { G.mapGenerals().forEach(function (m) { add(m.army); var a = {}; Object.keys(m.army || {}).forEach(function (u) { if (Number(m.army[u]) > 0) a[u] = Number(m.army[u]); }); per[m.key] = a; }); if (typeof G.looseTroops === "function") add(G.looseTroops()); } catch (_) { return; }
            /* 0.2.93 (author 2026-11-18: "Hoe kan het dat er nog steeds MM en MS verliezen zijn?"): every general's army too, so a
               loss per wave can be put on the general — and on the camp it attacked — instead of only on the island total */
            run.troopLog = run.troopLog || []; run.troopLog.push({ at: new Date(G.now()).toISOString(), label: label, round: run.round, troops: t, generals: per });
            say("troops on the island " + label + ": " + Object.keys(t).map(function (u) { return t[u] + " " + u; }).join(", "));
        }
        function publish() { run.pubAt = G.now(); G.status({ version: VERSION, adventure: run.id, phase: run.phase || phaseOf(run.state, run.round), phaseName: PHASES[run.phase || phaseOf(run.state, run.round)] || "", state: run.state, round: run.round, of: run.packets.length - 1, template: run.names[run.round] || "", zone: run.zone, reason: run.reason, fix: run.fix && run.fix.step && run.fix.round === run.round ? { step: run.fix.step.n, of: run.fix.step.of, reason: run.fix.step.reason, what: run.fix.step.what, until: new Date(run.fix.step.until).toISOString(), active: run.state === "FIX" } : null,   /* 0.2.166 r3 (tester): the count stays in the status while the step is played again */ since: new Date(run.since).toISOString(), log: run.log.slice(-15) }); }
        var load = run.packets[0];
        /* 0.2.7: the attack queue is spread (Mundane "time" per general); until it is through a restart would cut it */
        /* 0.2.164 (ADR 0101 rule 1, tester r2): did the game take the attack of general k? An attack task (G.tasks); a task
           that was not there when the order went out and is no Move (a Recover after a fight that ended between two ticks);
           or fewer units than at the send. A task the general already had at the send — its Move onto its spot, a Recover
           from an earlier fight — proves nothing. */
        function heldTo(pk, k) { var o = []; Object.keys(pk || {}).forEach(function (x) { if (x !== k && pk[x] && pk[x].walkTo > 0) o.push(Number(pk[x].walkTo)); }); return o; }   // 0.2.165 (tester): a spot a general walks on to is taken
        function near(a, b) { var d = G.dist ? G.dist(Number(a), Number(b)) : null; return d == null || d <= 6; }   // 0.2.165: "close to its spot"; an unknown distance blocks nothing (the behaviour before 0.2.165)
        function onOwnSpot(k, pk) { var e = pk && pk[k]; if (!e || !(e.grid > 0) || !G.mapGenerals) return false; var on = false; G.mapGenerals().forEach(function (m) { if (m.key === k && Number(m.grid) === Number(e.grid)) on = true; }); return on; }
        function noteSend(st, keys) {
            st.t0 = st.t0 || {}; st.u0 = st.u0 || {};
            var at = G.anyTask ? G.anyTask(keys) : {}, un = G.units ? G.units(keys) : {};
            keys.forEach(function (k) { st.t0[k] = at[k] || ""; if (un[k] != null) st.u0[k] = un[k]; else delete st.u0[k]; });
        }
        /* 0.2.178: a task the game view keeps showing past its end after STALE_REFRESHES refreshes is taken as ended - said once per general -
       so the camp-by-camp step goes on (the camp still stands: the next attacker; it fell: the next camp) instead of refreshing forever */
    var STALE_REFRESHES = 3;
    /* 0.2.183 (review r5): an attack task the view showed on a camp other than the general's own (and its via) is remembered - the game
       took the order and the general was intercepted there - so a later tick without a task does not read as "got no task" */
    function noteIntercept(cx, ks, tasks, pk) {
        cx.icamp = cx.icamp || {};
        ks.forEach(function (k) { var t = tasks[k], e = pk[k]; if (!t || t.target == null || !e || !(e.target > 0)) return;
            if (Number(t.target) !== Number(e.target) && !(Number(e.via) > 0 && Number(t.target) === Number(e.via))) cx.icamp[k] = Number(t.target); });
    }
    function staleEnded(cx, stale, tasks, still) {   // returns the generals newly taken as ended
        var fresh = [];
        stale.forEach(function (k) {
            if (still.indexOf(k) >= 0) return;
            delete tasks[k];
            cx.staleSaid = cx.staleSaid || {};
            if (!cx.staleSaid[k]) { cx.staleSaid[k] = 1; fresh.push(k); }
        });
        return fresh;
    }
    function tookAttack(st, k, tc, at, un, e) {   // e: the general's entry in the packet — its own camp (and via camp)
            if (e && (e.type === "buff" || e.type === "speedbuff")) return true;   // 0.2.172: an arrow has no task - once sent it is never "an attacker the game did not take" (camp by camp too)
            if (tc[k]) { var tt = tc[k].target; if (tt == null || !e || !(e.target > 0)) return true;
                if (Number(tt) === Number(e.target) || (Number(e.via) > 0 && Number(tt) === Number(e.via))) return true;   // architect F3: an attack on another camp is no proof
                return false; }   // 0.2.181 (review r3 CR-C1): a task on another camp is no proof either way - no fall-through to "any task" or losses
            var a = at[k], a0 = (st.t0 || {})[k];
            if (a && !/Move/i.test(a) && a !== a0) return true;
            var u0 = (st.u0 || {})[k];
            return u0 != null && un[k] != null && un[k] < u0;
        }
        /* 0.2.164 (ADR 0101 rule 2, tester r2): per attacker of a send outside CAMP/CAMPS (layers, the last layer, one-layer
           steps, "as it is"): an attacker whose order the game never took is sent again alone every 30 s, up to 8 minutes;
           while one is untaken nothing is judged. An attacker whose camp already fell is not needed. */
        function noteFight(keys) {
            if (!run.cf || run.cf.round !== run.round) run.cf = { round: run.round, sent: {}, tries: {}, seen: {}, first: {} };
            noteSend(run.cf, keys); keys.forEach(function (k) { run.cf.sent[k] = G.now(); if (!run.cf.first[k]) run.cf.first[k] = G.now(); run.cf.tries[k] = (run.cf.tries[k] || 0) + 1; });
            noteArrows(keys);
        }
        /* 0.2.172 (live FT 2026-11-26: both destroy arrows of an as-written step were "sent again, try 2 / try 3" as if they were
           generals without a task, 3 s after Mundane's queue had put them on their camp; author: "wasting arrows is a defect"):
           AN ARROW HAS NO TASK. It is judged by its camp falling, and by the star: what the star held of it before the send and
           what it holds after. Per arrow of a send: its camp, when Mundane's queue puts it there (the delays before it in the
           plan's order), and the star's count before. arrowsJudged():
             - the camp fell: done;
             - until ARROW_FLIGHT_MS after it was put on the camp: in flight, nothing is judged and nothing is sent;
             - the camp stands and the star shows the arrow was NOT used (the count explained by the camps that fell): it is put
               on the camp once more, by the game gateway's own applyArrow - at most ARROW_SENDS times per camp;
             - the camp stands and the arrow WAS used, or the star cannot be read, or the count does not say which arrow was
               used: it is never sent again; the log says so and a replay of the step leaves the arrow out (run.arrowSpent). */
        function starOf(def) { var st = null; try { st = G.starRead ? G.starRead() : null; } catch (_) { st = null; } return st == null ? null : (Number(st[def]) || 0); }
        function noteArrows(keys) {
            var pk = run.packets[run.round] || {}, cf = run.cf, ord = sendOrder(pk).filter(function (k) { return keys.indexOf(k) >= 0; }), t = 0;
            cf.arrow = cf.arrow || {}; cf.star0 = cf.star0 || {}; cf.asked = cf.asked || {};
            ord.forEach(function (k, i) { var e = pk[k]; if (i > 0) t += Number(e && e.time) || 0;
                if (!e || e.type !== "buff" || !(Number(e.target) > 0) || !G.campAlive(Number(e.target))) return;
                var def = String(e.name);
                if (!(def in cf.star0)) cf.star0[def] = starOf(def);
                cf.asked[def] = (cf.asked[def] || 0) + 1;
                var a = cf.arrow[k] || (cf.arrow[k] = { def: def, camp: Number(e.target), sends: 0 });
                a.sends += 1; a.due = G.now() + t; a.done = null; });
        }
        function arrowsJudged() {   // returns true while an arrow is in flight
            var cf = run.cf, pk = run.packets[run.round] || {}, ar = (cf && cf.arrow) || {}, flying = false, nm = run.names[run.round];
            Object.keys(ar).forEach(function (k) { var a = ar[k]; if (a.done) return;
                if (!G.campAlive(a.camp)) { a.done = "fell"; say(nm + ": camp " + a.camp + " fell (arrow " + a.def + ")"); return; }
                if (G.now() < a.due + ARROW_FLIGHT_MS) { flying = true; return; }
                var now = starOf(a.def), was = cf.star0[a.def], same = Object.keys(ar).filter(function (x) { return ar[x].def === a.def; });
                var fell = same.filter(function (x) { return !G.campAlive(ar[x].camp); }).length, stand = same.filter(function (x) { return G.campAlive(ar[x].camp) && !ar[x].done; }).length;
                var spent = function (why) { a.done = "spent"; run.arrowSpent = run.arrowSpent || {}; run.arrowSpent[a.camp] = a.def; say(nm + ": arrow " + a.def + " on camp " + a.camp + ": " + why + " - not sent again"); };
                if (now == null || was == null) return spent("the camp still stands and the star cannot be read, so it is not known whether the arrow was used");
                var used = was - now, unexplained = used - fell;
                if (unexplained >= stand) return spent("the camp still stands and the arrow was used (star " + was + " -> " + now + "; this arrow does not take this camp?)");
                if (unexplained > 0) return spent("the camp still stands and the star (" + was + " -> " + now + ", " + fell + " camp(s) fell) does not say which arrow was used");
                if (a.sends >= ARROW_SENDS) return spent("the camp still stands after " + a.sends + " sends that the star does not show as used (" + was + " -> " + now + ")");
                var r = G.applyArrow ? G.applyArrow(a.def, a.camp) : { ok: false, reason: "no gateway for an arrow" };
                if (r && r.ok === false && r.retry) { flying = true; return; }   // the adapter holds the send for a moment: tried again at the next tick
                if (!r || r.ok === false) return spent("it was not used (star " + was + " -> " + now + ") and could not be put on the camp again: " + ((r && r.reason) || "no answer"));
                a.sends += 1; a.due = G.now(); cf.asked[a.def] = (cf.asked[a.def] || 0) + 1; flying = true;
                say(nm + ": arrow " + a.def + " on camp " + a.camp + " was not used (star " + was + " -> " + now + ", the camp stands " + Math.round(ARROW_FLIGHT_MS / 1000) + " s after its place in the plan): put on the camp once more (" + a.sends + " of " + ARROW_SENDS + ")"); });
            return flying;
        }
        function untakenFight() {   // returns undefined (all taken), "wait", or "stopped"
            var cf = run.cf, pk = run.packets[run.round] || {};
            if (!cf || cf.round !== run.round) return;
            if (!G.tasks) return arrowsJudgedIdle();   // without the game's tasks no general can be confirmed; an arrow is judged by its camp and the star
            /* 0.2.169 (B13, live FT 2026-11-26 05:40Z: played as written, GHOST2 leaves 50 s after the first by the template's own delay;
               it was taken for "no task" after 30 s and the self-repair replayed the step): while the send queue still sends, nothing is judged */
            if (run.queueUntil && G.now() < run.queueUntil) return "wait";
            try { var aqs = G.attackQueue ? G.attackQueue() : null; if (aqs && aqs.sending) return "wait"; } catch (_) {}
            var flying = arrowsJudged();   // 0.2.172: an arrow has no task - it is judged by its camp and the star, never sent again as a general
            var ks = Object.keys(cf.sent).filter(function (k) { return pk[k] && pk[k].type !== "buff" && pk[k].type !== "speedbuff" && pk[k].target > 0 && G.campAlive(Number(pk[k].target)); });
            var tc = G.tasks ? G.tasks(ks) : {}, at = G.anyTask ? G.anyTask(ks) : {}, un = G.units ? G.units(ks) : {};
            ks.forEach(function (k) { if (tookAttack(cf, k, tc, at, un, pk[k])) cf.seen[k] = 1; });
            /* 0.2.182 (review r4: CR-C1/CR-B4/CR-B3/CR-E3): the question here is whether the game took the order at all. A general with an
               attack task in the view - on any camp, an interception included - has it; it is not "untaken" and never sent again (as CAMP
               and CAMPS already leave out a general with a task) */
            noteIntercept(cf, ks, tc, pk);
            ks.forEach(function (k) { if (tc[k]) cf.seen[k] = 1; });   // 0.2.183 (review r5 CR-C1): the order was taken - remembered, as 0.2.177 had it
            var un9 = ks.filter(function (k) { return !cf.seen[k]; });
            if (!un9.length) return flying ? "wait" : undefined;
            var k = un9[0], nm = String(pk[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0];
            if (G.now() - cf.sent[k] < 30000) return "wait";
            if ((cf.tries[k] || 1) >= 16) { stop(run.names[run.round] + ": the game took no attack of " + nm + " on camp " + pk[k].target + " in 8 minutes (" + cf.tries[k] + " tries)"); return "stopped"; }   // architect F2: 16 tries, as CAMP/CAMPS
            var one = {}; one[k] = JSON.parse(JSON.stringify(pk[k])); one[k].time = 1000; one[k].order = 0;
            /* tester r3: sent alone, it no longer has the template's timing or its blocks — its path may cross no live camp
               other than its own (as CAMP/CAMPS check before a send) */
            if (G.intercepts) { var ic = G.intercepts(one)[k], hit = ic ? (ic.by || []).filter(function (c) { return Number(c) !== Number(pk[k].target) && G.campAlive(c); }) : [];
                if (hit.length) { stop(run.names[run.round] + ": " + nm + " got no task for camp " + pk[k].target + " and is not sent again alone — live camp(s) " + hit.join(",") + " watch its way; block them or attack them first"); return "stopped"; } }   // architect F1: a stop ends the tick
            noteFight([k]); var r = G.attack(one);
            say(run.names[run.round] + ": " + nm + " got no task for camp " + pk[k].target + " (just placed from the star?): sent again, try " + cf.tries[k] + (r && r.queued === 0 ? " — " + (r.left || []).join("; ") : ""));
            return "wait";
        }
        function arrowsJudgedIdle() { try { var aq0 = G.attackQueue ? G.attackQueue() : null; if (aq0 && aq0.sending) return "wait"; } catch (_) {} if (run.queueUntil && G.now() < run.queueUntil) return "wait"; return arrowsJudged() ? "wait" : undefined; }
        function sendLayer(pa) {   // 0.2.47: send the generals of layer run.lay.i; log when the island should stand still again
            var cam = run.lay.plan[run.lay.i], lp = layerPacket(pa, cam, run.lay.ic, run.lay.i === 0);
            var sp = planSends(lp, run.lay.ic, { marginMs: Number((run.rules && run.rules.blockMarginSec) || 5) * 1000, speed: run.speed || 0, alive: function (b) { return G.campAlive(Number(b)); } }), bad = sp.bad, ks = sp.order, t = sp.span, still = sp.still;   // 0.2.51 (ADR 0066)
            ks.forEach(function (k, n) { lp[k] = JSON.parse(JSON.stringify(lp[k])); lp[k].time = n === 0 ? 1000 : Math.round(sp.send[k] - sp.send[ks[n - 1]]); });
            Object.keys(lp).forEach(function (k) { if (ks.indexOf(k) < 0) delete lp[k]; });   // blocks the chain does not need stay home
            /* 0.2.70: chains short only because blockers are still recovering — wait for them (at most 3 h) instead of stopping */
            if (bad.length && run.recB > 0 && bad.every(function (b) { return /too short|misses the block window|no blocker in the layer/.test(b); })) {
                run.waitRecSince = run.waitRecSince || G.now();
                if (G.now() - run.waitRecSince < 4.5 * 3600000) {   // 0.2.73: a 1R block recovers 4 h (measured); v4 reuses step-01/02 1R generals in steps 04-06 run.lay = null; run.resumed = false; run.packets[run.round] = run.orig && run.orig[run.round] || run.packets[run.round];
                    return go("LOADR", run.names[run.round] + ": chains short while " + run.recB + " blockers recover — waiting for them"); } }
            run.waitRecSince = 0;
            /* 0.2.76: a test layer (any general with test: true) is sent although a chain is short — the run measures where the
               game catches the passers; the guards (retreat on interception) stay on */
            if (bad.length && Object.keys(lp).some(function (k) { return lp[k] && lp[k].test; })) {
                var tb = bad.filter(function (b) { return /too short|misses the block window/.test(b); });
                if (tb.length === bad.length) { say(run.names[run.round] + ": TEST layer sent although: " + bad.join("; ")); bad = []; } }
            if (bad.length) return stop(run.names[run.round] + ": layer " + (run.lay.i + 1) + " not sent: " + bad.join("; "));
            var lo = {}; ks.forEach(function (k, n) { lo[k] = lp[k]; lo[k].order = n; }); lp = lo;   // 0.2.49: the send order is the timed order
            run.lay.sentAt = G.now(); run.lay.sendMs = t; run.lay.stillAt = run.lay.sentAt + still + 60000; run.lay.refreshAt = 0;
            Object.keys(sp.chains || {}).forEach(function (b) { var u = sp.chains[b]; if (u) say(run.names[run.round] + ": block on " + b + ": " + u.n + " blocks, " + Math.round((u.until - u.from) / 1000) + " s, slack " + u.slack + " s after the last passer" + (u.keep ? "; normal block " + String(lp[u.keep].name || u.keep).replace(/<[^>]*>/g, "").split(" ")[0] + " from " + Math.round((u.keepFrom - u.from) / 1000) + " s, leader falls at " + Math.round((u.fall - u.from) / 1000) + " s" : "")); });   // 0.2.54
            say(run.names[run.round] + ": layer " + (run.lay.i + 1) + "/" + run.lay.plan.length + ": " + ks.length + " generals on " + cam.join(",") + (still ? ", still by about " + new Date(run.lay.stillAt).toISOString().slice(11, 19) : ""));
            /* 0.2.67 (author: "maak een goede mundane ervan"): every layer that goes out is also written as a Mundane template —
               the generals in send order, "time" the delay before each — to dma-mundane\<adventure>\<step> layer <n>, so a
               played step can be loaded in Mundane as it was sent (a via-block carries its via camp as target) */
            try { var mt = {}; ks.forEach(function (k) { var e = JSON.parse(JSON.stringify(lp[k])); if (e.block && Number(e.via) > 0) e.target = Number(e.via); delete e.block; delete e.blockMs; delete e.via; mt[k] = e; });
                  airFile("dma-mundane/" + run.id + "/" + run.names[run.round] + (run.lay.plan.length > 1 ? " layer " + (run.lay.i + 1) : ""), mt); } catch (_) {}
            noteFight(ks); var aq = G.attack(lp); markQueue(lp); run.only = null; run.sentKeys = (run.sentKeys || []).concat(ks); run.retreated = false;   // 0.2.59
            if (aq && aq.of) { say(run.names[run.round] + ": queued " + aq.queued + " of " + aq.of + (aq.left.length ? " — left out: " + aq.left.join("; ") : ""));   // 0.2.52
                if (!aq.queued) return stop(run.names[run.round] + ": Mundane sent nobody — " + aq.left.join("; ")); }
            return go("FIGHT");
        }
        function part(pk) { if (!run.only) return pk; var o = {}; run.only.forEach(function (k) { if (pk[k]) o[k] = pk[k]; }); return o; }
        function markQueue(pk) { var ms = 0, ks = []; generalIds(pk).forEach(function (k) { if (pk[k].target > 0) { ms += Number(pk[k].time) || 0; ks.push(k); } }); run.queueUntil = G.now() + ms + 15000;
            run.attackQ = { at: G.now(), keys: ks, ms: ms, round: run.round, told: false }; }   // 0.2.102: watched until the last general has left
        /* 0.2.102 (author 2026-11-20: "kijken of je kunt zien wanneer de laatste generaal van een aanval verstuurd is, dat is belangrijke
           informatie omdat je dan weer opdrachten kunt geven"): the attack is sent when the client's send queue (Mundane's
           battleTimedQueue) is empty AND every general of the attack has an attack task in the game. Until then the run gives no other
           order (no pre-staging of the next round); then it says so once, with how long the sending took, and frees the client. If the
           game never shows a task for some general, the run goes on one minute after the queue ended and names them. */
        /* 0.2.114 (live YWC 2026-11-21 03:14Z: the main attack of 20 generals went out and fought, but the line never came — the
           send queue still read "sending" minutes later, so the run waited on it for ever): a general that has shown an attack task
           once has left, whatever the queue says; when every general of the attack has been seen leaving, the attack is sent.
           The queue is only consulted for generals not seen yet, and only until the attack's own sending time plus one minute;
           after that the run goes on and names the queue position it read. */
        function attackSent() {
            var q = run.attackQ; if (!q || q.told) return true;
            q.seen = q.seen || {};
            var tk = {}; try { tk = G.tasks ? G.tasks(q.keys) || {} : {}; } catch (_) { tk = {}; }
            q.keys.forEach(function (k) { if (tk[k]) q.seen[k] = true; });
            var left = q.keys.filter(function (k) { return !q.seen[k]; });
            var qs = null, stuck = "";
            if (left.length) {
                try { qs = G.attackQueue ? G.attackQueue() : null; } catch (_) { qs = null; }
                if (qs && qs.sending) { if (G.now() - q.at < (q.ms || 0) + 60000) return false; stuck = "; the send queue still reads " + qs.index + " of " + qs.len; }
                if (!q.queueEnd) q.queueEnd = G.now();
                if (!stuck && G.now() - q.queueEnd < 60000) return false;
            }
            q.told = true; run.queueUntil = 0;
            say((run.names[q.round] || ("round " + (q.round + 1))) + ": the last general of the attack has left (" + (q.keys.length - left.length) + " of " + q.keys.length + " on their way, " + Math.round((G.now() - q.at) / 1000) + " s after the first)" + (left.length ? "; no attack task seen for " + left.length + ": " + left.join(", ") : "") + stuck + " — free for new orders");
            return true;
        }

        /* 0.2.116 (ADR 0091): the first attack's generals, once idle on the island, are sent home (never while an attack is sent) */
        function aheadHomeStep() {
            var A = run.aheadHome, idle = G.idleOnIsland ? G.idleOnIsland() : [], go2 = A.keys.filter(function (k) { return !A.sent[k] && idle.indexOf(k) >= 0; });
            if (!go2.length || (A.at && G.now() - A.at < 15000)) return;
            A.at = G.now(); go2.forEach(function (k) { A.sent[k] = true; }); G.send(go2, G.homeZone());
            var pk1 = run.packets[1] || {};
            say("first attack done: " + go2.map(function (k) { return String((pk1[k] && pk1[k].name) || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; }).join(", ") + " sent home");
        }
        function tick() {
            if (run.stopped || run.state === "DONE") return run.state;
            if (run.emergencyFix != null && run.round !== run.emergencyFix) { run.emergency = false; run.emergencyFix = null; }   // 0.2.166 r2 (tester): camp by camp only for the repaired step
            /* 0.2.10: the player closed the adventure (Return) while the run was still on it */
            if (["LOADR", "MOVE", "ATTACK", "CAMP", "CAMPS", "FIGHT"].indexOf(run.state) >= 0 && run.zone != null && G.ownAdventure(run.res) !== run.zone) { go("DONE", "the adventure was closed by the player"); return run.state; }
            if (run.zone != null && G.viewedZone() === run.zone && G.campMap && (!run.mapAt || G.now() - run.mapAt > 60000)) { run.mapAt = G.now(); try { learnMap(run.res, G.campMap()); } catch (_) {} try { if (G.landingFields) learnLanding(run.res, G.landingFields(), say); } catch (_) {} }   // 0.2.115: watched
            var sentAll = attackSent();   // 0.2.102
            if (sentAll && run.aheadHome && run.zone != null && G.viewedZone() === run.zone) { try { aheadHomeStep(); } catch (_) {} }   // 0.2.116
            if (sentAll && run.rules.prestage !== false && ["MOVE", "ATTACK", "CAMP", "CAMPS", "FIGHT"].indexOf(run.state) >= 0 && run.zone != null && G.viewedZone() === run.zone) { try { prestage(); } catch (_) {} }   // 0.2.95; 0.2.102: only after the last general of the attack has left
            try { step(); } catch (e) { stop("error in " + run.state + ": " + e); }
            return run.state;
        }
        /* 0.2.95: make the next round ready while this one runs (any adventure, any generals) */
        function prestage() {
            var nx = run.round + 1; if (!run.packets || nx >= run.packets.length || run.emergency) return;
            if (run.preAt && G.now() - run.preAt < 20000) return;
            var cur = run.packets[run.round] || {}, pk = run.packets[nx] || {};
            var mine = Object.keys(pk).filter(function (k) { return pk[k] && pk[k].type !== "buff" && pk[k].type !== "speedbuff" && !(k in cur) && Number(pk[k].grid) > 0; });
            if (!mine.length) return;
            var sub = {}; mine.forEach(function (k) { sub[k] = pk[k]; });
            var ins = G.inspect(sub), taken = {};
            if (typeof G.mapGenerals === "function") G.mapGenerals().forEach(function (m) { if (m.grid > 0) taken[m.grid] = m.key; });
            var place = mine.filter(function (k) { var x = ins.generals[k]; if (!x || !x.idle || !x.star) return false;
                var g = Number(pk[k].grid); if (taken[g] && taken[g] !== k) return false; return !(G.placeable && G.placeable(k, g) === false); });
            var load = mine.filter(function (k) { var x = ins.generals[k]; return x && x.idle && x.onGrid && !x.match; });
            run.preAt = G.now();
            if (place.length) { var mp = {}; place.forEach(function (k) { mp[k] = pk[k]; }); G.move(mp); say(run.names[nx] + ": " + place.length + " generals of the next attack placed from the star"); return; }
            if (load.length && (run.preLoads || 0) < 3) { run.preLoads = (run.preLoads || 0) + 1; var lp = {}; load.forEach(function (k) { lp[k] = pk[k]; }); G.load(lp); say(run.names[nx] + ": " + load.length + " generals of the next attack loaded ahead"); }
        }
        /* 0.2.100 (author 2026-11-20: "alle versnellingen moeten actief zijn voordat het eerste adventure gestart kan worden, dat geldt
           natuurlijk niet als het al loopt" — live, a resumed YWC travelled at normal speed, and on a fresh start the buffs were sent but
           never ran, the star counts stayed the same): the chosen speed-ups are put on once, then the run waits until each one RUNS
           (the zone buff runs, or its star count went down, or the Observatory took the order) before the adventure opens or a general
           leaves. A speed-up that cannot be put on (none in the star, Observatory cooling down) is named and left out; one that was put
           on but does not run is sent once more after 30 s, and after 120 s the run stops: no start without it.
           Returns "ok", "wait" or the reason to stop. */
        /* 0.2.105 (author 2026-11-20: "hoefijzer moet op het adventure geactiveerd worden, niet hier"): a speed-up whose game definition
           targets only the adventure zone (a horseshoe: zone types 4) is not put on at home; it goes on at the adventure, once all
           generals have arrived and before the first round moves out of the star, and is confirmed there (at most 2 minutes; then
           the run goes on and says so — it does not stop on the island). */
        function onAdventure(tb) { if (/^Observatory:/.test(tb)) return false; var z = 0; try { z = G.buffZones ? G.buffZones(tb) : 0; } catch (_) { z = 0; } return z > 0 && (z & 4) !== 0 && (z & 1) === 0; }
        function advBuffsReady() {
            var list = run.advBuffs || []; if (!list.length || run.advBuffDone) return "ok";
            var A = run.advT;
            if (!A) { A = run.advT = { at: G.now(), want: [], before: {} }; try { A.before = G.starBuffs ? G.starBuffs(null) || {} : {}; } catch (_) {} var used = {};
                list.forEach(function (tb) { var gp = G.buffGroup ? G.buffGroup(tb) : null;
                    if (gp != null && used[gp]) { say("adventure: " + tb + " left out — it excludes " + used[gp]); return; }
                    if (G.zoneBuffActive && G.zoneBuffActive(tb)) { say("adventure: " + tb + " already runs"); if (gp != null) used[gp] = tb; return; }
                    var ra = G.applyZoneBuff ? G.applyZoneBuff(tb) : { ok: false, reason: "no gateway" };
                    if (ra.ok) { if (gp != null) used[gp] = tb; A.want.push(tb); }
                    say("adventure: " + tb + (ra.ok ? " put on" : " not put on: " + ra.reason)); });
                run.lastAt = G.now(); if (!A.want.length) { run.advBuffDone = true; return "ok"; } return "wait"; }
            var n0 = {}; try { n0 = G.starBuffs ? G.starBuffs(null) || {} : {}; } catch (_) {}
            var notYet = A.want.filter(function (tb) { return !((G.zoneBuffActive && G.zoneBuffActive(tb)) || (A.before[tb] != null && n0[tb] != null && n0[tb] < A.before[tb])); });
            if (!notYet.length) { run.advBuffDone = true; say("adventure: speed-ups run (" + A.want.join(", ") + ")"); return "ok"; }
            if (!A.resent && G.now() - A.at >= 30000) { A.resent = true; notYet.forEach(function (tb) { if (G.applyZoneBuff) G.applyZoneBuff(tb); }); say("adventure: " + notYet.join(", ") + " does not run yet — put on again"); return "wait"; }
            if (G.now() - A.at >= 120000) { run.advBuffDone = true; say("adventure: " + notYet.join(", ") + " does not run after 2 minutes — the run goes on without it"); return "ok"; }
            return "wait";
        }
        function travelReady() {
            var T = run.travel;
            if (!T) {
                T = run.travel = { at: G.now(), want: [], resent: false, before: {} }; var tUsed = {};
                try { T.before = G.starBuffs ? G.starBuffs(null) || {} : {}; } catch (_) { T.before = {}; }
                run.rules.travel.forEach(function (tb) {
                    if (onAdventure(tb)) { (run.advBuffs = run.advBuffs || []).indexOf(tb) < 0 && run.advBuffs.push(tb); say("travel: " + tb + " goes on at the adventure, before the generals move"); return; }   // 0.2.105
                    var gp = G.buffGroup ? G.buffGroup(tb) : null;
                    if (gp != null && tUsed[gp]) { say("travel: " + tb + " left out — it excludes " + tUsed[gp]); return; }
                    var obsName = /^Observatory:/.test(tb) ? tb.slice(12) : null, ra;
                    if (G.zoneBuffActive && G.zoneBuffActive(obsName || tb)) { say("travel: " + tb + " already runs"); if (gp != null) tUsed[gp] = tb; (T.already = T.already || []).push(tb); return; }
                    if (obsName) ra = G.startObservatory ? G.startObservatory(obsName) : { ok: false, reason: "no gateway" };
                    else ra = G.applyZoneBuff ? G.applyZoneBuff(tb) : { ok: false, reason: "no gateway" };
                    if (ra.ok) { if (gp != null) tUsed[gp] = tb; T.want.push({ name: tb, obs: obsName }); }
                    say("travel: " + tb + (ra.ok ? (obsName ? " ordered at the Observatory " + ra.grid : " put on") : " not put on: " + ra.reason));
                });
                run.lastAt = G.now(); return T.want.length ? "wait" : "ok";
            }
            var now0 = {}; try { now0 = G.starBuffs ? G.starBuffs(null) || {} : {}; } catch (_) { now0 = {}; }
            var runs = function (w) { if (w.obs) return true;   // the Observatory's order is its proof (the chart runs once made)
                if (G.zoneBuffActive && G.zoneBuffActive(w.name)) return true;
                return T.before[w.name] != null && now0[w.name] != null && now0[w.name] < T.before[w.name]; };
            var notYet = T.want.filter(function (w) { return !runs(w); });
            if (!notYet.length) { if (!T.said) { T.said = true; say("travel: all speed-ups run (" + T.want.map(function (w) { return w.name; }).join(", ") + ")"); } return "ok"; }
            var limit = 5 * 60000;   // 0.2.113
            /* 0.2.113 (live 2026-11-21: the Vortex put on at 02:53Z showed as running only minutes later; the run had put on a second
               one after 30 s and stopped after 2 minutes): put on again only if the star count did not go down after 90 s, and wait
               up to 5 minutes for it to show as running */
            if (!T.resent && G.now() - T.at >= 90000) { T.resent = true; notYet.forEach(function (w) { if (!w.obs && T.before[w.name] != null && now0[w.name] != null && now0[w.name] >= T.before[w.name]) { var ra = G.applyZoneBuff ? G.applyZoneBuff(w.name) : { ok: false }; say("travel: " + w.name + " was not taken from the star — put on again" + (ra.ok ? "" : " (" + ra.reason + ")")); } }); return "wait"; }
            /* 0.2.124 (live YWC 2026-11-22 00:28-00:33Z: Black Tree was put on twice and never taken from the star while the travel
               documents and the Observatory boost ran; the run refused to start): a speed-up the game does not take while another
               speed-up of the run runs does not stack with it — the run goes on with the ones that run; with none running it stops */
            if (G.now() - T.at >= limit) {
                var runningW = (T.already || []).concat(T.want.filter(runs).map(function (w) { return w.name; }));
                var refused = notYet.filter(function (w) { return !w.obs && T.before[w.name] != null && now0[w.name] != null && now0[w.name] >= T.before[w.name]; });
                if (runningW.length && refused.length === notYet.length) {
                    T.want = T.want.filter(function (w) { return refused.indexOf(w) < 0; }); T.said = true;
                    say("travel: " + refused.map(function (w) { return w.name; }).join(", ") + " not taken by the game while " + runningW.join(", ") + " run" + (runningW.length === 1 ? "s" : "") + " — they do not stack; going on");
                    return "ok";
                }
            }
            if (G.now() - T.at >= limit) return "the speed-ups do not run: " + notYet.map(function (w) { return w.name; }).join(", ") + " — not starting without them";
            return "wait";
        }
        /* 0.2.101 (live YWC 2026-11-20 10:44-10:53Z: after a restart the home island was held 9 minutes; the runner's four loads on the
           adventure island were refused by that start-up hold, it took them for "another version's troops" and called all 21 generals
           home): while the start-up hold lasts no step runs and nothing counts; the run's clock (since) moves on by the time held. */
        function heldNow() {
            var h = false; try { h = !!(G.startupHold && G.startupHold()); } catch (_) { h = false; }
            if (h) { if (!run.holdAt) { run.holdAt = G.now(); say("waiting: start-up hold (the home island is loading) — nothing is sent or counted until it ends"); } return true; }
            if (run.holdAt) { var dH = G.now() - run.holdAt; run.since += dH; run.lastAt = 0; run.holdAt = 0; say("start-up hold over after " + Math.round(dH / 1000) + " s; going on"); }
            return false;
        }
        function step() {
            if (run.state !== "STOPPED" && run.state !== "DONE" && heldNow()) return;   // 0.2.101
            switch (run.state) {
            case "FIX": {   // 0.2.166 (ADR 0102): a self-repair under way
                var fx = run.fix && run.fix.step; if (!fx) return go("PRECHECK", "self-repair without a step: starting over from the check");
                if (G.now() < fx.until) { if (!run.fixSaidAt || G.now() - run.fixSaidAt > 300000) { run.fixSaidAt = G.now(); publish(); } return; }
                if (fx.play && run.zone != null && G.ownAdventure(run.res) !== run.zone) return go("DONE", "the adventure was closed by the player");   // 0.2.166 r2 (tester)
                if (fx.play && run.zone != null && G.viewedZone() !== run.zone) { if (gap(30000)) { run.lastAt = G.now(); G.visit(run.zone); } return; }
                if (!fx.refAt) { fx.refAt = G.now(); if (G.refresh) G.refresh(); return; }
                if (G.now() - fx.refAt < 8000) return;
                if (fx.play) {
                    run.sentKeys = null; run.lay = null; run.cbc = null; run.only = null; run.resumed = false; run.cf = null; run.retreated = false;   /* the relearn count (tries9) carries on across repairs */
                    /* 0.2.166 r2 (tester): a general whose camp already fell is not sent again */
                    var pkF = run.packets[run.round] || {}, keepF = {}, gone = 0;
                    /* 0.2.166 r3 (tester): a removed entry's delay goes to the next one in SEND order (the "order" field, else the key
                       order), so the template's timing holds; the packet keeps its own key order */
                    var keysF = Object.keys(pkF), sendF = keysF.slice().sort(function (a, b) { var oa = pkF[a] && pkF[a].order != null ? Number(pkF[a].order) : keysF.indexOf(a), ob = pkF[b] && pkF[b].order != null ? Number(pkF[b].order) : keysF.indexOf(b); return oa - ob || keysF.indexOf(a) - keysF.indexOf(b); });
                    var carry = 0, outF = {};
                    var spentF = run.arrowSpent || {};   // 0.2.172: an arrow already used on its camp (or whose use is not known) is not put on it again by a replay
                    sendF.forEach(function (k) { var e = pkF[k]; if (e && Number(e.target) > 0 && (!G.campAlive(Number(e.target)) || (e.type === "buff" && spentF[Number(e.target)]))) { gone += 1; carry += Number(e.time) || 0; }
                        else { if (carry && e) { e = JSON.parse(JSON.stringify(e)); e.time = (Number(e.time) || 0) + carry; carry = 0; } outF[k] = e; } });
                    keysF.forEach(function (k) { if (k in outF) keepF[k] = outF[k]; });
                    if (gone) { run.orig = run.orig || {}; if (!run.orig[run.round]) run.orig[run.round] = pkF; run.packets[run.round] = keepF; }
                    if (fx.emergency && !run.emergency) { run.emergency = true; run.emergencyFix = run.round; }
                    return go("LOADR", run.names[run.round] + ": self-repair " + fx.n + "/" + fx.of + " — playing the step again" + (run.emergency ? " camp by camp" : "") + " from what still stands");
                }
                go(fx.from, "self-repair " + fx.n + "/" + fx.of + " — trying " + fx.from + " again");
                if (fx.from === "SEND") run.tries = 1;   // 0.2.166 r2 (tester): only the generals still at home are sent again
                return;
            }
            case "PRECHECK": {
                if (!G.atHome()) {   // 0.1.2: a restart while on the adventure
                    var onAdv = G.ownAdventure(run.res);
                    /* 0.2.174 (live FT 2026-11-26 19:34-20:30Z: "Finish camp by camp" started while the adventure was shown, said
                       "resuming on the adventure" and waited 55 minutes for 9 generals FINISH had sent home at 19:28): resume on the
                       adventure only when a general of the plan stands on it; with none there, go home first - at home the open
                       adventure is resumed the usual way (0.1.1/0.2.85: the generals still home are loaded and sent) */
                    if (onAdv && G.viewedZone() === onAdv) {
                        var iH = null; try { iH = G.inspect(load); } catch (_) { iH = null; }
                        var onIt = iH && iH.generals ? Object.keys(iH.generals).filter(function (k) { var x = iH.generals[k]; return x && x.here && !x.travelling; }).length : 1;
                        if (!onIt) { if (!run.homeFirstAt || G.now() - run.homeFirstAt > 60000) { run.homeFirstAt = G.now(); say("no general of the plan is on the adventure: home first, to load and send them"); G.visit(G.homeZone()); } return; }
                        run.zone = onAdv; run.resumed = !!run.prevState && FIGHTING.indexOf(run.prevState) >= 0; return go("TRAVEL", "resuming on the adventure"); }   // 0.2.30
                    return stop("not on the home island");
                }
                var open = G.ownAdventure(run.res);
                /* 0.2.2: an adventure we finished but that is still listed is still open on the server (live: a new FT did not
                   start after 0.1.7 had removed the old one from the list only). Never hide it; stop and say so. */
                if (open && run.doneZones && run.doneZones.indexOf(open) >= 0) return stop("the previous " + run.res + " (zone " + open + ") is still open: all its quests are done, but the game has not closed it. Close it in the quest book first.");
                if (open) {   // 0.1.1: resume an adventure of ours that is open while its generals are still home
                    var iR = G.inspect(load), atHome = Object.keys(iR.generals).filter(function (k) { return iR.generals[k].here && iR.generals[k].idle; });
                    if (atHome.length === Object.keys(iR.generals).length) { if ((run.rules.travel || []).length) { var tr1 = travelReady(); if (tr1 === "wait") return; if (tr1 !== "ok") return stop(tr1); } run.zone = open; return go("LOAD", "resuming the open adventure, zone " + open); }   // 0.2.100: speed-ups first
                    /* 0.2.85 (F11, live BB 2026-11-17 07:56-08:26Z: the emergency run resumed an adventure another version had
                       started, took "not all home" for "all sent", and waited 30 minutes for 9 generals that never left home):
                       the template's generals still idle at home are loaded and sent; the others are taken to be on the way */
                    run.resumedOpen = true;   // 0.2.86
                    /* 0.2.123 (live YWC 2026-11-21 16:01Z: the resumed run re-loaded and re-sent GHOST1, whom the run had sent home on
                       purpose): all generals leave home together, so with the rule "first attack home" a first-attack-only general
                       that is home while others are away has done its attack and came back — it is not sent again */
                    if (run.rules.aheadHome && run.packets.length > 2) {
                        var laterK = []; run.packets.slice(2).forEach(function (pk) { generalIds(pk).forEach(function (k) { if (laterK.indexOf(k) < 0) laterK.push(k); }); });
                        var aheadR = generalIds(run.packets[1]).filter(function (k) { return laterK.indexOf(k) < 0 && atHome.indexOf(k) >= 0; });
                        if (aheadR.length) { atHome = atHome.filter(function (k) { return aheadR.indexOf(k) < 0; }); run.aheadHome = { keys: aheadR, sent: {} }; aheadR.forEach(function (k) { run.aheadHome.sent[k] = true; });
                            say("resuming: " + aheadR.map(function (k) { var pk1 = run.packets[1] || {}; return String((pk1[k] && pk1[k].name) || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; }).join(", ") + " home on purpose (first attack done, rule first attack home) — not sent again"); }
                    }
                    if (atHome.length) { if ((run.rules.travel || []).length) { var tr2 = travelReady(); if (tr2 === "wait") return; if (tr2 !== "ok") return stop(tr2); } run.zone = open; run.part = atHome; run.resumed = !!run.prevState && FIGHTING.indexOf(run.prevState) >= 0;
                        return go("LOAD", "resuming the open adventure, zone " + open + ": " + atHome.length + " of " + Object.keys(iR.generals).length + " generals still home, they are loaded and sent"); }
                    run.zone = open; run.resumed = !!run.prevState && FIGHTING.indexOf(run.prevState) >= 0;   // 0.2.30
                    return go("TRAVEL", "resuming: generals already sent, going to the adventure (zone " + open + ")" + (run.prevState ? "; before the restart: " + run.prevState : ""));   // 0.1.2
                }
                if (run.resumeOnly) return stop("nothing to resume: no " + run.res + " of ours is open");   // 0.2.3: a resume never starts a new adventure
                var item = G.starItem(run.res);
                if (!item) return stop("no " + run.res + " in the star");
                if (item.count <= Number(run.rules.minStock || 0)) return stop("only " + item.count + " in the star, rule keeps " + run.rules.minStock);
                /* 0.2.117 (live YWC 2026-11-21 06:27Z; author: "dat de ghost er al is en de rest nog onderweg is dus normaal als je meerdere
                   runs doet. Dus de controle erop moet kloppen en niet een run stoppen om de verkeerde redenen"): every general of the load
                   is home and idle before the adventure is opened; generals still on their way are waited for (named once, at most 45
                   minutes), never a reason to start with part of the run */
                var iH = G.inspect(load), awayH = Object.keys(iH.generals || {}).filter(function (k) { return !(iH.generals[k].here && iH.generals[k].idle); });
                if (awayH.length) {
                    var nmH = awayH.map(function (k) { return String((load[k] && load[k].name) || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; });
                    /* 0.2.118: who is on the way home and when it lands comes from the game; the wait is the last arrival plus 2 minutes;
                       a general neither home nor on its way (still on an adventure) is named and waited for at most 45 minutes */
                    var trH = {}; try { trH = G.travellers ? G.travellers(awayH) || {} : {}; } catch (_) { trH = {}; }
                    var onWay = awayH.filter(function (k) { return trH[k]; }), elsewhere = awayH.filter(function (k) { return !trH[k]; });
                    var lastMs = onWay.reduce(function (m, k) { return Math.max(m, trH[k].ms || 0); }, 0);
                    var nm = function (k) { return String((load[k] && load[k].name) || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; };
                    var sig = onWay.length + "|" + elsewhere.length;
                    if (run.awaySig !== sig) { run.awaySig = sig; run.awaySaid = true;
                        say("waiting: " + awayH.length + " of " + Object.keys(iH.generals).length + " generals of the load are not home yet" +
                            (onWay.length ? "; on their way home: " + onWay.map(function (k) { return nm(k) + " " + Math.ceil((trH[k].ms || 0) / 60000) + " min"; }).join(", ") : "") +
                            (elsewhere.length ? "; not on their way (still on an adventure?): " + elsewhere.map(nm).join(", ") : ""));
                        run.awayUntil = G.now() + (elsewhere.length ? 45 * 60000 : lastMs + 2 * 60000); }
                    if (G.now() > run.awayUntil) return stop(awayH.length + " generals of the load did not come home in time: " + nmH.join(", "));
                    return;
                }
                if (run.awaySaid) { run.awaySaid = false; say("all " + Object.keys(iH.generals).length + " generals of the load are home"); }
                if (run.rules.checkArmy !== false) {
                    /* 0.2.103 (author 2026-11-20: "ze zijn waarschijnlijk in de generaals, telt hij die mee, want dat gebeurt ook als de
                       generaals terug komen van een eerdere ywc"): what the template's generals still need is covered by the loose troops
                       plus what the template's own generals carry too much; only a real gap stops the run, named as that gap */
                    var i = G.inspect(load), miss = {};
                    Object.keys(i.needs || {}).forEach(function (u) { var m = (Number(i.needs[u]) || 0) - ((i.free || {})[u] || 0) - ((i.surplus || {})[u] || 0); if (m > 0) miss[u] = m; });
                    if (!i.free && Object.keys(i.needs || {}).length && !i.canLoad) miss = i.needs;   // a gateway without the counts: as before
                    if (Object.keys(miss).length) {
                        /* 0.2.127 (author 2026-11-22: "De troop manager moet ze altijd op orde houden"): the troop manager is told what this
                           start needs loose at home (what is loose now plus the gap), and trains it */
                        try { var TM = root.DMA_Troops, wl = {}; Object.keys(miss).forEach(function (u) { wl[u] = ((i.free || {})[u] || 0) + miss[u]; });
                              if (TM && TM.want) TM.want(run.res, wl, "start refused: " + JSON.stringify(miss) + " missing"); } catch (_) {}
                        return stop("not enough troops at home for " + run.names[0] + ": " + JSON.stringify(miss) + " missing (loose and in the generals counted); the troop manager is asked to train them");
                    }
                    try { if (root.DMA_Troops && root.DMA_Troops.clearWant) root.DMA_Troops.clearWant(run.res); } catch (_) {}   // 0.2.127: started — nothing more to train for it
                }
                if ((run.rules.travel || []).length) { var tr = travelReady(); if (tr === "wait") return; if (tr !== "ok") return stop(tr); }   // 0.2.100: every speed-up active before the adventure opens
                run.item = item.id;
                var us = G.useStarItem(item.id);   // 0.2.83 (ADR 0073): the adapter's answer first, then START
                if (us && us.ok === false) { if (us.retry) { say("waiting: " + us.reason); return; } return stop("the star item was refused: " + us.reason); }
                go("START", "starting " + run.res + " (" + item.count + " in the star)");
                return;
            }
            case "START": {
                var z = G.ownAdventure(run.res);
                if (z) { run.zone = z; return go("LOAD", "adventure open, zone " + z); }
                /* 0.2.104 (live YWC 2026-11-20 10:23-10:30Z: the game took about 7 minutes to open the adventure; DMA gave up after 2,
                   the next try was refused — "Your Adventure could not be started" — and the first one opened afterwards): the run
                   waits up to 8 minutes, says once after 2 that the game is still opening it, and never uses a second star item meanwhile */
                if (!run.openSaid && G.now() - run.since >= 120000) { run.openSaid = true; say("the game is still opening " + run.res + " — waiting (up to 8 minutes)"); }
                if (late(T.start)) return stop("the adventure did not open within 8 minutes");
                return;
            }
            case "LOAD": {
                var i2 = G.inspect(load), ids = run.part || Object.keys(i2.generals), notMatch = ids.filter(function (k) { return !i2.generals[k].match; });
                if (!notMatch.length) return go("SEND", "load template " + run.names[0] + " loaded (" + ids.length + " generals)");
                if (gap(15000)) {
                    if (run.pass >= Math.max(4, Math.ceil(generalIds(load).length / 8))) return stop("load did not complete: " + notMatch.length + " generals differ from " + run.names[0]);
                    run.pass += 1; run.tries = 1; run.lastAt = G.now(); say("loading " + run.names[0] + " (pass " + run.pass + ")"); G.load(load);
                }
                return;
            }
            case "SEND": {
                var iS = G.inspect(load), gens = run.part || generalIds(load), home = gens.filter(function (k) { return iS.generals[k].here && iS.generals[k].idle; });
                if (run.tries > 0 && !gap(15000)) return;   // 0.2.35: a send that does not take leaves the general busy for a moment
                if (!home.length && run.tries > 0) return go("TRAVEL", "all " + gens.length + " generals on their way");
                if (gap(20000)) {
                    if (run.tries >= 3) return stop(home.length + " generals stayed home after 3 sends");
                    run.tries += 1; run.lastAt = G.now(); say("send " + run.tries + ": " + home.length + " generals"); G.send(run.tries === 1 ? gens : home, run.zone);
                }
                return;
            }
            case "TRAVEL": {
                if (G.viewedZone() !== run.zone) { if (run.tries === 0 || late(30000 * run.tries)) { run.tries += 1; G.visit(run.zone); } return; }
                var iT = G.inspect(load), all = generalIds(load), arrived = all.filter(function (k) { return iT.generals[k].here && !iT.generals[k].travelling && (iT.generals[k].idle || run.resumed || iT.generals[k].recovering); });   // 0.2.129: a recovering general is on the island   // 0.2.46: travelling is not arrived   // 0.2.7: after a restart a fighting general has arrived too
                /* 0.2.115 (ADR 0092): on arrival the landing fields are read from the game before any general goes to the star;
                   the star method is used only when more generals must land than there are fields */
                if (!run.landRead) { run.landRead = true; var lfT = null; try { lfT = G.landingFields ? G.landingFields() : null; } catch (_) { lfT = null; }
                    var lgT = lfT && lfT.length ? learnLanding(run.res, lfT, say) || landing(run.res) : null;
                    run.starNeeded = run.rules.starMethod !== false;   // 0.2.116: the player's rule, not the landing count
                    say(lgT ? all.length + " generals for " + lgT.n + " landing fields (read from the game)" + (run.starNeeded ? "; star method: all to the star, then each to its spot" : "")
                            : "landing fields could not be read" + (run.starNeeded ? "; star method as the rule says" : "")); }
                if (run.starNeeded && !run.resumed) { var idle = G.idleOnIsland().filter(function (k) { return !onOwnSpot(k, run.packets[1]); }); if (idle.length) G.toStar(idle); }   // 0.2.165: one already on its spot stays   // 0.2.7: after a restart the idle generals hold their round positions (live: they were sent to the star again and again)
                if (arrived.length === all.length) { run.round = 1; return go("LOADR", "all " + all.length + " generals arrived"); }
                /* 0.2.129: who is not counted as arrived, and why, every 2 minutes (live ToW: 16 minutes of silence in TRAVEL) */
                if (!run.travelSaidAt || G.now() - run.travelSaidAt > 120000) { run.travelSaidAt = G.now();
                    say("waiting for " + (all.length - arrived.length) + " of " + all.length + " generals: " + all.filter(function (k) { return arrived.indexOf(k) < 0; }).map(function (k) { var x = iT.generals[k] || {};
                        return String((load[k] && load[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0] + " (" + (!x.here ? "not here" : x.travelling ? "travelling" : x.star ? "in the star, busy" : "busy") + ")"; }).join(", ")); }
                if (late(T.arrive)) { var miss = all.filter(function (k) { return arrived.indexOf(k) < 0; }).map(function (k) { return String((load[k] && load[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]; });   // 0.2.85: name them
                    return stop(miss.length + " generals did not arrive in 30 minutes: " + miss.join(", ")); }
                return;
            }
            case "LOADR": {
                if (run.zone && G.viewedZone() === run.zone && run.troopAt !== run.round) troopCount("before " + (run.names[run.round] || "the end"));   // 0.2.90
                if (run.waitRecSince && G.now() - run.since < 120000) return;   // 0.2.70: waiting for recovering blockers, a try every 2 minutes
                if (run.zone && G.viewedZone() !== run.zone) { if (!run.lastVisit || G.now() - run.lastVisit > 30000) { run.lastVisit = G.now(); G.visit(run.zone); } return; }   // 0.2.40
                if (run.round >= run.packets.length) return go("FINISH", "all rounds played");
                var p = run.packets[run.round], tgs = targets(p);
                if (run.preRound !== run.round) { run.preRound = run.round; run.preLoads = 0; }   // 0.2.95
                /* 0.2.91 (author 2026-11-18: "Als je weet dat alle generaals geplaatst gaan worden vanuit star, dan breng je alles
                   naar star inclusief de marshalls. Daarna start je de eerste mundane die alle generaals op hun juiste plek zet,
                   laad de troepen en start de eerste aanval. Omdat je dezelfde generaals hergebruikt, hoef je alleen de tweede
                   aanval te laden en daarna te starten."): on arrival EVERY general and marshal of ours goes to the star once,
                   before the first round; each round then moves its generals from the star to their spots, loads and attacks.
                   The marshals stay in the star with their cargo until the end (this replaces 0.2.89's unloading). At most 3 min. */
                /* 0.2.115 (ADR 0092): "als je weet dat alle generaals geplaatst gaan worden vanuit star" — known only when the
                   landing fields (a game fact) are fewer than the generals; otherwise they keep their place and their troops */
                if (run.starNeeded == null) { var lgA = landing(run.res); run.starNeeded = run.rules.starMethod !== false; }
                if (run.round === 1 && !run.starAll && run.starNeeded && typeof G.mapGenerals === "function" && G.toStar) {
                    var p1 = run.packets[run.round] || {}, onM = G.mapGenerals().filter(function (m) { return m.onMap && m.idle && !(p1[m.key] && Number(p1[m.key].grid) === Number(m.grid)); }).map(function (m) { return m.key; });   // 0.2.165: one already on its spot stays
                    if (!run.starAllAt) { run.starAllAt = G.now(); if (onM.length) { G.toStar(onM); say("arrival: all " + onM.length + " generals and marshals to the star first"); } return; }
                    if (onM.length && G.now() - run.starAllAt < 3 * 60000) { if (gap(30000)) { run.lastAt = G.now(); G.toStar(onM); } return; }
                    run.starAll = true; run.starRound = -1;
                }
                if (tgs.length && !tgs.some(function (t) { return G.campAlive(t); })) { say(run.names[run.round] + ": its camps are already gone, skipped"); run.round += 1; return go("LOADR"); }   // 0.1.2: resume
                var i3 = G.inspect(p), ks = Object.keys(i3.generals);
                /* 0.2.58 (live BB: every step waited an hour for 1-Recruit blockers recovering from the step before, while the
                   chains need only a few of them): a blocker whose camp is gone, or who is recovering, is left out of the round;
                   the send plan then decides with the blockers there are (and refuses the layer if they are too few) */
                /* 0.2.176 (live FT 2026-11-27 04:38-05:30Z: the replay of "FT attack 01" waited 50 minutes for Narcissistic General, a
                   1-unit wave the plan sends to be beaten before the main of its camp comes in a later step): a 1-unit wave that is
                   recovering while a later step of the plan attacks its camp again is left out like a blocker - it has done its part */
                function waveDone(k) { var e = p[k], x = i3.generals[k]; if (!e || e.type === "buff" || !x || !x.recovering) return false;
                    var n = 0; Object.keys(e.army || {}).forEach(function (u) { n += Number(e.army[u]) || 0; }); if (n > 1) return false;
                    return run.packets.slice(run.round + 1).some(function (pk) { return Object.keys(pk || {}).some(function (k2) { return pk[k2] && pk[k2].type !== "buff" && Number(pk[k2].target) === Number(e.target); }); }); }
                if (!run.only) { var outB = blockIds(p).concat(Object.keys(p).filter(function (k) { return blockIds(p).indexOf(k) < 0 && waveDone(k); })).filter(function (k) { var x = i3.generals[k]; return !G.campAlive(p[k].target) || (x && x.recovering); });
                    run.recB = blockIds(p).filter(function (k) { var x = i3.generals[k]; return G.campAlive(p[k].target) && x && x.recovering; }).length;   // 0.2.70
                    if (outB.length) { run.orig = run.orig || {}; if (!run.orig[run.round]) run.orig[run.round] = p; var q = {}; Object.keys(p).forEach(function (k) { if (outB.indexOf(k) < 0) q[k] = p[k]; }); run.packets[run.round] = p = q;
                        say(run.names[run.round] + ": " + outB.length + " blockers or beaten waves left out (camp gone or recovering)"); i3 = G.inspect(p); ks = Object.keys(i3.generals); } }
                var busy = ks.filter(function (k) { return !i3.generals[k].idle; });
                var recovering = busy.filter(function (k) { return i3.generals[k].recovering; });   // 0.2.38: defeated, not attacking
                if (recovering.length) {
                    if (!run.recoverSaid) { run.recoverSaid = true; say(run.names[run.round] + ": waiting for " + recovering.length + " generals to recover"); }
                    if (G.now() - run.since > T.recover) return stop(recovering.length + " generals still recovering before " + run.names[run.round]);
                    return;
                }
                run.recoverSaid = false;
                /* 0.2.7 (live 2026-10-31: a restart cut the spread YWC attack; the last generals were never sent): after a
                   restart, idle generals of this round whose camp still stands and who are ready attack now */
                if (busy.length && run.resumed && !run.only) {
                    var late7 = ks.filter(function (k) { var x = i3.generals[k]; return x.idle && x.target > 0 && G.campAlive(x.target); });
                    if (late7.length) { run.only = late7; say(run.names[run.round] + ": resuming the attack, " + late7.length + " generals not yet sent"); }
                    else { run.resumed = false; return go("FIGHT", run.names[run.round] + ": resuming the fight (" + busy.length + " generals busy)"); }   // 0.2.8
                }
                if (run.only) { p = part(p); i3 = G.inspect(p); ks = Object.keys(i3.generals); busy = []; }   // 0.2.7: only the generals not yet sent
                if (busy.length) { if (late(T.round)) return stop(busy.length + " generals still busy before " + run.names[run.round]); return; }
                var diff = ks.filter(function (k) { return !i3.generals[k].match; });
                if (!diff.length) return go("MOVE", run.names[run.round] + ": armies ok");
                if (gap(15000)) {
                    if (run.tries >= 4) {
                        /* 0.2.86 (F12, live BB 2026-11-17 09:16Z: "two waves" resumed an adventure the blocks version had started;
                           16 generals there carried the blocks load, and the first wave lacked 982 MountedMarksman): a resumed
                           run (run.part) that has not attacked yet and finds the wrong troops on the island brings every general
                           home once — troops included — and starts again from home, where its own load template loads */
                        if (run.resumedOpen && run.round === 1 && !run.recalled && !(run.sentKeys || []).length && run.packets.slice(1).every(function (pk) { return targets(pk).every(function (t) { return G.campAlive(t); }); })) { run.recalled = true; run.tries = 0; return go("RECALL", run.names[run.round] + ": the troops on the island are another version's (short " + JSON.stringify(i3.needs) + "); every general goes home once and the run starts again from home"); }
                        return stop(run.names[run.round] + ": armies still differ after 4 loads (troops short?) " + JSON.stringify(i3.needs)); }
                    /* 0.2.88 (F16a): the load is short and generals on the map hold the surplus — they give it back first, then the load */
                    var needU = i3.needs || {}, shortU = Object.keys(needU).filter(function (x) { return Number(needU[x]) > 0; });
                    if (shortU.length && typeof G.mapGenerals === "function" && typeof G.raise === "function" && run.shedPass !== run.tries) {
                        run.shedPass = run.tries; var sh = shedPlan(needU, p, G.mapGenerals()), nSh = 0;
                        sh.raises.forEach(function (r) { if (G.raise(r.key, r.army, nSh)) nSh += 1; });
                        if (nSh) { run.lastAt = G.now(); say(run.names[run.round] + ": " + nSh + " generals give back " + sh.raises.reduce(function (a, r) { return a + r.freed; }, 0) + " troops for the short " + shortU.join(", ") + (Object.keys(sh.left).length ? " (still short " + JSON.stringify(sh.left) + ")" : "")); return; }
                    }
                    run.tries += 1; run.lastAt = G.now(); say(run.names[run.round] + ": load army (pass " + run.tries + ", " + diff.length + " generals)"); G.load(p);
                }
                return;
            }
            case "MOVE": {
                if (run.zone && G.viewedZone() !== run.zone) { if (!run.lastVisit || G.now() - run.lastVisit > 30000) { run.lastVisit = G.now(); say("not at the adventure (after a restart?): visiting it first"); G.visit(run.zone); } return; }   // 0.2.135
                if ((run.advBuffs || []).length && !run.advBuffDone && run.zone != null && G.viewedZone() === run.zone) { if (advBuffsReady() === "wait") return; }   // 0.2.105; 0.2.106: the first MOVE of the run, whatever its round (round 0 is the load)
                if (run.starRound !== run.round && run.starNeeded !== false && G.idleOnIsland && G.toStar) {   // 0.2.115: not when all fit; 0.2.45 (1): who has no spot in this round goes to the star first
                    run.starRound = run.round;
                    var pkS = run.packets[run.round] || {}, spotS = Object.keys(pkS).filter(function (k) { return pkS[k] && pkS[k].grid > 0 && !(pkS[k].target > 0 && !G.campAlive(Number(pkS[k].target))); });   // 0.2.153: a general whose camp fell needs no spot
                    var ahS = run.aheadHome ? run.aheadHome.keys : [];   // 0.2.116: the first attack's generals go home, not to the star
                    var outS = G.idleOnIsland().filter(function (k) { return spotS.indexOf(k) < 0 && ahS.indexOf(k) < 0 && !(pkS[k] && (pkS[k].home || pkS[k].plan)); });   // 0.2.158: planned moves are the plan's
                    if (outS.length) { say(run.names[run.round] + ": " + outS.length + " generals without a spot in this round to the star first"); G.toStar(outS); run.lastAt = G.now(); return; }
                }
                var pm = part(run.packets[run.round]), i4 = G.inspect(pm), km = Object.keys(i4.generals);
                /* 0.2.152 (live IP 07:37Z, a run started again after camps fell: BROM, FR03 and YGG4 were moved for camps already gone,
                   onto the same fields): a general whose camp has fallen does not move */
                /* 0.2.158 (author 2026-11-23: the plan is made beforehand — generator 0.7.0): an entry with home: true sends that general
                   home (once); it needs no spot */
                var pkH = run.packets[run.round], homeK = km.filter(function (k) { return pkH[k] && pkH[k].home; });
                if (homeK.length) { run.homeSent = run.homeSent || {}; var goH = homeK.filter(function (k) { if (run.homeSent[k] || !i4.generals[k].here || !i4.generals[k].idle) return false;
                        /* 0.2.161: not while a camp it attacked earlier in this run still stands */
                        return !run.packets.slice(0, run.round).some(function (q) { return q && q[k] && Number(q[k].target) > 0 && G.campAlive(Number(q[k].target)); }); });
                    if (goH.length) { goH.forEach(function (k) { run.homeSent[k] = true; }); G.send(goH, G.homeZone()); say(run.names[run.round] + ": " + goH.map(function (k) { return String(pkH[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0]; }).join(", ") + " done for this adventure: home (plan)"); } }
                /* 0.2.165 (ADR 0101 rule 3): a general that landed on a landing field instead of its refused spot walks on to it */
                var pkW = run.packets[run.round], walkOn = km.filter(function (k) { var e = pkW[k], gk = i4.generals[k]; return e && e.walkTo > 0 && gk && gk.onGrid && !gk.star && gk.idle; });
                if (walkOn.length) { walkOn.forEach(function (k) { var e = pkW[k]; say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " landed on " + e.grid + ": walks on to its spot " + e.walkTo); e.grid = e.walkTo; delete e.walkTo; e.walked = true; if (run.offTries) run.offTries[k] = 0; });
                    pm = part(pkW); i4 = G.inspect(pm); km = Object.keys(i4.generals); }
                var off = km.filter(function (k) { var tk = Number((run.packets[run.round][k] || {}).target) || 0; return !(pkH[k] && pkH[k].home) && !i4.generals[k].onGrid && !(tk > 0 && !G.campAlive(tk)); });
                if (!off.length) return go("ATTACK", run.names[run.round] + ": in position");
                var walking = off.filter(function (k) { return i4.generals[k].walking; });   // 0.2.36
                /* 0.2.144 (live IP 05:42Z: FR01 "move 1" for minutes, every fix silent): a general that is recovering cannot move —
                   the step waits for it (said every 5 minutes) instead of stopping */
                var recOff = off.filter(function (k) { return i4.generals[k].recovering; });
                if (recOff.length && recOff.length === off.length && !late(T.recover)) { if (!run.recSaidAt || G.now() - run.recSaidAt > 300000) { run.recSaidAt = G.now(); say(run.names[run.round] + ": waits for " + recOff.map(function (k) { return String((run.packets[run.round][k] || {}).name || k).replace(/<[^>]*>/g, "").split(" ")[0]; }).join(", ") + " to recover"); } return; }
                if ((late(T.move) && !walking.length) || late(T.walk)) return stop(run.names[run.round] + ": " + off.length + " generals could not take their position" + (run.waitSaid ? " (no substitute spot for a general that shares its camp)" : ""));
                if (walking.length === off.length) return;   // all on their way: a new move would only restart their walk
                /* 0.2.147 (live IP 06:35Z: BROM, ANS and YGG3 each lost 2.5 minutes on landing field 7153, which a general from the
                   star never reaches): a spot remembered as not usable on this adventure is swapped at once for a free landing field */
                try { var mBF = book()[run.res] && book()[run.res].map, badF = [] /* 0.2.153: remembered fields switched off — the marks were wrong when a field was held */, lfF = ((mBF && mBF.landing && mBF.landing.grids) || []).map(Number);
                    /* 0.2.150 (live IP 07:19Z: 6953 was marked unusable while ANS stood on it and YGG1 could not move): a field a general
                       of this step stands on is usable again */
                    km.forEach(function (k) { var gk = i4.generals[k], gr0 = Number((run.packets[run.round][k] || {}).grid); if (gk.onGrid && badF.indexOf(gr0) >= 0) { badF.splice(badF.indexOf(gr0), 1); bookSave(); say(run.names[run.round] + ": spot " + gr0 + " is usable after all"); } });
                    if (badF.length) { var pkF2 = run.packets[run.round], usedF = Object.keys(pkF2).filter(function (o) { return pkF2[o] && pkF2[o].grid > 0 && (!(pkF2[o].target > 0) || G.campAlive(Number(pkF2[o].target))); }).map(function (o) { return Number(pkF2[o].grid); });
                        off.forEach(function (k) { var e = pkF2[k]; if (!e || badF.indexOf(Number(e.grid)) < 0) return;
                            var fr = lfF.filter(function (g) { return badF.indexOf(g) < 0 && usedF.indexOf(g) < 0; })[0];
                            if (fr > 0) { say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").split(" ")[0] + ": spot " + e.grid + " is not usable here, takes " + fr); e.grid = fr; usedF.push(fr); } });
                        pm = part(pkF2); } } catch (_) {}
                /* 0.2.153 (live IP 07:50Z, from the game's own check (5-battle.js): "cannot move" = the field is not free — held by an
                   idle general whose camp had fallen, back on its field after the fight): that general goes to the star */
                if (G.mapGenerals && G.toStar) { var pkO = run.packets[run.round], occ = []; run.occAt = run.occAt || {};
                    off.forEach(function (k) { var gq = i4.generals[k], e = pkO[k]; if (!e || gq.walking || gq.canMove) return;
                        G.mapGenerals().forEach(function (m) { if (m.grid === Number(e.grid) && m.key !== k && m.idle && !(pkO[m.key] && pkO[m.key].target > 0 && G.campAlive(Number(pkO[m.key].target))) && (!run.occAt[m.key] || G.now() - run.occAt[m.key] > 60000)) { run.occAt[m.key] = G.now(); occ.push(m.key); } }); });
                    if (occ.length) { say(run.names[run.round] + ": " + occ.length + " idle general(s) hold the fields of this step: to the star"); G.toStar(occ); return; } }
                if (G.placeable && G.nearPlaceable) off.forEach(function (k) {   // 0.2.37: a grid he may not stand on gets a placeable one nearby
                    var e = run.packets[run.round][k]; if (!e || i4.generals[k].walking) return;
                    /* 0.2.132 (live IP 2026-11-23 01:53Z, a version made from scratch: every general's spot is its camp's own grid, the
                       game neither placed them nor said "not placeable", "move 11" for minutes): a spot on the target camp itself is
                       replaced by the nearest placeable spot to that camp, away from the step's other spots */
                    if (e.target > 0 && Number(e.grid) === Number(e.target)) {
                        var pk1 = run.packets[run.round], othersT = Object.keys(pk1).filter(function (o) { return o !== k && pk1[o] && pk1[o].grid > 0 && Number(pk1[o].grid) !== Number(pk1[o].target); }).map(function (o) { return Number(pk1[o].grid); }).concat(heldTo(pk1, k));
                        var altT = G.nearPlaceable(k, Number(e.target), Number(e.target), othersT);
                        if (altT > 0) { say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " stands next to camp " + e.target + " on " + altT); e.grid = altT; pm = part(run.packets[run.round]); }
                        else {
                            /* 0.2.134 (live IP 02:24Z: 8 of 11 generals still without a spot — the held land at the landing holds few
                               spots, and a general already standing there blocks its own neighbourhood): a general on the island
                               attacks from where it stands, when no other spot of the step is that grid */
                            var hereT = 0; if (G.mapGenerals) G.mapGenerals().forEach(function (m) { if (m.key === k && m.grid > 0) hereT = m.grid; });
                            if (hereT > 0 && othersT.indexOf(hereT) < 0 && near(hereT, e.target)) { /* 0.2.165 (tester): only close to the camp */ say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " attacks camp " + e.target + " from where it stands (" + hereT + ")"); e.grid = hereT; pm = part(run.packets[run.round]); }
                            else { if (!(hereT > 0)) { run.noSpot = run.noSpot || {}; run.noSpot[k] = 1; }   // 0.2.136
                                run.noSpotSaid = run.noSpotSaid || {}; if (!run.noSpotSaid[k]) { run.noSpotSaid[k] = 1;   // 0.2.135: once per general, with where it is
                                say(run.names[run.round] + ": no placeable spot near camp " + e.target + " for " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " (stands on " + (hereT || "no grid: not on the island") + (hereT && othersT.indexOf(hereT) >= 0 ? ", another general's spot" : "") + ")"); } }
                        }
                        return;
                    }
                    if (e.walked) return;   // 0.2.165: walking on to its own spot — the star's placement check does not apply
                    if (G.placeable(k, e.grid) !== false) return;
                    var pk0 = run.packets[run.round];
                    var shares = e.target > 0 && Object.keys(pk0).some(function (o) { return o !== k && pk0[o] && pk0[o].target === e.target; });   // 0.2.45 (2)
                    /* 0.2.173 (live FT 2026-11-26 18:25Z, probe 18:40Z: VAR "may not stand on 2873" because RES2 of the same step stood on
                       it - put there as a substitute for its own spot 3144 - and generals of earlier, stopped runs stood idle next to
                       the plan's spots): played as written, before a spot is called "not placeable" it is cleared - an idle general
                       standing ON it, or within 2 tiles of it, that is not on a spot of its own in this step goes to the star (once per
                       general); a general of this step lands again on its own spot. Never a stop, never a substitute, for a spot
                       that one of our own generals holds. */
                    if (run.rules.asIs && !run.only && !run.emergency && G.mapGenerals && G.toStar) {
                        run.cleared = run.cleared || {}; var inWay = [];
                        G.mapGenerals().forEach(function (m) { if (m.key === k || !m.idle || !(m.grid > 0) || run.cleared[m.key]) return;
                            var dW = m.grid === Number(e.grid) ? 0 : (G.dist ? G.dist(m.grid, Number(e.grid)) : null); if (dW == null || dW > 2) return;
                            var eW = pk0[m.key]; if (eW && eW.type !== "buff" && Number(eW.grid) === m.grid) return;   // on its own spot of the plan: the plan has them that close
                            inWay.push(m.key); });
                        if (inWay.length) { inWay.forEach(function (x) { run.cleared[x] = G.now(); }); run.clearAt = G.now(); G.toStar(inWay);
                            say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " may not stand on " + e.grid + ": " + inWay.map(function (x) { return String((pk0[x] && pk0[x].name) || x).replace(/<[^>]*>/g, "").trim().split(" ")[0]; }).join(", ") + " stand" + (inWay.length === 1 ? "s" : "") + " on or next to it and not on a spot of the plan - to the star first"); return; }
                        if (run.clearAt && G.now() - run.clearAt < 20000) return;   // the game takes a moment to free the land
                    }
                    if (shares && G.mapGenerals && G.toStar && !(run.starred && run.starred[k])) {   // 0.2.87 (F15): its spot held by a general of this round standing on the wrong spot — that one goes to the star
                        var holder = null; G.mapGenerals().forEach(function (m) { if (m.grid === Number(e.grid) && m.key !== k && m.idle) holder = m.key; });
                        if (holder && (!pk0[holder] || !i4.generals[holder] || !i4.generals[holder].onGrid)) { run.starred = run.starred || {};
                            if (!run.starred[holder]) { run.starred[holder] = true; G.toStar([holder]); say(run.names[run.round] + ": " + String((pk0[holder] && pk0[holder].name) || holder).replace(/<[^>]*>/g, "").trim() + " stands on the spot of " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " (" + e.grid + "): to the star first"); }
                            return; } }
                    /* 0.2.88 (F19, live BB 2026-11-17 17:54Z: SYL1's spot was held by YGG4, recovering after its lure; the round
                       timed out): played camp by camp (waves, camp by camp, emergency) the generals of a camp go one after the
                       other, so arrival order does not matter — a general whose spot is held by a busy general attacks from
                       where it stands, or from the nearest placeable spot */
                    if (shares && (run.rules.waves || run.rules.campByCamp || run.emergency) && G.mapGenerals) {
                        var busyHold = false, here = 0; G.mapGenerals().forEach(function (m) { if (m.grid === Number(e.grid) && m.key !== k && !m.idle) busyHold = true; if (m.key === k && m.grid > 0) here = m.grid; });
                        if (busyHold) {
                            var othersB = Object.keys(pk0).filter(function (o) { return o !== k && pk0[o] && pk0[o].grid > 0; }).map(function (o) { return pk0[o].grid; }).concat(heldTo(pk0, k));
                            var altB = here > 0 && othersB.indexOf(here) < 0 && near(here, e.grid) ? here : G.nearPlaceable(k, e.grid, e.target || 0, othersB);   // 0.2.165 (ADR 0101 rule 3): never from far away
                            if (altB > 0 && altB !== here && !near(altB, e.grid)) altB = -1;
                            if (altB > 0) { say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + "'s spot " + e.grid + " is held by a busy general; attacks from " + altB + (altB === here ? " (where it stands)" : "")); e.grid = altB; pm = part(run.packets[run.round]); return; }
                        } }
                    if (shares) { run.waitSaid = run.waitSaid || {}; if (!run.waitSaid[k]) { run.waitSaid[k] = true; say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " shares camp " + e.target + " with another general: waits for its own spot " + e.grid); } return; }
                    var others = Object.keys(pk0).filter(function (o) { return o !== k && pk0[o] && pk0[o].grid > 0; }).map(function (o) { return pk0[o].grid; }).concat(heldTo(pk0, k));
                    var alt = G.nearPlaceable(k, e.grid, e.target || 0, others);
                    if (alt > 0 && i4.generals[k] && !i4.generals[k].star && !near(alt, e.grid)) {   // 0.2.165 (tester): on the island never a far substitute
                        run.noSpot = run.noSpot || {}; if (!run.noSpot[k]) say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " may not stand on " + e.grid + "; the nearest free spot " + alt + " is too far from it — waits for a free spot"); run.noSpot[k] = 1; alt = -1; }
                    if (alt > 0) { if (i4.generals[k] && i4.generals[k].star && !near(alt, e.grid) && !(e.walkTo > 0)) e.walkTo = Number(e.grid);   // 0.2.165 (ADR 0101 rule 3): placed from the star far off, it walks on
                        say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " may not stand on " + e.grid + ", takes " + alt + (e.walkTo > 0 ? " and walks on to " + e.walkTo + " from there" : "")); e.grid = alt; pm = part(run.packets[run.round]); }
                });
                /* 0.2.136 (live IP 03:10Z: the held land at the landing holds 4 generals — the author's own IotP template sends 4; 7
                   generals in the star had no spot): generals of this round with no placeable spot and not on the island wait for a
                   step of their own after this one — by then camps have fallen and more land is held */
                /* 0.2.137 (live IP 03:23Z: "move 1" for minutes — one general with a spot never reached it while the other three
                   stood ready): a general sent 4 times without reaching its spot, not walking, waits for the next step too */
                run.offTries = run.offTries || {}; if (gap(30000)) off.forEach(function (k) { if (!i4.generals[k].walking) run.offTries[k] = (run.offTries[k] || 0) + 1; });
                off.forEach(function (k) { if ((run.offTries[k] || 0) >= 5 && !i4.generals[k].walking && off.length < genLive(run.packets[run.round], G)) { run.noSpot = run.noSpot || {}; if (!run.noSpot[k]) say(run.names[run.round] + ": " + String((run.packets[run.round][k] || {}).name || k).replace(/<[^>]*>/g, "").trim() + " did not reach its spot after 4 moves"); run.noSpot[k] = 1; } });
                /* 0.2.141 (live IP 04:54Z: FR01 alone in its step, "move 1" for 5 minutes — the landing fields were held by idle
                   generals of earlier steps): stuck generals that cannot wait for a later step free the fields — idle generals
                   on the island without a spot in this step go to the star, once */
                var stuckAll = off.filter(function (k) { return (run.offTries[k] || 0) >= 5 && !i4.generals[k].walking; });
                if (stuckAll.length && stuckAll.length >= genLive(run.packets[run.round], G) && !run.freedFor && G.idleOnIsland && G.toStar) {
                    run.freedFor = run.round; var pkF = run.packets[run.round], outF = G.idleOnIsland().filter(function (k) { return !pkF[k]; });
                    if (outF.length) { say(run.names[run.round] + ": the fields are held: " + outF.length + " idle generals without a spot in this step to the star"); G.toStar(outF); run.offTries = {}; run.lastAt = G.now(); return; } }
                /* 0.2.142 (live IP 05:08Z: FR01 alone, every field free, "move 1" to 7153 for 5 minutes — YGG1 and FR03 failed on
                   7153 before): a stuck general takes another placeable spot, away from the one it could not reach */
                if (stuckAll.length && stuckAll.length >= genLive(run.packets[run.round], G) && G.nearPlaceable) {
                    var pkR = run.packets[run.round]; run.badSpot = run.badSpot || {};
                    stuckAll.forEach(function (k) { var e = pkR[k]; if (!e) return; run.badSpot[Number(e.grid)] = 1;
                        var occB = false; try { if (G.mapGenerals) G.mapGenerals().forEach(function (m) { if (m.grid === Number(e.grid) && m.key !== k) occB = true; }); } catch (_) {}
                        if (false /* 0.2.153: switched off */ && !occB && i4.generals[k] && i4.generals[k].canMove) try { var mB = book()[run.res] && book()[run.res].map; if (mB) { mB.badFields = mB.badFields || []; if (mB.badFields.indexOf(Number(e.grid)) < 0) { mB.badFields.push(Number(e.grid)); bookSave(); say(run.names[run.round] + ": spot " + e.grid + " remembered as not usable on this adventure"); } } } catch (_) {}   // 0.2.147
                        var oth = Object.keys(pkR).filter(function (o) { return o !== k && pkR[o] && pkR[o].grid > 0 && (!(pkR[o].target > 0) || G.campAlive(Number(pkR[o].target))); }).map(function (o) { return Number(pkR[o].grid); }).concat(Object.keys(run.badSpot).map(Number)).concat(heldTo(pkR, k));
                        var altR = G.nearPlaceable(k, Number(e.grid), Number(e.target) || 0, oth);
                        /* 0.2.146 (live IP 06:16Z: the placement check finds nothing for a general in the star): the landing fields
                           learned from the game, not bad and not held by a general of this step whose camp stands, are tried in turn */
                        if (!(altR > 0)) { var lfR = []; try { var mR = book()[run.res] && book()[run.res].map; lfR = (mR && mR.landing && mR.landing.grids) || []; } catch (_) { lfR = []; }
                            lfR = lfR.map(Number).filter(function (g) { return !run.badSpot[g] && oth.indexOf(g) < 0; }); if (lfR.length) altR = lfR[0]; }
                        if (!(altR > 0)) say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " could not reach " + e.grid + " and no other placeable spot was found");   // 0.2.144
                        if (altR > 0 && i4.generals[k] && !i4.generals[k].star && !near(altR, e.grid)) {   // 0.2.165 (ADR 0101 rule 3): on the island it never moves far from its spot to attack
                            run.noSpot = run.noSpot || {}; if (!run.noSpot[k]) say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " could not reach " + e.grid + "; the nearest free spot " + altR + " is too far from it — waits for a free spot"); run.noSpot[k] = 1; altR = -1; }
                        if (altR > 0) { var gS = i4.generals[k], far = !near(altR, e.walkTo || e.grid);
                            if (gS && gS.star && far && !(e.walkTo > 0)) e.walkTo = Number(e.grid);   // 0.2.165 (ADR 0101 rule 3): it lands there, then walks on
                            say(run.names[run.round] + ": " + String(e.name || k).replace(/<[^>]*>/g, "").trim() + " could not reach " + e.grid + ", takes " + altR + (e.walkTo > 0 ? " and walks on to " + e.walkTo + " from there" : "")); e.grid = altR; }
                        run.offTries[k] = 0; });
                    pm = part(pkR); }
                var noSp = Object.keys(run.noSpot || {}).filter(function (k) { return run.packets[run.round][k]; });
                /* 0.2.172 (live FT 2026-11-26, R-PLAN-AS-WRITTEN: the first three generals of Sizz's plan - the ones that take the
                   sector leaders - had no placeable spot and waited "for the next step", so the later generals of the plan left
                   first and walked through the camps those leaders hold): played as written, a plan is never played out of its
                   order. The general without a spot waits together with EVERYTHING after it in the plan (generals and arrows);
                   when it is the first general of the plan nothing can go before it and the step stops, naming it. */
                if (noSp.length && run.rules.asIs && !run.only && !run.emergency) {
                    var curA = run.packets[run.round], ordA = sendOrder(curA), firstA = ordA.length;
                    noSp.forEach(function (k) { var ix = ordA.indexOf(k); if (ix >= 0 && ix < firstA) firstA = ix; });
                    var headA = ordA.slice(0, firstA), tailA = ordA.slice(firstA), nmA = String((curA[ordA[firstA]] || {}).name || ordA[firstA]).replace(/<[^>]*>/g, "").trim();
                    /* 0.2.173 (live FT 2026-11-26 18:25Z: VAR "may not stand on 2873", RES2 not on 3144 - spots on land the player does
                       not hold yet; Sizz: "buff 1 opens route part 1, buff 2 part 2, buff 3 part 3"): what comes before the general
                       in the plan and still has a camp to take - a general OR AN ARROW - is played first, as a step of its own; the
                       general's spot is judged again when that camp has fallen. 0.2.172 counted only generals, so an arrow alone
                       before the general stopped the step. Only when nothing before it has a camp left is the step stopped, at once
                       (no waiting ladder: waiting opens no land), with the game's own answer for the spot. */
                    if (!headA.some(function (k) { return curA[k] && curA[k].type !== "speedbuff" && curA[k].target > 0 && G.campAlive(Number(curA[k].target)); })) {
                        run.noSpot = {}; run.noSpotSaid = {}; run.offTries = {};
                        var gA = (curA[ordA[firstA]] || {}).grid, cdA = null; try { cdA = G.placeCode ? G.placeCode(ordA[firstA], Number(gA)) : null; } catch (_) { cdA = null; }
                        return stop(run.names[run.round] + ": " + nmA + " has no placeable spot (" + gA + (cdA != null ? ", the game's answer " + cdA : "") + ") and nothing of the plan before it has a camp left to take - the plan is not played out of its order; the spot is not on land you hold (a camp that opens it still stands?) or it is taken"); }
                    var restA = {}; tailA.forEach(function (k) { restA[k] = curA[k]; delete curA[k]; });
                    run.packets.splice(run.round + 1, 0, restA); run.names.splice(run.round + 1, 0, run.names[run.round] + " (rest)");
                    run.noSpot = {}; run.noSpotSaid = {}; run.offTries = {};
                    say(run.names[run.round] + ": " + nmA + " has no placeable spot yet: " + headA.map(function (k) { return curA[k].type === "buff" ? "arrow on " + curA[k].target : String(curA[k].name || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; }).join(", ") + " before it in the plan are played first; it and the " + (tailA.length - 1) + " steps after it follow in " + run.names[run.round + 1] + " - the plan keeps its order (the delay between the two parts is not the plan's)");
                    pm = part(curA); i4 = G.inspect(pm); off = Object.keys(i4.generals).filter(function (k) { return !i4.generals[k].onGrid; }); walking = off.filter(function (k) { return i4.generals[k].walking; });
                    if (!off.length) return go("ATTACK", run.names[run.round] + ": in position");
                    noSp = [];
                }
                if (noSp.length && noSp.length < genLive(run.packets[run.round], G)) {   // 0.2.139: generals, not camps
                    var cur = run.packets[run.round], rest = {};
                    noSp.forEach(function (k) { rest[k] = cur[k]; delete cur[k]; });
                    run.packets.splice(run.round + 1, 0, rest); run.names.splice(run.round + 1, 0, run.names[run.round] + " (rest)");
                    run.noSpot = {}; run.noSpotSaid = {}; run.offTries = {};
                    say(run.names[run.round] + ": " + noSp.length + " generals without a placeable spot wait in the star for the next step (" + run.names[run.round + 1] + ")");
                    pm = part(cur); i4 = G.inspect(pm); off = Object.keys(i4.generals).filter(function (k) { return !i4.generals[k].onGrid; }); walking = off.filter(function (k) { return i4.generals[k].walking; });
                    if (!off.length) return go("ATTACK", run.names[run.round] + ": in position");
                }
                if (gap(30000)) { run.tries += 1; run.lastAt = G.now(); say(run.names[run.round] + ": move " + (off.length - walking.length) + (off.length - walking.length <= 6 ? " [" + off.filter(function (k) { return !i4.generals[k].walking; }).map(function (k) { var gq = i4.generals[k]; return String((run.packets[run.round][k] || {}).name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " to " + (run.packets[run.round][k] || {}).grid + (gq.star ? " star" : "") + (gq.recovering ? " recovering" : "") + (gq.idle ? "" : " busy") + (gq.canMove ? "" : " cannot move") + (gq.here ? "" : " not here"); }).join(", ") + "]" : "") + (walking.length ? " (" + walking.length + " walking)" : "")); var pw = {}; Object.keys(pm).forEach(function (k) { if (!i4.generals[k] || !i4.generals[k].walking) pw[k] = pm[k]; }); G.move(pw); }
                return;
            }
            case "ATTACK": {
                if (run.zone && G.viewedZone() !== run.zone) { if (!run.lastVisit || G.now() - run.lastVisit > 30000) { run.lastVisit = G.now(); say("not at the adventure (after a restart?): visiting it first"); G.visit(run.zone); } return; }   // 0.2.135
                var pa = part(run.packets[run.round]), tg = targets(pa);
                if (!tg.length) { run.round += 1; return go("LOADR", run.names[run.round - 1] + ": no attacks, next"); }
                var i5 = G.inspect(pa), att = Object.keys(i5.generals).filter(function (k) { return i5.generals[k].target > 0; });
                var notReady = att.filter(function (k) { return !i5.generals[k].canAttack && G.campAlive(i5.generals[k].target); });
                /* 0.2.169 (B13, R-PLAN-AS-WRITTEN): played as written, an arrow earlier in the plan opens a general's way; that general
                   does not hold the step back */
                /* 0.2.172 (live FT 2026-11-26 16:37Z: three generals still busy from their move were let through by this rule;
                   Mundane leaves a general it cannot send out of its queue without a word, so only the arrows went and "0 of 3"
                   left): only a general that is idle - ready in everything but its way - is let through; a busy one is waited for */
                if (run.rules.asIs && !run.only) notReady = notReady.filter(function (k) { if (!i5.generals[k].idle) return true; var ok = Number((pa[k] || {}).order) || 0; return !Object.keys(pa).some(function (b) { return pa[b] && pa[b].type === "buff" && Number(pa[b].target) > 0 && (Number(pa[b].order) || 0) < ok; }); });
                /* 0.2.140 (live IP 04:30Z: "1 attacks cannot start" — YGG3's camp lay behind living camps): played camp by camp or in
                   waves, the camp scheduler waits for a blocked camp itself; only when no attack at all can start is it waited for here */
                var schedM = run.emergency || run.rules.waves || run.rules.campByCamp;
                if (notReady.length && !schedM) {   // 0.2.148: played camp by camp the scheduler decides, also when none can start yet (blockers first)
                 if (late(T.move)) return stop(run.names[run.round] + ": " + notReady.length + " attacks cannot start"); return; }
                /* 0.2.47 (ADR 0062): interception layers; a resumed partial attack (run.only) is sent as before */
                run.lay = null; run.sentKeys = [];   // 0.2.59
                /* 0.2.84 (ADR 0079): waves (version kind "without blocks") and the emergency mode use the camp scheduler
                   with several camps (CAMPS); plain camp by camp (ADR 0069) stays one camp at a time (CAMP). Both come before
                   the block permission: they never send a block entry. */
                if (run.rules.waves && !run.emergency && !run.rules.campByCamp && blockIds(pa).length) return stop(run.names[run.round] + ": a version without blocks has block entries (" + blockIds(pa).length + "); remove them or choose the kind blocks");
                if ((!run.only && run.rules.campByCamp) || run.emergency || (run.rules.waves && !run.only)) {
                    var cOrd = [], cBy = {}; Object.keys(pa).filter(function (k) { return pa[k] && pa[k].target > 0 && !pa[k].block; })
                        .sort(function (a, b) { return (pa[a].order || 0) - (pa[b].order || 0); })
                        .forEach(function (k) { var t9 = pa[k].target; if (!cBy[t9]) { cBy[t9] = []; cOrd.push(t9); } cBy[t9].push(k); });
                    run.only = null; run.sentKeys = [];
                    if (run.emergency || run.rules.waves) {
                        var lim = run.emergency || run.rules.campByCamp ? 1 : 99, stC = {}; cOrd.forEach(function (t9) { stC[t9] = { j: 0, at: 0, done: !G.campAlive(t9) }; });
                        run.cbc = { multi: true, limit: lim, camps: cOrd, by: cBy, st: stC, sent: {}, at: G.now() };
                        say(run.names[run.round] + ": " + (run.emergency ? "EMERGENCY — finish camp by camp" : "wave") + ": " + cOrd.map(function (t9) { return t9 + "(" + cBy[t9].length + ")" + (stC[t9].done ? " gone" : ""); }).join(" · "));
                        return go("CAMPS");
                    }
                    run.cbc = { camps: cOrd, by: cBy, i: 0, j: 0, sent: {}, at: G.now() };
                    say(run.names[run.round] + ": camp by camp: " + cOrd.map(function (t9) { return t9 + "(" + cBy[t9].length + ")"; }).join(" > "));
                    return go("CAMP");
                }
                if (blockIds(pa).length && run.rules.blocks !== true) return stop(run.names[run.round] + ": the template uses blocks and the player has not allowed blocks (ADVS: allow blocks, adv.blocks.on)");   // 0.2.51
                /* 0.2.55 (Adelgerta's BB guide: "all blocks work with minimum bronze horseshoe on"): a step with blocks is played
                   under a horseshoe — the zone's own when one is on, else rule adv.blocks.speedBuff from the star */
                if (blockIds(pa).length && G.speedBuff && !run.only) {
                    var sbOn = G.speedBuff();
                    if (!sbOn) { var want = String(run.rules.blockSpeedBuff || "GeneralSpeedBuff_Blackened_Titanium");
                        if (run.sbAt && G.now() - run.sbAt < 20000) return;   // 0.2.56: the server takes a few seconds; wait for it instead of applying again
                        if (want && want !== "none" && !run.sbAt) { var ar = G.applyZoneBuff ? G.applyZoneBuff(want) : { ok: false, reason: "no gateway" };
                            say(run.names[run.round] + ": horseshoe " + want + (ar.ok ? " applied (" + ar.left + " left)" : " not applied: " + ar.reason)); if (ar.ok) { run.sbAt = G.now(); return; } } }
                    run.speed = sbOn ? (SPEED[sbOn] || 0) : 0;
                    if (sbOn && !run.sbSaid) { run.sbSaid = 1; say(run.names[run.round] + ": horseshoe on: " + sbOn + " (+" + Math.round(run.speed * 100) + " %)"); }
                }
                /* 0.2.71 (author: "Voor mundane wil ik voorlopig werken met hun eigen mundanes"): a player's own Mundane template is
                   played as it is — its order and times, no layers, no re-timing — with the guards only: the interception
                   picture is logged; a general whose path a live camp watches that NO general of the step attacks would be
                   caught for certain, so the step is not sent; after the send the retreat on interception (0.2.59) and the camp
                   check before later attackers (0.2.69) watch over it. Rule adv.asIs (ADVS "play my own Mundane as it is"). */
                /* 0.2.79 (ADR 0069; live BB 2026-11-15: three mains reached their camp before their wave and lost — "Kamp voor
                   kamp is prima" — "Belangrijk is dat spelers hun eigen mundanes kunnen inzetten en het programma dat zelfstandig
                   kan volbrengen"): rule adv.campByCamp plays any template, the player's own Mundane included, one camp at a
                   time in the template's order; on a camp its attackers go one by one, the next only when the one before is
                   fighting there (or done); the next camp only when this one has fallen. Send times of the template are not used. */
                if (!run.only && run.rules.asIs && G.intercepts) {
                    var ica = G.intercepts(pa), hit = [], tgs = {}; Object.keys(pa).forEach(function (k) { if (pa[k] && pa[k].target > 0) tgs[pa[k].target] = 1; });
                    if (run.picSaid !== run.round) { run.picSaid = run.round; Object.keys(ica).forEach(function (k) { var w = ica[k].watch || {}, ws = Object.keys(w).map(function (c) { return c + "@" + w[c][0] + "-" + w[c][1] + (tgs[c] ? "" : " (not attacked)"); });
                        say(run.names[run.round] + ": picture " + String(pa[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " -> " + ica[k].target + ": " + (ws.join(" ") || "no camp")); }); }
                    Object.keys(ica).forEach(function (k) { (ica[k].by || []).forEach(function (c) { if (!tgs[c] && G.campAlive(c)) hit.push(String(pa[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " passes " + c); }); });
                    /* 0.2.110 (live YWC 2026-11-20 14:07Z: GHOST1 is meant to be intercepted — the author's rule adv.ywc.retreat is off
                       because "YWC intercepts some generals on purpose" — and this guard held the whole step back): when the player
                       turned the retreat on interception off for this adventure, an interception is intended; it is logged, not stopped */
                    if (hit.length && run.rules.retreat === false) say(run.names[run.round] + ": interception accepted (retreat on interception is off for this adventure): " + hit.join("; "));
                    else if (hit.length) return stop(run.names[run.round] + ": not sent — a camp nobody attacks or blocks watches the way: " + hit.join("; "));
                    say(run.names[run.round] + ": played as it is (" + Object.keys(pa).length + " generals, the template's own order and times)");
                    noteFight(Object.keys(pa)); var aqA = G.attack(pa);
                    /* 0.2.172 (live FT 2026-11-26): what Mundane really queued is said, as in the layers (0.2.52); an arrow that cannot
                       be put on its camp holds the whole step - no general walks on without the arrow of its plan */
                    if (aqA && aqA.held) { run.cf = null; return stop(run.names[run.round] + ": not sent - an arrow of the plan cannot be put on its camp: " + (aqA.badArrows || aqA.left || []).join("; ")); }
                    if (aqA && aqA.of) { if (aqA.left && aqA.left.length) say(run.names[run.round] + ": queued " + aqA.queued + " of " + aqA.of + " - left out: " + aqA.left.join("; "));
                        if (!aqA.queued && !aqA.arrows) { run.cf = null; return stop(run.names[run.round] + ": Mundane sent nobody - " + aqA.left.join("; ")); } }
                    markQueue(pa); run.only = null; run.sentKeys = Object.keys(pa); run.retreated = false; return go("FIGHT");
                }
                if (!run.only && run.rules.layers !== false && G.intercepts) {
                    var ic = G.intercepts(pa), bl = blockIds(pa), blocked = bl.map(function (k) { return pa[k].target; });
                    Object.keys(run.learned || {}).forEach(function (k) { if (!ic[k]) return; ic[k].watch = ic[k].watch || {};   // 0.2.61: what the game showed
                        run.learned[k].forEach(function (c) { if (!G.campAlive(c)) return; if (ic[k].by.indexOf(c) < 0) ic[k].by.push(c); if (!ic[k].watch[c]) ic[k].watch[c] = [0, Math.max(0, (ic[k].steps || 1) - 1)]; }); });
                    if (run.picSaid !== run.round) { run.picSaid = run.round; Object.keys(ic).forEach(function (k) { var w = ic[k].watch || {}, ws = Object.keys(w).map(function (c) { return c + "@" + w[c][0] + "-" + w[c][1]; });   // 0.2.65: the picture in the log, to set beside what the game does
                        say(run.names[run.round] + ": picture " + String(pa[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " -> " + ic[k].target + " (" + (ic[k].steps || "?") + " steps): " + (ws.join(" ") || "no camp")); }); }
                    var icL = {}; Object.keys(ic).forEach(function (k) { if (pa[k].block) return; icL[k] = { target: ic[k].target, by: ic[k].by.filter(function (b) { return blocked.indexOf(b) < 0; }) }; });   // 0.2.49
                    var plan = layersOf(icL, tg);
                    run.blocks = bl;
                    if (plan.length >= 1) {   // 0.2.48: also one layer, for the send times
                        run.lay = { plan: plan, i: 0, ic: ic };
                        say(run.names[run.round] + ": " + plan.length + " layers: " + plan.map(function (l) { return l.join(","); }).join(" | "));
                        return sendLayer(pa);
                    }
                }
                say(run.names[run.round] + ": attack " + tg.length + " camps"); noteFight(Object.keys(pa)); G.attack(pa); markQueue(pa); run.only = null; run.sentKeys = Object.keys(pa); run.retreated = false;   // 0.2.71: the guards watch this send too
                return go("FIGHT");
            }
            case "CAMP": {   // 0.2.79 (ADR 0069)
                var cb = run.cbc, pc = run.packets[run.round] || {};
                if (!cb) return go("FIGHT");
                var sentK = Object.keys(cb.sent), tc = G.tasks ? G.tasks(sentK) : {};
                cb.seen = cb.seen || {}; cb.tries = cb.tries || {}; var at9 = G.anyTask ? G.anyTask(sentK) : {}, un09 = G.units ? G.units(sentK) : {};
                sentK.forEach(function (k) { if (tookAttack(cb, k, tc, at9, un09, pc[k])) cb.seen[k] = 1; });   // a task, a Recover, or fewer units: the attack happened   // 0.2.164 (ADR 0101): an attack counts only once the game gave the general its task
                /* the adventure window can lag the server (live BB: fights 30 min past their end still shown): refresh it */
                var stale = sentK.filter(function (k) { return tc[k] && tc[k].remaining != null && tc[k].remaining < -60000; });
                /* 0.2.178 (live FT 2026-11-27 10:35-10:37: a task past its end stayed after every refresh and the run refreshed every 30 s
                   without going on): at most STALE_REFRESHES refreshes per general; then its task is taken as ended */
                cb.refN = cb.refN || {}; var staleR = stale.filter(function (k) { return (cb.refN[k] || 0) < STALE_REFRESHES; });
                if (staleR.length && G.refresh && (!cb.refAt || G.now() - cb.refAt > 30000)) { cb.refAt = G.now(); staleR.forEach(function (k) { cb.refN[k] = (cb.refN[k] || 0) + 1; }); G.refresh(); say(run.names[run.round] + ": the view is behind the server (" + stale.length + " tasks past their end): refreshed"); return; }
                var tgt9 = {}; stale.forEach(function (k) { tgt9[k] = tc[k] ? tc[k].target : null; });   // 0.2.181: where the view shows it, before it is taken as ended
                var se9 = staleEnded(cb, stale, tc, staleR);
                /* 0.2.180 (review r2: CR-C1/CR-B4/CR-D3): "seen" comes only from tookAttack. A general whose stale task is NOT its own
                   attack (another camp) is busy in the game: no resend, no next attacker on the strength of it - the step stops and
                   names it for the player */
                var busy9 = se9.filter(function (k) { return !cb.seen[k]; });
                if (busy9.length) return stop(run.names[run.round] + ": " + busy9.map(function (k) { return String((pc[k] && pc[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0] + " (the view shows a task on camp " + tgt9[k] + "; its own camp " + ((pc[k] && pc[k].target) || "?") + ")"; }).join(", ") + ": still so after " + STALE_REFRESHES + " refreshes - its attack was not seen. Please look at it before going on");
                if (se9.length) say(run.names[run.round] + ": the view stays behind the server for " + se9.map(function (k) { return String((pc[k] && pc[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]; }).join(", ") + " after " + STALE_REFRESHES + " refreshes: its task is taken as ended");
                if (cb.i >= cb.camps.length) { run.sentKeys = sentK; run.lay = null; return go("FIGHT", run.names[run.round] + ": every camp of the step attacked one by one"); }
                var camp9 = cb.camps[cb.i], ks9 = cb.by[camp9], nm9 = function (k) { return String((pc[k] && pc[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]; };
                if (!G.campAlive(camp9)) { say(run.names[run.round] + ": camp " + camp9 + " fell" + (cb.j < ks9.length ? " (" + (ks9.length - cb.j) + " not needed)" : "")); cb.i += 1; cb.j = 0; cb.at = G.now(); return; }
                /* 0.2.164 (ADR 0101, live FT 2026-11-24/25: a general just placed from the star got no task — the game takes no
                   attack from it for a few minutes — and 16 s later the run said "survived all its attackers"): an attacker the
                   game never gave a task is sent again, every 30 s for up to 8 minutes, before anything is judged */
                noteIntercept(cb, sentK, tc, pc);   // 0.2.183
                var un9 = ks9.slice(0, cb.j).filter(function (k) { return cb.sent[k] && !cb.seen[k] && !tc[k]; });
                if (un9.length) { var ku = un9[0];
                    if (cb.icamp && cb.icamp[ku] != null) return stop(run.names[run.round] + ": " + nm9(ku) + " was intercepted at camp " + cb.icamp[ku] + "; its attack on camp " + camp9 + " did not happen. Please look at it before going on");   // 0.2.183 (r5 CR-B3/CR-E3)
                    if (G.now() - cb.sent[ku] < 30000) return;
                    if ((cb.tries[ku] || 1) >= 16) return stop(run.names[run.round] + ": the game took no attack of " + nm9(ku) + " on camp " + camp9 + " in 8 minutes (" + (cb.tries[ku] || 1) + " tries)");
                    var oneU = {}; oneU[ku] = JSON.parse(JSON.stringify(pc[ku])); oneU[ku].time = 1000; oneU[ku].order = 0;
                    noteSend(cb, [ku]); var raU = G.attack(oneU); cb.sent[ku] = G.now(); cb.tries[ku] = (cb.tries[ku] || 1) + 1; cb.at = G.now();
                    say(run.names[run.round] + ": " + nm9(ku) + " got no task for camp " + camp9 + " (just placed from the star?): sent again, try " + cb.tries[ku] + (raU && raU.queued === 0 ? " — " + (raU.left || []).join("; ") : ""));
                    return; }
                if (cb.j < ks9.length) {
                    if (cb.j > 0) { var prev = ks9[cb.j - 1], tp = tc[prev];
                        var engaged = !tp ? !!cb.seen[prev] && G.now() - cb.sent[prev] > 5000 : (tp.phase != null && tp.phase >= 2) || tp.lost;   // 0.2.164 (tester): a wave the game never took is not "fighting there"
                        if (!engaged) { if (G.now() - cb.at > T.walk) return stop(run.names[run.round] + ": " + nm9(prev) + " did not reach " + camp9 + " in 30 minutes"); return; } }
                    var k9 = ks9[cb.j], one = {}; one[k9] = JSON.parse(JSON.stringify(pc[k9])); one[k9].time = 1000; one[k9].order = 0;
                    /* 0.2.80 (author: "Kamp voor kamp maakt het niet veel uit waar je de gen neerzet, als hij maar niet
                       onderschept wordt"): before it leaves, the general's path may cross no live camp other than its own */
                    if (G.intercepts) { var ic9 = G.intercepts(one)[k9], hit9 = ic9 ? (ic9.by || []).filter(function (c) { return Number(c) !== Number(camp9) && G.campAlive(c); }) : [];
                        if (hit9.length) return stop(run.names[run.round] + ": " + nm9(k9) + " not sent to " + camp9 + " — live camp(s) " + hit9.join(",") + " watch its way; put it on another spot or attack those first"); }
                    noteSend(cb, [k9]);
                    var ra9 = G.attack(one); cb.sent[k9] = G.now(); cb.tries[k9] = 1; cb.j += 1; cb.at = G.now();
                    if (ra9 && ra9.of > 0 && ra9.queued === 0) say(run.names[run.round] + ": " + nm9(k9) + " not taken by the game yet — " + (ra9.left || []).join("; "));   // 0.2.164
                    say(run.names[run.round] + ": " + nm9(k9) + " -> " + camp9 + (cb.j > 1 ? " (" + nm9(ks9[cb.j - 2]) + " is fighting there)" : ""));
                    return;
                }
                /* every attacker of this camp sent: wait for the camp to fall; all done and the camp stands -> stop */
                var busy9 = ks9.filter(function (k) { return !!tc[k]; });
                if (!busy9.length && G.now() - cb.at > 10000) { if (!cb.lastRef) { cb.lastRef = G.now(); if (G.refresh) G.refresh(); return; }
                    if (G.now() - cb.lastRef < 6000) return;
                    if (G.campAlive(camp9)) return stop(run.names[run.round] + ": camp " + camp9 + " survived all its attackers (" + ks9.map(nm9).join(", ") + "); check losses before going on");
                }
                if (G.now() - cb.at > T.round) return stop(run.names[run.round] + ": camp " + camp9 + " still fighting after 40 minutes");
                return;
            }
            case "RECALL": {   // 0.2.86 (F12): every general home, then PRECHECK again (the adventure stays open)
                if (run.tries === 0) {
                    if (!run.stowed && (typeof G.rule !== "function" || G.rule("adv.stowLoose", true) !== false)) { run.stowed = true; var nR = stowLoose(G, say); if (nR) { run.stowUntil = G.now() + 1000 * (nR + 3); return; } }
                    if (run.stowUntil && G.now() < run.stowUntil) return;
                    var mineR = G.allGeneralIds(); run.tries = 1; run.lastAt = G.now();
                    say("recall: sending " + mineR.length + " generals home"); if (mineR.length) G.send(mineR, G.homeZone());
                    return;
                }
                if (!G.atHome()) { if (gap(30000)) { run.lastAt = G.now(); G.visit(G.homeZone()); } return; }
                var iH = G.inspect(load), gH = generalIds(load), homeH = gH.filter(function (k) { return iH.generals[k].here && iH.generals[k].idle; });
                if (homeH.length === gH.length) { if ((run.rules.travel || []).length) { if (!run.recallTravel) { run.recallTravel = true; run.travel = null; } var trR = travelReady(); if (trR === "wait") return; if (trR !== "ok") return stop(trR); }   // 0.2.101: the speed-ups again before the generals leave home
                    run.part = null; run.round = 0; run.tries = 0; run.pass = 0; run.stowed = false; run.resumed = false; return go("LOAD", "recall: all " + gH.length + " generals home; loading " + run.names[0] + " for zone " + run.zone); }
                if (late(T.arrive)) return stop("recall: " + (gH.length - homeH.length) + " generals not home in 30 minutes");
                return;
            }
            case "CAMPS": {   // 0.2.84 (ADR 0079): waves and the emergency mode — several camps, each wave before its main
                if (run.zone && G.viewedZone() !== run.zone) { if (!run.lastVisit || G.now() - run.lastVisit > 30000) { run.lastVisit = G.now(); say("not at the adventure (after a restart?): visiting it first"); G.visit(run.zone); } return; }   // 0.2.135
                var cm = run.cbc, pm9 = run.packets[run.round] || {};
                if (!cm) return go("FIGHT");
                var sk = Object.keys(cm.sent), tm = G.tasks ? G.tasks(sk) : {};
                cm.seen = cm.seen || {}; cm.tries = cm.tries || {}; var atM = G.anyTask ? G.anyTask(sk) : {}, unM0 = G.units ? G.units(sk) : {};
                sk.forEach(function (k) { if (tookAttack(cm, k, tm, atM, unM0, pm9[k])) cm.seen[k] = 1; });   // 0.2.164 (ADR 0101)
                noteIntercept(cm, sk, tm, pm9);   // 0.2.183
                var nmM = function (k) { return String((pm9[k] && pm9[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]; };
                var staleM = sk.filter(function (k) { return tm[k] && tm[k].remaining != null && tm[k].remaining < -60000; });
                cm.refN = cm.refN || {}; var staleMR = staleM.filter(function (k) { return (cm.refN[k] || 0) < STALE_REFRESHES; });   // 0.2.178
                if (staleMR.length && G.refresh && (!cm.refAt || G.now() - cm.refAt > 30000)) { cm.refAt = G.now(); staleMR.forEach(function (k) { cm.refN[k] = (cm.refN[k] || 0) + 1; }); G.refresh(); say(run.names[run.round] + ": the view is behind the server (" + staleM.length + " tasks past their end): refreshed"); return; }
                var tgtM = {}; staleM.forEach(function (k) { tgtM[k] = tm[k] ? tm[k].target : null; });   // 0.2.181
                var seM = staleEnded(cm, staleM, tm, staleMR);
                var busyM = seM.filter(function (k) { return !cm.seen[k]; });   // 0.2.180: as in CAMP
                if (busyM.length) return stop(run.names[run.round] + ": " + busyM.map(function (k) { return String((pm9[k] && pm9[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0] + " (the view shows a task on camp " + tgtM[k] + "; its own camp " + ((pm9[k] && pm9[k].target) || "?") + ")"; }).join(", ") + ": still so after " + STALE_REFRESHES + " refreshes - its attack was not seen. Please look at it before going on");
                if (seM.length) say(run.names[run.round] + ": the view stays behind the server for " + seM.map(function (k) { return String((pm9[k] && pm9[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]; }).join(", ") + " after " + STALE_REFRESHES + " refreshes: its task is taken as ended");
                var active = 0, waiting = [], c, sC, ksC, ci;
                for (ci = 0; ci < cm.camps.length; ci++) { c = cm.camps[ci]; sC = cm.st[c];
                    if (sC.done) continue;
                    if (!G.campAlive(c)) { sC.done = true; say(run.names[run.round] + ": camp " + c + " fell" + (sC.j < cm.by[c].length ? " (" + (cm.by[c].length - sC.j) + " not needed)" : "")); continue; }
                    if (sC.j > 0) active += 1; }
                if (cm.camps.every(function (t) { return cm.st[t].done; })) { run.sentKeys = sk; run.lay = null; return go("FIGHT", run.names[run.round] + ": every camp of the " + (run.emergency ? "step (camp by camp)" : "wave") + " fell"); }
                for (ci = 0; ci < cm.camps.length; ci++) { c = cm.camps[ci]; sC = cm.st[c]; ksC = cm.by[c];
                    if (sC.done) continue;
                    if (sC.j < ksC.length) {
                        if (sC.j === 0 && active >= cm.limit) continue;
                        if (sC.j > 0) { var pv = ksC[sC.j - 1], tpv = tm[pv];
                            if (!tpv && !cm.seen[pv] && cm.icamp && cm.icamp[pv] != null) return stop(run.names[run.round] + ": " + nmM(pv) + " was intercepted at camp " + cm.icamp[pv] + "; its attack on camp " + c + " did not happen. Please look at it before going on");   // 0.2.183
                            if (!tpv && !cm.seen[pv]) {   // 0.2.164 (tester): the wave has no task yet — send it again, do not send the main
                                if (G.now() - cm.sent[pv] < 30000) continue;
                                if ((cm.tries[pv] || 1) >= 16) return stop(run.names[run.round] + ": the game took no attack of " + nmM(pv) + " on camp " + c + " in 8 minutes (" + (cm.tries[pv] || 1) + " tries)");
                                var oP = {}; oP[pv] = JSON.parse(JSON.stringify(pm9[pv])); oP[pv].time = 1000; oP[pv].order = 0; noteSend(cm, [pv]); G.attack(oP); cm.sent[pv] = G.now(); cm.tries[pv] = (cm.tries[pv] || 1) + 1;
                                say(run.names[run.round] + ": " + nmM(pv) + " got no task for camp " + c + " (just placed from the star?): sent again, try " + cm.tries[pv]); return; }
                            var eng = !tpv ? !!cm.seen[pv] && G.now() - cm.sent[pv] > 5000 : (tpv.phase != null && tpv.phase >= 2) || tpv.lost;
                            if (!eng) { if (G.now() - sC.at > T.walk) return stop(run.names[run.round] + ": " + nmM(pv) + " did not reach " + c + " in 30 minutes"); continue; } }
                        var kM = ksC[sC.j], oneM = {}; oneM[kM] = JSON.parse(JSON.stringify(pm9[kM])); oneM[kM].time = 1000; oneM[kM].order = 0;
                        if (G.intercepts) { var icM = G.intercepts(oneM)[kM], hitM = icM ? (icM.by || []).filter(function (x) { return Number(x) !== Number(c) && G.campAlive(x); }) : [];
                            if (hitM.length) { waiting.push(c + " (" + nmM(kM) + " passes " + hitM.join(",") + ")"); (cm.blk = cm.blk || {}); hitM.forEach(function (x) { cm.blk[Number(x)] = 1; });
                                try { var mBk = book()[run.res] && book()[run.res].map; if (mBk) { mBk.blocks = mBk.blocks || {}; var bl0 = mBk.blocks[c] || [], ch0 = false; hitM.forEach(function (x) { if (bl0.indexOf(Number(x)) < 0) { bl0.push(Number(x)); ch0 = true; } }); if (ch0) { mBk.blocks[c] = bl0; bookSave(); } } } catch (_) {}   /* 0.2.159: learned for the generator */ continue; } }
                        /* 0.2.149 (live IP 07:01Z: ANS "-> 4450", 16 s later "survived all its attackers" — the game never took the
                           attack: its path lay behind living camps): an attack the game does not queue is waiting, not fought */
                        noteSend(cm, [kM]);
                        var raM = G.attack(oneM);
                        if (raM && raM.of > 0 && raM.queued === 0 && (raM.left || []).every(function (x) { return /busy|not on its spot/.test(x); }) && G.now() - (sC.busyAt || (sC.busyAt = G.now())) < 120000) return;   // 0.2.162 (live IP 10:28Z: "Narcissistic: busy" right after his move — wait, up to 2 minutes)
                        if (raM && raM.of > 0 && raM.queued === 0) { waiting.push(c + " (" + nmM(kM) + ": not taken — " + (raM.left || []).join("; ") + ")"); cm.unq = cm.unq || {}; cm.unq[c] = 1; continue; }
                        cm.sent[kM] = G.now(); sC.j += 1; sC.at = G.now();
                        say(run.names[run.round] + ": " + nmM(kM) + " -> " + c + (sC.j > 1 ? " (" + nmM(ksC[sC.j - 2]) + " is fighting there)" : ""));
                        return;
                    }
                    var unM = ksC.filter(function (k) { return cm.sent[k] && !cm.seen[k] && !tm[k]; });   // 0.2.164 (ADR 0101): no task yet -> send again
                    if (unM.length) { var kU = unM[0];
                        if (cm.icamp && cm.icamp[kU] != null) return stop(run.names[run.round] + ": " + nmM(kU) + " was intercepted at camp " + cm.icamp[kU] + "; its attack on camp " + c + " did not happen. Please look at it before going on");   // 0.2.183
                        if (G.now() - cm.sent[kU] < 30000) continue;
                        if ((cm.tries[kU] || 1) >= 16) return stop(run.names[run.round] + ": the game took no attack of " + nmM(kU) + " on camp " + c + " in 8 minutes (" + (cm.tries[kU] || 1) + " tries)");
                        var oU = {}; oU[kU] = JSON.parse(JSON.stringify(pm9[kU])); oU[kU].time = 1000; oU[kU].order = 0;
                        noteSend(cm, [kU]); var rU = G.attack(oU); cm.sent[kU] = G.now(); cm.tries[kU] = (cm.tries[kU] || 1) + 1; sC.at = G.now();
                        say(run.names[run.round] + ": " + nmM(kU) + " got no task for camp " + c + " (just placed from the star?): sent again, try " + cm.tries[kU] + (rU && rU.queued === 0 ? " — " + (rU.left || []).join("; ") : ""));
                        return; }
                    var busyM = ksC.filter(function (k) { return !!tm[k]; });
                    if (!busyM.length && G.now() - sC.at > 10000) { if (!sC.ref) { sC.ref = G.now(); if (G.refresh) G.refresh(); return; }
                        if (G.now() - sC.ref < 6000) return;
                        /* 0.2.128 (live ToW 2026-11-22 15:08Z: a step that only weakens a camp — its attackers all 1R waves, the main in a
                           later step because they share one spot — stopped the run as if the attack had failed): a camp whose attackers in
                           this step carry at most one unit each was meant to stand; it is left for the next step */
                        if (G.campAlive(c) && waveOnly(pm9, c, run.packets.slice(run.round + 1)) && ksC.every(function (k) { var a = (pm9[k] && pm9[k].army) || {}, n = 0; Object.keys(a).forEach(function (u) { n += Number(a[u]) || 0; }); return n <= 1; })) {
                            sC.done = true; say(run.names[run.round] + ": camp " + c + " weakened by " + ksC.map(nmM).join(", ") + " (wave only, the main follows in a later step)"); continue; }
                        if (G.campAlive(c)) return stop(run.names[run.round] + ": camp " + c + " survived all its attackers (" + ksC.map(nmM).join(", ") + "); check losses, then Finish camp by camp"); }
                    if (G.now() - sC.at > T.round) return stop(run.names[run.round] + ": camp " + c + " still fighting after 40 minutes");
                }
                /* 0.2.138 (live IP 03:36Z, ADR 0094 lesson 3 "blockers first": every camp of the step lay behind 6545 and 6070, whose
                   generals waited in a later step): the generals of a later step that attack a camp standing in the way come forward;
                   this step's generals not yet sent go to the star (their spots are free for the newcomers) and follow after them */
                /* 0.2.151 (live IP 07:19-07:25Z: ANS/YGG3 and YGG1 swapped places every minute, no attack taken): a "blockers first"
                   that brought no camp down since the last one stops with the game's reasons instead of swapping again */
                var aliveN = 0; try { Object.keys(book()[run.res].map.camps || {}).forEach(function (g) { if (G.campAlive(Number(g))) aliveN++; }); } catch (_) { aliveN = -1; }
                if (!active && waiting.length && G.now() - cm.at > 10000 && !cm.pulled && run.pullAlive != null && run.pullAlive === aliveN && aliveN >= 0) return stop(run.names[run.round] + ": blockers first brought no camp down — " + waiting.join("; "));
                if (!active && waiting.length && G.now() - cm.at > 10000 && !cm.pulled) {
                    var blk = cm.blk || {}, fwd = {}, nF = 0;
                    if (!Object.keys(blk).length && cm.unq) { blk = {}; for (var rU = run.round + 1; rU < run.packets.length; rU++) { var pU = run.packets[rU] || {}; Object.keys(pU).forEach(function (k) { if (pU[k] && pU[k].target > 0) blk[Number(pU[k].target)] = 1; }); } }   // 0.2.149: unknown blockers — any reachable later camp
                    for (var rB = run.round + 1; rB < run.packets.length; rB++) { var pB = run.packets[rB] || {};
                        Object.keys(pB).forEach(function (k) { if (!pB[k] || !blk[Number(pB[k].target)] || !G.campAlive(Number(pB[k].target)) || nF >= 4) return;
                            /* 0.2.140 (live IP 04:28Z: seven generals came forward for four landing fields): only a general whose own
                               camp is reachable now (no other living camp on its path), at most four */
                            if (G.intercepts) { var oneP = {}; oneP[k] = JSON.parse(JSON.stringify(pB[k])); var icP = G.intercepts(oneP)[k];
                                if (icP && (icP.by || []).some(function (x) { return Number(x) !== Number(pB[k].target) && G.campAlive(x); })) return; }
                            fwd[k] = pB[k]; delete pB[k]; nF++; }); }
                    if (nF) {
                        cm.pulled = true; run.pullAlive = aliveN; say(run.names[run.round] + ": waiting — " + waiting.join("; ")); var back = {}, curB = run.packets[run.round];
                        Object.keys(curB).forEach(function (k) { if (!cm.sent[k] && curB[k] && curB[k].target > 0) { back[k] = curB[k]; delete curB[k]; } });
                        Object.keys(fwd).forEach(function (k) { curB[k] = fwd[k]; });
                        run.packets.splice(run.round + 1, 0, back); run.names.splice(run.round + 1, 0, run.names[run.round] + " (after the blockers)");
                        if (G.toStar) G.toStar(Object.keys(back));
                        say(run.names[run.round] + ": blockers first — " + Object.keys(fwd).map(function (k) { return String(fwd[k].name || k).replace(/<[^>]*>/g, "").split(" ")[0] + " -> " + fwd[k].target; }).join(", ") + " come forward; " + Object.keys(back).length + " generals wait in the star");
                        run.cbc = null; run.tries = 0; run.noSpot = {}; run.noSpotSaid = {}; run.offTries = {}; run.starRound = -1; return go("MOVE", run.names[run.round] + ": blockers first");   // 0.2.141: MOVE sends idle generals off the fields
                    }
                }
                if (!active && waiting.length && G.now() - cm.at > 10000) return stop(run.names[run.round] + ": no remaining camp can be reached — " + waiting.join("; ") + "; those camps stand in the way and nobody here attacks them");
                return;
            }
            case "FIGHT": {
                if (run.zone && G.viewedZone() !== run.zone) { if (!run.lastVisit || G.now() - run.lastVisit > 30000) { run.lastVisit = G.now(); say("not at the adventure (after a restart?): visiting it first"); G.visit(run.zone); } return; }   // 0.2.135
                if (run.rules.claim !== false && (!run.questAt || G.now() - run.questAt > 30000)) { run.questAt = G.now(); var qf = G.claimQuests(); if (qf.claimed || qf.accepted) say("quests: " + qf.claimed + " claimed, " + qf.accepted + " accepted" + (qf.last ? " (last quest)" : "")); if (qf.last) run.lastQuest = true; }
                /* 0.2.59 (author: "Als je ziet dat het fout gaat kunt je met 1 commando de generaals terug trekken voor die
                   generals waarvoor de strijd nog niet begonnen is"): every tick after a send, an attacker heading for another
                   camp than its own is intercepted — then every general of the step whose fight has not begun (walking or
                   waiting at the camp) is retreated with the game's own RETREAT (the general panel's command) and the run
                   stops; fights already running go on */
                if (run.sentKeys && G.tasks && G.retreat && run.rules.retreat !== false && !run.retreated) {
                    var tk = G.tasks(run.sentKeys), pk9 = run.packets[run.round] || {}, caught = [];
                    run.sentKeys.forEach(function (k) { var t = tk[k], e = pk9[k]; if (!t || !e || e.block) return;
                        if ((t.phase === 0 || t.phase === 1) && t.target > 0 && String(t.target) !== String(e.target)) { caught.push(k + " by " + t.target);
                            run.learned = run.learned || {}; var lk = run.learned[k] = run.learned[k] || []; if (lk.indexOf(Number(t.target)) < 0) lk.push(Number(t.target)); } });
                    if (caught.length) { run.retreated = true; var back = [];
                        run.sentKeys.forEach(function (k) { var t = tk[k]; if (t && (t.phase === 0 || t.phase === 1 || t.phase === 4)) { var r9 = G.retreat(k); if (r9 && r9.ok) back.push(String((pk9[k] && pk9[k].name) || k).replace(/<[^>]*>/g, "").split(" ")[0]); } });
                        var msg9 = run.names[run.round] + ": intercepted (" + caught.join(", ") + ") — retreated " + back.length + " generals before their fight: " + back.join(", ");
                        /* 0.2.61: what the game showed is learned — the interceptor joins that general's picture — and the step is
                           tried again (at most 3 times) once the retreated generals are back */
                        run.tries9 = (run.tries9 || 0) + 1;
                        if (run.tries9 <= 3 && run.rules.relearn !== false && !run.rules.asIs) { run.sentKeys = null; run.lay = null; run.resumed = false; run.only = null; return go("LOADR", msg9 + "; learned, trying again (" + run.tries9 + "/3)"); }
                        return stop(msg9); }
                }
                /* 0.2.69 (author: "doe wat jij denkt dat het beste is om vanaf nu alle avonturen BB foutloos uit te voeren met
                   blocks"; live 2026-11-14: twice the main lost 128 MM at 1.3 after a wave the simulator overrated): before an
                   attacker's own fight, when the one ahead of it on the same camp is done, the camp is read; an attacker with
                   "maxFoe" (units it may still meet, from the simulator) or "foeOnly" (unit types it may meet) that would meet
                   more is retreated with every later one on that camp, and the run stops. Each camp read is logged. */
                if (run.sentKeys && G.tasks && G.campArmy && G.retreat && !run.retreated) {
                    var tq = G.tasks(run.sentKeys), pq = run.packets[run.round] || {}, byT = {};
                    run.sentKeys.forEach(function (k) { var e = pq[k]; if (!e || e.block || !(e.target > 0)) return; (byT[e.target] = byT[e.target] || []).push(k); });
                    run.foeSeen = run.foeSeen || {};
                    for (var tgq in byT) { var ksq = byT[tgq].sort(function (a, b) { return (pq[a].order || 0) - (pq[b].order || 0); });
                        for (var iq = 1; iq < ksq.length; iq++) { var kq = ksq[iq], tqk = tq[kq]; if (!tqk || (tqk.phase !== 0 && tqk.phase !== 1) || run.foeSeen[kq]) continue;
                            var ahead = ksq.slice(0, iq).every(function (a) { var ta = tq[a]; return !ta || ta.phase >= 3; }); if (!ahead) break;
                            var ca = G.campArmy(Number(tgq)); if (!ca || ca.engaged) break;
                            run.foeSeen[kq] = true; var nmq = String(pq[kq].name || kq).replace(/<[^>]*>/g, "").split(" ")[0];
                            say(run.names[run.round] + ": " + tgq + " before " + nmq + ": " + ca.units + " units " + JSON.stringify(ca.by));
                            var mf = pq[kq].maxFoe != null ? Number(pq[kq].maxFoe) : null, only = pq[kq].foeOnly || null;
                            var badT = only ? Object.keys(ca.by).filter(function (t) { return only.indexOf(t) < 0; }) : [];
                            if ((mf != null && ca.units > mf) || badT.length) { run.retreated = true; var backq = [];
                                ksq.slice(iq).concat(run.sentKeys.filter(function (r) { return pq[r] && pq[r].block && pq[r].keep; })).forEach(function (r) { var tr9 = tq[r]; if (tr9 && (tr9.phase === 0 || tr9.phase === 1)) { var rr = G.retreat(r); if (rr && rr.ok) backq.push(String(pq[r].name || r).replace(/<[^>]*>/g, "").split(" ")[0]); } });   // 0.2.73: a normal block still walking goes back with them — the leader will not fall
                                return stop(run.names[run.round] + ": " + tgq + " is stronger than planned before " + nmq + " (" + ca.units + " units" + (mf != null ? ", plan at most " + mf : "") + (badT.length ? ", " + badT.join("/") + " still there" : "") + ") — retreated " + backq.join(", ") + " before their fight"); }
                            break; } }
                }
                /* 0.2.164 (ADR 0101 rule 2): an attacker the game never took is sent again before anything is judged */
                if (!run.lay || G.now() - run.lay.sentAt >= run.lay.sendMs + 20000) { var uf = untakenFight(); if (uf || run.stopped) return; }
                /* 0.2.47 (ADR 0062): between layers — wait until the island stands still, refresh, then the next layer */
                if (run.lay && run.lay.i < run.lay.plan.length - 1) {
                    if (G.now() - run.lay.sentAt < run.lay.sendMs + 20000) return;   // the Mundane still sends this layer
                    if (G.attacking() > 0) { if (G.now() - run.lay.sentAt > T.round) return stop(run.names[run.round] + ": layer " + (run.lay.i + 1) + " still fighting after 40 minutes"); return; }
                    if (!run.lay.refreshAt) { if (G.refresh) G.refresh(); run.lay.refreshAt = G.now(); return; }
                    if (G.now() - run.lay.refreshAt < 6000) return;
                    var stand = run.lay.plan[run.lay.i].filter(function (t) { return G.campAlive(t); });
                    var lateBy = Math.round((G.now() - run.lay.stillAt) / 1000);
                    if (stand.length) return stop(run.names[run.round] + ": layer " + (run.lay.i + 1) + ": camp(s) " + stand.join(",") + " survived; check losses before going on");
                    say(run.names[run.round] + ": layer " + (run.lay.i + 1) + " done, island still" + (lateBy > 0 ? " (" + lateBy + " s after the expected time)" : ""));
                    run.lay.i += 1; return sendLayer(part(run.packets[run.round]));
                }
                var pf = run.packets[run.round], alive = targets(pf).filter(function (t) { return G.campAlive(t) && !waveOnly(pf, t, run.packets.slice(run.round + 1)); });   // 0.2.130: a camp only weakened in this step is not waited for
                var i6 = G.inspect(pf), busyF = Object.keys(i6.generals).filter(function (k) { return i6.generals[k].here && !i6.generals[k].idle; });
                /* 0.2.9 (live YWC 2026-10-31: all camps gone, the run waited in FIGHT and Return was never pressed): a general
                   that lost (ghost/blocker) recovers and stays "busy"; with no camp left the last round does not wait for it,
                   other rounds wait at most 3 minutes */
                var lastRound = run.round >= run.packets.length - 1;
                var fin9 = run.zone != null && G.advStatus ? G.advStatus(run.zone) : null;   // 0.2.9: the game says the adventure is won/lost
                if (fin9 === 2 || fin9 === 3) { run.lastQuest = run.lastQuest || fin9 === 2; return go("FINISH", "the game marks the adventure " + (fin9 === 2 ? "won" : "lost")); }
                if (!alive.length && (!busyF.length || lastRound || late(180000))) {
                    /* 0.2.51 (ADR 0066): a camp that was only blocked falls with its leader; if it still stands 30 s after the
                       leader, this adventure does not clear a sector with its leader — stop, the full version must be played */
                    var blk = []; blockIds(pf).forEach(function (k) { var t = pf[k].target; if (blk.indexOf(t) < 0) blk.push(t); });
                    var stillB = blk.filter(function (t) { return G.campAlive(t); });
                    if (stillB.length) { if (!run.blkGoneAt) run.blkGoneAt = G.now(); if (G.now() - run.blkGoneAt < 30000) return;
                        return stop(run.names[run.round] + ": blocked camp(s) " + stillB.join(",") + " still stand after their leader fell — this adventure does not clear a sector with its leader; play the full version"); }
                    run.blkGoneAt = 0;
                    say(run.names[run.round] + ": camps gone" + (busyF.length ? " (" + busyF.length + " generals still recovering)" : ""));
                    if (run.starNeeded == null) { var lgR = landing(run.res); run.starNeeded = run.rules.starMethod !== false; }   // 0.2.115: after a restart
                    var next = run.packets[run.round + 1] || {}, keep = generalIds(next);
                    /* 0.2.116 (ADR 0091): the first attack's generals go home, not to the star, when the rule says so */
                    if (run.round === 1 && run.rules.aheadHome && run.packets.length > 2) {
                        var ahead = generalIds(pf).filter(function (k) { return keep.indexOf(k) < 0; });
                        if (ahead.length) { run.aheadHome = { keys: ahead, sent: {} }; say(run.names[run.round] + ": " + ahead.length + " generals of the first attack go home when they are free"); }
                    }
                    /* 0.2.122 (live YWC 2026-11-21 17:13Z: in the whole fight no troop was loose; at "camps gone" of the last attack the
                       13 idle generals went to the star, which empties a general — 2 569 troops loose, 1 068 left in the 7 recovering
                       ones): after the last round no general goes to the star; they keep their troops and go home loaded */
                    if (run.starNeeded && !lastRound) {
                        var ah = run.aheadHome ? run.aheadHome.keys : [];
                        var back = G.idleOnIsland().filter(function (k) { return keep.indexOf(k) < 0 && ah.indexOf(k) < 0; });
                        if (back.length) G.toStar(back);
                    }
                    run.round += 1; run.resumed = false; return go("LOADR");   // 0.2.32
                }
                var sig = alive.length + "|" + busyF.slice().sort().join(",");   // 0.2.45 (3): a picture that does not change for 10 minutes is refreshed once
                if (sig !== run.fightSig) { run.fightSig = sig; run.fightSigAt = G.now();
                    /* 0.2.121 (live YWC 16:21Z: the MM of the first eleven generals ended loose, the last five kept theirs): every change in
                       the fight (a camp falls, a general goes idle) is measured — each general's army and the loose troops — at most once in 30 s */
                    if (run.zone && G.viewedZone() === run.zone && (!run.fightTroopAt || G.now() - run.fightTroopAt >= 30000)) { run.fightTroopAt = G.now(); troopCount("in the fight (" + alive.length + " camps, " + busyF.length + " busy)"); } }
                else if (G.refresh && G.now() - run.fightSigAt > 600000 && (!run.refreshAt || G.now() - run.refreshAt > 600000)) { run.refreshAt = G.now(); G.refresh(); say(run.names[run.round] + ": no change for 10 minutes, zone refreshed"); }
                if (late(T.round)) return stop(run.names[run.round] + ": " + alive.length + " camps still standing after 40 minutes");
                if (alive.length && !busyF.length && late(90000)) return stop(run.names[run.round] + ": " + alive.length + " camp(s) survived the attack (generals idle); check losses before going on");
                /* 0.2.172 (live FT 2026-11-26 16:44-17:02Z and 10:28-10:44Z: "1 camps, 2 busy ... no change for 10 minutes" - the two
                   "busy" generals were beaten and recovering, which takes hours, and FIGHT waited its 40 minutes for them): a
                   recovering general fights no more. When camps stand and every general of the step that is not idle is
                   recovering - nobody on its way, fighting or walking back - for 90 s, with the attack sent and no arrow in
                   flight (untakenFight above), the step is judged at once and names the camps and the beaten generals. */
                var recF = busyF.filter(function (k) { return i6.generals[k].recovering; });
                if (alive.length && busyF.length && recF.length === busyF.length) {
                    if (!run.quietAt) run.quietAt = G.now();
                    if (G.now() - run.quietAt >= 90000) { run.quietAt = 0;
                        return stop(run.names[run.round] + ": " + alive.length + " camp(s) survived the attack (" + alive.join(",") + "): " + recF.map(function (k) { return String((pf[k] || {}).name || k).replace(/<[^>]*>/g, "").trim().split(" ")[0]; }).join(", ") + " beaten and recovering, no general on its way or fighting; check losses before going on"); }
                } else run.quietAt = 0;
                return;
            }
            case "FINISH": {
                if (run.tries === 0 && run.rules.closeAtOnce && !run.stowed && !run.closeFast) { run.closeFast = true; run.marshalsOut = true; say("closing at once: no wait for recovering generals; loose troops go into the free generals first (rule close at once)"); }   // 0.2.116 (ADR 0091); 0.2.120: still stows
                /* 0.2.120 (live YWC 2026-11-21 16:21Z: closing at once left 1 780 MM, 507 Sw and more loose on the island — they went home on
                   their own): closing at once skips the waits, never the stowing of loose troops into the idle generals that have room */
                if (run.tries === 0 && run.troopAt !== -1 && run.zone && G.viewedZone() === run.zone) { troopCount("at the end"); run.troopAt = -1; }   // 0.2.90
                /* 0.2.111 (live YWC 2026-11-20 14:35Z: the closing step counted 62 329 loose troops and 58 generals — the home island's,
                   not the adventure's 2 377 and 21 — and "sent 78 generals home"): stowing and sending home only while the adventure is in
                   view; otherwise wait (at most 1 minute) and then close without stowing */
                if (run.tries === 0 && run.zone != null && G.viewedZone() !== run.zone) {
                    if (!run.viewWaitAt) { run.viewWaitAt = G.now(); say("closing: waiting for the adventure to be in view"); }
                    if (G.now() - run.viewWaitAt < 60000) return;
                    if (!run.stowed) { run.stowed = true; say("closing: the adventure is not in view — loose troops not stowed"); }
                }
                if (run.tries === 0 && !run.stowed) {   // 0.2.81: loose troops into the generals before they are sent home
                    /* 0.2.88 (F17, live BB 2026-11-17 18:21Z: 2 608 loose troops stayed behind — the generals that had just
                       lost theirs were still recovering, and a recovering general is not raised): while troops lie loose and
                       generals of ours on the map are recovering, wait for them (at most 8 minutes) — an emptied general takes
                       any type */
                    if (!run.closeFast && typeof G.looseTroops === "function" && typeof G.mapGenerals === "function" && !late(8 * 60000)) {
                        var lo = G.looseTroops(), nLo = 0, xL; for (xL in lo) if (lo.hasOwnProperty(xL)) nLo += Number(lo[xL]) || 0;
                        var recG = G.mapGenerals().filter(function (gn) { return gn.onMap && !gn.idle; }).length;
                        if (nLo > 0 && recG > 0) { if (!run.stowWaitSaid) { run.stowWaitSaid = true; say(nLo + " troops loose; waiting for " + recG + " generals to recover before stowing them"); } return; }
                    }
                    /* 0.2.91 (author: "Na alle aanvallen ... zet je de marshalls op het eiland en laad je alle troepen. Als alle troepen
                       geladen zijn, hoef je alleen maar het avontuur af te melden"): the marshals come out of the star onto their
                       load spots (a placeable spot nearby if needed) before the loose troops are stowed (at most 3 minutes) */
                    if (typeof G.mapGenerals === "function" && G.move && !run.marshalsOut) {
                        var crF = carrierIds(run.packets), mgF = {}; G.mapGenerals().forEach(function (m) { mgF[m.key] = m; });
                        var inStar = crF.filter(function (k) { return mgF[k] && !mgF[k].onMap && mgF[k].idle; });
                        if (!run.marshalsAt) {
                            run.marshalsAt = G.now();
                            if (inStar.length) { var mvF = {}, takenF = Object.keys(mgF).map(function (x) { return mgF[x].grid; }).filter(function (gx) { return gx > 0; });
                                inStar.forEach(function (k) { var e = load[k], gF = e && e.grid > 0 ? e.grid : 0;
                                    if (gF && G.placeable && G.placeable(k, gF) === false && G.nearPlaceable) gF = G.nearPlaceable(k, gF, 0, takenF) || 0;
                                    if (gF) { mvF[k] = JSON.parse(JSON.stringify(e)); mvF[k].grid = gF; mvF[k].army = mgF[k].army; takenF.push(gF); } });
                                if (Object.keys(mvF).length) { G.move(mvF); say("closing: " + Object.keys(mvF).length + " marshals from the star onto the island to take the loose troops"); return; } }
                        }
                        if (inStar.length && G.now() - run.marshalsAt < 3 * 60000) return;
                        run.marshalsOut = true;
                    }
                    run.stowed = true;
                    if (run.rules.stowLoose !== false && (typeof G.rule !== "function" || G.rule("adv.stowLoose", true) !== false)) { var nS = stowLoose(G, say); if (nS) { run.stowUntil = G.now() + 1000 * (nS + 3); return; } }
                }
                if (run.tries === 0 && run.stowUntil && G.now() < run.stowUntil) return;
                if (run.tries === 0) {
                    run.tries = 1;
                    if (run.rules.collect !== false) say("collect: " + G.collect() + " collectables");
                    if (run.rules.claim !== false) { var q = G.claimQuests(); if (q.last) run.lastQuest = true; say("quests claimed " + q.claimed + ", accepted " + q.accepted + ", still open " + q.open + (run.lastQuest ? ", last quest rewarded" : "")); }
                    if (run.rules.claim !== false && !run.lastQuest && q && q.open > 0) { run.keepOpen = true; return go("DONE", "set played; the adventure still has " + q.open + " open quests, the generals stay on the island"); }   // 0.2.41
                    if (run.zone == null || G.viewedZone() === run.zone) { var mine = G.allGeneralIds(); if (mine.length) { say("sending " + mine.length + " generals home"); G.send(mine, G.homeZone()); } }   // 0.2.111: only the adventure's own generals
                    return;
                }
                if (late(30000) && run.tries === 1) {
                    /* 0.2.6: after the last quest wait (max 90 s) until the game marks the adventure finished, then press
                       "Return" the client's way; without the last quest just go home */
                    var fs = run.zone != null ? G.advStatus(run.zone) : null;
                    if (run.lastQuest && fs != null && fs !== 2 && fs !== 3 && !late(120000)) return;   // 0.2.119: an adventure already gone (status null) is not waited for
                    /* 0.2.131 (live ToW 2026-11-22 18:34Z, author: "ToW was finished just not closed"; earlier: "F2 als het avontuur open
                       blijft staan terwijl je hem wel gesloten hebt"): all camps gone, one quest claimed, but the game still marked the
                       adventure active (status 1) and the run went home without closing it. While the status stays active, every 20 s
                       the zone is refreshed (the client's F2, ZONE_REFRESH) and the quests are claimed again — a closing quest often
                       appears only after the one before was rewarded — for at most 4 minutes, before Return */
                    if (fs === 1 && !late(4 * 60000 + 30000)) {
                        if (!run.closeAt || G.now() - run.closeAt >= 20000) { run.closeAt = G.now(); run.closeTries = (run.closeTries || 0) + 1;
                            try { if (G.refresh) G.refresh(); } catch (_) {}
                            if (run.rules.claim !== false) { var q2 = G.claimQuests(); if (q2.last) run.lastQuest = true;
                                if (q2.claimed || q2.accepted || run.closeTries === 1) say("closing: the game still marks the adventure active — refreshed (F2) and claimed " + q2.claimed + ", accepted " + q2.accepted + ", open " + q2.open + (q2.last ? ", last quest rewarded" : "")); } }
                        return;
                    }
                    run.tries = 2;
                    if (run.zone != null && G.returnHome) { var rh = G.returnHome(run.zone); say("return home" + (rh.dropped ? ": adventure finished and closed" : " (adventure status " + rh.status + ")")); }
                    else G.visit(G.homeZone());
                    return;
                }
                /* 0.2.131: home but the adventure still listed: refresh (F2) and Return again, up to three times */
                if (run.tries === 2 && G.atHome() && run.zone != null && G.ownAdventure(run.res) === run.zone && (run.retAgain || 0) < 3 && G.returnHome) {
                    if (!run.retAt || G.now() - run.retAt >= 20000) { run.retAt = G.now(); run.retAgain = (run.retAgain || 0) + 1; try { if (G.refresh) G.refresh(); } catch (_) {}
                        try { if (run.rules.claim !== false) G.claimQuests(); } catch (_) {}
                        var rh2 = G.returnHome(run.zone); say("still listed at home: refreshed (F2) and Return again (" + run.retAgain + "/3)" + (rh2.dropped ? ": closed" : ", status " + rh2.status)); }
                    return;
                }
                if (run.tries === 2 && G.atHome()) {
                    var still = run.lastQuest && run.zone != null && G.ownAdventure(run.res) === run.zone;
                    if (still) say("the adventure is still listed: restart the client; if it stays, log out for 20 minutes");   // author: "soms blijft dat hangen ... restart ... soms 20 minuten uitloggen"
                    return go("DONE", "home; run took " + Math.round((G.now() - run.startedAt) / 60000) + " min" + (still ? " (adventure still listed)" : ""));
                }
                if (late(T.finish)) return stop("could not get home");
                return;
            }
            }
        }
        publish();
        return { restartSafe: function () {
                    try { var q = root.battleTimedQueue; if (q && typeof q.len === "function" && q.index < q.len()) return false; } catch (_) {}   // 0.2.53: Mundane still sends
                    return run.stopped || run.state === "DONE" || ["START", "LOAD", "SEND", "MOVE", "ATTACK"].indexOf(run.state) < 0 && !(run.queueUntil && G.now() < run.queueUntil); },
                 tick: tick, stop: function (why) { if (!run.stopped && run.state !== "DONE") { run.fixOff = true; /* 0.2.166: a stop from outside is never repaired */ stop(why || "stopped by the player"); } }, state: function () { return JSON.parse(JSON.stringify(run)); },
                 emergency: function () {   // 0.2.84 (ADR 0079): finish camp by camp from the next step on
                    if (run.stopped || run.state === "DONE") return false;
                    run.emergencyFix = null;   // 0.2.166 r3 (tester): the player's order stays, also over a repair's camp by camp
                    if (run.emergency) return true;
                    run.emergency = true; run.only = null; say("EMERGENCY: finish camp by camp (asked by the player)");
                    if (run.state === "CAMP" || run.state === "CAMPS" || (run.state === "FIGHT" && (run.sentKeys || []).length)) { run.lay = null; run.cbc = null; run.resumed = false; go("LOADR", "emergency: the step under way is waited for, then loaded again and played camp by camp"); }
                    publish(); return true; } };
    }

    /* ---------------- 0.2.0 (ADR 0035): the adventure book — versions and results per adventure ----------------
       dma-adv-book.json next to the client: { <res>: { versions: [{name, mode, folder}], def: <index>, runs: [...] } } */
    function airFile(name, obj) {
        try { var A = root.air, f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath), st = new A.FileStream();
              if (obj === undefined) { if (!f.exists) return null; st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); }
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); return obj; } catch (_) { return null; }
    }
    var bookCache = null;
    function book() { if (!bookCache) bookCache = airFile("dma-adv-book.json") || {}; return bookCache; }
    function bookSave() { airFile("dma-adv-book.json", book()); }
    /* 0.2.10: per adventure the camp map grows with every visit: camps by grid (name, most units seen) and the camp
       names the quests ask to destroy (book[res].map = { camps: {grid: {name, units}}, destroy: {name: amount}, at }) */
    function learnMap(res, m) {
        if (!res || !m || !m.camps || !m.camps.length) return false;
        var e = entry(res), map = e.map || (e.map = { camps: {}, destroy: {}, at: null }), changed = false;
        m.camps.forEach(function (c) {
            var army = c.army && Object.keys(c.army).length ? c.army : null, o = map.camps[c.grid];
            var ar = m.res && String(m.res) === String(res) ? String(res) : null;   // 0.2.126: an army is kept only when the map names this adventure
            if (!o) { map.camps[c.grid] = { name: c.name, units: c.units }; if (army && ar) { map.camps[c.grid].army = army; map.camps[c.grid].armyRes = ar; } changed = true; }
            else if (c.units > (o.units || 0)) { o.units = c.units; if (army && ar) { o.army = army; o.armyRes = ar; } changed = true; }
            else if (army && ar && (!o.army || o.armyRes !== ar) && c.units >= (o.units || 0)) { o.army = army; o.armyRes = ar; changed = true; }   // 0.2.125: the full army, seen once
        });
        m.destroy.forEach(function (d) { if (!map.destroy[d.name]) { map.destroy[d.name] = d.amount; changed = true; } });
        if (m.triggers) { var tr = map.triggers || (map.triggers = []); m.triggers.forEach(function (x) { if (tr.indexOf(x) < 0) { tr.push(x); changed = true; } }); }   // 0.2.13
        if (changed) { map.at = new Date().toISOString(); bookSave(); }
        return changed;
    }
    function entry(res) { var b = book(); if (!b[res]) b[res] = { versions: [], def: 0, runs: [] }; return b[res]; }
    /* 0.2.125 (ADR 0094): the camps' armies as the Mundane generator wants them — {grid: [[unitType, n], ...]} and names — from
       the book (the fullest army seen of each camp); a camp seen only with fewer units than at its first sighting keeps that. */
    function campArmies(res) {
        var m = (entry(res).map || {}).camps || {}, camps = {}, names = {}, n = 0;
        Object.keys(m).forEach(function (g) { var c = m[g]; if (!c.army || c.armyRes !== String(res)) return;   /* 0.2.126: armies read on this adventure only */ camps[g] = Object.keys(c.army).map(function (t) { return [t, c.army[t]]; }); names[g] = c.name; n++; });
        return { camps: camps, names: names, count: n, at: (entry(res).map || {}).at || null };
    }
    /* 0.2.115 (ADR 0092): the landing fields are a game fact of each adventure — registered from the game (source "game",
       seen in practice) and watched; a count read from a public source may be registered as map.landingOnline {n, url, at}.
       landing(res) -> { n, source: "game" | "online" | null, at, url } (the game's own reading wins). */
    function learnLanding(res, grids, tell) {
        if (!res || !grids || !grids.length) return null;
        var e = entry(res), map = e.map || (e.map = { camps: {}, destroy: {}, at: null }), old = map.landing || null;
        var gs = grids.map(Number).sort(function (a, b) { return a - b; }), same = old && old.grids && old.grids.join(",") === gs.join(",");
        if (same) return map.landing;
        map.landing = { n: gs.length, grids: gs, source: "game", at: new Date().toISOString() }; bookSave();
        if (tell) tell("landing fields of " + res + (old ? " changed: " + old.n + " → " + gs.length : ": " + gs.length) + " (read from the game)");
        return map.landing;
    }
    function landing(res) {
        var m = res && book()[res] && book()[res].map || null;
        if (m && m.landing && m.landing.n > 0) return { n: m.landing.n, source: "game", at: m.landing.at, url: null };
        if (m && m.landingOnline && m.landingOnline.n > 0) return { n: m.landingOnline.n, source: "online", at: m.landingOnline.at || null, url: m.landingOnline.url || null };
        return { n: null, source: null, at: null, url: null };
    }
    function needStar(fields, generals) { return fields > 0 ? generals > fields : null; }
    function landingRules(res) { var l = landing(res);
        return { landingSpots: l.n, landingSource: l.source === "game" ? "read from the game" + (l.at ? " " + String(l.at).slice(0, 10) : "") : l.source === "online" ? "read online" + (l.url ? ": " + l.url : "") : null, starMethod: true }; }
    var MODES = ["full", "quick loot", "hybrid", "arrows only", "test", "blocks", "without blocks", "camp by camp", "shared Mundane"];   // 0.2.84 (ADR 0079): the version kinds
    /* 0.2.78 (author 2026-11-15: "Maak de test variant zo dat de speler de mogelijkheid heeft per avontuur meerdere
       varianten aan te maken met een naam en nummer. De folder waar het in vastgelegd wordt heeft dezelfde naam"):
       a test variant is named "test NN <name>" (NN the next free number of that adventure) and lives in a folder of
       exactly that name inside the adventure's template folder; the folder is made when it does not exist. */
    function testLabel(label) { return String(label || "").replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim(); }
    function testName(n, label) { var l = testLabel(label); return "test " + (n < 10 ? "0" : "") + n + (l ? " " + l : ""); }
    function nextTestNo(res) {
        var m = 0; entry(res).versions.forEach(function (x) { var r = /^test (\d+)/.exec(x.name || ""); if (x.mode === "test" && r) m = Math.max(m, Number(r[1])); });
        return m + 1;
    }
    function addTest(res, label, base) {
        if (!base) return { ok: false, error: "no template folder for this adventure" };
        var n = nextTestNo(res), name = testName(n, label), folder = String(base).replace(/[\\\/]+$/, "") + "\\" + name;
        try { if (root.air) { var f = new root.air.File(folder); if (!f.exists) f.createDirectory(); } } catch (e) { return { ok: false, error: "folder not made: " + String(e) }; }
        var rec = saveVersion(res, { name: name, mode: "test", folder: folder, number: n });
        return { ok: true, number: n, name: rec.name, folder: rec.folder };
    }
    function saveVersion(res, v) {
        var e = entry(res), i = -1;
        e.versions.forEach(function (x, k) { if (x.name === v.name) i = k; });
        var rec = { name: String(v.name || v.mode || "version"), mode: MODES.indexOf(v.mode) >= 0 ? v.mode : "full", folder: String(v.folder || "") };
        var was = i >= 0 ? e.versions[i] : null;   // 0.2.170 (architect F5, AT129/PT42): the source and origin of a plan stay with it
        if (v.source || (was && was.source)) rec.source = String(v.source || was.source); if (v.origin != null || (was && was.origin != null)) rec.origin = String(v.origin != null ? v.origin : was.origin);
        if (rec.mode === "test") rec.number = Number(v.number) || (/^test (\d+)/.exec(rec.name) ? Number(/^test (\d+)/.exec(rec.name)[1]) : nextTestNo(res));   // 0.2.78
        if (rec.mode === "arrows only") { rec.folder = ""; rec.plan = v.plan || (i >= 0 && e.versions[i].plan) || {}; rec.analysis = analyseArrows(res, rec); }   // 0.2.11: no templates
        else rec.analysis = analyse(rec.folder, res, rec.mode);   // 0.2.1; 0.2.84 res and kind: a version always carries its analysis
        if (i >= 0) e.versions[i] = rec; else e.versions.push(rec);
        bookSave(); return rec;
    }
    function removeVersion(res, name) { var e = entry(res); e.versions = e.versions.filter(function (x) { return x.name !== name; }); if (e.def >= e.versions.length) e.def = 0; bookSave(); }
    function setDefault(res, name) { var e = entry(res); e.versions.forEach(function (x, k) { if (x.name === name) e.def = k; }); bookSave(); }
    function recordRun(res, version, st) {
        var e = entry(res); e.runs.push({ at: new Date().toISOString(), version: version || "", state: st.state, reason: st.reason || "", min: Math.round((Date.now() - st.startedAt) / 60000), rounds: st.round, troops: st.troopLog || [], phases: st.phases || [] });   // 0.2.90: troops per round; 0.2.92: phases with times
        e.runs = e.runs.slice(-10); bookSave();
    }
    /* 0.2.1 (author: "de analyse op adventure niveau ... automatisch doen en meegeven met de versie" — "een agent kan in
       de gaten houden of een adventure is aangepast ... of dat er een nieuw adventure beschikbaar is"):
       every version carries its analysis (run order, load template, generals, findings, folder signature); the watch
       re-analyses a version whose folder changed, adopts a found folder as version "full" when the analysis finds a
       load and rounds, and lists star adventures the catalogue does not know. */
    function folderSig(folder) {
        try { var A = root.air, d = new A.File(folder); if (!d.exists || !d.isDirectory) return ""; var parts = [];
              d.getDirectoryListing().forEach(function (f) { if (!f.isDirectory && !f.isHidden) parts.push(f.name + ":" + (f.modificationDate ? f.modificationDate.getTime() : 0) + ":" + f.size); });
              return parts.sort().join("|"); } catch (_) { return ""; }
    }
    function summarize(a, sig) {
        var c = { error: 0, warn: 0, info: 0 }; (a.findings || []).forEach(function (f) { c[f.level] = (c[f.level] || 0) + 1; });
        return { at: new Date().toISOString(), sig: sig, run: a.run || [], load: (a.choices && a.choices.loadTemplate) || "", generals: (a.choices && a.choices.generals) || 0,
                 findings: c, ok: !!(a.choices && a.choices.loadTemplate && (a.run || []).length >= 2) };
    }
    function analyse(folder, res, mode) {
        var M = root.DMA_Mundane; if (!M || !M.analyzeAir) return null;
        var r = M.analyzeAir(folder, landingRules(res)); var a = r && r[0];   // 0.2.115 (ADR 0092)
        if (!a || a.error) return { at: new Date().toISOString(), sig: folderSig(folder), run: [], load: "", generals: 0, findings: { error: 1, warn: 0, info: 0 }, ok: false, error: (a && a.error) || "no templates" };
        return adviseBlocks(summarize(a, folderSig(folder)), a, res, mode);
    }
    /* 0.2.88 (ADR 0080, F16b; author 2026-11-17: "En er wordt te weinig meegenomen in eerste instantie" — "Maak die marges
       groter bij en avontuur waar bijgeladen moet worden"): a version that reloads between waves must carry, per unit type,
       what every wave needs plus what the waves before it are expected to lose, plus the margin. Expected loss of a wave:
       its ranged units (marksmen, bowmen, cannoneers) 10 %, every other unit 100 % (the front line of a wave is assumed
       spent). Wave 1 needs no margin — the load template carries its armies exactly. Pure: packets[0] is the load. */
    function waveLoadCheck(packets, opts) {
        opts = opts || {}; var margin = opts.margin != null ? Number(opts.margin) : 0.25;
        function tot(p) { var c = {}; Object.keys(p || {}).forEach(function (k) { var e = p[k]; if (!e || e.type === "buff" || e.type === "speedbuff") return; Object.keys(e.army || {}).forEach(function (u) { c[u] = (c[u] || 0) + (Number(e.army[u]) || 0); }); }); return c; }
        function lossShare(u) { return opts.loss && opts.loss[u] != null ? Number(opts.loss[u]) : (/Marksman|Bowman|Archer|Crossbow|Cannoneer/i.test(u) ? 0.1 : 1); }
        var have = tot(packets[0]), waves = (packets || []).slice(1).map(tot), req = {}, lost = {}, short = {};
        waves.forEach(function (w, i) {
            Object.keys(w).forEach(function (u) { var need = (w[u] || 0) + (lost[u] || 0); need = i === 0 ? (w[u] || 0) : Math.ceil(need * (1 + margin)); if (!(req[u] >= need)) req[u] = need; });
            Object.keys(w).forEach(function (u) { lost[u] = (lost[u] || 0) + Math.round((w[u] || 0) * lossShare(u)); });
        });
        Object.keys(req).forEach(function (u) { if ((have[u] || 0) < req[u]) short[u] = req[u] - (have[u] || 0); });
        return { have: have, req: req, short: short, waves: waves.length };
    }
    /* 0.2.84 (ADR 0079): block entries against the adventure's advice and the version's kind */
    function adviseBlocks(sum, a, res, mode) {
        var n = 0; (a.run || []).forEach(function (nm) { try { n += blockIds(toPacket((a.texts || {})[nm])).length; } catch (_) {} });
        var C = root.DMA_AdvCatalogue, adv = C && C.advice && res ? C.advice(res) : [];
        sum.blocks = n; sum.advice = adv; sum.notes = [];
        if (n && C && C.noBlocks && C.noBlocks(res)) { sum.findings.warn = (sum.findings.warn || 0) + 1; sum.notes.push({ level: "warn", code: "NO_BLOCKS_ADVISED", msg: n + " block entries: this adventure is advised to be played without blocks" }); }
        if (n && mode === "without blocks") { sum.findings.error = (sum.findings.error || 0) + 1; sum.notes.push({ level: "error", code: "BLOCKS_IN_WAVES", msg: n + " block entries in a version without blocks" }); }
        if (a.shared) sum.shared = { notCovered: a.shared.camps.notCovered, generals: a.shared.rows.length };
        if (mode === "without blocks" && (a.run || []).length >= 3) {   // 0.2.88 (ADR 0080): more than one wave — the load must carry them all
            try { var mg = 0.25; try { var P8 = root.GCAF_PlayerPolicyInstance, rv = P8 && P8.get ? P8.get("adv.waves.loadMargin") : null; if (rv != null && !isNaN(Number(rv))) mg = Number(rv); } catch (_) {}
                  var wc = waveLoadCheck((a.run || []).map(function (nm) { return toPacket((a.texts || {})[nm]); }), { margin: mg });
                  sum.loadCheck = { margin: mg, have: wc.have, req: wc.req, short: wc.short };
                  var sk = Object.keys(wc.short);
                  if (sk.length) { sum.findings.error = (sum.findings.error || 0) + 1; sum.ok = false;
                      sum.notes.push({ level: "error", code: "LOAD_SHORT", msg: "the load carries too little for " + wc.waves + " waves (margin " + Math.round(mg * 100) + " %): short " + sk.map(function (u) { return wc.short[u] + " " + u; }).join(", ") + " — add a carrier (a quartermaster or a general that does not fight) or lower the waves" }); } } catch (_) {}
        }
        return sum;
    }
    var watchState = { at: null, analysed: 0, adopted: 0, changed: [], unknown: [] };
    function watch(opts) {
        opts = opts || {}; var C = root.DMA_AdvCatalogue, star = {}, limit = opts.limit || 4, n = 0;
        try { star = gameGateway().starCounts(); } catch (_) {}
        watchState = { at: new Date().toISOString(), analysed: 0, adopted: 0, changed: [], unknown: [] };
        Object.keys(star).forEach(function (res) { if (C && !C.byRes(res)) watchState.unknown.push(res); });
        var b = book();
        Object.keys(b).forEach(function (res) {
            (b[res].versions || []).forEach(function (v) {
                if (n >= limit) return;
                if (v.mode === "arrows only") { v.folder = ""; v.analysis = analyseArrows(res, v); return; }   // 0.2.11
                var sig = folderSig(v.folder);
                var stale = v.analysis && v.analysis.findings && v.analysis.findings.error > 0;   // 0.2.27: an error can be passing (generals away when it was analysed); look again
                if (!v.analysis || v.analysis.sig !== sig || stale) { if (v.analysis) watchState.changed.push(res + "/" + v.name); v.analysis = analyse(v.folder, res, v.mode); n++; watchState.analysed++; }
            });
        });
        if (opts.guess) Object.keys(star).forEach(function (res) {
            if (n >= limit) return; var e = b[res]; if (e && e.versions && e.versions.length) return;
            var folder = opts.guess(res); if (!folder) return;
            var an = analyse(folder, res, "full"); n++; watchState.analysed++;
            if (an && an.ok) { entry(res).versions.push({ name: "full", mode: "full", folder: folder, analysis: an, auto: true }); watchState.adopted++; }
            else { entry(res).found = { folder: folder, analysis: an }; }
        });
        bookSave();
        return JSON.parse(JSON.stringify(watchState));
    }
    function resOf(id) { if (RES[id]) return RES[id]; var C = root.DMA_AdvCatalogue; return (C && C.byRes(id)) ? id : (/^[A-Za-z0-9_]+$/.test(String(id)) && id.length > 4 ? id : null); }

    /* ---------------- the console's entry: run once ---------------- */
    var current = null, timer = null;
    /* 0.1.2: the run survives a client restart: dma-adv-run.json {id, source, active}; 90 s after load an active run
       resumes (PRECHECK picks up the open adventure where it is) */
    function runFile(obj) {
        try { var A = root.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-adv-run.json").nativePath), st = new A.FileStream();
              if (obj === undefined) { if (!f.exists) return null; st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); }
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); } catch (_) { return null; }
        return obj;
    }
    function rulesFor(id) {
        /* 0.2.107 (live YWC 2026-11-20 13:44Z: started from the Run card with the star name "1001NightsWoodcutter", the run read
           adv.1001NightsWoodcutter.asIs — none — so "play my Mundane as it is" was off, camp by camp was on, and GHOST1, meant to be
           intercepted, was held back): a star name is read as the console's short key (ywc) for the per-adventure rules */
        if (id && !RES[id]) { for (var rk in RES) if (RES.hasOwnProperty(rk) && RES[rk] === id) { id = rk; break; } }
        var P = root.GCAF_PlayerPolicyInstance, get = function (k, d) { try { var v = P && P.get ? P.get(k) : undefined; return v == null ? d : v; } catch (_) { return d; } };
        var tv = get("adv.travel", []); if (typeof tv === "string") tv = tv.split(",");
        return { travel: (tv || []).map(function (x) { return String(x).trim(); }).filter(Boolean), prestage: get("adv.prestage", true) !== false, minStock: get("adv." + id + ".minStock", 0), checkArmy: get("adv." + id + ".checkArmy", true), collect: get("adv." + id + ".collect", true),
                 claim: get("adv." + id + ".claim", true), starMethod: get("adv.mundane.starMethod", true) === true,
                 blocks: get("adv.blocks.on", false) === true, blockMarginSec: Number(get("adv.blocks.marginSec", 5)) || 5, blockSpeedBuff: get("adv.blocks.speedBuff", "GeneralSpeedBuff_Blackened_Titanium"), retreat: get("adv." + id + ".retreat", get("adv.retreat.on", true)) !== false, asIs: true /* 0.2.169 (B13, R-PLAN-AS-WRITTEN): always */,
                 aheadHome: get("adv." + id + ".aheadHome", get("adv.aheadHome", false)) === true, closeAtOnce: get("adv." + id + ".closeAtOnce", get("adv.closeAtOnce", false)) === true, /* 0.2.116 (ADR 0091) */ campByCamp: false /* 0.2.169 (B13): only a version of kind "camp by camp" */, relearn: get("adv.relearn.on", true) !== false, selfRepair: get("adv.selfRepair", true) !== false /* 0.2.166 (ADR 0102) */ };   // 0.2.51 (ADR 0066): the player's permission for blocks
    }
    /* ---------------- 0.2.11: arrows only (ADR 0035 addendum 5; author: "als je alleen arrows selecteert, hoeft hij niet
       naar een template te zoeken") — no generals, no templates: start, go there, per camp to destroy the player's plan
       of arrows (each step: apply, wait until the unit count settles, camp gone -> next camp), quests, Return. ---- */
    var DEFAULT_PLAN = [{ arrow: "Rain of Flaming Arrows", max: 1 }, { arrow: "Cupid's Arrow", max: 5 }];   // author's GP demonstration
    function defaultPlan() {   // the GP rules on the ADVS page (adv.gp.arrowFirst / arrowThen) when set
        try { var P = root.GCAF_PlayerPolicyInstance, a = P && P.get ? P.get("adv.gp.arrowFirst") : null, b = P && P.get ? P.get("adv.gp.arrowThen") : null;
              if (a || b) return [{ arrow: String(a || DEFAULT_PLAN[0].arrow), max: 1 }, { arrow: String(b || DEFAULT_PLAN[1].arrow), max: 5 }]; } catch (_) {}
        return DEFAULT_PLAN;
    }
    function planFor(ver, campName, grid) { var p = ver && ver.plan && ((grid != null && ver.plan["#" + grid]) || ver.plan[campName] || ver.plan["*"]); return p && p.length ? p : defaultPlan(); }   // 0.2.169 (B14 beta): a per-camp plan "#<grid>"
    function arrowTargets(res, ver) {   // the camps to destroy: quest names from the map, else the plan's own camp names
        var e = entry(res), map = e.map || { camps: {}, destroy: {} }, names = Object.keys(map.destroy || {}), out = [];
        /* 0.2.169 (B14 beta): a generated plan names its camps by grid ("#<grid>": the quest camps and the camps on their way) — those are the targets */
        var byGrid = ver && ver.plan ? Object.keys(ver.plan).filter(function (n) { return /^#\d+$/.test(n); }).map(function (n) { return Number(n.slice(1)); }) : [];
        if (byGrid.length) { byGrid.forEach(function (g) { var c = (map.camps || {})[g]; out.push({ grid: g, name: c ? c.name : "camp " + g }); }); return { names: byGrid.map(function (g) { return "#" + g; }), camps: out }; }
        if (!names.length && ver && ver.plan) names = Object.keys(ver.plan).filter(function (n) { return n !== "*"; });
        if (!names.length) { var seen = {}; Object.keys(map.camps || {}).forEach(function (g) { var c = map.camps[g]; if (c.units > 0 && /castle/i.test(c.name)) seen[c.name] = 1; }); names = Object.keys(seen); }   // 0.2.13: "Defeat all black castles" — the castles on the map
        Object.keys(map.camps || {}).forEach(function (grid) { var c = map.camps[grid]; if (names.indexOf(c.name) >= 0 && !(ver.plan && ver.plan[c.name] === "skip")) out.push({ grid: Number(grid), name: c.name }); });
        return { names: names, camps: out };
    }
    function analyseArrows(res, ver) {
        var t = arrowTargets(res, ver), f = [];
        if (!t.names.length) f.push("the camps to destroy are not known yet: visit or play this adventure once");
        else if (!t.camps.length) f.push("the camps " + t.names.join(", ") + " were not seen on the map yet");
        return { at: new Date().toISOString(), arrows: true, targets: t.camps, names: t.names, findings: { error: f.length, warn: 0, info: 0 }, ok: !f.length, error: f[0] || "" };
    }
    /* ---------------- 0.2.12: learning by demonstration (author: "eerst voorgedaan hoe de speler het wil, en dat wordt
       opgeslagen en nagedaan. Als je het wil wijzigen, dan doe je het weer een keer voor waarbij je kunt aangeven dat
       hij die moet vervangen, of zelfs als een tweede versie opslaan") ----------------
       Start learning for an adventure on the ADVS page; the player plays; every server action on our open adventure of
       that kind is noted (arrows: which arrow on which camp, units before; other actions kept raw for later replay).
       Stop: the demonstration becomes a version — "replace" overwrites the version of that name, otherwise a new name.
       Arrows learned become the plan per camp, in the order and number the player used. */
    var learning = null;
    function learnFile(obj) { return airFile("dma-adv-learn.json", obj); }
    function startLearning(res, name, replace) {
        learning = { res: res, name: String(name || "learned"), replace: !!replace, startedAt: new Date().toISOString(), startedAtMs: Date.now(), steps: [] };   // 0.2.26: ms (the client cannot Date.parse an ISO date)
        learnFile(learning); hookLearning(); observeStart(); return learning;
    }
    /* 0.2.13 (live 2026-10-31: the GP demonstration recorded 0 actions — the game's own clicks do not pass the
       script-side SendServerAction): learning OBSERVES instead. Every 1.5 s on our open adventure of that kind: the
       arrows in the star and the units per camp. An arrow count that drops is an arrow used; it is put on the camp that
       loses units within the next 6 s (most units lost). Generals: their grid and whether they are busy, noted as
       moves / attacks (for the later replay). */
    var obs = null, obsTimer = null;
    function observeStart() { if (!obsTimer) obsTimer = bg(setInterval(function () { try { observeTick(); } catch (_) {} }, 1500)); }
    function observeTick(G) {
        if (!learning) { obs = null; return; }
        G = G || gameGateway();
        var mine = G.ownAdventure(learning.res); if (mine == null || G.viewedZone() !== mine || (current && current.state && ["DONE", "STOPPED"].indexOf(current.state().state) < 0)) { obs = null; return; }
        var arr = G.arrows(), m = G.campMap(), units = {}, names = {}, now = G.now();
        try { learnMap(learning.res, m); } catch (_) {}
        m.camps.forEach(function (c) { if (c.units > 0 || (obs && obs.units[c.grid] > 0)) { units[c.grid] = c.units; names[c.grid] = c.name; } });
        var gens = G.generalsHere ? G.generalsHere() : {};
        if (obs) {
            Object.keys(obs.arrows).forEach(function (d) { var was = obs.arrows[d].count, is = arr[d] ? arr[d].count : 0;
                for (var k = 0; k < was - is; k++) obs.pending.push({ def: d, arrow: obs.arrows[d].name, at: now, before: JSON.parse(JSON.stringify(obs.units)) }); });
            obs.pending = obs.pending.filter(function (pa) {   // attribute: the camp with the largest loss since the arrow
                /* 0.2.15 (live GP: the Cupid's Arrow that finished the castle went to a dark camp that vanished with it):
                   among the camps that lost units, a camp the quests ask to destroy first, then the camp of the previous
                   arrow, then the largest loss */
                var lost = {}, best = null, loss = 0, tgt = targetNames(learning.res), prev = null;
                for (var q = learning.steps.length - 1; q >= 0; q--) if (learning.steps[q].kind === "arrow") { prev = String(learning.steps[q].grid); break; }
                Object.keys(pa.before).forEach(function (g) { var l = (pa.before[g] || 0) - (units[g] || 0); if (l > 0) lost[g] = l; });
                var cand = Object.keys(lost), pick = cand.filter(function (g) { return tgt.indexOf(names[g] || obs.names[g]) >= 0; });
                if (!pick.length && prev && lost[prev]) pick = [prev];
                if (!pick.length) pick = cand;
                pick.forEach(function (g) { if (lost[g] > loss) { loss = lost[g]; best = g; } });
                if (best && (loss > 0) && (now - pa.at >= 3000 || !units[best])) { learning.steps.push({ at: new Date(now).toISOString(), kind: "arrow", arrow: pa.arrow, def: pa.def, camp: names[best] || obs.names[best] || "", grid: Number(best), units: pa.before[best], lost: loss }); learnFile(learning); return false; }
                if (now - pa.at > 8000) { learning.steps.push({ at: new Date(now).toISOString(), kind: "arrow", arrow: pa.arrow, def: pa.def, camp: "", grid: 0, note: "no camp lost units" }); learnFile(learning); return false; }
                return true;
            });
            Object.keys(gens).forEach(function (id) { var a = obs.gens[id], b = gens[id]; if (!a || !b) return;
                if (a.grid !== b.grid) { learning.steps.push({ at: new Date(now).toISOString(), kind: "move", general: id, name: b.name, from: a.grid, grid: b.grid }); learnFile(learning); }
                if (!a.busy && b.busy) { learning.steps.push({ at: new Date(now).toISOString(), kind: "busy", general: id, name: b.name, grid: b.grid, note: "attack or move started" }); learnFile(learning); } });
        }
        /* 0.2.14 (author: "leert het ook de ls communicatie?" — "de demo actiehandelingen moeten ondersteund worden"):
           the chat lines (own and others, with channel) and the invited players of the adventure */
        var CH = root.DMA_Chat, own = ""; try { own = String(CH && CH.ownName ? CH.ownName() : "").toLowerCase(); } catch (_) {}
        try { (CH && CH.recent ? CH.recent(obs ? obs.chatAt : (learning.startedAtMs || Date.now())) : []).forEach(function (l) {
            learning.steps.push({ at: new Date(l.at).toISOString(), kind: own && l.sender.toLowerCase() === own ? "say" : "chat", channel: l.channel, sender: l.sender, text: l.text }); learnFile(learning); }); } catch (_) {}
        var players = G.advPlayers ? G.advPlayers(mine) : {};
        if (obs) Object.keys(players).forEach(function (nm) { var was = obs.players[nm], is = players[nm];
            if (was === undefined) { learning.steps.push({ at: new Date(now).toISOString(), kind: "invite", player: nm, status: is }); learnFile(learning); }
            else if (was !== is) { learning.steps.push({ at: new Date(now).toISOString(), kind: is === 1 ? "joined" : is === 3 ? "left" : is === 2 ? "declined" : "player", player: nm, status: is }); learnFile(learning); } });
        var ac = {}; Object.keys(arr).forEach(function (d) { ac[d] = { name: arr[d].name, count: arr[d].count }; });
        obs = { arrows: ac, units: units, names: names, gens: gens, pending: obs ? obs.pending : [], chatAt: Date.now(), players: players };
    }
    function decodeAction(a) {
        var G = gameGateway(), R = root, nr = a[0], out = { at: new Date().toISOString(), nr: nr };
        try { out.zone = R.game.gi.mCurrentViewedZoneID; } catch (_) {}
        if (nr === 61 && a[2]) {   // a buff on a building: on a camp an arrow
            out.kind = "buff"; out.grid = a[2];
            try { var u = a[4]; R.game.gi.mCurrentPlayer.getAvailableBuffs_vector().forEach(function (b) { try { var id = b.GetUniqueId(); if (u && id.uniqueID1 === u.uniqueID1 && id.uniqueID2 === u.uniqueID2) { out.def = b.GetBuffDefinition().GetName_string(); out.arrow = String(b.getName ? b.getName() : out.def); } } catch (_) {} }); } catch (_) {}
            try { var bd = R.game.zone.mStreetDataMap.GetBuildingByGridPos(a[2]); out.camp = bd ? String(bd.GetBuildingName_string()) : ""; out.units = G.campUnits(a[2]); } catch (_) {}
            if (out.def && out.def.indexOf("BattleBuff") === 0) out.kind = "arrow";
        } else { out.kind = "other"; out.args = a.slice(1, 4).map(function (x) { return x == null ? null : typeof x === "object" ? "obj" : x; }); }
        return out;
    }
    var learnHooked = false;
    function hookLearning() {
        if (learnHooked) return; var C = root.DMA_Control; if (!C || !C.onServerAction) return;
        learnHooked = true;
        C.onServerAction(function (a) {
            if (!learning) return;
            var mine = null; try { mine = gameGateway().ownAdventure(learning.res); } catch (_) {}
            var vz = null; try { vz = root.game.gi.mCurrentViewedZoneID; } catch (_) {}
            if (a[0] === 61 && !a[2]) { learning.steps.push({ at: new Date().toISOString(), kind: "start", nr: 61 }); learnFile(learning); return; }   // the star item (start) or a zone buff
            if (mine == null || vz !== mine) return;
            if (current && current.state && current.state().state !== "DONE" && !current.state().stopped) return;   // our own run is not a demonstration
            learning.steps.push(decodeAction(a)); learnFile(learning);
        });
    }
    function stopLearning(save) {
        var L = learning; learning = null; learnFile({ stopped: true, at: new Date().toISOString() });
        if (!L || !save) return { ok: true, saved: false };
        var arrows = L.steps.filter(function (x) { return x.kind === "arrow"; }), others = L.steps.filter(function (x) { return x.kind === "move" || x.kind === "busy" || x.kind === "other"; });
        var plan = planFromSteps(L.res, L.steps);   // 0.2.15
        var e = entry(L.res), name = L.name;
        if (!L.replace) { var taken = {}; e.versions.forEach(function (v) { taken[v.name] = 1; }); var n = 2, base = name; while (taken[name]) name = base + " " + n++; }
        var mode = others.length ? "full" : "arrows only";
        /* 0.2.25 (live TT demonstration: generals moved and attacked): a demonstration with generals is a hybrid version on
           the templates of the adventure's default version (the generals come from its Mundane templates); the arrows
           learned stay with it as its plan. Arrows alone stay "arrows only". */
        var dv0 = (e.versions || [])[e.def || 0], folder0 = dv0 && dv0.mode !== "arrows only" ? dv0.folder : "";
        var rec = others.length && folder0 ? saveVersion(L.res, { name: name, mode: "hybrid", folder: folder0 }) : saveVersion(L.res, { name: name, mode: "arrows only", plan: plan });
        if (rec.mode === "hybrid") rec.plan = plan;
        /* 0.2.26 (live TT: 250 chat lines filled the 300 kept steps; the attacks after 18:21 were lost): every action is
           kept; the chat only for its last 150 lines */
        var acts = L.steps.filter(function (x) { return x.kind !== "chat" && x.kind !== "say"; }), talk = L.steps.filter(function (x) { return x.kind === "chat" || x.kind === "say"; }).slice(-150);
        rec.learned = { at: L.startedAt, arrows: arrows.length, other: others.length, steps: acts.concat(talk).sort(function (a, b) { return String(a.at) < String(b.at) ? -1 : 1; }) };
        var ls = learnLs(L.steps, L.startedAt); if (ls && ls.spots) rec.ls = ls; else delete rec.ls;   // 0.2.14; 0.2.26: only a loot-spot flow with invitations
        if (others.length) rec.learned.note = others.length + " other actions (generals) recorded; their replay comes in a later version";
        bookSave();
        return { ok: true, saved: true, name: name, mode: mode, arrows: arrows.length, other: others.length, plan: plan };
    }
    /* 0.2.14: the loot-spot communication of a demonstration: the own guild line that offers the spots, who answered,
       who was invited, the own announcement (names as {players}), the kills reported, and the wait in between */
    function targetNames(res) { try { var m = entry(res).map || {}, n = Object.keys(m.destroy || {}); if (n.length) return n; var c = {}; Object.keys(m.camps || {}).forEach(function (g) { if (/castle/i.test(m.camps[g].name)) c[m.camps[g].name] = 1; }); return Object.keys(c); } catch (_) { return []; } }
    /* 0.2.15: re-attribute learned arrows: an arrow on a non-target camp right after an arrow on a target camp (within
       30 s) belongs to that target (its camps vanish with it) */
    function planFromSteps(res, steps) {
        var tgt = targetNames(res), plan = {}, prevT = null;
        steps.filter(function (x) { return x.kind === "arrow"; }).forEach(function (x) {
            var camp = x.camp || "*", t = Date.parse(x.at) || 0;
            if (tgt.indexOf(camp) >= 0) prevT = { camp: camp, t: t };
            else if (prevT && t - prevT.t <= 30000) camp = prevT.camp;
            var p = plan[camp] || (plan[camp] = []), last = p[p.length - 1];
            if (last && last.arrow === x.arrow) last.max += 1; else p.push({ arrow: x.arrow, max: 1 });
        });
        return plan;
    }
    function learnLs(steps, sinceIso) {
        if (sinceIso) steps = steps.filter(function (x) { return !x.at || String(x.at) >= String(sinceIso); });   // 0.2.26: not the chat from before the demonstration
        var offer = null, invited = [], announce = null, kills = [], asked = [];
        steps.forEach(function (x) {
            if (x.kind === "say" && !offer && /\bls\b/i.test(x.text)) offer = { text: x.text, channel: x.channel, at: x.at };
            else if (x.kind === "chat" && offer && !invited.length && x.channel === offer.channel) asked.push({ sender: x.sender, text: x.text });
            else if (x.kind === "invite") invited.push(x.player);
            else if (x.kind === "say" && invited.length && !announce && invited.some(function (n) { return x.text.toLowerCase().indexOf(n.toLowerCase()) >= 0; })) {
                var t = x.text; invited.forEach(function (n, i) { t = t.replace(new RegExp(n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), "{player" + (i + 1) + "}"); }); announce = { text: t, channel: x.channel };   // 0.2.15: names in any case
            } else if (x.kind === "chat" && invited.some(function (n) { return n.toLowerCase() === String(x.sender).toLowerCase(); }) && /\bk\.?d\b|kill/i.test(x.text)) kills.push({ sender: x.sender, text: x.text, channel: x.channel });
        });
        if (!offer && !invited.length) return null;
        var seenW = {}, words = asked.filter(function (a) { var k = a.sender.toLowerCase(); if (seenW[k] || !invited.some(function (n) { return n.toLowerCase() === k; })) return false; seenW[k] = 1; return true; }).map(function (a) { return a.text; });   // 0.2.15: the first answer per invited player
        return { offer: offer, spots: invited.length, requestWords: words, invited: invited, announce: announce, kills: kills.length, killWords: kills.map(function (k) { return k.text; }), approved: false };
    }
    try { var bk0 = book(); Object.keys(bk0).forEach(function (r) { (bk0[r].versions || []).forEach(function (v) { if (v.learned && v.learned.steps && v.learned.steps.length && !v.replanned) { v.plan = planFromSteps(r, v.learned.steps); var l2 = learnLs(v.learned.steps); if (l2) v.ls = l2; v.replanned = VERSION; if (v.mode === "arrows only") v.analysis = analyseArrows(r, v); }
        if (v.ls && v.learned && v.learned.at && (!v.ls.spots || (v.ls.offer && String(v.ls.offer.at) < String(v.learned.at)))) delete v.ls;   // 0.2.26
        }); }); bookSave(); } catch (_) {}   // 0.2.15; 0.2.28: the 0.2.17 one-time approval for the author's Gunpowder is gone — every other player approves his own loot-spot lines with the checkbox
    try { var lf0 = learnFile(); if (lf0 && lf0.res && !lf0.stopped) { learning = lf0; bg(setTimeout(function () { hookLearning(); observeStart(); }, 30000)); } } catch (_) {}   // a restart keeps the demonstration
    function createArrowRun(opts, G) {
        G = G || gameGateway();
        var run = { id: opts.id, res: opts.res, ver: opts.ver || {}, state: "PRECHECK", since: G.now(), zone: null, idx: 0, step: 0, used: 0, reason: "", log: [], startedAt: G.now(), stopped: false, resumeOnly: !!opts.resumeOnly, doneZones: opts.doneZones || [], targets: [] };
        function say(m) { run.log.push(new Date(G.now()).toISOString().slice(11, 19) + " " + m); if (run.log.length > 60) run.log.shift(); G.log(m); if (!(run.pubAt > 0) || G.now() - run.pubAt >= 10000) publish(); }
        function publish() { run.pubAt = G.now(); var c = run.targets[run.idx]; G.status({ version: VERSION, adventure: run.id, mode: "arrows only", state: run.state, round: run.idx, of: run.targets.length, template: c ? c.name : "", zone: run.zone, reason: run.reason, since: new Date(run.since).toISOString(), log: run.log.slice(-15) }); }
        function go(st, m) { run.state = st; run.since = G.now(); run.tries = 0; if (m) say(m); publish(); }
        function stop(r) { run.reason = r; run.stopped = true; go("STOPPED", "stopped: " + r); }
        function late(ms) { return G.now() - run.since > ms; }
        function lsOn() { return !!(run.ver && run.ver.ls && run.ver.ls.approved && G.say); }   // 0.2.17
        function step() {
            switch (run.state) {
            case "PRECHECK": {
                var open = G.ownAdventure(run.res);
                if (open && run.doneZones.indexOf(open) >= 0) return stop("the previous " + run.res + " (zone " + open + ") is still open; close it first");
                if (open) { run.zone = open; return go("TRAVEL", "resuming the open adventure, zone " + open); }
                if (run.resumeOnly) return stop("nothing to resume: no " + run.res + " of ours is open");
                var item = G.starItem(run.res); if (!item) return stop("no " + run.res + " in the star");
                var arr = G.arrows(), have = {}; Object.keys(arr).forEach(function (k) { have[arr[k].name] = arr[k].count; have[k] = arr[k].count; });
                var first = planFor(run.ver, "*")[0]; if (first && !(have[first.arrow] > 0)) say("note: no " + first.arrow + " in the star");
                var us2 = G.useStarItem(item.id);   // 0.2.83 (ADR 0073)
                if (us2 && us2.ok === false) { if (us2.retry) { say("waiting: " + us2.reason); return; } return stop("the star item was refused: " + us2.reason); }
                go("START", "starting " + run.res + " (arrows only)"); return;
            }
            case "START": { var z = G.ownAdventure(run.res); if (z) { run.zone = z; return go("TRAVEL", "adventure open, zone " + z); } if (late(120000)) return stop("the adventure did not open within 2 minutes"); return; }
            case "TRAVEL": {
                if (G.viewedZone() !== run.zone) { if (!run.tries || late(30000 * run.tries)) { run.tries = (run.tries || 0) + 1; G.visit(run.zone); } return; }
                try { learnMap(run.res, G.campMap()); } catch (_) {}
                run.targets = arrowTargets(run.res, run.ver).camps;
                if (!run.targets.length) { if (late(90000)) return stop("no camps to destroy known for " + run.res + "; set them on the ADVS page"); return; }
                if (G.collect && G.rule && G.rule("adv." + run.id + ".collect", true) !== false) { var nc = 0; try { nc = G.collect(); } catch (_) {} say("collect: " + nc + " collectables"); }   // 0.2.21 (author: "hij vergeet de collectables")
                return go("ARROW", "on the adventure; camps to destroy: " + run.targets.map(function (c) { return c.name; }).join(", "));
            }
            case "ARROW": {
                var c = run.targets[run.idx];
                if (!c) return lsOn() ? go("LS_OFFER", "all camps done; loot spots next") : go("QUESTS", "all camps done");
                var units = G.campUnits(c.grid);
                if (units <= 0) { if (run.wait && run.wait.def) arrowObserved(run.wait.def, c.name, true); say(c.name + ": gone"); if (G.collect && G.rule && G.rule("adv." + run.id + ".collect", true) !== false) { try { G.collect(); } catch (_) {} }   // 0.2.23
                    run.idx += 1; run.step = 0; run.used = 0; return go("ARROW"); }
                if (run.wait) {   // the result of the last arrow: wait until the unit count settles (max 25 s)
                    if (units !== run.wait.units) { run.wait.units = units; run.wait.at = G.now(); return; }
                    if (G.now() - run.wait.at < 6000 && G.now() - run.wait.start < 25000) return;
                    if (run.wait.def) arrowObserved(run.wait.def, c.name, false);   // 0.2.170 (F7): the game's answer, kept for the generator
                    say(c.name + ": " + units + " units left after " + run.wait.name); run.wait = null; return;
                }
                var plan = planFor(run.ver, c.name, c.grid), s = plan[run.step];
                if (!s) return stop(c.name + " still stands with " + units + " units after the whole plan");
                if (s.arrow === "general" || s.arrow === "skip") { say(c.name + ": left to " + s.arrow); run.idx += 1; run.step = 0; run.used = 0; return go("ARROW"); }
                if (run.used >= (Number(s.max) || 1)) { run.step += 1; run.used = 0; return; }
                var r = G.applyArrow(s.arrow, c.grid);
                if (!r.ok) { say(c.name + ": " + r.reason); run.step += 1; run.used = 0; return; }
                run.used += 1; run.wait = { units: units, at: G.now(), start: G.now(), name: r.name, def: r.def };
                say(c.name + ": " + r.name + " (" + units + " units, " + r.left + " left in the star)"); publish();
                return;
            }
            /* 0.2.17 (author: "nee met ls uitnodiging en alles"): the loot spots as learned from the demonstration —
               offer in the guild chat, the first who ask, invite, announce, wait for their kills; then quests and Return */
            case "LS_OFFER": if (root.DMA_LootSpots) {   // 0.2.18: the loot-spot PBC with the global rules (ADVS top)
                var nL = Number(G.rule("adv." + (run.id || "") + ".lootSpots", (run.ver.ls && run.ver.ls.spots) || 2)) || 0, Cc = root.DMA_AdvCatalogue, cat = Cc && Cc.byRes ? Cc.byRes(run.res) : null;
                var kept = null; try { var kf = airFile("dma-adv-ls.json"); if (kf && kf.ls && kf.zone === run.zone && Date.now() - kf.atMs < 3600000 && !kf.ls.done) kept = kf.ls;
                    else if (kf && kf.ls && !kf.ls.done && root.DMA_LootSpots.abandon) { root.DMA_LootSpots.abandon(kf.ls, "the run was cut off before the loot spots were closed"); airFile("dma-adv-ls.json", { zone: kf.zone, atMs: Date.now(), ls: null }); } } catch (_) {}   // 0.2.31 (P7); 0.2.44: close what cannot continue
                run.lsm = root.DMA_LootSpots.create({ n: nL, adv: lsTag(run.id, run.res, cat, Cc), zone: run.zone, restore: kept },
                    { now: G.now, say: G.say, chatSince: G.chatSince, ownName: G.ownName, rule: G.rule, invite: G.invite, cancelInvite: G.cancelInvite, players: G.advPlayers, guestGenerals: G.guestGenerals, log: G.log });
                return go("LS_RUN", kept ? "loot spots: going on with the case from before the restart (" + kept.state + ")" : "loot spots: " + nL);
            } /* falls through to the 0.2.17 replay when the PBC is not loaded */
            case "LS_OFFER_OLD": {
                var ls = run.ver.ls || {}, n = Number(G.rule("adv.gp.lootSpots", ls.spots || 2)) || 0;
                if (n <= 0) return go("QUESTS", "no loot spots (rule 0)");
                var txt = ls.offer && ls.offer.text ? ls.offer.text.replace(/\d+x/i, n + "x") : String(G.rule("adv.gp.textOffer", "{n}x ls GP")).replace("{n}", n);
                var r = G.say(txt); if (!r || !r.ok) { say("loot spots not offered: " + ((r && r.reason) || "?")); return go("QUESTS"); }
                run.ls = { n: n, offerAt: Date.now(), picked: [], invited: [], kills: {} }; return go("LS_WAIT", "offered in the guild chat: " + txt);
            }
            case "LS_RUN": {
                var stL = run.lsm.tick(), sL = run.lsm.state();
                try { airFile("dma-adv-ls.json", { zone: run.zone, atMs: Date.now(), ls: sL.done ? null : sL }); } catch (_) {}   // 0.2.31 (P7)
                if (sL.log.length && sL.log[sL.log.length - 1] !== run.lsLast) { run.lsLast = sL.log[sL.log.length - 1]; say(run.lsLast.slice(9)); publish(); }
                if (run.lsm.done() && run.lsm.failed && run.lsm.failed()) return stop("loot spots could not be offered (" + sL.result + "); the adventure stays open — offer them yourself or press Run once again");   // 0.2.19
                if (run.lsm.done()) return go("QUESTS", "loot spots: " + sL.result);
                return;
            }
            case "LS_WAIT": {
                var words = String(G.rule("adv.gp.requestWords", "pls, plz, please, me")).split(/\s*,\s*/).filter(Boolean), own = G.ownName().toLowerCase();
                var reW = new RegExp("\\b(" + words.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|") + ")\\b", "i");
                G.chatSince(run.ls.offerAt - 1).forEach(function (l) { var w = l.sender.toLowerCase();
                    if (l.channel === "guild" && w && w !== own && reW.test(l.text) && run.ls.picked.indexOf(l.sender) < 0 && run.ls.picked.length < run.ls.n) run.ls.picked.push(l.sender); });
                var waitMin = Number(G.rule("adv.gp.pleaseWaitMin", 5)) || 5;
                if (run.ls.picked.length < run.ls.n && !late(waitMin * 60000)) return;
                if (!run.ls.picked.length) { say("nobody asked within " + waitMin + " min"); return go("QUESTS"); }
                run.ls.picked.forEach(function (nm) { var r = G.invite(nm, run.zone); if (r.ok) run.ls.invited.push(nm); else say("invite " + nm + ": " + r.reason); });
                if (!run.ls.invited.length) return go("QUESTS", "no invitation went out");
                var ls2 = run.ver.ls || {}, t2;
                if (ls2.announce && ls2.announce.text) { t2 = ls2.announce.text; if (run.ls.invited.length === 1) t2 = t2.replace(/\s*(and|&|,)\s*\{player2\}|\{player2\}\s*(and|&|,)\s*/i, ""); run.ls.invited.forEach(function (nm, i) { t2 = t2.split("{player" + (i + 1) + "}").join(nm); }); }
                else t2 = String(G.rule("adv.gp.textPromise", "{names} invited, just make a kill and report it on adv chat, I'll close")).replace("{names}", run.ls.invited.join(" and "));
                G.say(t2); return go("LS_KILLS", "invited " + run.ls.invited.join(", ") + "; announced");
            }
            case "LS_KILLS": {
                var dw = String(G.rule("adv.gp.declareWords", "kd, done, killed")).split(/\s*,\s*/).filter(Boolean);
                var reK = new RegExp("\\b(" + dw.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|") + ")\\b", "i");
                G.chatSince(run.ls.offerAt).forEach(function (l) { run.ls.invited.forEach(function (nm) { if (nm.toLowerCase() === l.sender.toLowerCase() && reK.test(l.text) && !run.ls.kills[nm]) { run.ls.kills[nm] = 1; say(nm + " reported the kill"); } }); });
                var done = run.ls.invited.every(function (nm) { return run.ls.kills[nm]; });
                if (done) return go("QUESTS", "all loot spots reported their kill");
                if (late((Number(G.rule("adv.gp.killWaitMin", 15)) || 15) * 60000)) return go("QUESTS", "kill wait over; closing");
                return;
            }
            case "QUESTS": {
                if (!run.collected2 && G.collect && G.rule && G.rule("adv." + run.id + ".collect", true) !== false) { run.collected2 = true; var nc2 = 0; try { nc2 = G.collect(); } catch (_) {} say("collect (before the quests): " + nc2); }   // 0.2.21: those the camps left
                if (!run.qAt || G.now() - run.qAt > 15000) { run.qAt = G.now(); var q = G.claimQuests(); if (q.claimed || q.accepted) say("quests: " + q.claimed + " claimed, " + q.accepted + " accepted" + (q.last ? " (last quest)" : "")); if (q.last) run.last = true; }
                var fs = G.advStatus ? G.advStatus(run.zone) : null;
                if ((fs === 2 || fs === 3 || (run.last && late(60000))) && !run.stowed) {   // 0.2.81: stow before Return
                    run.stowed = true;
                    if (typeof G.rule !== "function" || G.rule("adv.stowLoose", true) !== false) { var nG = stowLoose(G, say); if (nG) { run.stowUntil = G.now() + 1000 * (nG + 3); return; } }
                }
                if (run.stowUntil && G.now() < run.stowUntil) return;
                if (fs === 2 || fs === 3 || (run.last && late(60000))) { var rh = G.returnHome(run.zone); return go("FINISH", "return home" + (rh.dropped ? ": adventure finished and closed" : " (status " + fs + ")")); }   // 0.2.20: after the last quest at most 1 min (live: with loot-spot players on it the status stayed "started")
                if (late(5 * 60000)) return stop("all camps are gone but the game has not marked the adventure won; check the quest book");
                return;
            }
            case "FINISH": { if (G.atHome()) return go("DONE", "home; run took " + Math.round((G.now() - run.startedAt) / 60000) + " min"); if (late(5 * 60000)) return stop("could not get home"); return; }
            }
        }
        function tick() { if (run.stopped || run.state === "DONE") return run.state; try { step(); } catch (e) { stop("error in " + run.state + ": " + e); } return run.state; }
        publish();
        return { tick: tick, restartSafe: function () { return true; }, stop: function (why) { if (!run.stopped && run.state !== "DONE") stop(why || "stopped by the player"); }, state: function () { return JSON.parse(JSON.stringify(run)); } };
    }
    /* 0.2.33: TK18 — one transaction per run. 0.2.167: the cases of the player's Run once and of AR17's runOnce keep these
       direct records (the player is no initiator of TK18 in the backbone, so the gateway would refuse them); a case taken in by
       request() (B12) goes through the G-CAF gateway from its request to its end (gwEnd). */
    function tk18(act, cs, d) { try { var o = { tk: "TK18", act: act, caseId: cs, actor: "adventure runner" }, k; for (k in (d || {})) o[k] = d[k]; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {} }
    /* 0.2.167 (tester kf-tk18-initiator-accepts): the initiator of each case, so its answers (accept, allow) are its own */
    var ROLE_BY = { "adventure manager": "AR17", ar17: "AR17", "ar17 adventure manager": "AR17", "quest completer": "AR71", ar71: "AR71", "ar71 quest completer": "AR71" };
    function roleOf(by) { return ROLE_BY[String(by || "").toLowerCase()] || ""; }
    function initiatorName(by) { var r = roleOf(by); return r === "AR17" ? "adventure manager" : r === "AR71" ? "quest completer" : String(by || "player"); }
    var caseBy = {};
    function runCase(id, resumeOnly) {
        var rf = runFile();
        if (resumeOnly && rf && rf.active && rf.id === id && rf.caseId) return { cs: rf.caseId, old: true, by: rf.by || "", role: rf.role || "", via: rf.via || "" };   // 0.2.167: a resumed case keeps its initiator
        return { cs: "adv:" + id + "@" + Date.now(), old: false };
    }
    function tk18Start(rc, id, version, by) { if (rc.old) return; caseBy[rc.cs] = by || "player"; tk18("request", rc.cs, { actor: by || "player", adventure: id, version: version || "" });   /* 0.2.94: the initiator (the adventure manager, ADR 0088) */
    tk18("promise", rc.cs, { adventure: id }); }
    function tk18End(rf, st, why) {
        if (!rf || !rf.caseId) return;
        if (rf.via === "gateway") return gwEnd(rf, st, why);   // 0.2.167 (B12)
        var by = rf.by || caseBy[rf.caseId] || "player", who = by === "player" ? "player (tacit)" : by;   // 0.2.167: the initiator answers, not "player (tacit)"
        delete caseBy[rf.caseId];
        if (st === "DONE") { tk18("execute", rf.caseId, { adventure: rf.id }); tk18("declare", rf.caseId, { adventure: rf.id, reason: why || "done" }); tk18("accept", rf.caseId, { actor: who }); }
        else { tk18("revoke promise", rf.caseId, { reason: why || "stopped" }); tk18("allow", rf.caseId, { actor: who }); tk18("decline", rf.caseId, { reason: why || "stopped" }); }
    }

    /* ---------------- 0.2.167 (change-set B12, backbone v3.34): AR18 takes TK18 requests in ----------------
       request(id, {by, quest, task, version}) records the request of the initiator (AR17 adventure manager or AR71 quest
       completer) through the G-CAF gateway and assesses it at once (ARS-18-02); the Adventure switch is not AR18's (per author
       22:53, model v3.35 pending: switching off is the manager's revoke request); a failing truth clause
       (T3 R-ADV-IN-STAR, T4 R-ADV-ATTACK-PLAN, T5 R-ADV-LOCATION-ACTIVE) is a decline naming that clause; otherwise a promise
       that names its turn. The promised requests wait in arrival order of their promises (dma-adv-requests.json, so a
       restart keeps them); the first is started (ARS-18-03) when it is its turn (T2 R-ADV-FIRST-COME: no run going, no run
       waiting to be resumed) and the general is idle (T3 R-ADV-GENERAL-IDLE: no run of ours holds the generals; the run's own
       PRECHECK reads them). Re-assessed when a run ends (TK18/da, rv-pm, rv-rq) and every 30 s (TK82/ac). */
    function GW() { var g = root.GCAF_Transactions; return g && typeof g.act === "function" ? g : null; }
    function gact(act, cs, by, reason, data) {
        var g = GW(); if (!g) return { ok: false, refused: true, why: "the coordination gateway (GCAF_Transactions) is not loaded" };
        var o = { by: by, data: data || {} }; if (reason) o.reason = reason;
        try { return g.act("TK18", act, cs, o); } catch (e) { return { ok: false, refused: true, why: String(e) }; }
    }
    /* 0.2.167 r2 (tester kf-adv-queue-stale-second-window, ADR 0051): the file is the source of truth - read fresh before every
       reading and every change, so a second window (the adventure window loads this module too) never acts on a request the
       other window already started or ended. Only without files (no AIR) the queue lives in memory. */
    var RQ_FILE = "dma-adv-requests.json", reqsMem = null;
    function rq() { var f = airFile(RQ_FILE); if (f && f.list && f.list.length != null) return f; return reqsMem ? JSON.parse(JSON.stringify(reqsMem)) : { format: "dma-adv-requests/1", list: [], seq: 0 }; }
    function rqWrite(r) { if (airFile(RQ_FILE, r)) reqsMem = null; else reqsMem = r; }
    function rqFind(cs) { var l = rq().list, i; for (i = 0; i < l.length; i++) if (l[i].cs === cs) return l[i]; return null; }
    function rqPut(e, newSeq) { var r = rq(), i, hit = false; if (newSeq) { r.seq = (r.seq || 0) + 1; e.pseq = r.seq; } for (i = 0; i < r.list.length; i++) if (r.list[i].cs === e.cs) { r.list[i] = e; hit = true; } if (!hit) r.list.push(e); rqWrite(r); }
    function rqDrop(cs) { var r = rq(); r.list = r.list.filter(function (x) { return x.cs !== cs; }); rqWrite(r); }
    function promisedList() { return rq().list.filter(function (x) { return x.state === "promised"; }).sort(function (a, b) { return (a.pseq || 0) - (b.pseq || 0); }); }
    function shortOf(res) { for (var k in RES) if (RES.hasOwnProperty(k) && RES[k] === res) return k; return res; }
    function caseKey(id, task) { var res = resOf(id) || String(id); return "adv:" + res + "@" + (task != null && task !== "" ? String(task) : String(Date.now())); }
    /* DFS-76 [adventure] is in the star: the star stock of its adventure kind, read from the location manager's picture (ADR 0040); the game's own star without it */
    /* 0.2.168: the picture is read only when it carries a star reading at all; before the first stock sample after a load it holds
       none (stockNow() is {}), and "no reading" was taken for "none in the star" - live 2026-11-25 20:43Z, YWC x39 in the star */
    function starStock(res) {
        try { var D = root.DMA_Demo; if (D && typeof D.stockNow === "function") { var s = D.stockNow() || {}, k;
              for (k in s) if (k.indexOf("star:") === 0) return Number(s["star:Adventure:" + res] || 0) || 0; } } catch (_) {}
        try { return Number(gameGateway().starCounts()[res] || 0) || 0; } catch (_) { return null; }   // 0.2.170 (F4): a star not read is null, never 0
    }
    /* DFS-77 [adventure] has an attack plan: a version in the player's adventure book; which one is the work instruction (the named one, else the
       book's default). An "arrows only" version has no folder by construction (0.2.11) and is a plan all the same. */
    function planOf(res, name) {
        var e = book()[res]; if (!e || !e.versions || !e.versions.length) return null;
        var v = null; if (name) e.versions.forEach(function (x) { if (x.name === name) v = x; });
        if (!v) v = e.versions[e.def || 0] || e.versions[0];
        if (!v || (v.mode !== "arrows only" && !v.folder)) return null;
        return v;
    }
    /* T5 R-ADV-LOCATION-ACTIVE: "the location of the general of [adventure] is active (given externally; DFS-66)". GENERAL is not
       in the fact model yet (B12-Q6); the clause is read where a reading exists (DMA_Control.locationActive), else as given. */
    function locationActive() { try { var C = root.DMA_Control; if (C && typeof C.locationActive === "function") return C.locationActive("home") !== false; } catch (_) { return false; } return true; }
    function running() { try { if (!current) return false; var s = current.state(); return s.state !== "DONE" && !s.stopped; } catch (_) { return false; } }
    /* the run before a client restart waits to be resumed (90 s after load, or by the adventure window, ADR 0051) */
    function resumePending() { try { var rf = runFile(); return !!(rf && rf.active && !running()); } catch (_) { return false; } }
    /* ARS-18-02 on TK18/rq: promise, decline (with the failed truth clause), or - the rightness clause failing - no act */
    function assess(e) {
        /* ARS-18-02.R3 R-ADV-SWITCH is not read here: per author 22:53 ("het uitzetten van de schakelaar geldt als revoke request van de
           manager"; model v3.35 pending) the switch is the manager's - switched off, the manager revokes its own requests */
        var fail = null, v = null;
        var ss = starStock(e.res);
        if (ss == null) { e.why = "waiting, not promised yet: ARS-18-02.T3 R-ADV-IN-STAR: the star is not read yet"; e.lastWait = Date.now(); rqPut(e, false); return e.state; }   // 0.2.170 (F4)
        if (!(ss > 0)) fail = "ARS-18-02.T3 R-ADV-IN-STAR: no " + e.res + " in the star";
        else if (!(v = planOf(e.res, e.version))) fail = "ARS-18-02.T4 R-ADV-ATTACK-PLAN: no version of " + e.res + " in the adventure book";
        else if (v.analysis && v.analysis.ok === false) fail = "ARS-18-02.T4 R-ADV-ATTACK-PLAN: version \"" + v.name + "\" is not playable (" + (v.analysis.error || "its analysis has errors") + ")";
        else if (!locationActive()) fail = "ARS-18-02.T5 R-ADV-LOCATION-ACTIVE: the home island is not active";
        /* 0.2.170 (architect F1, B13-Q3: "before the promise ... everything needs to be checked"): T6-T10 here, a failed clause is a
           decline naming it; a fact not read now leaves the request unpromised, assessed again by pump() */
        var aheadN = promisedList().length + (running() || resumePending() ? 1 : 0);
        if (!fail) {
            if (e.lastWait && Date.now() - e.lastWait < 60000) return e.state;   // a waiting request is assessed again at most once a minute
            var pa = null; try { pa = planAssess(e.res, v, e.runs || 1, aheadN); } catch (eP) { pa = { wait: "the plan could not be read: " + eP }; }
            if (pa.wait) { e.lastWait = Date.now(); e.why = "waiting, not promised yet: " + pa.wait; rqPut(e, false); return e.state; }
            if (pa.fails && pa.fails.length) fail = pa.fails.map(function (x) { return x.clause + " " + x.name + ": " + x.msg; }).join("; ");
        }
        /* T2 R-ADV-NOT-LOST holds for a request: the adventure it asks for is not yet started, so it cannot be lost */
        if (fail) { var d = gact("decline", e.cs, "AR18", fail, { adventure: e.res, rule: "ARS-18-02" }); rqDrop(e.cs); e.state = d.ok ? "declined" : "refused"; e.why = d.ok ? fail : "the gateway refused the decline: " + d.why; return e.state; }
        var ahead = aheadN;
        var p = gact("promise", e.cs, "AR18", null, { adventure: e.res, version: v.name, turn: ahead + 1, rule: "ARS-18-02" });
        if (!p.ok) { e.why = "the gateway refused the promise: " + p.why; return "refused"; }
        e.state = "promised"; e.version = v.name; e.folder = v.folder || ""; e.mode = v.mode || "";
        e.why = ahead ? "promised; executed after the " + ahead + " adventure completing promised before it (ARS-18-03.T2 R-ADV-FIRST-COME)" : "promised";
        rqPut(e, true); return "promised";
    }
    function request(id, o) {
        o = o || {};
        var res = resOf(id) || String(id || ""), cs = o.caseId || caseKey(res, o.task), had = rqFind(cs);
        if (had) return { ok: true, caseId: cs, state: had.state, why: "already requested: " + (had.why || had.state) };
        var g = gact("request", cs, o.by, null, { adventure: res, quest: o.quest || "", task: o.task || "", version: o.version || "", rule: o.rule || "" });
        if (!g.ok) return { ok: false, refused: true, caseId: cs, reason: g.why };
        var e = { cs: cs, id: shortOf(res), res: res, version: o.version || "", runs: Math.max(1, Number(o.runs) || 1), by: initiatorName(o.by), role: roleOf(o.by), quest: o.quest || "", task: o.task || "", at: Date.now(), state: "requested" };
        rqPut(e, false);
        var out = assess(e);
        try { pump(); } catch (_) {}
        return { ok: out !== "refused", caseId: cs, state: e.state === "requested" ? "requested" : e.state, why: e.why };
    }
    /* the initiator revokes its request (ARS-71-01-LEAVE, ARS-71-06): allowed by AR18 while the adventure has not started (DFS-78) */
    function withdraw(cs, o) {
        o = o || {}; var e = rqFind(cs);
        if (!e) return { ok: false, reason: "nothing waits under " + cs + ": started, ended or never requested" };
        var r = gact("revoke request", cs, o.by, o.reason || "withdrawn by the initiator", { adventure: e.res });
        if (!r.ok) return { ok: false, refused: true, reason: r.why };
        gact("allow", cs, "AR18", null, { adventure: e.res, reason: "the adventure has not started" });
        rqDrop(cs); return { ok: true, caseId: cs };
    }
    /* ARS-18-03: the first promised request starts when it is its turn, the general is idle and the switch is on */
    function pump() {
        /* r3 (tester kf-adv-queue-dropped-by-adventure-window, ADR 0051): the queue is served only where the gateway and the transaction
           book are loaded (the home window); a window without them (the adventure window, ADV_ALLOW) leaves the queue alone */
        if (!GW() || !root.DMA_Tx) return { wait: "no gateway or transaction book in this window: the queue is served by the home window" };
        rq().list.filter(function (x) { return x.state === "requested"; }).forEach(function (x) { assess(x); });   // a request whose promise the gateway refused is assessed again
        var next = promisedList()[0]; if (!next) return null;
        /* ARS-18-03.R2 R-ADV-SWITCH-START: not read (per author 22:53, model v3.35 pending): the switch is AR17's, a quest's run follows quest.auto */
        if (running()) return { wait: "ARS-18-03.T2 R-ADV-FIRST-COME: a run is going" };
        if (resumePending()) return { wait: "ARS-18-03.T2 R-ADV-FIRST-COME: the run before the restart is resumed first" };
        var g0 = GW(), s0 = g0 ? g0.state("TK18", next.cs) : null;
        if (s0 == null) return { wait: "the book does not know " + next.cs + " (yet): kept" };   // r3: unknown is not "no longer promised"
        if (s0 !== "promised") { rqDrop(next.cs); return { dropped: next.cs, state: s0 }; }   // r2: the book says the case is no longer promised (another window started or ended it)
        rqDrop(next.cs);   // r2: taken off the file before the start, so a second window cannot take it too
        var rs = null; try { rs = startRun(next.id, next.folder, next.version, false, { by: next.by }, { cs: next.cs, old: true, by: next.by, role: next.role, via: "gateway" }); } catch (eS) { rs = { ok: false, reason: String(eS) }; }
        if (rs && rs.ok) return { started: next.cs };
        var why = "the run did not start: " + (rs && rs.reason ? rs.reason : "no reason");   // the promise cannot be kept: revoked, allowed by the initiator, declined
        gwEnd({ caseId: next.cs, id: next.id, role: next.role, via: "gateway" }, "STOPPED", why);
        return { failed: next.cs, why: why };
    }
    /* the end of a gateway case: DONE -> execute, declare (ARS-18-04); the adventure manager's accept is given on its behalf
       (ARS-18-05: [adventure] is won - the run's DONE); the quest completer accepts itself when the game counts the task
       (ARS-18-05-AR71). Stopped -> revoke promise, allowed by the initiator; lost -> the initiator revokes its request
       (ARS-18-07, ARS-18-07-AR71) and AR18 allows; otherwise AR18 declines with the reason (the cause may change: AR71 asks
       again after its pause, ARS-71-01-AGAIN). */
    function gwEnd(rf, st, why) {
        var cs = rf.caseId, role = rf.role || "", d = { adventure: rf.id };
        if (st === "DONE") { gact("execute", cs, "AR18", null, d); gact("declare", cs, "AR18", null, { adventure: rf.id, result: why || "done" }); if (role === "AR17") gact("accept", cs, "AR17", null, d); return; }
        var r = String(why || "stopped");
        gact("revoke promise", cs, "AR18", r, d); gact("allow", cs, role || "AR17", null, d);
        if (/the game marks the adventure lost/.test(r)) { gact("revoke request", cs, role || "AR17", r, d); gact("allow", cs, "AR18", null, d); }
        else gact("decline", cs, "AR18", /^the run /.test(r) ? r : "the run stopped: " + r, d);
    }
    /* 0.2.169 (B13-Q3, ARS-18-02.T6-T10): what the selected plan needs, checked before the promise. facts: {star: {name: count},
       adventures: n (the adventure kind in the star), runs: n, caps: {key: capacity}, foreign: [names], travel: [names]} */
    function planCheck(packets, facts) {
        facts = facts || {}; var out = [], need = {}, star = facts.star || {}, runs = Math.max(1, Number(facts.runs) || 1);
        function nm(e, k) { return String((e && e.name) || k).replace(/<[^>]*>/g, "").replace(/\([^)]*\)/g, "").replace(/\s+/g, " ").trim(); }
        var needAdv = runs - (facts.open ? 1 : 0);   // an adventure already open is the first run
        if (facts.adventures != null && Number(facts.adventures) < needAdv) out.push({ clause: "ARS-18-02.T6", name: "R-PLAN-ADVENTURES", msg: "the star holds " + Number(facts.adventures) + " of this adventure, the run needs " + needAdv });
        if (facts.foreign && facts.foreign.length) out.push({ clause: "ARS-18-02.T7", name: "R-PLAN-GENERALS", msg: "not your generals: " + facts.foreign.join(", ") + " (Analyse ▶ Save my copy makes a version with your own)" });
        if (facts.unavailable && facts.unavailable.length) out.push({ clause: "ARS-18-02.T7", name: "R-PLAN-GENERALS", msg: "generals not available: " + facts.unavailable.join(", ") });   // 0.2.170 (F2)
        var over = [];
        (packets || []).forEach(function (p) { Object.keys(p || {}).forEach(function (k) { var e = p[k]; if (!e) return;
            if (e.type === "buff") { if (Number(e.target) > 0 && e.name) need[e.name] = (need[e.name] || 0) + 1; return; }
            if (e.type === "speedbuff") return;
            var cap = facts.caps ? facts.caps[k] : null, n = 0; Object.keys(e.army || {}).forEach(function (u) { n += Number(e.army[u]) || 0; });
            if (cap != null && cap > 0 && n > cap && over.indexOf(nm(e, k)) < 0) over.push(nm(e, k) + " " + n + "/" + cap); }); });
        if (over.length) out.push({ clause: "ARS-18-02.T8", name: "R-PLAN-CAPACITY", msg: "army over capacity: " + over.join(", ") });
        var miss = Object.keys(need).filter(function (b) { return (Number(star[b]) || 0) < need[b] * runs; }).map(function (b) { return b + " " + (Number(star[b]) || 0) + "/" + need[b] * runs; });
        if (miss.length) out.push({ clause: "ARS-18-02.T9", name: "R-PLAN-ARROWS", msg: "arrows missing in the star (have/need): " + miss.join(", ") });
        var tb = (facts.travel || []).filter(function (b) { return !/^Observatory:/.test(b) && !((Number(star[b]) || 0) >= runs); });
        if (tb.length) out.push({ clause: "ARS-18-02.T10", name: "R-PLAN-BUFFS", msg: "buffs missing in the star: " + tb.join(", ") });
        return out;
    }
    /* 0.2.170 (architect review 2026-11-26 F1-F4): ARS-18-02.T6-T10 read once, the same way for the gateway's assess() (before the
       promise) and the player's direct start. Returns {fails: [...]} or {wait: why} when a fact could not be read now - a
       reading that is not there is never taken for zero (CR-D3). v: the version; runs: the runs selected (the initiator's
       agenda, 1 for one run, F3); ahead: a run going or promised before this one (then the generals' availability cannot be
       judged yet: the request waits unpromised, F2). */
    /* 0.2.170 (architect F7, ADR 0042): the watcher of the destroy-arrow facts is the game - an arrow put on a camp either took it
       (the camp fell) or did not (it still stood when the unit count settled). Counted per buff kind and camp size in
       dma-arrow-facts.json; an observation that contradicts the registered copy (docs/05-ontology/dma/facts/destroy-arrows.yaml,
       mirrored in the generator) is recorded as "the facts of destroy arrows changed". */
    function arrowSize(name) { try { var MG = root.DMA_MundaneGen; if (MG && MG.campSize) return MG.campSize(name); } catch (_) {}
        var n = String(name || ""); return /\(easy\)/i.test(n) ? "easy" : /\(medi/i.test(n) ? "medium" : /\(hard\)|heavy|leader|boss/i.test(n) ? "hard" : null; }
    function arrowFacts() { var f = airFile("dma-arrow-facts.json"); return (f && f.obs) || {}; }
    function arrowObserved(def, campName, taken) {
        var size = arrowSize(campName); if (!def || !size) return null;
        var f = airFile("dma-arrow-facts.json") || { format: "dma-arrow-facts/1", source: "the game (observed by the adventure completer)", obs: {} };
        f.obs = f.obs || {}; var o = (f.obs[def] = f.obs[def] || {}); o[size] = o[size] || { taken: 0, notTaken: 0 }; o[size][taken ? "taken" : "notTaken"] += 1; f.at = new Date().toISOString();
        airFile("dma-arrow-facts.json", f);
        try { var MG = root.DMA_MundaneGen, copy = MG && MG.destroyArrows ? MG.destroyArrows().arrows : [], a = copy.filter(function (x) { return x.def === def; })[0];
              var says = a ? a.sizes.indexOf(size) >= 0 : null;
              if (says != null && says !== !!taken) { var txt = "the facts of destroy arrows changed: " + def + " on a " + size + " camp (" + campName + ") was " + (taken ? "taken" : "not taken") + "; the registered copy says " + (says ? "it takes it" : "it does not");
                  try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "the facts of destroy arrows changed", def: def, size: size, camp: campName, taken: !!taken, copy: says }); } catch (_) {}
                  try { if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log("adv: " + txt); } catch (_) {} return txt; } } catch (_) {}
        return null;
    }
    function starRead() {   // the star from the location manager's picture (ADR 0040); the game only where no picture is loaded
        try { var D = root.DMA_Demo; if (D && typeof D.stockNow === "function") { var s = D.stockNow() || {}, out = {}, any = false, k, nm;
              for (k in s) if (k.indexOf("star:") === 0) { any = true; nm = k.slice(5).split(":")[0]; out[nm] = (out[nm] || 0) + (Number(s[k]) || 0); }
              if (any) return out; } } catch (_) { return null; }   // as starStock(): the picture where its last sample carries the star
        try { var Gs = gameGateway(); return Gs.starRead ? Gs.starRead() : null; } catch (_) { return null; }
    }
    function planPackets(res, v) {
        if (!v || v.mode === "arrows only") return { packets: [], names: [], a: null };
        var M = root.DMA_Mundane; if (!M || !M.analyzeAir) return { error: "user_dma_mundane.js not loaded" };
        var a = M.analyzeAir(v.folder, landingRules(res))[0];
        if (!a || a.error) return { error: (a && a.error) || "no templates" };
        if (!a.run.length || !a.choices.loadTemplate) return { error: "the advisor found no load template" };
        return { a: a, names: a.run.slice(), packets: a.run.map(function (n) { return toPacket(a.texts[n]); }) };
    }
    function planAssess(res, v, runs, ahead, pp) {
        pp = pp || planPackets(res, v); if (pp.error) return { fails: [{ clause: "ARS-18-02.T4", name: "R-ADV-ATTACK-PLAN", msg: pp.error }] };
        var rl = rulesFor(Object.keys(RES).filter(function (k) { return RES[k] === res; })[0] || "own"), Gc = null; try { Gc = gameGateway(); } catch (_) {}
        var keysAll = Object.keys(pp.packets.reduce(function (o, p) { Object.keys(p || {}).forEach(function (k) { if (p[k] && p[k].type !== "buff" && p[k].type !== "speedbuff") o[k] = 1; }); return o; }, {}));
        var fc = { caps: {}, foreign: [], travel: rl.travel || [], runs: Math.max(1, Number(runs) || 1), unavailable: [] };
        fc.adventures = starStock(res);   // F4: T6 reads DFS-76 as T3 does
        if (fc.adventures == null) return { wait: "ARS-18-02.T6 R-PLAN-ADVENTURES: the star is not read yet" };
        var st = starRead(); if (st == null) return { wait: "ARS-18-02.T9/T10: the star is not read yet - assessed again at the next reading" };
        fc.star = st;
        try { if (Gc && Gc.ownAdventure) fc.open = Gc.ownAdventure(res) != null; } catch (_) {}
        try { if (Gc && Gc.capacities && keysAll.length) fc.caps = Gc.capacities(keysAll) || {}; } catch (_) {}
        (pp.a && pp.a.findings || []).forEach(function (f) { if (f.code === "FOREIGN_GENERALS" && f.level !== "info" && pp.a.run.indexOf(f.file) >= 0) fc.foreign.push("template " + f.file); });
        /* F2: T7 also reads "available: not travelling, not recovering, not promised to another adventure". With a run going or
           promised before this one the generals are that run's: their availability for this one is judged when it is its turn */
        var availWait = null;
        if (keysAll.length && !fc.foreign.length) {
            if (ahead) availWait = "ARS-18-02.T7 R-PLAN-GENERALS: the generals are judged available when the adventure completing before this one has ended";
            else {
                var all = {}; pp.packets.forEach(function (p) { Object.keys(p || {}).forEach(function (k) { if (p[k] && p[k].type !== "buff" && p[k].type !== "speedbuff" && !all[k]) all[k] = p[k]; }); });   // every general of the plan
                var ins = null; try { ins = Gc && Gc.inspect ? Gc.inspect(all) : null; } catch (_) { ins = null; }
                if (!ins || !ins.generals) availWait = "ARS-18-02.T7 R-PLAN-GENERALS: the generals are not read yet";
                else Object.keys(all).forEach(function (k) { var x = ins.generals[k], e = all[k]; if (!x) return;
                    var nm = String((e && e.name) || k).replace(/<[^>]*>/g, "").replace(/\([^)]*\)/g, "").replace(/\s+/g, " ").trim();
                    if (x.recovering) fc.unavailable.push(nm + " (recovering)");
                    else if (x.travelling) fc.unavailable.push(nm + " (travelling)");
                    else if (!x.here && !fc.open) fc.unavailable.push(nm + " (not on the home island)"); });   // 0.2.171: with an open adventure of this kind the generals may stand there (live FT 2026-11-26 15:49Z)
            }
        }
        var fl = planCheck(pp.packets, fc);
        if (!fl.length && availWait) return { wait: availWait };   // a clause that fails is said at once; availability not read only holds back the promise
        return { fails: fl, facts: fc };
    }
    function runOnce(id, source, version, resumeOnly, how) {
        /* 0.2.167 (B12 decision 3, ARS-18-03.T2 first come, first served): an initiator's runOnce waits behind the requests promised before it */
        if (!resumeOnly && how && roleOf(how.by)) { var pl = promisedList().length; if (pl) return { ok: false, reason: "first come, first served: " + pl + " adventure completing promised before (ARS-18-03.T2 R-ADV-FIRST-COME)" }; }
        return startRun(id, source, version, resumeOnly, how, null);
    }
    function startRun(id, source, version, resumeOnly, how, rcIn) {
        if (current && current.state().state !== "DONE" && !current.state().stopped) return { ok: false, reason: "a run is already going: " + current.state().state };
        var res = resOf(id); if (!res) return { ok: false, reason: "no star item name known for " + id + " yet" };
        if (!resumeOnly) { try { var rfP = runFile(); if (rfP && rfP.active && rfP.caseId) { tk18End(rfP, "STOPPED", "the client restarted during this run; a new run took over"); rfP.active = false; rfP.end = "STOPPED"; runFile(rfP); } } catch (_) {} }   // 0.2.44
        var ver0 = null; try { (entry(res).versions || []).forEach(function (v) { if (v.name === version) ver0 = v; }); } catch (_) {}
        /* 0.2.88 (ADR 0080, F16b/F18): a version whose analysis is not ok (a load shortage, block entries in a version without
           blocks, no load template) does not start; the reason is the analysis' first error */
        if (ver0 && ver0.analysis && ver0.analysis.ok === false && !(how && how.force)) {
            var n0 = (ver0.analysis.notes || []).filter(function (x) { return x.level === "error"; })[0];
            return { ok: false, reason: "version \"" + version + "\" does not start: " + (n0 ? n0.msg : (ver0.analysis.error || "its analysis is not ok")) };
        }
        function caseOf() { var rc = rcIn || runCase(id, resumeOnly); if (!rcIn) tk18Start(rc, id, version, how && how.by); return rc; }
        function fileOf(rc, src, dz) { return { id: id, source: src, version: version || "", active: true, at: new Date().toISOString(), doneZones: dz, caseId: rc.cs, by: rc.by || (rc.old ? "" : (how && how.by) || "player"), role: rc.role || roleOf(how && how.by), via: rc.via || "" }; }   // 0.2.167: the run file names the initiator
        if (ver0 && ver0.mode === "arrows only") {   // 0.2.11
            var prevA = runFile() || {}, dzA = (prevA.doneZones || []).slice(-10);
            current = createArrowRun({ id: id, res: res, ver: ver0, doneZones: dzA, resumeOnly: !!resumeOnly }); current.version = version;
            var rcA = caseOf();
            runFile(fileOf(rcA, "", dzA));
            startTimer(); current.tick(); return { ok: true, run: ["arrows only"], caseId: rcA.cs };
        }
        var M = root.DMA_Mundane; if (!M || !M.analyzeAir) return { ok: false, reason: "user_dma_mundane.js not loaded" };
        var a = M.analyzeAir(source, landingRules(res))[0];   // 0.2.115 (ADR 0092)
        if (!a || a.error) return { ok: false, reason: (a && a.error) || "no templates" };
        if (!a.run.length || !a.choices.loadTemplate) return { ok: false, reason: "the advisor found no load template" };
        var names = a.run.slice(), packets = names.map(function (n) { return toPacket(a.texts[n]); });
        /* 0.2.169 (B13-Q3) / 0.2.170 (architect F1): everything the plan needs before the promise. A gateway case (rcIn) was assessed
           in assess() before its promise; the player's direct start and the manager's runOnce are assessed here, before tk18Start */
        if (!resumeOnly && !rcIn && !(how && how.force)) {
            var pa = planAssess(res, ver0 || { name: version, folder: source, mode: "" }, (how && Number(how.runs)) || 1, 0, { a: a, names: names, packets: packets });
            if (pa.wait) return { ok: false, reason: "not promised yet: " + pa.wait, wait: true };
            if (pa.fails && pa.fails.length) return { ok: false, reason: "not promised: " + pa.fails.map(function (x) { return x.name + " — " + x.msg; }).join("; "), planCheck: pa.fails };
        }
        var prev = runFile() || {}, doneZones = (prev.doneZones || []).slice(-10);
        var prevSt = null, prevFix = null; if (resumeOnly) { try { var ps = airFile("dma-adv-status.json"); if (ps && ps.adventure === id && ps.state && ps.state !== "STOPPED" && ps.state !== "DONE") { prevSt = ps.state; if (ps.fix && ps.fix.step) prevFix = { n: ps.fix.step, round: ps.round, reason: ps.fix.reason }; } } catch (_) {} }   // 0.2.30
        var rl = rulesFor(RES[id] ? id : (Object.keys(RES).filter(function (k) { return RES[k] === id; })[0] || "own")), kind = ver0 ? ver0.mode : "";   // 0.2.84 (ADR 0079): the version's kind sets the way it is played
        if (kind === "camp by camp") { rl.campByCamp = true; rl.asIs = false; }   // 0.2.169 (B13): a kind the player chose for this version
        if (kind === "without blocks") { rl.waves = true; rl.asIs = false; }
        if (kind === "blocks") rl.asIs = false;
        /* 0.2.177 (live FT 2026-11-27 05:47-06:12Z, B14 section 13): FT's rule "retreat on interception off" is the author's, for HIS
           plans, which are caught on purpose. A plan DMA made has no intended interception: "interception accepted" sent YGG1 into
           camp 1132 twice. A version whose source is "made by DMA" is not sent when a camp nobody attacks watches the way. */
        if (ver0 && /made by DMA/i.test(String(ver0.source || ""))) rl.retreat = true;
        current = createRun({ id: id, res: res, packets: packets, names: names, rules: rl, doneZones: doneZones, resumeOnly: !!resumeOnly, prevState: prevSt, prevFix: prevFix, emergency: !!(how && how.emergency) });
        current.version = version || "";
        var rc = caseOf();
        runFile(fileOf(rc, source, doneZones));
        startTimer();
        current.tick();
        return { ok: true, run: names, caseId: rc.cs };
    }
    /* a run that ended: recorded in the book, its TK18 case ended, the run file closed */
    function settle() {
        if (!current) return null;
        var st = current.state().state; if (st !== "DONE" && st !== "STOPPED") return null;
        var rf = runFile(); if (!rf || !rf.active) return null;
        try { recordRun(current.state().res, rf.version, current.state()); } catch (_) {}
        try { tk18End(rf, st, current.state().reason || current.state().note); } catch (_) {}
        rf.active = false; rf.end = st; if (st === "DONE" && !current.state().keepOpen) { var cz = current.state().zone; rf.doneZones = (rf.doneZones || []).concat(cz != null ? [cz] : []); } runFile(rf);
        return st;
    }
    function startTimer() {
        if (!timer) timer = bg(setInterval(function () {
            try { if (!current) return; current.tick(); if (settle()) { try { pump(); } catch (_) {} } } catch (eT) {   // 0.2.167: the next promised request follows at once (re-assessed at TK18/da, rv-pm)
                /* 0.2.160 (live IP 09:56-10:07Z: the run sat in LOADR for 11 minutes without a word): an error in a tick is said, once a minute */
                try { if (!startTimer.errAt || Date.now() - startTimer.errAt > 60000) { startTimer.errAt = Date.now(); var msg = "adv: tick error: " + String(eT && (eT.stack || eT.message) || eT).slice(0, 300);
                    if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log(msg); airFile("dma-adv-error.json", { at: new Date().toISOString(), error: msg }); } } catch (_) {} }
        }, 2000));
    }
    function bg(t) { try { if (t && t.unref) t.unref(); } catch (_) {} return t; }   // 0.2.1: background timers do not keep a test process alive
    try { bg(setInterval(function () { try { watch({ limit: 3, guess: root.DMA_advGuessFolderByRes }); } catch (_) {} }, 600000)); } catch (_) {}   // 0.2.1
    /* 0.2.10: also learn on a visit without a run: every minute, when the viewed zone is one of our open adventures */
    try { bg(setInterval(function () {
        try { var G1 = gameGateway(), vz = G1.viewedZone(), res1 = null;
              advMgrList().forEach(function (a) { if (a.zoneID === vz && a.mine) res1 = a.res; });
              if (res1) learnMap(res1, G1.campMap()); } catch (_) {}
    }, 60000)); } catch (_) {}
    function advMgrList() {
        try { var R = root, am = R.swmmo.getDefinitionByName("com.bluebyte.tso.adventure.logic::AdventureManager").getInstance(), me = R.game.player.GetPlayerId(), out = [];
              am.getAdventures().forEach(function (a) { if (a) out.push({ zoneID: a.zoneID, res: a.adventureName, mine: a.ownerPlayerID === me }); }); return out; } catch (_) { return []; }
    }
    try { bg(setTimeout(function () {   // 0.1.8: catalogue inventory once per start
        try { var G0 = gameGateway(), pr = G0.probe(), A = root.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-adv-probe.json").nativePath), st = new A.FileStream();
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(pr, null, 1)); st.close(); } catch (_) {}
    }, 60000)); } catch (_) {}
    try { bg(setTimeout(function () {
        var W = root.DMA_WINDOW; if (W && W.role === "home" && W.advAlive && W.advAlive()) { try { if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log("adv: run left to the adventure window (ADR 0051)"); } catch (_) {} return; }   // 0.2.43
        var rf = runFile(); if (rf && rf.active && !current) { var r = runOnce(rf.id, rf.source, rf.version, true); try { if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log("adv: resume after restart " + JSON.stringify(r)); } catch (_) {}
            /* 0.2.167: a resume that cannot start ends its case, so the run file does not hold the queue for ever */
            if (!(r && r.ok)) { try { tk18End(rf, "STOPPED", "the run before the restart could not be resumed: " + (r && r.reason ? r.reason : "no reason")); } catch (_) {} rf.active = false; rf.end = "STOPPED"; runFile(rf); try { pump(); } catch (_) {} } }
    }, 90000)); } catch (_) {}
    /* 0.2.167 (B12): the waiting requests are assessed again (TK82/ac, the picture) - every 30 s */
    try { bg(setInterval(function () { try { if (rq().list.length) pump(); } catch (_) {} }, 30000)); } catch (_) {}
    /* 0.2.154 (2026-11-23, author: "blijf verbeteren, alleen mij meer actief op de hoogte houden"; the client window was hidden on
       another screen while a run had to go on): dma-adv-cmd.json {id, cmd: "finish" | "stop", adv, folder?, version?} next to the
       client is carried out once per id — the same as the console's Finish camp by camp / Stop — and answered in dma-adv-cmd-done.json */
    try { bg(setInterval(function () {
        try { var c = airFile("dma-adv-cmd.json"); if (!c || !c.id) return; var dn = airFile("dma-adv-cmd-done.json"); if (dn && dn.id === c.id) return;
              var r = null;
              if (c.cmd === "finish") r = api.finishCampByCamp(String(c.adv), c.folder || undefined, c.version || undefined);
              else if (c.cmd === "stop") { api.stop(); r = { ok: true }; }
              else if (c.cmd === "move" || c.cmd === "tostar") {   // 0.2.157: one general by hand (a test of placing from the star)
                  var Gm = gameGateway(), pk = {}; (c.keys || []).forEach(function (k) { pk[k] = { grid: c.cmd === "tostar" ? -1 : Number(c.grid), name: k, army: {}, target: 0, time: 1000, order: 0 }; });
                  if (c.cmd === "tostar") { Gm.toStar(c.keys || []); r = { ok: true }; } else r = { ok: true, sent: Gm.move(pk), inspect: Gm.inspect(pk) }; }
              else if (c.cmd === "probe") {   // 0.2.155: where the generals are and what the game says about the landing fields
                  var Gp = gameGateway(), zP = null; advMgrList().forEach(function (a) { if (a.res === String(c.adv) && a.mine) zP = a.zoneID; });
                  if (zP != null && Gp.viewedZone() !== zP) { Gp.visit(zP); return; }   // 0.2.156: probe at the adventure itself
                  var gens = Gp.mapGenerals(), m = book()[String(c.adv)] && book()[String(c.adv)].map, lf = (m && m.landing && m.landing.grids) || [], fl = {};
                  var ids = (c.ids && c.ids.length ? c.ids : gens.filter(function (x) { return !x.onMap; }).slice(0, 4).map(function (x) { return x.key; }));
                  lf.concat(c.grids || []).forEach(function (g) { fl[g] = {}; ids.forEach(function (k) { try { fl[g][k] = Gp.placeable(k, Number(g)); } catch (e) { fl[g][k] = String(e).slice(0, 40); } }); });
                  r = { ok: true, zone: Gp.viewedZone(), generals: gens, fields: fl, alive: Object.keys((m && m.camps) || {}).filter(function (g) { try { return Gp.campAlive(Number(g)); } catch (_) { return false; } }) }; }
              else r = { ok: false, reason: "unknown cmd " + c.cmd };
              airFile("dma-adv-cmd-done.json", { id: c.id, at: new Date().toISOString(), cmd: c.cmd, result: r });
              try { if (root.DMA_Control && root.DMA_Control.log) root.DMA_Control.log("adv: command " + c.cmd + " " + JSON.stringify(r)); } catch (_) {} } catch (_) {}
    }, 15000)); } catch (_) {}
    var api = { version: VERSION, RES: RES, MODES: MODES, createRun: createRun, needStar: needStar, landing: landing, learnLanding: learnLanding, landingRules: landingRules, stowPlan: stowPlan, shedPlan: shedPlan, waveLoadCheck: waveLoadCheck, carrierIds: carrierIds, phaseOf: phaseOf, PHASES: PHASES, toPacket: toPacket, runOnce: runOnce, resOf: resOf,
                book: function () { return JSON.parse(JSON.stringify(book())); }, saveVersion: saveVersion, addTest: addTest, nextTestNo: nextTestNo, testName: testName, removeVersion: removeVersion, setDefault: setDefault,
                starCounts: function () { try { return gameGateway().starCounts(); } catch (_) { return {}; } },
                starBuffs: function () { try { return gameGateway().starBuffs(null); } catch (_) { return {}; } }, arrowFacts: arrowFacts, arrowObserved: arrowObserved,   // 0.2.170 (F7)   // 0.2.169 (B14 beta): the arrows in the star, for Make my Mundane
                watch: watch, watchState: function () { return JSON.parse(JSON.stringify(watchState)); }, analyse: analyse, adviseBlocks: adviseBlocks,
                stop: function () { if (current) current.stop("stopped by the player"); },
                finishCampByCamp: function (id, source, version) {   // 0.2.84 (ADR 0079): the emergency mode, any version
                    if (current && current.emergency && !current.state().stopped && current.state().state !== "DONE") return { ok: current.emergency(), running: true };
                    var rf = runFile() || {}; id = id || rf.id; if (!id) return { ok: false, reason: "no adventure named" };
                    var src = source || (rf.id === id ? rf.source : ""), ver = version != null ? version : (rf.id === id ? rf.version : "");
                    /* 0.2.88 (F18, live BB 2026-11-17 17:47Z: the button passed the default version "full", whose folder is the
                       loose SOL\BB folder — its analysis was not ok and its run was a stray test template, claus3): the open
                       adventure is finished with the version its last run played, and never with a version whose analysis is not ok */
                    try { var eF = entry(resOf(id)), vs = eF.versions || [], byName = function (n) { var h = null; vs.forEach(function (v) { if (v.name === n) h = v; }); return h; };
                          var lastR = (eF.runs || []).slice().reverse().filter(function (r) { return r.version && byName(r.version); })[0], lv = lastR ? byName(lastR.version) : null;
                          if (lv && lv.name !== ver && lv.mode !== "arrows only") { src = lv.folder; ver = lv.name; }
                          var cv = byName(ver); if (cv && cv.analysis && cv.analysis.ok === false) return { ok: false, reason: "version \"" + ver + "\" is not playable (its analysis has errors): analyse it again or choose another version" }; } catch (_) {}
                    if (!src) { try { var e0 = entry(resOf(id)), v0 = (e0.versions || [])[e0.def || 0]; if (v0) { src = v0.folder; ver = v0.name; } } catch (_) {} }
                    if (!src) return { ok: false, reason: "no templates known for " + id + ": choose a version first" };
                    current = null; return runOnce(id, src, ver, true, { emergency: true }); },
                restartSafe: function () { try { return !current || current.restartSafe(); } catch (_) { return true; } },   // 0.2.7
                onOwnAdventure: function () { try { var G2 = gameGateway(), vz = G2.viewedZone(), ok = false; advMgrList().forEach(function (a) { if (a.mine && a.zoneID === vz) ok = true; }); return ok; } catch (_) { return false; } },   // 0.2.14
                setLsApproved: function (res, name, on) { var e = entry(res), ok = false; e.versions.forEach(function (v) { if (v.name === name && v.ls) { v.ls.approved = !!on; v.ls.approvedAt = new Date().toISOString(); ok = true; } }); bookSave(); return ok; },   // 0.2.17
                learnLs: learnLs, planFromSteps: planFromSteps, observeTick: observeTick, startLearning: startLearning, stopLearning: stopLearning, learning: function () { return learning ? { res: learning.res, name: learning.name, replace: learning.replace, steps: learning.steps.length, arrows: learning.steps.filter(function (x) { return x.kind === "arrow"; }).length, startedAt: learning.startedAt } : null; },   // 0.2.12
                arrowsInStar: function () { try { return gameGateway().arrows(); } catch (_) { return {}; } },
                createArrowRun: createArrowRun, analyseArrows: analyseArrows, planFor: planFor, setPlan: function (res, name, camp, plan) { var e = entry(res), hit = null; e.versions.forEach(function (v) { if (v.name === name) hit = v; }); if (!hit) return false; hit.plan = hit.plan || {}; hit.plan[camp] = plan; hit.analysis = analyseArrows(res, hit); bookSave(); return true; },   // 0.2.11
                learnMap: learnMap, campArmies: campArmies, landing: landing, learnLanding: learnLanding, landingRules: landingRules, needStar: needStar, campMap: function () { try { return gameGateway().campMap(); } catch (e) { return { error: String(e) }; } },
                /* 0.2.177 (B14 section 13): the camps watching the way from a spot to a camp, from the game's own path and watch areas
                   (the interception picture), for the Mundane generator's choice of spot; null when the game cannot say */
                way: function (from, to) { try { var r = gameGateway().intercepts({ w: { grid: Number(from), target: Number(to) } }).w; return r && r.steps ? r.by.slice() : null; } catch (e) { return null; } },   // 0.2.10
                tk18: { start: tk18Start, end: tk18End }, request: request, withdraw: withdraw, pump: function () { settle(); return pump(); }, caseKey: caseKey, resumePending: resumePending,   // 0.2.167 (B12)
                requests: function () { return JSON.parse(JSON.stringify(rq().list)); }, lsTag: lsTag, planSends: planSends, rulesFor: rulesFor, planCheck: planCheck,   // 0.2.51 (tests); 0.2.96: rulesFor
                travelBuffs: function () { var P = root.GCAF_PlayerPolicyInstance, m = "TravelBoost|StarChart|GeneralSpeedBuff|TravelDocuments"; try { var v = P && P.get ? P.get("adv.travel.match") : null; if (v) m = String(v); } catch (_) {}
                    var G0 = gameGateway(), c = {}; try { c = G0.starBuffs(new RegExp(m, "i")); } catch (_) {} var out = Object.keys(c).sort().map(function (n) { return { name: n, count: c[n], group: G0.buffGroup(n) }; });
                    try { var ob = G0.observatories(), seen = {}; ob.forEach(function (o) { o.recipes.forEach(function (r) { var k = "Observatory:" + r.name; if (!seen[k]) { seen[k] = { name: k, count: 0, group: G0.buffGroup(k), observatory: true, costs: r.costs }; out.push(seen[k]); } if (o.cooldownMs <= 0) seen[k].count += 1; }); }); } catch (_) {}   // 0.2.99: ready Observatories
                    return out; },   // 0.2.97
                exclusive: function (list) { var G0 = gameGateway(), seen = {}, hit = null; (list || []).forEach(function (n) { if (hit) return; var gp = null; try { gp = G0.buffGroup(n); } catch (_) {} if (gp == null) return; if (seen[gp]) hit = [seen[gp], n]; else seen[gp] = n; }); return hit ? { ok: false, conflict: hit } : { ok: true }; },   // 0.2.97
                   // 0.2.33 (tests)
                status: function () { if (!current) return null; var st = current.state(); st.version = current.version || ""; return st; } };   // 0.2.5: the version that runs
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    root.DMA_Adventure = api;
})(typeof window !== "undefined" ? window : this);
