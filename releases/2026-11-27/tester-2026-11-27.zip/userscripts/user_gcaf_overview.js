/*
 * Operations Overview 0.2.0 — blue display TK
 * Reads green PBC instances only. No SendServerAction.
 *
 * 0.2.0 (2026-10-24): when the Location Management PBC is not loaded (it is not in the
 * current userscript set), the island snapshot is taken from DMA_Control.map() — the
 * location manager's observation — with caps from the Player Policy. Same snapshot shape.
 * 0.2.1 (2026-10-24): a free deposit with a recent build order (DMA_Control.hasBuildOrder) is
 *   shown as "building", not "deposit" (construction sites looked like plain deposits).
 */
(function (root) {
    "use strict";
    var ID = "pbc.operations-overview";
    var NAME = "Operations Overview";
    var VERSION = "0.2.1";
    var CATALOG = ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];
    function sameRes(name, r) {
        name = String(name || "");
        if (name === r) return true;
        var ores = {
            BronzeOre: /^(MineDepletedDeposit)?(BronzeOre|CopperOre)$/i,
            IronOre: /^(MineDepletedDeposit)?IronOre(Industrial)?$/i,
            GoldOre: /^(MineDepletedDeposit)?GoldOre(Industrial)?$/i,
            Coal: /^(MineDepletedDeposit)?Coal$/i,
            TitaniumOre: /^(MineDepletedDeposit)?TitaniumOre$/i,
            Salpeter: /^(MineDepletedDeposit)?Salpeter$/i,
            Stone: /^Stone$/,
            Marble: /^Marble$/,
            Granite: /^Granite$/
        };
        return !!(ores[r] && ores[r].test(name));
    }
    function pad2(n) {
        n = String(n);
        return n.length < 2 ? "0" + n : n;
    }
    var lastAmt = {};
    function formatSecs(sec) {
        sec = Number(sec || 0);
        if (!sec || sec < 0) return "";
        var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
        if (m >= 60) {
            var h = Math.floor(m / 60);
            m = m % 60;
            return h + "h" + (m < 10 ? "0" : "") + m + "m";
        }
        return m + "m" + (s < 10 ? "0" : "") + s + "s";
    }
    function depleteEta(grid, amount) {
        amount = Number(amount);
        if (!(amount > 0) || grid == null) return "";
        var now = Date.now();
        var prev = lastAmt[String(grid)];
        lastAmt[String(grid)] = { amount: amount, at: now };
        if (!prev || !(prev.amount > amount) || !(now > prev.at)) return "";
        var rate = (prev.amount - amount) / ((now - prev.at) / 1000);
        if (!(rate > 0)) return "";
        return formatSecs(amount / rate);
    }
    var MINE_HINT = {
        BronzeOre: /^(Epic)?BronzeMine(Endless)?$|^CopperMine$/i,
        IronOre: /^(Epic)?IronMine$|^ArcticIronMine$/i,
        Coal: /^(Epic)?CoalMine$/i,
        GoldOre: /^(Epic)?GoldMine$/i,
        TitaniumOre: /^(Epic)?TitaniumMine$|^ArcticTitaniumMine$/i,
        Salpeter: /^(Epic)?SalpeterMine$/i,
        Stone: /^(Stone)?\s*Mason$|StoneMason|StoneQuarry/i,
        Marble: /MarbleMason/i,
        Granite: /GraniteMason/i
    };
    var WIKI = { Stone: 8, BronzeOre: 6, Marble: 10, IronOre: 16, GoldOre: 8, Coal: 6, Granite: 6, TitaniumOre: 6, Salpeter: 6 };

    function inst(name) {
        try { return root[name] || null; } catch (_) { return null; }
    }

    function classifyMines(buildingAll, r) {
        var hint = MINE_HINT[r];
        var working = 0, mini = 0, depleted = 0, k;
        buildingAll = buildingAll || {};
        for (k in buildingAll) {
            if (!buildingAll.hasOwnProperty(k)) continue;
            if (!hint || !hint.test(k)) continue;
            var n = Number(buildingAll[k] || 0);
            if (/Depleted/i.test(k)) depleted += n;
            else if (/Mini/i.test(k)) mini += n;
            else working += n;
        }
        return { working: working, mini: mini, depleted: depleted };
    }

    /* Location view over DMA_Control.map(): getSnapshot / refresh / cap / depositCount / freeDeposits */
    function controlLocation() {
        var ctrl = root.DMA_Control;
        if (!ctrl || typeof ctrl.map !== "function") return null;
        function snap() {
            var m = ctrl.map() || {};
            var caps = {};
            try {
                var p = root.GCAF_PlayerPolicyInstance;
                if (p && p.caps) caps = p.caps();
            } catch (_) {}
            return {
                home: m.home !== false,
                deposits: m.deposits || [],
                buildings: m.buildings || [],
                queue: m.queue || [],
                queueUsed: m.queueUsed,
                queueSlots: m.queueSlots,
                counts: { depositAll: (m.counts && m.counts.depositAll) || {}, buildingAll: (m.counts && m.counts.buildingAll) || {} },
                caps: caps,
                scannedAt: m.scannedAt
            };
        }
        function minedGrids() {
            var m = ctrl.map() || {}, g = {}, i, b;
            for (i = 0; i < (m.buildings || []).length; i++) {
                b = m.buildings[i];
                if (b && b.grid != null && /mine|mason|quarry/i.test(String(b.name || "")) && !/deposit|depleted/i.test(String(b.name || ""))) g[String(b.grid)] = true;
            }
            return g;
        }
        return {
            fromControl: true,
            refresh: function () {},
            getSnapshot: snap,
            cap: function (r) { var c = snap().caps; return Number(c && c[r]) || 0; },
            depositCount: function (r) {
                var d = snap().deposits, n = 0, i;
                for (i = 0; i < d.length; i++) if (sameRes(d[i].name, r) && !d[i].depleted) n += 1;
                return n;
            },
            freeDeposits: function (r) {
                var d = snap().deposits, used = minedGrids(), out = [], i;
                for (i = 0; i < d.length; i++) if (sameRes(d[i].name, r) && !d[i].depleted && !used[String(d[i].grid)]) out.push(d[i]);
                return out;
            }
        };
    }

    function gather() {
        var loc = inst("GCAF_LocationManagementInstance") || controlLocation();
        var search = inst("GCAF_GeologistSearchInstance");
        var bld = inst("GCAF_BuildingManagementInstance");
        var buf = inst("GCAF_BuffManagementInstance");
        var dem = inst("GCAF_DemolishManagementInstance");
        var inv = inst("GCAF_InventoryManagementInstance");
        var pol = inst("GCAF_PlayerPolicyInstance");
        try { if (loc && loc.refresh) loc.refresh(); } catch (_) {}
        try { if (root.DMA_Control && root.DMA_Control.scan) root.DMA_Control.scan(); } catch (_) {}
        try {
            if (pol && typeof pol.observeScan === "function" && loc && loc.getSnapshot) {
                pol.observeScan(loc.getSnapshot());
            }
        } catch (_) {}

        var snap = loc && loc.getSnapshot ? loc.getSnapshot() : { counts: { depositAll: {}, buildingAll: {} }, deposits: [], buildings: [], caps: {}, home: false };
        var counts = (snap.counts && snap.counts.depositAll) || {};
        var buildings = (snap.counts && snap.counts.buildingAll) || {};
        var openSearch = {};
        try { if (search && search.getOpenAssignments) openSearch = search.getOpenAssignments() || {}; } catch (_) {}
        var geos = [];
        try { if (search && search.listGeologists) geos = search.listGeologists() || []; } catch (_) {}
        if (!geos.length && root.DMA_Control && typeof root.DMA_Control.geologists === "function") {
            try { geos = root.DMA_Control.geologists() || []; } catch (_) {}
        }
        if (!geos.length) {
            try {
                var raw = (typeof game !== "undefined" && game.getSpecialists) ? game.getSpecialists() : [];
                if (raw && raw.forEach) raw.forEach(function (item) {
                    var base = null, task = null;
                    try { base = item.GetBaseType(); } catch (_) {}
                    try { task = item.GetTask(); } catch (_) {}
                    if (base === 2) geos.push({ idle: !task, raw: item });
                });
            } catch (_) {}
        }
        var idle = 0, i, g;
        var searchClock = {};
        for (i = 0; i < geos.length; i++) {
            g = geos[i];
            if (g && g.idle) idle += 1;
        }
        var rk;
        for (rk in openSearch) {
            if (!openSearch.hasOwnProperty(rk) || !openSearch[rk]) continue;
            var sid = String(openSearch[rk].specialistId || "");
            var remS = null;
            for (i = 0; i < geos.length; i++) {
                if (!geos[i] || geos[i].idle) continue;
                if (sid && String(geos[i].id || "") === sid) {
                    remS = geos[i].remainingSec || geos[i].remaining;
                    break;
                }
            }
            searchClock[rk] = remS || openSearch[rk].predictedDuration || "Q";
            if (typeof remS === "number") searchClock[rk] = formatSecs(remS);
        }

        var resources = [];
        var missingTotal = 0;
        var geosOut = 0;
        var nextEmpty = null;
        var r, cap, have, miss, mines, rem, d, j, lowest;
        for (i = 0; i < CATALOG.length; i++) {
            r = CATALOG[i];
            cap = loc && loc.cap ? loc.cap(r) : Number((snap.caps || {})[r] || 0);
            have = loc && loc.depositCount ? loc.depositCount(r) : Number(counts[r] || 0);
            miss = Math.max(0, Math.min(Number(cap) || 0, (WIKI && WIKI[r] != null ? WIKI[r] + 1 : Number(cap) || 0)) - have);
            missingTotal += miss;
            mines = classifyMines(buildings, r);
            lowest = null;
            for (j = 0; j < (snap.deposits || []).length; j++) {
                d = snap.deposits[j];
                if (!sameRes(d.name, r)) continue;
                rem = d.amount;
                if (rem == null) continue;
                rem = Number(rem);
                if (lowest == null || rem < lowest) lowest = rem;
            }
            if (lowest != null && (nextEmpty == null || lowest < nextEmpty.remaining)) {
                nextEmpty = { resourceType: r, remaining: lowest, eta: "n/a" };
            }
            if (openSearch[r]) geosOut += 1;
            var locs = [];
            var masonType = r === "Stone" || r === "Marble" || r === "Granite";
            var masonList = [];
            if (masonType) {
                var hx = MINE_HINT[r];
                for (j = 0; j < (snap.buildings || []).length; j++) {
                    if (hx && hx.test(String(snap.buildings[j].name || "")) && !/Depleted/i.test(String(snap.buildings[j].name || ""))) masonList.push(snap.buildings[j]);
                }
            }
            var nSlots = 0;
            var orePool = [];
            for (j = 0; j < (snap.deposits || []).length; j++) {
                if (sameRes(snap.deposits[j].name, r)) orePool.push(snap.deposits[j]);
            }
            nSlots = orePool.length;
            var usedGrid = {};
            var sn, sk, labk, storedGrid, lab, dep, bldAt, reason, found;
            for (sn = 1; sn <= nSlots; sn++) {
                sk = "location.slot." + r + "." + sn;
                labk = "location.label." + r + "." + sn;
                storedGrid = pol && pol.get ? pol.get(sk) : null;
                found = null;
                if (storedGrid != null && storedGrid !== "" && !usedGrid[String(storedGrid)]) {
                    for (j = 0; j < (snap.deposits || []).length; j++) {
                        if (String(snap.deposits[j].grid) === String(storedGrid) && sameRes(snap.deposits[j].name, r)) {
                            found = snap.deposits[j];
                            break;
                        }
                    }
                }
                if (!found && orePool && orePool.length) {
                    for (j = 0; j < orePool.length; j++) {
                        dep = orePool[j];
                        if (usedGrid[String(dep.grid)]) continue;
                        found = dep;
                        if (pol && pol.requestChange && found.grid != null) {
                            try { pol.requestChange(sk, String(found.grid)); } catch (_) {}
                        }
                        break;
                    }
                }
                if (!found && masonType) {
                    var hintB = MINE_HINT[r];
                    for (j = 0; j < (snap.buildings || []).length; j++) {
                        var bb = snap.buildings[j];
                        if (!hintB || !hintB.test(String(bb.name || ""))) continue;
                        if (/Depleted/i.test(String(bb.name || ""))) continue;
                        if (usedGrid[String(bb.grid)]) continue;
                        if (storedGrid != null && String(bb.grid) !== String(storedGrid)) continue;
                        found = { grid: bb.grid, name: bb.name, amount: null, depleted: false };
                        if (pol && pol.requestChange && bb.grid != null) {
                            try { pol.requestChange(sk, String(bb.grid)); } catch (_) {}
                        }
                        break;
                    }
                }
                if (!found && masonType) {
                    hintB = MINE_HINT[r];
                    for (j = 0; j < (snap.buildings || []).length; j++) {
                        bb = snap.buildings[j];
                        if (!hintB || !hintB.test(String(bb.name || ""))) continue;
                        if (/Depleted/i.test(String(bb.name || ""))) continue;
                        if (usedGrid[String(bb.grid)]) continue;
                        found = { grid: bb.grid, name: bb.name, amount: null, depleted: false };
                        if (pol && pol.requestChange && bb.grid != null) {
                            try { pol.requestChange(sk, String(bb.grid)); } catch (_) {}
                        }
                        break;
                    }
                }
                if (found && found.grid != null) usedGrid[String(found.grid)] = true;
                lab = (found && found.grid != null && root.DMA_Labels && root.DMA_Labels.get && root.DMA_Labels.get("location.label.grid." + found.grid))
                    || (root.DMA_Labels && root.DMA_Labels.get && root.DMA_Labels.get(labk))
                    || (found && found.grid != null && pol && pol.get && pol.get("location.label.grid." + found.grid))
                    || (pol && pol.get && pol.get(labk))
                    || ("S" + pad2(i + 1) + ":" + pad2(sn));
                bldAt = null;
                if (found && found.grid != null) {
                    try {
                        var zone = (typeof game !== "undefined" && game.zone) ? game.zone : null;
                        if (!zone && typeof game !== "undefined" && game.gi) zone = game.gi.mCurrentPlayerZone;
                        var live = zone && zone.GetBuildingFromGridPosition ? zone.GetBuildingFromGridPosition(Number(found.grid)) : null;
                        if (live && typeof live.GetBuildingName_string === "function") {
                            var ln = String(live.GetBuildingName_string() || "");
                            if (MINE_HINT[r] && MINE_HINT[r].test(ln)) {
                                bldAt = {
                                    name: ln,
                                    grid: (live.GetGrid && live.GetGrid()) || found.grid,
                                    uiLevel: live.GetUIUpgradeLevel ? live.GetUIUpgradeLevel() : null,
                                    level: live.GetUIUpgradeLevel ? live.GetUIUpgradeLevel() : null,
                                    upgradeInProgress: !!(live.IsUpgradeInProgress && live.IsUpgradeInProgress())
                                };
                            }
                        }
                    } catch (_) {}
                    if (!bldAt) {
                        for (j = 0; j < (snap.buildings || []).length; j++) {
                            if (String(snap.buildings[j].grid) !== String(found.grid)) continue;
                            if (MINE_HINT[r] && MINE_HINT[r].test(String(snap.buildings[j].name || ""))) {
                                bldAt = snap.buildings[j];
                                break;
                            }
                        }
                    }
                }
                if (found && (found.amount == null || found.amount === "") && found.grid != null) {
                    for (j = 0; j < (snap.deposits || []).length; j++) {
                        if (String(snap.deposits[j].grid) === String(found.grid)) {
                            found.amount = snap.deposits[j].amount;
                            break;
                        }
                    }
                }
                if (found && /Depleted/i.test(String(found.rawName || found.name || ""))) found.depleted = true;
                if (found && found.amount != null && Number(found.amount) === 0) found.depleted = true;
                reason = "empty";
                if (found && found.depleted) reason = "depleted";
                else if (found && !bldAt) reason = "deposit";
                else if (bldAt && bldAt.upgradeInProgress) reason = "upgrade";
                else if (bldAt) reason = /Mason/i.test(String(bldAt.name || "")) ? "mason" : "mine";
                var qHit = null, qj;
                var gkey = found && found.grid != null ? String(found.grid) : "";
                for (qj = 0; qj < (snap.queue || []).length; qj++) {
                    if (gkey && String(snap.queue[qj].grid) === gkey) { qHit = snap.queue[qj]; break; }
                }
                var promised = null;
                try {
                    var bapi = inst("GCAF_BuildingManagementInstance");
                    var op = bapi && bapi.getOpenConstruction && bapi.getOpenConstruction();
                    if (op && gkey && op[gkey]) promised = op[gkey];
                } catch (_) {}
                if (reason === "deposit" && gkey) {
                    try { if (root.DMA_Control && root.DMA_Control.hasBuildOrder && root.DMA_Control.hasBuildOrder(gkey)) reason = "building"; } catch (_) {}
                }
                if (qHit && reason !== "mine" && reason !== "mason" && reason !== "depleted") {
                    reason = "building" + (qHit.percent != null ? (" " + qHit.percent + "%") : "");
                } else if (promised && reason === "empty") {
                    reason = promised.transactionFact === "ex" ? "building (ex)" : "promised";
                }
                locs.push({
                    slot: sn,
                    label: lab,
                    labelRule: labk,
                    grid: found ? found.grid : storedGrid,
                    amount: found ? found.amount : null,
                    depleted: !!(found && found.depleted),
                    building: bldAt && bldAt.name,
                    level: bldAt && (bldAt.uiLevel != null ? bldAt.uiLevel : bldAt.level),
                    levelTo: (bldAt && bldAt.upgradeInProgress)
                        ? (Number(bldAt.uiLevel != null ? bldAt.uiLevel : bldAt.level) + 1)
                        : null,
                    reason: reason,
                    searchTime: (reason === "empty" || reason === "depleted") ? (searchClock[r] || "") : "",
                    eta: (reason === "mine" || reason === "mason") ? depleteEta(found && found.grid, found && found.amount) : ""
                });
            }
            if (masonType) {
                for (j = 0; j < masonList.length; j++) {
                    var mb = masonList[j];
                    if (!mb) continue;
                    locs.push({
                        slot: "M" + pad2(j + 1),
                        label: (root.DMA_Labels && root.DMA_Labels.get && root.DMA_Labels.get("location.label." + r + ".mason." + (j + 1))) || ("mason " + pad2(j + 1)),
                        labelRule: "location.label." + r + ".mason." + (j + 1),
                        grid: mb.grid,
                        amount: null,
                        depleted: false,
                        building: mb.name,
                        level: mb.uiLevel != null ? mb.uiLevel : mb.level,
                        levelTo: mb.upgradeInProgress ? (Number(mb.uiLevel != null ? mb.uiLevel : mb.level) + 1) : null,
                        reason: "mason",
                        searchTime: "",
                        eta: ""
                    });
                }
            }
            resources.push({
                resourceType: r,
                count: have,
                cap: cap,
                missing: miss,
                inPlay: have > 0 || mines.working + mines.mini > 0,
                search: openSearch[r] || null,
                mines: mines,
                free: loc && loc.freeDeposits ? loc.freeDeposits(r).length : 0,
                lowestRemaining: lowest,
                eta: "n/a",
                searchRemaining: openSearch[r] && (openSearch[r].predictedDuration || openSearch[r].remaining),
                buildingNow: 0,
                levelText: "—",
                locations: locs
            });
        }

        var qi, qit, ri, hint;
        for (qi = 0; qi < (snap.queue || []).length; qi++) {
            qit = snap.queue[qi];
            for (ri = 0; ri < resources.length; ri++) {
                hint = MINE_HINT[resources[ri].resourceType];
                if (hint && hint.test(String(qit.name || ""))) resources[ri].buildingNow += 1;
            }
        }
        var levels = {};
        for (qi = 0; qi < (snap.buildings || []).length; qi++) {
            qit = snap.buildings[qi];
            for (ri = 0; ri < resources.length; ri++) {
                hint = MINE_HINT[resources[ri].resourceType];
                if (!hint || !hint.test(String(qit.name || ""))) continue;
                if (/Depleted/i.test(String(qit.name || ""))) continue;
                var lv = qit.uiLevel != null ? qit.uiLevel : qit.level;
                if (lv == null) continue;
                lv = Number(lv);
                if (!levels[resources[ri].resourceType]) levels[resources[ri].resourceType] = { min: lv, max: lv };
                if (lv < levels[resources[ri].resourceType].min) levels[resources[ri].resourceType].min = lv;
                if (lv > levels[resources[ri].resourceType].max) levels[resources[ri].resourceType].max = lv;
            }
        }
        for (ri = 0; ri < resources.length; ri++) {
            if (levels[resources[ri].resourceType]) {
                resources[ri].levelText = levels[resources[ri].resourceType].min + "→" + levels[resources[ri].resourceType].max;
            }
            if (openSearch[resources[ri].resourceType]) {
                resources[ri].searchRemaining = openSearch[resources[ri].resourceType].predictedDuration || openSearch[resources[ri].resourceType].remaining || "Q";
            }
        }

        var alerts = [];
        var pol = inst("GCAF_PlayerPolicyInstance");
        var execOn = false, buildOn = false;
        try { execOn = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        try { buildOn = !!(pol && pol.get && pol.get("building.autoEnabled")); } catch (_) {}
        var bLast = bld && bld.getStatus ? bld.getStatus() : null;
        if (bLast && bLast.last && bLast.last.fact === "dc") {
            alerts.push({ level: "intervene", tk: "construction", fact: "dc", reason: bLast.last.reason, detail: bLast.last.detail || null });
        }
        for (i = 0; i < resources.length; i++) {
            if (resources[i].free > 0 && buildOn && !execOn) {
                alerts.push({ level: "intervene", tk: "construction", reason: "execute-off", resourceType: resources[i].resourceType, free: resources[i].free });
            }
            if (resources[i].free > 0 && buildOn && execOn && ["Stone", "Marble", "Granite"].indexOf(resources[i].resourceType) >= 0) {
                alerts.push({ level: "intervene", tk: "construction", reason: "no-build-mapping", resourceType: resources[i].resourceType });
            }
        }
        if (idle === 0 && geos.length) {
            alerts.push({ level: "info", tk: "search", reason: "no-idle-geologist" });
        }

        return {
            id: ID,
            version: VERSION,
            suite: root.GCAF_SuiteVersion || (root.DMA_Control && root.DMA_Control.suiteVersion) || "0.1.0",
            control: root.DMA_Control && root.DMA_Control.version,
            home: !!(snap.home),
            tiles: {
                missing: missingTotal,
                geosOut: geosOut,
                minesWorking: resources.reduce(function (a, x) { return a + x.mines.working + x.mines.mini; }, 0),
                nextEmpty: nextEmpty
            },
            idleGeologists: idle,
            geologists: geos,
            resources: resources,
            construction: bld && bld.getOpenConstruction ? bld.getOpenConstruction() : null,
            queue: (snap.queue || []).slice(),
            queueUsed: snap.queueUsed,
            queueSlots: snap.queueSlots,
            buffs: buf && buf.getOpenAssignments ? buf.getOpenAssignments() : {},
            demolishCandidates: dem && dem.candidates ? dem.candidates() : [],
            pbcs: root.DMA_Control && root.DMA_Control.listPbcs ? root.DMA_Control.listPbcs() : [],
            alerts: alerts,
            lastBuild: bLast && bLast.last ? bLast.last : null
        };
    }

    function boardText(b) {
        var lines = [];
        lines.push("DMA Overview " + VERSION + " suite " + b.suite + " control " + (b.control || "?") + " home:" + b.home);
        lines.push("Gap " + b.tiles.missing + " | geos out " + b.tiles.geosOut + " | mines " + b.tiles.minesWorking + " | idle geo " + b.idleGeologists);
        if (b.queueUsed != null) {
            var qn = [];
            var qi, qit;
            for (qi = 0; qi < (b.queue || []).length; qi++) {
                qit = b.queue[qi];
                qn.push((qit.name || "?") + (qit.percent != null ? " " + qit.percent + "%" : ""));
            }
            lines.push("Queue " + b.queueUsed + "/" + (b.queueSlots != null ? b.queueSlots : "?") + (qn.length ? " " + qn.join(", ") : ""));
        }
        if (b.tiles.nextEmpty) lines.push("Lowest remaining " + b.tiles.nextEmpty.resourceType + " " + b.tiles.nextEmpty.remaining + " eta " + b.tiles.nextEmpty.eta);
        if (b.alerts && b.alerts.length) {
            var ai, al;
            for (ai = 0; ai < b.alerts.length; ai++) {
                al = b.alerts[ai];
                lines.push((al.level === "intervene" ? "INGRIJP " : "info ") + (al.tk || "") + " " + (al.reason || "") + (al.resourceType ? " " + al.resourceType : ""));
            }
        }
        var i, x, s;
        for (i = 0; i < b.resources.length; i++) {
            x = b.resources[i];
            s = x.resourceType + " " + x.count + "/" + x.cap + " miss " + x.missing + " free " + x.free + " mines " + x.mines.working + "+" + x.mines.mini;
            if (x.search) s += " SEARCH " + (x.search.specialistTypeName || x.search.transactionFact);
            if (x.lowestRemaining != null) s += " rem " + x.lowestRemaining;
            lines.push(s);
        }
        return lines.join("\n");
    }

    function show() {
        var b = gather();
        var html;
        try {
            if (typeof createModalWindow === "function") {
                createModalWindow("DMA_OperationsOverview", "DMA Overview");
                html = "<div style='padding:8px;font:12px/1.4 sans-serif;white-space:pre-wrap'>";
                html += boardText(b).replace(/</g, "&lt;");
                html += "</div>";
                if (typeof $("#DMA_OperationsOverview") !== "undefined") {
                    $("#DMA_OperationsOverview").html(html);
                }
            }
        } catch (_) {}
        try { game.showAlert("DMA Overview gap " + b.tiles.missing + " geos " + b.tiles.geosOut + " mines " + b.tiles.minesWorking + " idle " + b.idleGeologists); } catch (_) {}
        try { if (typeof debug === "function") debug(b); } catch (_) {}
        return b;
    }

    var api = {
        id: ID, name: NAME, version: VERSION,
        gather: gather,
        show: show,
        getStatus: function () { return { id: ID, name: NAME, version: VERSION, started: true }; }
    };
    root.GCAF_OperationsOverview = api;
    root.GCAF_OperationsOverviewInstance = api;
    /* DMA Overview menu item removed — console is the only UI */
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
