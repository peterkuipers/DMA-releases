/*
 * 0.1.2 (2026-11-24, architect review 2026-11-24-gcaf-gateway): (a) a refusal is an information fact (record "i"), not a production fact — it
 *   is not in the fact model; (b) the complete pattern: execute after promised and after rejected (re-execute before a new declare), not after
 *   declared; the remaining narrowings against EO2 ch. 8 are documented in NEXT and follow the book (one view): no revoke request on a declined case
 *   (the book's REVOKE table), and after accept only revoke accept (the book reopens a closed case only for that); (c) self-activation comes from the TPT (DMA_Rules.roles(tk).selfActivating): a TK
 *   with no initiator link that is not self-activating is refused (a support TK until its initiator links are modelled).
 *   Unit: tests/unit/gcaf-transaction-framework.test.js, tests/unit/gcaf-gateway-defects.test.js. Integration: tests/integration/gcaf-gateway-forge.test.js.
 * 0.1.1 (2026-11-24, tester findings on 0.1.0): (1) after accept only revoke accept and a new request are allowed — the book reopens an accepted
 *   case only for revoke accept, so the other revocations would split the gateway's view from the book's; (2) a case key that differs from the key
 *   the book derives from the data is refused; (3) without the transaction book every act is refused (no state, no judgement — no request storm).
 *   Open: a revocation that is never answered keeps the case revoking (book 0.4.x does not archive it). Unit: tests/unit/gcaf-gateway-defects.test.js.
 * Stable client filename: transaction-framework.js (sorts after game-interface-adapter.js and pbc-*, before user_*: it loads
 * before every application PBC; the backbone catalogue user_dma_rules.js and the transaction book are read at call time).
 *
 * G-CAF Promise/Transaction Framework 0.1.0 — THE COORDINATION GATEWAY (ADR 0099; recovery plan phase 1.1; ADR 0098 the
 * backbone comes first; G-CAF layer Frameworks, docs/01-architecture/solution-architecture.md).
 *
 * DEMO: every coordination act of every PBC passes here. The gateway holds the transaction pattern of DEMO 4 (2nd edition,
 * with the six revocations) and the roles of the construction model, both taken from the backbone through the generated
 * catalogue DMA_Rules (user_dma_rules.js 0.1.4: executor and initiator roles per TK, the support TKs). It refuses — with
 * the reason, recording nothing — an act that the model does not allow:
 *   - a TK that is no transaction kind of the backbone (during migration a pending green/blue id is let through, named);
 *   - an act that is no DEMO 4 coordination act and not the production act "execute";
 *   - an act by a role that does not perform it: request, accept, reject, revoke request, revoke accept, revoke reject by
 *     the initiator (a CSD initiator link; for a TK that is self-activating in the TPT, its executor; neither: refused); promise, decline,
 *     declare, execute, revoke promise, revoke declare, revoke decline by the executor (TPT); allow / refuse by the party
 *     that did not revoke;
 *   - an act not allowed in the case's current state (the standard pattern with its revocations);
 *   - a new request for a case that is open (requested, promised, declared, rejected, or revoking) — author 2026-11-01;
 *   - a decline, reject, revoke or refuse without a reason — author 2026-11-24.
 * What passes is recorded as the C-fact through DMA_Demo.record("c", …) with the backbone's role names; the transaction book
 * (blue, user_dma_transactions.js) keeps it, and the gateway reads the case's state back from the book, so both hold one truth.
 *
 * API (global GCAF_Transactions):
 *   act(tk, act, caseKey, { by, reason, data })  -> { ok: true, state } | { ok: false, refused: true, why }
 *   state(tk, caseKey)  -> the book's state ("requested" … "accepted", "initial" when voided) or null
 *   isOpen(tk, caseKey) -> true while requested / promised / declared / rejected / revoking
 *   refusals()          -> the last 50 refusals (for the console and the architect's live review)
 * `by` is a backbone role id ("AR66") or its name ("resource supply manager").
 *
 * Unit: tests/unit/gcaf-transaction-framework.test.js. Integration: tests/integration/gcaf-gateway-forge.test.js.
 */
(function (root) {
    "use strict";
    if (root.GCAF_Transactions && root.GCAF_Transactions.version) return;
    var VERSION = "0.1.2";
    var INITIATOR_ACTS = { request: 1, accept: 1, reject: 1, "revoke request": 1, "revoke accept": 1, "revoke reject": 1 };
    var EXECUTOR_ACTS = { promise: 1, decline: 1, declare: 1, execute: 1, "revoke promise": 1, "revoke declare": 1, "revoke decline": 1 };
    var ANSWER_ACTS = { allow: 1, refuse: 1 };   // the party that did not revoke answers a revocation
    var REASON_ACTS = { decline: 1, reject: 1, "revoke request": 1, "revoke promise": 1, "revoke declare": 1, "revoke accept": 1, "revoke decline": 1, "revoke reject": 1, refuse: 1 };
    /* the standard pattern (EO2 ch. 8; DEMO 4 2nd ed.): which act may follow which state; null = no instance yet or voided */
    var NEXT = {
        none:      { request: 1 },
        initial:   { request: 1 },
        requested: { promise: 1, decline: 1, "revoke request": 1 },
        promised:  { declare: 1, execute: 1, "revoke request": 1, "revoke promise": 1 },
        declined:  { request: 1, "revoke decline": 1 },   /* narrowing, documented: the book (REVOKE, ADR 0070 "requested or further") has no revoke request on a declined case; it is left by a renewed request, a revoke decline, or archived after 1 h */
        declared:  { accept: 1, reject: 1, "revoke request": 1, "revoke promise": 1, "revoke declare": 1 },
        rejected:  { execute: 1, declare: 1, "revoke request": 1, "revoke promise": 1, "revoke declare": 1, "revoke reject": 1 },
        accepted:  { "revoke accept": 1, request: 1 }   /* 0.1.1 (tester): the book reopens an accepted case only for revoke accept; the other revocations after accept wait until the book carries them */
    };
    var OPEN = { requested: 1, promised: 1, declared: 1, rejected: 1 };
    var refused = [];

    function catalogue() { var R = root.DMA_Rules; return R && typeof R.roles === "function" ? R : null; }
    function book() { var T = root.DMA_Tx; return T && typeof T.state === "function" ? T : null; }
    function bookEntry(tk, key) { var T = book(); if (!T || typeof T.open !== "function") return null; try { return T.open(String(tk), String(key)); } catch (_) { return null; } }
    function pending(tk) {
        try { var P = root.GCAF_PENDING_TKS; if (P && Object.prototype.hasOwnProperty.call(P, tk)) return true; } catch (_) {}
        return /^TK-(BLUE|LOC|VISIT|SAFE|MAIL)$/.test(tk);   // pending green/blue ids (dist/dma-ontology.json pendingID), until phase 3 B9
    }
    function roleMatch(by, r) { if (!r || !by) return false; var b = String(by).toLowerCase(); return b === String(r.id).toLowerCase() || b === String(r.name).toLowerCase() || b === (String(r.id) + " " + String(r.name)).toLowerCase(); }
    function refuse(tk, act, key, why) {
        refused.push({ at: Date.now(), tk: tk, act: act, caseId: key, why: why }); if (refused.length > 50) refused.shift();
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", { fact: "coordination refused", tk: tk, act: act, caseId: key, why: why, by: "transaction framework " + VERSION }); } catch (_) {}
        return { ok: false, refused: true, why: why };
    }
    function currentState(tk, key) {
        var e = bookEntry(tk, key); if (e) return { state: e.state, revoking: e.revoking || "" };
        var T = book(), s = null; if (T) { try { s = T.state(String(tk), String(key)); } catch (_) {} }
        return { state: s || "none", revoking: "" };
    }
    function act(tk, a, key, o) {
        o = o || {}; tk = String(tk || ""); a = String(a || ""); key = key == null ? "" : String(key);
        var R = catalogue(); if (!R) return refuse(tk, a, key, "the backbone catalogue (DMA_Rules) is not loaded");
        if (!key) return refuse(tk, a, key, "no case key");
        var T = book(); if (!T) return refuse(tk, a, key, "the transaction book (DMA_Tx) is not loaded: without the state of the case no act can be judged");   // 0.1.1 (tester)
        if (typeof T.keyOf === "function" && o.data && typeof o.data === "object") {   // 0.1.1 (tester): one case key, the gateway's and the book's
            var bk = null; try { var d0 = { tk: tk, caseId: key }; Object.keys(o.data).forEach(function (k) { if (!(k in d0)) d0[k] = o.data[k]; }); bk = T.keyOf(d0); } catch (_) {}
            if (bk != null && String(bk) !== key) return refuse(tk, a, key, "the case key " + key + " differs from the key the transaction book derives from the data (" + bk + ")");
        }
        var roles = R.roles(tk), isPending = !roles && pending(tk);
        if (!roles && !isPending) return refuse(tk, a, key, "not a transaction kind of the backbone: " + tk);
        if (!INITIATOR_ACTS[a] && !EXECUTOR_ACTS[a] && !ANSWER_ACTS[a]) return refuse(tk, a, key, "not a DEMO 4 coordination act: " + a);
        if (REASON_ACTS[a] && !(o.reason && String(o.reason).replace(/\s+/g, ""))) return refuse(tk, a, key, a + " without a reason");
        var cur = currentState(tk, key);
        /* the performer */
        var initiators = [], executor = null, performer = null;
        if (roles) {
            executor = roles.executor; initiators = (roles.initiators && roles.initiators.length) ? roles.initiators : roles.selfActivating ? [roles.executor] : [];   // 0.1.2: self-activating per the TPT
            if (!initiators.length && !pending(tk)) return refuse(tk, a, key, tk + " has no initiator link in the backbone and is not self-activating: its initiator must be modelled first");
            var want = INITIATOR_ACTS[a] ? initiators : EXECUTOR_ACTS[a] ? [executor] : (/^revoke (request|accept|reject)$/.test(cur.revoking) ? [executor] : initiators);
            for (var i = 0; i < want.length; i++) if (roleMatch(o.by, want[i])) performer = want[i];
            if (!performer) return refuse(tk, a, key, a + " of " + tk + " is performed by " + want.map(function (r) { return r.id + " " + r.name; }).join(" or ") + ", not by " + (o.by || "nobody"));
        }
        /* the state */
        if (ANSWER_ACTS[a]) {
            if (!cur.revoking) return refuse(tk, a, key, a + " without a revocation to answer (state " + cur.state + ")");
        } else {
            if (cur.revoking) return refuse(tk, a, key, "the case is revoking (" + cur.revoking + "): answer it first with allow or refuse");
            var allowed = NEXT[cur.state] || {};
            if (a === "request" && OPEN[cur.state]) return refuse(tk, a, key, "a request for an open case (" + cur.state + "): one transaction per case at a time");
            if (!allowed[a]) return refuse(tk, a, key, a + " is not allowed after " + cur.state);
        }
        /* record the C-fact */
        var f = { tk: tk, act: a, caseId: key, actor: performer ? performer.name : String(o.by || ""), role: performer ? performer.id : "", by: "transaction framework " + VERSION };
        if (o.reason) f.reason = String(o.reason);
        if (executor) f.executor = executor.name;
        if (initiators.length) f.initiator = initiators[0].name;
        if (o.data && typeof o.data === "object") Object.keys(o.data).forEach(function (k) { if (!(k in f)) f[k] = o.data[k]; });
        try { root.DMA_Demo.record("c", f); } catch (e) { return refuse(tk, a, key, "the C-fact could not be recorded: " + e); }
        return { ok: true, state: currentState(tk, key).state };
    }
    root.GCAF_Transactions = {
        version: VERSION,
        act: act,
        state: function (tk, key) { var c = currentState(String(tk), String(key)); return c.state === "none" ? null : c.state; },
        isOpen: function (tk, key) { var c = currentState(String(tk), String(key)); return !!(OPEN[c.state] || c.revoking); },
        refusals: function () { return JSON.parse(JSON.stringify(refused)); }
    };
})(typeof window !== "undefined" ? window : this);
