/*
 * user_dma_trade.js — Trade acceptor (PBC Trade, DEMO TK25 "trade accepting"); a round trade is its specialisation
 * 0.1.29 (2026-11-17, tester release, author: nothing may fit only his island): linesOf() took a guild line that contains the literal "kuipje"
 *   (the author's in-game name) as addressing the player. It now reads only the OWNER's own names: the in-game name read from the game
 *   (DMA_Chat.ownName()), the chat reply words of the policy (DMA_Chat.words()) and the owner name the chat gives (ownerName(), never the
 *   fallback "the player"); names of fewer than two letters are ignored. Nothing else changes.
 *   Unit: tests/unit/dma-trade-addressing.test.js (a guild line with "kuipje" does not address a player called Zed; "zed, wait" and the
 *   chat word do; no names known = no guild line addresses the player). Integration: tests/integration/dma-trade-close-it.test.js
 *   (an addressed guild line "Peter, wait" gives more time; conversation does not; "close it" revokes).
 * 0.1.28 (2026-11-16, author: "why is the inbox opening constantly?"): live, while one RT case waited for trades (Norwegian_AI, promised
 *   18:01 UTC, no trade sent), every tick asked control for the mail window (ensureMailPanel -> a mail-manager round), so the inbox was
 *   open 33 s of every 40 s for half an hour. Now, while the window is not open, the acceptor asks for a round at most once per
 *   roundEveryMs (2 min) per case, and once at the promise; when the player has the window open it reads it as before. A trade sent
 *   is therefore seen within 2 min; pairWaitMs (3 min) still holds. Unit: none (behaviour). Integration:
 *   tests/integration/dma-trade-inbox-throttle.test.js (30 ticks of 5 s while waiting give at most 2 round requests).
 * 0.1.27 (2026-11-16, author: "did you read the reaction of Norwegian_AI, that can be considered as a revoke request"): live, after
 *   "the waiting time is up ... Need more time?" Norwegian_AI whispered "close it"; the acceptor did not see a revocation and, one minute
 *   later, read "one moment" from his GUILD chat talk as a request for more time ("ok, 3 more minutes"). Two changes:
 *   (1) the requester's lines that count are his whispers to us, and his guild lines only when they address the player (owner name or
 *       "kuipje"); his other guild chat is conversation, not an act. Read from DMA_Chat.recent (channel and room), linesFrom as fallback.
 *   (2) the same holds for accept/reject after the declare. (3) REVOKE also knows "close it / close that / forget it / no need / not needed / leave it / skip it / no rt / don't need it".
 *   A revocation is checked before more time, as before. Unit: none (behaviour). Integration: tests/integration/dma-trade-close-it.test.js
 *   (whispered "close it" after the time-up revokes the request and declines his trades; a guild line "one moment" not addressed to us
 *   gives no extra time; an addressed guild line "Peter, wait" does).
 * 0.1.26 (2026-11-02, live: the client did not load 0.1.25 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.1.25 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   only DEMO 4 acts are recorded as C-facts, one TK25 instance per round-trade CASE (case = sender@request time):
 *   request (the requester) -> promise | decline (acceptor) -> execute (each trade accepted; production act) -> declare
 *   (once, the trades are gone from the inbox) -> accept | reject (the requester; tacit accept after acceptMin).
 *   - A second request while a case is open: a repeated request on that case (was "rq-dup").
 *   - The acceptor gives up after its promise (no valid set within expireMin, the trades do not net to zero, the accept
 *     did not take twice): revoke promise + allow (requester, tacit) + decline, with the reason (was "revoke",
 *     "decline" per trade, "fail"). The trades returned in the game are information (what: "trade returned").
 *   - The requester cancels before execution: revoke request (requester) + allow (acceptor) (was "revoke-request").
 *   - The requester undoes it after the result: the original is accepted (tacit — the result arrived) and the reversal
 *     is a NEW case: request (requester, reversalOf) + promise (was "revoke-result").
 *   - Not coordination, so information (kind "i"): time-up, more-time, retry, restore.
 *   What is said in the chat and done in the game is unchanged.
 *   Unit/integration expectation: round-trade, multi-rt, trade-revoke, trade-accept, trade-restore tests read the new
 *   acts; tests/unit/dma-demo4-acts.test.js finds no non-DEMO act literal.
 * 0.1.23 (2026-10-30, author: "na de RT kun je terug naar de guild chat en de mail sluiten"): when an RT is over — a case
 *   reached declared (RT done) or an end state, and no case is promised or executing — the acceptor wraps up once:
 *   the gateway closes the mail window (DMA_Control.trade.closeMailPanel) and the chat puts the guild tab in front
 *   (DMA_Chat.backToGuild). 5 s after the last message, so the whisper is out first.
 *   Unit expectation:        a case going promised -> declared with no other open case calls closeMailPanel and
 *                            backToGuild once (c.wrapped = true); a still-promised second case postpones it.
 *   Integration expectation: after a live RT the mail window is closed and the guild chat tab is shown.
 * 0.1.24 (2026-10-31, author: RT during adventures — "ja"): the RT also runs away from home while our own adventure
 *   run is in FIGHT (DMA_Control.rtAwayOk: home-stock snapshot). Unit: away + rtAwayOk ticks, away alone does not;
 *   integration: an RT accepted during a YWC fight.
 * 0.1.22 (2026-10-25, author: "when I go to another island the orders carry on; they must stop"): no tick while the
 *   player is on another island (DMA_Control.atHome() false); requests wait until he is home.
 *
 * 0.1.0 (2026-10-25), author's request: "accepteer een Round Trade die iemand via de chat aanvraagt",
 * set up the DEMO way: "een request, een actor role responding to the request als het legitiem is, enzovoort".
 *
 * 0.1.21 (2026-10-25, live: Bets333 "right, nonzero didn't work, sent third that zeroes, then worked" after "RT done" was
 *   read as a REJECT — "sorry about that, I've passed it to Peter"; Bets: "hey I didn't even say peter"): a line that
 *   also reads positive (worked, thanks, got it ...) is an accept, never a reject; "didn't work" alone no longer counts —
 *   a reject must say the trade did not ARRIVE (didn't get / receive / arrive, not received, missing, wrong amount).
 * 0.1.20 (2026-10-25, author: "a safety margin — an RT of a resource we hold little of is consumed before we can send it
 *   back; refuse that RT with the reason that we have too little to guarantee it"): the margin (policy trade.marginPct,
 *   default 100 %) goes to the gateway's guardRoundSet; a set that nets to zero but fails the margin is declined AT
 *   ONCE with that reason (no waiting for the time-up).
 * 0.1.19 (2026-10-25, live: Wendigo's RT — accepted at 15:19:34, the client reloaded at 15:20, the case was lost and
 *   he received nothing): an EXECUTING case (accepted, not yet verified) is restored after a restart like a promise;
 *   when its trades are still in the inbox after the verify time, the accept is RETRIED once (its mail ids are released
 *   from usedIds and the case goes back to promised) instead of failing; only a second miss is "failed".
 * 0.1.18 (2026-10-25, author: "voor alle trade geldt de demo gedachte. als iemand zich bedenkt moet je het altijd terug
 *   kunnen draaien. Voor een round trade lijkt onzinnig, maar je werkt wel mee"): the DEMO revocation patterns. The
 *   requester may say "cancel / undo / never mind / changed my mind / reverse / take back / laat maar / terugdraaien"
 *   at any point of his case:
 *   - before execution (promised): REVOKE REQUEST — the case is cancelled and his waiting trades are declined in the
 *     game (they go back to him); said in the chat;
 *   - after execution (executing, declared, or accepted within 24 h): the result is undone by a COUNTER-TRANSACTION —
 *     a new round-trade case is promised at once (reversal of the earlier one): he sends the reverse trades, the
 *     acceptor accepts them under the same rules (net zero). The original case is marked revoked-result.
 * 0.1.17 (2026-10-25, author: "star trade is part of trade, same as help trade"): round trades are one kind under the
 *   Trade switch; trade.rt.on false (TRADE page) switches round trades off while help and star trades go on.
 * 0.1.16 (2026-10-25, author: "RTs per uur slaat nergens op"): no limit on round trades per hour any more.
 * 0.1.15 (2026-10-25, author: "all these values must be adjustable by the player in a screen"): the rules are read
 *   every tick from the policy (trade.cap, trade.waitMin, trade.graceMin, trade.extensions, trade.expireMin,
 *   trade.acceptMin, trade.perSenderHour), set in the console's TRADE screen. dma-trade-config.json is
 *   the fallback only; a value it holds is moved into the policy once if the policy still has its default.
 * 0.1.14 (2026-10-25, author: "when the three minutes are up, say the waiting time is up, unless that person needs more
 *   time; he can ask for more time"): after pairWaitMs without a new trade the acceptor first SAYS the time is up
 *   (with what is still wrong) and that he can ask for more time; "more time" (or wait / moment / sec) from the
 *   requester within timeUpGraceMs (1 min) gives another pairWaitMs, at most maxExtensions (3) times. Only then the
 *   trades are declined. A new trade resets the clock.
 * 0.1.13 (2026-10-25, author: "make the message 10K, that reads easier"): amounts in chat texts as 10K / 1.5K.
 * 0.1.12 (2026-10-25, author: "a multiple RT: 3 or more trades that net to zero"): the acceptor looks for the largest
 *   set of the requester's (unused) trades that nets to zero and that the stock can pay in some order (control
 *   guardRoundSet); a pair is the smallest such set. Trades are declined only after nothing new arrived for
 *   pairWaitMs (3 min), so a multiple RT can arrive one trade at a time. Promise text: "send me your trades".
 * 0.1.11 (2026-10-25, author: "he should redline your trades and tell you why"): trades of the requester that do not
 *   make a valid pair are DECLINED in the game (returned) and the reason is said — when two or more are there and no
 *   pair qualifies, or a single one has waited pairWaitMs (3 min). Each decline is a TK25 decline; the case closes.
 * 0.1.10 (2026-10-25) incident: a second RT request of the same player was "done" with the mails of his FIRST RT,
 *   which were still in the inbox list; his new, non-mirrored pair was never looked at, and "RT done" was false.
 *   - a mail id that was accepted (or attempted) is never used again (usedIds, kept in the status file);
 *   - after a promise the acceptor first asks for fresh headers and waits firstLookMs (8 s) before judging;
 *   - accepting is not declaring: the case is "executing" until fresh headers show both mails gone; only then
 *     execute + declare are recorded and "RT done" is said. Still there after verifyMs (90 s): "failed" —
 *     one notice to the requester, Peter is told, nothing is declared.
 * 0.1.9 (2026-10-25): nothing player-specific — a reject is answered with the player's own word from the console
 *   (DMA_Chat.ownerName(), e.g. "Peter"), not a fixed name.
 * 0.1.8 (2026-10-25): the console switch "Trade" (policy trade.auto, actor role trade acceptor) decides whether the
 *   acceptor acts: off -> a request is declined ("trading is switched off") and no trade is accepted; the result
 *   phase of an already declared case is still recorded. Without a loaded policy the config decides.
 * 0.1.7 (2026-10-25): author decision — a round trade may be up to 10,000 per item; the hard ceiling rises from
 *   1,000 to 10,000 (the configured cap still decides, and is set to 10,000 in dma-trade-config.json).
 * 0.1.6 (2026-10-25): the result phase completes (author: "after the ex you need to declare and he can still ac or
 *   re your ex"). After execute + declare the case is "declared" and waits for the requester: an explicit thanks /
 *   got it in the chat is his accept, a "didn't work / not received / wrong" his reject (Peter is told, nothing is
 *   undone automatically); silence for acceptMin (30) minutes is recorded as a tacit accept.
 * 0.1.5 (2026-10-25): a promise survives a client restart — open cases (status promised, within expireMin) are
 *   restored from dma-trade-status.json at start, so the requester need not ask again; nothing is said again.
 * 0.1.4 (2026-10-25): live, the panel check stayed false with the inbox open: the acceptor now asks for the headers
 *   anyway and reports control.mailProbe() in the status; control opens the window at most once per 2 min.
 * 0.1.3 (2026-10-25): the status shows what the acceptor sees (mails, types, the requester's trades as parsed).
 * 0.1.2 (2026-10-25): opens the game's mail window when the inbox is needed (live: the inbox stays empty until it
 *   has been opened once), and closes it again afterwards.
 * 0.1.1 (2026-10-25), author: "Een trade is a trade. A RT is just a specialisation, where the netto of two trades is 0."
 * Transaction TK25 trade accepting — product: [trade] is accepted. One TK25 instance per trade.
 * Specialisation (DFS-19): [trade] is in a round trade — another trade of the same sender is its exact mirror, so
 *   together they change no stock. The current policy accepts a trade ONLY when it is in a round trade.
 *   initiator  : a guild member (CTAR02, outside the SoI)          executor: AR25 trade acceptor (this module)
 *   rq  TK25/rq  "Peter … RT" in the guild chat (recorded by user_dma_chat.js >= 0.5.0)
 *   pm  TK25/pm  legitimate (ARS-25-02) -> "@x: RT ok, send me both trades …"
 *   dc  TK25/dc  not legitimate        -> "@x: sorry, no RT right now: <reason>"
 *   ex           each trade of the round trade accepted through the trade gateway of DMA_Control (ARS-25-04)
 *   da  TK25/da  per trade; the requester is told "@x: RT done …"
 *   ac  TK25/ac  tacit by the requester (the quest completes)
 *   rv  revoke promise after the expiry, when no valid pair arrived
 * Every c-act is a fact in the facts log (DMA_Demo.record "c", tk "TK25").
 *
 * ARS-25-02 (on rq) — rightness: the request came from the guild chat (only guild lines are recorded);
 *   truth: trading is enabled; (0.1.16: no per-hour limit); fewer than
 *   perSenderHour requests by this sender in the last hour; no open (promised) case for this sender.
 * ARS-25-04 (on pm, while trade mails of the requester are present) — truth: two TRADE mails from the requester,
 *   resource for resource, one lot each, an EXACT mirror, each side at most `cap`, and the stock covers both sides.
 *   The same conditions are enforced again, fail closed, in DMA_Control.trade.acceptRoundTrade (decision 0010).
 *
 * Files: dma-trade-config.json (optional overrides), dma-trade-status.json (heartbeat).
 * Layering: no game call here — everything goes through DMA_Control.trade (Game Interface Adapter) and DMA_Chat.
 */
(function (root) {
    "use strict";
    if (root.DMA_Trade && root.DMA_Trade.version) return;
    var VERSION = "0.1.29";
    var DEFAULTS = { enabled: true, cap: 100, perHour: 6, perSenderHour: 2, expireMin: 30, headersEveryMs: 15000, bodyEveryMs: 30000,
                     tickMs: 5000, statusEveryMs: 30000, acceptMin: 30, firstLookMs: 8000, verifyMs: 90000, pairWaitMs: 180000, timeUpGraceMs: 60000, roundEveryMs: 120000, maxExtensions: 3, marginPct: 100 };
    var cfg = JSON.parse(JSON.stringify(DEFAULTS));
    var cases = [];          // { sender, rqAt, rqTime, status: promised|declined|declared|accepted|rejected|revoked, pmAt, daAt, noticed }
    var seenRq = {};
    var usedIds = {};        // 0.1.10: mail id -> time it was accepted or attempted; never used again
    var bodyAskedAt = {};
    var lastHeadersAt = 0, lastStatusAt = 0, timer = null;
    var state = { startedAt: null, ticks: 0, lastError: "", mailWindow: false, cases: 0, done: 0, declined: 0, revoked: 0 };

    function note(s) { state.lastError = String(s).slice(0, 300); try { if (root.debug) root.debug("[DMA_Trade] " + s); } catch (_) {} }
    function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function readJson(name) {
        try {
            var a = airApi(); if (!a) return null;
            var f = a.File.applicationDirectory.resolvePath(name), file = new a.File(f.nativePath);
            if (!file.exists) return null;
            var st = new a.FileStream(); st.open(file, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close();
            return JSON.parse(t);
        } catch (e) { note("read " + name + ": " + e); return null; }
    }
    function writeJson(name, obj) {
        try {
            var a = airApi(); if (!a) return;
            var f = a.File.applicationDirectory.resolvePath(name), file = new a.File(f.nativePath);
            var st = new a.FileStream(); st.open(file, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close();
        } catch (e) { note("write " + name + ": " + e); }
    }
    function loadConfig() {
        var c = readJson("dma-trade-config.json"), k;
        if (c) for (k in c) if (c.hasOwnProperty(k) && DEFAULTS.hasOwnProperty(k) && typeof c[k] === typeof DEFAULTS[k]) cfg[k] = c[k];
        if (!(cfg.cap > 0) || cfg.cap > 10000) cfg.cap = 100;     // 0.1.7: never above 10,000 (author 2026-10-25), whatever the file says
    }
    function caseId(cs) { return cs ? String(cs.sender) + "@" + cs.rqAt : undefined; }   // 0.1.25: one TK25 instance per case
    function record(act, data, cs) {
        var o = { tk: "TK25", act: act, actor: "trade acceptor" }, k;
        if (cs) o.caseId = caseId(cs);
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function info(what, data, cs) {                             // 0.1.25: not a coordination act
        var o = { tk: "TK25", what: what, actor: "trade acceptor" }, k;
        if (cs) o.caseId = caseId(cs);
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", o); } catch (_) {}
    }
    function giveUp(cs, why, extra) {                           // 0.1.25: the acceptor withdraws its promise and declines
        var x = { sender: cs.sender, reason: why }, k; for (k in (extra || {})) x[k] = extra[k];
        record("revoke promise", x, cs);
        record("allow", { sender: cs.sender, actor: "requester (tacit)" }, cs);
        record("decline", x, cs);
    }
    function say(text, tag) { try { return !!(root.DMA_Chat && root.DMA_Chat.say && root.DMA_Chat.say(text, tag)); } catch (e) { note("say " + e); return false; } }
    function kfmt(n) {                                        // 0.1.13: 10000 -> 10K, 1500 -> 1.5K, 750 -> 750
        n = Number(n) || 0;
        if (n < 1000) return String(n);
        var k = Math.round(n / 100) / 10;
        return (k % 1 === 0 ? String(k) : k.toFixed(1)) + "K";
    }
    function clean(n) { return String(n || "").replace(/[^A-Za-z0-9_ .-]/g, ""); }
    function switchedOn() {                                  // 0.1.8: the player's switch (policy), else the config
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && typeof p.get === "function") { var v = p.get("trade.auto"); if (v === false) return false; if (p.get("trade.rt.on") === false) return false; } } catch (_) {}
        return cfg.enabled !== false;
    }
    function gw() { return root.DMA_Control && root.DMA_Control.trade; }

    /* ---------- ARS-25-02: on request — promise or decline ---------- */
    function onRequest(rq, now) {
        var who = String(rq.sender), why = "";
        var hour = now - 3600000;
        var done = cases.filter(function (c) { return c.doneAt && c.doneAt >= hour; }).length;   // 0.1.6: every executed RT counts
        var mine = cases.filter(function (c) { return c.sender.toLowerCase() === who.toLowerCase() && c.rqAt >= hour; });
        if (!switchedOn()) why = "trading is switched off";
        else if (!gw()) why = "the trade gateway is not loaded";
        else if (mine.some(function (c) { return c.status === "promised"; })) why = "";      // already open: no second promise, no reply
        else if (mine.length >= cfg.perSenderHour) why = "you asked " + mine.length + " times this hour";
        var openCs = mine.filter(function (c) { return c.status === "promised"; })[0];
        if (openCs) { record("request", { sender: who, actor: "requester", text: rq.text, repeated: true }, openCs); return; }   // 0.1.25: was rq-dup
        var cs = { sender: who, rqAt: rq.at || now, rqTime: rq.time, status: why ? "declined" : "promised", pmAt: now, noticed: false };
        cases.push(cs); state.cases += 1;
        record("request", { sender: who, actor: "requester", text: rq.text }, cs);
        if (why) {
            state.declined += 1;
            record("decline", { sender: who, reason: why }, cs);
            say("@" + clean(who) + ": sorry, no RT right now: " + why + ".", "rt-dc");
        } else {
            record("promise", { sender: who, cap: cfg.cap }, cs);
            say("@" + clean(who) + ": RT ok, send me your trades (together they must net to zero, max " + kfmt(cfg.cap) + " per item).", "rt-pm");
        }
    }

    /* ---------- ARS-25-04: on promise, while the requester's trade mails are present — execute and declare ---------- */
    function work(cs, now) {
        var G = gw(); if (!G) return;
        if (now - cs.pmAt > cfg.expireMin * 60000) {
            cs.status = "revoked"; state.revoked += 1;
            giveUp(cs, "no valid pair within " + cfg.expireMin + " min");   // 0.1.25: was "revoke"
            say("@" + clean(cs.sender) + ": RT request expired. Ask again when you've sent both trades.", "rt-rv");
            return;
        }
        // 0.1.2: the inbox is only filled once the game's mail window exists (see control 0.2.17)
        // 0.1.4: live — the panel check stayed false with the inbox open; never stop here, ask for the headers anyway
        var ready = true;   // 0.1.28: ask for the window at most once per roundEveryMs; read what is there in between
        if (typeof G.ensureMailPanel === "function") {
            var open = typeof G.mailPanelReady === "function" ? !!G.mailPanelReady() : false;
            if (open) ready = true;
            else if (!cs.roundAskAt || now - cs.roundAskAt >= cfg.roundEveryMs) { cs.roundAskAt = now; ready = G.ensureMailPanel(); }
            else ready = false;
        }
        state.inbox = ready ? "ready" : "mail window not confirmed; reading anyway";
        try { if (typeof G.mailProbe === "function") state.mailProbe = G.mailProbe(); } catch (_) {}
        if (now - lastHeadersAt >= cfg.headersEveryMs) { lastHeadersAt = now; try { G.requestInboxHeaders(); } catch (e) { note("headers " + e); } }
        if (now - cs.pmAt < cfg.firstLookMs) return;            // 0.1.10: judge only a fresh inbox list
        var all = G.mails() || [];
        var diag = { at: new Date(now).toISOString(), mails: all.length, types: {}, fromSender: 0, parsed: [] };
        all.forEach(function (m) { try { var ty = String(m.type); diag.types[ty] = (diag.types[ty] || 0) + 1; } catch (_) {} });
        var mails = all.filter(function (m) {
            try { return Number(m.type) === G.MAIL_TRADE && String(m.senderName || "").toLowerCase() === cs.sender.toLowerCase() && !usedIds[String(m.id)]; } catch (_) { return false; }
        });
        var trades = [];
        diag.fromSender = mails.length;
        state.diag = diag;                                   // 0.1.3: what the acceptor sees, in dma-trade-status.json
        mails.forEach(function (m) {
            var t = null;
            try { t = G.tradeOfMail(m); } catch (e) { note("parse " + e); diag.parsed.push({ error: String(e).slice(0, 120) }); }
            if (t) diag.parsed.push(t);
            if (!t) return;
            if (t.needsBody) {
                if (!bodyAskedAt[t.id] || now - bodyAskedAt[t.id] >= cfg.bodyEveryMs) { bodyAskedAt[t.id] = now; try { G.requestMailBody(t.id); } catch (e) { note("body " + e); } }
                return;
            }
            if (!t.error) trades.push(t);
        });
        // 0.1.12: a round trade is any set of the requester's trades that nets to zero (a pair is the simplest)
        if (trades.length !== cs.lastCount) { cs.lastCount = trades.length; cs.lastChangeAt = now; cs.timeUpAt = 0; }
        var quiet = now - (cs.lastChangeAt || now) >= cfg.pairWaitMs;   // nothing new arrived for 3 min
        if (quiet) quiet = timeUp(cs, now, trades);              // 0.1.14: say so first; he may ask for more time
        if (trades.length < 2) {
            if (trades.length === 1 && quiet) declinePair(cs, trades, "only one trade arrived, a round trade needs two or more that net to zero", now);
            return;
        }
        var pick = null, last = "";
        if (typeof G.guardRoundSet === "function") {
            var full = G.guardRoundSet(trades, cfg.cap, cfg.marginPct), marginWhy = full.margin ? full.why : "";
            if (!full.why) pick = trades.slice(); else last = full.why;
            for (var size = trades.length - 1; !pick && size >= 2; size--) {
                combos(trades, size).some(function (sub) { var g = G.guardRoundSet(sub, cfg.cap, cfg.marginPct); if (!g.why) { pick = sub; return true; } if (g.margin && !marginWhy) marginWhy = g.why; return false; });
            }
            if (!pick && marginWhy) { declinePair(cs, trades, marginWhy, now); return; }   // 0.1.20: at once
        } else {
            for (var i = 0; !pick && i < trades.length; i++) for (var j = i + 1; !pick && j < trades.length; j++) {
                var why = G.guardRoundTrade(trades[i], trades[j], cfg.cap);
                if (!why) pick = [trades[i], trades[j]]; else last = why;
            }
        }
        if (pick) {
            pick.forEach(function (t) { usedIds[String(t.id)] = now; });   // 0.1.10: attempted = used
            var res = typeof G.acceptRoundSet === "function" ? G.acceptRoundSet(pick, cfg.cap, cfg.marginPct) : G.acceptRoundTrade(pick[0], pick[1], cfg.cap);
            if (res && res.ok) {
                cs.status = "executing"; cs.exAt = now; lastStatusAt = 0;   /* 0.1.19: written at once, a restart must find it */  cs.mailIds = pick.map(function (t) { return t.id; });   // 0.1.10: verify before declaring
                cs.pair = pick;
                lastHeadersAt = 0;
            } else {
                declinePair(cs, pick, (res && res.reason) || "refused", now);
            }
            return;
        }
        if (quiet) declinePair(cs, trades, last || "the trades do not net to zero", now);   // 0.1.11/0.1.12: redline them and say why
    }
    /* 0.1.29: the names that address THIS player (lower case): the in-game name, the chat reply words, the owner name - nothing typed into the code */
    function ownNames(C) {
        var out = [];
        function add(n) { n = String(n == null ? "" : n).toLowerCase().replace(/^\s+|\s+$/g, ""); if (n.length >= 2 && n !== "the player" && out.indexOf(n) < 0) out.push(n); }
        try { if (C && C.ownName) add(C.ownName()); } catch (_) {}
        try { if (C && C.words) (C.words() || []).forEach(add); } catch (_) {}
        try { if (C && C.ownerName) add(C.ownerName()); } catch (_) {}
        return out;
    }
    /* 0.1.27: the requester's lines that are acts toward us: his whispers, and guild lines that address the player */
    function linesOf(sender, since) {
        var C = root.DMA_Chat, w = String(sender || "").toLowerCase(), me = ownNames(C);
        try {
            if (C && typeof C.recent === "function") {
                return (C.recent(since) || []).filter(function (l) {
                    if (String(l.sender || "").toLowerCase() !== w || (l.at || 0) < (since || 0)) return false;
                    if (String(l.channel || "") !== "guild") return true;
                    var t = String(l.text || "").toLowerCase();
                    return me.some(function (n) { return t.indexOf(n) >= 0; });
                }).map(function (l) { return { at: l.at, text: l.text }; });
            }
            if (C && C.linesFrom) return C.linesFrom(sender, since) || [];
        } catch (_) {}
        return [];
    }
    /* 0.1.14: true only when the waiting time is up, was announced, and no more time was asked for */
    var MORE_TIME = /more\s*time|\bwait\b|\bmoment\b|\bsec\b|\bhold on\b|\bminute\b/i;
    function timeUp(cs, now, trades) {
        var why = "";
        try { var G = gw(); if (trades.length >= 2 && G && G.guardRoundSet) why = G.guardRoundSet(trades, cfg.cap, cfg.marginPct).why; } catch (_) {}
        if (!why) why = trades.length < 2 ? "only " + trades.length + " trade arrived" : "the trades do not make a round trade";
        if (!cs.timeUpAt) {
            cs.timeUpAt = now;
            info("time-up", { sender: cs.sender, reason: why, extensions: cs.extensions || 0 }, cs);
            var more = (cs.extensions || 0) < cfg.maxExtensions;
            say("@" + clean(cs.sender) + ": the waiting time is up (" + String(why).replace(/\b(\d{4,})\b/g, function (m) { return kfmt(m); }) + ")." +
                (more ? " Need more time? Say \"more time\", otherwise I decline your trades in 1 min." : " I decline your trades in 1 min."), "rt-tu");
            return false;
        }
        var asked = false;
        try { if ((cs.extensions || 0) < cfg.maxExtensions && root.DMA_Chat && root.DMA_Chat.linesFrom) asked = linesOf(cs.sender, cs.timeUpAt).some(function (l) { return MORE_TIME.test(String(l.text || "")); }); } catch (_) {}
        if (asked) {
            cs.extensions = (cs.extensions || 0) + 1; cs.lastChangeAt = now; cs.timeUpAt = 0;
            info("more-time", { sender: cs.sender, extension: cs.extensions }, cs);
            say("@" + clean(cs.sender) + ": ok, " + Math.round(cfg.pairWaitMs / 60000) + " more minutes.", "rt-mt");
            return false;
        }
        return now - cs.timeUpAt >= cfg.timeUpGraceMs;
    }
    function combos(arr, k) {                                  // all k-subsets, in order
        var out = [];
        (function rec(start, cur) {
            if (cur.length === k) { out.push(cur.slice()); return; }
            for (var x = start; x < arr.length; x++) { cur.push(arr[x]); rec(x + 1, cur); cur.pop(); }
        })(0, []);
        return out;
    }
    function declinePair(cs, trades, why, now) {
        var G = gw();
        trades.forEach(function (t) { usedIds[String(t.id)] = now; });
        var res = null;
        try { res = G && G.declineTradeMails ? G.declineTradeMails(trades) : null; } catch (e) { note("decline " + e); }
        trades.forEach(function (t) { info("trade returned", { sender: cs.sender, trade: t.id, reason: why, give: t.costs, get: t.offer, sent: !!(res && res.ok) }, cs); });
        giveUp(cs, why, { trades: trades.map(function (t) { return t.id; }) });   // 0.1.25: the case, not each trade
        cs.status = "declined"; cs.endAt = now; state.declined += 1;
        say("@" + clean(cs.sender) + ": I declined your trades: " + String(why).replace(/\b(\d{4,})\b/g, function (m) { return kfmt(m); }) + ". Send trades that net to zero and ask again.", "rt-dct");
    }

    /* ---------- 0.1.6 ARS-25-06: on declare — the requester accepts or rejects ---------- */
    var REJECT = /(didn'?t|did not|not|never)\s+(receiv|get|got|arriv|go through|come through)|\bnot received\b|wrong amount|\bmissing\b/i;   // 0.1.21
    /* 0.1.18: revocation (DEMO): the requester changes his mind — always possible, before and after execution */
    var REVOKE = /\b(cancel+(ed)?|undo|never\s*mind|nvm|changed my mind|reverse|take (it )?back|laat maar|terugdraaien|annuleer|niet meer nodig|close (it|that|the rt)|forget (it|that)|no need|not needed|leave it|skip it|no (more )?rts?|don'?t need it)\b/i;
    var revokeSeen = {};
    function revokeAsked(cs, since) {
        var lines = linesOf(cs.sender, since);
        for (var i = 0; i < lines.length; i++) {
            var key = cs.sender + "|" + (lines[i].at || lines[i].time || "") + "|" + lines[i].text;
            if (revokeSeen[key] || !REVOKE.test(String(lines[i].text || ""))) continue;
            revokeSeen[key] = true;                                   // one revocation line acts once, on the newest open case
            return String(lines[i].text);
        }
        return "";
    }
    function revoke(cs, now, text) {
        var G = gw(), who = clean(cs.sender);
        if (cs.status === "promised") {
            var mine = [];
            try { mine = (G && G.mails ? G.mails() : []).map(function (m) { return G.tradeOfMail(m); }).filter(function (t) { return t && !t.needsBody && t.sender && t.sender.toLowerCase() === cs.sender.toLowerCase() && !usedIds[String(t.id)]; }); } catch (_) {}
            var res = null; if (mine.length && G.declineTradeMails) { try { res = G.declineTradeMails(mine); } catch (e) { res = { ok: false, reason: String(e) }; } }
            mine.forEach(function (t) { usedIds[String(t.id)] = now; });
            cs.status = "cancelled"; cs.endAt = now; state.revoked += 1;
            record("revoke request", { sender: cs.sender, actor: "requester", text: text.slice(0, 200) }, cs);   // 0.1.25: was revoke-request
            record("allow", { sender: cs.sender, declined: mine.map(function (t) { return t.id; }), sent: !!(res && res.ok) }, cs);
            say("@" + who + ": ok, cancelled" + (mine.length ? " — your " + mine.length + " trade" + (mine.length > 1 ? "s are" : " is") + " declined and back with you" : "") + ".", "rt-cx");
            return;
        }
        if (cs.status === "declared") record("accept", { sender: cs.sender, actor: "requester", tacit: true, reason: "asks to undo it, so the result arrived" }, cs);   // 0.1.25
        info("undo asked", { sender: cs.sender, text: text.slice(0, 200) }, cs);
        cs.status = "revoked-result"; cs.endAt = now; state.revoked += 1;
        var nc = { sender: cs.sender, rqAt: now, rqTime: new Date(now).toISOString(), status: "promised", pmAt: now, noticed: false, reversalOf: cs.rqAt };
        cases.push(nc); state.cases += 1;
        record("request", { sender: cs.sender, actor: "requester", reversalOf: caseId(cs), text: text.slice(0, 200) }, nc);   // 0.1.25: the counter-transaction
        record("promise", { sender: cs.sender, cap: cfg.cap, reversal: true }, nc);
        say("@" + who + ": no problem, let's undo it — send me the reverse trades (what you sent, the other way round) and I'll accept them.", "rt-un");
    }
    var POSITIVE = /\b(thx|thanks?|thank you|ty|tnx|tyvm|cheers|works|worked|perfect|great|nice one)\b/i;   // 0.1.21: no "received"/"got it" (they negate)
    var ACCEPT = /\b(thx|thanks?|thank you|ty|tnx|tyvm|cheers|got it|received|works|worked|perfect|great|nice one)\b/i;
    function awaitAccept(cs, now) {
        var lines = [];
        try { if (root.DMA_Chat && root.DMA_Chat.linesFrom) lines = linesOf(cs.sender, cs.daAt); } catch (_) {}
        for (var i = 0; i < lines.length; i++) {
            var tx = String(lines[i].text || "");
            if (REJECT.test(tx) && !POSITIVE.test(tx)) {   // 0.1.21: a positive line is never a reject
                cs.status = "rejected"; cs.endAt = now; state.rejected = (state.rejected || 0) + 1;
                record("reject", { sender: cs.sender, actor: "requester", text: tx.slice(0, 200) }, cs);
                var owner = "the player"; try { if (root.DMA_Chat && root.DMA_Chat.ownerName) owner = clean(root.DMA_Chat.ownerName()) || owner; } catch (_) {}
                say("@" + clean(cs.sender) + ": sorry about that, I've passed it to " + owner + ".", "rt-rj");
                return;
            }
            if (ACCEPT.test(tx)) {
                cs.status = "accepted"; cs.endAt = now; state.accepted = (state.accepted || 0) + 1;
                record("accept", { sender: cs.sender, actor: "requester", text: tx.slice(0, 200) }, cs);
                return;
            }
        }
        if (now - cs.daAt >= cfg.acceptMin * 60000) {
            cs.status = "accepted"; cs.endAt = now; state.accepted = (state.accepted || 0) + 1;
            record("accept", { sender: cs.sender, actor: "requester", tacit: true, after: cfg.acceptMin + " min without a reply" }, cs);
        }
    }

    /* 0.1.10: accepted is not declared — fresh headers must show both mails gone */
    function verify(cs, now) {
        var G = gw(); if (!G) return;
        if (now - lastHeadersAt >= cfg.headersEveryMs) { lastHeadersAt = now; try { G.requestInboxHeaders(); } catch (e) { note("headers " + e); } }
        if (now - cs.exAt < cfg.firstLookMs) return;
        var ids = {}; (G.mails() || []).forEach(function (m) { try { ids[String(m.id)] = 1; } catch (_) {} });
        var still = (cs.mailIds || []).filter(function (id) { return ids[String(id)]; });
        if (!still.length) {
            cs.status = "declared"; cs.doneAt = now; cs.daAt = now; state.done += 1;   // 0.1.6: wait for ac / rj
            // 0.1.25: one TK25 instance per case; each trade accepted is an execute, then one declare (DFS-19, net zero)
            (cs.pair || []).forEach(function (t) {
                record("execute", { sender: cs.sender, trade: t.id, give: t.costs, get: t.offer, specialisation: "round trade" }, cs);
            });
            record("declare", { sender: cs.sender, trades: (cs.mailIds || []).join(",") }, cs);
            delete cs.pair;
            say("@" + clean(cs.sender) + ": RT done, good luck with your quest!", "rt-da");
        } else if (now - cs.exAt >= cfg.verifyMs && !cs.retried) {   // 0.1.19: the accept did not take — try once more
            cs.retried = true; cs.status = "promised"; cs.pmAt = now; cs.lastChangeAt = now;
            (cs.mailIds || []).forEach(function (id) { delete usedIds[String(id)]; });
            info("retry", { sender: cs.sender, reason: "trades still in the inbox after accepting", trades: still }, cs);
        } else if (now - cs.exAt >= cfg.verifyMs) {
            cs.status = "failed"; cs.endAt = now; state.failed = (state.failed || 0) + 1;
            var owner = "the player"; try { if (root.DMA_Chat && root.DMA_Chat.ownerName) owner = clean(root.DMA_Chat.ownerName()) || owner; } catch (_) {}
            giveUp(cs, "the trades were still in the inbox after accepting twice", { trades: still.join(",") });   // 0.1.25: was "fail"
            say("@" + clean(cs.sender) + ": I couldn't complete the RT, " + owner + " will check it.", "rt-fl");
            delete cs.pair;
        }
    }

    /* 0.1.15: the player's rules, from the policy (minutes in the screen, milliseconds here) */
    var POLICY_MAP = {
        "trade.cap":           { k: "cap",          f: 1,     dflt: 100 },
        "trade.waitMin":       { k: "pairWaitMs",   f: 60000, dflt: 3 },
        "trade.graceMin":      { k: "timeUpGraceMs", f: 60000, dflt: 1 },
        "trade.extensions":    { k: "maxExtensions", f: 1,    dflt: 3 },
        "trade.expireMin":     { k: "expireMin",    f: 1,     dflt: 30 },
        "trade.acceptMin":     { k: "acceptMin",    f: 1,     dflt: 30 },
        "trade.perSenderHour": { k: "perSenderHour", f: 1,    dflt: 2 },
        "trade.marginPct":     { k: "marginPct",    f: 1,     dflt: 100 }   // 0.1.20
    };
    var fileCfg = null, migrated = false;
    function applyPolicy() {
        var p = null; try { p = root.GCAF_PlayerPolicyInstance; } catch (_) {}
        if (!p || typeof p.get !== "function") return;
        var key, m, v;
        if (!migrated) {
            migrated = true;
            try { fileCfg = readJson("dma-trade-config.json") || {}; } catch (_) { fileCfg = {}; }
            for (key in POLICY_MAP) {
                if (!POLICY_MAP.hasOwnProperty(key)) continue;
                m = POLICY_MAP[key];
                var fv = fileCfg[m.k];
                if (fv == null) continue;
                var asPolicy = m.f > 1 ? fv / m.f : fv;
                try { if (Number(p.get(key)) === m.dflt && Number(asPolicy) !== m.dflt && p.requestChange) p.requestChange(key, asPolicy); } catch (_) {}
            }
        }
        for (key in POLICY_MAP) {
            if (!POLICY_MAP.hasOwnProperty(key)) continue;
            m = POLICY_MAP[key];
            try { var raw = p.get(key); v = (raw === null || raw === undefined || raw === "") ? NaN : Number(raw); } catch (_) { v = NaN; }
            if (!isNaN(v) && v >= 0) cfg[m.k] = v * m.f;
        }
        if (!(cfg.cap > 0) || cfg.cap > 10000) cfg.cap = 100;
    }

    var WRAP_END = { declared: 1, accepted: 1, declined: 1, rejected: 1, cancelled: 1, "revoked-result": 1, revoked: 1, failed: 1 };
    function wrapUp(G, now) {                                 // 0.1.23: the RT is over -> mail closed, guild tab in front
        if (cases.some(function (c) { return c.status === "promised" || c.status === "executing"; })) return;
        var due = cases.filter(function (c) { return !c.wrapped && !c.restored && WRAP_END[c.status]; });
        if (!due.length) return;
        var last = 0; due.forEach(function (c) { last = Math.max(last, c.endAt || c.daAt || c.doneAt || 0); });
        if (last && now - last < 5000) return;
        due.forEach(function (c) { c.wrapped = true; });
        var mail = false, guild = false;
        try { if (G && typeof G.closeMailPanel === "function") mail = G.closeMailPanel(); } catch (e) { note("wrap mail " + e); }
        try { if (root.DMA_Chat && typeof root.DMA_Chat.backToGuild === "function") guild = root.DMA_Chat.backToGuild(); } catch (e) { note("wrap chat " + e); }
        state.wrapUp = { at: new Date(now).toISOString(), mailClosed: mail, guildTab: guild };
    }
    function away() { try { var C = root.DMA_Control; return !!(C && typeof C.atHome === "function" && !C.atHome() && !(typeof C.rtAwayOk === "function" && C.rtAwayOk())); } catch (_) { return false; } }   // 0.1.22; 0.1.24: not away while our adventure run fights
    function tick(now) {
        if (away()) return;
        now = now || Date.now();
        state.ticks += 1;
        try { applyPolicy(); } catch (e) { note("policy " + e); }   // 0.1.15
        try {
            var G = gw();
            state.mailWindow = !!(G && G.mailWindow());
            var reqs = (root.DMA_Chat && root.DMA_Chat.rtRequests) ? root.DMA_Chat.rtRequests(3900000) : [];
            reqs.forEach(function (r) {
                var key = r.sender + "|" + r.at;
                if (seenRq[key]) return;
                seenRq[key] = true;
                onRequest(r, now);
            });
            var on = switchedOn(); state.switchedOn = on;
            cases.slice().reverse().forEach(function (c) {   // 0.1.18 (newest first): a revocation first — the requester may always change his mind
                var open = c.status === "promised" || c.status === "executing" || c.status === "declared" || (c.status === "accepted" && now - (c.endAt || c.doneAt || 0) < 86400000);
                if (open && !c.reversalOf) { var tx = revokeAsked(c, Math.max(c.rqAt || 0, c.rvCheckedAt || 0)); if (tx) { revoke(c, now, tx); return; } }
                if (c.status === "promised") { if (on) work(c, now); } else if (c.status === "executing") verify(c, now); else if (c.status === "declared") awaitAccept(c, now);
            });
            if (G && typeof G.closeMailPanelIfOurs === "function" && !cases.some(function (c) { return c.status === "promised"; })) G.closeMailPanelIfOurs();
            wrapUp(G, now);   // 0.1.23
        } catch (e) { note("tick " + e); }
        if (now - lastStatusAt >= cfg.statusEveryMs) {
            lastStatusAt = now;
            var ui = {}, k; for (k in usedIds) if (usedIds.hasOwnProperty(k) && now - usedIds[k] < 7 * 86400000) ui[k] = usedIds[k];
            writeJson("dma-trade-status.json", { format: "dma-trade-status/1", version: VERSION, at: new Date(now).toISOString(), config: cfg, state: state,
                cases: cases.slice(-10), usedIds: ui });   // 0.1.10
        }
    }
    /* 0.1.5: the trade acceptor remembers its own promises across a restart (a promise is a fact of TK25) */
    function restoreCases(now) {
        var st = readJson("dma-trade-status.json"), list = (st && st.cases) || [], n = 0, k0;
        if (st && st.usedIds) for (k0 in st.usedIds) if (st.usedIds.hasOwnProperty(k0)) usedIds[k0] = Number(st.usedIds[k0]) || now;   // 0.1.10
        list.forEach(function (c) { (c && c.mailIds || []).forEach(function (id) { usedIds[String(id)] = usedIds[String(id)] || now; }); });
        list.forEach(function (c) {
            if (!c || !c.sender) return;
            var openPm = c.status === "promised" && now - Number(c.pmAt) < cfg.expireMin * 60000;
            var openDa = c.status === "declared" && c.daAt;                      // 0.1.6: a declaration still awaits ac / rj
            var openEx = c.status === "executing" && now - Number(c.exAt || 0) < 3600000;   // 0.1.19: accepted, not yet verified
            if (!openPm && !openDa && !openEx) return;
            if (cases.some(function (x) { return x.sender === c.sender && x.rqAt === c.rqAt; })) return;
            cases.push({ sender: String(c.sender), rqAt: Number(c.rqAt), rqTime: c.rqTime, status: c.status, pmAt: Number(c.pmAt), daAt: c.daAt ? Number(c.daAt) : undefined, doneAt: c.doneAt ? Number(c.doneAt) : undefined, noticed: !!c.noticed, restored: true,
                         exAt: openEx ? now : undefined, mailIds: openEx ? (c.mailIds || []) : undefined, pair: openEx ? c.pair : undefined, retried: !!c.retried });   // 0.1.19: verify again from now
            seenRq[c.sender + "|" + c.rqAt] = true; n++;
        });
        if (n) { state.cases += n; state.restored = n; info("restore", { cases: n }); }
        return n;
    }
    function start() {
        if (timer) return;
        state.startedAt = new Date().toISOString();
        loadConfig();
        restoreCases(Date.now());
        if (root.DMA_TRADE_NO_TIMER) return;
        timer = root.setInterval(function () { try { tick(); } catch (e) { note("tick " + e); } }, cfg.tickMs);
    }
    root.DMA_Trade = {
        version: VERSION,
        tick: tick,
        _linesOf: linesOf,   // 0.1.29: for the unit test
        cases: function () { return JSON.parse(JSON.stringify(cases)); },
        status: function () { return JSON.parse(JSON.stringify(state)); },
        config: function () { return JSON.parse(JSON.stringify(cfg)); },
        restoreCases: function (now) { return restoreCases(now || Date.now()); }
    };
    start();
})(typeof window !== "undefined" ? window : this);
