/*
 * user_dma_adv_catalogue.js — the adventure catalogue (PBC adventure management, ADR 0035)
 * 0.1.0 (2026-10-31, author: "Wellicht kun je de online informatie gebruiken om alle bestaande avonturen op te nemen"):
 *   every adventure of the game with its type (mission, mini mission, venture, scenario, coop, event), players, loot
 *   spots (players - 1 for non-co-op, derived), minimum level, internal (star item) name and wiki page. Generated from
 *   docs/06-adventures/adventure-catalogue.json (tsowiki.eu) and adventure-internal-names.json (the client's star).
 *   No game call. Regenerate, do not edit by hand.
 * 0.1.1 (2026-11-08, author: "laten we eerst de reeks aanmaken en opnemen in de ADVS tab"; ADR 0046): adventure series.
 *   A series is an ordered list of adventures played one after another (The Mountain Clan: At the Foot of the Mountain,
 *   Unknown Regions, Mountain Labyrinth, The People of the Mountain, A Giant Battle). groups() lists every series first
 *   as its own group (type "series", items in play order, each with its step number); series(id) and seriesOf(res)
 *   give the series of an adventure. Each series adventure has its template folder name (AtFotM, UR, ML, TPotM, AGB),
 *   used by abbr() so the ADVS page finds the Mundane set under the template base.
 *   Unit expectation:        groups()[0] is the Mountain Clan series with 5 items in order; abbr("The People of the
 *                            Mountain") === "TPotM"; seriesOf("BuffAdventures_TMC_A_giant_Battle").step === 5.
 *   Integration expectation: the ADVS page shows "The Mountain Clan" above the other groups, its adventures in order.
 * 0.1.2 (2026-11-17, ADR 0079; author: "Wellicht zelfs het advies bij dit avontuur geen blocks te gebruiken" — "de speler
 *   heeft meerdere mogelijkheden bij het aanmaken van een nieuwe versie op een avontuur: block, zonder block, kamp voor
 *   kamp ... een bestaande mundain ... mijn mundane ter beschikking stellen"): advice(res) gives the advice for an adventure
 *   ([{ code, level, text }]); Bonaberti Business: NO_BLOCKS ("do not use blocks"). noBlocks(res) is true when that advice
 *   holds. KINDS lists the version kinds of the New version selector in order, each { mode, label, hint }.
 *   Unit expectation:        advice("BonabertiBusiness")[0].code === "NO_BLOCKS"; noBlocks("BonabertiBusiness") === true;
 *                            noBlocks("1001NightsFirstThief") === false; KINDS has the five kinds of ADR 0079 first.
 *   Integration expectation: the ADVS page shows "do not use blocks" on Bonaberti Business and offers the five kinds.
 * 0.1.3 (2026-11-20, author: "the guide leads to a very old guide, let me give you the central place for all guides" —
 *   https://settlersonlinewiki.eu/en/adventures/): every adventure carries guide, its guide page there (null when the index has
 *   none); url stays the tsowiki page the loot and catalogue facts come from.
 *   Unit expectation:        byRes("1001NightsWoodcutter").guide is the settlersonlinewiki.eu YWC page; the copy equals adventure-guides.json.
 *   Integration expectation: the ADVS "guide" link opens settlersonlinewiki.eu (console 0.1.110).
 * Unit expectation:        byRes("1001NightsFirstThief").type === "mission"; groups() lists the six types in order.
 * Integration expectation: the ADVS overview groups the player's adventures by these types.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.3";
    var TYPES = [["mission", "Missions"], ["mini mission", "Mini missions"], ["venture", "Ventures"], ["scenario", "Scenarios"], ["coop", "Co-op"], ["event", "Event adventures"]];
    /* [name, type, players, lootSpots, level, internalName, url] */
    var ROWS = [["Lakeside Treasure", "coop", 2, null, 36, "LakesideTreasure", "https://tsowiki.eu/adventures/pages/lakeside-treasure/"],
        ["Raiding the Raiders", "coop", 3, null, 36, "RaidingTheRaiders", "https://tsowiki.eu/adventures/pages/raiding-the-raiders/"],
        ["Split City in Fall", "coop", 2, null, 55, "SplitCityFall", "https://tsowiki.eu/adventures/pages/split-city-in-fall/"],
        ["Split City in Summer", "coop", 2, null, 42, "SplitCity", "https://tsowiki.eu/adventures/pages/split-city-in-summer/"],
        ["The Buccaneer Roundup", "coop", 3, null, 26, "BuccaneerRoundup", "https://tsowiki.eu/adventures/pages/the-buccaneer-roundup/"],
        ["The Siege", "coop", 2, null, 26, "TheSiege", "https://tsowiki.eu/adventures/pages/the-siege/"],
        ["The Whirlwind", "coop", 4, null, 42, "Whirlwind", "https://tsowiki.eu/adventures/pages/the-whirlwind/"],
        ["Tomb Raiders", "coop", 4, null, 42, "TombRaiders", "https://tsowiki.eu/adventures/pages/tomb-raiders/"],
        ["A New Egg Hunt", "event", 1, 0, 17, null, "https://tsowiki.eu/adventures/pages/a-new-egg-hunt/"],
        ["A new experience", "event", 1, 0, 1, "Birthday2013Adventure1", "https://tsowiki.eu/adventures/pages/a-new-experience/"],
        ["Finals", "event", 1, 0, 16, null, "https://tsowiki.eu/adventures/pages/finals/"],
        ["Garrun the Trapper", "event", 1, 0, 26, "EasterGarrunTrapper", "https://tsowiki.eu/adventures/pages/garrun-the-trapper/"],
        ["Getting into the Christmas Spirit", "event", 1, 0, 16, "XMAS_Map_1", "https://tsowiki.eu/adventures/pages/getting-into-the-christmas-spirit/"],
        ["Hero wanted", "event", 1, 0, 1, "Birthday2013Adventure2", "https://tsowiki.eu/adventures/pages/hero-wanted/"],
        ["Hunting Eggs", "event", 1, 0, 17, "EasterEvent2013Adventure03", "https://tsowiki.eu/adventures/pages/hunting-eggs/"],
        ["Improving the Christmas Spirit", "event", 1, 0, 16, "XMAS_Map_3", "https://tsowiki.eu/adventures/pages/improving-the-christmas-spirit/"],
        ["Keeping up the Christmas Spirit", "event", 1, 0, 16, "XMAS_Map_6", "https://tsowiki.eu/adventures/pages/keeping-up-the-christmas-spirit/"],
        ["Looming Danger", "event", 1, 0, 28, "HWCampaign1_Adv2", "https://tsowiki.eu/adventures/pages/looming-danger/"],
        ["Lost Easter Eggs", "event", 1, 0, 17, null, "https://tsowiki.eu/adventures/pages/lost-easter-eggs/"],
        ["Misty Cake", "event", 1, 0, 26, "Birthday2020CakeMap1", "https://tsowiki.eu/adventures/pages/misty-cake/"],
        ["Monsters from the Mist", "event", 1, 0, 28, "HWCampaign1_Adv1", "https://tsowiki.eu/adventures/pages/monsters-from-the-mist/"],
        ["Nearly a Picasso", "event", 1, 0, 17, "EasterEvent2013Adventure02", "https://tsowiki.eu/adventures/pages/nearly-a-picasso/"],
        ["Nothing special", "event", 1, 0, 1, "Birthday2013Adventure5", "https://tsowiki.eu/adventures/pages/nothing-special/"],
        ["Old Ruins", "event", 1, 0, 26, "Birthday2013MilitaryAdventure2ShopVersion", "https://tsowiki.eu/adventures/pages/old-ruins/"],
        ["Practice Match", "event", 1, 0, 16, null, "https://tsowiki.eu/adventures/pages/practice-match/"],
        ["Quarter Finals", "event", 1, 0, 16, null, "https://tsowiki.eu/adventures/pages/quarter-finals/"],
        ["Retro Style", "event", 1, 0, 1, "Birthday2013Adventure4", "https://tsowiki.eu/adventures/pages/retro-style/"],
        ["Round of 16", "event", 1, 0, 16, "WMEventAdventure04", "https://tsowiki.eu/adventures/pages/round-of-16/"],
        ["Sabotage", "event", 1, 0, 17, null, "https://tsowiki.eu/adventures/pages/sabotage/"],
        ["Save the Christmas Feast", "event", 1, 0, 26, "ChristmasAdventureEasy", "https://tsowiki.eu/adventures/pages/save-the-christmas-feast/"],
        ["Semi-Finals", "event", 1, 0, 16, null, "https://tsowiki.eu/adventures/pages/semi-finals/"],
        ["The Cousin's Island", "event", 1, 0, 17, null, "https://tsowiki.eu/adventures/pages/the-cousin-s-island/"],
        ["The Dark Gate", "event", 1, 0, 28, "HWCampaign1_Adv3", "https://tsowiki.eu/adventures/pages/the-dark-gate/"],
        ["The Egg Hunt Begins", "event", 1, 0, 17, null, "https://tsowiki.eu/adventures/pages/the-egg-hunt-begins/"],
        ["The Egg Hunt Continues", "event", 1, 0, 17, "EasterEvent2013Adventure08", "https://tsowiki.eu/adventures/pages/the-egg-hunt-continues/"],
        ["The End Of The World", "event", 1, 0, 26, "EoWEventAdventure", "https://tsowiki.eu/adventures/pages/the-end-of-the-world/"],
        ["The jester's map", "event", 1, 0, 1, "Birthday2013Adventure3", "https://tsowiki.eu/adventures/pages/the-jester-s-map/"],
        ["The Shaman", "event", 1, 0, 26, "Birthday2013MilitaryAdventure1ShopVersion", "https://tsowiki.eu/adventures/pages/the-shaman/"],
        ["The Stolen Sleigh", "event", 1, 0, 36, null, "https://tsowiki.eu/adventures/pages/the-stolen-sleigh/"],
        ["Where Do Easter Eggs Come From?", "event", 1, 0, 26, "BuffAdventures_Easter_Event_2015", "https://tsowiki.eu/adventures/pages/where-do-easter-eggs-come-from/"],
        ["Winter Wonderland", "event", 1, 0, 26, "XMAS_Cookie_Easy_1", "https://tsowiki.eu/adventures/pages/winter-wonderland/"],
        ["Winter Wonderland revisited", "event", 1, 0, 26, "XMAS_Cookie_Easy_2", "https://tsowiki.eu/adventures/pages/winter-wonderland-revisited/"],
        ["Arctic Explosion", "mini mission", 1, 0, 42, "MiadArcticExplosion", "https://tsowiki.eu/adventures/pages/arctic-explosion/"],
        ["Bastille Island", "mini mission", 1, 0, 36, "MiadBastilleIsland", "https://tsowiki.eu/adventures/pages/bastille-island/"],
        ["Bounty Hunter", "mini mission", 1, 0, 26, "BountyHunterNew", "https://tsowiki.eu/adventures/pages/bounty-hunter/"],
        ["Pirate Life", "mini mission", 1, 0, 36, "MiadPirateLife", "https://tsowiki.eu/adventures/pages/pirate-life/"],
        ["Sleepy Reef", "mini mission", 1, 0, 26, "MiadSleepyReef", "https://tsowiki.eu/adventures/pages/sleepy-reef/"],
        ["The Dark Priests", "mini mission", 2, 1, 26, "TheDarkPriests", "https://tsowiki.eu/adventures/pages/the-dark-priests/"],
        ["The Lost Skull", "mini mission", 1, 0, 26, "MiadTheLostSkull", "https://tsowiki.eu/adventures/pages/the-lost-skull/"],
        ["The Sleeping Volcano", "mini mission", 1, 0, 26, "MiadTheSleepingVolcano", "https://tsowiki.eu/adventures/pages/the-sleeping-volcano/"],
        ["Tikki Island", "mini mission", 1, 0, 26, "MiadTikkiIsland", "https://tsowiki.eu/adventures/pages/tikki-island/"],
        ["Tropical Sun", "mini mission", 1, 0, 26, "MiadTropicalSun", "https://tsowiki.eu/adventures/pages/tropical-sun/"],
        ["Aladdin and the Beautiful Princess", "mission", 1, 0, 51, "1001NightsPrincess", "https://tsowiki.eu/adventures/pages/aladdin-and-the-beautiful-princess/"],
        ["Aladdin and the Oil Lamp", "mission", 3, 2, 51, "1001NightsOilLamp", "https://tsowiki.eu/adventures/pages/aladdin-and-the-oil-lamp/"],
        ["Ali Baba and the First Thief", "mission", 1, 0, 51, "1001NightsFirstThief", "https://tsowiki.eu/adventures/pages/ali-baba-and-the-first-thief/"],
        ["Ali Baba and the Second Thief", "mission", 2, 1, 51, "1001NightsSecondThief", "https://tsowiki.eu/adventures/pages/ali-baba-and-the-second-thief/"],
        ["Ali Baba and the Third Thief", "mission", 1, 0, 51, "1001NightsThirdThief", "https://tsowiki.eu/adventures/pages/ali-baba-and-the-third-thief/"],
        ["Ali Baba and the Treasure of Knowledge", "mission", 2, 1, 51, "1001NightsTreasureKnowledge", "https://tsowiki.eu/adventures/pages/ali-baba-and-the-treasure-of-knowledge/"],
        ["Ali Baba and the Treasure of Wisdom", "mission", 1, 0, 51, "1001NightsTreasureWisdom", "https://tsowiki.eu/adventures/pages/ali-baba-and-the-treasure-of-wisdom/"],
        ["Ali Baba the Young Woodcutter", "mission", 1, 0, 51, "1001NightsWoodcutter", "https://tsowiki.eu/adventures/pages/ali-baba-the-young-woodcutter/"],
        ["Bandit Nest", "mission", 1, 0, 36, "BanditNest", "https://tsowiki.eu/adventures/pages/bandit-nest/"],
        ["Bonaberti Business", "mission", 1, 0, 57, "BonabertiBusiness", "https://tsowiki.eu/adventures/pages/bonaberti-business/"],
        ["Desperate Rich", "mission", 1, 0, 26, "StealingFromTheRich02", "https://tsowiki.eu/adventures/pages/desperate-rich/"],
        ["Gunpowder", "mission", 3, 2, 36, "Gunpowder", "https://tsowiki.eu/adventures/pages/gunpowder/"],
        ["Horseback", "mission", 1, 0, 26, "Horseback", "https://tsowiki.eu/adventures/pages/horseback/"],
        ["More Secluded Experiments", "mission", 2, 1, 36, "MoreSecludedExperiments", "https://tsowiki.eu/adventures/pages/more-secluded-experiments/"],
        ["Motherly Love", "mission", 2, 1, 36, "MotherLove", "https://tsowiki.eu/adventures/pages/motherly-love/"],
        ["Old Friends", "mission", 1, 0, 36, "OldFriends", "https://tsowiki.eu/adventures/pages/old-friends/"],
        ["Outlaws", "mission", 1, 0, 36, "Outlaws", "https://tsowiki.eu/adventures/pages/outlaws/"],
        ["Return to the Bandit's Nest", "mission", 1, 0, 26, "NewBanditNest", "https://tsowiki.eu/adventures/pages/return-to-the-bandit-s-nest/"],
        ["Roaring Bull", "mission", 3, 2, 42, "RoaringBull", "https://tsowiki.eu/adventures/pages/roaring-bull/"],
        ["Secluded Experiments", "mission", 3, 2, 42, "SecludedExperiments", "https://tsowiki.eu/adventures/pages/secluded-experiments/"],
        ["Sindbad and the Besieged City", "mission", 2, 1, 51, "1001NightsBesiegedCity", "https://tsowiki.eu/adventures/pages/sindbad-and-the-besieged-city/"],
        ["Sindbad and the Sea Snake", "mission", 2, 1, 51, "1001NightsSeaSnake", "https://tsowiki.eu/adventures/pages/sindbad-and-the-sea-snake/"],
        ["Sir Robin's Revenge", "mission", 1, 0, 26, "Traitors02", "https://tsowiki.eu/adventures/pages/sir-robin-s-revenge/"],
        ["Sons Of The Veld", "mission", 2, 1, 36, "SonsOfTheVeld", "https://tsowiki.eu/adventures/pages/sons-of-the-veld/"],
        ["Stealing From The Rich", "mission", 2, 1, 26, "StealingFromTheRich", "https://tsowiki.eu/adventures/pages/stealing-from-the-rich/"],
        ["Surprise Attack", "mission", 2, 1, 36, "SurpriseAttack", "https://tsowiki.eu/adventures/pages/surprise-attack/"],
        ["The Betrayed Little Tailor", "mission", 3, 2, 42, "TheBetrayedLittleTailor", "https://tsowiki.eu/adventures/pages/the-betrayed-little-tailor/"],
        ["The Black Knights", "mission", 3, 2, 42, "TheBlackKnights", "https://tsowiki.eu/adventures/pages/the-black-knights/"],
        ["The Clever Little Tailor", "mission", 3, 2, 42, "TheCleverLittleTailor", "https://tsowiki.eu/adventures/pages/the-clever-little-tailor/"],
        ["The Dark Brotherhood", "mission", 3, 2, 42, "TheDarkBrotherhood", "https://tsowiki.eu/adventures/pages/the-dark-brotherhood/"],
        ["The Heroic Little Tailor", "mission", 3, 2, 42, "TheHeroicLittleTailor", "https://tsowiki.eu/adventures/pages/the-heroic-little-tailor/"],
        ["The Invasion of the Nords", "mission", 1, 0, 1, "TheNords2", "https://tsowiki.eu/adventures/pages/the-invasion-of-the-nords/"],
        ["The Island Of The Pirates", "mission", 1, 0, 26, "TheIslandOfThePirates", "https://tsowiki.eu/adventures/pages/the-island-of-the-pirates/"],
        ["The Nords", "mission", 2, 1, 36, "TheNords", "https://tsowiki.eu/adventures/pages/the-nords/"],
        ["The Sons of the Little Tailor", "mission", 3, 2, 42, "TheSonsOfTheLittleTailor", "https://tsowiki.eu/adventures/pages/the-sons-of-the-little-tailor/"],
        ["The Valiant Little Tailor", "mission", 3, 2, 42, "TheValiantLittleTailor", "https://tsowiki.eu/adventures/pages/the-valiant-little-tailor/"],
        ["Traitors", "mission", 1, 0, 26, "Traitors", "https://tsowiki.eu/adventures/pages/traitors/"],
        ["Victor The Vicious", "mission", 3, 2, 36, "VictorTheVicious", "https://tsowiki.eu/adventures/pages/victor-the-vicious/"],
        ["Wild Mary", "mission", 1, 0, 36, "MadHenry", "https://tsowiki.eu/adventures/pages/wild-mary/"],
        ["Witch of the Swamp", "mission", 1, 0, 26, "WitchOfTheSwamp", "https://tsowiki.eu/adventures/pages/witch-of-the-swamp/"],
        ["A Refreshing Expedition", "scenario", 1, 0, 1, "adv_unity_00", "https://tsowiki.eu/adventures/pages/a-refreshing-expedition/"],
        ["Heart of the Wood", "scenario", 1, 0, 36, "BuffAdventures_heartOfTheWood_medium", "https://tsowiki.eu/adventures/pages/heart-of-the-wood/"],
        ["Riches of the Mountain", "scenario", 1, 0, 42, "BuffAdventures_Riches_of_the_Mountain", "https://tsowiki.eu/adventures/pages/riches-of-the-mountain/"],
        ["Storm Recovery", "scenario", 1, 0, 51, "BuffAdventures_Storm_Recovery", "https://tsowiki.eu/adventures/pages/storm-recovery/"],
        ["The Grain Conflict", "scenario", 1, 0, 26, "BuffAdventures_safeTheTowns_easy", "https://tsowiki.eu/adventures/pages/the-grain-conflict/"],
        ["Twins", "scenario", 1, 0, 26, "BuffAdventures_twins_easy", "https://tsowiki.eu/adventures/pages/twins/"],
        ["A Giant Battle", "venture", 1, 0, 65, "BuffAdventures_TMC_A_giant_Battle", "https://tsowiki.eu/adventures/pages/a-giant-battle/"],
        ["At the Foot of the Mountain", "venture", 1, 0, 65, "BuffAdventures_TMC_At_the_Foot_of_the_Mountain", "https://tsowiki.eu/adventures/pages/at-the-foot-of-the-mountain/"],
        ["El Chupacabra", "venture", 1, 0, 44, "BuffAdventures_ElChupacabra", "https://tsowiki.eu/adventures/pages/el-chupacabra/"],
        ["Hansel and Gretel", "venture", 1, 0, 58, "BuffAdventures_Evil_Queen_Hansel_Gretel", "https://tsowiki.eu/adventures/pages/hansel-and-gretel/"],
        ["Mountain Labyrinth", "venture", 1, 0, 65, "BuffAdventures_TMC_Mountain_Labyrinth", "https://tsowiki.eu/adventures/pages/mountain-labyrinth/"],
        ["Of Songs and Curses", "venture", 1, 0, 28, "BuffAdventures_OfSongsAndCurses", "https://tsowiki.eu/adventures/pages/of-songs-and-curses/"],
        ["One Step Ahead", "venture", 1, 0, 63, "BuffAdventures_OneStepAhead", "https://tsowiki.eu/adventures/pages/one-step-ahead/"],
        ["Raid of the Nords", "venture", 1, 0, 44, "BuffAdventures_RaidOfTheNords", "https://tsowiki.eu/adventures/pages/raid-of-the-nords/"],
        ["Red Riding Hood", "venture", 1, 0, 58, "BuffAdventures_Evil_Queen_Red_Riding_Hood", "https://tsowiki.eu/adventures/pages/red-riding-hood/"],
        ["Snow White", "venture", 1, 0, 58, "BuffAdventures_Evil_Queen_Snow_White", "https://tsowiki.eu/adventures/pages/snow-white/"],
        ["The Dragon's Roost", "venture", 1, 0, 28, "BuffAdventures_DragonsRoost", "https://tsowiki.eu/adventures/pages/the-dragon-s-roost/"],
        ["The Fisherman and his Wife", "venture", 1, 0, 58, "BuffAdventures_Evil_Queen_Fisherman", "https://tsowiki.eu/adventures/pages/the-fisherman-and-his-wife/"],
        ["The Lost City", "venture", 1, 0, 63, "BuffAdventures_LostCity", "https://tsowiki.eu/adventures/pages/the-lost-city/"],
        ["The People of the Mountain", "venture", 1, 0, 65, "BuffAdventures_TMC_The_People_of_the_Mountain", "https://tsowiki.eu/adventures/pages/the-people-of-the-mountain/"],
        ["The Pied Piper of Hamelin", "venture", 1, 0, 58, "BuffAdventures_Evil_Queen_Piper_of_Hamelin", "https://tsowiki.eu/adventures/pages/the-pied-piper-of-hamelin/"],
        ["Unknown Regions", "venture", 1, 0, 65, "BuffAdventures_TMC_Unknown_Regions", "https://tsowiki.eu/adventures/pages/unknown-regions/"],
        ["Valuable Intel", "venture", 1, 0, 28, "BuffAdventures_ValuableIntel", "https://tsowiki.eu/adventures/pages/valuable-intel/"],
        ["Getting into the Christmas Spirit (hard)", "event", 1, 0, null, "XMAS_Map_Hard_2", null],
        ["Improving the Christmas Spirit (hard)", "event", 1, 0, null, "XMAS_Map_Hard_5", null],
        ["Keeping up the Christmas Spirit (hard)", "event", 1, 0, null, "XMAS_Map_Hard_7", null]];
    /* 0.1.3: the guide of each adventure on settlersonlinewiki.eu (the author's central place for guides); registered copy of
       docs/06-adventures/adventure-guides.json, fetched 2026-11-20 (tests/unit/catalogue-guides.test.js keeps them equal) */
    var GUIDES = [["A Giant Battle","https://settlersonlinewiki.eu/en/adventures/ventures/a-giant-battle/"],["A new experience","https://settlersonlinewiki.eu/en/adventures/events/new-experience"],["Aladdin and the Beautiful Princess","https://settlersonlinewiki.eu/en/adventures/fairy-tale/aladdin-and-the-beautiful-princess"],["Aladdin and the Oil Lamp","https://settlersonlinewiki.eu/en/adventures/fairy-tale/aladdin-and-the-oil-lamp"],["Ali Baba and the First Thief","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-and-the-first-thief"],["Ali Baba and the Second Thief","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-and-the-second-thief"],["Ali Baba and the Third Thief","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-and-the-third-thief"],["Ali Baba and the Treasure of Knowledge","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-and-the-treasure-of-knowledge"],["Ali Baba and the Treasure of Wisdom","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-and-the-treasure-of-wisdom"],["Ali Baba the Young Woodcutter","https://settlersonlinewiki.eu/en/adventures/fairy-tale/ali-baba-the-young-wood-cutter"],["Arctic Explosion","https://settlersonlinewiki.eu/en/adventures/for-one-player/arctic-explosion"],["At the Foot of the Mountain","https://settlersonlinewiki.eu/en/adventures/ventures/at-the-foot-of-the-mountain/"],["Bandit Nest","https://settlersonlinewiki.eu/en/adventures/for-one-player/bandit-nest"],["Bastille Island","https://settlersonlinewiki.eu/en/adventures/for-one-player/bastille-island"],["Bonaberti Business","https://settlersonlinewiki.eu/en/adventures/for-one-player/bonaberti-business/"],["Bounty Hunter","https://settlersonlinewiki.eu/en/adventures/for-one-player/bounty-hunter"],["El Chupacabra","https://settlersonlinewiki.eu/en/adventures/ventures/el-chupacabra/"],["Garrun the Trapper","https://settlersonlinewiki.eu/en/adventures/for-one-player/garrun-the-trapper"],["Gunpowder","https://settlersonlinewiki.eu/en/adventures/for-three-players/gunpowder"],["Hansel and Gretel","https://settlersonlinewiki.eu/en/adventures/ventures/hansel-and-gretel/"],["Heart of the Wood","https://settlersonlinewiki.eu/en/adventures/scenarios/heart-of-the-wood"],["Hero wanted","https://settlersonlinewiki.eu/en/adventures/events/hero-needed-immediately"],["Horseback","https://settlersonlinewiki.eu/en/adventures/for-one-player/horseback"],["Lakeside Treasure","https://settlersonlinewiki.eu/en/adventures/cooperation/lakeside-treasure"],["Looming Danger","https://settlersonlinewiki.eu/en/adventures/events/looming-danger/"],["Misty Cake","https://settlersonlinewiki.eu/en/adventures/events/misty-cake/"],["Monsters from the Mist","https://settlersonlinewiki.eu/en/adventures/events/monsters-from-the-mist/"],["More Secluded Experiments","https://settlersonlinewiki.eu/en/adventures/for-two-players/more-secluded-experiments"],["Motherly Love","https://settlersonlinewiki.eu/en/adventures/for-two-players/motherly-love"],["Mountain Labyrinth","https://settlersonlinewiki.eu/en/adventures/ventures/mountain-labyrinth/"],["Nothing special","https://settlersonlinewiki.eu/en/adventures/events/nothing-special"],["Of Songs and Curses","https://settlersonlinewiki.eu/en/adventures/ventures/of-songs-and-curses/"],["Old Friends","https://settlersonlinewiki.eu/en/adventures/for-one-player/old-friends"],["Old Ruins","https://settlersonlinewiki.eu/en/adventures/for-one-player/old-ruins"],["One Step Ahead","https://settlersonlinewiki.eu/en/adventures/ventures/one-step-ahead/"],["Outlaws","https://settlersonlinewiki.eu/en/adventures/for-one-player/outlaws"],["Pirate Life","https://settlersonlinewiki.eu/en/adventures/for-one-player/pirate-life"],["Raid of the Nords","https://settlersonlinewiki.eu/en/adventures/ventures/raid-of-the-nords/"],["Raiding the Raiders","https://settlersonlinewiki.eu/en/adventures/cooperation/raiding-the-raiders"],["Red Riding Hood","https://settlersonlinewiki.eu/en/adventures/ventures/red-riding-hood/"],["Retro Style","https://settlersonlinewiki.eu/en/adventures/events/retro-style"],["Riches of the Mountain","https://settlersonlinewiki.eu/en/adventures/scenarios/riches-of-the-mountain"],["Roaring Bull","https://settlersonlinewiki.eu/en/adventures/for-three-players/roaring-bull"],["Save the Christmas Feast","https://settlersonlinewiki.eu/en/adventures/for-one-player/save-the-christmas-feast"],["Secluded Experiments","https://settlersonlinewiki.eu/en/adventures/for-three-players/secluded-experiments"],["Sindbad and the Besieged City","https://settlersonlinewiki.eu/en/adventures/fairy-tale/sinbad-and-the-besieged-city"],["Sindbad and the Sea Snake","https://settlersonlinewiki.eu/en/adventures/fairy-tale/sinbad-and-the-sea-snake"],["Sleepy Reef","https://settlersonlinewiki.eu/en/adventures/for-one-player/sleepy-reef"],["Snow White","https://settlersonlinewiki.eu/en/adventures/ventures/snow-white/"],["Sons Of The Veld","https://settlersonlinewiki.eu/en/adventures/for-two-players/sons-of-the-veld"],["Split City in Fall","https://settlersonlinewiki.eu/en/adventures/cooperation/split-city-in-fall/"],["Split City in Summer","https://settlersonlinewiki.eu/en/adventures/cooperation/split-city-in-summer/"],["Stealing From The Rich","https://settlersonlinewiki.eu/en/adventures/for-two-players/stealing-from-the-rich"],["Storm Recovery","https://settlersonlinewiki.eu/en/adventures/scenarios/storm-recovery"],["Surprise Attack","https://settlersonlinewiki.eu/en/adventures/for-two-players/suprise-attack"],["The Betrayed Little Tailor","https://settlersonlinewiki.eu/en/adventures/fairy-tale/the-betrayed-little-tailor"],["The Black Knights","https://settlersonlinewiki.eu/en/adventures/for-three-players/the-black-knights"],["The Buccaneer Roundup","https://settlersonlinewiki.eu/en/adventures/cooperation/the-buccaneer-roundup"],["The Clever Little Tailor","https://settlersonlinewiki.eu/en/adventures/fairy-tale/the-clever-little-tailor"],["The Dark Brotherhood","https://settlersonlinewiki.eu/en/adventures/for-three-players/the-dark-brotherhood"],["The Dark Gate","https://settlersonlinewiki.eu/en/adventures/events/the-dark-gate/"],["The Dark Priests","https://settlersonlinewiki.eu/en/adventures/for-two-players/the-dark-priests"],["The Dragon's Roost","https://settlersonlinewiki.eu/en/adventures/ventures/the-dragons-roost/"],["The End Of The World","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-end-of-the-world"],["The Fisherman and his Wife","https://settlersonlinewiki.eu/en/adventures/ventures/the-fisherman-and-his-wife/"],["The Grain Conflict","https://settlersonlinewiki.eu/en/adventures/scenarios/the-grain-conflict"],["The Heroic Little Tailor","https://settlersonlinewiki.eu/en/adventures/fairy-tale/the-heroic-little-tailor"],["The Invasion of the Nords","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-invasion-of-the-nords"],["The Island Of The Pirates","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-island-of-the-pirates"],["The Lost City","https://settlersonlinewiki.eu/en/adventures/ventures/the-lost-city/"],["The Lost Skull","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-lost-skull"],["The Nords","https://settlersonlinewiki.eu/en/adventures/for-two-players/the-nords"],["The People of the Mountain","https://settlersonlinewiki.eu/en/adventures/ventures/the-people-of-the-mountain/"],["The Pied Piper of Hamelin","https://settlersonlinewiki.eu/en/adventures/ventures/the-pied-piper-of-hamelin/"],["The Shaman","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-shaman"],["The Siege","https://settlersonlinewiki.eu/en/adventures/cooperation/the-siege"],["The Sleeping Volcano","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-sleeping-volcano"],["The Sons of the Little Tailor","https://settlersonlinewiki.eu/en/adventures/fairy-tale/the-sons-of-the-little-tailor"],["The Stolen Sleigh","https://settlersonlinewiki.eu/en/adventures/for-one-player/the-stolen-sleight"],["The Valiant Little Tailor","https://settlersonlinewiki.eu/en/adventures/fairy-tale/the-valiant-little-tailor"],["The Whirlwind","https://settlersonlinewiki.eu/en/adventures/cooperation/the-whirlwind"],["Tikki Island","https://settlersonlinewiki.eu/en/adventures/for-one-player/tikki-island"],["Tomb Raiders","https://settlersonlinewiki.eu/en/adventures/cooperation/tomb-raiders"],["Traitors","https://settlersonlinewiki.eu/en/adventures/for-one-player/traitors"],["Tropical Sun","https://settlersonlinewiki.eu/en/adventures/for-one-player/tropical-sun"],["Twins","https://settlersonlinewiki.eu/en/adventures/scenarios/twins"],["Unknown Regions","https://settlersonlinewiki.eu/en/adventures/ventures/unknown-regions/"],["Valuable Intel","https://settlersonlinewiki.eu/en/adventures/ventures/valuable-intel/"],["Victor The Vicious","https://settlersonlinewiki.eu/en/adventures/for-three-players/victor-the-vicious"],["Where Do Easter Eggs Come From?","https://settlersonlinewiki.eu/en/adventures/scenarios/where-do-easter-eggs-come-from"],["Wild Mary","https://settlersonlinewiki.eu/en/adventures/for-one-player/wild-mary"],["Witch of the Swamp","https://settlersonlinewiki.eu/en/adventures/for-one-player/witch-of-the-swamp"]];
    var guideBy = {}; GUIDES.forEach(function (x) { guideBy[x[0]] = x[1]; });
    var list = ROWS.map(function (r) { return { name: r[0], type: r[1], players: r[2], lootSpots: r[3], level: r[4], res: r[5], url: r[6], guide: guideBy[r[0]] || null }; });
    var byRes = {}; list.forEach(function (a) { if (a.res) byRes[a.res] = a; });
    var STOP = { the: 1, and: 1, of: 1, a: 1, ali: 1, baba: 1, aladdin: 1, sindbad: 1 };
    /* the author's folder names are initials: FT (First Thief), YWC (Young WoodCutter), VLT (Valiant Little Tailor) */
    function abbr(name) {
        var w = String(name || "").replace(/[^A-Za-z ]/g, " ").split(/\s+/).filter(function (x) { return x && !STOP[x.toLowerCase()]; });
        var s = w.map(function (x) { return x.charAt(0).toUpperCase(); }).join("");
        if (/woodcutter/i.test(name)) s = s.replace(/W$/, "WC");
        return s;
    }
    /* 0.1.1: series (ADR 0046) — play order, template folder per adventure */
    var SERIES = [{ id: "tmc", title: "Series: The Mountain Clan", note: "play in this order; one Mundane set per adventure (ADR 0046)",
                    items: [["BuffAdventures_TMC_At_the_Foot_of_the_Mountain", "AtFotM"], ["BuffAdventures_TMC_Unknown_Regions", "UR"],
                            ["BuffAdventures_TMC_Mountain_Labyrinth", "ML"], ["BuffAdventures_TMC_The_People_of_the_Mountain", "TPotM"],
                            ["BuffAdventures_TMC_A_giant_Battle", "AGB"]] }];
    var seriesByRes = {}, folderByName = {};
    SERIES.forEach(function (sr) { sr.items.forEach(function (it, i) { seriesByRes[it[0]] = { id: sr.id, title: sr.title, step: i + 1, of: sr.items.length, folder: it[1] };
        if (byRes[it[0]]) folderByName[byRes[it[0]].name.toLowerCase()] = it[1]; }); });
    var abbr0 = abbr;
    abbr = function (name) { var f = folderByName[String(name || "").toLowerCase()]; return f || abbr0(name); };
    function seriesGroups() { return SERIES.map(function (sr) { return { type: "series", id: sr.id, title: sr.title, note: sr.note,
        items: sr.items.map(function (it, i) { var a = byRes[it[0]]; if (!a) return null; var o = {}; Object.keys(a).forEach(function (k) { o[k] = a[k]; }); o.step = i + 1; o.folder = it[1]; return o; }).filter(Boolean) }; }); }
    /* 0.1.2 (ADR 0079): advice per adventure and the version kinds */
    var ADVICE = { BonabertiBusiness: [{ code: "NO_BLOCKS", level: "warn",
        text: "Do not use blocks: block runs failed here (ADR 0066). Play it without blocks (two waves, generals reused) or camp by camp." }] };
    var KINDS = [{ mode: "blocks", label: "blocks", hint: "templates with block entries; needs ALL: allow blocks (adv.blocks.on)" },
                 { mode: "without blocks", label: "without blocks (waves)", hint: "each attack template is a wave; camps start when their way is clear; the same generals come back and are loaded for the next wave" },
                 { mode: "camp by camp", label: "camp by camp", hint: "one camp at a time; a camp's next attacker leaves when the one before is fighting" },
                 { mode: "full", label: "own Mundane", hint: "your own Mundane folder, analysed and played" },
                 { mode: "shared Mundane", label: "author's Mundane", hint: "a shared folder with generals.json; checked against your generals (same, equally skilled, or alternatives)" }];
    function advice(r) { return (ADVICE[r] || []).map(function (a) { return { code: a.code, level: a.level, text: a.text }; }); }
    var api = { version: VERSION, TYPES: TYPES, KINDS: KINDS, advice: advice, noBlocks: function (r) { return advice(r).some(function (a) { return a.code === "NO_BLOCKS"; }); },
                series: function (id) { return seriesGroups().filter(function (g) { return g.id === id; })[0] || null; },
                seriesOf: function (r) { return seriesByRes[r] || null; }, list: function () { return list.slice(); }, byRes: function (r) { return byRes[r] || null; },
                byName: function (n) { n = String(n || "").toLowerCase(); return list.filter(function (a) { return a.name.toLowerCase() === n; })[0] || null; }, abbr: abbr,
                groups: function () { return seriesGroups().concat(TYPES.map(function (t) { return { type: t[0], title: t[1], items: list.filter(function (a) { return a.type === t[0]; }) }; })); } };
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    root.DMA_AdvCatalogue = api;
})(typeof window !== "undefined" ? window : this);
