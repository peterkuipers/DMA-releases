/*
 * DMA Event 0.2.13 — the event manager and the rule sets of the event types (decisions 0026, 0028).
 *
 * Author, 2026-10-29 10:33 Dubai: "Dus je hebt een event manager die constateert dat een event gestart of gestopt is van
 * een bepaald type. Daardoor zijn bedrijfsregels geldig, die gespecificeerd kunnen worden door de speler op die
 * betreffende pagina."
 *
 * Two parts, one concern each:
 *   - EVENT MANAGER (actor role, console button EVENT): observes which events the game runs — the game's
 *     Events:EventManager (client.swf: GetActiveEventNames, isEventRunning, GetEventStartDate, GetEventStopDate) — and
 *     records "event <type> started / stopped" as facts. It decides nothing else.
 *   - RULE SETS per event type: what a type brings while it runs (for Halloween: the pumpkin cemeteries and their seconds
 *     per pumpkin). The player specifies them on the EVENT page (policy event.<type>.buffable); the defaults come from
 *     the wiki. A rule set is VALID only while the event manager observes its type running.
 * Green (R-EV-BUFF-CHOICE) and the buff manager (R-EV-BUFF-WHEN) read match(name); it returns nothing for a type that
 * does not run, so the demand to buff lapses when the event stops.
 *
 * When the game's event list cannot be read, the type counts as running only up to its fallback end (untilMs), and the
 * EVENT page says the state is assumed, not observed.
 *
 * 0.3.0 (2026-11-16, ADR 0074 step 3b; the author: "filling a deposit is the same transaction as a buff", D-5): the event module keeps only the READING of a fill round — which event type runs, the filler stack in the star,
 *   which buildings are fillable and how much each gets (spread) — and hands the round to the construction manager (DMA_ConstructionManager.requestFills): the AR20 request, the order to the buff applier (applyFill)
 *   and the review of the fill (declare + accept when the deposit grows) are theirs now. The hand-over happens only while the manager reports ready and offers requestFills (presence and readiness, ADR 0074 section 3);
 *   without it the round is sent exactly as in 0.2.17 (rollback = remove the manager file). The counters verified / notShown in fill.status() are still kept, fed by the manager's report.
 *   Unit: tests/unit/dma-event-fill-handover.test.js (the round is handed over with plan, filler id and before-amounts and the event module sends nothing itself; without the manager it sends as before).
 *   Integration: tests/integration/dma-event-fill-handover.test.js (real event, adapter, applier and manager: the fills reach the game once each through the applier, request by the construction manager).
 * 0.2.17 (2026-11-16, coordinator, model v3.18 PR #431; adapter 0.2.4): the trick counter's pair is read from the facts, not typed here. "Answer a trick
 *   with a Treat" was { when: "Horror", give: "Treat" } at the type table; the pair is now the registered BUFF ACTION of the event type
 *   (docs/05-ontology/dma/facts/buff-actions.yaml via GCAF_GameInterface.buffActions()): when = the acted-on kind (HalloweenEvent_Horror), give =
 *   the acting kind (Treat). Without the adapter or without a fact for the type the counter is not offered. The player's rules .on / .when / .give
 *   still override. Unit: tests/unit/dma-event-counter-from-facts.test.js (the pair equals the registered fact; no adapter = no counter).
 *   Integration: tests/integration/dma-trick-treat.test.js (event manager + green + adapter: the tricked bakery gets the Treat).
 * 0.2.16 (2026-11-16, tester batch on ADR 0073; coordinator): a TRANSIENT refusal is not a decline. When the adapter answers retry: true (a hold or the
 *   pace) the fill waits and is sent again 1.5 s later, up to 5 times, under the same TK41 case; if the hold outlasts that, the
 *   initiator revokes its request ("revoke request", reason = the adapter's) and the round is open again at once (lastRoundAt is
 *   cleared) so that the next tick plans it anew. No decline, no promise. Any other refusal still declines with the adapter's
 *   reason. Integration: tests/integration/event-fill-retry-waits.test.js (moved from tests/known-failing/kf-retry-declines-event-fill).
 * 0.2.15 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C2 of the migration): the fill send
 *   goes through the Game Interface Adapter, GCAF_GameInterface.sendAction("EVENT_FILL", 0, grid, amount, uid), not through
 *   gi.SendServerAction: the adapter decides (registered command, an amount above 0, start-up and visit holds, pace per class
 *   "fill", control's permit opened for the one call) and answers { ok } or { ok: false, reason }. The buff applier promises only
 *   on ok; a refusal is a TK41 decline with the adapter's reason ("the client refused the send" is gone: the adapter says what
 *   refused). No adapter loaded = decline "game interface adapter not loaded". This is the fix of
 *   kf-event-fill-blocked-by-control, which moves into the suite as tests/integration/event-fill-through-adapter.test.js.
 *   Unit: tests/unit/dma-event-fill.test.js (an adapter refusal -> decline with its reason, nothing pending).
 *   Integration: tests/integration/event-fill-through-adapter.test.js (real control + adapter + event: the fills reach the game,
 *   the permit is closed again).
 * 0.2.14 (2026-11-16, architect verdict on PR #391):
 *   (1) A fill is declared only when the deposit is SEEN to grow. A send the client takes is not proof: after it the
 *   buff applier promises and executes, and the case waits (fillState.pending). The deposit at the grid is read again
 *   20 s after the send and at every tick; when its amount is above the amount before the round, the buff applier
 *   declares (amount seen) and the construction manager accepts. When it has not grown 10 minutes after the send, the
 *   buff applier revokes its promise ("the deposit did not grow"), the construction manager allows it (EO2 §8.2.6.3:
 *   back to requested), and the buff applier declines — so no fill is ever declared that did not happen.
 *   (2) An unreadable events picture no longer counts as "event running": when the location manager's picture is
 *   missing or not readable, no type runs (the fallback date is no longer assumed), as zombies, green and premium read
 *   it. status().how says "running events could not be read". An event in the picture whose stop date has passed does
 *   not run (as agents' eventRunning).
 *   Unit: tests/unit/dma-event-fill.test.js (declare/accept only after the deposit grows; a deposit that never grows ->
 *   revoke promise, allow, decline; nothing declared at the send) and tests/unit/dma-event-picture.test.js (no picture or
 *   not readable -> nothing runs). Integration: tests/integration/dma-event-fill-tk41.test.js (event + C-fact memory +
 *   picture: grown fills end accepted, a fill that never shows ends declined after an allowed revocation; nothing
 *   foreign).
 * 0.2.13 (2026-11-16, backbone v3.16 — ADR 0071 D-5, confirmed by the author 2026-11-16: "filling is part of creating
 *   and changing"; reconciliation R-13; ADR 0040):
 *   (1) Each fill is TK41 buff applying with buff sort "deposit filler" (AT76), requested by AR20 construction manager
 *   (ARS-20-11: "[construction] needs filling", DFS-45) and executed by AR41 buff applier: per building of a round,
 *   request (construction manager) -> promise -> execute -> declare (buff applier, when the client took the send) ->
 *   accept (construction manager); a send the client refuses (false) or that throws -> decline (buff applier, why). One
 *   case per building and round (caseId "fill@<grid>@<round time>"). The TK-EV facts ("fill", "started", "stopped",
 *   "observed running") are no longer written: TK-EV is retired in the backbone (v3.16).
 *   (2) The event manager no longer reads the game's events itself: observe() takes the running events from the location
 *   manager's events picture (DMA_Demo.events, agents 0.4.27) and matches them to the event types by their game names as
 *   before. When the picture is missing or says "not readable", the type's fallback date applies as it did when the
 *   game's list could not be read. The changes of the running set are kept as information facts ("event started" /
 *   "event stopped", no transaction kind).
 *   Unit: tests/unit/dma-event-fill.test.js (a round gives one TK41 case per building: request by the construction
 *   manager, buffSort deposit filler, promise/execute/declare by the buff applier, accept; a refused send -> decline; no
 *   TK-EV) and tests/unit/dma-event-picture.test.js (running events from the picture; no game read). Integration:
 *   tests/integration/dma-event-fill-tk41.test.js (event + C-fact memory + picture: the round's TK41 instances end
 *   accepted; nothing foreign; no TK-EV instance).
 * 0.2.12 (2026-11-16, architecture review 2026-11-16 finding #12, packaging §5.2 "every automation switch defaults off
 *   for a new player"): the Event switch event.auto falls back to OFF when no policy answers (only true / "true" is on).
 *   With the policy loaded nothing changes: event.auto is a policy switch (stored value, else off; policy 0.2.58 no
 *   longer writes it on for every policy that lacks it). No other behaviour change.
 *   Unit: tests/unit/dma-event-switch.test.js (unset -> off; on only when the player set it). Integration:
 *   tests/integration/dma-event-default.test.js (real policy + event manager: fresh -> off, no fill, no counters, no
 *   event building; switched on -> the event's buildings and counters).
 * 0.2.11 (2026-11-09, author: "Green onthoudt alleen en doet berekeningen. Een rode transactor role bufft"): the buff
 *   and trick parts are executed by the buffer (TK41, root.DMA_Buffer, green 0.8.20); green only computes the choice.
 * 0.2.10 (2026-11-09, live 0.2.9: buff and trick showed "needs you"): on the client the buff manager is a stub — the
 *   buffer is green (R-EV-BUFF-WHEN / R-EV-COUNTER run there), so the buff and trick parts need DMA_Green only.
 * 0.2.9 (2026-11-09, author: "dus de event manager heeft een pagina met een onderdeel voor elk event ... Ben ik nog
 *   zaken vergeten" — then "ja"): an event type names its PARTS — the fixed things the event asks of the player, each
 *   with the actor role that executes it and a switch (event.<type>.<part>.on; fill / buff / trick keep their own
 *   rules, event quests use quest.do.event). parts(type) gives per part: on, the actor, whether that actor is loaded
 *   (root global), and a state — "auto" (switched on, executor loaded), "off", or "needs you" (switched on, no
 *   executor). The parts that need the player are the event manager's notice to him (ADR 0053: no silent gaps); the
 *   list is written to dma-event-parts.json once a minute when it changed. Halloween: place the cemeteries, earn
 *   fillers, fill to the maximum, buff the cemeteries round the clock, answer tricks, event quests first, golem hearts
 *   in the Provision House, defeat golems (own island and friends'), zombie crypts, event adventures, pumpkin
 *   upgrades, other pumpkin sources, the event shop, the event dates.
 *   Unit: tests/unit/dma-event-parts.test.js; integration: live, dma-event-parts.json lists the golem parts as
 *   "needs you" and the fill part as "auto".
 * 0.2.8 (2026-11-09, author: "event quest have a high priority if auto is selected. also adjust the console so event
 *   and quest book kan be selected, inclusding all subselections"): the Event switch (event.auto, policy 0.2.48, default
 *   on) is the master of the event manager: while it is off, match() declares no event building (no event buffs),
 *   counters() gives none and filling waits ("Event switch off"). The sub-rules per type stay as they are.
 *   Unit: tests/unit/dma-event-switch.test.js; integration: live, switching Event off stops the fill rounds.
 * 0.2.7 (2026-11-03, live: first round placed only 84 of 518): the deposit's GetMaxAmount is its ORIGINAL size (small
 *   45, common 80, noble 100) — nobles held 263 already and the author's own fills reached 445 — so it is no cap. The
 *   limit is the author's rule alone: hours until the event ends x units per hour (x rateX).
 * 0.2.6 (2026-11-03, author: "Denk ook aan het aanvullen van de begraafplaatsen"): 0.2.5 never placed a filler — it
 *   looked for "pumpkin", but the game names the pumpkin filler FillDeposit / resource "HalloweenResource" (live: 518 in
 *   the star, read 0). The rule set's match is now "pumpkin|HalloweenResource" for the filler and the deposits.
 *   Unit: tests/unit/dma-event-fill.test.js runs with the game's names; integration: live, a TK-EV fill fact within 30 min.
 * 0.2.5 (2026-11-01, author: "en de fillers toepassen" — "Pompoen vullen is onderdeel van het event halloween"): FILLING
 *   is part of an event type's rule set. Halloween declares fill { buffPrefix "FillDeposit", unit pumpkin }: while the
 *   type runs, the event manager puts the star's deposit fillers on the type's buildings the way the game's amount
 *   dialog does (APPLY_BUFF 61, 0, grid, amount, uniqueId), following docs/06-adventures/cemetery-filling.md:
 *   LIMIT per building = hours until the event ends x units per hour x event.<type>.fill.rateX (5), never above the
 *   deposit's maximum; the largest filler stack is spread for EQUAL HOURS OF COVER; at home, no visit hold, at most one
 *   round per event.<type>.fill.everyMin (30), only from event.<type>.fill.minBatch (10) units; event.<type>.fill.on
 *   (default on). Status in dma-fill-status.json, a TK-EV fact per round. Replaces user_dma_filler.js 0.1.0.
 *   Unit: tests/unit/dma-event-fill.test.js; integration: live, fillers from an AE mail land on the nine cemeteries.
 * 0.2.4 (2026-10-30, ADR 0030): the event manager does not read the game's event list while a visit hold is on.
 * 0.2.3 (2026-10-29, live: the EVENT page showed the trick on 30 buildings is the buff "HalloweenEvent_Horror"): the
 *   default 'when' of the trick counter is "Horror"; with it the buffer put a Treat on the tricked buildings, 5 per cycle.
 * 0.2.2 (2026-10-29, author: "they are putting tricks on my building, you can go after it with treats" — "a scan must be
 *   able to tell"): a rule set can name COUNTERS: a building that carries a buff whose name contains `when` gets the buff
 *   `give` (it replaces the one there). Halloween: a trick is answered with a Treat (+300 %, 2 h, "Target: Workyard with
 *   the trick buff"). Player rules on the EVENT page: event.halloween.trick.on (default on), event.halloween.trick.when
 *   (default "trick"), event.halloween.trick.give (default "Treat").
 * 0.2.1 (2026-10-29, live: the EVENT page showed "the game runs: HW2017plus_Shop, HW2017plus_Content" and "Halloween — not
 *   running"): the game names Halloween "HW2017plus_*", not "Halloween". The names that count for a type are a rule the
 *   player sets on the EVENT page (event.<type>.gameNames, comma separated, a name counts when it starts with one of
 *   them, case-insensitive); default for Halloween "Halloween, HW".
 * 0.2.0 (2026-10-29, ADR 0028): the event manager replaces the fixed end date as the ground of validity; rule sets per
 *   type with player overrides; facts "started"/"stopped"; status() for the EVENT page.
 * 0.1.2: event end as Date.UTC (the AIR engine returns NaN for Date.parse of an ISO string).
 * 0.1.1: match() ignores case and underscores in the game's building name.
 *
 * Unit expectation:        with the game reporting an event name containing "Halloween", match("pumpkinfield_03") gives
 *                          2400 s per pumpkin and one "started" fact is recorded; when the game no longer reports it,
 *                          match() gives nothing and one "stopped" fact is recorded; a player override of the seconds per
 *                          pumpkin is used.
 * Integration expectation: with Halloween stopped, the buff manager proposes no cemetery buff even with buff.event.on
 *                          (tests/integration/dma-event-manager.test.js).
 */
(function (root) {
    "use strict";
    var VERSION = "0.3.0";
    var OBSERVE_MS = 60000;

    /* the rule sets of the event types: defaults; the player overrides them on the EVENT page */
    var TYPES = {
        halloween: {
            label: "Halloween",
            gameNames: "Halloween, HW",   // 0.2.1: default; the player's rule event.halloween.gameNames overrides it
            unit: "pumpkin",
            counters: { trick: { fact: true, on: true, label: "answer a trick with a Treat" } },   // 0.2.2; 0.2.17: the pair (when / give) is the registered BUFF ACTION of the event
            fallbackUntilMs: Date.UTC(2026, 10, 30),
            fill: { buffPrefix: "FillDeposit", match: "pumpkin|HalloweenResource", rateX: 5, minBatch: 10, everyMin: 30 },   // 0.2.5; 0.2.6: the game's name
            /* 0.2.9: the parts of the event — rule: the switch rule (default event.halloween.<id>.on); dflt: its default;
               actor: the executing role; uses: root globals of the executor (all loaded = executor present; none = by hand) */
            parts: [
                { id: "place",      label: "Place the nine cemeteries",                                   actor: "player (layout / event merchant not live)", uses: [] },
                { id: "earn",       label: "Earn fillers (GP runs with loot spots, explorers, mail)",     actor: "adventure manager + mail manager", uses: ["DMA_Adventure", "DMA_Mail"] },
                { id: "fill",       label: "Fill the cemeteries to the maximum (hours to the end x rate)", actor: "event manager", uses: ["DMA_Event"] },
                { id: "buff",       label: "Buff the cemeteries round the clock with the most effective buff", actor: "buffer (TK41; green computes the choice)", uses: ["DMA_Buffer"], dflt: false },
                { id: "trick",      label: "Answer a trick with a Treat",                                actor: "buffer (TK41)", uses: ["DMA_Buffer"] },
                { id: "quests",     label: "Event quests first in the quest book",                       actor: "quest manager", uses: ["DMA_Quest"], rule: "quest.do.event" },
                { id: "golemmake",  label: "Make golem hearts in the Provision House event tab",         actor: "player (no executor yet)", uses: [] },
                { id: "golemkill",  label: "Defeat golems: own island and friends' islands",             actor: "player (no executor yet)", uses: [] },
                { id: "crypts",     label: "Clear the zombie crypts",                                    actor: "zombie hunter", uses: ["DMA_Zombies"] },
                { id: "adventures", label: "Play the event adventures (Terrorized Town, Darkhood)",       actor: "player (not learned by the adventure manager)", uses: [] },
                { id: "upgrade",    label: "Upgrade buildings with pumpkins",                            actor: "player (no executor yet)", uses: [] },
                { id: "sources",    label: "Other pumpkin sources: explorers, Love Tree, PFB, premium",  actor: "explorer agents + premium", uses: ["DMA_Demo", "DMA_Premium"] },
                { id: "shop",       label: "Spend the pumpkins in the event shop before it closes",      actor: "player (no executor yet)", uses: [] },
                { id: "dates",      label: "Event dates: fillers until the stop, shop and claims until deactivation", actor: "event manager", uses: ["DMA_Event"] }
            ],
            buffable: {
                pumpkinfield_01: { label: "Small Pumpkin Cemetery",  secondsPerUnit: 19200 },
                pumpkinfield_02: { label: "Common Pumpkin Cemetery", secondsPerUnit: 9600 },
                pumpkinfield_03: { label: "Noble Pumpkin Cemetery",  secondsPerUnit: 2400 }
            }
        }
    };

    var state = { readable: false, at: 0, names: [], running: {}, how: "not observed yet", error: "" };
    var seen = null;   // types running at the previous observation (null: none observed yet since load)

    function pol(k, d) {
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {}
        return d;
    }
    function record(what, d) {   // 0.2.13: information only (TK-EV retired, backbone v3.16)
        try { var o = d || {}; o.fact = "event " + what; o.by = "event manager"; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", o); } catch (_) {}
    }
    /* 0.2.13 (D-5): a fill is TK41 buff applying, buff sort "deposit filler", requested by AR20, executed by AR41 */
    function tk41(act, cs, actor, extra) {
        try { var o = { tk: "TK41", act: act, caseId: cs.id, grid: cs.grid, actor: actor, initiator: "construction manager", rule: "R-EV-FILL", buffSort: "deposit filler", event: cs.event }, k;
              for (k in (extra || {})) o[k] = extra[k];
              if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function toList(v) {
        var out = [], i;
        if (!v) return out;
        if (typeof v === "string") return [v];
        try { if (typeof v.forEach === "function") { v.forEach(function (x) { out.push(String(x)); }); return out; } } catch (_) {}
        try { for (i = 0; i < v.length; i++) out.push(String(v[i])); } catch (_) {}
        return out;
    }
    /* 0.2.13: gameEventManager() removed — the location manager reads the game's events (agents 0.4.27, ADR 0040) */
    /* 0.2.1: does a game event name belong to this type? (event.<type>.gameNames, prefixes, case-insensitive) */
    function gameNames(type) {
        var v = pol("event." + type + ".gameNames", null);
        if (v == null || v === "") v = TYPES[type].gameNames;
        return String(v).split(",").map(function (x) { return x.replace(/^\s+|\s+$/g, "").toLowerCase(); }).filter(function (x) { return !!x; });
    }
    function nameCounts(type, name) {
        var n = String(name || "").toLowerCase();
        return gameNames(type).some(function (p) { return n.indexOf(p) === 0; });
    }
    function dateMs(d) { try { if (d == null) return null; if (typeof d === "number") return d; if (d.getTime) return d.getTime(); } catch (_) {} return null; }

    /* the event manager's act: observe the game's running events */
    function visitHold() { try { var C = root.DMA_Control; return !!(C && C.visit && C.visit.held()); } catch (_) { return false; } }   // 0.2.4 (ADR 0030)
    function observe(now) {
        if (visitHold() && state.at) return status();   // 0.2.4: no reading of the game's events during a visit hold
        var t = now == null ? Date.now() : now;
        var pic = null, names = [], dates = {}, running = {}, k;   // 0.2.13: the location manager's events picture (ADR 0040)
        state.at = t; state.error = "";
        try { var D = root.DMA_Demo; pic = D && typeof D.events === "function" ? D.events() : null; } catch (e) { pic = null; state.error = String(e); }
        if (pic && pic.readable) {
            (pic.running || []).forEach(function (e) { names.push(String(e.name)); dates[String(e.name)] = e; });
            state.readable = true; state.how = "the location manager's events picture";
        } else { state.readable = false; state.error = !pic ? "no events picture (location manager)" : ("events picture not readable" + (pic.why ? ": " + pic.why : "")); }
        state.names = names;
        for (k in TYPES) {
            if (!TYPES.hasOwnProperty(k)) continue;
            var ty = TYPES[k];
            if (state.readable) {
                var hit = names.filter(function (n) { var sp = dateMs(dates[n] && dates[n].stop); return nameCounts(k, n) && !(sp && sp <= t); })[0];   // 0.2.14: not after its stop date
                if (hit) {
                    var start = dateMs(dates[hit] && dates[hit].start), stop = dateMs(dates[hit] && dates[hit].stop);
                    running[k] = { name: hit, start: start, stop: stop, observed: true };
                }
            }   // 0.2.14: not readable -> no type runs (the fallback date is no longer assumed; architect on #391)
        }
        if (!state.readable) state.how = "running events could not be read" + (state.error ? " (" + state.error + ")" : "") + "; no event counted as running";
        /* facts: started / stopped, once per change */
        var was = seen || {};
        for (k in running) if (running.hasOwnProperty(k) && !was[k]) record(seen === null ? "observed running" : "started", { type: k, name: running[k].name, observed: running[k].observed });
        for (k in was) if (was.hasOwnProperty(k) && !running[k]) record("stopped", { type: k, name: was[k].name });
        seen = running;
        state.running = running;
        return status();
    }
    function fresh() { if (!state.at || Date.now() - state.at > OBSERVE_MS) observe(); }

    /* the rule set of a type, with the player's overrides (policy event.<type>.buffable: { name: secondsPerUnit }) */
    function ruleSet(type) {
        var ty = TYPES[type];
        if (!ty) return null;
        var over = pol("event." + type + ".buffable", null), out = {}, n;
        for (n in ty.buffable) {
            if (!ty.buffable.hasOwnProperty(n)) continue;
            var s = ty.buffable[n].secondsPerUnit;
            if (over && typeof over === "object" && Number(over[n]) > 0) s = Number(over[n]);
            out[n] = { label: ty.buffable[n].label, secondsPerUnit: s, defaultSecondsPerUnit: ty.buffable[n].secondsPerUnit, unit: ty.unit, event: type };
        }
        return out;
    }
    /* the valid rules: only the types the event manager observes running */
    function buffable(now) {
        if (now != null) observe(now); else fresh();
        var out = {}, k, n;
        for (k in state.running) {
            if (!state.running.hasOwnProperty(k)) continue;
            var rs = ruleSet(k);
            for (n in rs) if (rs.hasOwnProperty(n)) out[n] = rs[n];
        }
        return out;
    }
    function key(name) { return String(name || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }
    function eventOn() { var v = pol("event.auto", false); return v === true || v === "true"; }   // 0.2.8: the Event switch; 0.2.12: default off
    function match(name, now) {
        if (!eventOn()) return null;   // 0.2.8
        var b = buffable(now), k = key(name), n;
        if (!k) return null;
        for (n in b) if (b.hasOwnProperty(n) && key(n) === k) return b[n];
        return null;
    }
    function status() {
        var types = [], k;
        for (k in TYPES) {
            if (!TYPES.hasOwnProperty(k)) continue;
            var r = state.running[k] || null;
            types.push({ type: k, label: TYPES[k].label, gameNames: gameNames(k).join(", "), running: !!r, observed: r ? r.observed : state.readable, name: r ? r.name : "", start: r ? r.start : null, stop: r ? r.stop : null, rules: ruleSet(k) });
        }
        return { version: VERSION, readable: state.readable, how: state.how, at: state.at, gameEvents: state.names.slice(), types: types };
    }


    /* ---------- 0.2.5: filling — part of an event type's rule set ---------- */
    var fillState = { ticks: 0, reason: "", lastRoundAt: {}, rounds: 0, last: null, pending: [], verified: 0, notShown: 0 };   // 0.2.14: pending, verified, notShown
    var VERIFY_FIRST_MS = 20000, VERIFY_MS = 10 * 60000;   // 0.2.14
    function depositAmount(gi, grid) {   // 0.2.14: the deposit at a grid, read again
        var amt = null;
        try { gi.mCurrentPlayerZone.mStreetDataMap.mDepositContainer.forEach(function (d) { try { if (amt === null && d && Number(d.GetGrid()) === Number(grid)) amt = Number(d.GetAmount()); } catch (_) {} }); } catch (_) {}
        return amt == null || isNaN(amt) ? null : amt;
    }
    /* 0.2.14: declare only what is seen (architect on #391) */
    function verifyFills(now) {
        now = now || Date.now();
        var gi = null, keep = [], done = 0;
        try { gi = root.game && root.game.gi; } catch (_) {}
        fillState.pending.forEach(function (pf) {
            var amt = gi ? depositAmount(gi, pf.grid) : null, cs = { id: pf.id, grid: pf.grid, event: pf.event };
            if (amt !== null && amt > pf.before) {
                tk41("declare", cs, "buff applier", { amount: pf.add, seen: amt - pf.before, before: pf.before, after: amt });
                tk41("accept", cs, "construction manager", {});
                fillState.verified += 1; done += 1; return;
            }
            if (now - pf.at >= VERIFY_MS) {
                var why = "the deposit did not grow (" + pf.before + " -> " + (amt === null ? "not readable" : amt) + ")";
                tk41("revoke promise", cs, "buff applier", { reason: why });
                tk41("allow", cs, "construction manager", { revoked: "promise" });
                tk41("decline", cs, "buff applier", { reason: why });
                fillState.notShown += 1; done += 1; return;
            }
            keep.push(pf);
        });
        fillState.pending = keep;
        if (done) fillWrite();
        return { verified: fillState.verified, notShown: fillState.notShown, pending: keep.length };
    }
    function fvec(v) { var out = [], i; if (!v) return out; try { for (i = 0; i < v.length; i++) out.push(v[i]); } catch (_) {} return out; }
    function fillWrite() {
        try { var A = root.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-fill-status.json").nativePath), st = new A.FileStream();
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(fillState, null, 1)); st.close(); } catch (_) {}
    }
    function fillWhy(r) { if (fillState.reason !== r) { fillState.reason = r; fillWrite(); } return { ok: false, reason: r }; }
    /* pure: items [{grid, amount, sec, limit}], f units -> [{grid, add}] for equal hours of cover, never above a limit */
    function spread(items, f) {
        function addAt(hours) { return items.map(function (c) { var want = Math.min(c.limit, Math.max(c.amount, Math.floor(hours * 3600 / c.sec))); return Math.max(0, want - c.amount); }); }
        function sum(a) { return a.reduce(function (x, y) { return x + y; }, 0); }
        var lo = 0, hi = 1, i;
        while (sum(addAt(hi)) < f && hi < 1e7) { if (sum(addAt(hi)) === sum(addAt(hi * 2))) break; hi *= 2; }
        for (i = 0; i < 60; i++) { var mid = (lo + hi) / 2; if (sum(addAt(mid)) <= f) lo = mid; else hi = mid; }
        var adds = addAt(lo), left = f - sum(adds), order = items.map(function (c, k) { return k; });
        while (left > 0) {
            order.sort(function (a, b) { return (items[a].amount + adds[a]) * items[a].sec - (items[b].amount + adds[b]) * items[b].sec; });
            var given = false;
            for (i = 0; i < order.length && left > 0; i++) { var k = order[i]; if (items[k].amount + adds[k] < items[k].limit) { adds[k] += 1; left -= 1; given = true; break; } }
            if (!given) break;
        }
        return items.map(function (c, k) { return { grid: c.grid, add: adds[k] }; }).filter(function (x) { return x.add > 0; });
    }
    function fillTick(now) {
        now = now || Date.now(); fillState.ticks += 1;
        try { if (fillState.pending.length) verifyFills(now); } catch (_) {}   // 0.2.14: also with the switch off
        if (!eventOn()) return fillWhy("Event switch off (event.auto)");   // 0.2.8
        var C = root.DMA_Control, gi = null;
        try { if (C && typeof C.atHome === "function" && !C.atHome()) return fillWhy("not on the home island"); } catch (_) {}
        try { if (C && C.visit && C.visit.held()) return fillWhy("visit hold"); } catch (_) {}
        try { gi = root.game && root.game.gi; } catch (_) {}
        if (!gi) return fillWhy("game not ready");
        var out = { ok: false, reason: "no running event type fills" };
        Object.keys(TYPES).forEach(function (k) {
            var ty = TYPES[k], fl = ty.fill, r = state.running[k];
            if (!fl || !r) return;
            if (pol("event." + k + ".fill.on", true) === false) { out = fillWhy(ty.label + ": filling switched off (event." + k + ".fill.on)"); return; }
            var every = (Number(pol("event." + k + ".fill.everyMin", fl.everyMin)) || 30) * 60000;
            if (fillState.lastRoundAt[k] && now - fillState.lastRoundAt[k] < every) { out = { ok: false, reason: "waits for the next round" }; return; }
            var re = new RegExp(fl.match, "i"), stack = 0, uid = null, total = 0;
            try { fvec(gi.mCurrentPlayer.getAvailableBuffs_vector()).forEach(function (b) {
                try { var nm = String(b.GetBuffDefinition().GetName_string()), rn = ""; try { rn = String(b.GetResourceName_string() || ""); } catch (_) {}
                      if (nm.indexOf(fl.buffPrefix) === 0 && re.test(rn + nm)) { var a = Number(b.GetAmount()) || 0; total += a; if (a > stack) { stack = a; uid = b.GetUniqueId(); } } } catch (_) {}
            }); } catch (_) {}
            var minB = Number(pol("event." + k + ".fill.minBatch", fl.minBatch)) || 1;
            if (stack < minB || !uid) { out = fillWhy(ty.label + ": " + total + " " + (ty.unit || "") + " of filler in the star (fills from " + minB + ")"); return; }
            if (!r.stop || r.stop <= now) { out = fillWhy(ty.label + ": end of the event unknown"); return; }
            var rateX = Number(pol("event." + k + ".fill.rateX", fl.rateX)) || 1, hours = (r.stop - now) / 3600000, sd = gi.mCurrentPlayerZone.mStreetDataMap, items = [], rules = ruleSet(k);
            try { sd.mDepositContainer.forEach(function (d) {
                try { if (!d || !re.test(String(d.GetName_string()))) return;
                      var grid = d.GetGrid(), b = sd.GetBuildingByGridPos(grid), bn = b ? String(b.GetBuildingName_string()) : "", m = bn ? match(bn, now) : null;
                      if (!m || !m.secondsPerUnit) return;
                      var sec = Number(m.secondsPerUnit) / rateX;   // 0.2.7: GetMaxAmount is the original size (45/80/100), not a cap
                      items.push({ grid: grid, name: bn, amount: Number(d.GetAmount()) || 0, sec: sec, limit: Math.floor(hours * 3600 / sec) });
                } catch (_) {}
            }); } catch (_) {}
            if (!items.length) { out = fillWhy(ty.label + ": no buildings to fill found"); return; }
            var plan = spread(items, stack);
            if (!plan.length) { out = fillWhy(ty.label + ": every building is at its limit"); return; }
            fillState.lastRoundAt[k] = now;
            var before = {}; items.forEach(function (it) { before[it.grid] = it.amount; });   // 0.2.14
            var CM = null; try { CM = root.DMA_ConstructionManager; if (!(CM && typeof CM.check === "function" && CM.check() && typeof CM.requestFills === "function")) CM = null; } catch (_) { CM = null; }   // 0.3.0: AR20 requests the fills when it is ready
            if (CM) {
                CM.requestFills({ type: k, event: k, plan: plan, uid: uid, before: before, now: now, report: {
                    verified: function () { fillState.verified += 1; fillWrite(); }, notShown: function () { fillState.notShown += 1; fillWrite(); },
                    revoked: function (why) { fillState.lastRoundAt[k] = 0; fillState.reason = "waits: " + why; } } });
            } else plan.forEach(function (p, i) {
                var cs = { id: "fill@" + p.grid + "@" + now, grid: p.grid, event: k };
                tk41("request", cs, "construction manager", { amount: p.add, reason: "needs filling (DFS-45)" });   // 0.2.13
                var tries = 0;
                var send = function () {
                    var r, A = root.GCAF_GameInterface;   // 0.2.15 (ADR 0073): the adapter owns the send
                    if (!A) { tk41("decline", cs, "buff applier", { reason: "game interface adapter not loaded" }); return; }
                    try { r = A.sendAction("EVENT_FILL", 0, p.grid, p.add, uid); }
                    catch (e) { fillState.reason = "send failed: " + e; tk41("decline", cs, "buff applier", { reason: "send failed: " + e }); return; }
                    if (r && !r.ok && r.retry) {   // 0.2.16: transient — wait, do not decline
                        tries += 1;
                        if (tries < 5 && !root.DMA_EVENT_NO_TIMER && typeof root.setTimeout === "function") { root.setTimeout(send, 1500); return; }
                        tk41("revoke request", cs, "construction manager", { reason: r.reason }); fillState.lastRoundAt[k] = 0; fillState.reason = "waits: " + r.reason; return;
                    }
                    if (!r || !r.ok) { tk41("decline", cs, "buff applier", { reason: (r && r.reason) || "no answer from the adapter" }); return; }
                    tk41("promise", cs, "buff applier", {}); tk41("execute", cs, "buff applier", { amount: p.add });
                    /* 0.2.14: the client took the send — not proof; declare when the deposit is seen to grow */
                    fillState.pending.push({ id: cs.id, grid: p.grid, event: k, add: p.add, before: before[p.grid] || 0, at: now });
                    if (!root.DMA_EVENT_NO_TIMER && typeof root.setTimeout === "function") root.setTimeout(function () { try { verifyFills(); } catch (_) {} }, VERIFY_FIRST_MS);
                };
                if (i === 0 || root.DMA_EVENT_NO_TIMER || typeof root.setTimeout !== "function") send(); else root.setTimeout(send, i * 3000);
            });
            var placed = plan.reduce(function (x, p) { return x + p.add; }, 0);
            fillState.rounds += 1; fillState.last = { type: k, at: new Date(now).toISOString(), fillers: total, stack: stack, placed: placed, plan: plan };
            fillState.reason = ty.label + ": placed " + placed + " " + (ty.unit || "") + " on " + plan.length + " buildings"; fillWrite();
            record("filled", { type: k, placed: placed, buildings: plan.length });   // 0.2.13: information; the facts are the TK41 cases
            out = { ok: true, reason: fillState.reason, plan: plan };
        });
        return out;
    }
    try { if (!root.DMA_EVENT_NO_TIMER && typeof root.setInterval === "function") root.setInterval(function () { try { observe(); } catch (_) {} try { fillTick(); } catch (_) {} }, OBSERVE_MS); } catch (_) {}   // 0.2.5: fill after observe

    function buffActionOf(type) {   // 0.2.17: the registered BUFF ACTION of the event type (docs/05-ontology/dma/facts/buff-actions.yaml, owned by the adapter)
        try { var A = root.GCAF_GameInterface, l = A && typeof A.buffActions === "function" ? A.buffActions() : []; for (var i = 0; i < l.length; i++) if (l[i].event === type) return l[i]; } catch (_) {}
        return null;
    }
    /* 0.2.2: the counters of the running types, with the player's rules event.<type>.<counter>.on / .when / .give */
    function counters(now) {
        if (now != null) observe(now); else fresh();
        var out = [], k, c;
        if (!eventOn()) return out;   // 0.2.8
        for (k in state.running) {
            if (!state.running.hasOwnProperty(k) || !TYPES[k].counters) continue;
            for (c in TYPES[k].counters) {
                if (!TYPES[k].counters.hasOwnProperty(c)) continue;
                var d = TYPES[k].counters[c], base = "event." + k + "." + c + ".";
                if (d.fact) { var fx = buffActionOf(k); if (!fx) continue; d = { when: fx.acted_on, give: fx.acting, on: d.on, label: d.label }; }   // 0.2.17: the pair comes from the facts, not from a table typed here
                var on = pol(base + "on", null); on = on == null ? d.on : on === true;
                if (!on) continue;
                out.push({ event: k, counter: c, when: String(pol(base + "when", d.when)), give: String(pol(base + "give", d.give)), label: d.label });
            }
        }
        return out;
    }

    /* 0.2.9: the parts of a type, each with its switch, executor and state */
    function parts(type, globals) {
        var T = TYPES[type]; if (!T || !T.parts) return [];
        var g = globals || root;
        return T.parts.map(function (p) {
            var rule = p.rule || ("event." + type + "." + p.id + ".on"), d = p.dflt == null ? true : p.dflt;
            var v = pol(rule, null), on = v == null ? d : v === true;
            var has = p.uses.length > 0 && p.uses.every(function (n) { try { return !!g[n]; } catch (_) { return false; } });
            var st = !eventOn() || !on ? "off" : (has ? "auto" : "needs you");
            return { id: p.id, label: p.label, actor: p.actor, rule: rule, on: on, executor: has, state: st };
        });
    }
    var partsJson = "";
    function partsWrite() {
        try {
            var out = { format: "dma-event-parts/1", version: VERSION, types: {} }, k;
            for (k in state.running) if (state.running.hasOwnProperty(k)) out.types[k] = parts(k);
            var j = JSON.stringify(out); if (j === partsJson) return; partsJson = j;
            out.at = new Date().toISOString();
            var A = root.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-event-parts.json").nativePath), st = new A.FileStream();
            st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(out, null, 1)); st.close();
        } catch (_) {}
    }
    try { if (!root.DMA_EVENT_NO_TIMER && typeof root.setInterval === "function") root.setInterval(function () { try { partsWrite(); } catch (_) {} }, OBSERVE_MS); } catch (_) {}

    root.DMA_Event = {
        parts: parts,                                                      // 0.2.9
        counters: counters,
        version: VERSION,
        on: eventOn,                                                       // 0.2.8
        observe: observe,
        status: status,
        ruleSet: ruleSet,
        buffable: buffable,
        match: match,
        fill: { tick: fillTick, spread: spread, verify: verifyFills,   // 0.2.14: verify
                status: function () { return JSON.parse(JSON.stringify(fillState)); } },   // 0.2.5
        events: function () { fresh(); return JSON.parse(JSON.stringify(status().types.filter(function (t) { return t.running; }))); }
    };
})(typeof window !== "undefined" ? window : this);
