/*
 * user_dma_premium.js — Premium Keeper 0.1.7. DEMO: TK41 buff applying ("[buff] is applied"), a zone buff whose scope is
 * every construction of the island (ADR 0056), initiated by AR20 construction manager under R-ZONE-REPLACE (ADR 0026),
 * executed by AR41 buff applier — the names as the backbone (dist/dma-ontology.json) has them.
 *
 * 0.1.7 (2026-11-16, tester batch on ADR 0073; coordinator): (1) the premium buff is an island-wide zone buff: apply passes ctx { zoneBuff: true }
 *   to the adapter, which exempts it from the building guard that adapter 0.2.1 puts on every action-61 send that targets a
 *   building. (2) premium reads refusal.retry: a transient refusal (a hold, the pace) is not a decline — the initiator revokes its
 *   request ("revoke request", reason = the adapter's), the case is closed without an extension and the 15-minute request gap is
 *   cleared, so the next tick asks again; a hard refusal still declines with the adapter's reason.
 *   Unit: tests/unit/premium-with-control.test.js (a retry refusal: revoke request, no decline, the next tick sends).
 * 0.1.6 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C5 of the migration): premium does not send itself
 *   and no longer touches control's permit (0.1.4's permit("buff") calls are gone): the gateway's apply sends through the Game
 *   Interface Adapter, GCAF_GameInterface.sendAction("STAR_ITEM", 0, mayor-house grid, 0, unique id) — the premium buff is a zone
 *   buff of the whole island (ADR 0056), not a buff on a building, so the adapter's building guard (verified kind, never
 *   buffed) does not apply; start-up and visit holds, pace per class and control's permit (opened for the one call) do (ADR 0073
 *   open point: STAR_ITEM, not APPLY_BUFF). The promise is recorded only on ok; a refusal declines with the adapter's reason
 *   (G.refusal()), no adapter = "game interface adapter not loaded". Unit: tests/unit/dma-premium.test.js (a refusal -> decline
 *   with the reason). Integration: tests/unit/premium-with-control.test.js (real control + adapter + premium: one 61 reaches the
 *   server, the permit is closed again, premium holds no permit call).
 * 0.1.5 (2026-11-16, backbone v3.16 D-2 (AT72 the premium setting, VT23: off · always · during an event; DFS-41
 *   premium is due) and its addendum (model PR #384: "during an event" means any running event); policy 0.2.60 (#380)):
 *   premium follows the three-valued premium setting instead of the boolean premium.autoExtend:
 *     "off"    — never extends (the default: everything off for a new player; the author sets his own at deploy);
 *     "always" — extends when premium has ended (as before);
 *     "event"  — extends when premium has ended AND an event is running (any event), read from the location manager's
 *                events picture (DMA_Demo.anyEventRunning, agents 0.4.27; ADR 0040). Without that picture: no extension.
 *   A policy older than 0.2.60 has no premium.setting: then premium.autoExtend true means "always". The config file's
 *   {"autoExtend": false} still switches it off. Nothing else changes.
 *   Unit: tests/unit/dma-premium.test.js (+ each setting; "event" with and without a running event; no picture; the
 *   legacy key). Integration: tests/integration/dma-premium-tx.test.js (+ the setting "event" with the events picture:
 *   no extension while no event runs, one TK41 accepted when one runs, through the real control).
 * 0.1.4 (2026-11-16, tester re-run 2026-11-16 (report §9 on main; comment on #361): FAIL — known-failing
 *   kf-premium-with-control): control's SendServerAction wrapper lets action 61 through only while permit("buff") is open,
 *   and premium never opened it, so with the real control loaded every extension was refused ("the client refused the
 *   send") and never reached the server. The gateway's apply now opens DMA_Control.permit("buff") right before the send
 *   and closes it right after — also when the send throws — as the buff manager does. Without control loaded nothing
 *   changes. The promise still follows only a send the client took (0.1.3).
 *   Unit: tests/unit/premium-with-control.test.js (the tester's test, moved from tests/known-failing: with the real
 *   control loaded one action 61 reaches the mayor house and the case is promised). Integration:
 *   tests/integration/dma-premium-tx.test.js now loads the real control beside the policy, the C-fact memory and premium:
 *   the extension reaches the server through control's wrapper, the TK41 case ends accepted, the permit is closed
 *   again afterwards, and a send the wrapper refuses (permit kept closed) is still a decline without a promise.
 * 0.1.3 (2026-11-16, tester report 2026-11-16 (PR #373) on proposal #361, item D11): a send the client refuses —
 *   control's SendServerAction wrapper answers false (safeguard, permit closed) without throwing — was recorded as
 *   "promise" and ended as "lost" 10 min later. The buff applier now promises only for a send the client took: the
 *   send is tried first (its implementation), then promise on success; a refused send is a decline "the client refused
 *   the send", a throwing send a decline "send failed: …". No promise is ever recorded for a refused send, so the
 *   revoke promise / allow pair of 0.1.2 is gone. The gateway's apply returns what the game answered.
 *   Unit: tests/unit/dma-premium.test.js (refused -> request, decline; throws -> request, decline; neither records a
 *   promise). Integration: tests/integration/dma-premium-tx.test.js (+ with a SendServerAction that answers false,
 *   the TK41 instance ends declined, never promised, and nothing is "lost").
 * 0.1.2 (2026-11-16, architecture review 2026-11-16 finding #5 (High; F1), #8 (ADR 0040), #12/§5.2, #17):
 *   (#5) 0.1.1 recorded one act "ex" under TK75. "ex" is no DEMO act and TK75 is collectible managing in the backbone,
 *   so the memory counted it foreign and no transaction existed. Premium extension is now recorded as TK41 buff applying
 *   with the full pattern, one case per extension (caseId "premium@<ms>"):
 *     request (construction manager: premium has ended and the gap since the last request is 15 min, R-ZONE-REPLACE)
 *     -> promise (buff applier: an item is in the star and a mayor house exists; then APPLY_BUFF 61, its implementation)
 *        | decline (buff applier: "an extension is waiting for the server" | "no premium item in the star" | "no mayor house")
 *     -> declare (buff applier, observed: the picture's premium end moved past the end at the request and lies ahead)
 *     -> accept (construction manager).
 *     A send the client refuses or that throws: decline (buff applier, why) — never a promise (0.1.3).
 *     No declare within 10 min: revoke request (construction manager) -> allow (buff applier); the case is void — as
 *     TK41's "lost" rule in ADR 0038 step 2.
 *   MODELLING DECISION FOR THE AUTHOR: premium as a TK41 zone buff follows ADR 0026 (Love Tree, a zone buff, belongs to
 *   the buff manager and is recorded as TK41) and ADR 0056 (a zone buff is a buff whose scope is a set of construction);
 *   no new transaction kind is introduced. The alternative — a premium transaction kind of its own in the backbone — is [O].
 *   (#8, ADR 0040) The manager no longer reads the game: "at home" is the location manager's DMA_Control.atHome(); the
 *   premium end is read from the location manager's picture DMA_Demo.premium() {at, until} (proposed for agents 0.4.26).
 *   Without that picture the manager waits ("no picture"), as the troop manager does. The buff applier reads the star
 *   and the mayor house only at the moment it acts — its truth clauses (ADR 0040 §3).
 *   (#12) premium.autoExtend falls back to OFF when no policy answers (policy 0.2.58 registers it, default off).
 *   (#17) The header no longer calls the executing role "green": the buff applier is original production (O).
 *   Unit: tests/unit/dma-premium.test.js (rewritten on a gateway: the TK41 pattern per path, no act outside DEMO 4).
 *   Integration: tests/integration/dma-premium-tx.test.js (premium + the C-fact memory + the real policy: off by default;
 *   switched on, one extension is one TK41 instance that ends accepted; nothing foreign; no TK75 written).
 *
 * 0.1.1 (2026-11-03, author: "premium is not on ... what is going on?"): premium had lapsed — 0.1.0 was withdrawn on
 *   2026-10-26 (extend by hand), the author then asked (same day) for one 1-day star item every day right after the old
 *   one has run out, "never on top of running premium"; that was kept by a scheduled task that no longer exists. Back as
 *   this module, with the author's rule: leadMinutes defaults to 0 — an item is applied only once premium has ENDED
 *   (no stacking), the shortest star item first (the 1-day gifts). Off switch unchanged (dma-premium-config.json
 *   {"autoExtend": false} or policy premium.autoExtend false). Unit: tests/unit/dma-premium.test.js; integration: live,
 *   dma-premium.json shows premiumUntil about one day ahead within a minute after the old premium ended.
 *
 * 0.1.0 (2026-10-26; author 13:36 Dubai: "make sure premium is extended as soon as it has run out" — "you can find it in
 *   the star"). Read from client.swf (2026-10-26):
 *   - the premium end is cPlayerData.GetPremiumUntil() (epoch ms); hasActivePremiumAccount() is premiumUntil > now;
 *   - a premium item in the star is a cBuff whose GetType() starts with "PremiumAccount" (defines.PREMIUM_ACCOUNT_BUFF);
 *     the star menu opens cPremiumAccountActivationWindow, whose accept button sends
 *     SendServerAction(APPLY_BUFF 61, 0, <grid of the mayor house>, 0, buff.GetUniqueId()) and marks the buff waiting;
 *   - cBuff applying a PremiumAccount buff sets the new end to premiumUntil + duration when premium is still running, so
 *     extending a few minutes before the end loses nothing.
 *   P-1 WATCH (read only, every minute): premiumUntil, minutes left, and the premium items in the star (name, duration in
 *     days, count) → dma-premium.json.
 *   P-2 EXTEND: when fewer than leadMinutes (default 5) are left, or premium has ended, apply ONE premium item from the
 *     star — the shortest one first, so no long item is spent when a short one does — through the game's own accept path.
 *     Only star items: there is no shop and no gem path in this module. At most one extension per 15 minutes, and none
 *     while the previous one is still waiting for the server. Only on the home island, behind premium.autoExtend
 *     (policy; default off since 0.1.2) and dma-premium-config.json {"autoExtend": false} as the player's off switch.
 *
 * DEMO (0.1.2): the construction manager initiates and the buff applier executes TK41 on the player's standing
 * instruction (premium.autoExtend); the player stays accountable. 0.1.0/0.1.1 wrote "the premium agent (green) executes
 * TK75" — corrected above.
 */
(function (root) {
    "use strict";
    if (root.DMA_Premium && root.DMA_Premium.version) return;
    var VERSION = "0.1.7", TICK_MS = 60000, PREFIX = "PremiumAccount", GAP_MS = 15 * 60000, LOST_MS = 10 * 60000;
    var INIT = "construction manager", EXEC = "buff applier", RULE = "R-ZONE-REPLACE";

    /* ---------------- gateway: picture, executor's reads, files, facts (replaced in the tests) ---------------- */
    function gameGateway() {
        var R = root, refusal = null;   // 0.1.6: the adapter's answer to the last refused send
        function gi() { return R.game.gi; }
        function airApi() { try { return (typeof air !== "undefined") ? air : R.air; } catch (_) { return R.air || null; } }
        function uid(b) { try { var u = b.GetUniqueId(); return u.uniqueID1 + "_" + u.uniqueID2; } catch (_) { return ""; } }
        function days(b) { try { return Number(b.GetBuffDefinition().getDuration(0)); } catch (_) { return null; } }   // BUFF_APPLIANCE_MODE.PLAYER = 0
        return {
            now: function () { return Date.now(); },
            /* the location manager's facts (ADR 0040) */
            atHome: function () { try { var C = R.DMA_Control; return !!(C && typeof C.atHome === "function" && C.atHome()); } catch (_) { return false; } },
            picture: function () { try { var D = R.DMA_Demo; return D && typeof D.premium === "function" ? D.premium() : null; } catch (_) { return null; } },
            /* 0.1.5: "an event is running" from the location manager's events picture; undefined = no picture */
            eventRunning: function () { try { var D = R.DMA_Demo; if (!D || typeof D.anyEventRunning !== "function" || typeof D.events !== "function" || !D.events()) return undefined; return !!D.anyEventRunning(); } catch (_) { return undefined; } },
            rule: function (k, d) { try { var p = R.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); return v == null ? d : v; } } catch (_) {} return d; },
            /* the buff applier's reads at the moment of acting (truth clauses, ADR 0040 §3) */
            starItems: function () {
                var out = [], menu, i, b, t;
                try { menu = gi().mCurrentPlayer.getBuffsSortedForStarMenu() || []; } catch (_) { menu = []; }
                for (i = 0; i < menu.length; i++) {
                    b = menu[i];
                    try { t = String(b.GetType()); } catch (_) { continue; }
                    if (t.indexOf(PREFIX) !== 0) continue;
                    out.push({ buff: b, type: t, id: uid(b), days: days(b), count: b.GetAmount ? Number(b.GetAmount()) : 1,
                               waiting: !!(b.GetWaitingForServer && b.GetWaitingForServer()), exhausted: !!b.IsExhausted });
                }
                out.sort(function (x, y) { return (x.days == null ? 1e9 : x.days) - (y.days == null ? 1e9 : y.days); });
                return out;
            },
            mayorGrid: function () { try { var m = gi().mCurrentPlayerZone.mStreetDataMap.GetMayorHouse(); return m ? m.GetGrid() : null; } catch (_) { return null; } },
            apply: function (grid, item) {   // 0.1.6 (ADR 0073): through the adapter; false = refused, the reason is in refusal()
                var A = R.GCAF_GameInterface, r;
                refusal = null;
                if (!A) { refusal = { reason: "game interface adapter not loaded" }; return false; }
                r = A.sendAction("STAR_ITEM", 0, grid, 0, item.buff.GetUniqueId(), { zoneBuff: true });
                if (!r || !r.ok) { refusal = { reason: (r && r.reason) || "no answer from the adapter", retry: !!(r && r.retry) }; return false; }
                try { item.buff.IncWaitingForServerCount(gi()); } catch (_) {}
                return true;
            },
            refusal: function () { return refusal; },
            fileRead: function (name) {
                try {
                    var a = airApi(); if (!a) return R.__DMA_PREMIUM_FILES ? R.__DMA_PREMIUM_FILES[name] || null : null;
                    var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
                    if (!f.exists) return null;
                    var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close();
                    return JSON.parse(t);
                } catch (_) { return null; }
            },
            fileWrite: function (name, obj) {
                try {
                    var a = airApi(); if (!a) { if (R.__DMA_PREMIUM_FILES) R.__DMA_PREMIUM_FILES[name] = JSON.parse(JSON.stringify(obj)); return true; }
                    var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
                    var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true;
                } catch (_) { return false; }
            },
            record: function (kind, data) { try { if (R.DMA_Demo && R.DMA_Demo.record) R.DMA_Demo.record(kind, data); } catch (_) {} }
        };
    }

    function createManager(G) {
        G = G || gameGateway();
        var old = G.fileRead("dma-premium.json") || {};
        var state = { lastError: "", lastRequestAt: 0, extensions: old.extensions || [], open: old.open || null, last: "" };
        function note(s) { state.lastError = String(s).slice(0, 300); }
        function c(act, cs, actor, extra) {
            var o = { tk: "TK41", act: act, caseId: cs.id, actor: actor, what: "premium", initiator: INIT, rule: RULE, grid: cs.grid }, k;
            for (k in (extra || {})) o[k] = extra[k];
            G.record("c", o);
        }
        function enabled() {
            var cf = G.fileRead("dma-premium-config.json");
            if (cf && cf.autoExtend === false) return false;
            var set = G.rule("premium.setting", null);   // 0.1.5: AT72 off | always | event
            if (set == null || set === "") { var v = G.rule("premium.autoExtend", false); set = (v === true || v === "true") ? "always" : "off"; }   // a policy before 0.2.60
            set = String(set).toLowerCase();
            if (set === "always") return true;
            if (set === "event") return typeof G.eventRunning === "function" && G.eventRunning() === true;   // any running event (model PR #384)
            return false;
        }
        function lead() { var cf = G.fileRead("dma-premium-config.json"); var m = cf && Number(cf.leadMinutes); return m >= 0 && m < 1440 ? m : 0; }   // 0.1.1: 0 = only after premium has ended
        function due(u, now) { return !u || (u - now) <= lead() * 60000; }   // lead 0: u <= now, never on top of running premium
        function done(cs, end) { cs.end = end; state.extensions.push(cs); if (state.extensions.length > 50) state.extensions.shift(); state.open = null; }

        /* the buff applier: truth clauses at the moment of acting, then promise and the send */
        function execute(cs) {
            var list = G.starItems(), pick = null, i, grid;
            if (list.some(function (x) { return x.waiting; })) { c("decline", cs, EXEC, { reason: "an extension is waiting for the server" }); done(cs, "declined"); return "declined"; }
            for (i = 0; i < list.length; i++) { if (!list[i].exhausted && list[i].count > 0) { pick = list[i]; break; } }
            if (!pick) { c("decline", cs, EXEC, { reason: "no premium item in the star" }); done(cs, "declined"); return "declined"; }
            grid = G.mayorGrid();
            if (grid == null) { c("decline", cs, EXEC, { reason: "no mayor house" }); done(cs, "declined"); return "declined"; }
            cs.grid = grid; cs.type = pick.type; cs.days = pick.days;
            var took;
            try { took = G.apply(grid, pick); } catch (e) { note("extend " + e); c("decline", cs, EXEC, { reason: "send failed: " + e }); done(cs, "declined"); return "declined"; }
            if (took === false && G.refusal && G.refusal() && G.refusal().retry) {   // 0.1.7: transient — ask again next tick
                var rt = G.refusal(); note("extend waits: " + rt.reason); c("revoke request", cs, INIT, { reason: rt.reason }); state.open = null; state.lastRequestAt = 0; return "waits: " + rt.reason;
            }
            if (took === false) { var rf = (G.refusal && G.refusal()) || null; note("extend refused: " + ((rf && rf.reason) || "by the client")); c("decline", cs, EXEC, { reason: (rf && rf.reason) || "the client refused the send" }); done(cs, "declined"); return "declined"; }   // 0.1.3; 0.1.6: the adapter's reason
            c("promise", cs, EXEC, { type: pick.type, days: pick.days });   // 0.1.3: only for a send the client took
            cs.sentAt = G.now(); return "promised";
        }
        function tick() {
            var now = G.now(), pic, cs = state.open, r = "ok";
            if (!G.atHome()) { r = "away"; }
            else if (!(pic = G.picture())) { r = "no picture"; }
            else if (cs) {
                var u = Number(pic.until) || 0;
                if (u > now && u > (Number(cs.before) || 0)) { c("declare", cs, EXEC, { until: new Date(u).toISOString(), observed: true }); c("accept", cs, INIT, {}); cs.after = u; done(cs, "accepted"); r = "accepted"; }
                else if (now - cs.at >= LOST_MS) { c("revoke request", cs, INIT, { reason: "premium not extended within 10 min" }); c("allow", cs, EXEC, { tacit: true }); done(cs, "voided"); r = "voided"; }
                else r = "waiting";
            } else if (!enabled()) { r = "off"; }
            else if (due(Number(pic.until) || 0, now) && now - state.lastRequestAt >= GAP_MS) {
                cs = state.open = { id: "premium@" + now, at: now, before: Number(pic.until) || 0, grid: null };
                state.lastRequestAt = now;
                c("request", cs, INIT, { before: cs.before ? new Date(cs.before).toISOString() : null });
                r = execute(cs);
            }
            state.last = r;
            G.fileWrite("dma-premium.json", status(pic));
            return r;
        }
        function status(pic) {
            var u = pic ? Number(pic.until) || 0 : 0, now = G.now();
            return { format: "dma-premium/2", version: VERSION, savedAt: new Date(now).toISOString(), lastError: state.lastError, last: state.last,
                     premiumUntil: u ? new Date(u).toISOString() : null, minutesLeft: u ? Math.round((u - now) / 60000) : null,
                     autoExtend: enabled(), leadMinutes: lead(), open: state.open, extensions: state.extensions };
        }
        return { tick: tick, due: function (u) { return due(u, G.now()); }, status: function () { return status(G.picture()); }, state: function () { return state; } };
    }

    var mgr = null;
    function start() {
        if (root.DMA_PREMIUM_NO_TIMER || typeof setInterval !== "function") return;
        mgr = createManager();
        setTimeout(function () { try { mgr.tick(); } catch (_) {} }, 20000);
        setInterval(function () { try { mgr.tick(); } catch (_) {} }, TICK_MS);
    }
    root.DMA_Premium = { version: VERSION, createManager: createManager, gameGateway: gameGateway,
                         tick: function () { return (mgr || (mgr = createManager())).tick(); },
                         status: function () { return (mgr || (mgr = createManager())).status(); } };
    start();
})(typeof window !== "undefined" ? window : this);
