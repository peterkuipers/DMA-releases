/*
 * user_dma_camp_solver.js — the cheapest way to take one camp with the player's own generals (PBC adventure management,
 * ADR 0094 step A)
 * 0.3.0 (2026-11-23, author: "Naast minste verliezen, etc. Heb je dus ook de kortste tijd om het verlies weer op te bouwen"; model
 *   cross-checked with tsowikipro.bytespoiler.de ?tab=rebuild): objective quickestRebuild — the time to train the losses again.
 *   The Barracks and the Elite Barracks train side by side, so the rebuild is the longer of the two queues: per queue the sum of
 *   lost x the unit's production time (the game's, unit facts) / that barracks' speed (o.barracks {regular, elite}, default 1;
 *   the caller derives it from the barracks' level), net of the general's resurrection. o.rebuildBase {regular, elite} carries
 *   the queues of the camps planned before, so the camp's choice is judged on the whole adventure's rebuild. metrics gain
 *   rebuildRegular, rebuildElite, rebuild (seconds). Unit: tests/unit/dma-camp-solver.test.js (case 7).
 * 0.2.1 (2026-11-22, live ToW): opts.maxWaves 0 means no wave tier (it was only applied to the 1R tier).
 *   Unit: tests/unit/dma-camp-solver.test.js.
 * 0.2.0 (2026-11-22, ADR 0094 addendum 10:47; author: "dan krijg je de beperkingen van het avontuur en de settings van de
 *   speler, zo snel mogelijk, zo min mogelijk verliezen, bepaalde troepen die je perse niet wil verliezen ... meerdere versies:
 *   snelste, minste verliezen, best geschikt voor multiple run, meeste XP ... quest, doe een avontuur en verlies minder dan x
 *   van troeptype y"): OBJECTIVES — author (the tier order, then cheapest), cheapest, fewestLosses, fastest (battle rounds x
 *   20 s x 100 / time bonus), spareGenerals (fewest generals beaten, for multiple runs), mostXP (enemy xp x the general's
 *   CombatXP); opts.objective ranks; any objective other than author weighs every tier. opts.avoid {unit: weight} keeps a
 *   unit type out where possible (a quest "lose fewer than x of y"). Every option carries its metrics; the best five are
 *   returned as options. Unit: tests/unit/dma-camp-solver.test.js (cases 5-6).
 * 0.1.1 (2026-11-22, ADR 0094 step B): opts.tiers limits the tiers tried (e.g. ["1R", "main"]: a camp without a wave, so
 *   no general is beaten); a tier left out is not taken even when it passes. Unit: tests/unit/dma-camp-solver.test.js (case 4).
 * 0.1.0 (2026-11-22, ADR 0094 addendum 09:15; author: "Ik bereken per kamp hoe het verslagen kan worden met mijn generals. Met 1
 *   of 2 1R attacks, de map mode die het betekend voor alle kampen met alleen een hoofdaanval en tot slot de kampen die
 *   overblijven of ze te verslaan zijn met een wave attack ... Uiteindelijk willen we een oplossing in scripts, dus zonder
 *   TSOS."): the author's order, as tiers — the first tier with a solution decides:
 *     1. "1R"    one or two generals with 1 Recruit each take the camp (the generals' own strike);
 *     2. "main"  one general alone (a main attack), its army searched: a core type at capacity, with 0-50 % Swordsmen (or
 *                Recruits when elite units may not go) as fodder;
 *     3. "waves" one or two wave attacks (1 Recruit, or a wave type at full capacity) that damage the camp, then one main.
 *   A solution passes when the camp falls in at least minWin of the battles and, in the bad case (quantile), no attacker
 *   loses a unit type its role may not lose (main: mainMayLose; wave: waveMayLose). Cost: the mean loss, valued by the unit's
 *   production time (or the caller's unitCost) and net of the general's resurrection. Every option names its generals; the
 *   caller (user_dma_mundane_gen.js) decides who is free. Screening with few battles first, the best verified with all.
 *   Pure: facts (DMA_BattleSim.Facts) and the simulator are passed in; no game call.
 *   Unit expectation:        tests/unit/dma-camp-solver.test.js — a camp a lone general takes with 1R is solved in tier 1;
 *                            a camp that needs a wave gets tier 3 with the main losing only Recruits/Swordsmen in the bad case.
 *   Integration expectation: tests/integration/dma-mundane-gen-bb.test.js (camps the author's attackers cannot take with the
 *                            player's generals go through this solver).
 */
(function (root) {
    "use strict";
    var VERSION = "0.3.0";
    var DEFAULTS = { iterations: 200, screen: 20, minWin: 0.99, quantile: 0.95, maxWaves: 2, mainBuilds: 4, waveBuilds: 3, verifyTop: 3,
                     mainMayLose: ["Recruit", "Swordsman"], waveMayLose: ["Recruit", "Swordsman", "Bowman", "Cavalry", "Knight"], eliteUnits: true };
    var BASE_UNITS = ["Recruit", "Bowman", "Militia", "Cavalry", "Longbowman", "Soldier", "Crossbowman", "EliteSoldier", "Cannoneer"];
    var ELITE_UNITS = ["Swordsman", "MountedSwordsman", "Knight", "Marksman", "ArmoredMarksman", "MountedMarksman", "Besieger"];

    function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function keys(o) { var r = [], k; for (k in o) if (own(o, k)) r.push(k); return r; }
    function each(o, f) { keys(o).forEach(function (k) { f(k, o[k]); }); }
    function total(a) { var t = 0; each(a || {}, function (k, v) { t += Number(v) || 0; }); return t; }
    function rng(seed) { var s = seed >>> 0 || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
    function opt(o) { var r = {}; each(DEFAULTS, function (k, v) { r[k] = v; }); each(o || {}, function (k, v) { if (v !== undefined) r[k] = v; }); return r; }
    function value(facts, t, cost) { if (cost && cost[t] != null) return Number(cost[t]); var u = facts.units[t]; return u && u.productionTime ? u.productionTime / 180000 : 1; }

    /* waves: [{g: profile, army}] fought in order against what the one before left; per wave the mean and bad-case losses and
       how often it was beaten (a wave that does not take the camp is beaten: its general must recover) */
    function evaluate(S, facts, camp, waves, n, q, seed, zoneMods) {
        var r = rng(seed || 7), wins = 0, per = waves.map(function () { return { lost: {}, samples: {}, beaten: 0, fought: 0, rounds: 0, killed: {} }; });
        for (var it = 0; it < n; it++) {
            var left = camp.map(function (u) { return [u[0], u[1]]; }), won = false, itLost = waves.map(function () { return {}; });
            for (var w = 0; w < waves.length && !won; w++) {
                var wv = waves[w], o = S.simulate(facts, { kind: wv.g.kind, skills: wv.g.skills }, wv.army, left,
                    { iterations: 1, seed: Math.floor(r() * 4294967295) + 1, keepLast: true, zoneMods: zoneMods }).last;
                per[w].fought++; per[w].rounds += o.rounds / n;
                each(o.defLost || {}, function (t, v) { per[w].killed[t] = (per[w].killed[t] || 0) + v / n; });
                each(o.lost, function (t, v) { per[w].lost[t] = (per[w].lost[t] || 0) + v / n; itLost[w][t] = (itLost[w][t] || 0) + v; });
                if (o.win) won = true; else per[w].beaten++;
                var by = {}; o.defLeft.forEach(function (x) { by[x[0]] = (by[x[0]] || 0) + x[1]; });
                left = left.map(function (x) { return [x[0], by[x[0]] !== undefined ? by[x[0]] : x[1]]; });
            }
            if (won) wins++;
            per.forEach(function (p, w) { keys(waves[w].army).forEach(function (t) { (p.samples[t] = p.samples[t] || []).push(itLost[w][t] || 0); }); });
        }
        per.forEach(function (p) { p.bad = {}; each(p.samples, function (t, a) { a.sort(function (x, y) { return x - y; }); p.bad[t] = a[Math.min(a.length - 1, Math.floor(q * a.length))]; });
            delete p.samples; p.beaten = p.fought ? p.beaten / p.fought : 0; });
        return { win: wins / n, perWave: per };
    }
    function judge(e, waves, o) {
        var bad = [];
        e.perWave.forEach(function (p, i) { var may = i === waves.length - 1 ? o.mainMayLose : o.waveMayLose;
            each(p.bad, function (t, v) { if (v > 0 && may.indexOf(t) < 0) bad.push(waves[i].g.short + " loses " + v + " " + t); }); });
        return { ok: e.win >= o.minWin && !bad.length, bad: bad };
    }
    function costOf(facts, e, waves, unitCost) {
        var c = 0; e.perWave.forEach(function (p, w) { each(p.lost, function (u, n) { c += n * (1 - Math.min(1, waves[w].g.recover || 0)) * value(facts, u, unitCost); }); });
        return c;
    }
    /* 0.2.0: what a solution costs and brings, for the player's objectives (author 2026-11-22 10:47: "zo snel mogelijk, zo min
       mogelijk verliezen, ... snelste, minste verliezen, best geschikt voor multiple run, meeste XP"; quests "verlies minder dan
       x van troeptype y") */
    /* 0.3.0: seconds to train lost units again, per barracks; elite units in the Elite Barracks */
    function trainSeconds(facts, u, n) { var f = facts.units[u]; return n * (f && f.productionTime ? f.productionTime / 1000 : 180); }
    function rebuildOf(facts, lostByWave, waves, rb) {
        var sp = (rb && rb.barracks) || {}, r = 0, el = 0;
        lostByWave.forEach(function (lost, w) { var keep = 1 - Math.min(1, waves[w].g.recover || 0);
            each(lost, function (u, n) { var s = trainSeconds(facts, u, n * keep); if (ELITE_UNITS.indexOf(u) >= 0) el += s; else r += s; }); });
        r /= Number(sp.regular) || 1; el /= Number(sp.elite) || 1;
        var b = (rb && rb.rebuildBase) || {};
        return { regular: r, elite: el, total: Math.max((Number(b.regular) || 0) + r, (Number(b.elite) || 0) + el) };
    }
    function metrics(facts, e, waves, unitCost, avoid, rb) {
        var m = { cost: costOf(facts, e, waves, unitCost), units: 0, seconds: 0, defeats: 0, xp: 0, generals: waves.length, avoided: 0 };
        var rbo = rebuildOf(facts, e.perWave.map(function (p) { return p.lost; }), waves, rb); m.rebuildRegular = rbo.regular; m.rebuildElite = rbo.elite; m.rebuild = rbo.total;
        e.perWave.forEach(function (p, w) {
            var g = waves[w].g, sp = facts.specialists[g.kind] || {}, mult = 1;
            facts.generalModifiers(g.kind, g.skills).forEach(function (md) { if (md.item === "CombatXP") mult *= md.multiplier || 1; });
            each(p.lost, function (u, n) { m.units += n; if (avoid && avoid[u]) m.avoided += n * avoid[u]; });
            m.seconds += p.rounds * 20 * 100 / (sp.timeBonus || 100);          // a round lasts 20 s at time bonus 100 (ADR 0063)
            if (p.beaten > 0.5 && w < waves.length - 1) m.defeats++;
            each(p.killed, function (u, n) { var f = facts.units[u]; m.xp += n * (f && f.xp ? f.xp : 0) * mult; });
        });
        return m;
    }
    var OBJECTIVES = {
        author:        function (m) { return m.cost; },                                   // the author's tier order, then the cheapest
        cheapest:      function (m) { return m.cost; },
        fewestLosses:  function (m) { return m.units * 1000 + m.cost; },
        fastest:       function (m) { return m.seconds * 1000 + m.cost; },
        spareGenerals: function (m) { return m.defeats * 1e6 + m.generals * 1e3 + m.cost; },   // multiple runs: generals stay fit
        mostXP:        function (m) { return -m.xp * 1000 + m.cost; },
        quickestRebuild: function (m) { return (m.rebuild || 0) * 1000 + m.cost; }   // 0.3.0
    };
    function score(x, obj) { return (OBJECTIVES[obj] || OBJECTIVES.author)(x.m) + x.m.avoided * 1e3 + (x.j.ok ? 0 : 1e9 * Math.max(0, 1 - x.e.win) + 1e8 * x.j.bad.length + 1e8); }

    /* the armies a main may take: a core type at capacity, 0-50 % fodder */
    function mainArmies(g, o, facts) {
        var units = BASE_UNITS.concat(o.eliteUnits ? ELITE_UNITS : []).filter(function (t) { return facts.units[t]; });
        if (o.units) units = units.filter(function (t) { return o.units.indexOf(t) >= 0; });
        var fodder = o.eliteUnits && units.indexOf("Swordsman") >= 0 ? "Swordsman" : "Recruit", out = [], seen = {};
        units.forEach(function (t) {
            [0, 0.1, 0.2, 0.3, 0.5].forEach(function (f) {
                var a = {}, nf = t === fodder ? 0 : Math.round(g.cap * f); if (nf) a[fodder] = nf; a[t] = (a[t] || 0) + g.cap - nf;
                var k = JSON.stringify(a); if (!seen[k]) { seen[k] = 1; out.push(a); }
            });
        });
        return out;
    }
    function waveArmies(g, o, facts) {
        var out = [{ Recruit: 1 }];
        o.waveMayLose.forEach(function (t) { if (!facts.units[t] || (!o.eliteUnits && ELITE_UNITS.indexOf(t) >= 0)) return; if (o.units && o.units.indexOf(t) < 0) return; var a = {}; a[t] = g.cap; out.push(a); });
        return out;
    }
    function distinct(gens) {                       // one representative per build (kind + skills); the caller's order kept
        var by = {}, out = [];
        gens.forEach(function (g) { var k = g.kind + " " + JSON.stringify(keys(g.skills || {}).sort().map(function (s) { return [s, g.skills[s]]; }));
            if (!by[k]) { by[k] = { g: g, all: [] }; out.push(by[k]); } by[k].all.push(g); });
        return out;
    }

    function solveCamp(S, facts, camp, gens, o0) {
        var o = opt(o0), seed = o.seed || 17, builds = distinct(gens.filter(function (g) { return g.cap > 0; }));
        var byStrike = builds.slice().sort(function (x, y) { return y.g.strike - x.g.strike; });
        var obj = o.objective || "author";
        function run(waves, n) { var e = evaluate(S, facts, camp, waves, n, o.quantile, seed, o.zoneMods); var x = { waves: waves, e: e, j: judge(e, waves, o) };
            x.m = metrics(facts, e, waves, o.unitCost, o.avoid, o); x.cost = x.m.cost; return x; }
        function sc(x) { return score(x, obj); }
        function verify(cands, tier) {
            cands.sort(function (x, y) { return sc(x) - sc(y); });
            var top = cands.slice(0, o.verifyTop).map(function (c) { var v = run(c.waves, o.iterations); v.tier = tier; return v; });
            top.sort(function (x, y) { return sc(x) - sc(y); });
            return top;
        }
        function pickGens(list, n, not) { var r = [], used = {}; (not || []).forEach(function (g) { used[g.id] = 1; });
            list.forEach(function (b) { b.all.forEach(function (g) { if (r.length < n && !used[g.id]) { used[g.id] = 1; r.push(g); } }); }); return r.length === n ? r : null; }
        var tried = [], best = null;
        function allow(t) { return !o.tiers || o.tiers.indexOf(t) >= 0; }
        function done(list) { list.forEach(function (x) { tried.push(x); }); var ok = tried.filter(function (x) { return x.j.ok; }).sort(function (x, y) { return sc(x) - sc(y); });
            if (ok.length) best = ok[0]; return !!ok.length && obj === "author"; }   // other objectives weigh every tier

        /* tier 1: one or two 1R attacks */
        var t1 = [];
        for (var k = 1; k <= Math.min(2, o.maxWaves); k++) { var gs = pickGens(byStrike, k); if (gs) t1.push(run(gs.map(function (g) { return { g: g, army: { Recruit: 1 } }; }), o.screen)); }
        if (allow("1R") && done(verify(t1, "1R"))) return result();

        /* tier 2: a main alone */
        var mains = byStrike.slice(0, o.mainBuilds), t2 = [], keepArmies = {};
        mains.forEach(function (b) {
            var rs = mainArmies(b.g, o, facts).map(function (a) { return run([{ g: b.g, army: a }], o.screen); });
            rs.sort(function (x, y) { return sc(x) - sc(y); }); keepArmies[b.g.id] = rs.slice(0, 5).map(function (x) { return x.waves[0].army; });
            rs.slice(0, 2).forEach(function (x) { t2.push(x); });
        });
        if (allow("main") && done(verify(t2, "main"))) return result();

        if (!allow("waves") || o.maxWaves < 1) return result();   // 0.2.1: maxWaves 0 = no wave
        /* tier 3: wave(s), then a main */
        var t3 = [];
        mains.forEach(function (mb) {
            var waveGens = byStrike.filter(function (b) { return b !== mb; }).slice(0, o.waveBuilds);
            var configs = [];
            waveGens.forEach(function (wb) { waveArmies(wb.g, o, facts).forEach(function (wa) { configs.push([{ g: wb.g, army: wa }]); }); });
            if (o.maxWaves >= 2) { var two = pickGens(waveGens, 2, [mb.g]); if (two) configs.push(two.map(function (g) { return { g: g, army: { Recruit: 1 } }; })); }
            configs.forEach(function (cw) {
                if (cw.some(function (w) { return w.g.id === mb.g.id; })) return;
                (keepArmies[mb.g.id] || []).forEach(function (a) { t3.push(run(cw.concat([{ g: mb.g, army: a }]), o.screen)); });
            });
        });
        done(verify(t3, "waves"));
        return result();

        function result() {
            var all = tried.slice().sort(function (x, y) { return sc(x) - sc(y); });
            function out(x) { return x ? { tier: x.tier, ok: x.j.ok, win: Math.round(x.e.win * 1000) / 1000, cost: Math.round(x.cost * 10) / 10, why: x.j.bad, objective: obj,
                metrics: { cost: Math.round(x.m.cost * 10) / 10, units: Math.round(x.m.units), seconds: Math.round(x.m.seconds), defeats: x.m.defeats, xp: Math.round(x.m.xp), generals: x.m.generals,
                    rebuild: Math.round(x.m.rebuild), rebuildRegular: Math.round(x.m.rebuildRegular), rebuildElite: Math.round(x.m.rebuildElite) },
                waves: x.waves.map(function (w, i) { var p = x.e.perWave[i]; return { id: w.g.id, general: w.g.short, kind: w.g.kind, army: w.army, lost: p.lost, bad: p.bad, beaten: p.beaten }; }) } : null; }
            var options = tried.filter(function (x) { return x.j.ok; }).sort(function (x, y) { return sc(x) - sc(y); }).slice(0, 5).map(out);
            return { version: VERSION, ok: !!best, best: out(best), closest: best ? null : out(all[0]), options: options };
        }
    }

    var api = { version: VERSION, rank: function (m, obj) { return (OBJECTIVES[obj] || OBJECTIVES.author)(m) + m.avoided * 1e3; }, solveCamp: solveCamp, evaluate: evaluate, metrics: metrics, rebuildOf: rebuildOf, OBJECTIVES: keys(OBJECTIVES), DEFAULTS: DEFAULTS };
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    root.DMA_CampSolver = api;
})(typeof window !== "undefined" ? window : this);
