/*
 * user_dma_mundane_gen.js — Mundane generator (PBC adventure management, ADR 0094)
 * 0.8.6 (2026-11-27, author 11:00 and 11:03, B14 section 15; SirBirk's Raid of the Nords template): objective "sameType" = way 2 of
 *   the author's four: an existing Mundane 1:1 with the player's own generals of the author's types (the most skilled one of each
 *   type). Only the generals change; spots, armies, targets, order, delays and arrows are the author's, nothing is re-planned. A
 *   missing type or too little capacity is an error (then way 3, "Use with my generals", is the one to use). The result's source
 *   says it is the author's plan, so the executor keeps the author's interception rule for it.
 *   Way 3 ("author", Use with my generals) keeps the author's attack of a camp whose every attacker has a stand-in of his own type
 *   when it wins, his losses named (AUTHOR_LOSSES_KEPT) instead of re-planned by the camp solver. Of the player's generals of the
 *   author's type the one that carries the author's army comes first, then the most skilled (before: the first in the list).
 *   Unit: tests/unit/dma-mundane-gen-same-type.test.js. Integration: tests/integration/dma-mundane-gen-rotn-sirbirk.test.js.
 * 0.8.5 (2026-11-27, live FT 2026-11-27 05:47-06:12Z, change-set B14 section 13). The battle simulator was right; the way was
 *   not. "Use with my generals" moved YGG1 (the main for camp 1870) to the nearest free spot, 1516, because the author's spot was
 *   held by the wave before him. From 1516 the way to 1870 passes camp 1132, which the plan never attacks: YGG1 was caught there,
 *   won with 3 of his 155 left (simulator: 1-9 left) and lost at 1870, twice. When a step needs another spot, the spots whose way
 *   passes a camp still standing at that point of the plan come last (adventure.way(from, to): the camps watching that way, from
 *   the game's own path and watch areas). When every free spot is watched, the plan names it (INTERCEPT_RISK). Version 0.8.4 was
 *   tried and withdrawn (B14 section 8), so this version is 0.8.5.
 *   Unit: tests/unit/dma-mundane-gen-steps-way.test.js. Integration: tests/integration/battlesim-guides-ft.test.js (the simulator
 *   against 18 published First Thief attacks, YGG waves included) and the FT stand-in test with a way that watches 1516 -> 1870.
 * 0.8.3 (2026-11-26, live FT 2026-11-26 16:37-17:02Z, change-set B14 section 7; "Use with my generals" = objective author).
 *   Sizz's SYLVANA (195 troops on camp 1870, 75 s after the general before her) was written as "Narcissistic General, 1 Recruit"
 *   with a delay of 1 s: the first wave of the camp solver's own way for that camp (her stand-in wins, but loses a unit type the
 *   player's rule keeps), put in her place, its second wave and main in attacks 02 and 03.
 *   - a way that keeps the author's plan comes first: before the camp solver plans a camp its own way it is asked for a way
 *     with no more attackers than the author used and no general with 1 unit where he brought an army (another general or
 *     army in his slot, his order and delay);
 *   - when the solver's waves are needed after all, a wave in the author's place leaves after the author's delay, not after 1 s;
 *   - a camp the player's generals do not WIN in the simulator is NOT written (CAMP_NOT_SOLVED "is NOT in the plan", camp
 *     record notWritten); before, the closest losing army was written into the plan;
 *   - a step's keys are written in the order of the plan. Mundane sends a template in KEY order (its "order" field is only
 *     kept); the steps were written generals first, arrows last, so the arrows went on their camps after every general had left.
 *   Unit: tests/unit/dma-mundane-gen-steps.test.js (key order = order, the arrows in their place).
 *   Integration: tests/integration/dma-mundane-gen-ft-standin.test.js (the fixture with rosters that hold a Narcissistic
 *   General: every slot keeps the author's delay, a 1-unit general only as a wave of a camp whose main follows, no general
 *   written for a camp that is not won, the keys in the plan's order).
 * 0.8.2 (2026-11-26, architect review 2026-11-26-b13-b14-own-mundane F7, ADR 0042): the destroy-arrow table is the registered copy
 *   of docs/05-ontology/dma/facts/destroy-arrows.yaml, with its source named (DESTROY_SOURCE) and the game as its watcher: the
 *   observations in dma-arrow-facts.json (A.arrowFacts) decide before the copy; a camp without a known size gets no arrow and a
 *   finding ARROW_SIZE_UNKNOWN. Unit: dma-mundane-gen-campplan. Integration: dma-arrow-facts-watch.
 * 0.8.1 (2026-11-26, live FT): Use with my generals (and every objective that starts from the author's templates) keeps
 *   the author's arrows and buffs 1:1 — same item, same camp, own place in the order, in the first step. Before, they were
 *   dropped and the generals walked through the camps the arrows clear. Integration: dma-mundane-gen-ft-arrows.
 * 0.8.0 (2026-11-26, BETA, change-set B14; author 07:52/07:58: scenarios "Quick loot", "Most XP", "Only arrows/buffs", "Not more
 *   than x losses of troop y"; "de generator moet ook kunnen bepalen welke kampen minimaal vernietigd moeten worden om het avontuur
 *   te kunnen afsluiten en welke arrows/buffs de kampen doen vernietigen ... in deze release in beta vorm"): campPlan() — for a plan
 *   made from scratch —
 *   - quickLoot: only the camps the adventure's quests name (book map.destroy, read in the game) and, before them, every camp on
 *     their way (adventure.blocks, learned from the game's interception picture); without quest names every camp stays (finding
 *     QUICKLOOT_UNKNOWN);
 *   - arrows: a camp that a destroy arrow in the star can take is given to the arrow, not to a general — Small Catapult
 *     (BattleBuffDestroy_small_camps) an easy camp, Big Catapult (BattleBuffDestroy_small_medium_camps) an easy or medium camp
 *     (sources: settlersonlinewiki.eu battle buffs, tsomaps.com buff list; the size of a camp: the game's name "(easy)/(medium)"
 *     or tsowiki's camp type Small/Medium); cheapest arrow first, counted against the star;
 *   - arrowsOnly: no general at all; a camp no arrow takes is named (ARROWS_SHORT) and the version is of kind "arrows only"
 *     with a per-camp plan ("#<grid>": [{arrow, max}]) for the arrows run.
 *   The arrows go into the first attack template before the generals (type "buff", in their own place: played as written).
 *   Unit: tests/unit/dma-mundane-gen-campplan.test.js.
 * 0.7.3 (2026-11-26, change-set B13; policy 0.2.89): a saved version no longer writes adv.<id>.asIs (removed: every plan is
 *   played as written; a scratch plan keeps its kind "without blocks"). Unit: tests/unit/dma-mundane-gen.test.js.
 * 0.7.2 (2026-11-23, live IP: the rest of an open adventure had to be played with the 354 Recruits and 140 Cavalry on the island):
 *   choice units [types] limits the camp solver to those unit types. Unit: tests/unit/dma-mundane-gen-scratch.test.js (units).
 * 0.7.1 (2026-11-23, live IP: "5402 (Narcissistic passes 4450,4384,3905,4996)"): from scratch with adventure.blocks {camp: [camps
 *   on its path]} (learned by the executor, adventure 0.2.159) every camp comes after the camps on its path. Unit:
 *   tests/unit/dma-mundane-gen-scratch.test.js (blockers first).
 * 0.7.0 (2026-11-23, author: "als een generaal zijn kamp verslagen heeft en hij is de rest van het avontuur niet meer nodig, dan
 *   kun je hem naar huis sturen, als hij alleen de volgende aanval niet meer nodig is en je hebt zijn landingsspot nodig, dan kun je
 *   hem opzij zetten of zelfs naar star"; "Dat gehele plan moet onderdeel uitmaken van je mundanes vooraf en niet trial en error"):
 *   from scratch with known landing fields, each round's template first names what happens to the generals of earlier rounds
 *   still on a field — to the star (grid -1) when needed again, home (home: true) when not — then the attackers on their fields.
 *   Unit: tests/unit/dma-mundane-gen-scratch.test.js (field plan). Executor: user_dma_adventure 0.2.158 plays home entries.
 * 0.6.1 (2026-11-23, live IP 03:10-04:10Z, ADR 0094 lesson 3: on the Island of the Pirates a general may only stand on the 4
 *   landing fields until camps fall, and camps 6545/6070 next to the landing stand in the way of every other camp): from scratch,
 *   when the landing fields are known (adventure.landing.grids, learned from the game), the camps are taken nearest the landing
 *   first (the blockers), a round holds no more generals than there are landing fields, and each attacker stands on a landing
 *   field of its own. Unit: tests/unit/dma-mundane-gen-scratch.test.js (landing case).
 * 0.6.0 (2026-11-23, author: "Naast minste verliezen, etc. Heb je dus ook de kortste tijd om het verlies weer op te bouwen"):
 *   objective quickestRebuild (camp solver 0.3.0). Choice barracks {regular, elite} = each barracks' speed (its level; the
 *   console reads it from the troop picture). From scratch every camp is solved against the rebuild queues of the camps
 *   planned before it; each camp record carries rebuildRegular/rebuildElite and phase 4 totals.rebuild = the longer of the two
 *   queues (the barracks train side by side). The versions list gains quickestRebuild and shows rebuild.
 *   Unit: tests/unit/dma-mundane-gen-scratch.test.js (rebuild totals). Integration: tests/integration/dma-mundane-gen-versions.test.js.
 * 0.5.1 (2026-11-22, live IP 18:55Z: the start was refused — "the load carries too little for 2 waves, short 32 Recruit"): the
 *   steps are checked as the executor checks a version without blocks (waveLoadCheck), and what is short goes to the carriers.
 *   Unit: tests/unit/dma-mundane-gen-scratch.test.js (the executor's own check passes on the made version).
 * 0.5.0 (2026-11-22, ADR 0094 addendum 19:58, the live ToW lessons 2 and 4; author: "leer ervan en maak het beter"): a round is
 *   written as steps (splitSteps): an attacker that would stand on the spot of an earlier attacker of the same camp moves, with
 *   the rest of that camp, to the next step, so a wave and its main never need one spot at once (attackers on spots of their
 *   own keep one step and the author's timing); no two generals of a step share a spot, and a wave general's spot is not given to a later step of
 *   the round (it recovers on it) — the nearest free grid of the round is taken. Finding STEPS. Lesson 3 (blockers first) is
 *   left to the executor's camp scheduler and the round order. Unit: tests/unit/dma-mundane-gen-steps.test.js. Integration:
 *   tests/integration/dma-mundane-gen-versions.test.js (no shared spot in a step; a camp's main after its waves).
 * 0.4.1 (2026-11-22, live ToW 13:33Z): a wave the camp solver puts before a main where the author used fewer attackers gets a
 *   slot of its own in the template (same camp, just before the main); before, the main took the author's only slot alone and
 *   fought the full camp (simulated: YGG2 losing 108 MountedMarksman at camp 7217). The camp solver is asked for up to two waves
 *   whatever the author used. Unit: tests/unit/dma-mundane-gen.test.js (every simulated attacker is in the template).
 * 0.4.0 (2026-11-22, ADR 0094 addendum 17:22; author: "Begin eens met een heel laag level avontuur" — "En kijk niet naar mijn
 *   mundanes maar vergelijk achteraf"): from scratch — input.scratch (or no template files) makes the plan from the adventure's
 *   camps and the player's generals alone: the camps hardest first (enemy hit points), each solved by the camp solver for the
 *   chosen objective with the generals still free in the round (a general attacks once per round; a camp no free general takes
 *   opens the next round; a beaten general is out unless it recovers once). The attack templates stand each attacker on its
 *   target's grid (the executor moves it to the nearest placeable spot, user_dma_adventure nearPlaceable) and play as the kind
 *   "without blocks" (waves): the camp scheduler sends a camp when no live camp watches the way, so the order on the island is
 *   found while playing. The made templates then go through the same five phases as a shared Mundane (the player's own generals,
 *   so every general maps to itself). Camps by coordinates take adventure.zoneWidth (default 68, the width every adventure
 *   template checked so far maps onto). Finding SCRATCH names it. Unit: tests/unit/dma-mundane-gen-scratch.test.js.
 * 0.3.2 (2026-11-22, live: the game had not shown Bonaberti's camps yet, so nothing could be simulated): adventure.campsXY
 *   ({"x,y": [name, [[type, n]]]}, an online source such as user_dma_adv_camps_online.js) is used when no camps by grid are
 *   given; the zone width is found from the templates' targets; finding CAMPS_ONLINE names the source.
 *   Unit: tests/unit/dma-adv-camps-online.test.js.
 * 0.3.1 (2026-11-22, console 0.1.120 "Check my versions"): generals.json of a generated version also lists allIds — every
 *   general the player had then — so a new general can be told from one that was simply not used. rosterOf exported.
 * 0.3.0 also (ADR 0094 addendum 11:01; author: "kan een speler een nieuwe general krijgen of een bestaande skillen en moet hij een
 *   bestaande mundane opnieuw kunnen analyseren en eventueel verbeteren"): reanalyse(input) / reanalyseJob — the generals the
 *   version was made for (its generals.json) against the generals now: NEW, SKILLED, GONE; the version planned for both; the
 *   plan for now offered when it is better (more camps, or the objective's measure at least 2 % lower). fingerprint(generals)
 *   for the client to notice a change. Unit: tests/unit/dma-mundane-gen.test.js (changes, fingerprint). Integration:
 *   tests/integration/dma-mundane-gen-reanalyse.test.js.
 * 0.3.0 (2026-11-22, ADR 0094 addendum 10:59; author: "Geef de speler de mogelijkheid om te kiezen voor een mundane
 *   rekenfase, waarbij hij bewust kiest om dat even voorrang te geven op alles, anders vindt het plaats op de achtergrond"):
 *   a plan is a job of small steps (a round's set-up, one camp, a round's end, the rest); generateJob / versionsJob; calculate(job,
 *   {mode}) runs it in slices — "background" (40 ms, then 500 ms for the rest of the client) or "priority" (1 s slices back to
 *   back, with the blue work at home held through control's visit hold while it runs); setMode switches while it runs, cancel
 *   stops it and releases the hold. generate / generateVersions stay synchronous (the same jobs run to the end).
 *   Unit: tests/unit/dma-mundane-gen-calc.test.js (fake clock: slices, mode switch, hold requested and released, cancel).
 * 0.2.0 (2026-11-22, ADR 0094 addendum 10:47; author: "zo snel mogelijk, zo min mogelijk verliezen, bepaalde troepen die je
 *   perse niet wil verliezen ... meerdere versies: snelste, minste verliezen, best geschikt voor multiple run, meeste XP ...
 *   quest, doe een avontuur en verlies minder dan x van troeptype y"): choice objective (camp solver 0.2.0 OBJECTIVES) — with
 *   another objective than "author" every camp also asks the camp solver and takes its way when it is better for that
 *   objective; choice maxLoss {unit: n} (a quest) is weighed in every camp and checked on the run's bad case (QUEST_LOSS);
 *   choice avoid {unit: weight}. Phase 4 carries totals (seconds: rounds one after another, camps of a round side by side;
 *   xp; units lost; generals beaten). generateVersions(input, objectives) makes one version per objective to compare.
 *   Unit: tests/unit/dma-mundane-gen.test.js. Integration: tests/integration/dma-mundane-gen-versions.test.js.
 * 0.1.1 (2026-11-22, ADR 0094 step B; author: "Als ik 4 wave attacks heb met de YGG, moet ik ook 4 YGGs beschikbaar hebben. Zo
 *   niet kan dat een reden zijn om de aanval op te breken"; "Herstel van een generaal betekent dat hij niet meer mee kan doen
 *   voor dat avontuur"): when the author's waves would beat more generals than the player has (GENERAL_OUT), the plan is made
 *   again with choice spareGenerals: a camp a general takes alone (1R or a main without a wave) is played that way, so no
 *   general is beaten for it; the plan with more solved camps (then fewer errors) is kept, with finding SPARE_GENERALS.
 *   Unit: tests/unit/dma-mundane-gen.test.js (version, choice). Integration: tests/integration/dma-mundane-gen-bb.test.js —
 *   without Ghost and Gemini generals more camps are solved than with the author's waves (9 of 18 in 0.1.0).
 * 0.1.0 (2026-11-22, ADR 0094; author: "gebruik alle lessen van de ywc run, want dat geeft precies aan de 5 fasen die we
 *   hebben, daar kan de speler keuzes voor maken, de eigenschappen van het avontuur en de eigenschappen van de generals moeten
 *   leiden tot goede mundanes"):
 *   A shared Mundane folder (the author's, with generals.json) is rebuilt for the player's OWN generals and skills, and the
 *   result is a run plan along the five phases of ADR 0082 plus the Mundane files the executor plays.
 *   Pure, no game call: the caller passes the facts —
 *     files        the shared folder's files [{name, text}] (templates and generals.json)
 *     adventure    {id, abbr, camps: {<grid>: [[unitType, n], ...]}, campNames: {<grid>: name}, landing: {n, source},
 *                   eliteUnits: true|false}  — properties of the adventure
 *     myGenerals   the player's generals (dma-skills.json specialists: {id, name, type, skills: [{name, level}]})
 *     facts        a DMA_BattleSim.Facts of the game's unit, specialist and skill facts (ADR 0042)
 *     pool         the free units at home {type: n} (optional: phase 1 then names no shortfall)
 *     reserve      ids of generals not to use (e.g. one in the zombie hunt)
 *     choices      the player's choices per phase (CHOICES below)
 *   and gets {version, ok, phases: [5 sections], files: [{name, text}], generals, settings, cost, findings}.
 *   Mapping (ADR 0094 §2): one stand-in per author general for the whole run — SAME, EQUAL, SKILLS_DIFFER, ALTERNATIVE (by
 *   role: a front attacker takes the smallest capacity that holds its army, a main the strongest own strike that holds it).
 *   Re-simulation (§3): per camp the attackers in the author's order; a camp passes at win >= minWin and, in the bad case
 *   (quantile), no attacker loses a unit type its role may not lose; otherwise front at full capacity / more Swordsmen in the
 *   main / main at full capacity of its strongest type, the cheapest that passes.
 *   Unit expectation:        tests/unit/dma-mundane-gen.test.js
 *   Integration expectation: tests/integration/dma-mundane-gen-bb.test.js (the author's shared Bonaberti two-waves folder for a
 *                            player without his Ghost and Gemini generals).
 */
(function (root) {
    "use strict";
    var VERSION = "0.8.6";
    var CHOICES = {
        quantile: 0.95,                      // phase 1/4: plan on the bad case (ADR 0080), not the mean
        loadMargin: 0.10,                    // phase 1/2: extra on the carriers' cargo (adv.waves.loadMargin)
        runs: 1,                             // phase 1: runs to plan the troops for (troop manager)
        iterations: 200,                     // phase 4: simulated battles per camp and variant
        minWin: 0.99,                        // phase 4
        mainMayLose: ["Recruit", "Swordsman"],                                    // author 2026-11-05/13
        waveMayLose: ["Recruit", "Swordsman", "Bowman", "Cavalry", "Knight"],     // author 2026-11-13: never MS
        starMethod: "auto",                  // phase 3: "auto" = only when more generals land than there are spots
        prestage: true,                      // phase 3/4 (adv.prestage)
        asIs: true,                          // phase 4: keep the author's order and times (his timings chain exactly)
        aheadHome: "auto",                   // phase 5: "auto" = on when the first round has generals of its own
        closeAtOnce: true,                   // phase 5
        objective: "author",                 // author | cheapest | fewestLosses | fastest | spareGenerals | mostXP | quickestRebuild (camp solver)
        barracks: null,                      // 0.6.0: {regular, elite} speed of each barracks (its level); null = 1 each
        units: null,                         // 0.7.2: only these unit types (e.g. what is on the island when an adventure is resumed)
        maxLoss: null,                       // a quest: {unitType: n} — lose fewer than n of it in the run (bad case)
        avoid: null,                         // {unitType: weight}: keep a unit type out of the losses where possible
        spareGenerals: "auto",               // step B: "auto" = only when the author's waves beat more generals than there are
        quickLoot: false,                    // 0.8.0 (B14 beta): only the quest camps and the camps on their way
        arrows: true,                        // 0.8.0: destroy arrows in the star take the camps they can
        arrowsOnly: false                    // 0.8.0: only arrows, no generals (kind "arrows only")
    };
    /* 0.8.0 (B14 beta): the destroy arrows and the camp sizes they take; cheapest first.
       0.8.2 (architect review 2026-11-26 F7, ADR 0042): this is the REGISTERED COPY of docs/05-ontology/dma/facts/destroy-arrows.yaml
       (source: settlersonlinewiki.eu battle buffs and tsomaps.com buff list, read 2026-11-26). Its watcher is the game itself: every
       arrow the adventure completer puts on a camp is observed (taken: the camp fell; not taken: it stood) and kept in
       dma-arrow-facts.json; campPlan() acts on those observations before the copy (ADR 0042 rule 4: where the source answers, it
       wins), and the completer records "the facts of destroy arrows changed" when an observation contradicts the copy. */
    var DESTROY_ARROWS = [{ def: "BattleBuffDestroy_small_camps", name: "Small Catapult", sizes: ["easy"] },
                          { def: "BattleBuffDestroy_small_medium_camps", name: "Big Catapult", sizes: ["easy", "medium"] }];
    var DESTROY_SOURCE = { file: "docs/05-ontology/dma/facts/destroy-arrows.yaml", source: "settlersonlinewiki.eu battle buffs; tsomaps.com buff list", at: "2026-11-26", watcher: "the game (dma-arrow-facts.json)" };
    /* does arrow a take a camp of this size: the game's observations first (taken / not taken on a camp of that size), else the copy */
    function arrowTakes(a, size, obs) {
        var o = obs && obs[a.def] && obs[a.def][size];
        if (o && o.notTaken > 0 && !(o.taken > 0)) return false;
        if (o && o.taken > 0) return true;
        return a.sizes.indexOf(size) >= 0;
    }
    function campSize(name, type) {
        var n = String(name || ""), t = String(type || (/^(small|medium|heavy|leader)$/i.test(n) ? n : ""));   // an online camp is named by its type
        if (/^small$/i.test(t) || /\(easy\)|easy\b|Easy$/i.test(n)) return "easy";
        if (/^medium$/i.test(t) || /\(medi|medium/i.test(n)) return "medium";
        if (/^(heavy|leader)$/i.test(t) || /hard|heavy|leader|boss/i.test(n)) return "hard";
        return null;
    }
    /* camps: [{grid, name, army}]; A: {questCamps: [names], blocks: {grid: [grids on its way]}, campTypes: {grid: type}};
       ch: {quickLoot, arrows, arrowsOnly}; star: {buff def name: count}. Pure. */
    function campPlan(camps, A, ch, star) {
        A = A || {}; ch = ch || {}; var F = [], keep = camps.slice(), stock = copy(star || {}), arrows = [], qn = (A.questCamps || []).map(String);
        if (ch.quickLoot || ch.arrowsOnly && qn.length) {
            if (!qn.length) F.push(finding("warn", "QUICKLOOT_UNKNOWN", 4, "quick loot: the camps the quests ask for are not known yet; every camp is planned.", "Open the adventure once so DMA reads its quests, then make the version again."));
            else {
                var need = {}, byGrid = {}; camps.forEach(function (c) { byGrid[c.grid] = c; });
                (function add(list) { list.forEach(function (g) { if (need[g] || !byGrid[g]) return; need[g] = 1; add(((A.blocks || {})[g] || []).map(Number)); }); })
                    (camps.filter(function (c) { return qn.indexOf(String(c.name)) >= 0; }).map(function (c) { return c.grid; }));
                keep = camps.filter(function (c) { return need[c.grid]; });
                F.push(finding("info", "QUICKLOOT", 4, "quick loot: " + keep.length + " of " + camps.length + " camps (the quest camps " + qn.join(", ") + " and the camps on their way).", ""));
            }
        }
        var toSolve = [];
        var unsized = [];
        keep.forEach(function (c) {
            var size = campSize(c.name, (A.campTypes || {})[c.grid]), pick = null;
            if (!size && (ch.arrows !== false || ch.arrowsOnly)) unsized.push(c.name + " (" + c.grid + ")");   // 0.8.2 (F7): no size, no arrow
            if (ch.arrows !== false || ch.arrowsOnly) DESTROY_ARROWS.forEach(function (a) { if (!pick && size && arrowTakes(a, size, A.arrowFacts) && (Number(stock[a.def]) || 0) > 0) pick = a; });
            if (pick) { stock[pick.def]--; arrows.push({ grid: c.grid, name: c.name, def: pick.def, arrow: pick.name }); }
            else toSolve.push(c);
        });
        if (unsized.length) F.push(finding("warn", "ARROW_SIZE_UNKNOWN", 4, "no camp size known for " + unsized.join(", ") + ": no destroy arrow is given to it (the size comes from the game's camp name or the online camp type).", "Open the adventure once so its camps are read from the game."));
        if (arrows.length) F.push(finding("info", "ARROWS", 4, arrows.length + " camp(s) taken by a destroy arrow: " + arrows.map(function (x) { return x.name + " (" + x.grid + ") " + x.arrow; }).join(", ") + ".", ""));
        if (ch.arrowsOnly && toSolve.length) F.push(finding("error", "ARROWS_SHORT", 4, "only arrows: no arrow in the star takes " + toSolve.map(function (c) { return c.name + " (" + c.grid + ")"; }).join(", ") + ".",
            "Make Small or Big Catapults (easy / medium camps), or allow generals for these camps."));
        return { camps: ch.arrowsOnly ? [] : toSolve, arrows: arrows, findings: F, notTaken: ch.arrowsOnly ? toSolve : [] };
    }
    function arrowEntries(arrows) { var o = {}; arrows.forEach(function (a, i) { o["buff_" + a.grid] = { name: a.def, order: i, time: 1000, type: "buff", skills: {}, army: {}, target: a.grid, targetName: a.name }; }); return o; }
    var CARRIER_PREF = { 12: 1, 54: 1 };
    var RECOVER_TYPES = { 50: 1, 63: 1 };    // Halloween2019General (YGG), GhostGeneral     // Quartermaster General, Quartermaster Bigheart (user_dma_mundane CARRIER_TYPES)

    function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function keys(o) { var r = [], k; for (k in o) if (own(o, k)) r.push(k); return r; }
    function each(o, f) { keys(o).forEach(function (k) { f(k, o[k]); }); }
    function copy(o) { var r = {}; each(o || {}, function (k, v) { r[k] = v; }); return r; }
    function add(o, a, f) { each(a || {}, function (k, v) { o[k] = (o[k] || 0) + (f == null ? 1 : f) * v; }); return o; }
    function total(a) { var t = 0; each(a || {}, function (k, v) { t += Number(v) || 0; }); return t; }
    function strip(s) { return String(s || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim(); }
    function shortName(name) { var n = strip(name), i = n.indexOf("("); return (i > 0 ? n.slice(0, i) : n).trim(); }
    function key(id) { id = String(id); return /\./.test(id) ? id : id + ".0"; }
    function idOf(k) { return String(k).replace(/\.0$/, ""); }
    function skillMap(sk) {                  // [{name, level}] or {name: level} -> {Name: level} without the Skill_ prefix
        var r = {};
        if (sk && sk.length !== undefined) sk.forEach(function (x) { if (x && x.level) r[String(x.name).replace(/^Skill_/, "")] = Number(x.level); });
        else each(sk || {}, function (k, v) { if (v) r[String(k).replace(/^Skill_/, "")] = Number(v); });
        return r;
    }
    function finding(level, code, phase, text, fix) { return { level: level, code: code, phase: phase, text: text, fix: fix || "" }; }
    function fmt(u) { return keys(u).filter(function (t) { return u[t] > 0; }).map(function (t) { return u[t] + " " + t; }).join(", ") || "nothing"; }

    /* ---------- properties of the generals ---------- */
    function specOfType(facts) { var r = {}; each(facts.specialists, function (n, s) { r[s.type] = s; }); return r; }
    function profile(facts, specs, S, g) {
        var sp = specs[g.type]; if (!sp) return null;
        var skills = skillMap(g.skills), mods = facts.generalModifiers(sp.name, skills);
        var p = { id: idOf(g.id), name: g.name, short: shortName(g.name) || sp.name, type: g.type, kind: sp.name, skills: skills,
                  general: !!sp.general && !sp.transport && sp.maxUnits > 0, transport: !!sp.transport, cap: facts.capacity(sp.name, skills),
                  recover: 0, strike: 0 };
        mods.forEach(function (m) { if (m.item === "RecoverLostTroops") p.recover += m.multiplier; if (m.item === "InstantRecover") p.recoverOnce = true; });
        if (RECOVER_TYPES[g.type]) p.recoverOnce = true;     // author 2026-11-22 09:19: YGG and Ghost recover once per adventure
        if (p.general) {
            try { var q = S.makeSquad(facts, sp.militaryUnitType, 1, mods, "att", true);
                  p.strike = ((q.acc * q.maxD + (100 - q.acc) * q.minD) / 100) * (q.splash ? 1 : 0.2) * (q.twice ? 2 : 1); } catch (e) { p.strike = 0; }
        }
        return p;
    }
    function atLeast(mine, theirs) { return keys(theirs).every(function (k) { return (mine[k] || 0) >= theirs[k]; }); }

    /* ---------- the author's run: load, rounds, camps ---------- */
    function readRun(M, files, myGenerals) {
        var side = null, tpl = [];
        files.forEach(function (f) {
            var d = null; try { d = JSON.parse(String(f.text)); } catch (e) { d = null; }
            if (d && d.format === "dma-shared-generals/1") side = d; else tpl.push(f);
        });
        var a = M.analyzeAdventure(tpl, { myGenerals: [] }), role = {};
        a.templates.forEach(function (t) { role[t.file] = t.role; });
        var byName = {}; tpl.forEach(function (f) { byName[f.name] = f; });
        a.built.forEach(function (b) { byName[b.file] = { name: b.file, text: b.text }; });
        var load = null, rounds = [];
        a.run.forEach(function (file) {
            var t = M.parse(file, byName[file] ? byName[file].text : ""); if (t.error) return;
            var r = role[file] || (/load/i.test(file) ? "LOAD" : "ATTACK");
            if (!load && (r === "LOAD" || r === "LOAD+ATTACK")) load = t;
            if (t.generals.some(function (g) { return g.target; })) rounds.push(t);
        });
        return { side: side, load: load, rounds: rounds, analysis: a };
    }

    /* ---------- §2 mapping: one stand-in per author general ---------- */
    function mapGenerals(run, mine, ctx) {
        var roles = {}, armies = {}, order = [], info = {};
        function note(g) { if (!info[g.id]) { info[g.id] = { id: g.id, name: g.name, type: g.type }; order.push(g.id); } }
        run.rounds.forEach(function (t) {
            var byCamp = {};
            t.generals.forEach(function (g) { note(g); if (g.target) (byCamp[g.target] = byCamp[g.target] || []).push(g); armies[g.id] = Math.max(armies[g.id] || 0, g.total); });
            each(byCamp, function (c, gs) { gs.sort(function (x, y) { return x.order - y.order; }); gs.forEach(function (g, i) {
                if (i === gs.length - 1) roles[g.id] = "main"; else if (!roles[g.id]) roles[g.id] = "front"; }); });
        });
        var used = {}, map = {}, rows = {}, side = (run.side && run.side.generals) || {}, need = {}, theirs = {}, tp = {};
        var att = order.filter(function (aid) { return roles[aid]; });
        att.forEach(function (aid) { var sd = side[key(aid)] || side[aid] || {}; theirs[aid] = skillMap(sd.skills); tp[aid] = sd.type != null ? sd.type : info[aid].type;
            need[aid] = armies[aid] || 0; rows[aid] = { from: aid, fromName: shortName(info[aid].name) || sd.name, role: roles[aid], outcome: "MISSING" }; });
        function free() { return mine.filter(function (m) { return m.general && !used[m.id] && ctx.reserve.indexOf(m.id) < 0; }); }
        function take(aid, m, outcome) { used[m.id] = 1; map[aid] = m; var r = rows[aid]; r.outcome = outcome; r.to = m.id; r.toName = m.short; r.cap = m.cap; }
        /* in passes over ALL generals, so a general of the player's that the author also uses is never taken as another's
           stand-in first: SAME, then EQUAL, then the same type, then an alternative — mains before fronts */
        att.forEach(function (aid) { var m = free().filter(function (x) { return x.id === idOf(aid); })[0]; if (m) take(aid, m, "SAME"); });
        /* 0.8.6 (author 2026-11-27 11:00: "een generaal van dat type, volledig geskilled"): of the player's generals of the author's type
           the one that carries the author's army comes first, then the most skilled, then the largest (before: the first in the list) */
        function best(aid, list) { return list.sort(function (x, y) { return (y.cap >= need[aid] ? 1 : 0) - (x.cap >= need[aid] ? 1 : 0) || total(y.skills) - total(x.skills) || y.cap - x.cap; })[0]; }
        att.forEach(function (aid) { if (map[aid]) return; var m = best(aid, free().filter(function (x) { return x.type === tp[aid] && atLeast(x.skills, theirs[aid]); })); if (m) take(aid, m, "EQUAL"); });
        att.forEach(function (aid) { if (map[aid]) return; var m = best(aid, free().filter(function (x) { return x.type === tp[aid]; })); if (m) take(aid, m, "SKILLS_DIFFER"); });
        ["main", "front"].forEach(function (role) {
            att.filter(function (aid) { return !map[aid] && roles[aid] === role; }).sort(function (x, y) { return need[y] - need[x]; }).forEach(function (aid) {
                var f = free(), holds = f.filter(function (m) { return m.cap >= need[aid]; });
                var m = holds.sort(function (x, y) { return y.strike - x.strike || x.cap - y.cap; })[0] || f.sort(function (x, y) { return y.cap - x.cap; })[0];
                if (m) take(aid, m, "ALTERNATIVE");
            });
        });
        rows = att.map(function (aid) { return rows[aid]; });
        return { map: map, rows: rows, roles: roles };
    }

    /* ---------- §3 simulation ---------- */
    function unitValue(facts, t, cost) { if (cost && cost[t] != null) return Number(cost[t]); var u = facts.units[t]; return u && u.productionTime ? u.productionTime / 180000 : 1; }
    function scaleTo(army, cap) {
        var t = total(army); if (t <= cap || t <= 0) return copy(army);
        var r = {}, sum = 0, ks = keys(army).sort(function (x, y) { return army[y] - army[x]; });
        ks.forEach(function (k) { r[k] = Math.floor(army[k] * cap / t); sum += r[k]; });
        if (sum < cap) r[ks[0]] += cap - sum;
        return r;
    }
    function strongest(army, facts) { return keys(army).filter(function (t) { return t !== "Swordsman" && t !== "Recruit"; })
        .sort(function (x, y) { return unitValue(facts, y) - unitValue(facts, x) || army[y] - army[x]; })[0] || keys(army)[0]; }
    function variants(waves, facts, ch) {
        var out = [{ label: "as the author", waves: waves }], last = waves.length - 1;
        function clone(ws) { return ws.map(function (w) { return { g: w.g, army: copy(w.army), entry: w.entry }; }); }
        var fullFront = clone(waves), changed = false;
        fullFront.forEach(function (w, i) { if (i === last) return; var t = keys(w.army).sort(function (x, y) { return w.army[y] - w.army[x]; })[0];
            if (t && ch.waveMayLose.indexOf(t) >= 0 && total(w.army) < w.g.cap) { w.army = {}; w.army[t] = w.g.cap; changed = true; } });
        if (changed) out.push({ label: "front at full capacity", waves: fullFront });
        [waves, changed ? fullFront : null].forEach(function (base) {
            if (!base) return;
            var m = base[last], cap = m.g.cap, top = strongest(m.army, facts);
            for (var step = 1; step <= 5; step++) {
                var ws = clone(base), a = ws[last].army, sw = Math.round(cap * 0.1 * step), t0 = total(a);
                a.Swordsman = (a.Swordsman || 0) + sw;
                var over = total(a) - cap; if (over > 0 && top && top !== "Swordsman") a[top] = Math.max(0, a[top] - over);
                if (total(a) > cap) a.Swordsman -= total(a) - cap;
                if (total(a) >= t0 - 1) out.push({ label: (base === waves ? "" : "front at full capacity, ") + "main +" + sw + " Swordsman", waves: ws });
            }
            var ws2 = clone(base), a2 = ws2[last].army; if (top && total(a2) < cap) { a2[top] = (a2[top] || 0) + cap - total(a2);
                out.push({ label: (base === waves ? "" : "front at full capacity, ") + "main at full capacity (" + top + ")", waves: ws2 }); }
        });
        if (ch.units && ch.units.length) out = out.filter(function (v) { return v.waves.every(function (w) { return keys(w.army).every(function (u) { return !w.army[u] || ch.units.indexOf(u) >= 0; }); }); });   // 0.7.2
        return out;
    }
    function judge(e, waves, ch) {
        var bad = [];
        e.perWave.forEach(function (p, i) { var may = i === waves.length - 1 ? ch.mainMayLose : ch.waveMayLose;
            each(p.bad, function (t, v) { if (v > 0 && may.indexOf(t) < 0) bad.push(waves[i].g.short + " loses " + v + " " + t); }); });
        return { ok: e.win >= ch.minWin && !bad.length, bad: bad };
    }

    /* ---------- 0.4.0: from scratch (ADR 0094 addendum 17:22) ---------- */
    function campWeight(facts, army) { var w = 0; (army || []).forEach(function (u) { var f = facts.units[u[0]]; w += (Number(u[1]) || 0) * (f && f.hp ? f.hp : 1); }); return w; }
    function scratchCamps(A) {
        var out = [], W = Number(A.zoneWidth) || 68;
        if (A.camps && keys(A.camps).length) each(A.camps, function (g, army) { out.push({ grid: Number(g), army: army, name: (A.campNames && A.campNames[g]) || "camp" }); });
        else each(A.campsXY || {}, function (k, v) { var p = k.split(","); out.push({ grid: Number(p[1]) * W + Number(p[0]), army: v[1], name: v[0] }); });
        return out.filter(function (c) { return c.army && c.army.length; });
    }
    function scratchJob(input, ch) {
        var S = input.sim || root.DMA_BattleSim, SV = input.solver || root.DMA_CampSolver, facts = input.facts, A = input.adventure || {}, abbr = A.abbr || "MY";
        if (!S || !SV || !facts) return doneJob({ files: [], findings: [finding("error", "NO_FACTS", 0, "the battle simulator, the camp solver or the unit facts are missing.", "")] });
        var specs = specOfType(facts), reserve = (input.reserve || []).map(String), avoid = {};
        each(ch.avoid || {}, function (u, w) { avoid[u] = Number(w) || 1; }); each(ch.maxLoss || {}, function (u) { avoid[u] = Math.max(avoid[u] || 0, 100); });
        var mine = (input.myGenerals || []).map(function (g) { return profile(facts, specs, S, g); }).filter(function (m) { return m && m.general && reserve.indexOf(m.id) < 0; });
        var camps = scratchCamps(A).sort(function (x, y) { return campWeight(facts, y.army) - campWeight(facts, x.army) || x.grid - y.grid; });
        /* 0.6.1: known landing fields — nearest the landing first, at most one general per field in a round */
        var LG = ((A.landing && A.landing.grids) || []).map(Number).filter(function (g) { return g > 0; }), WL = Number(A.zoneWidth) || 68;
        if (LG.length) { var cx = 0, cy = 0; LG.forEach(function (g) { cx += g % WL; cy += Math.floor(g / WL); }); cx /= LG.length; cy /= LG.length;
            var dL = function (g) { return Math.max(Math.abs(g % WL - cx), Math.abs(Math.floor(g / WL) - cy)); };
            camps.sort(function (x, y) { return dL(x.grid) - dL(y.grid) || x.grid - y.grid; }); }
        /* 0.7.0: the camps that stand in the way (adventure.blocks {camp: [camps on its path from the landing]}, learned by the
           executor from the game's interception picture) fall first: a camp comes after every living camp on its path */
        var BL = A.blocks || {};
        if (keys(BL).length) { var inPlan = {}; camps.forEach(function (c) { inPlan[c.grid] = 1; }); var outC = [], doneC = {};
            (function visit(list) { list.forEach(function (c) { if (doneC[c.grid]) return; doneC[c.grid] = -1;
                visit((BL[c.grid] || []).map(Number).filter(function (b) { return inPlan[b] && doneC[b] !== -1; }).map(function (b) { return camps.filter(function (x) { return x.grid === b; })[0]; }));
                doneC[c.grid] = 1; outC.push(c); }); })(camps.slice());
            camps = outC; }
        var cp = campPlan(camps, A, ch, input.star);   // 0.8.0 (B14 beta): quick loot and destroy arrows
        camps = cp.camps;
        var F = cp.findings.slice(), rounds = [{}], used = [{}], defeats = {}, order = [0], skipped = [], ci = 0, maxRounds = Number(ch.maxRounds) || 6, rbq = { regular: 0, elite: 0 };   // 0.6.0
        function available(m) { var d = defeats[m.id] || 0; return d === 0 || (m.recoverOnce && d === 1); }
        function solve(c, ri) {
            var free = mine.filter(function (m) { return !used[ri][m.id] && available(m); });
            if (!free.length) return null;
            var sol = SV.solveCamp(S, facts, c.army, free, { iterations: ch.iterations, minWin: ch.minWin, quantile: ch.quantile, mainMayLose: ch.mainMayLose, waveMayLose: ch.waveMayLose,
                eliteUnits: A.eliteUnits !== false, unitCost: input.unitCost, seed: 31 + c.grid, objective: ch.objective === "author" ? "cheapest" : ch.objective, avoid: avoid,
                barracks: ch.barracks, rebuildBase: copy(rbq), units: ch.units || undefined });
            return sol.ok ? sol : null;
        }
        var job = { done: false, result: null, total: camps.length + 1, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (ci >= camps.length) { job.result = finish(); job.done = true; return true; }
            var c = camps[ci++], ri, sol = null;
            function fits(s0, r0) { return !s0 || !LG.length || keys(used[r0]).length + s0.best.waves.length <= LG.length; }   // 0.6.1
            for (ri = 0; ri < rounds.length && !sol; ri++) { sol = solve(c, ri); if (sol && !fits(sol, ri)) sol = null; if (sol) break; }
            if (!sol && rounds.length < Math.max(maxRounds, LG.length ? camps.length : 0)) { rounds.push({}); used.push({}); order.push(0); ri = rounds.length - 1; sol = solve(c, ri); }
            if (!sol) { skipped.push(c); F.push(finding("error", "CAMP_NOT_SOLVED", 4, "camp " + c.name + " (" + c.grid + "): none of your free generals takes it (" + fmt(armyOf(c.army)) + ").",
                "Skill or free more generals, or play this camp yourself.")); return false; }
            rbq.regular += sol.best.metrics.rebuildRegular || 0; rbq.elite += sol.best.metrics.rebuildElite || 0;   // 0.6.0
            sol.best.waves.forEach(function (w, i) {
                var m = mine.filter(function (x) { return x.id === String(w.id); })[0]; used[ri][m.id] = 1;
                if (w.beaten > 0.5 && i < sol.best.waves.length - 1) defeats[m.id] = (defeats[m.id] || 0) + 1;
                var spot = LG.length ? LG[keys(rounds[ri]).length % LG.length] : c.grid;   // 0.6.1: a landing field of its own
                rounds[ri][key(m.id)] = { grid: spot, name: m.name, order: order[ri]++, time: 1000, skills: {}, army: copy(w.army), type: m.type, target: c.grid, targetName: c.name };
            });
            return false;
        } };
        function armyOf(a) { var r = {}; (a || []).forEach(function (u) { r[u[0]] = u[1]; }); return r; }
        function finish() {
            var load = {}, lo = 0;
            rounds.forEach(function (r) { each(r, function (k, e) { if (load[k]) return; load[k] = { grid: e.grid, name: e.name, order: lo++, time: 1000, skills: {}, army: copy(e.army), type: e.type, target: null, targetName: null }; }); });
            var files = [{ name: abbr + " load", text: JSON.stringify(load) }];
            /* 0.7.0 (author 2026-11-23: "als een generaal zijn kamp verslagen heeft en hij is de rest van het avontuur niet meer nodig,
               dan kun je hem naar huis sturen, als hij alleen de volgende aanval niet meer nodig is en je hebt zijn landingsspot nodig,
               dan kun je hem opzij zetten of zelfs naar star"; "Dat gehele plan moet onderdeel uitmaken van je mundanes vooraf"):
               with landing fields known, every round names what happens to the generals still on a field: needed again later ->
               to the star (grid -1), not needed again -> home (home: true); both before the round's attackers */
            if (LG.length) { var pos = {};
                rounds.forEach(function (r, ri) {
                    var atk = keys(r), freeMoves = [];
                    /* a general that attacks again keeps the field it stands on; the others take the free fields — no swaps */
                    var taken = {}; atk.forEach(function (k) { if (pos[k] > 0 && !taken[pos[k]]) { r[k].grid = pos[k]; taken[pos[k]] = 1; } else r[k].grid = 0; });
                    atk.forEach(function (k) { if (r[k].grid > 0) return; var f = LG.filter(function (g) { return !taken[g]; })[0]; r[k].grid = f; taken[f] = 1; });
                    keys(pos).forEach(function (k) { if (!(pos[k] > 0) || atk.indexOf(k) >= 0) return;
                        var later = rounds.slice(ri + 1).some(function (r2) { return !!r2[k]; }), m = mine.filter(function (x) { return key(x.id) === k; })[0];
                        freeMoves.push(k); r[k] = { grid: -1, name: m ? m.name : k, order: -1, time: 1000, skills: {}, army: {}, type: m ? m.type : null, target: null, targetName: null, home: !later, plan: later ? "star" : "home" }; pos[k] = 0; });
                    keys(r).sort(function (a, b) { return (r[a].order < 0 ? -1 : 0) - (r[b].order < 0 ? -1 : 0) || r[a].order - r[b].order; }).forEach(function (k, i) { r[k].order = i; });
                    atk.forEach(function (k) { pos[k] = r[k].grid; });
                    if (freeMoves.length) F.push(finding("info", "FIELDS_FREED", 4, "round " + (ri + 1) + ": " + freeMoves.length + " general(s) leave their landing field first (" +
                        freeMoves.map(function (k) { return strip(r[k].name).split(" ")[0] + " " + r[k].plan; }).join(", ") + ").", ""));
                });
                rounds.forEach(function (r, ri) { var last = ri === rounds.length - 1; if (!last) return;
                    keys(pos).forEach(function (k) { /* after the last round the run closes and everyone goes home */ }); }); }
            rounds.forEach(function (r, i) { if (keys(r).length) files.push({ name: abbr + " attack " + ("0" + (i + 1)).slice(-2), text: JSON.stringify(r) }); });
            var side = { format: "dma-shared-generals/1", source: "user_dma_mundane_gen " + VERSION + " (from scratch)", generals: {} };
            mine.forEach(function (m) { if (!load[key(m.id)]) return; var sk = {}; each(m.skills, function (n, l) { sk["Skill_" + n] = l; }); side.generals[key(m.id)] = { name: m.short, type: m.type, skills: sk }; });
            files.push({ name: "generals.json", text: JSON.stringify(side) });
            F.unshift(finding("info", "SCRATCH", 4, "made from scratch: " + camps.length + " camps from " + (A.campsSource || (A.camps && keys(A.camps).length ? "the game" : "an online source")) + ", " + (camps.length - skipped.length) +
                " solved with your generals in " + rounds.filter(function (r) { return keys(r).length; }).length + " round(s) for objective " + ch.objective + "; the order on the island is found while playing (kind: without blocks).", ""));
            return { files: files, findings: F, skipped: skipped.concat(cp.notTaken), arrows: cp.arrows };
        }
        return job;
    }

    /* ---------- generate ---------- */
    function generate(input) { var j = generateJob(input); while (!j.step()) {} return j.result; }
    /* step B (ADR 0094): when the author's way beats more generals than the player has (GENERAL_OUT), a second plan plays the
       camps a general takes alone without a wave; the plan that leaves the fewest problems is kept */
    function generateJob(input) {
        var ch = copy(CHOICES); each(input.choices || {}, function (k, v) { ch[k] = v; });
        if (ch.objective === "sameType") return doneJob(sameType(input, ch));   // 0.8.6: mode 2, the author's plan 1:1 with my generals of his types
        if (input.scratch || !(input.files && input.files.length)) return fromScratchJob(input, ch);
        var j1 = onceJob(input, ch), j2 = null;
        function errs(x) { return x.findings.filter(function (f) { return f.level === "error"; }).length; }
        function solved(x) { return x.phases ? x.phases[3].solved : 0; }
        var job = { done: false, result: null, total: j1.total, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (!j1.done) { j1.step(); return false; }
            var r = j1.result;
            if (!j2 && ch.spareGenerals === "auto" && r.findings && r.findings.some(function (f) { return f.code === "GENERAL_OUT"; })) {
                var ch2 = copy(ch); ch2.spareGenerals = true; j2 = onceJob(input, ch2); job.total += j2.total; }
            if (j2 && !j2.done) { j2.step(); return false; }
            var r2 = j2 && j2.result;
            if (r2 && (solved(r2) > solved(r) || (solved(r2) === solved(r) && errs(r2) < errs(r)))) {
                r2.findings.unshift(finding("info", "SPARE_GENERALS", 4, "your generals do not last for the author's waves (a beaten general is out unless it recovers once): camps a general takes alone are played without a wave. " +
                    solved(r2) + " camps solved instead of " + solved(r) + ".", "The losses per run differ from the author's: see phase 1."));
                r = r2;
            }
            job.result = r; job.done = true; return true;
        } };
        return job;
    }
    /* 0.4.0: the made templates go through the five phases like a shared Mundane: the player's own generals map to themselves,
       the camp solver's armies are kept (asIs), and the result says it was made from scratch, kind "without blocks" */
    function fromScratchJob(input, ch) {
        var sj = scratchJob(input, ch), oj = null, A = input.adventure || {};
        var job = { done: false, result: null, total: sj.total + 30, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (!sj.done) { sj.step(); return false; }
            if (ch.arrowsOnly) {   // 0.8.0 (B14 beta): a plan of arrows only is the arrows run's per-camp plan
                var pl = {}; (sj.result.arrows || []).forEach(function (a) { pl["#" + a.grid] = [{ arrow: a.def, max: 1 }]; });
                job.result = { version: VERSION, ok: !sj.result.findings.some(function (f) { return f.level === "error"; }), scratch: true, kind: "arrows only", plan: pl, files: [], findings: sj.result.findings,
                               choices: ch, settings: {}, beta: true, phases: null, arrows: sj.result.arrows };
                job.done = true; return true;
            }
            if (!oj) {
                var A2 = copy(A), W = Number(A.zoneWidth) || 68;
                if (!(A.camps && keys(A.camps).length) && A.campsXY) { A2.camps = {}; A2.campNames = copy(A.campNames);
                    each(A.campsXY, function (k, v) { var p = k.split(","), g = Number(p[1]) * W + Number(p[0]); A2.camps[g] = v[1]; if (!A2.campNames[g]) A2.campNames[g] = v[0]; }); A2.campsXY = null; }
                var inp = copy(input); inp.files = sj.result.files; inp.adventure = A2; inp.scratch = false;
                var ch2 = copy(ch); ch2.objective = "author"; ch2.spareGenerals = false; ch2.asIs = true;
                oj = onceJob(inp, ch2); job.total = sj.total + oj.total; return false;
            }
            if (!oj.done) { oj.step(); return false; }
            var r = oj.result; r.findings = sj.result.findings.concat(r.findings || []); r.ok = r.ok && !sj.result.skipped.length;
            r.scratch = true; r.kind = "without blocks"; r.choices = ch; if (r.phases) r.phases[3].objective = ch.objective;
            if (sj.result.arrows && sj.result.arrows.length) {   // 0.8.0 (B14 beta): the arrows go first in the first attack, in their own place
                r.beta = true; r.arrows = sj.result.arrows; r.findings = sj.result.findings.filter(function (f) { return f.code === "ARROWS" || f.code === "QUICKLOOT" || f.code === "QUICKLOOT_UNKNOWN"; }).concat(r.findings || []);
                var fa = (r.files || []).filter(function (f) { return / attack 01$/.test(f.name); })[0], ae = arrowEntries(sj.result.arrows);
                if (!fa) { fa = { name: (A.abbr || "MY") + " attack 01", text: "{}" }; r.files = (r.files || []).concat([fa]); }
                var t1 = JSON.parse(fa.text), n = keys(ae).length, o2 = {}; each(ae, function (k, v) { o2[k] = v; }); each(t1, function (k, v) { v.order = (Number(v.order) || 0) + n; o2[k] = v; }); fa.text = JSON.stringify(o2);
            } else if (sj.result.findings.some(function (f) { return /^QUICKLOOT/.test(f.code); })) r.findings = sj.result.findings.filter(function (f) { return /^QUICKLOOT/.test(f.code); }).concat(r.findings || []);
            if (r.phases) sj.result.skipped.forEach(function (c) { r.phases[3].camps.push({ round: 0, grid: c.grid, name: c.name, attackers: [], result: "NOT_SOLVED" }); r.phases[3].notSolved++; });
            { var seenF = {}; r.findings = (r.findings || []).filter(function (f) { var k = f.code + "|" + f.text; if (seenF[k]) return false; seenF[k] = 1; return true; }); }   // 0.8.0 (live test): each finding once
            job.result = r; job.done = true; return true;
        } };
        return job;
    }

    /* 0.8.6 (author 2026-11-27 11:00 and 11:03): the four ways to play a Mundane are (1) an existing Mundane 1:1, (2) an existing
       Mundane 1:1 with my own generals of the same types, (3) an existing Mundane with my own generals, of other types too (the
       objective "author", "Use with my generals"), (4) my own Mundane (Make new). This is (2): "als een mundane van een andere speler
       dezelfde type generaals vraagt die jezelf ook hebt, mag je deze generaals ... vervangen door een generaal van dat type,
       volledig geskilled". Every author general is replaced by one of the player's generals of the same type - the most skilled
       one, the author's busiest general first; nothing else changes: spots, armies, targets, order, delays, arrows, the files. No
       camp is re-planned. A type the player lacks, or a general who cannot carry the author's army, is an error: the plan is then
       not playable 1:1 and way (3) is the one to use. */
    function sameType(input, ch) {
        var F = [], facts = input.facts, S = input.sim || root.DMA_BattleSim, specs = facts ? specOfType(facts) : {};
        var files = [], side = null;
        (input.files || []).forEach(function (f) { var d = null; try { d = JSON.parse(String(f.text)); } catch (_) { d = null; }
            if (d && d.format === "dma-shared-generals/1") side = d; else if (d && typeof d === "object") files.push({ name: f.name, d: d }); });
        var authors = {}, order = [];
        files.forEach(function (f) { each(f.d, function (k, e) { if (!e || e.type === "buff" || !(Number(e.grid) || e.target)) return;
            var a = authors[k] || (authors[k] = { key: k, type: Number(e.type), name: shortName(e.name), army: 0, uses: 0 });
            if (!a.uses) order.push(k); a.uses++; a.army = Math.max(a.army, total(e.army)); }); });
        var mine = (input.myGenerals || []).map(function (g) { return profile(facts, specs, S, g); }).filter(function (m) { return m && m.general; });
        var reserve = (ch.reserve || []).map(String), used = {}, map = {}, rows = [];
        order.slice().sort(function (x, y) { return authors[y].army - authors[x].army || authors[y].uses - authors[x].uses; }).forEach(function (k) {
            var a = authors[k], same = mine.filter(function (m) { return m.type === a.type && !used[m.id] && reserve.indexOf(String(m.id)) < 0; });
            if (idOf(k) && same.some(function (m) { return m.id === idOf(k); })) same = same.filter(function (m) { return m.id === idOf(k); });   // his own general (the author plays it himself)
            var m = same.sort(function (x, y) { return (y.cap >= a.army ? 1 : 0) - (x.cap >= a.army ? 1 : 0) || total(y.skills) - total(x.skills) || y.cap - x.cap; })[0];
            if (!m) { rows.push({ from: k, fromName: a.name, type: a.type, outcome: "MISSING" });
                F.push(finding("error", "NO_GENERAL_OF_TYPE", 1, "no general of yours of the type of the author's " + a.name + " (type " + a.type + (specs[a.type] ? ", " + specs[a.type].name : "") + ") is free.",
                    "Use \"Use with my generals\" (other types allowed) or get a general of this type.")); return; }
            used[m.id] = 1; map[k] = m; rows.push({ from: k, fromName: a.name, type: a.type, to: m.id, toName: m.short, cap: m.cap, skills: total(m.skills), outcome: m.id === idOf(k) ? "SAME" : "SAME_TYPE" });
            if (m.cap < a.army) F.push(finding("error", "CAPACITY_SHORT", 1, m.short + " holds " + m.cap + ", the author's " + a.name + " brings " + a.army + ": 1:1 is not possible.", "Skill " + m.short + "'s capacity (Garrison Annex), or use \"Use with my generals\"."));
        });
        var out = files.map(function (f) { var t = {};
            each(f.d, function (k, e) { var m = map[k]; if (!m) { t[k] = e; return; }
                var c = copy(e); c.name = m.name; c.type = m.type; t[key(m.id)] = c; });
            return { name: f.name, text: JSON.stringify(t) }; });
        var gj = { format: "dma-shared-generals/1", source: "user_dma_mundane_gen " + VERSION + " (same type)", generals: {}, allIds: mine.map(function (m) { return m.id; }) };
        each(map, function (k, m) { var sk = {}; each(m.skills, function (n, l) { sk["Skill_" + n] = l; }); gj.generals[key(m.id)] = { name: m.short, type: m.type, skills: sk }; });
        out.push({ name: "generals.json", text: JSON.stringify(gj, null, 1) });
        var camps = {}; files.forEach(function (f) { each(f.d, function (k, e) { if (e && e.target) camps[e.target] = 1; }); });
        var ok = !F.some(function (f) { return f.level === "error"; });
        if (ok) F.push(finding("info", "SAME_TYPE", 1, keys(map).length + " general(s) of the author replaced 1:1 by yours of the same type: " + rows.map(function (r) { return r.fromName + " → " + r.toName; }).join(", ") + ". Spots, armies, order and delays are the author's.", ""));
        return { version: VERSION, ok: ok, kind: "full", source: "the author's plan 1:1, my generals of his types", files: out, findings: F, mapping: rows, settings: {},
                 phases: [{ phase: 1, lossesPerRun: {} }, null, null, { solved: ok ? keys(camps).length : 0, camps: keys(camps).map(function (c) { return { grid: Number(c), result: ok ? "AS_WRITTEN" : "NOT_PLAYABLE" }; }), totals: {} }] };
    }
    /* several versions of one adventure, one per objective (ADR 0094 addendum 10:47): the player compares and picks */
    var ALL_OBJECTIVES = ["author", "cheapest", "fewestLosses", "fastest", "spareGenerals", "mostXP", "quickestRebuild"];
    var SCENARIOS = ["quickLoot", "arrowsOnly"];   // 0.8.0 (B14 beta): scenarios besides the objectives
    function summary(obj, r) { var t = r.phases ? r.phases[3].totals : {};
        if (r.kind === "arrows only") return { objective: obj, ok: r.ok, solved: (r.arrows || []).length, camps: (r.arrows || []).length + ((r.findings || []).some(function (f) { return f.code === "ARROWS_SHORT"; }) ? 1 : 0),
                 lossesBad: {}, cost: null, seconds: 0, xp: 0, units: {}, defeats: 0, rebuild: 0, beta: true, result: r };
        return { objective: obj, ok: r.ok, solved: r.phases ? r.phases[3].solved : 0, camps: r.phases ? r.phases[3].camps.length : 0,
                 lossesBad: r.phases ? r.phases[0].lossesPerRun : {}, cost: r.cost, seconds: t.seconds, xp: t.xp, units: t.units, defeats: t.defeats, rebuild: t.rebuild, result: r }; }
    function versionsJob(input, objectives) {
        var list = objectives || ALL_OBJECTIVES, i = 0, cur = null, out = [];
        function make(obj) { var inp = copy(input), c = copy(input.choices || {}); c.objective = obj;
            /* 0.8.0 (B14 beta): the scenarios that are not a camp solver's objective */
            if (obj === "quickLoot") { c.quickLoot = true; c.objective = "fastest"; }
            if (obj === "arrowsOnly") { c.arrowsOnly = true; c.objective = "fastest"; }
            inp.choices = c; return generateJob(inp); }
        var job = { done: false, result: null, total: 0, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (!cur) { if (i >= list.length) { job.result = out; job.done = true; return true; } cur = make(list[i]); job.total += cur.total; return false; }
            if (!cur.done) { cur.step(); return false; }
            out.push(summary(list[i], cur.result)); i++; cur = null; return false;
        } };
        job.total = list.length * 30;                       // a first guess, corrected as each version starts
        return job;
    }
    function generateVersions(input, objectives) { var j = versionsJob(input, objectives); while (!j.step()) {} return j.result; }

    /* re-analysis (ADR 0094 addendum 11:01; author: "Daarnaast kan een speler een nieuwe general krijgen of een bestaande skillen en
       moet hij een bestaande mundane opnieuw kunnen analyseren en eventueel verbeteren"): a version's folder carries the generals it
       was made for (generals.json); the generals now (dma-skills.json) are compared with them — NEW, SKILLED (which skills), GONE —
       and the version is planned twice, for the generals then and now; when the plan for now is better (more camps, or the
       objective's measure lower) it is offered as the improvement. fingerprint() lets the client see that the generals changed. */
    function fingerprint(myGenerals) {
        return (myGenerals || []).map(function (g) { var sk = skillMap(g.skills); return idOf(g.id) + ":" + g.type + ":" + keys(sk).sort().map(function (k) { return k + sk[k]; }).join(","); }).sort().join("|");
    }
    function rosterOf(sidecar) {
        var r = []; each((sidecar && sidecar.generals) || {}, function (k, g) { r.push({ id: idOf(k), name: "<b>" + (g.name || k) + "</b>", type: g.type, skills: g.skills || {} }); }); return r;
    }
    function generalChanges(then, now) {
        var a = {}, b = {}, out = { added: [], skilled: [], gone: [] };
        then.forEach(function (g) { a[idOf(g.id)] = g; }); now.forEach(function (g) { b[idOf(g.id)] = g; });
        each(b, function (id, g) { var t = a[id]; if (!t) { out.added.push({ id: id, name: shortName(g.name), type: g.type }); return; }
            var s0 = skillMap(t.skills), s1 = skillMap(g.skills), ch = [];
            keys(s0).concat(keys(s1)).forEach(function (k) { if ((s0[k] || 0) !== (s1[k] || 0) && ch.indexOf(k) < 0) ch.push(k + " " + (s0[k] || 0) + "→" + (s1[k] || 0)); });
            if (ch.length) out.skilled.push({ id: id, name: shortName(g.name), skills: ch }); });
        each(a, function (id, g) { if (!b[id]) out.gone.push({ id: id, name: shortName(g.name), type: g.type }); });
        return out;
    }
    function reanalyseJob(input) {
        var side = null; (input.files || []).forEach(function (f) { try { var d = JSON.parse(String(f.text)); if (d && d.format === "dma-shared-generals/1") side = d; } catch (e) {} });
        var then = rosterOf(side), now = input.myGenerals || [], changes = generalChanges(then, now);
        var nChanged = changes.added.length + changes.skilled.length + changes.gone.length;
        /* to improve, the camps must be planned again with the generals now: without an objective of the player's, "cheapest"
           (the author's own order only re-plans camps it cannot take); both plans use the same objective, so they compare */
        var obj = (input.choices && input.choices.objective) || (nChanged ? "cheapest" : "author");
        var inp = copy(input), c = copy(input.choices || {}); c.objective = obj; inp.choices = c;
        var jb = side ? generateJob(withGenerals(inp, then)) : null, ja = generateJob(inp);
        var job = { done: false, result: null, total: (jb ? jb.total : 0) + ja.total, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (jb && !jb.done) { jb.step(); return false; }
            if (!ja.done) { ja.step(); return false; }
            var before = jb ? summary(obj, jb.result) : null, after = summary(obj, ja.result), better = false, why = [];
            if (before) {
                if (after.solved > before.solved) { better = true; why.push((after.solved - before.solved) + " camp(s) more"); }
                else if (after.solved === before.solved) {
                    var SV = input.solver || root.DMA_CampSolver;
                    var mb = { cost: total(before.cost.perRunMean), units: before.units || 0, seconds: before.seconds || 0, defeats: before.defeats || 0, xp: before.xp || 0, generals: 0, avoided: 0 };
                    var ma = { cost: total(after.cost.perRunMean), units: after.units || 0, seconds: after.seconds || 0, defeats: after.defeats || 0, xp: after.xp || 0, generals: 0, avoided: 0 };
                    var rb = SV ? SV.rank(mb, obj) : mb.cost, ra = SV ? SV.rank(ma, obj) : ma.cost;
                    if (ra < rb * 0.98) { better = true; why.push(obj + ": " + Math.round(rb) + " → " + Math.round(ra)); }
                }
            }
            var changed = changes.added.length + changes.skilled.length + changes.gone.length;
            job.result = { version: VERSION, objective: obj, changed: changed > 0, changes: changes, before: before, after: after, improved: better, why: why,
                           advice: !side ? "the folder has no generals.json: planned for your generals now, nothing to compare with." :
                                   !changed ? "your generals are the same as when this version was made." :
                                   better ? "your generals changed and the plan improves (" + why.join("; ") + "): save it as a new version." :
                                   "your generals changed; the plan does not improve: keep the version as it is.",
                           result: ja.result };
            job.done = true; return true;
        } };
        return job;
    }
    function withGenerals(input, roster) { var x = copy(input); x.myGenerals = roster; return x; }
    function reanalyse(input) { var j = reanalyseJob(input); while (!j.step()) {} return j.result; }

    /* the calculation phase (ADR 0094 addendum 10:59; author: "Geef de speler de mogelijkheid om te kiezen voor een mundane
       rekenfase, waarbij hij bewust kiest om dat even voorrang te geven op alles, anders vindt het plaats op de achtergrond"):
       background — short slices with pauses, the other roles go on; priority — long slices, and the player's chosen hold on the
       blue work at home (control's visit hold) while it runs, released when it is done or cancelled. The mode can change while it
       runs. opts: {mode, setTimeout, now, control, onProgress(done, total, mode), onDone(result), sliceMs, pauseMs} */
    var MODES = { background: { sliceMs: 40, pauseMs: 500 }, priority: { sliceMs: 1000, pauseMs: 0 } };
    function calculate(job, opts) {
        opts = opts || {};
        var st = opts.setTimeout || (typeof setTimeout !== "undefined" ? setTimeout : null), now = opts.now || function () { return new Date().getTime(); };
        var mode = MODES[opts.mode] ? opts.mode : "background", cancelled = false, held = false, finished = false;
        function hold(on) {
            var c = opts.control && opts.control.visit; if (!c) return;
            try { if (on && !held) { c.request("mundane generator", "calculation phase chosen by the player"); held = true; }
                  else if (!on && held) { c.close("mundane calculation " + (cancelled ? "cancelled" : mode === "priority" ? "done" : "back to background")); held = false; } } catch (e) { held = false; }
        }
        function tick() {
            if (cancelled || finished) return;
            var m = MODES[mode], t0 = now(), sl = mode === "priority" ? (opts.prioritySliceMs || m.sliceMs) : (opts.sliceMs || m.sliceMs);
            while (!job.done && now() - t0 < sl) job.step();
            if (opts.onProgress) try { opts.onProgress(Math.min(job.at, job.total), Math.max(job.total, job.at), mode); } catch (e) {}
            if (job.done) { finished = true; hold(false); if (opts.onDone) opts.onDone(job.result); return; }
            st(tick, mode === "priority" ? 0 : (opts.pauseMs != null ? opts.pauseMs : m.pauseMs));
        }
        if (mode === "priority") hold(true);
        if (st) st(tick, 0); else { while (!job.done) job.step(); finished = true; hold(false); if (opts.onDone) opts.onDone(job.result); }
        return {
            mode: function () { return mode; },
            setMode: function (m) { if (!MODES[m] || m === mode) return mode; mode = m; hold(m === "priority"); return mode; },
            cancel: function () { if (finished) return false; cancelled = true; hold(false); return true; },
            progress: function () { return { done: job.at, total: Math.max(job.total, job.at), finished: finished, cancelled: cancelled, mode: mode }; }
        };
    }

    function generateOnce(input, ch) { var j = onceJob(input, ch); while (!j.step()) {} return j.result; }
    function doneJob(r) { return { done: true, result: r, total: 0, at: 0, step: function () { return true; } }; }
    /* one plan as a job of small steps (0.3.0): a round's set-up, one camp, a round's end, the rest — so a caller can run it in
       slices in the background or with priority (ADR 0094 addendum 10:59) */
    function onceJob(input, ch) {
        var M = input.mundane || root.DMA_Mundane, S = input.sim || root.DMA_BattleSim, SV = input.solver || root.DMA_CampSolver, facts = input.facts;
        var A = input.adventure || {}, F = [], abbr = A.abbr || "MY", avoid = {};
        each(ch.avoid || {}, function (u, w) { avoid[u] = Number(w) || 1; }); each(ch.maxLoss || {}, function (u) { avoid[u] = Math.max(avoid[u] || 0, 100); });
        if (!M || !S || !SV || !facts) return doneJob({ version: VERSION, ok: false, findings: [finding("error", "NO_FACTS", 0, "the Mundane advisor, the battle simulator, the camp solver or the unit facts are missing.", "Load user_dma_mundane.js, user_dma_battlesim.js and user_dma_camp_solver.js; read the unit facts first.")] });
        var specs = specOfType(facts), ctx = { reserve: (input.reserve || []).map(String) };
        var mine = (input.myGenerals || []).map(function (g) { return profile(facts, specs, S, g); }).filter(Boolean);
        var run = readRun(M, input.files || [], input.myGenerals);
        if (!run.rounds.length) return doneJob({ version: VERSION, ok: false, findings: [finding("error", "NO_ROUNDS", 4, "the folder has no attack template.", "Choose the shared Mundane folder of this adventure.")] });
        if (!run.side) F.push(finding("warn", "NO_SIDECAR", 4, "the folder has no generals.json: the author's skills are not known, so a stand-in of the same type counts as equal.", "Ask for the shared folder with its generals.json."));
        /* 0.3.2: camps given by coordinates ("x,y", an online source such as tsowiki) are turned into grids with the zone width
           that maps every target of the templates onto a camp (as mundane.js does); camps the game showed (by grid) win */
        if (A.campsXY && !(A.camps && keys(A.camps).length)) {
            var tg = []; run.rounds.forEach(function (t) { t.generals.forEach(function (g) { if (g.target && tg.indexOf(Number(g.target)) < 0) tg.push(Number(g.target)); }); });
            var xy = keys(A.campsXY), W = 0;
            for (var w = 20; w < 400 && !W && tg.length; w++) if (tg.every(function (g) { return A.campsXY[(g % w) + "," + Math.floor(g / w)]; })) W = w;
            if (W) { A = copy(A); A.camps = {}; A.campNames = A.campNames || {};
                xy.forEach(function (k) { var p = k.split(","), g = Number(p[1]) * W + Number(p[0]); A.camps[g] = A.campsXY[k][1]; if (!A.campNames[g]) A.campNames[g] = A.campsXY[k][0]; });
                F.push(finding("info", "CAMPS_ONLINE", 4, "the camps' armies come from " + (A.campsSource || "an online source") + " (zone width " + W + "): the game has not shown this adventure's camps yet.", "Open the adventure once; then the game's own camps are used.")); }
            else F.push(finding("warn", "CAMPS_ONLINE", 4, "the online camps do not match the templates' targets: camps not simulated.", "Open the adventure once so the game shows its camps."));
        }
        var mp = mapGenerals(run, mine, ctx), defeats = {}, budgetInfo = null;
        /* ADR 0094 addendum 09:19/10:04: a beaten general is out for the adventure, unless it has Instant Recovery (YGG, Ghost
           or the skill): recovered on return to its start position, once per adventure */
        function available(m) { var d = defeats[m.id] || 0; return d === 0 || (m.recoverOnce && d === 1); }
        function beaten(m) { defeats[m.id] = (defeats[m.id] || 0) + 1; }
        var outcomeOf = {}; mp.rows.forEach(function (r) { outcomeOf[r.from] = r.outcome; });   // 0.8.6: author general id -> SAME / EQUAL / SKILLS_DIFFER / ...
        mp.rows.forEach(function (r) { if (r.outcome === "MISSING") F.push(finding("error", "NO_GENERAL", 4, "no general of yours is left for " + r.fromName + " (" + r.role + ").", "Free a general (reserve) or get one more general.")); });

        /* phase 4: per round, per camp */
        var roundsOut = [], camps = [], lossMean = {}, lossBad = {}, perRound = [], firstArmy = {}, notSolved = [];
        var roundFns = run.rounds.map(function (t, ri) { return function () {
            var byCamp = {}, campOrder = [], entries = {}, rl = { mean: {}, bad: {} };
            t.generals.forEach(function (g) { if (g.target) { if (!byCamp[g.target]) { byCamp[g.target] = []; campOrder.push(g.target); } byCamp[g.target].push(g); } });
            var inRound = {};
            t.generals.forEach(function (g) { var m = mp.map[g.id]; if (m) inRound[m.id] = 1; });
            function free(not) { return mine.filter(function (m) { return m.general && !inRound[m.id] && available(m) && ctx.reserve.indexOf(m.id) < 0 && (!not || !not[m.id]); }); }
            return { camps: campOrder.slice(), camp: function (grid) {
                var gs = byCamp[grid].sort(function (x, y) { return x.order - y.order; });
                var name = (A.campNames && A.campNames[grid]) || gs[0].targetName || "camp";
                var waves = gs.map(function (g, i) {
                    var m = mp.map[g.id]; if (!m) return null;
                    if (!available(m)) {                     // beaten earlier and no recovery left: another general takes this slot
                        var need = total(g.army), f = free(), alt = f.filter(function (x) { return x.cap >= need; }).sort(function (x, y) { return y.strike - x.strike; })[0] || f.sort(function (x, y) { return y.cap - x.cap; })[0];
                        F.push(finding(alt ? "warn" : "error", "GENERAL_OUT", 4, m.short + " was beaten earlier in this adventure and has no recovery left (round " + (ri + 1) + ", camp " + name + ")" + (alt ? ": " + alt.short + " takes the slot." : "; no free general takes the slot."),
                            "Instant Recovery (YGG, Ghost, or the skill) lets a beaten general attack once more per adventure."));
                        if (!alt) return null; delete inRound[m.id]; inRound[alt.id] = 1; m = alt;
                    }
                    return { g: m, army: scaleTo(g.army, m.cap), entry: g };
                });
                var rec = { round: ri + 1, grid: Number(grid), name: name, attackers: [], win: null, variant: null };
                if (waves.some(function (w) { return !w; })) { rec.result = "MISSING"; notSolved.push(rec); camps.push(rec); return; }
                waves.forEach(function (w) { if (total(w.army) < total(w.entry.army)) F.push(finding("warn", "CAPACITY_SHORT", 4, w.g.short + " holds " + w.g.cap + ", the author's " + shortName(w.entry.name) + " brought " + total(w.entry.army) + " at camp " + name + " (" + grid + ").", "The army is scaled down and simulated; a capacity skill would bring it back.")); });
                var army = A.camps && A.camps[grid], pick = null;
                function judged(label, ws) { var e = SV.evaluate(S, facts, army, ws, ch.iterations, ch.quantile, 11 + Number(grid)), j = judge(e, ws, ch);
                    var m = SV.metrics(facts, e, ws, input.unitCost, avoid, { barracks: ch.barracks });
                    return { label: label, waves: ws, e: e, j: j, cost: m.cost, m: m, rank: SV.rank(m, ch.objective) }; }
                if (!army) {
                    F.push(finding("warn", "CAMP_UNKNOWN", 4, "camp " + grid + " (" + name + ") is not in the adventure's camp facts: not simulated, the author's armies kept.", "Open the adventure once so its camps are read, then generate again."));
                    pick = { label: "not simulated", waves: waves, e: null };
                } else {
                    var best = null, closest = null;
                    /* the camp solver with the camp's generals and those still free in this round, in as many slots as the
                       author used; the solution's waves take the first slots, its main the author's main slot */
                    function trySolver(tiers, why, beat, maxW, quiet) {
                        var cand = waves.map(function (w) { return w.g; }).concat(free(inRound)), sol = SV.solveCamp(S, facts, army, cand, { iterations: ch.iterations, minWin: ch.minWin, quantile: ch.quantile,
                            mainMayLose: ch.mainMayLose, waveMayLose: ch.waveMayLose, maxWaves: maxW == null ? 2 : maxW, eliteUnits: A.eliteUnits !== false, unitCost: input.unitCost, seed: 23 + Number(grid), tiers: tiers,
                            objective: ch.objective, avoid: avoid, barracks: ch.barracks, units: ch.units || undefined });
                        if (!sol.ok) { if (sol.closest && why && !quiet) F.push(finding("info", "SOLVER_CLOSEST", 4, "camp " + name + " (" + grid + ", round " + (ri + 1) + "): the camp solver found no way with the generals free in this round; closest (" + sol.closest.tier + ", wins " +
                            Math.round(sol.closest.win * 100) + " %): " + sol.closest.waves.map(function (w) { return w.general + " " + fmt(w.army); }).join(" → ") + (sol.closest.why.length ? "; " + sol.closest.why.join("; ") : "") + ".", "")); return null; }
                        var bw = sol.best.waves, byId = {}; cand.forEach(function (g) { byId[g.id] = g; });
                        /* 0.4.1 (live ToW 2026-11-22 13:33Z: the solver's 1R wave before a main had no slot of its own where the author used
                           one attacker, so only the main was saved and it would fight the full camp — YGG2 losing 108 MM in the simulation):
                           the main takes the author's main slot, the waves the author's earlier slots, and a wave beyond them gets a slot of
                           its own on the same camp, just before the main */
                        var mainSlot = gs[gs.length - 1], slots = bw.map(function (w, i) { if (i === bw.length - 1) return mainSlot;
                            if (i < gs.length - 1) return gs[i];
                            /* 0.8.3 (live FT 2026-11-26): a wave written before the author's attacker stands in his place in the order, so it leaves
                               after his delay (Sizz's SYLVANA: 75 s after the general before her; the wave in her place was written with 1 s
                               and left before the camps on its way had fallen). Each such attacker plays in a step of its own (splitSteps). */
                            return { id: "+" + grid + "#" + i, extra: true, grid: mainSlot.grid, target: Number(grid), targetName: mainSlot.targetName, order: mainSlot.order - (bw.length - 1 - i) * 0.01, delay: mainSlot.delay || 1000, army: {}, name: "" }; });
                        var ws = bw.map(function (w, i) { return { g: byId[w.id], army: w.army, entry: slots[i] }; });
                        var c = judged("camp solver: " + sol.best.tier, ws); if (!c.j.ok) { if (!beat) closest = c; return null; }
                        if (beat && c.rank >= beat.rank) return null;      // the author's way is at least as good for this objective
                        waves.forEach(function (w) { delete inRound[w.g.id]; }); ws.forEach(function (w) { inRound[w.g.id] = 1; });
                        gs.forEach(function (g) { if (slots.indexOf(g) < 0) entries[g.id] = null; });
                        F.push(finding("info", "CAMP_SOLVED", 4, "camp " + name + " (" + grid + ", round " + (ri + 1) + "): " + why + "; the camp solver (" + sol.best.tier + "): " +
                            ws.map(function (w) { return w.g.short + " " + fmt(w.army); }).join(" → ") + ".", ""));
                        return c;
                    }
                    /* step B (ADR 0094): when the author's waves would beat more generals than the player has, a camp a general
                       takes without a wave (1R or a main alone) is played that way — no general beaten, no recovery spent */
                    if (ch.spareGenerals === true && gs.length > 1) best = trySolver(["1R", "main"], "played without a wave to spare generals");
                    if (!best) variants(waves, facts, ch).forEach(function (v) {
                        var cand = judged(v.label, v.waves);
                        if (cand.j.ok && (!best || cand.rank < best.rank)) best = cand;
                        if (!closest || cand.e.win > closest.e.win || (cand.e.win === closest.e.win && cand.j.bad.length < closest.j.bad.length)) closest = cand;
                    });
                    /* step A (ADR 0094 addendum): the author's attackers do not take it with these generals */
                    /* 0.8.3 (live FT 2026-11-26, "Use with my generals" on Sizz's route: his SYLVANA with 195 troops on camp 1870 became
                       "Narcissistic General, 1 Recruit" - the first wave of the camp solver's way, in her place): with objective
                       "author" a way that keeps the author's plan as it is comes first - no more attackers than he used on the
                       camp, and no general with 1 unit where he brought an army: another general or another army in his slot.
                       Only when there is none does the camp solver plan the camp its own way (ADR 0094 step A: waves in steps of
                       their own). */
                    /* 0.8.6 (author 2026-11-27 11:00, way 3 of four): a camp whose every attacker has a stand-in of the author's own
                       general type keeps the author's attack when it wins - his armies and his losses, named (AUTHOR_LOSSES_KEPT); it is
                       not handed to the camp solver because those losses fall outside the player's own loss rule (SirBirk's Raid of the
                       Nords: every camp was re-planned). Camps with a general of another type are planned as before. */
                    if (!best && ch.objective === "author" && waves.length && waves.every(function (w) { var o = outcomeOf[w.entry && w.entry.id]; return o === "SAME" || o === "EQUAL" || o === "SKILLS_DIFFER"; })) {
                        var asA = judged("as the author", waves);
                        if (asA.e.win >= ch.minWin) { best = asA;
                            if (asA.j.bad.length) F.push(finding("info", "AUTHOR_LOSSES_KEPT", 4, "camp " + name + " (" + grid + ", round " + (ri + 1) + "): the author's attack with your generals of his types (" +
                                waves.map(function (w) { return w.g.short; }).join(" → ") + ") wins and is kept; it loses what he planned: " + asA.j.bad.join("; ") + ".", "Optimise or Make new plans within your own loss rule.")); }
                    }
                    var authorWay = ch.objective === "author", slotsN = gs.length, oneR = gs.every(function (g) { return total(g.army) <= 1; });
                    if (!best && gs.length && authorWay) best = trySolver(slotsN > 1 || oneR ? null : ["main"], "the author's attackers do not take it with your generals", null, oneR ? Math.min(2, slotsN) : Math.min(2, slotsN - 1), true);
                    if (!best && gs.length) best = trySolver(null, "the author's attackers do not take it with your generals");
                    /* another objective than the author's (ADR 0094 addendum 10:47): the camp solver's best for it replaces the
                       author's way when it is better for that objective */
                    else if (best && ch.objective !== "author" && gs.length) best = trySolver(null, "better for " + ch.objective, best) || best;
                    pick = best || closest;
                    /* 0.8.3 (live FT 2026-11-26): with objective "author" a camp the player's generals do not WIN in the simulator is
                       NOT written - no general is sent on the author's route with an army that does not win. The camp is named as
                       a problem and stays for the player to decide. (A way that wins but loses a unit type the player's rule
                       keeps is written and named CAMP_NOT_SOLVED, as before.) */
                    if (!best && authorWay && pick.e.win < ch.minWin) {
                        rec.win = Math.round(pick.e.win * 1000) / 1000; rec.variant = pick.label; rec.result = "NOT_SOLVED"; rec.notWritten = true;
                        rec.why = pick.j.bad.concat(pick.e.win < ch.minWin ? ["wins " + Math.round(pick.e.win * 100) + " %"] : []); notSolved.push(rec);
                        pick.waves.forEach(function (w) { rec.attackers.push({ general: w.g.short, id: w.g.id, army: w.army }); });
                        gs.forEach(function (g) { entries[g.id] = null; });
                        F.push(finding("error", "CAMP_NOT_SOLVED", 4, "camp " + name + " (" + grid + ", round " + (ri + 1) + ") is NOT in the plan: in the place of " + gs.map(function (g) { return shortName(g.name); }).join(" → ") +
                            " your " + pick.waves.map(function (w) { return w.g.short; }).join(" → ") + " does not take it (" + rec.why.join("; ") + "), and the camp solver found no way with your generals.",
                            "Skill these generals (capacity, strike), free other generals from the reserve, or choose Optimise for my generals."));
                        camps.push(rec); return;
                    }
                    rec.win = Math.round(pick.e.win * 1000) / 1000; rec.variant = pick.label; rec.cost = Math.round(pick.cost * 10) / 10;
                    rec.seconds = Math.round(pick.m.seconds); rec.xp = Math.round(pick.m.xp); rec.units = Math.round(pick.m.units); rec.defeats = pick.m.defeats;
                    rec.rebuildRegular = Math.round(pick.m.rebuildRegular || 0); rec.rebuildElite = Math.round(pick.m.rebuildElite || 0);   // 0.6.0
                    if (!best) { rec.result = "NOT_SOLVED"; rec.why = closest.j.bad.concat(closest.e.win < ch.minWin ? ["wins " + Math.round(closest.e.win * 100) + " %"] : []); notSolved.push(rec);
                        F.push(finding("error", "CAMP_NOT_SOLVED", 4, "camp " + name + " (" + grid + ", round " + (ri + 1) + ") with " + pick.waves.map(function (w) { return w.g.short; }).join(" → ") + ": " + rec.why.join("; ") + ".",
                            "Skill these generals (capacity, strike), free other generals from the reserve, or play this camp camp by camp.")); }
                    else rec.result = "OK";
                    pick.e.perWave.forEach(function (p, w) { add(lossMean, p.lost); add(lossBad, p.bad); add(rl.mean, p.lost); add(rl.bad, p.bad);
                        if (p.beaten > 0.5 && w < pick.waves.length - 1) beaten(pick.waves[w].g);
                        rec.attackers.push({ general: pick.waves[w].g.short, id: pick.waves[w].g.id, army: pick.waves[w].army, lostMean: round1(p.lost), lostBad: p.bad, beaten: p.beaten > 0.5 }); });
                }
                if (!rec.attackers.length) pick.waves.forEach(function (w) { rec.attackers.push({ general: w.g.short, id: w.g.id, army: w.army }); });
                pick.waves.forEach(function (w) { entries[w.entry.id] = { g: w.g, army: w.army, entry: w.entry }; });
                camps.push(rec);
            }, end: function () {
            // generals in the round without a target (parked, moved): their stand-in keeps the author's army, scaled
            t.generals.forEach(function (g) { if (entries[g.id] === undefined && mp.map[g.id] && (available(mp.map[g.id]) || (g.raw && g.raw.plan)) && !inRoundOther(g)) entries[g.id] = { g: mp.map[g.id], army: scaleTo(g.army, mp.map[g.id].cap), entry: g }; });
            function inRoundOther(g) { var m = mp.map[g.id]; return keys(entries).some(function (k) { return entries[k] && k !== g.id && entries[k].g.id === m.id; }); }
            var tpl = {};
            var slotsAll = t.generals.concat(keys(entries).map(function (k) { return entries[k]; }).filter(function (e) { return e && e.entry && e.entry.extra; }).map(function (e) { return e.entry; }));   // 0.4.1
            slotsAll.forEach(function (g) {
                var e = entries[g.id]; if (!e) return;
                if (!firstArmy[e.g.id]) firstArmy[e.g.id] = { g: e.g, army: e.army, grid: g.grid };
                tpl[key(e.g.id)] = { grid: g.grid, name: e.g.name, order: g.order, time: ch.asIs ? (g.delay || 1000) : 1000, skills: {}, army: e.army,
                                     type: e.g.type, target: g.target || null, targetName: g.targetName || null };
                if (g.raw && g.raw.home) tpl[key(e.g.id)].home = true;   // 0.7.0: the field plan's home entries carry through
                if (g.raw && g.raw.plan) tpl[key(e.g.id)].plan = g.raw.plan;
            });
            /* 0.8.1 (live FT 2026-11-26, Sizz's route on the author's account: "Use with my generals" wrote the attack without its
               three destroy arrows, so every general walked through the camps they clear and was intercepted): the author's
               arrows and buffs are carried 1:1 — the same item, the same camp, in their own place in the order */
            (t.buffs || []).forEach(function (b, bi) { if (!b || !b.name) return; var bk = "buff_" + (b.target || "x") + "_" + bi;
                tpl[bk] = { name: b.name, order: b.order, time: 1000, type: "buff", skills: {}, army: {}, target: b.target || null, targetName: b.targetName || null }; });
            keys(tpl).sort(function (a, b) { return tpl[a].order - tpl[b].order; }).forEach(function (k, i) { tpl[k].order = i; });   // 0.4.1: whole orders again
            roundsOut.push({ file: abbr + " attack " + ("0" + (ri + 1)).slice(-2), from: t.file, tpl: tpl, entries: entries });
            perRound.push(rl);
            } };
        }; });
        var nCamps = 0; run.rounds.forEach(function (t) { var seen = {}; t.generals.forEach(function (g) { if (g.target && !seen[g.target]) { seen[g.target] = 1; nCamps++; } }); });
        var ri = -1, cur = null, ci = 0;
        var job = { done: false, result: null, total: nCamps + 2 * run.rounds.length + 1, at: 0, step: function () {
            if (job.done) return true;
            job.at++;
            if (!cur) { ri++; if (ri >= roundFns.length) { job.result = post(); job.done = true; return true; } cur = roundFns[ri](); ci = 0; return false; }
            if (ci < cur.camps.length) { cur.camp(cur.camps[ci++]); return false; }
            cur.end(); cur = null; return false;
        } };
        return job;
        function post() {
        /* step B — the generals budget (author 2026-11-22: "Als ik 4 wave attacks heb met de YGG, moet ik ook 4 YGGs beschikbaar
           hebben"; "Herstel ... dat kan maar 1 keer per avontuur"): every wave is a general beaten; a beaten general is out unless it
           recovers once. The last round needs all its slots from generals still in; every wave of the earlier rounds beyond the
           recoveries the player's generals have costs one general. */
        (function budget() {
            var slotsLast = 0, wavesBefore = 0;
            run.rounds.forEach(function (t, ri) {
                var byC = {}; t.generals.forEach(function (g) { if (g.target) byC[g.target] = (byC[g.target] || 0) + 1; });
                each(byC, function (c, n) { if (ri === run.rounds.length - 1) slotsLast += n; else wavesBefore += n - 1; });
            });
            var have = mine.filter(function (m) { return m.general && ctx.reserve.indexOf(m.id) < 0; }), rec = have.filter(function (m) { return m.recoverOnce; }).length;
            var need = slotsLast + Math.max(0, wavesBefore - rec);
            budgetInfo = { generals: have.length, recoverOnce: rec, wavesBeforeLast: wavesBefore, slotsLast: slotsLast, needed: need, short: Math.max(0, need - have.length) };
            if (need > have.length) F.push(finding("error", "GENERALS_BUDGET", 1, "the author's plan beats " + wavesBefore + " wave general(s) before the last round and needs " + slotsLast + " generals in it: " + need +
                " generals, or fewer with Instant Recovery. You have " + have.length + " (" + rec + " recover once): " + (need - have.length) + " short.",
                "Bring " + (need - have.length) + " more generals, or generals that recover once (YGG, Ghost, the Instant Recovery skill), or play the camps the plan cannot reach camp by camp."));
        })();
        /* totals for the objectives: camps of one round fight side by side, rounds one after another */
        var totals = { seconds: 0, xp: 0, units: 0, defeats: 0, rebuild: 0, rebuildRegular: 0, rebuildElite: 0 };
        camps.forEach(function (c) { totals.rebuildRegular += c.rebuildRegular || 0; totals.rebuildElite += c.rebuildElite || 0; });   // 0.6.0: the barracks train side by side
        totals.rebuild = Math.max(totals.rebuildRegular, totals.rebuildElite);
        run.rounds.forEach(function (t, ri) { var mx = 0; camps.forEach(function (c) { if (c.round !== ri + 1) return; mx = Math.max(mx, c.seconds || 0); totals.xp += c.xp || 0; totals.units += c.units || 0; totals.defeats += c.defeats || 0; }); totals.seconds += mx; });
        /* a quest "lose fewer than x of y" (ADR 0094 addendum 10:47): checked on the bad case of the whole run */
        each(ch.maxLoss || {}, function (u, n) { var l = Math.ceil(lossBad[u] || 0);
            if (l >= Number(n)) F.push(finding("error", "QUEST_LOSS", 4, "this plan loses up to " + l + " " + u + " (bad case); the quest allows fewer than " + n + ".", "Choose another version, or other generals for the camps that lose " + u + "."));
            else F.push(finding("info", "QUEST_LOSS", 4, "this plan loses at most " + l + " " + u + " (bad case): fewer than " + n + ".", "")); });
        var outs = F.filter(function (f) { return f.code === "GENERAL_OUT"; }).length;
        if (outs) F.push(finding("warn", "GENERALS_PER_ATTACK", 4, outs + " slot(s) in later rounds need a general that was already beaten (ADR 0094 step B: a beaten general is out unless it recovers once).",
            "Split the attacks differently, add generals with Instant Recovery (YGG, Ghost or the skill), or bring more generals."));

        /* phase 2: the load — every general with the army of its first round; carriers for what later rounds need */
        var load = {}, ord = 0, island = {};
        keys(firstArmy).forEach(function (id) { var f = firstArmy[id];
            var lg = run.load ? run.load.generals.filter(function (g) { return mp.map[g.id] && mp.map[g.id].id === id; })[0] : null;
            load[key(id)] = { grid: lg ? lg.grid : f.grid, name: f.g.name, order: ord++, time: 1000, skills: {}, army: copy(f.army), type: f.g.type, target: null, targetName: null };
            add(island, f.army); });
        var cargo = {}, have = copy(island);
        roundsOut.forEach(function (r, ri) {
            if (ri > 0) { var need = {}; each(r.entries, function (k, e) { if (e) add(need, e.army); });   // 0.8.3: a slot that is not written carries nothing
                each(need, function (u, n) { var gap = n - Math.max(0, have[u] || 0); if (gap > 0) { cargo[u] = (cargo[u] || 0) + gap; have[u] = n; } }); }
            each(perRound[ri].bad, function (u, n) { have[u] = (have[u] || 0) - n; });
        });
        each(cargo, function (u, n) { cargo[u] = Math.ceil(n * (1 + ch.loadMargin) / 10) * 10; });
        /* 0.5.1 (live IP 2026-11-22 18:55Z: "the load carries too little for 2 waves ... short 32 Recruit"): the steps are checked
           as the executor checks a version "without blocks" (user_dma_adventure waveLoadCheck: every unit a step may lose that is
           not a ranged one counted as lost, the next step's need with the margin); what is short goes to the carriers */
        var stepPk = []; roundsOut.forEach(function (r) { splitSteps(r.tpl, Number(A.zoneWidth) || 68, A.way).forEach(function (t) { stepPk.push(t); }); });
        if (stepPk.length > 1) {
            var haveW = copy(island); each(cargo, function (u, n) { haveW[u] = (haveW[u] || 0) + n; });
            var reqW = {}, lostW = {}, mgW = ch.loadMargin;
            stepPk.forEach(function (t, i) { var w = {}; each(t, function (k, e) { add(w, e.army); });
                each(w, function (u, n) { var need = i === 0 ? n : Math.ceil((n + (lostW[u] || 0)) * (1 + mgW)); if (!(reqW[u] >= need)) reqW[u] = need; });
                each(w, function (u, n) { lostW[u] = (lostW[u] || 0) + Math.round(n * (/Marksman|Bowman|Archer|Crossbow|Cannoneer/i.test(u) ? 0.1 : 1)); }); });
            each(reqW, function (u, n) { var gap = n - (haveW[u] || 0); if (gap > 0) cargo[u] = (cargo[u] || 0) + Math.ceil(gap / 10) * 10; });
        }
        var carriers = [], rest = copy(cargo), authorCarriers = run.load ? run.load.generals.filter(function (g) { return !mp.map[g.id] && g.total > 0; }) : [];
        if (total(rest) > 0) {
            var tr = mine.filter(function (m) { return m.transport && ctx.reserve.indexOf(m.id) < 0; })
                .sort(function (x, y) { return (CARRIER_PREF[y.type] || 0) - (CARRIER_PREF[x.type] || 0) || y.cap - x.cap; });
            tr.forEach(function (c, ci) {
                if (total(rest) <= 0) return;
                var take = {}, room = c.cap;
                keys(rest).sort().forEach(function (u) { var n = Math.min(rest[u], room); if (n > 0) { take[u] = n; rest[u] -= n; room -= n; } });
                if (!total(take)) return;
                var ag = authorCarriers[carriers.length];
                load[key(c.id)] = { grid: ag ? ag.grid : 0, name: c.name, order: ord++, time: 1000, skills: {}, army: take, type: c.type, target: null, targetName: null };
                carriers.push({ id: c.id, name: c.short, cap: c.cap, cargo: take, grid: ag ? ag.grid : 0 }); add(island, take);
            });
            keys(rest).forEach(function (u) { if (rest[u] <= 0) delete rest[u]; });
            if (total(rest) > 0) F.push(finding("error", "LOAD_SHORT", 2, "the later rounds need " + fmt(rest) + " more than your generals and carriers bring.", "Get a Quartermaster (or a larger one), or let a general bring more in the load."));
            carriers.forEach(function (c) { if (!c.grid) F.push(finding("warn", "CARRIER_SPOT", 3, c.name + " has no spot from the author's load; it lands where the game puts it.", "Give it a free spot in the load template, or let the star method place it.")); });
        }

        /* phase 1: prepare at home */
        var pool = input.pool || null, shortfall = {};
        if (pool) each(island, function (u, n) { var s = n - (pool[u] || 0); if (s > 0) shortfall[u] = s; });
        if (total(shortfall)) F.push(finding("warn", "TROOPS_SHORT", 1, "at home you miss " + fmt(shortfall) + " for the load.", "Let the troop manager train them before the start (losses per run below)."));
        var perRun = {}; each(lossBad, function (u, n) { if (n > 0) perRun[u] = Math.ceil(n); });

        /* phase 3: landing */
        var landing = Number(A.landing && A.landing.n) || 0, landers = keys(load).length, star = ch.starMethod;
        if (star === "auto") star = landing ? landers > landing : null;
        if (star === null) F.push(finding("warn", "LANDING_UNKNOWN", 3, "the landing spots of this adventure are not known yet: the star method is not advised on a guess.", "Open the adventure once (the spots are read from the game), or set the star method yourself."));
        var firstOnly = [];
        if (roundsOut.length > 1) { var later = {}; roundsOut.slice(1).forEach(function (r) { each(r.tpl, function (k) { later[k] = 1; }); });
            each(roundsOut[0].tpl, function (k, e) { if (!later[k] && e.type !== "buff") firstOnly.push(strip(e.name).split(" ")[0] || idOf(k)); }); }

        /* phase 5: close */
        var ahead = ch.aheadHome === "auto" ? firstOnly.length > 0 : !!ch.aheadHome;

        var cost = { perRunBad: perRun, perRunMean: round1(lossMean) };
        var id = A.id || abbr.toLowerCase(), settings = {};
        settings["adv." + id + ".aheadHome"] = ahead; settings["adv." + id + ".closeAtOnce"] = !!ch.closeAtOnce;
        if (star !== null) settings["adv.mundane.starMethod"] = !!star;
        settings["adv.prestage"] = !!ch.prestage; settings["adv.waves.loadMargin"] = ch.loadMargin;
        function ph(n) { return F.filter(function (f) { return f.phase === n; }); }
        var phases = [
            { phase: 1, name: "Prepare at home", generalsBudget: budgetInfo, load: island, shortfall: shortfall, lossesPerRun: perRun, runs: ch.runs, troopPlan: scale(perRun, ch.runs),
              generalsHome: keys(load).map(function (k) { return strip(load[k].name).split(" ")[0]; }), findings: ph(1) },
            { phase: 2, name: "Start and send", template: abbr + " load", generals: keys(firstArmy).length, carriers: carriers, cargo: cargo, findings: ph(2) },
            { phase: 3, name: "Landing to the first attack", landingSpots: landing || null, landingSource: (A.landing && A.landing.source) || null, landing: landers,
              starMethod: star, prestage: !!ch.prestage, firstRound: keys(roundsOut[0].tpl).length, findings: ph(3) },
            { phase: 4, name: "Attack", objective: ch.objective, totals: totals, rounds: roundsOut.map(function (r) { return { file: r.file, from: r.from, generals: keys(r.tpl).filter(function (k) { return r.tpl[k].type !== "buff"; }).length }; }), mapping: mp.rows, camps: camps,
              solved: camps.filter(function (c) { return c.result === "OK"; }).length, notSolved: notSolved.length, asIs: !!ch.asIs, findings: ph(4) },
            { phase: 5, name: "Load troops and close", firstRoundOnly: firstOnly, aheadHome: ahead, closeAtOnce: !!ch.closeAtOnce, findings: ph(5) }
        ];
        /* 0.5.0 (ADR 0094 addendum 19:58, lessons 2 and 4): each round is played as steps — the waves of a camp each in a step of
           their own before its main, a camp without waves in the first step — and no two generals of one step share a spot, nor
           take the spot of a wave general of this round still recovering */
        var stepNo = 0, stepFiles = [];
        roundsOut.forEach(function (r) { splitSteps(r.tpl, Number(A.zoneWidth) || 68, A.way).forEach(function (t) { stepNo++;
            var nm = abbr + " attack " + ("0" + stepNo).slice(-2);
            keys(t).forEach(function (k) { var e = t[k]; if (!e.interceptRisk) return;   // 0.8.5: every free spot was watched - named, never silent
                F.push(finding("warn", "INTERCEPT_RISK", 4, nm + ": " + shortName(e.name) + " to camp " + e.target + " from spot " + e.grid + " passes camp(s) " + e.interceptRisk.join(", ") +
                    " that are still standing then; every free spot's way is watched.", "Attack or block those camps first, or play this camp camp by camp; DMA does not send a plan of its own into an interception."));
                delete e.interceptRisk; });
            stepFiles.push({ name: nm, text: JSON.stringify(t), round: r.file }); }); });
        if (stepFiles.length > roundsOut.length) F.push(finding("info", "STEPS", 4, roundsOut.length + " round(s) played as " + stepFiles.length + " steps: the waves of a camp before its main, each general on a spot of its own.", ""));
        var files = [{ name: abbr + " load", text: JSON.stringify(load) }].concat(stepFiles.map(function (f) { return { name: f.name, text: f.text }; }));
        var gj = { format: "dma-shared-generals/1", source: "user_dma_mundane_gen " + VERSION, generals: {},
                   allIds: mine.map(function (m) { return m.id; }) };   // 0.3.1: every general the player had, so a later check can tell which are new
        keys(load).forEach(function (k) { var m = mine.filter(function (x) { return key(x.id) === k; })[0]; if (m) { var sk = {}; each(m.skills, function (n, l) { sk["Skill_" + n] = l; }); gj.generals[k] = { name: m.short, type: m.type, skills: sk }; } });
        files.push({ name: "generals.json", text: JSON.stringify(gj, null, 1) });
        return { version: VERSION, ok: !F.some(function (f) { return f.level === "error"; }), phases: phases, files: files, settings: settings, cost: cost, findings: F, choices: ch };
        }
    }
    /* 0.5.0: one round's template as steps (pure). Per camp the attackers in order: attacker i plays in step i, the main in the
       step after the last wave; a camp with one attacker plays in step 0; generals without a target stay in step 0. Spots: a
       general keeps its own grid unless another general of the step has it, or a wave general of an earlier step of this
       round (it recovers on it); then the nearest free grid of the round (to its target) is taken. */
    function splitSteps(tpl, W, way) {
        /* a camp's attackers stay in one step (the scheduler sends them in order) unless one would stand on the spot of an
           attacker of the same camp before it: then it and the rest of that camp move to the next step (the author's own
           waves on spots of their own keep their step and timing) */
        var byT = {}, parked = [], steps = [], plan = {}, n = 1, buffs = [];
        keys(tpl).forEach(function (k) { var e = tpl[k]; if (e.type === "buff") buffs.push(k); else if (e.target) (byT[e.target] = byT[e.target] || []).push(k); else parked.push(k); });   // 0.8.1: an arrow has no spot
        var pool = []; keys(tpl).forEach(function (k) { var g = Number(tpl[k].grid); if (tpl[k].type !== "buff" && g > 0 && pool.indexOf(g) < 0) pool.push(g); });
        keys(byT).forEach(function (t) { var L = byT[t].sort(function (a, b) { return tpl[a].order - tpl[b].order; }), s = 0, here = {};
            L.forEach(function (k) { var g = Number(tpl[k].grid); if (here[g]) { s++; here = {}; } here[g] = 1; plan[k] = s; }); n = Math.max(n, s + 1); });
        function L0last(c) { var L = byT[c] || []; return L[L.length - 1]; }
        function dist(a, b) { return Math.max(Math.abs(a % W - b % W), Math.abs(Math.floor(a / W) - Math.floor(b / W))); }
        var held = {}, gone = {}, cur = {};
        /* 0.8.5: the camps still standing when an entry leaves - every camp the plan attacks or arrows in an EARLIER step, or
           earlier in this step, counts as gone; a camp the plan never attacks stands all the time */
        function watchers(from, to, k) { if (typeof way !== "function") return [];
            var by = []; try { by = way(Number(from), Number(to)) || []; } catch (_) { by = []; }
            return by.map(Number).filter(function (c) { return c !== Number(to) && !gone[c] && !cur[c]; }); }
        for (var s = 0; s < n; s++) {
            var t = {}, used = {}, waves = []; cur = {};
            if (s === 0) buffs.forEach(function (k) { if (tpl[k].target) cur[Number(tpl[k].target)] = 1; });   // an arrow takes its camp before the generals after it
            keys(tpl).filter(function (k) { return tpl[k].target && plan[k] === s; }).sort(function (a, b) { return tpl[a].order - tpl[b].order; }).forEach(function (k) {
                var e = copy(tpl[k]), g = Number(e.grid), tg = Number(e.target);
                if (g !== tg && (!(g > 0) || used[g] || held[g])) {   // a spot on the target itself (from scratch) is found by the executor
                    /* 0.8.5 (live FT 2026-11-27 05:47-06:12Z, B14 section 13): the nearest free spot was taken without asking whose
                       camp watches the way from it. YGG1 went from 1516 to 1870, was caught by 1132 (a camp the plan never attacks),
                       won there with 3 of his 155 left and lost at 1870 - twice. A spot whose way passes a camp that is still
                       standing at this point of the plan comes last; when every free spot is watched, the entry says so
                       (interceptRisk) and the generator names it (INTERCEPT_RISK). way(from, to) = the camps watching that way,
                       from the game's own path and watch areas (the executor's interception picture); without it, as before. */
                    var free = pool.filter(function (x) { return !used[x] && !held[x]; }), risk = {};
                    free.forEach(function (x) { risk[x] = watchers(x, tg, k); });
                    var alt = free.sort(function (x, y) { return (risk[x].length ? 1 : 0) - (risk[y].length ? 1 : 0) || dist(x, tg) - dist(y, tg); })[0];
                    if (alt) { g = alt; if (risk[alt].length) e.interceptRisk = risk[alt]; }
                }
                e.grid = g; if (g !== tg) used[g] = 1; t[k] = e;
                if (L0last(e.target) === k) cur[tg] = 1;   // 0.8.5: the camp's main has left: the camp counts as gone for those after him
                var L = byT[e.target]; if (L[L.length - 1] !== k && plan[L[L.length - 1]] > s && g !== tg) waves.push(g);   // a wave whose main comes later recovers on its spot
            });
            if (s === 0) buffs.forEach(function (k) { t[k] = copy(tpl[k]); });   // 0.8.1: the arrows in the first step, in their own place in the order
            if (s === 0) parked.forEach(function (k) { var e = copy(tpl[k]); if (Number(e.grid) > 0 && used[Number(e.grid)]) return; t[k] = e; if (Number(e.grid) > 0) used[Number(e.grid)] = 1; });   // 0.7.0: many may go to the star (-1)
            /* 0.8.3 (live FT 2026-11-26): Mundane sends a template in the order of its KEYS (5-battle.js battleAttack: $.each), the
               "order" field is only kept in the file. The step was written generals first, arrows last, so Mundane put the arrows
               on their camps after every general had left. The keys are written in the order of the plan. */
            var tOrd = {}; keys(t).sort(function (a, b) { return t[a].order - t[b].order; }).forEach(function (k, i) { t[k].order = i; tOrd[k] = t[k]; }); t = tOrd;
            waves.forEach(function (g) { held[g] = 1; });
            keys(cur).forEach(function (c) { gone[c] = 1; });
            if (keys(t).length) steps.push(t);
        }
        return steps;
    }
    function round1(o) { var r = {}; each(o || {}, function (k, v) { if (v >= 0.05) r[k] = Math.round(v * 10) / 10; }); return r; }
    function scale(o, n) { var r = {}; each(o || {}, function (k, v) { r[k] = v * (n || 1); }); return r; }

    var api = { version: VERSION, generate: generate, generateVersions: generateVersions, generateJob: generateJob, versionsJob: versionsJob, reanalyse: reanalyse, reanalyseJob: reanalyseJob, fingerprint: fingerprint, rosterOf: rosterOf, generalChanges: generalChanges, calculate: calculate, MODES: keys(MODES), OBJECTIVES: ALL_OBJECTIVES, SCENARIOS: SCENARIOS, CHOICES: CHOICES, campPlan: campPlan, DESTROY_ARROWS: DESTROY_ARROWS, destroyArrows: function () { return { arrows: JSON.parse(JSON.stringify(DESTROY_ARROWS)), source: DESTROY_SOURCE }; }, arrowTakes: arrowTakes, campSize: campSize, _test: { scratchJob: scratchJob, splitSteps: splitSteps, mapGenerals: mapGenerals, variants: variants, scaleTo: scaleTo, skillMap: skillMap } };
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    root.DMA_MundaneGen = api;
})(typeof window !== "undefined" ? window : this);
