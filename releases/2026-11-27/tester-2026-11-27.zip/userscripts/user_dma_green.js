/*
 * DMA Green 0.5.0 — the managers' decisions as a rule table over island facts.
 * Does not write client files (the policy and the island memory own persistence).
 * Ticked by DMA_Demo after the location manager has observed the island.
 *
 * Every decision is made by a named rule (RULES) that states:
 *   - the action rule (ARS) and coordination act it decides (left: facts, right: c-act);
 *   - the facts it reads;
 *   - its settings, which the player can change in the policy as rule.<id>.<setting>.
 * Every row green produces carries the id of the rule that decided it, so the console and the
 * log say which rule fired. This table is what the player rule engine will take over.
 *
 * 0.5.0 (2026-10-24, author decisions after the live test)
 *  1. Capacity is a learned fact: the number of deposit spots the island has shown
 *     (DMA_Demo.island()). Until a search proves it, the policy cap is the hypothesis.
 *     Green no longer raises the policy caps (they are the player's facts).
 *  2. Optimal production: a mine whose deposit runs out within the search lead time
 *     (+ margin) needs a replacement search now; a search is only sent when its find can
 *     land (an empty spot, or a mine that will be demolished before the geologist returns).
 *     Demolish when the deposit is empty, or when a returning geologist needs the spot.
 *  3. Buff: the player's choice per building type (BUFF screen), else the strongest buff
 *     that the game accepts (score = bonus % x duration, Rainbow Snow only on endless mines),
 *     highest level first — as in the Building Buffer reference script.
 *  4. Build: the building manager initiates a construction only for a free build-queue slot
 *     (ARS-20-11). Priority: the resource furthest below its capacity, then the richest
 *     deposit. A resource whose materials were missing is skipped for a while. Upgrades take
 *     the slots that are left.
 *  Implementation: all server actions of one cycle go through one paced sequence
 *  (control.sendIntervalMs, default 1500 ms) so the client's server traffic is not flooded.
 *
 * 0.5.1 (2026-10-24, live): declines are logged once per (act, resource, reason); a mine whose
 *  buff the game refuses is retried after 10 minutes, not every cycle; the search lead time is
 *  the median measured search duration of R (island memory), then the client's prediction,
 *  then the default — the client exposes no predicted duration.
 *
 * 0.5.2 (2026-10-24, live): free build-queue slots = maximum - used when the maximum is known
 *  (the client's "available slots" stayed 4 while 7 constructions were queued); slots, used and
 *  free are logged every cycle.
 *
 * 0.6.0 (2026-10-24, author decisions):
 *  - Every decision row (pm and dc, with its rule) and every execution result is recorded in the
 *    facts log (DMA_Demo.record): the transaction steps are kept, as DEMO intends.
 *  - Self-correcting pace: the send interval starts at control.sendIntervalMs (1500 ms). An action
 *    that throws, or returns an error that points at the connection or the zone, doubles the
 *    interval (max 6000 ms) and is recorded; after 20 clean actions it shrinks by 10 %, never below
 *    control.sendIntervalMinMs (700 ms). The current pace is logged and recorded per cycle.
 *
 * 0.8.1 (2026-11-01, author: "Je moet wel de love tree gebruiken zodra het kan" — "Love tree hoort bij de buff manager"):
 *   R-ZONE-LOVETREE (ADR 0026) is a rule of the BUFF MANAGER (switch Buff): the Love Tree with the highest level is
 *   started as soon as its cooldown has ended, with the best recipe that level allows (live, the first allowed recipe
 *   was Lvl1 on a level-3 tree); costs in stock; it waits while its own buff or another zone buff of the same group runs
 *   (R-ZONE-REPLACE). The buffer executes it the way the game's culture-building panel does: START_TIMED_PRODUCTION (91)
 *   with dTimedProductionVO. Param rule.R-ZONE-LOVETREE.on (default on). Replaces user_dma_zonebuff.js 0.1.x.
 *   Unit: tests/unit/dma-green-lovetree.test.js; integration: live, the level-3 tree starts at its cooldown end.
 * 0.8.0 (2026-10-30, author: "this is important, that should be remembered by green and when blue decides to wait, it will
 *   still be remembered as work list"; live the same day: two build orders the game never carried out were forgotten by
 *   nobody and blocked their deposits for an hour): GREEN REMEMBERS THE WORK. Every construction green wants is an item
 *   on the WORK LIST (kind build, grid, resource, state, since, attempts, why), kept in dma-worklist.json so it survives a
 *   restart. States: "open" — wanted, waiting for blue (a queue slot, materials, the hold), with the reason blue gave;
 *   "sent" — blue carried the order to the game; DONE — a mine stands on the grid: the item leaves the list (fact TK21
 *   "declare"). A sent item that is neither in the build queue nor a mine 10 min later goes BACK TO OPEN with
 *   attempts + 1 (fact TK21 "reopen") — never lost. An open item whose deposit is no longer free and that was never
 *   sent leaves the list (fact "withdrawn"). Blue still decides when; green never forgets what.
 *   Unit expectation:        a waiting candidate is "open" with blue's reason; an executed build is "sent"; a mine on the
 *                            grid removes it; sent without a mine after 10 min -> open again, attempts 1; the list is
 *                            written to the file and read back at start.
 *   Integration expectation: tests/integration/dma-green-worklist.test.js.
 * 0.9.8 (2026-11-27, review 2026-11-27-b16b-game-refusal-limit-r2 R2-F1/R2-F2): ARS-11-05 looks for a NEW deposit instead of a count - the
 *   request carries the deposits of the resource (depositMapAtRequest: grid -> amount); a deposit on a location that held none, or with
 *   more left than at the request, is the find (a replacement find after a demolition is found); accepted at once, and the accept breaks
 *   DFS-13's row (island().found); rejected after two accepted pictures without one. Unit: tests/unit/dma-capacity-refused.test.js.
 *   Integration: tests/integration/dma-capacity-from-game.test.js (green and the deposit search manager).
 * 0.9.7 (2026-11-27, change-set B16b, backbone v3.41; review 2026-11-27-b16b-game-refusal-limit F1/F2/F4): TK11 is no longer accepted the
 *   moment the geologist is back. The request carries the deposits of the resource then (depositsAtRequest); the return is declared;
 *   ARS-11-05 R-DEPOSIT-FOUND accepts it only when the accepted picture after the return holds a deposit more, confirmed by the next
 *   accepted picture, else rejects it (the game refused: too many deposits of this type), hands the rejection to the location manager
 *   (DFS-13) and ends the case. Unit: tests/unit/dma-capacity-refused.test.js. Integration: tests/integration/dma-capacity-from-game.test.js.
 * 0.9.6 (2026-11-27, construction review F3; backbone v3.40): R-CAP reads DFS-13, whose definition is now the number of the
 *   deposit places of [resource] (ET47, the game's); the rule's facts name them. Unit: tests/unit/dma-capacity-from-game.test.js.
 *   Integration: tests/integration/dma-capacity-from-game.test.js.
 * 0.9.5 (2026-11-27, change-set B16-2): R-CAP's statement - the capacity of R is the number of places the game holds for this player
 *   (agents 0.4.47 island().capacity); the learned proof only on a client that gives none. Text only; the computation reads the
 *   island picture as before. Unit: tests/unit/dma-capacity-from-game.test.js. Integration: tests/integration/dma-capacity-from-game.test.js.
 * 0.9.4 (2026-11-17, UAT 2026-11-17 finding F2; the manual says "Without a target nothing is upgraded"): compute.targetLevel(resource, name) returned 2 (3 for TitaniumOre) when the player had set no
 *   upgrade target, so a new player who switched Upgrade on saw 48 level-1 mines upgraded to level 2. It now returns 0 when neither upg.<Resource> nor building.upgradeLevel.<Resource> holds a number of at least 1,
 *   and every reader (R-UPG, R-BUFF-WHEN) already treats a level that is not below the target as "no upgrade needed". A stored target keeps its meaning, including the cap at control's maximum level of the
 *   building type (0.8.29). The default of the policy follows in pbc-player-policy 0.2.70, the fallbacks of control, the demo agents and the construction manager in their own PRs.
 *   Unit: tests/unit/green-target-level-capped.test.js (no target -> 0, also for TitaniumOre; a stored target still wins and is capped). Integration: tests/integration/green-no-target-nothing-upgraded.test.js (the real policy
 *   with an explicit 0 / a stored 3: with no target R-UPG yields no row, with 3 a level-1 mine gets one).
 * 0.9.3 (2026-11-16, ADR 0074 step 4): green hands the AR10 search decisions to the deposit search manager (user_dma_deposit_search_manager.js 0.1.0, DMA_DepositSearchManager) ONLY WHEN IT SEES IT READY (check()):
 *   assess() then emits no R-GAP / R-DUE / R-LF row and runs no tk11Review; it keeps R-CAP (computing: the "capacity 0" row); last() adds the manager's rows after the construction manager's; execute() starts its
 *   sequence after both managers' (sendingMs()). verifySearch is control's now (0.2.107). Without the manager nothing changes (rollback = remove the file).
 *   Unit: tests/unit/dma-green-search-handover.test.js (no search row while the manager is ready, R-CAP stays, rollback). Integration: tests/integration/dma-deposit-search-handover.test.js.
 * 0.9.2 (2026-11-16, ADR 0074 step 3): green hands every AR20 decision to the construction manager (user_dma_construction_manager.js 0.1.0, DMA_ConstructionManager) ONLY WHEN IT SEES IT READY (check()):
 *   assess() then emits no demolish, upgrade, build or buff rows and runs no tk31/tk41/tk51 review; it keeps the search rows (AR10, step 4) and tk11Review; the cleared grids of the manager's demolitions
 *   (demolished()) reach the search rules; busy(grid) is the manager's; last() returns the manager's rows first; execute() starts its sequence after the manager's (sendingMs()). Without the manager nothing
 *   changes (rollback = remove the file). New in the interface: pictureOf(slots), compute.session() / buffPref / trainsForTroops / eventDecl / eventRunning / eventBuildings, agenda.get / update.
 *   Unit: tests/unit/dma-green-construction-handover.test.js (no AR20 row while the manager is ready, the search rows stay, rollback). Integration: tests/integration/dma-construction-manager-handover.test.js.
 * 0.9.1 (2026-11-16, ADR 0074 step 2): green hands TK41 execution to the buff applier (user_dma_buff_applier.js 0.1.0, DMA_Buffer owner "buff applier") ONLY WHEN IT SEES IT READY (DMA_Buffer.check()):
 *   execute() sends the Love Tree order, the buff orders and the choice rule (R-BUFF-CHOICE) through DMA_Buffer.startLoveTree / applyBuff / applyChosen; the "buff on its way" and "game refused" reads of the rules come from
 *   the applier (onItsWay, refused), and the Love Tree's 3-minute guard counts the applier's start. Without a ready applier everything runs as in 0.9.0 (the old code stays until step 5; removing the file is the rollback).
 *   green defines its own DMA_Buffer only when none is present (the applier loads first: user_dma_buff_applier.js sorts before user_dma_green.js). DMA_Green.busy(grid) is exported for the applier's truth clause.
 *   compute.buffChoice(grid, name, request) takes the player's request (the choice the player asked for). Unit: tests/unit/dma-green-buffer-handover.test.js (not ready: green sends; ready: the applier sends, green does not).
 *   Integration: tests/integration/dma-buff-applier-handover.test.js (real policy, control, adapter and applier: one buff, one TK41 promise by the buff applier, never two).
 * 0.9.0 (2026-11-16, ADR 0074 step 1, additive; author: "green is de onthouder en de berekenaar, verder niks"): green offers its I-services behind an interface, with NO change of behaviour:
 *   DMA_Green.facts() / picture() / live(grid) (the island picture: TK86 sharing), DMA_Green.compute.{ capacity(r), targetLevel(r, name), lead(r), due(r), gap(r), low(), buffNeeds(), buffChoice(grid, name),
 *   eventPlan(), eventOptions(grid, name), loveTreePlan(), lootAdvice() } (computing: TK83 gap, TK84 low and due mines, TK85 buff need, DFS-44/46/51, R-CAP, R-ADV-LOOT) and
 *   DMA_Green.agenda.{ list(), want(grid, r, why), sent(grid, r), review(freeGrids, queued) } (remembering the construction agenda, ADR 0045; dma-worklist.json, written on the caller's call).
 *   Each is the code assess() uses (the same helpers) or derived from the same predicates without the cycle's transient holds (busy, on its way, per-cycle maxima, stock): the construction manager,
 *   the deposit search manager and the buff applier of the next steps read these. Unit: tests/unit/dma-green-compute.test.js (the compute results equal the rows assess() produces, row for row).
 *   Integration: tests/integration/dma-green-compute-policy.test.js (the real policy, DMA_Demo and control: the interface answers on a live-shaped island and assess() is unchanged).
 * 0.8.29 (2026-11-16, URGENT; the author: a level above the maximum corrupts the island): R-UPG's target level never exceeds control's maximum level of the building
 *   type. The target came from the player's setting upg.<Resource> / building.upgradeLevel.<Resource> ("Upgrade max", e.g. 7 for the mines) and the worklist asked
 *   "level 6 < 7" for a mine whose maximum is 6, leaving only control's safeguard to refuse it every cycle. targetLevel(resource, name) is now
 *   min(the player's value, DMA_Control.maxLevel(name)) — control's maximum is itself min(game, registered copy), 0.2.106 — so green never targets, requests or lists an
 *   upgrade above it; a type control does not know keeps the player's value. Unit: tests/unit/green-target-level-capped.test.js (setting 7, maximum 6 -> 6; setting 4 stays 4;
 *   no control -> the setting). Integration: tests/integration/green-target-level-real-control.test.js (real policy + real control: upg.IronOre = 7 -> target 6 for an IronMine).
 * 0.8.28 (2026-11-16, coordinator, model v3.18 PR #431; adapter 0.2.4): the exception to ELS-32 is a property of the buff KIND (game fact BUFF ACTION,
 *   docs/05-ontology/dma/facts/buff-actions.yaml), not a flag on the order. R-EV-COUNTER no longer puts replace:true / was on its order; applyBuff
 *   asks GCAF_GameInterface.buffAction(order.buff, the running buff in the location manager's picture): a buffed building is declined "already
 *   buffed" unless that pair is registered, and the TK41 record still notes replace / was when it is (so the declare waits for the buff to
 *   change). ctx.replace / ctx.was are no longer passed to the adapter, which decides on the item's kind. Unit/integration:
 *   tests/integration/dma-trick-treat.test.js (the counter order carries no replace or was; the Treat still goes, a mill with another buff gets
 *   nothing) and dma-tk41-transaction.test.js (the replacing order is declared when the buff changes). Needs adapter 0.2.4 merged first.
 * 0.8.27 (2026-11-16, architect review of #412–#422, decision (b); adapter 0.2.2): a replace order NAMES the buff it replaces. The counter rule R-EV-COUNTER (a Treat
 *   answering a trick) puts the trick it answers into the order (order.was = c.when) and applyBuff passes it to the adapter as
 *   ctx.was next to ctx.replace; adapter 0.2.2 lets the send pass only when the building's running buff is that one — never any
 *   running buff. Without was a replace order is now refused ("already buffed", replace refused). Unit/integration:
 *   tests/integration/dma-trick-treat.test.js (the Treat order carries was and goes; an order without was is declined).
 * 0.8.26 (2026-11-16, tester batch on ADR 0073; coordinator): a TRANSIENT refusal is not a decline. When the adapter answers retry: true (a hold or
 *   the pace), applyBuff, the R-BUFF-CHOICE job and the Love Tree start wait: no TK41 decline, no "buff refused" block of the grid
 *   for 10 minutes (that block is for a refusal that will not pass), the order stays open and is carried out on a later cycle; the
 *   answer is { fact: "wait", reason }. Unit/integration: tests/integration/green-buff-through-adapter.test.js (a pace refusal ->
 *   fact "wait", nothing declined, the grid not blocked, the next cycle sends).
 * 0.8.25 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR 2 of the migration): the buff applier no
 *   sends itself. applyBuff, the R-BUFF-CHOICE job and the Love Tree start go through the Game Interface Adapter
 *   (GCAF_GameInterface.sendAction("APPLY_BUFF", ...) / sendMessage("START_TIMED_PRODUCTION", ...)) — green never calls
 *   SendServerAction / SendMessagetoServer. The adapter decides (tribute never, verified kinds or the game's own check, never an
 *   already buffed building unless this is the construction manager's replace order, holds, pace); green records its answer:
 *   promise only on ok, otherwise decline with the adapter's reason (no adapter loaded = decline "game interface adapter not
 *   loaded", fail closed). Control's permit is no longer green's business (the adapter opens it for the one call): this is the fix
 *   of kf-green-buff-blocked-by-control, which moves into the suite as tests/integration/green-buff-through-adapter.test.js.
 *   Unit: tests/unit/dma-green-buff-prod.test.js (adapter loaded; a refusal -> decline with its reason, nothing promised).
 *   Integration: tests/integration/green-buff-through-adapter.test.js (real control + adapter + green: the buff reaches the game
 *   and the permit is closed again; a tribute and a buffed building are refused with the adapter's reason).
 * 0.8.24 (2026-11-16, architect assessment #403 step 2; V-model plan follow-up): retract() no longer calls the retired
 *   rgb module's retract (it always returned 0, and the module is in legacy-reference since #404). retract() still asks
 *   control's retractBuild and still returns 0. Nothing else changes.
 *   Unit: tests/unit/no-dma-rgb-in-src.test.js (green is off the list of rgb readers). Integration:
 *   tests/integration/dma-green-retract.test.js (green's retract with the real control: control's retractBuild
 *   is called with the grid and the reason; no rgb global needed).
 * 0.8.23 (2026-11-16, backbone v3.17 — ADR 0072 T-5, model PR #388, reconciliation R-21): a BARRACKS is buffed only
 *   while it trains for the troops. DFS-51 "[construction] trains for the troops": a Barracks / EliteBarracks whose
 *   queue in the location manager's troop picture (DMA_Demo.troops(), ADR 0040) has a row in production or a waiting
 *   row of more than 0 units. DFS-10 "needs buff": such a building is a candidate of R-BUFF-PROD (TK41 requested by AR20
 *   construction manager, executed by AR41 buff applier — "a buffer buffs; a troop manager manages troops") while it
 *   trains, with the same checks (not buffed, level, not upgrading, buff on its way, per-cycle limit); an idle barracks,
 *   or no troop picture, gets nothing ("not training for the troops (DFS-51)"). The troop manager never buffs
 *   (troops 0.1.2 has no buff code). No barracks on/off (T-6). Nothing else changes.
 *   Unit: tests/unit/dma-green-barracks-buff.test.js (training -> one R-BUFF-PROD order by the construction manager;
 *   idle or no picture -> declined "not training for the troops"). Integration: tests/integration/dma-barracks-buff-tk41
 *   .test.js (green with the C-fact memory and the agents' troop-picture shape: a training Elite Barracks gets a TK41
 *   case requested by the construction manager and promised by the buff applier; once idle, none).
 * 0.8.22 (2026-11-16, architect on PR #389; backbone role AR41 "buff applier"): the executor of TK41 is recorded as
 *   "buff applier" instead of "buffer" in every fact green writes (promise, decline, the tacit allow, the observed
 *   declare) and in the rules table; DMA_Buffer.actor is "buff applier". Nothing else changes.
 *   Unit: tests/unit/dma-green-buffer-role.test.js (DMA_Buffer.actor is "buff applier"). Integration:
 *   tests/integration/dma-event-buff-ar20.test.js (an event buff's TK41 facts: requested by the construction manager,
 *   promised by the buff applier; no "buffer" actor).
 * 0.8.21 (2026-11-16, backbone v3.16 — ADR 0071 D-3 "a" and D-4 "ja"; reconciliation R-03 and R-12):
 *   (1) D-3: the event buffs are rules of AR20 construction manager (ARS-20-11, given "the running events"; no initiator
 *   link AR76 -> TK41). R-EV-BUFF-WHEN and R-EV-COUNTER now record TK41 requests with initiator/actor "construction
 *   manager" (was "event manager") and cite ARS-20-11; the other TK41 rules (R-BUFF-WHEN, R-BUFF-PROD, R-ZONE-LOVETREE)
 *   record the backbone's name too (was "buff manager"). "An event of <type> is running" (DFS-42/DFS-48) is read from the
 *   location manager's events picture (DMA_Demo.eventRunning, agents 0.4.27; ADR 0040) with the event type's game-name
 *   prefixes (the rule data of DMA_Event.status, the player's event.<type>.gameNames); without the picture the two event
 *   rules order nothing ("no events picture") — fail closed. Which buildings an event brings and its counters stay the
 *   event's rule set (DMA_Event).
 *   (2) D-4: R-BUFF-PROD reads the target level of a production building from the construction type policy,
 *   ctype.<Type>.targetLevel (AT70, policy 0.2.60), before the older per-building key building.upgradeLevel.<Name>.
 *   Unit: tests/unit/dma-green-v316.test.js (initiator names; event rules gated on the picture; ctype target level
 *   first). Integration: tests/integration/dma-event-buff-ar20.test.js (green + event + agents-shaped picture + C-fact
 *   memory: an event buff is a TK41 request by the construction manager while Halloween runs, none without it).
 * 0.8.20 (2026-11-09, author: "Green onthoudt alleen en doet berekeningen. Een rode transactor role bufft"): the
 *   buffer — the red transactor role that executes TK41 (applyBuff, startLoveTree) — is published as its own role,
 *   root.DMA_Buffer { actor "buffer", tk "TK41" }, so the event and quest managers route buff orders to the buffer, not
 *   to green. Green keeps remembering and computing (the best buff, the plans). The buffer's code still lives in this
 *   file; moving it to its own module is the next step (ADR 0054 addendum). Behaviour unchanged.
 *   Unit: tests/unit/dma-green-buffer-role.test.js; integration: live, DMA_Buffer is loaded and the EVENT page shows
 *   the buff part executed by "buffer (TK41)".
 * 0.8.19 (2026-11-09, review of the auto choice against the island's star): R-BUFF-PROD-CHOICE also keeps Rainbow Snow
 *   (ProductivityBuffLvl12) for endless buildings, as R-BUFF-CHOICE does (rule.R-BUFF-CHOICE.rainbowOnlyEndless); without
 *   it the most buff-time in stock was Rainbow Snow (332 x 4 days). The auto pick on a workyard is now Lvl7 (+400 %, 12 h).
 * 0.8.18 (2026-11-09, author: "Buffing is always good when at the determined level" — "Extend the buff manager for all
 *   building"): rule R-BUFF-PROD of the BUFF MANAGER (switch Buff, ARS-40-11, request TK41). Every production building in
 *   the location manager's picture (control 0.2.88: prod, producing) that is not a mine slot and not an event building,
 *   produces now (active, not waiting for input), is not buffed, not upgrading, not busy, has no buff on its way and stands
 *   at its determined level (policy building.upgradeLevel.<BuildingName>, the "Upgrade max" setting the mines use per resource; none set = its current level) gets an order to the buffer.
 *   The buff (R-BUFF-PROD-CHOICE, computed here): the player's choice for the building type (BUFF screen, buff.prefs;
 *   "none" = never buff this type); else, among the single-building buffs the game accepts on that grid (target group,
 *   fallback IsApplyable), not reserved for the mines (buff.name.<R>, buff.defaultName) and with more than minStock left,
 *   a buff that names the building type before the generic Workyard buffs, then the most buff-time in stock
 *   (stock x duration), so the auto choice does not burn scarce buffs. Area and zone buffs are not chosen here.
 *   Params rule.R-BUFF-PROD.on (true), maxPerCycle (3), minStock (20).
 *   Unit: tests/unit/dma-green-buff-prod.test.js; integration: live, an unbuffed producing Toolmaker at its level gets
 *   a buff order and the buffer's promise within one cycle.
 * 0.8.17 (2026-11-05, ADR 0048, author: "Zorg dat je weet welk avontuur je moet spelen als je een bepaalde grondstof
 *   nodig hebt" — "Ja maak er maar een business rule van"): rule R-ADV-LOOT of the ADVENTURE MANAGER (AR17, ARS-17-11).
 *   Facts: the stock trends of the location manager (DMA_Demo.stockTrends), the adventure loot reference facts
 *   (DMA_AdvLoot, external fact bank tsowiki.eu), the adventures in the star and the versions in the adventure book.
 *   A stock that falls and runs out within adv.loot.horizonHours gets the adventure that yields most of it among those
 *   in reach (adv.loot.from: star | star or book | any); the best overall is named to obtain when it is not in reach.
 *   The advice is an informational fact (record "i", what "adventure advice"), once per resource per 6 h; it does not
 *   start an adventure — the player decides (adv.<id>.on). Shown on the ADVS page; lootAdvice() returns the last advice.
 *   Unit: tests/unit/dma-adv-loot.test.js; integration: a falling resource shows its adventure on the ADVS page.
 * 0.8.16 (2026-11-04, author 14:19 "Ja": the cockpit showed 14 upgrades promised since 2026-11-02/03 that the game never
 *   started; the ledger kept them, so the mines were never upgraded): rule R-UPG's setting revokeHours defaults to 2
 *   (was 0 = never). After 2 h without the game starting it, the construction manager revokes its request (DEMO 4:
 *   revoke request, the game allows tacitly) — but only when control.releaseUpgradeOrder (0.2.85) confirms that no
 *   upgrade runs and the level is unchanged; then the ledger lets the mine be requested again. A setting
 *   (rule.R-UPG.revokeHours) changes the term; 0 switches it off.
 *   Unit expectation: dma-upgrade-revoke.test.js. Integration expectation: each stuck upgrade is revoked once, then
 *   requested again when it is due.
 * 0.8.15 (2026-11-04, backbone v3.12 and v3.11 — ADR 0041, ADR 0045; author 09:11 "Dat moet constructie manager worden,
 *   waarbij constructie bouwer en constructie upgrader hetzelfde is", 08:33 "Indien hij beperkt wordt door een bouwrij,
 *   dan worden de beschikbare plaatsen gebruikt door de eerste gebouwen en zodra een gebouw gerealiseerd is, wordt de
 *   vrijgekomen plaats aangevuld met het volgende gebouw uit de wachtrij"): an implementation change, the ontology
 *   is not touched.
 *   (1) An upgrade is TK21 construction composing to the next level: the acts are recorded as TK21 with key
 *       "<grid>@<level>" (level = from + 1) and actor "construction manager" (was TK31 / "upgrade manager"); R-UPG
 *       reads the open composition of a grid from the transaction book under TK21. A construction (level 1) keeps key
 *       "<grid>". Behaviour is unchanged.
 *   (2) A construction the build queue cannot take yet is NOT declined: it stays on the construction composer's agenda
 *       — promised once ("on the agenda; realised when the build queue has a place") and realised when a place is free
 *       (the order taken adds no act: sending is not an execute, 0.8.x). Only a real refusal is a decline; missing material stays a decline (the
 *       accepted resource promise rule, project-memory).
 *   Unit expectation: dma-construction-composing.test.js — a queue-full wait gives one promise and no decline; the next
 *   wait gives nothing; the later ex adds nothing (the promise stands); an upgrade request is TK21 "<grid>@3" for a mine at level 2.
 *   Integration expectation: live, no TK21 decline with "queue-full" / "previous order not confirmed", and the facts
 *   show TK21 compositions to level 2 and 3 instead of TK31.
 * 0.8.14 (2026-11-02, release audit R4): the demolish order names the building green decided on (the slot's name), so
 *   control 0.2.78 refuses it when another building stands on the grid by the time the order is sent.
 *   Unit: tests/unit/dma-release-safety.test.js (control side); integration: dma-tk51-transaction.test.js.
 * 0.8.13 (2026-11-02, author: "upgrades komen niet in de bouwrij"): R-SLOT setting upgradesUseQueue defaults to false —
 *   an upgrade takes no build-queue slot, so upgrades no longer use up the slots of this cycle and no longer wait for
 *   one. The player can still set rule.R-SLOT.upgradesUseQueue in the policy. Builds: unchanged (control 0.2.77 counts
 *   build orders in flight and sends them one by one).
 *   Unit: tests/unit/dma-green-upgrade-no-slot.test.js. Integration: tests/integration/dma-build-order-lost.test.js.
 * 0.8.12 (2026-11-02, test of this version: while a mine upgraded, "TK31 execute" was written every 30 s cycle — six
 *  mines gave 9 executes in one minute): the execute (the game observed carrying out the upgrade) is recorded once per
 *  transaction, when it first shows. Behaviour unchanged.
 *  Unit/integration expectation: dma-tk31-transaction (one execute per upgrade over many cycles).
 * 0.8.11 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *  - TK21: a work-list item the game dropped is voided (revoke request + allow, as 0.8.6) and goes back on the list as a
 *    NEW request (was the act "reopen", outside DEMO 4 — and the next promise then had no instance to land on).
 *  - A send error is information (kind "i"), not a C-fact. Behaviour unchanged.
 *  Unit/integration expectation: dma-green-worklist (dropped order: revoke request, allow, request; then promise lands);
 *  tests/unit/dma-demo4-acts.test.js.
 * 0.8.10 (2026-11-02, ADR 0038 migration step 4, author: "Voor de specialisten geldt hetzelfde ... als een zoekactie
 *  afgesloten is en een nieuwe zoekactie wordt gestart kan de oude transactie informatie naar het historie document"):
 *  TK11 (deposit search) is one transaction per search, keyed by its search id (resource#send time#n), with the full
 *  DEMO 4 pattern; what the specialist manager sends is unchanged.
 *  request (specialist manager; R-GAP / R-DUE / R-LF; recorded with the send, with the geologist when there is one) ->
 *  promise (the game, observed: the geologist has the search 30 s after the send) | decline (the send was refused, or the
 *  geologist is still idle after 30 s: "the game did not start the search" — was the act "failed") -> declare (the game,
 *  observed: the geologist is back, idle or on another task) -> accept (specialist manager). A request with no answer
 *  after 10 min (e.g. a restart within the 30 s): promise when the geologist is out on it, else revoke request + allow.
 *  The closed search goes to the history document (transactions 0.4.3). The 30-min back-off per refused resource stays.
 *  Unit/integration expectation: tests/integration/dma-tk11-transaction.test.js — a search gives request, promise,
 *  declare, accept under its own id; two searches for one resource are two transactions; a refused start is a decline.
 * 0.8.9 (2026-11-02, ADR 0038 migration step 3, author: "ga dan verder met ADR 0038 stap 3: TK51"): TK51 (mine
 *  demolition) records its full pattern of C-facts; what the demolish manager does is unchanged.
 *  request (initiator: the demolish manager, R-DEMO-EMPTY / R-DEMO-LAND / R-DEMO-LOW; control's R-REPAIR-CORRUPT records
 *  its own request, control 0.2.72) -> promise (the game took the destruct command; was recorded as "execute") | decline
 *  (refused: away from home, execute off, safeguard, no building) -> declare (the game, observed: the mine is gone from
 *  the grid — no building, another building, or no longer a mine) -> accept (the initiator). Execute stays tacit. A
 *  promise without the mine gone within 10 min: revoke request + allow, reason "the game did not demolish it"; a request
 *  that was never answered within 10 min (the action was skipped): revoke request + allow. Declare and accept are made
 *  for every TK51 in progress, whoever initiated it, whether Demo is on or off.
 *  Unit/integration expectation: tests/integration/dma-tk51-transaction.test.js — R-DEMO-LOW and R-REPAIR-CORRUPT each
 *  give request, promise, declare, accept; a demolition the game did not carry out gives revoke request + allow; a refusal
 *  is a decline; one destruct command per mine, as before.
 *  Also: the 10-min lost check of TK41 counts from the promise that opened the state, not from a repeated one.
 * 0.8.8 (2026-11-01, ADR 0038 migration step 2, author: "Ga verder met ADR 0038, stap 2: TK41 (buffen)"): TK41 (buff
 *  application) records its full pattern of C-facts; what the buff manager, the event manager and the buffer do is
 *  unchanged (the 10-min "on its way" marker dma-buff-sent.json stays the rule fact; it is now also visible as "TK41
 *  promised" in the C-fact memory).
 *  request (initiator: buff manager for R-BUFF-WHEN / R-ZONE-LOVETREE, event manager for R-EV-BUFF-WHEN / R-EV-COUNTER;
 *  recorded with "initiator") -> promise (the buffer sends the buff / starts the Love Tree; was recorded as "execute") |
 *  decline (the buffer refuses: no building, already buffed, upgrading, not home, no accepted buff ...; the mine path
 *  now records these too, it only wrote them to the cycle log) -> declare (the buffer, observed: the game shows the buff
 *  on the grid; for a replacing order the building's buff changed; for the Love Tree its zone buff runs) -> accept (the
 *  initiator). Execute stays tacit (the game applies the buff). A promised buff the game does not show within 10 min,
 *  a request the buffer never took up within 10 min, and a building that is gone: the initiator records revoke request,
 *  the buffer allow (tacit) — the transaction is void and a later request is a new one (the marker expired in the same
 *  10 min, as before).
 *  Unit/integration expectation: tests/integration/dma-tk41-transaction.test.js — mine, event order, counter (replace)
 *  and Love Tree each give request, promise, declare, accept; a buff not shown in 10 min gives revoke request + allow
 *  and then one new request; a refusal is a decline; buffer-order and lovetree tests unchanged.
 * 0.8.7 (2026-11-01, author: "demo 4 second edition kent geen stop en quit, dus zorg dat je het juiste patroon
 *  gebruikt"): no "quit" any more. After a decline the transaction rests in the discussion state "declined"; the next
 *  request R-UPG / the build manager makes for that grid is the renewed request of the same transaction (DEMO 4 CTP).
 *  R-UPG's rule fact is "a TK31 is in progress" (requested, promised, declared, rejected, or a revocation pending), read
 *  with DMA_Tx.inProgress; a declined one does not block the renewed request. revoke request + allow stay (rv-rq by the
 *  initiator, allow by the executor, tacit). Behaviour unchanged.
 *  Unit/integration expectation: dma-tk31-transaction and dma-green-worklist: no quit/stop in the facts; a declined TK31
 *  is renewed by the next request (same instance).
 * 0.8.6 (2026-11-01, author: "cancel is geen coordinatiehandeling, houd de terminologie van demo consequent aan. Als het
 *  in de implementatie iets anders is, dan komt dat in de DAO theorie naar voren, wij houden nu de ontologie bij"): only
 *  DEMO 4 acts are recorded for TK21 and TK31. Where 0.8.4/0.8.5 wrote "cancel" or "revoke", the initiator now records
 *  "revoke request" and the executor's "allow" (tacit, recorded by the initiator); after a "decline" the initiator
 *  records "quit" (a later request is a new transaction). Execute stays the production act. What the actor roles do is
 *  unchanged; why the game dropped an order or a mine is gone is DAO, recorded in "reason".
 *  Unit/integration expectation: tests/integration/dma-tk31-transaction.test.js and dma-green-worklist.test.js read
 *  only DEMO 4 acts in the C-fact memory (revoked via revoke request + allow; quitted after decline).
 * 0.8.5 (2026-11-01, ADR 0038 migration step 1, author "ja"): TK21 (mine construction) records its full pattern of
 *  C-facts; what the build manager does is unchanged. request (on the work list; a later R-SLOT request is a repeated
 *  request) -> promise (the game took the order; was recorded as "execute") | decline -> declare (the game shows the mine;
 *  actor now the game, observed) -> accept (build manager). The game dropping the order is "cancel" (then "reopen" on the
 *  work list as before); a work-list item that leaves because its deposit is no longer free is "revoke" (was "withdrawn").
 *  Also for every kind: a rule row that decides NOT to request now (waiting for a slot, level below target, covered,
 *  ...) is the initiator's own assessment, not a decline by the executor. It is recorded as act "assess" (outcome
 *  "not now"), no longer as "decline", so the C-fact memory does not read it as the end of a transaction. A real refusal
 *  by the game or a safeguard stays "decline". Logging pace (first, on change, hourly) as 0.6.1.
 *  Unit expectation:        a build that the game carries out gives request, promise, declare, accept for its grid in the
 *                           C-fact memory (execute tacit); a lost order gives cancel then a new request; behaviour and
 *                           work list as 0.8.0 (tests/integration/dma-green-worklist.test.js unchanged).
 *  Integration expectation: live, every TK21 instance in dma-transactions.json ends accepted, cancelled or revoked.
 * 0.8.4 (2026-11-01, author: "elke transactie kent coordinatiehandelingen en de feiten daarvan. Dit dient onthouden te
 *  worden door groen en als het nodig is, kan rood dit opvragen. Een boek is een blauwe transactie om het vast te leggen.
 *  Het mag de gehele werking ... niet wijzigen. Het is alleen dat je de feiten kunt gebruiken bij logische
 *  bedrijfsregels", ADR 0038 amended): the upgrade manager records its TK31 acts as C-facts, like every actor role
 *  (request, promise | decline, execute, declare, accept, cancel, revoke); the C-fact memory (DMA_Tx 0.2.0, green)
 *  remembers them, and R-UPG uses that memory as a fact in its rule: no new TK31 request while one is open. Green no
 *  longer asks a "book" for permission; nothing else changes. Behaviour as 0.8.2.
 *  Unit/integration expectation: tests/integration/dma-tk31-transaction.test.js (acts and behaviour as 0.8.2/0.8.3).
 * 0.8.3 (2026-11-01, author: "Dit is dus standaard voor alle transacties. Voor alle transacties zou je de status bij moeten
 *  houden", ADR 0038): TK31 is kept in the shared transaction book DMA_Tx (user_dma_transactions.js, dma-transactions.json)
 *  instead of green's own dma-tk31.json; open TK31s from that file are moved into the book once. The book refuses a
 *  second request while one is open and records every act as a fact. Behaviour as 0.8.2.
 *  Unit/integration expectation: tests/integration/dma-tk31-transaction.test.js unchanged in its acts, now read from
 *  DMA_Tx.list({ tk: "TK31" }); dma-tk31.json is migrated.
 * 0.8.2 (2026-11-01, author: "een upgrade order is een verzoek tot upgraden, een nieuw verzoek terwijl een mijn al aan het
 *  upgraden is, is onzin. als de upgrade gedaan is, krijg je een declare, waardoor de verzoeker weet dat de upgrade gedaan
 *  is waarna hij hem accepteert, pas dan indien het nieuwe level nog niet het gewenste level is, kun je een nieuw upgrade
 *  verzoek doen"): TK31 is a DEMO transaction per grid, kept in dma-tk31.json. request (R-UPG decides) -> promise (the
 *  game took the order) | decline (refused: no transaction) -> execute (the game shows the upgrade running) -> declare
 *  (the game shows a higher level, the upgrade no longer running) -> accept (the upgrade manager). While a transaction is
 *  open there is NO new request for that grid, however long it takes; only after the accept, and only when the level is
 *  still below the target, R-UPG may request again. The 15-minute order marker no longer opens the way for a new
 *  request. A transaction ends without a declare only when the building on the grid is gone or another one (rebuilt):
 *  "cancel". Optional rule.R-UPG.revokeHours (default 0 = never) lets the upgrade manager revoke an order the game never
 *  carried out.
 *  Unit expectation:        a promised TK31 at level 2 blocks every further request while the level stays 2 (any number
 *                           of cycles, any time); level 3 shown and not upgrading -> declare + accept, and one new
 *                           request when the target is higher; a rebuilt mine cancels; the file survives a reload.
 *  Integration expectation: live, one TK31 execute per level per mine in the facts, each followed by declare + accept.
 * 0.7.8 (2026-10-29, author: "they are putting tricks on my building, you can go after it with treats" — "a scan must
 *  be able to tell"): R-EV-COUNTER (event manager) — a building whose buff in the location manager's scan (buffName)
 *  contains a running event's counter `when` (Halloween: "trick") gets an order to the buffer with its `give` (a Treat),
 *  replacing the buff there; up to maxPerCycle per cycle. The buffer accepts an order with replace: true on a buffed
 *  building, and finds the buff by its definition name or its shown name.
 * 0.7.7 (2026-10-29, ADR 0029, author: "Alles wat gerelateerd is aan het event plaats je bij het event. Alles wat in
 *  algemeenheid gerelateerd is aan buffen, plaats je bij de buff. Een actor role verantwoordelijk voor het buff, krijgt een
 *  opdracht te buffen, op een bepaalde locatie, met een specifieke buff. Hij is zich niet bewust dat het hier gaat om een
 *  begraafplaats die er alleen is met een halloween event. Separations of Concerns."):
 *  - R-EV-BUFF-WHEN now belongs to the EVENT MANAGER: while its type runs and the player's rule event.<type>.buff.on is
 *    set, it decides, with green's computation (R-EV-BUFF-CHOICE, minus event.<type>.buff.exclude), WHICH buff goes on
 *    WHICH grid, and hands the buffer an order { grid, buff }.
 *  - The BUFFER (applyBuff) carries out any such order: it finds the named buff in the star menu and applies it to the
 *    grid when the building is there, not buffed, not busy and the player is home. It knows nothing of events or
 *    cemeteries. Facts: TK41 request by the event manager, execute/decline by the buffer.
 *  The 0.7.4 settings buff.event.on / buff.event.exclude are no longer read.
 * 0.7.6 (2026-10-29, author: "Je hoeft met een dergelijke vraag niet te wachten tot de buff is afgelopen. Het valt onder
 *  een specifiek type buff en welke buffs komen daarvoor in aanmerking? Welke daarvan heb ik en welke levert het meeste
 *  op?"): which buffs qualify is a property of the buff TYPE, not of the building's state. Read from client.swf: every
 *  buff definition names a target group (cBuffDefinition.GetTargetGroup_string), and BuffSystem:BuffTargetGroups knows
 *  which buildings a group holds (groupContains). Green now decides eligibility from that, so the options show while
 *  the building is still buffed; IsApplyable (which refuses a buffed building) is only the fallback when the groups
 *  cannot be read. eventPlan shows the target group of each option.
 * 0.7.5 (2026-10-29, live: no event building found): event buildings are recognised with DMA_Event.match, which ignores
 *  case and underscores in the game's building name.
 * 0.7.4 (2026-10-29, decision 0026; author: "Buff manager kijkt wat er gebuft moet worden aan de hand van de eiland
 *  feiten, initieert de buffer. Het event brengt de begraafplaatsen met eigenschappen" — "Als je een keuze hebt uit buff
 *  types, laat je groen uitrekenen wat de meest gunstige is qua pompoenen" — "neem alle mogelijke buffs mee"):
 *  - R-EV-BUFF-WHEN (buff manager, setting buff.event.on, default off): a building that the running event declares
 *    buffable (DMA_Event.buffable(): the pumpkin cemeteries), seen unbuffed in the location manager's scan and not busy,
 *    is buffed. Highest base rate first (noble before common before small).
 *  - R-EV-BUFF-CHOICE (computed in green): for EVERY buff in the star menu that the game accepts on that grid
 *    (IsApplyable) and that the player has not excluded (buff.event.exclude), green computes the extra output
 *    = bonus % / 100 x duration / the event's seconds per unit, and the buffer uses the highest.
 *    DMA_Green.eventPlan() shows the options per building for the BUFF screen.
 *  No cemetery knowledge here: the names and rates come from the event's declaration.
 * 0.7.3 (2026-10-25, author: "we decide what can and cannot be; if a rule counts the occupied spots, the same rule holds
 *  for sending a geo — he finds a new deposit just after that mine is demolished — so that spot is not counted as
 *  occupied"): a mine demolished in this cycle (R-DEMO-EMPTY, R-DEMO-LOW at or below the threshold) counts as a FREE
 *  spot for the search rules of the same cycle; the send sequence demolishes first and starts the searches 5 s after
 *  the last demolition, so the spot is free when the geologist leaves. Fixed on the way: the sort put demolitions
 *  LAST, not first — RANK.demolish is 0 and "0 || 9" is 9.
 * 0.7.2 (2026-10-25, live after the 19:01 restart: the two copper replacement searches of 0.7.1 were refused AT THE START —
 *  "the game did not start the search (geologist idle after 30 s)" — so the game checks the deposit limit when the
 *  search starts, not when the find lands; a geologist cannot be sent ahead while every spot is occupied). So, with
 *  every spot occupied: no replacement search (decline says why), and a mine at or below the demolish threshold is
 *  demolished WITHOUT waiting for a replacement when an idle geologist is there (R-DEMO-LOW "makes room"); R-GAP then
 *  sends the search for the freed spot in the next cycle. The threshold is the moment of the change-over.
 * 0.7.1 (2026-10-25, author: "that is what the threshold is for: from it you can send a geo on that line that finds a
 *  new deposit right after the demolition"): with every spot occupied, a due mine counts for a replacement search when
 *  it will reach the demolish threshold within the search time (island eta of amount - threshold <= the resource's
 *  search lead): the geologist is sent so that he returns as the mine reaches the threshold, R-DEMO-LAND demolishes it
 *  (at or below the threshold) and the find lands at once. Not earlier (the find would be refused) and not only once
 *  the mine is already at the threshold (0.7.0 lost the search time).
 * 0.7.0 (2026-10-25, author: "I have 6 copper mines running and you send two new searches — is that to find them right
 *  after the demolition?"): yes, R-DUE sends a replacement when a mine runs out within the search lead — but with every
 *  spot occupied the game refuses the find ("Geologist failed: too many deposits of this type") until a mine is
 *  demolished, and since 0.6.8 a mine is demolished only at or below the threshold. The facts showed 2 copper searches
 *  every 4-5 min (17:43, 17:47, 17:52) for mines with 64 and 67 left, each failing. Now, with no empty spot, a due mine
 *  counts for a replacement search only when it is at or below the demolish threshold (it can make room at once:
 *  R-DEMO-LOW demolishes it as soon as the search is out). Above it the decline says so.
 * 0.6.9 (2026-10-25, author: "when I go to another island the orders must stop"): every action of a send sequence
 *  checks DMA_Control.atHome() just before it is sent, so a sequence that started at home stops when the player leaves.
 * 0.6.8 (2026-10-25, growth analysis: R-DEMO-LAND demolished 8 iron mines holding 348-365 ore to make room for a find;
 *  author: "the threshold is at 20, that is what it is for"): R-DEMO-LAND too demolishes only a mine at or below the
 *  demolish threshold (demolish.threshold, default 20). A lowest mine above it is a decline ("N left, above the
 *  threshold"), recorded like every decline; the find waits for a spot.
 * 0.6.7 (2026-10-25, production analysis "all resources must grow"): a geologist send the game does not start is no
 *  longer counted as a search and re-sent every cycle. The facts showed TK11 R-GAP Marble "sent" ≈ 600 times an hour for
 *  about 16 of 34 hours (24th 14-22 h, 25th 02-06 h UTC), while the island's search record holds only 8 real Marble
 *  searches: the game refused them (e.g. no room for another deposit) and the refused command went to the server every
 *  few seconds. Now, 30 s after a send, the geologist is looked at: still idle = refused, fact TK11 "failed", and that
 *  resource gets no search for 30 min, doubling per refusal up to 4 h (a real search resets it). (Proposal P-1 for
 *  searches; the same verify-before-declare for TK21/TK31/TK41 stays the author's decision.)
 * 0.6.6 (2026-10-25, live: the AIR client's localStorage does not survive a restart): the buffs on their way are also
 *  kept in the file dma-buff-sent.json (read first at start).
 * 0.6.5 (2026-10-25, production check): a buff sent stays "on its way" for 10 min (or until the game shows it),
 *  persisted in localStorage "dma.buffSent.v1" so a restart does not forget it. The game shows productionBuff only
 *  once the settler has carried the buff to the mine, so R-BUFF-WHEN fired again every 30 s: 5 to 10 buffs per mine
 *  on 2026-10-25 09:57-10:08 (facts log: TK41 execute 59 times for about 12 mines).
 */
(function (root) {
    "use strict";
    var VERSION = "0.9.8";
    var last = [];
    var ORES = ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];
    var QUARRY = { Stone: 1, Marble: 1, Granite: 1 };
    var RANK = { demolish: 0, buff: 1, build: 2, upgrade: 3, search: 4 };

    /* ---------- the rule table ---------- */
    var RULES = [
        { id: "R-CAP", ars: "ARS-11-02", act: "promise TK11", actor: "deposit searcher",
          facts: ["DFS-13 the capacity of R", "ET47 deposit places of R (the game)", "learned spots of R (fallback)", "policy cap of R (fallback)"],   // 0.9.6 (backbone v3.40)
          text: "The capacity of R is the number of places the game holds for this player where a deposit of R can be found; only on a client that gives none: the spots seen, a learned proof, at least the policy cap.",
          params: {} },
        { id: "R-DUE", ars: "ARS-10-11", act: "request TK11", actor: "specialist manager (geo)",
          facts: ["eta of mine", "search lead time of R", "margin"],
          text: "A mine is due for replacement when its deposit runs out within the search lead time plus the margin.",
          params: { marginSeconds: 1800, defaultLeadSeconds: 7200, fallbackSecondsPerUnit: 33.3 } },
        { id: "R-GAP", ars: "ARS-10-11", act: "request TK11", actor: "specialist manager (geo)",
          facts: ["capacity of R", "mines of R", "free deposits of R", "due mines of R", "open searches of R"],
          text: "Searches needed for R = empty spots + due mines without a replacement - open searches.",
          params: {} },
        { id: "R-LF", ars: "ARS-10-11", act: "request TK11", actor: "specialist manager (geo)",
          facts: ["proven limit of R", "deposits of R", "lucky find extra found", "open searches of R", "geologist has Lucky Find"],
          text: "Iron or marble at its proven limit, extra deposit not yet found, no search open: send one geologist WITH Lucky Find.",
          params: {} },
        { id: "R-DEMO-EMPTY", ars: "ARS-51-02", act: "promise TK51", actor: "mine demolisher",
          facts: ["remaining amount of the deposit of the mine"],
          text: "A mine whose deposit is empty is demolished: it produces nothing and blocks the spot.",
          params: {} },
        { id: "R-DEMO-LAND", ars: "ARS-51-02", act: "promise TK51", actor: "mine demolisher",
          facts: ["open search of R and its remaining time", "empty spots of R", "remaining amount"],
          text: "When a geologist for R returns within the lead and R has no empty spot, the lowest mine of R is demolished so the find can land, provided it holds no more than the demolish threshold (0.6.8).",
          params: { leadSeconds: 600 } },
        { id: "R-DEMO-LOW", ars: "ARS-51-02", act: "promise TK51", actor: "mine demolisher",
          facts: ["remaining amount", "demolish threshold", "free deposits of R", "open searches of R"],
          text: "A mine at or below the demolish threshold is demolished when a replacement exists; one replacement covers one mine.",
          params: {} },
        { id: "R-SLOT", ars: "ARS-20-11", act: "request TK21", actor: "building manager",
          facts: ["free slots of the build queue"],
          text: "The building manager requests a construction only for a free build-queue slot; the rest waits (promise deferred).",
          params: { upgradesUseQueue: false } },   // 0.8.13: an upgrade takes no build-queue slot
        { id: "R-PRIO", ars: "ARS-20-11", act: "request TK21", actor: "building manager",
          facts: ["capacity of R", "mines of R", "deposit amount", "missing materials of R"],
          text: "Build first where R is furthest below capacity, then the richest deposit; skip R for a while when materials were missing.",
          params: { missingPauseSeconds: 600 } },
        { id: "R-UPG", ars: "ARS-20-11", act: "request TK21 (a level above 1)", actor: "construction manager",
          facts: ["level of mine", "upgrade target of R", "busy grid"],
          text: "A construction below its target level with no open composition to the next level is composed to that level; a composition the game did not start within revokeHours is revoked.",
          params: { revokeHours: 2 } },   // 0.8.16 (author 2026-11-04: an upgrade the game did not start within 2 h is revoked)
        { id: "R-BUFF-WHEN", ars: "ARS-20-11", act: "request TK41", actor: "construction manager",
          facts: ["level of mine", "upgrade target of R", "buffed", "upgrading", "busy grid"],
          text: "A mine at its target level, not buffed, not upgrading and not busy, is buffed.",
          params: { maxPerCycle: 3 } },
        { id: "R-BUFF-CHOICE", ars: "ARS-41-02", act: "promise TK41", actor: "mine buffer",
          facts: ["player buff choice for the building type", "buffs in the star menu", "game check IsApplyable"],
          text: "Use the player's buff for the building type; else the strongest buff the game accepts (bonus % x duration); Rainbow Snow only on endless mines.",
          params: { rainbowOnlyEndless: true } },
        { id: "R-BUFF-PROD", ars: "ARS-20-11", act: "request TK41", actor: "construction manager",   // 0.8.18
          facts: ["production buildings (location manager: prod, producing)", "level and determined level (building.upgradeLevel.<BuildingName>)", "buffed", "upgrading", "busy grid", "buff on its way"],
          text: "A production building that produces, is not buffed, not upgrading and not busy, and stands at its determined level gets an order to the buffer with the buff R-BUFF-PROD-CHOICE computes.",
          params: { on: true, maxPerCycle: 3, minStock: 20 } },
        { id: "R-BUFF-PROD-CHOICE", ars: "ARS-41-02", act: "promise TK41", actor: "buff applier (choice computed in green)",   // 0.8.18
          facts: ["player buff choice for the building type (buff.prefs)", "single-building buffs in the star menu", "the buff's target group", "buffs reserved for the mines (buff.name.<R>)", "stock and duration of each buff"],
          text: "The player's choice for the type ('none' = never); else a buff the game accepts on the grid, not reserved for the mines, above minStock: one that names the building type first, then the most buff-time in stock.",
          params: {} },
        { id: "R-ZONE-LOVETREE", ars: "ARS-20-11", act: "request TK41", actor: "construction manager",   // 0.8.1
          facts: ["Love Trees on the island and their level", "cooldown of the tree", "the recipes the level allows", "zone buffs running (own and same group)", "costs in stock"],
          text: "The Love Tree with the highest level is started as soon as its cooldown has ended, with the best recipe that level allows; never while its buff or another zone buff of the same group runs.",
          params: { on: true } },
        { id: "R-EV-BUFF-WHEN", ars: "ARS-20-11", act: "request TK41", actor: "construction manager",   // 0.8.21 (v3.16 D-3)
          facts: ["the buildings a running event type brings", "buffed (location manager's scan)", "busy grid", "buff on its way", "the player's rule event.<type>.buff.on"],
          text: "While its event type runs and event.<type>.buff.on is set, an event building that is not buffed, not busy and has no buff on its way gets an order to the buffer: this grid, the buff green computes as best; highest base rate first.",
          params: { maxPerCycle: 3 } },
        { id: "R-EV-COUNTER", ars: "ARS-20-11", act: "request TK41", actor: "construction manager",   // 0.8.21 (v3.16 D-3)
          facts: ["the buff on each building (location manager's scan)", "the running event's counters (event.<type>.<counter>.when / give / on)", "buff on its way"],
          text: "A building whose buff contains a running event's counter 'when' (a trick) gets an order to the buffer: the counter's 'give' (a Treat), replacing it.",
          params: { maxPerCycle: 5 } },
        { id: "R-ADV-LOOT", ars: "ARS-17-11", act: "advise the adventure for TK18 (the player decides)", actor: "adventure manager",   // 0.8.17
          facts: ["stock trend of R (location manager)", "adventure loot reference facts (tsowiki)", "adventures in the star", "versions in the adventure book", "the player's rules adv.loot.*"],
          text: "A stock that falls and runs out within the horizon gets the adventure that yields most of it among the adventures in reach; the best overall is named to obtain when it is not in reach.",
          params: {} },
        { id: "R-EV-BUFF-CHOICE", ars: "ARS-41-02", act: "promise TK41", actor: "buff applier (choice computed in green)",
          facts: ["the event's seconds per unit of the building", "every buff in the star menu", "bonus % and duration of each buff", "the buff's target group", "buffs the player excluded for the event (event.<type>.buff.exclude)"],
          text: "For every buff the game accepts on the building, green computes the extra output = bonus % / 100 x duration / seconds per unit; the buff with the highest extra output is used.",
          params: {} }
    ];
    function ruleById(id) { var i; for (i = 0; i < RULES.length; i++) if (RULES[i].id === id) return RULES[i]; return null; }
    function param(id, name) {
        var r = ruleById(id);
        var d = r && r.params ? r.params[name] : undefined;
        var v = pol("rule." + id + "." + name, null);
        if (v === null || v === undefined || v === "") return d;
        if (typeof d === "number") { v = Number(v); return isNaN(v) ? d : v; }
        if (typeof d === "boolean") return v === true || v === "true";
        return v;
    }

    function note(s) {
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
            if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200);
            root.__DMA_CYCLE_AT = Date.now();
        } catch (_) {}
    }
    function pol(k, d) {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && p.get) {
                var v = p.get(k);
                if (v != null && v !== "") return v;
            }
        } catch (_) {}
        return d;
    }
    function facts() {
        var mem = root.DMA_Demo && root.DMA_Demo.memory && root.DMA_Demo.memory();
        return (mem && mem.slots) || [];
    }
    function island() {
        try { if (root.DMA_Demo && root.DMA_Demo.island) return root.DMA_Demo.island(); } catch (_) {}
        return { capacity: function () { return 0; }, proven: function () { return false; }, spots: function () { return 0; },
                 eta: function () { return null; }, rate: function () { return null; } };
    }
    function ctrl() { return root.DMA_Control || null; }
    function isMineSlot(s) {
        return !!(s && (s.mine || /mine|mason|quarry/i.test(String(s.name || ""))) && !s.depleted);
    }
    function targetLevel(r, name) {   // 0.8.29: never above control's maximum level of the building type (ELS-33; the player's Upgrade max may say more)
        var max = Number(pol("upg." + r, pol("building.upgradeLevel." + r, 0)));
        if (!max || max < 1) return 0;   // 0.9.4 (UAT F2): no target set = no target (0); nothing is upgraded for this resource
        var cap = null; try { var C = root.DMA_Control; cap = name && C && typeof C.maxLevel === "function" ? C.maxLevel(String(name)) : null; } catch (_) {}
        return cap != null && Number(cap) >= 1 && Number(cap) < max ? Number(cap) : max;
    }

    /* ---------- busy grids (recent build/upgrade order) ---------- */
    var BUSY_MS = 15 * 60 * 1000;
    var recentOrder = {};
    function markOrder(grid, kind) { recentOrder[String(grid)] = { kind: kind, at: Date.now() }; }
    function busy(grid) {
        var Mb = null; try { Mb = root.DMA_ConstructionManager; if (Mb && Mb.ready && typeof Mb.busy === "function") return Mb.busy(grid) || ""; } catch (_) {}   // 0.9.2: the order's owner knows
        var r = recentOrder[String(grid)];
        if (r && Date.now() - r.at < BUSY_MS) return r.kind;
        if (r) delete recentOrder[String(grid)];
        try { var c = ctrl(); if (c && c.hasBuildOrder && c.hasBuildOrder(grid)) return "build"; } catch (_) {}
        return "";
    }
    function realLevel(b) {        // 0.2.19 incident: GetUIUpgradeLevel may be a fixed UI overwrite; take the higher of real and UI
        try { if (root.DMA_Control && typeof root.DMA_Control.levelOf === "function") return Number(root.DMA_Control.levelOf(b)) || 0; } catch (_) {}
        var r = 0, u = 0;
        try { r = Number(b.GetUpgradeLevel ? b.GetUpgradeLevel() : b.mUpgradeLevel) || 0; } catch (_) {}
        try { u = Number(b.GetUIUpgradeLevel ? b.GetUIUpgradeLevel() : 0) || 0; } catch (_) {}
        return Math.max(r, u);
    }
    function live(grid) {
        try {
            var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone);
            var b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid));
            if (!b) return null;
            return {
                name: b.GetBuildingName_string ? String(b.GetBuildingName_string()) : "",
                level: realLevel(b),                       // 0.6.3: real level, not the UI overwrite
                upgrading: !!(b.IsUpgradeInProgress && b.IsUpgradeInProgress()),
                buffed: b.productionBuff != null
            };
        } catch (_) { return null; }
    }

    /* ---------- timing facts ---------- */
    var leadCache = {};
    function leadSeconds(r) {
        var c = leadCache[r];
        if (c && Date.now() - c.at < 60000) return c.v;
        var v = null;
        try {
            var isl = root.DMA_Demo && root.DMA_Demo.island && root.DMA_Demo.island();
            var done = isl && isl.searches ? isl.searches().filter(function (x) { return x.resource === r && x.seconds > 0; }).map(function (x) { return x.seconds; }) : [];
            if (done.length) { done.sort(function (a, b) { return a - b; }); v = done[Math.floor(done.length / 2)]; }
        } catch (_) {}
        if (!v) try {
            var p = ctrl() && ctrl().predictSearch && ctrl().predictSearch(r);
            if (p) v = p.idleBest || p.median || null;
        } catch (_) {}
        if (!v) v = param("R-DUE", "defaultLeadSeconds");
        leadCache[r] = { v: v, at: Date.now() };
        return v;
    }
    function etaSeconds(s) {
        if (!s || s.amount == null) return null;
        var a = Number(s.amount);
        if (!(a >= 0)) return null;
        if (a === 0) return 0;
        var e = island().eta(s.grid, a);
        if (e != null) return e;
        return Math.round(a * param("R-DUE", "fallbackSecondsPerUnit") / (s.buffed ? 2 : 1));
    }
    function geologists() {
        try { return (ctrl() && ctrl().geologists && ctrl().geologists()) || []; } catch (_) { return []; }
    }

    /* ---------- missing materials (resource reservation declined) ---------- */
    var missingAt = {};
    /* ---------- buffs the game refused for a grid ---------- */
    var buffRefused = {};
    /* ---------- 0.6.7: searches the game did not start, per resource ---------- */
    var searchRefused = {};
    function searchBackoffMs(n) { return Math.min(4 * 3600000, 30 * 60000 * Math.pow(2, Math.max(0, n - 1))); }
    function searchHeld(r, now) { var x = searchRefused[r]; return x && (now || Date.now()) - x.at < searchBackoffMs(x.n) ? x : null; }
    var REFUSE_MS = 10 * 60 * 1000;
    /* 0.6.5: buffs on their way (the game shows productionBuff only when the settler arrives) */
    var BUFF_SENT_MS = 10 * 60 * 1000, buffSent = {};
    function airF() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function fileRead(name) {
        try { var a = airF(); if (!a) return null; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function fileWrite(name, obj) {
        try { var a = airF(); if (!a) return false; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    /* ---------- 0.8.0: the work list — green remembers what has to be built; blue decides when ---------- */
    var WORK_FILE = "dma-worklist.json", WORK_LOST_MS = 10 * 60000, work = {};
    try { work = (fileRead(WORK_FILE) || {}).items || {}; } catch (_) { work = {}; }
    function saveWork() { fileWrite(WORK_FILE, { format: "dma-worklist/1", at: new Date().toISOString(), items: work }); }
    function mineOn(grid) {
        try { var z = game.zone || (game.gi && game.gi.mCurrentPlayerZone); var b = z && z.GetBuildingFromGridPosition && z.GetBuildingFromGridPosition(Number(grid));
              return !!(b && /mine|mason/i.test(String(b.GetBuildingName_string ? b.GetBuildingName_string() : ""))); } catch (_) { return false; }
    }
    function workWant(grid, resource, why) {   // an item green wants; blue's reason for waiting is kept with it
        var k = "build@" + grid, it = work[k], now = Date.now(), changed = false;
        if (!it) { it = work[k] = { kind: "build", grid: String(grid), resource: resource, state: "open", since: now, at: now, attempts: 0, why: why }; record("c", { tk: "TK21", act: "request", actor: "build manager", rule: "WORKLIST", resource: resource, grid: grid, reason: "on the work list: " + why }); changed = true; }
        else if (it.state === "open" && it.why !== why) { it.why = why; it.at = now; changed = true; }
        return changed;
    }
    function workSent(grid, resource) { var k = "build@" + grid, now = Date.now(); var it = work[k] || (work[k] = { kind: "build", grid: String(grid), resource: resource, since: now, attempts: 0 }); it.state = "sent"; it.sentAt = now; it.at = now; it.why = "order given to the game"; saveWork(); }
    function workReview(freeGrids, queued) {   // done / reopen / withdrawn
        var k, it, now = Date.now(), changed = false;
        for (k in work) {
            if (!work.hasOwnProperty(k)) continue; it = work[k];
            if (mineOn(it.grid)) { delete work[k]; changed = true; record("c", { tk: "TK21", act: "declare", actor: "game (observed)", rule: "WORKLIST", resource: it.resource, grid: it.grid, reason: "mine stands", attempts: it.attempts }); record("c", { tk: "TK21", act: "accept", actor: "build manager", rule: "WORKLIST", resource: it.resource, grid: it.grid }); continue; }
            if (it.state === "sent" && !(queued && queued[String(it.grid)]) && now - (it.sentAt || 0) >= WORK_LOST_MS) {
                it.state = "open"; it.attempts = (it.attempts || 0) + 1; it.at = now; it.why = "the game did not build it; back on the list"; it.promised = 0;   // 0.8.15: a new instance
                changed = true; record("c", { tk: "TK21", act: "revoke request", actor: "build manager", rule: "WORKLIST", resource: it.resource, grid: it.grid, reason: "the game did not build it" }); record("c", { tk: "TK21", act: "allow", actor: "game (tacit)", rule: "WORKLIST", resource: it.resource, grid: it.grid }); record("c", { tk: "TK21", act: "request", actor: "build manager", rule: "WORKLIST", resource: it.resource, grid: it.grid, attempts: it.attempts, reason: "back on the work list" });   // 0.8.11: a new request (was "reopen")
                continue;
            }
            if (it.state === "open" && freeGrids && !freeGrids[String(it.grid)]) { delete work[k]; changed = true; record("c", { tk: "TK21", act: "revoke request", actor: "build manager", rule: "WORKLIST", resource: it.resource, grid: it.grid, reason: "the deposit is no longer free" }); record("c", { tk: "TK21", act: "allow", actor: "game (tacit)", rule: "WORKLIST", resource: it.resource, grid: it.grid }); }
        }
        return changed;
    }
    try { buffSent = (fileRead("dma-buff-sent.json") || {}).sent || JSON.parse(localStorage.getItem("dma.buffSent.v1") || "{}") || {}; } catch (_) { buffSent = {}; }
    function saveBuffSent() { try { localStorage.setItem("dma.buffSent.v1", JSON.stringify(buffSent)); } catch (_) {} fileWrite("dma-buff-sent.json", { format: "dma-buff-sent/1", sent: buffSent }); }
    /* ---------- 0.8.2/0.8.4: TK31 (upgrade) — the upgrade manager's acts are C-facts; R-UPG reads them from the C-fact memory ---------- */
    function cmem() { return root.DMA_Tx || null; }
    /* 0.8.15: an upgrade is TK21 composing to a level above 1 — the case key is "<grid>@<level>" */
    function upOpen(grid) {                                  // the open composition above level 1 on a grid (any state), or null
        var M = cmem(); if (!M) return null;
        var l = M.list({ tk: "TK21", open: true }).filter(function (t) { return String(t.key).indexOf(String(grid) + "@") === 0; });
        return l.length ? l[0] : null;
    }
    function upInProgress(grid) { var t = upOpen(grid), M = cmem(); return t && M ? M.inProgress("TK21", t.key) : null; }
    function tk31Act(act, grid, extra) {
        var from = extra && extra.from != null ? Number(extra.from) : null, t0 = from == null ? upOpen(grid) : null;
        if (from == null && t0) from = Number(t0.data && (t0.data.from != null ? t0.data.from : t0.data.fromLevel)) || 0;
        var to = (Number(from) || 0) + 1;
        var o = { tk: "TK21", act: act, rule: "R-UPG", grid: Number(grid), key: String(grid) + "@" + to, to: to }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        if (o.actor === "upgrade manager") o.actor = "construction manager";
        record("c", o);
    }
    function tk31Revoke(grid, why, extra) {                 // 0.8.6: DEMO 4 — the initiator revokes its request; the game allows (tacit)
        var o = { actor: "construction manager", reason: why }, k; if (extra) for (k in extra) o[k] = extra[k];
        tk31Act("revoke request", grid, o);
        tk31Act("allow", grid, { actor: "game (tacit)" });
    }
    /* the open TK31 of a grid, reviewed against the game (execute / declare + accept / cancel / revoke); null when none */
    function tk31Review(grid, s) {
        var M = cmem(); if (!M) return null;
        var t = upInProgress(grid);                             // 0.8.7: a declined one is not in progress; 0.8.15 TK21 <grid>@<level>
        if (!t) return null;
        var from = Number(t.data.from != null ? t.data.from : t.data.fromLevel) || 0;
        var lv = s ? Number(s.level) || 0 : 0, nm = s ? String(s.name || "") : "", up = !!(s && s.upgrading);
        if (!s) { try { var L = live(grid); if (L) { lv = Number(L.level) || 0; nm = L.name; up = !!L.upgrading; s = L; } } catch (_) {} }
        if (!s) { tk31Revoke(grid, "the mine is gone"); return null; }
        if (lv < from || (t.data.name && nm && t.data.name !== nm)) { tk31Revoke(grid, "another building on the grid (rebuilt)", { level: lv }); return null; }
        if (t.state === "requested") return upInProgress(grid);
        if (lv > from && !up) {
            tk31Act("declare", grid, { actor: "game (observed)", level: lv, from: from });
            tk31Act("accept", grid, { actor: "construction manager", level: lv, from: from });
            return null;
        }
        if (up && t.state === "promised" && !(t.history || []).some(function (h) { return h.act === "execute"; })) tk31Act("execute", grid, { actor: "game (observed)", from: from });   // 0.8.12: once
        var rh = Number(param("R-UPG", "revokeHours")) || 0;
        if (rh > 0 && !up && t.state === "promised" && Date.now() - t.since > rh * 3600000) {
            var rel = ctrl() && typeof ctrl().releaseUpgradeOrder === "function" ? ctrl().releaseUpgradeOrder(grid) : { ok: false, reason: "no control" };   // 0.8.16
            if (rel && rel.ok) { tk31Revoke(grid, "the game did not start it within " + rh + " h; " + rel.reason); return null; }
        }
        return upInProgress(grid);
    }
    function cmgr() {   // 0.9.2: the construction manager (AR20), when it is there and ready: it then owns every AR20 request of the cycle
        try { var M = root.DMA_ConstructionManager; if (M && typeof M.check === "function" && M.check()) return M; } catch (_) {}
        return null;
    }
    function dsmgr() {   // 0.9.3: the deposit search manager (AR10), when it is there and ready
        try { var M = root.DMA_DepositSearchManager; if (M && typeof M.check === "function" && M.check()) return M; } catch (_) {}
        return null;
    }
    function applier() {   // 0.9.1: the buff applier, when it is there and ready
        try { var B = root.DMA_Buffer; if (B && B.owner === "buff applier" && (typeof B.check === "function" ? B.check() : B.ready === true)) return B; } catch (_) {}
        return null;
    }
    function refusedHeld(grid) {   // the game refused every buff for the grid, less than 10 min ago
        var B = applier(); if (B) return !!B.refused(grid);
        return !!(buffRefused[String(grid)] && Date.now() - buffRefused[String(grid)] < REFUSE_MS);
    }
    function buffOnItsWay(grid) {
        var B = applier(); if (B) return B.onItsWay(grid);   // 0.9.1: the applier sent it, the applier knows
        var at = buffSent[String(grid)];
        if (at && Date.now() - at < BUFF_SENT_MS) return true;
        if (at) { delete buffSent[String(grid)]; saveBuffSent(); }
        return false;
    }
    /* ---------- 0.8.8: TK41 (buff application) — C-facts of the buffer, reviewed against the game ---------- */
    var TK41_INITIATOR = { "R-BUFF-WHEN": "construction manager", "R-BUFF-PROD": "construction manager", "R-ZONE-LOVETREE": "construction manager", "R-EV-BUFF-WHEN": "construction manager", "R-EV-COUNTER": "construction manager" };   // 0.8.21: AR20 (backbone v3.16 D-3)
    function tk41Act(act, grid, extra) {
        var o = { tk: "TK41", act: act, grid: Number(grid) }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    function mapBuilding(grid) {
        try { var m = ctrl() && ctrl().map && ctrl().map(), bs = (m && m.buildings) || [], i; for (i = 0; i < bs.length; i++) if (String(bs[i].grid) === String(grid)) return bs[i]; } catch (_) {}
        return null;
    }
    function zoneBuffRunning(effect) {
        try { var zb = game.gi.mZoneBuffManager; return !!(effect && zb && zb.isBuffRunning && zb.isBuffRunning(effect)); } catch (_) { return false; }
    }
    function promisedAt(t) {
        var i; for (i = t.history.length - 1; i >= 0; i--) if (t.history[i].act === "promise" && !t.history[i].note) return Number(t.history[i].at) || t.since;   // 0.8.9: not a repeated one
        return t.since;
    }
    /* every TK41 in progress: declare + accept when the game shows the buff; revoke request + allow when it is lost */
    function tk41Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now();
        M.list({ tk: "TK41", open: true }).forEach(function (t0) {
            var t = M.inProgress("TK41", t0.key); if (!t || t.revoking) return;
            var d = t.data || {}, grid = t.key, init = d.initiator || "construction manager", shown = false, gone = false;
            if (d.zone || d.rule === "R-ZONE-LOVETREE") shown = zoneBuffRunning(d.buff);
            else {
                var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone), b = null;
                try { b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid)); } catch (_) { b = null; }
                if (!b) gone = true;
                else if (d.replace) { var mb = mapBuilding(grid), bn = mb ? String(mb.buffName || "") : ""; shown = t.state === "promised" && !!(bn && bn !== String(d.was || "")); }
                else shown = b.productionBuff != null;
            }
            function revoke(why) { tk41Act("revoke request", grid, { actor: init, reason: why }); tk41Act("allow", grid, { actor: "buff applier (tacit)" }); }
            if (gone) { revoke("the building is gone"); return; }
            if (shown && (t.state === "promised" || t.state === "requested")) {
                tk41Act("declare", grid, { actor: "buff applier (game observed)", buff: d.buff });
                tk41Act("accept", grid, { actor: init, buff: d.buff });
                return;
            }
            if (t.state === "promised" && now - promisedAt(t) >= BUFF_SENT_MS) { revoke("the game did not show the buff within " + Math.round(BUFF_SENT_MS / 60000) + " min"); return; }
            if (t.state === "requested" && now - t.since >= BUFF_SENT_MS) revoke("the buffer did not take it up within " + Math.round(BUFF_SENT_MS / 60000) + " min");
        });
    }

    /* ---------- 0.8.9: TK51 (mine demolition) — reviewed against the game; declare + accept, or revoke when lost ---------- */
    var TK51_LOST_MS = 10 * 60000;
    function tk51Act(act, grid, extra) {
        var o = { tk: "TK51", act: act, grid: Number(grid) }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    function tk51Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now();
        M.list({ tk: "TK51", open: true }).forEach(function (t0) {
            var t = M.inProgress("TK51", t0.key); if (!t || t.revoking) return;
            var d = t.data || {}, grid = t.key, init = d.initiator || "demolish manager", b = null, nm = "";
            try { var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone); b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid)); } catch (_) { b = null; }
            try { nm = b && b.GetBuildingName_string ? String(b.GetBuildingName_string()) : ""; } catch (_) { nm = ""; }
            var gone = !b || !/mine|mason|quarry/i.test(nm) || (d.name && nm !== String(d.name));
            if (gone) {
                tk51Act("declare", grid, { actor: "game (observed)", name: d.name, reason: b ? "another building on the grid" : "the mine is gone" });
                tk51Act("accept", grid, { actor: init, name: d.name });
                return;
            }
            var since = t.since, i;
            for (i = t.history.length - 1; i >= 0; i--) if (t.history[i].act === "promise" && !t.history[i].note) { since = Number(t.history[i].at) || since; break; }   // the promise that counts, not a repeated one
            if (now - since < TK51_LOST_MS) return;
            tk51Act("revoke request", grid, { actor: init, reason: t.state === "promised" ? "the game did not demolish it within 10 min" : "not answered within 10 min" });
            tk51Act("allow", grid, { actor: "game (tacit)" });
        });
    }

    /* ---------- 0.8.10: TK11 — one transaction per search ---------- */
    var searchSeq = 0;
    function tk11Act(act, search, extra) {
        var o = { tk: "TK11", act: act, search: search }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    var foundCheck = {};   // v3.41 (B16b): TK11 key -> the complete scan at which "no deposit more" was first seen
    function isl() { try { return root.DMA_Demo && root.DMA_Demo.island ? root.DMA_Demo.island() : null; } catch (_) { return null; } }
    function tk11Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now(), geos = geologists(), byId = {};
        geos.forEach(function (g) { if (g && g.id != null) byId[String(g.id)] = g; });
        M.list({ tk: "TK11", open: true }).forEach(function (t) {
            if (!M.inProgress("TK11", t.key) || t.revoking) return;
            var d = t.data || {}, g = d.geo != null ? byId[String(d.geo)] : null;
            var out = !!(g && !g.idle && (!g.taskResource || g.taskResource === d.resource));
            /* ARS-11-05 R-DEPOSIT-FOUND (backbone v3.41; reviews b16b r1/r2): the finder's declaration is accepted as soon as an accepted
               picture taken after it holds a NEW deposit of the resource - on a location that held none of it at the request, or a fresh
               one with more left than there was at the request (a mine demolished during the search to make room does not hide the find);
               it is rejected when two accepted pictures after it hold none - the game refused the finding ("too many deposits of this
               type") - and the rejection goes to the location manager for DFS-13. Without the game's places or the deposits at the
               request, the old way (accept) holds. */
            if (t.state === "declared") {
                var I = isl(), R0 = d.resource, was = null;
                try { was = d.depositMapAtRequest ? JSON.parse(d.depositMapAtRequest) : null; } catch (_) { was = null; }
                var judge = !!(I && I.fromGame && I.fromGame(R0) && I.completeScanAt && I.depositMap && was && typeof was === "object");
                if (!judge) { tk11Act("accept", t.key, { actor: "specialist manager (geo)", resource: R0 }); return; }
                var dAt = Number(d.declaredAt) || Number(t.at) || 0, sc = I.completeScanAt();
                if (!(sc > dAt)) return;   // wait for a complete picture after the return
                var nowMap = I.depositMap(R0), fresh = Object.keys(nowMap).filter(function (gr) { return !(gr in was) || Number(nowMap[gr]) > Number(was[gr]); });
                if (fresh.length) { delete foundCheck[t.key]; tk11Act("accept", t.key, { actor: "specialist manager (geo)", resource: R0, rule: "ARS-11-05 R-DEPOSIT-FOUND", grid: fresh[0] }); try { I.found(R0); } catch (_) {} return; }
                if (!foundCheck[t.key]) { foundCheck[t.key] = sc; return; }   // rejected only when the next accepted picture holds none either
                if (!(sc > foundCheck[t.key])) return;
                delete foundCheck[t.key];
                var n0 = Object.keys(nowMap).length;
                tk11Act("reject", t.key, { actor: "specialist manager (geo)", resource: R0, rule: "ARS-11-05 R-DEPOSIT-FOUND", deposits: n0, reason: "no new deposit of " + R0 + " in two accepted pictures: the game refused the finding (too many deposits of this type)" });
                try { I.refused(R0, n0, t.key); } catch (_) {}
                tk11Act("revoke request", t.key, { actor: "specialist manager (geo)", resource: R0, reason: "the finding was rejected (ARS-11-05)" });
                tk11Act("allow", t.key, { actor: "game (tacit)" });
                return;
            }
            if (t.state === "promised" && !out) {
                tk11Act("declare", t.key, { actor: "game (observed)", resource: d.resource, geo: d.geo, declaredAt: now, reason: g ? "the geologist is back" : "the geologist is no longer listed" });
                var I2 = isl();   // without the game's places or the deposits at the request: accepted at once, as before
                if (!(I2 && I2.fromGame && I2.fromGame(d.resource) && I2.completeScanAt && I2.depositMap && d.depositMapAtRequest))
                    tk11Act("accept", t.key, { actor: "specialist manager (geo)", resource: d.resource });
                return;   // else accepted or rejected by ARS-11-05 above, on a later tick
            }
            if (t.state === "requested" && now - t.since >= 10 * 60000) {
                if (out) tk11Act("promise", t.key, { actor: "game (observed)", resource: d.resource, geo: d.geo });
                else { tk11Act("revoke request", t.key, { actor: "specialist manager (geo)", resource: d.resource, reason: "no answer within 10 min" }); tk11Act("allow", t.key, { actor: "game (tacit)" }); }
            }
        });
    }

    /* ---------- the per-resource picture ---------- */
    function picture(slots) {
        var pic = {}, i, s, r;
        function p(r) {
            if (!pic[r]) pic[r] = { r: r, mines: [], free: [], due: [], open: 0, openSoon: [], capacity: 0, seed: 0, proven: false, spots: 0 };
            return pic[r];
        }
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!s || !s.resource) continue;
            if (isMineSlot(s)) p(s.resource).mines.push(s);
            else if (!s.depleted) p(s.resource).free.push(s);
        }
        var geos = geologists();
        for (i = 0; i < geos.length; i++) {
            if (!geos[i] || geos[i].idle || !geos[i].taskResource) continue;
            var x = p(geos[i].taskResource);
            x.open += 1;
            x.openSoon.push(Number(geos[i].remainingSec) || 0);
        }
        var isl = island();
        for (r in pic) {
            if (!pic.hasOwnProperty(r)) continue;
            var q = pic[r];
            q.seed = Number(pol("location.caps." + r, 0)) || 0;
            q.spots = isl.spots(r);
            q.proven = isl.proven(r);
            q.capacity = q.proven ? isl.capacity(r) : Math.max(isl.capacity(r), q.seed);
            q.occupied = QUARRY[r] ? q.free.length : q.mines.length + q.free.length;   /* masons do not stand on the spot */
            q.empty = Math.max(0, q.capacity - q.occupied);
            q.lead = leadSeconds(r) + param("R-DUE", "marginSeconds");
            if (!QUARRY[r]) {
                for (i = 0; i < q.mines.length; i++) {
                    var e = etaSeconds(q.mines[i]);
                    q.mines[i].eta = e;
                    if (e != null && e <= q.lead) q.due.push(q.mines[i]);
                }
            }
        }
        return pic;
    }

    function safeUpgrade(slot) {
        var C = root.DMA_Control;
        if (!C || typeof C.guardUpgrade !== "function") return "control without safeguard";   // fail closed
        try { return C.guardUpgrade(slot.grid) || ""; } catch (e) { return "safeguard error " + e; }
    }
    function record(kind, data) {
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {}
    }
    var ARS_TK = { search: "TK11", build: "TK21", upgrade: "TK21", buff: "TK41", demolish: "TK51" };   // 0.8.15: an upgrade is TK21
    var declineSeen = {}, DECLINE_REPEAT_MS = 3600000;   // 0.6.1: decline recorded on change, else hourly

    /* ---------- self-correcting pace ---------- */
    var pace = { ms: null, clean: 0, errors: 0 };
    function paceMs() {
        if (pace.ms == null) pace.ms = Number(pol("control.sendIntervalMs", 1500)) || 1500;
        return pace.ms;
    }
    function paceResult(ok, what) {
        var floor = Number(pol("control.sendIntervalMinMs", 700)) || 700;
        if (ok) {
            pace.clean += 1;
            if (pace.clean >= 20 && pace.ms > floor) { pace.ms = Math.max(floor, Math.round(pace.ms * 0.9)); pace.clean = 0; note("pace faster: " + pace.ms + " ms"); record("pace", { ms: pace.ms, why: "20 clean actions" }); }
        } else {
            pace.errors += 1;
            pace.clean = 0;
            pace.ms = Math.min(6000, paceMs() * 2);
            note("pace slower: " + pace.ms + " ms after " + what);
            record("pace", { ms: pace.ms, why: what });
        }
    }
    function trouble(out) {
        var e = out && (out.error || out.reason);
        return e && /zone|ready|connect|server|timeout|socket|lost/i.test(String(e)) ? String(e) : "";
    }

    function row(rule, ars, fact, s, r, reason, extra) {
        var o = { rule: rule, ars: ars, fact: fact, grid: s ? s.grid : "", resource: r, reason: reason, slot: s || null };
        if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        return o;
    }

    /* ---------- assess ---------- */
    function assess() {
        var slots = facts();
        var on = {
            geo: pol("geo.auto", false) === true, build: pol("build.auto", false) === true,
            upgrade: pol("upgrade.auto", false) === true, buff: pol("buff.auto", false) === true,
            demo: pol("demo.auto", false) === true
        };
        note("green " + VERSION + " assess slots=" + slots.length + " geo=" + on.geo + " build=" + on.build + " upgrade=" + on.upgrade + " buff=" + on.buff + " demo=" + on.demo);
        var i, j, s, r, q;
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!isMineSlot(s)) continue;
            var lv = live(s.grid);
            if (lv) { if (lv.level) s.level = lv.level; s.upgrading = lv.upgrading; s.buffed = lv.buffed; }
            s.busy = busy(s.grid);
        }
        var pic = picture(slots);
        var rows = [];

        var cmOn = cmgr();   // 0.9.2: when the construction manager is ready it makes every AR20 decision; green keeps the search rows (AR10) until step 4
        if (!cmOn) tk51Review();   // 0.8.9: before any new TK51 request of this cycle
        var dsmOn = dsmgr();   // 0.9.3
        if (!dsmOn) tk11Review();   // 0.8.10
        /* --- demolish (ARS-51-02) --- */
        var demolished = {};
        if (cmOn) { try { demolished = cmOn.demolished() || {}; } catch (_) { demolished = {}; } }
        if (on.demo && !cmOn) {
            var threshold = Number(pol("demolish.threshold", 20)) || 20;
            var landLead = param("R-DEMO-LAND", "leadSeconds");
            var cD = ctrl(), idleGeos = geologists().filter(function (g) { return g && g.idle && !(cD && cD.isReserved && cD.isReserved(g.id)); }).length;   // 0.7.2
            for (r in pic) {
                if (!pic.hasOwnProperty(r) || QUARRY[r]) continue;
                q = pic[r];
                var budget = { free: q.free.length, open: q.open };
                var byAmount = q.mines.filter(function (m) { return m.amount != null && !m.busy; })
                    .sort(function (a, b) { return Number(a.amount) - Number(b.amount); });
                for (j = 0; j < byAmount.length; j++) {
                    s = byAmount[j];
                    if (Number(s.amount) === 0) { rows.push(row("R-DEMO-EMPTY", "demolish", "pm", s, r, "deposit empty")); demolished[s.grid] = true; }
                }
                var returning = q.openSoon.filter(function (t) { return t > 0 && t <= landLead; }).length;
                var emptyNow = q.empty;
                for (j = 0; j < byAmount.length && returning > emptyNow; j++) {
                    s = byAmount[j];
                    if (demolished[s.grid]) continue;
                    if (!(Number(s.amount) <= threshold)) { rows.push(row("R-DEMO-LAND", "demolish", "dc", s, r, "lowest mine has " + s.amount + " left, above the threshold " + threshold + "; the find waits")); break; }   // 0.6.8
                    rows.push(row("R-DEMO-LAND", "demolish", "pm", s, r, "geologist returns within " + landLead + " s and R has no empty spot; lowest mine (" + s.amount + " left)"));
                    demolished[s.grid] = true;
                    emptyNow += 1;
                }
                for (j = 0; j < byAmount.length; j++) {
                    s = byAmount[j];
                    if (demolished[s.grid]) continue;
                    var a = Number(s.amount);
                    if (!(a > 0 && a <= threshold)) continue;
                    if (budget.free > 0) { budget.free -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", replacement: free deposit")); }
                    else if (budget.open > 0) { budget.open -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", replacement: geologist out")); }
                    else if (q.empty <= 0 && idleGeos > 0) { idleGeos -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", every spot occupied: makes room, a search follows")); }   // 0.7.2
                    else rows.push(row("R-DEMO-LOW", "demolish", "dc", s, r, "low " + a + ", no replacement left"));
                }
            }
        }

        if (!cmOn) tk41Review();   // 0.8.8: before any new TK41 request of this cycle
        /* --- upgrade and buff candidates --- */
        var upgradeCand = [], buffCand = [], seenTk31 = {};
        var requests = [];
        try { requests = JSON.parse(localStorage.getItem("dma.buffRequests.v1") || "[]") || []; } catch (_) {}
        var requestGrids = {};
        requests.forEach(function (rq) { if (rq && rq.grid != null) requestGrids[String(rq.grid)] = rq; });
        for (i = 0; i < slots.length && !cmOn; i++) {   // 0.9.2: the candidates are the construction manager's
            s = slots[i];
            if (!isMineSlot(s) || demolished[s.grid]) continue;
            var max = targetLevel(s.resource, s.name);
            var req = requestGrids[String(s.grid)];
            if (s.buffed && req) { delete requestGrids[String(s.grid)]; req = null; }
            var openT = tk31Review(s.grid, s);   // 0.8.2: declare/accept happen whether Upgrade is on or off
            if (openT) seenTk31[String(s.grid)] = true;
            if (on.upgrade && Number(s.level) < max) {
                if (openT) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "TK31 " + openT.state + " at level " + (openT.data.from != null ? openT.data.from : openT.data.fromLevel) + ": waiting for the declare"));
                else if (s.busy) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, s.busy + " order in progress"));
                else if (s.upgrading) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "upgrading"));
                else upgradeCand.push(s);
            }
            if (s.buffed && buffSent[String(s.grid)]) { delete buffSent[String(s.grid)]; saveBuffSent(); }   // 0.6.5: it arrived
            if ((on.buff || req) && !s.buffed) {
                if (buffOnItsWay(s.grid)) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "buff on its way (sent less than 10 min ago)"));
                else if (s.busy) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, s.busy + " order in progress"));
                else if (s.upgrading) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "upgrading"));
                else if (Number(s.level) < max && !req) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "level " + s.level + " < target " + max));
                else if (refusedHeld(s.grid)) rows.push(row("R-BUFF-CHOICE", "buff", "dc", s, s.resource, "game refused every buff; retry after 10 min"));
                else buffCand.push({ s: s, req: req });
            }
        }
        if (!cmOn) try { localStorage.setItem("dma.buffRequests.v1", JSON.stringify(Object.keys(requestGrids).map(function (k) { return requestGrids[k]; }))); } catch (_) {}
        buffCand.sort(function (a, b) { return (Number(b.s.level) || 0) - (Number(a.s.level) || 0); });
        var maxBuff = param("R-BUFF-WHEN", "maxPerCycle");
        for (i = 0; i < buffCand.length; i++) {
            s = buffCand[i].s;
            rows.push(row("R-BUFF-WHEN", "buff", i < maxBuff ? "pm" : "dc", s, s.resource,
                i < maxBuff ? ("at target level " + s.level + ", not buffed" + (buffCand[i].req ? " (player request)" : "")) : ("wait: max " + maxBuff + " per cycle"),
                { level: s.level, name: s.name, request: buffCand[i].req || null }));
        }

        /* --- build (ARS-20-11): only for free queue slots, by priority --- */
        var qn = null;
        try { qn = ctrl() && ctrl().queueNow && ctrl().queueNow(); } catch (_) {}
        var slotsFree = qn && qn.free != null ? Math.max(0, Number(qn.free)) : 0;
        if (qn && qn.slots != null && qn.used != null) slotsFree = Math.min(slotsFree, Math.max(0, Number(qn.slots) - Number(qn.used)));
        var qInfo = qn ? ("slots=" + qn.slots + " used=" + qn.used + " clientFree=" + qn.free + " free=" + slotsFree) : "queue unknown";
        var queued = (qn && qn.grids) || {};
        if (on.build && !cmOn) {
            var pauseMs = param("R-PRIO", "missingPauseSeconds") * 1000;
            var buildCand = [];
            for (r in pic) {
                if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0) continue;
                q = pic[r];
                for (j = 0; j < q.free.length; j++) {
                    s = q.free[j];
                    if (queued[String(s.grid)] || busy(s.grid)) { rows.push(row("R-SLOT", "build", "dc", s, r, "already ordered")); continue; }
                    if (missingAt[r] && Date.now() - missingAt[r].at < pauseMs) { rows.push(row("R-PRIO", "build", "dc", s, r, "materials missing: " + (missingAt[r].what || "?"))); continue; }
                    buildCand.push({ s: s, r: r, shortfall: Math.max(0, q.capacity - q.mines.length) / Math.max(1, q.capacity), amount: Number(s.amount) || 0 });
                }
            }
            buildCand.sort(function (a, b) { return (b.shortfall - a.shortfall) || (b.amount - a.amount); });
            var workChanged = false, freeGrids = {};   // 0.8.0
            for (r in pic) { if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0) continue; for (j = 0; j < pic[r].free.length; j++) freeGrids[String(pic[r].free[j].grid)] = true; }
            for (i = 0; i < buildCand.length; i++) {
                var bc = buildCand[i];
                if (slotsFree > 0) {
                    slotsFree -= 1;
                    rows.push(row("R-SLOT", "build", "pm", bc.s, bc.r, "queue slot free; priority " + (i + 1) + " (shortfall " + Math.round(bc.shortfall * 100) + "%, " + bc.amount + " units)", { amount: bc.amount }));
                    if (workWant(bc.s.grid, bc.r, "queue slot free; priority " + (i + 1))) workChanged = true;
                } else {
                    rows.push(row("R-SLOT", "build", "dc", bc.s, bc.r, "waiting for a build-queue slot (promise deferred)"));
                    if (workWant(bc.s.grid, bc.r, "waiting for a build-queue slot")) workChanged = true;
                }
            }
            for (r in pic) {   // 0.8.0: a candidate waiting for materials is still work
                if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0 || !(missingAt[r] && Date.now() - missingAt[r].at < pauseMs)) continue;
                for (j = 0; j < pic[r].free.length; j++) { s = pic[r].free[j]; if (!queued[String(s.grid)] && !busy(s.grid) && workWant(s.grid, r, "materials missing: " + (missingAt[r].what || "?"))) workChanged = true; }
            }
            if (workReview(freeGrids, queued)) workChanged = true;
            if (workChanged) saveWork();
        }

        /* --- 0.8.2: open TK31 on grids that were not among this cycle's mines (gone or not a mine slot) --- */
        if (cmem() && !cmOn) cmem().list({ tk: "TK21", open: true }).filter(function (t) { return t.state !== "declined" && String(t.key).indexOf("@") > 0; }).forEach(function (t) { var g = String(t.key).split("@")[0]; if (!seenTk31[g]) { var sx = null; for (var q = 0; q < slots.length; q++) if (String(slots[q].grid) === g && isMineSlot(slots[q])) sx = slots[q]; if (!sx) tk31Review(g, null); } });

        /* --- upgrades take the slots that are left --- */
        var useQueue = param("R-SLOT", "upgradesUseQueue");
        upgradeCand.sort(function (a, b) { return (Number(a.level) || 0) - (Number(b.level) || 0); });
        for (i = 0; i < upgradeCand.length; i++) {
            s = upgradeCand[i];
            // 0.6.2 SAFEGUARD (incident 2026-10-24): only a kind control has verified, below its maximum level
            var whyK = safeUpgrade(s);
            if (whyK) { rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "safeguard: " + whyK)); continue; }
            if (!useQueue || slotsFree > 0) {
                if (useQueue) slotsFree -= 1;
                rows.push(row("R-UPG", "upgrade", "pm", s, s.resource, "level " + s.level + " < " + targetLevel(s.resource, s.name), { level: s.level }));
            } else {
                rows.push(row("R-SLOT", "upgrade", "dc", s, s.resource, "waiting for a build-queue slot"));
            }
        }

        /* --- search (ARS-10-11): gap with replacement timing --- */
        if (on.geo) {
            var operational = null;
            try { if (root.DMA_Demo && root.DMA_Demo.operational) operational = root.DMA_Demo.operational(); } catch (_) {}
            var wants = [];
            for (r in pic) {
                if (!pic.hasOwnProperty(r)) continue;
                if (operational && pol("search.inPlayOnly", true) !== false && operational.indexOf(r) < 0) continue;
                q = pic[r];
                if (q.capacity <= 0) { rows.push(row("R-CAP", "search", "dc", null, r, "capacity 0")); continue; }
                if (dsmOn) continue;   // 0.9.3: R-GAP, R-DUE and R-LF are the deposit search manager's
                var held = searchHeld(r);                                                          // 0.6.7
                if (held) { rows.push(row("R-GAP", "search", "dc", null, r, "the game refused " + held.n + " search(es); retry after " + new Date(held.at + searchBackoffMs(held.n)).toISOString().slice(11, 16) + " UTC")); continue; }
                var cleared = q.mines.filter(function (m) { return demolished[m.grid]; }).length;   // 0.7.3: demolished this cycle = free
                var dueUncovered = Math.max(0, q.due.filter(function (m) { return !demolished[m.grid]; }).length - q.free.length);
                if (q.empty + cleared <= 0 && dueUncovered > 0) {                                  // 0.7.0 / 0.7.2
                    rows.push(row("R-DUE", "search", "dc", null, r, "every spot occupied: the game refuses a search until a mine is demolished (at the threshold " + (Number(pol("demolish.threshold", 20)) || 20) + ")"));
                    dueUncovered = 0;
                }
                var need = q.empty + cleared + dueUncovered - q.open;
                var why = "capacity " + q.capacity + (q.proven ? " (proven)" : " (" + q.spots + " spots seen, seed " + q.seed + ")") +
                          ", occupied " + q.occupied + ", empty " + q.empty + ", due " + q.due.length + " (lead " + Math.round(q.lead / 60) + " min)" +
                          ", free " + q.free.length + ", open " + q.open + (cleared ? ", demolished now " + cleared : "");
                if (need <= 0) {
                    // 0.6.4: iron / marble at the proven limit — one Lucky Find geologist at a time for the extra deposit
                    var lfw = false; try { var islG = island(); lfw = !!(islG && islG.lfWanted && islG.lfWanted(r)); } catch (_) {}
                    if (lfw && q.open === 0) { wants.push({ r: r, need: 1, why: "limit " + q.capacity + " reached; Lucky Find geologist for the one extra deposit", replacement: false, lf: true }); continue; }
                    rows.push(row("R-GAP", "search", "dc", null, r, "covered: " + why + (lfw ? "; Lucky Find search open" : ""))); continue;
                }
                wants.push({ r: r, need: need, why: why, replacement: dueUncovered > 0 });
            }
            wants.sort(function (a, b) { return b.need - a.need; });
            var c = ctrl();
            var idle = geologists().filter(function (g) { return g && g.idle && !(c && c.isReserved && c.isReserved(g.id)); }).length;
            var seq = 1;
            for (i = 0; i < wants.length; i++) {
                if (idle <= 0) { rows.push(row("R-GAP", "search", "dc", null, wants[i].r, "no idle geologist; need " + wants[i].need + ": " + wants[i].why)); continue; }
                var n = Math.min(wants[i].need, idle);
                for (j = 0; j < n; j++) {
                    rows.push(row(wants[i].lf ? "R-LF" : wants[i].replacement ? "R-DUE" : "R-GAP", "search", "pm", null, wants[i].r, "send " + (j + 1) + "/" + n + ": " + wants[i].why, { grid: "s" + seq, replacement: true, lf: !!wants[i].lf }));
                    seq += 1;
                }
                idle -= n;
            }
        }

        /* --- 0.7.8: counters (R-EV-COUNTER): a trick on a building is answered with a Treat --- */
        var ctrs = [];
        try { ctrs = (root.DMA_Event && root.DMA_Event.counters && !cmOn) ? root.DMA_Event.counters() : []; } catch (_) { ctrs = []; }
        if (ctrs.length) {
            var cMax = param("R-EV-COUNTER", "maxPerCycle"), cN = 0, cm = null;
            try { cm = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            ((cm && cm.buildings) || []).forEach(function (b) {
                var bn = String(b.buffName || "").toLowerCase();
                if (!bn) return;
                ctrs.forEach(function (c) {
                    if (bn.indexOf(String(c.when).toLowerCase()) < 0) return;
                    if (eventRunningPic(c.event) !== true) return;   // 0.8.21: only while the picture shows the event
                    var es = { grid: b.grid, name: b.name, resource: b.name };
                    if (buffOnItsWay(b.grid)) { rows.push(row("R-EV-COUNTER", "buff", "dc", es, b.name, c.when + " on it; " + c.give + " on its way")); return; }
                    if (cN >= cMax) { rows.push(row("R-EV-COUNTER", "buff", "dc", es, b.name, "wait: max " + cMax + " per cycle")); return; }
                    cN += 1;
                    rows.push(row("R-EV-COUNTER", "buff", "pm", es, b.name, c.when + " on it (" + b.buffName + "): order " + c.give,
                        { order: { grid: b.grid, buff: c.give, by: "construction manager", why: c.label } }));
                });
            });
        }

        /* --- 0.7.7: the event manager's orders to the buffer (R-EV-BUFF-WHEN / R-EV-BUFF-CHOICE, ADR 0029) --- */
        var evMax = param("R-EV-BUFF-WHEN", "maxPerCycle"), evN = 0, evGroups = null;
        (cmOn ? [] : eventBuildings()).forEach(function (b) {
            if (pol("event." + b.event + ".buff.on", false) !== true) return;
            var evr = eventRunningPic(b.event);   // 0.8.21: the running event from the picture (ARS-20-11 given)
            if (evr !== true) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", { grid: b.grid, name: b.name, resource: b.label }, b.label, evr === undefined ? "no events picture (location manager)" : "the event is not running")); return; }
            var es = { grid: b.grid, name: b.name, resource: b.label };
            if (b.buffed) return;
            if (buffOnItsWay(b.grid)) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "buff on its way (sent less than 10 min ago)")); return; }
            if (busy(b.grid)) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "order in progress")); return; }
            if (evN >= evMax) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "wait: max " + evMax + " per cycle")); return; }
            if (!evGroups) evGroups = allBuffGroups();
            var best = eventOptions(b.grid, b.name, evGroups)[0];
            if (!best) { rows.push(row("R-EV-BUFF-CHOICE", "buff", "dc", es, b.label, "no buff in stock for this building")); return; }
            best.g.used += 1; evN += 1;
            rows.push(row("R-EV-BUFF-WHEN", "buff", "pm", es, b.label, "order to the buffer: " + best.loc + " (+" + best.extra + " " + (b.unit || "") + " in " + best.hours + " h)",
                { order: { grid: b.grid, buff: best.def, by: "construction manager", why: "+" + best.extra + " " + (b.unit || "") } }));
        });

        /* --- 0.8.18: R-BUFF-PROD (buff manager): every production building at its determined level --- */
        if (on.buff && !cmOn && param("R-BUFF-PROD", "on") !== false) {
            var pm0 = null; try { pm0 = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            var slotGrids = {}; slots.forEach(function (x) { if (x && x.grid != null) slotGrids[String(x.grid)] = true; });
            var pMax = param("R-BUFF-PROD", "maxPerCycle"), pN = 0, pGroups = null;
            ((pm0 && pm0.buildings) || []).forEach(function (b) {
                var trains = b && MILITARY_RX.test(String(b.name || "")) ? trainsForTroops(b) : null;   // 0.8.23: DFS-51 (null: not a barracks)
                if (!b || (!b.prod && trains === null) || slotGrids[String(b.grid)] || eventDecl(b.name)) return;
                if (b.buffed) { if (buffSent[String(b.grid)]) { delete buffSent[String(b.grid)]; saveBuffSent(); } return; }
                var ps = { grid: b.grid, name: b.name, resource: b.name, level: b.level };
                var pref = prefFor(b.name);
                if (pref === "none") return;
                if (trains === false) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "not training for the troops (DFS-51)")); return; }   // 0.8.23
                if (trains !== true && !b.producing) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "not producing (stopped or waiting for input)")); return; }
                if (b.upgradeInProgress) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "upgrading")); return; }
                var tl = Number(pol("ctype." + b.name + ".targetLevel", null)) || Number(pol("building.upgradeLevel." + b.name, 0)) || 0;   // 0.8.21: construction type policy (AT70) first
                if (tl && Number(b.level) < tl) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "level " + b.level + " < determined level " + tl)); return; }
                if (buffOnItsWay(b.grid)) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "buff on its way (sent less than 10 min ago)")); return; }
                if (busy(b.grid)) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "order in progress")); return; }
                if (refusedHeld(b.grid)) { rows.push(row("R-BUFF-PROD-CHOICE", "buff", "dc", ps, b.name, "game refused; retry after 10 min")); return; }
                if (pN >= pMax) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "wait: max " + pMax + " per cycle")); return; }
                if (!pGroups) pGroups = buffGroups();
                var pick = prodChoice(b.grid, b.name, pGroups, pref);
                if (!pick) { rows.push(row("R-BUFF-PROD-CHOICE", "buff", "dc", ps, b.name, "no accepted buff in stock for this type")); return; }
                pick.g.used += 1; pN += 1;
                rows.push(row("R-BUFF-PROD", "buff", "pm", ps, b.name, "producing at level " + b.level + ", not buffed: " + pick.g.loc + " (" + pick.how + ")",
                    { order: { grid: b.grid, buff: pick.g.def, by: "construction manager", why: "R-BUFF-PROD " + pick.how } }));
            });
        }

        /* --- 0.8.1: R-ZONE-LOVETREE (buff manager) --- */
        if (on.buff && !cmOn && param("R-ZONE-LOVETREE", "on") !== false) {
            var lt = loveTreePlan();
            if (lt.ok) rows.push(row("R-ZONE-LOVETREE", "buff", "pm", { grid: lt.grid, name: "LoveTree" }, "Love Tree", "ready: " + lt.recipeName + " (level " + lt.level + ")",
                { order: { kind: "zone", grid: lt.grid, level: lt.level, by: "construction manager", why: "R-ZONE-LOVETREE" } }));
            else if (lt.grid != null) rows.push(row("R-ZONE-LOVETREE", "buff", "dc", { grid: lt.grid, name: "LoveTree" }, "Love Tree", lt.reason));
        }
        rows.sort(function (a, b) { return (RANK[a.ars] != null ? RANK[a.ars] : 9) - (RANK[b.ars] != null ? RANK[b.ars] : 9); });   // 0.7.3: demolish (rank 0) was sorted last ("0 || 9")
        last = rows;
        rows.forEach(function (x) {
            var tk = ARS_TK[x.ars] || x.ars;
            if (x.fact === "pm") {
                if (x.ars === "demolish") { var ds = x.slot || {}; tk51Act("request", x.grid, { initiator: "demolish manager", actor: "demolish manager", rule: x.rule, resource: x.resource, name: ds.name || null, amount: ds.amount != null ? Number(ds.amount) : null, reason: x.reason }); return; }   // 0.8.9
                if (x.ars === "buff") { tk41Act("request", x.grid, { initiator: TK41_INITIATOR[x.rule] || "construction manager", actor: TK41_INITIATOR[x.rule] || "construction manager", rule: x.rule, resource: x.resource, reason: x.reason, buff: x.order && x.order.buff, zone: x.order && x.order.kind === "zone" ? true : null, replace: x.order && x.order.replace ? true : null }); return; }   // 0.8.8
                if (x.ars !== "upgrade" && x.ars !== "search") record("c", { tk: tk, act: "request", rule: x.rule, resource: x.resource, grid: x.grid, reason: x.reason });   // 0.8.10: a search records its request with the send
                return;
            }   // 0.8.3: TK31 acts come from the book
            // 0.6.1: a decline is recorded when it first appears, when its reason changes, and at least hourly
            // while it holds; `repeats` says how many cycles the same decline held since the last record.
            var key = tk + "|" + x.rule + "|" + x.resource + "|" + (x.grid == null ? "" : x.grid);
            var seen = declineSeen[key], now = Date.now();
            if (!seen || seen.reason !== x.reason || now - seen.at >= DECLINE_REPEAT_MS) {
                record("c", { tk: tk, act: "assess", outcome: "not now", rule: x.rule, resource: x.resource, grid: x.grid, reason: x.reason, repeats: seen ? seen.n : 0,
                              key: x.ars === "upgrade" && x.grid != null ? String(x.grid) + "@" + ((Number(x.slot && x.slot.level) || 0) + 1) : undefined });   // 0.8.15: an upgrade's assessment belongs to the composition to the next level   // 0.8.5: the initiator's own assessment, not an executor's decline
                declineSeen[key] = { reason: x.reason, at: now, n: 0 };
            } else {
                seen.n += 1;
            }
        });
        var pm = rows.filter(function (x) { return x.fact === "pm"; }).length;
        note("green assess pm=" + pm + " dc=" + (rows.length - pm) + " queue " + qInfo);
        rows.forEach(function (x) { if (x.fact === "pm" || x.ars === "search") note("green [" + x.rule + "] " + x.ars + " " + x.resource + " @" + x.grid + " " + x.fact + " " + x.reason); });
        var dcs = {};
        rows.forEach(function (x) {
            if (x.fact === "pm" || x.ars === "search") return;
            var key = x.rule + "|" + x.ars + "|" + x.resource + "|" + x.reason;
            if (!dcs[key]) dcs[key] = { x: x, grids: [] };
            dcs[key].grids.push(x.grid);
        });
        Object.keys(dcs).forEach(function (k) {
            var d = dcs[k];
            note("green [" + d.x.rule + "] " + d.x.ars + " " + d.x.resource + " dc " + d.x.reason + " @" + d.grids.slice(0, 6).join(",") + (d.grids.length > 6 ? " +" + (d.grids.length - 6) : ""));
        });
        return rows;
    }

    /* ---------- buff choice (R-BUFF-CHOICE) ---------- */
    function buffGroups() {
        var groups = {}, out = [];
        try {
            (game.gi.mCurrentPlayer.getBuffsSortedForStarMenu() || []).forEach(function (buff) {
                try {
                    if (!buff || buff.IsExhausted || (buff.GetWaitingForServer && buff.GetWaitingForServer())) return;
                    var def = buff.GetBuffDefinition && buff.GetBuffDefinition();
                    if (!def) return;
                    if (def.GetBuffType() !== 0 || def.GetTargetType() !== 0) return;
                    var nm = def.GetName_string && def.GetName_string();
                    if (!nm || nm.indexOf("Area") >= 0) return;
                    var loc = nm;
                    try { loc = loca.GetText("RES", nm) || nm; } catch (_) {}
                    if (!groups[nm]) {
                        var pct = 0, dur = 0;
                        try { pct = def.getProductivityOutputPercent ? def.getProductivityOutputPercent() || 0 : 0; } catch (_) {}
                        try { dur = def.getDuration ? def.getDuration(0) || 0 : 0; } catch (_) {}
                        groups[nm] = { def: nm, loc: loc, percent: pct, duration: dur, score: Math.max(pct, 1) * Math.max(dur, 1), stacks: [], available: 0, used: 0 };
                    }
                    groups[nm].stacks.push(buff);
                    groups[nm].available += (buff.GetAmount && buff.GetAmount()) || 1;
                } catch (_) {}
            });
        } catch (_) {}
        for (var k in groups) if (groups.hasOwnProperty(k)) out.push(groups[k]);
        out.sort(function (a, b) { return b.score - a.score; });
        return out;
    }
    function buffPrefs() {
        var p = pol("buff.prefs", null);
        if (p && typeof p === "object") return p;
        try { if (root.DMA_Demo && root.DMA_Demo.getBuffPrefs) return root.DMA_Demo.getBuffPrefs() || {}; } catch (_) {}
        return {};
    }
    function applicable(group, grid) {
        try {
            var st = group.stacks[0];
            if (!st || !st.IsApplyable) return true;
            var res = st.IsApplyable(game.gi.mCurrentPlayer, game.gi, Number(grid));
            return res !== null && typeof res === "object";
        } catch (_) { return false; }
    }
    /* ---------- 0.8.23 (v3.17 T-5): DFS-51 [construction] trains for the troops ---------- */
    var MILITARY_RX = /^(Barracks|EliteBarracks)$/;
    function trainsForTroops(b) {
        var pic = null;
        try { pic = root.DMA_Demo && typeof root.DMA_Demo.troops === "function" ? root.DMA_Demo.troops() : null; } catch (_) { pic = null; }
        if (!pic || !pic.queues) return false;   // no picture: fail closed, no buff
        var q = pic.queues[String(b.name)];
        if (!q || (q.grid != null && b.grid != null && Number(q.grid) !== Number(b.grid))) return false;
        if (q.started && Number(q.started.amount) > 0) return true;
        return (q.runs || []).some(function (r) { return Number(r[1]) > 0 && Number(r[2] || 1) > 0; });
    }
    /* ---------- 0.8.18: R-BUFF-PROD-CHOICE ---------- */
    function normName(x) { return String(x || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }
    function prefFor(bldName) {
        var p = buffPrefs()[bldName];
        if (p && typeof p === "object") p = p.buff;
        return p ? String(p) : null;
    }
    function mineReserved() {
        var out = {}, k, pp = null;
        try { pp = root.GCAF_PlayerPolicyInstance && root.GCAF_PlayerPolicyInstance.getPolicy && root.GCAF_PlayerPolicyInstance.getPolicy(); } catch (_) {}
        ORES.forEach(function (r) { var v = pol("buff.name." + r, null); if (v) out[normName(v)] = true; });
        var dv = pol("buff.defaultName", null); if (dv) out[normName(dv)] = true;
        if (pp) for (k in pp) if (pp.hasOwnProperty(k) && k.indexOf("buff.name.") === 0 && pp[k]) out[normName(pp[k])] = true;
        return out;
    }
    function prodChoice(grid, bldName, groups, pref) {
        var i, g;
        if (pref) {
            for (i = 0; i < groups.length; i++) {
                g = groups[i];
                if ((g.def === pref || g.loc === pref) && g.available - g.used > 0 && (eligible(g, bldName) !== false) && applicable(g, grid)) return { g: g, how: "player choice" };
            }
        }
        var reserved = mineReserved(), minStock = param("R-BUFF-PROD", "minStock"), cand = [];
        for (i = 0; i < groups.length; i++) {
            g = groups[i];
            if (g.available - g.used <= minStock) continue;
            if (reserved[normName(g.def)] || reserved[normName(g.loc)]) continue;
            if (param("R-BUFF-CHOICE", "rainbowOnlyEndless") && (g.def === "ProductivityBuffLvl12" || /rainbow/i.test(g.loc)) && !/Endless/i.test(bldName || "")) continue;   // 0.8.19
            var el = eligible(g, bldName);
            if (el === false) continue;
            if (el === null && !applicable(g, grid)) continue;
            var tg = groupOf(g), named = new RegExp("(^|,)" + String(bldName).replace(/[^A-Za-z0-9_]/g, "") + "(,|$)").test(String(tg.text || "") + "," + String(tg.group || ""));
            cand.push({ g: g, named: named, time: (g.available - g.used) * (Number(durationSeconds(g.duration)) || 1) });
        }
        cand.sort(function (a, b) { return (b.named ? 1 : 0) - (a.named ? 1 : 0) || b.time - a.time; });
        if (!cand.length) return null;
        return { g: cand[0].g, how: (pref ? "choice " + pref + " not available; " : "") + (cand[0].named ? "auto, names " + bldName : "auto, most buff-time in stock") };
    }
    function chooseBuff(job, groups, bldName) {
        var pref = buffPrefs()[bldName];
        if (pref && typeof pref === "object") pref = pref.buff;
        if (job.request && job.request.buff) pref = job.request.buff;
        var i, g;
        if (pref) {
            for (i = 0; i < groups.length; i++) {
                g = groups[i];
                if ((g.def === pref || g.loc === pref) && g.available - g.used > 0 && applicable(g, job.grid)) return { g: g, how: "player choice" };
            }
        }
        var endless = /Endless/i.test(bldName || "");
        var rainbowOnly = param("R-BUFF-CHOICE", "rainbowOnlyEndless");
        for (i = 0; i < groups.length; i++) {
            g = groups[i];
            if (g.available - g.used <= 0) continue;
            if (rainbowOnly && (g.def === "ProductivityBuffLvl12" || /rainbow/i.test(g.loc)) && !endless) continue;
            if (applicable(g, job.grid)) return { g: g, how: pref ? "auto, choice " + pref + " not available" : "auto, strongest accepted" };
        }
        return null;
    }

    /* ---------- 0.7.4: event buildings (decision 0026) ---------- */
    function eventDecl(name) {   // 0.7.5: the event's declaration for a building name as the game reports it
        try { return (root.DMA_Event && root.DMA_Event.match && root.DMA_Event.match(name)) || null; } catch (_) { return null; }
    }
    function durationSeconds(d) {
        d = Number(d) || 0;
        return d > 100000 ? d / 1000 : d;      // the client reports some durations in ms, some in s; 6 h = 21,600 s
    }
    /* every buff in the star menu, without the mine filters of buffGroups: "neem alle mogelijke buffs mee" */
    function allBuffGroups() {
        var groups = {}, out = [];
        try {
            (game.gi.mCurrentPlayer.getBuffsSortedForStarMenu() || []).forEach(function (buff) {
                try {
                    if (!buff || buff.IsExhausted || (buff.GetWaitingForServer && buff.GetWaitingForServer())) return;
                    var def = buff.GetBuffDefinition && buff.GetBuffDefinition();
                    if (!def) return;
                    var nm = def.GetName_string && def.GetName_string();
                    if (!nm) return;
                    if (!groups[nm]) {
                        var loc = nm, pct = 0, dur = 0;
                        try { loc = loca.GetText("RES", nm) || nm; } catch (_) {}
                        try { pct = def.getProductivityOutputPercent ? def.getProductivityOutputPercent() || 0 : 0; } catch (_) {}
                        try { dur = def.getDuration ? def.getDuration(0) || 0 : 0; } catch (_) {}
                        groups[nm] = { def: nm, loc: loc, percent: Number(pct) || 0, duration: durationSeconds(dur), stacks: [], available: 0, used: 0 };
                    }
                    groups[nm].stacks.push(buff);
                    groups[nm].available += (buff.GetAmount && buff.GetAmount()) || 1;
                } catch (_) {}
            });
        } catch (_) {}
        for (var k in groups) if (groups.hasOwnProperty(k)) out.push(groups[k]);
        return out;
    }
    /* 0.7.6: eligibility by the buff's target group (BuffSystem:BuffTargetGroups.groupContains), not by the building's state.
       Returns true / false, or null when the groups cannot be read (then the game's IsApplyable decides). */
    var targetGroupsApi;
    function targetGroups() {
        if (targetGroupsApi !== undefined) return targetGroupsApi;
        targetGroupsApi = null;
        try {
            var sw = (typeof swmmo !== "undefined") ? swmmo : root.swmmo;
            var cls = sw && sw.getDefinitionByName && sw.getDefinitionByName("BuffSystem::BuffTargetGroups");
            if (cls && typeof cls.groupContains === "function") targetGroupsApi = cls;
            else if (cls && typeof cls.getInstance === "function" && cls.getInstance() && typeof cls.getInstance().groupContains === "function") targetGroupsApi = cls.getInstance();
            else if (cls && cls.instance && typeof cls.instance.groupContains === "function") targetGroupsApi = cls.instance;
        } catch (_) { targetGroupsApi = null; }
        return targetGroupsApi;
    }
    function groupOf(g) {
        try { var def = g.stacks[0].GetBuffDefinition(); return { group: def.GetTargetGroup_string ? String(def.GetTargetGroup_string() || "") : "", text: def.GetTargetDescription_string ? String(def.GetTargetDescription_string() || "") : "" }; }
        catch (_) { return { group: "", text: "" }; }
    }
    function eligible(g, buildingName) {
        var api = targetGroups(), tg = groupOf(g).group;
        if (!api || !tg) return null;
        try { return !!api.groupContains(tg, String(buildingName)); } catch (_) { return null; }
    }
    function excludedBuffs(type) {   // 0.7.7: the event type's rule
        var x = pol("event." + type + ".buff.exclude", null);
        if (Array.isArray(x)) return x.map(String);
        if (x && typeof x === "object") return Object.keys(x).filter(function (k) { return !!x[k]; });
        return [];
    }
    /* R-EV-BUFF-CHOICE: the options for one building, best first */
    function eventOptions(grid, name, groups) {
        var decl = eventDecl(name);
        if (!decl) return [];
        var ex = excludedBuffs(decl.event), out = [];
        (groups || allBuffGroups()).forEach(function (g) {
            if (g.available - g.used <= 0) return;
            if (ex.indexOf(g.def) >= 0 || ex.indexOf(g.loc) >= 0) return;
            if (!(g.percent > 0) || !(g.duration > 0)) return;
            var el = eligible(g, name);                          // 0.7.6: by the buff type's target group
            if (el === false) return;
            if (el === null && !applicable(g, grid)) return;     // fallback: the game's check (refuses a buffed building)
            var extra = (g.percent / 100) * g.duration / decl.secondsPerUnit;
            var tgt = groupOf(g);
            out.push({ g: g, def: g.def, loc: g.loc, percent: g.percent, hours: Math.round(g.duration / 360) / 10, available: g.available - g.used, extra: Math.round(extra * 10) / 10, target: tgt.text || tgt.group, by: el === null ? "game check" : "target group" });
        });
        out.sort(function (a, b) { return b.extra - a.extra; });
        return out;
    }
    /* 0.8.21 (v3.16 D-3; DFS-48): is an event of <type> running — from the location manager's events picture */
    function eventRunningPic(type) {
        var D = root.DMA_Demo;
        try { if (!D || typeof D.eventRunning !== "function" || typeof D.events !== "function" || !D.events()) return undefined; } catch (_) { return undefined; }
        var pre = pol("event." + type + ".gameNames", null);
        if (pre == null || pre === "") { try { (root.DMA_Event.status().types || []).forEach(function (t) { if (t.type === type) pre = t.gameNames; }); } catch (_) {} }
        if (pre == null || pre === "") pre = type;
        try { return !!D.eventRunning(String(pre)); } catch (_) { return undefined; }
    }
    function eventBuildings() {
        var m = null, out = [];
        try { m = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
        ((m && m.buildings) || []).forEach(function (b) {
            var d = eventDecl(b.name);
            if (d) out.push({ grid: b.grid, name: b.name, label: d.label, unit: d.unit, secondsPerUnit: d.secondsPerUnit, event: d.event, buffed: !!b.buffed });
        });
        out.sort(function (a, b) { return a.secondsPerUnit - b.secondsPerUnit; });
        return out;
    }
    function eventPlan() {
        var groups = allBuffGroups();
        return eventBuildings().map(function (b) {
            var opts = eventOptions(b.grid, b.name, groups);
            return { grid: b.grid, name: b.name, label: b.label, unit: b.unit, event: b.event, buffed: b.buffed,
                     options: opts.map(function (o) { return { buff: o.loc, def: o.def, percent: o.percent, hours: o.hours, available: o.available, extra: o.extra, target: o.target, by: o.by }; }) };
        });
    }

    /* ---------- 0.7.7: the BUFFER — carries out an order { grid, buff }; knows nothing of who asked or why ---------- */
    /* 0.8.1: R-ZONE-LOVETREE — read only: what the buff manager would start now */
    var loveTreeSentAt = 0;
    function lvec(v) { var out = [], i; if (!v) return out; try { for (i = 0; i < v.length; i++) out.push(v[i]); } catch (_) {} return out; }
    function ldef(n) { return root.swmmo.getDefinitionByName(n); }
    function loveTreePlan() {
        var gi = game && game.gi; if (!gi) return { ok: false, reason: "game not ready" };
        var trees = [];
        try { lvec(gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector()).forEach(function (b) { try { if (b && String(b.GetBuildingName_string()) === "LoveTree") trees.push(b); } catch (_) {} }); } catch (_) {}
        if (!trees.length) return { ok: false, reason: "no Love Tree on the island" };
        trees.sort(function (a, b) { return Number(b.GetUpgradeLevel()) - Number(a.GetUpgradeLevel()); });
        var tree = trees[0], lvl = Number(tree.GetUpgradeLevel()), grid = tree.GetGrid();
        function no(r) { return { ok: false, reason: r, grid: grid, level: lvl }; }
        if (gi.isOnHomzone && !gi.isOnHomzone()) return no("not home");
        var cd = 0; try { cd = Number(tree.getRemainingCooldown()) || 0; } catch (_) {}
        if (cd > 0) return no("cooldown: " + Math.ceil(cd / 60000) + " min left");
        var ltAt = loveTreeSentAt; try { var Bl = root.DMA_Buffer; if (Bl && Bl.owner === "buff applier" && typeof Bl.loveTreeSentAt === "function") ltAt = Math.max(ltAt, Bl.loveTreeSentAt()); } catch (_) {}
        if (Date.now() - ltAt < 180000) return no("started less than 3 min ago");
        var type = tree.productionQueue.mProductionType, recipe = null;
        function rank(r) { var m = /Lvl(\d+)\s*$/i.exec(String(r.GetType ? r.GetType() : "")); return Number(r.requiresUpgradeLevelMin) * 100 + (m ? Number(m[1]) : 0); }
        lvec(ldef("global").timedProductions_vector[type]).forEach(function (r) {
            if (r && Number(r.requiresUpgradeLevelMin) <= lvl && lvl <= Number(r.requiresUpgradeLevelMax) && (!recipe || rank(r) > rank(recipe))) recipe = r;
        });
        if (!recipe) return no("no recipe for a level-" + lvl + " Love Tree");
        var effect = ""; try { effect = String(recipe.effects_vector[0].name_string); } catch (_) {}
        var zb = gi.mZoneBuffManager;
        try { if (effect && zb.isBuffRunning(effect)) return no(effect + " is running"); } catch (_) {}
        try { var bd = ldef("BuffSystem::cBuffDefinition").GetByName(effect), others = bd ? lvec(zb.getBuffInExclusivityGroup_vector(bd.GetExclusivityGroup())) : [];
              if (others.length) return no("another zone buff of the same group runs (R-ZONE-REPLACE)"); } catch (_) {}
        var res = gi.mCurrentPlayerZone.GetResources(gi.mCurrentPlayer), short = [];
        lvec(recipe.GetCosts_vector()).forEach(function (c) { try { if (!res.HasPlayerResource(c.name_string, c.amount)) short.push(c.amount + " " + c.name_string); } catch (_) {} });
        if (short.length) return no("not in stock: " + short.join(", "));
        return { ok: true, grid: grid, level: lvl, type: type, recipe: recipe, recipeName: String(recipe.GetType()), effect: effect, tree: tree };
    }
    /* 0.8.25 (ADR 0073): green never sends; the adapter owns the send and answers { ok } or { ok: false, reason } */
    function viaAdapter(fn) {
        var A = root.GCAF_GameInterface;
        if (!A) return { ok: false, reason: "game interface adapter not loaded" };
        try { return fn(A) || { ok: false, reason: "no answer from the adapter" }; } catch (e) { return { ok: false, reason: "send failed: " + e }; }
    }
    function startLoveTree(order) {
        var lt = loveTreePlan();
        if (!lt.ok) { note("buffer Love Tree dc " + lt.reason); tk41Act("decline", order.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", reason: lt.reason }); return { fact: "dc", reason: lt.reason }; }
        var gi = game.gi, vo = new (ldef("Communication.VO::dTimedProductionVO"))();
        vo.productionType = lt.type; vo.type_string = lt.recipeName; vo.amount = 1; vo.stacks = 1; vo.buildingGrid = lt.grid;
        var sLT = viaAdapter(function (A) { return A.sendMessage("START_TIMED_PRODUCTION", vo); });   // 0.8.25
        if (!sLT.ok && sLT.retry) { note("buffer Love Tree waits: " + sLT.reason); return { fact: "wait", reason: sLT.reason }; }   // 0.8.26
        if (!sLT.ok) { note("buffer Love Tree dc " + sLT.reason); tk41Act("decline", order.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", reason: sLT.reason }); return { fact: "dc", reason: sLT.reason }; }
        loveTreeSentAt = Date.now();
        note("buffer Love Tree @" + lt.grid + " ex " + lt.recipeName + " (level " + lt.level + ")");
        tk41Act("promise", lt.grid, { actor: "buff applier", rule: "R-ZONE-LOVETREE", zone: true, buff: lt.effect, recipe: lt.recipeName, level: lt.level, by: order.by });   // 0.8.8: was "execute"
        return { fact: "ex" };
    }
    function applyBuff(order) {
        var grid = Number(order.grid), want = String(order.buff || "");
        var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone);
        var bld = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(grid);
        function dc(reason) { note("buffer @" + grid + " " + want + " dc " + reason); tk41Act("decline", grid, { actor: "buff applier", buff: want, reason: reason, by: order.by }); return { fact: "dc", reason: reason }; }
        if (!bld) return dc("no building");
        var mbA = bld.productionBuff != null ? mapBuilding(grid) : null, GAf = root.GCAF_GameInterface;   // 0.8.28: the exception is the buff KIND (adapter 0.2.4, buff-actions.yaml), not a flag on the order
        var acts = mbA && GAf && typeof GAf.buffAction === "function" ? GAf.buffAction(want, String(mbA.buffName || "")) : null;
        if (bld.productionBuff != null && !acts) return dc("already buffed");
        if (bld.IsUpgradeInProgress && bld.IsUpgradeInProgress()) return dc("upgrading");
        if (busy(grid)) return dc("order in progress");
        if (buffOnItsWay(grid)) return dc("buff on its way");
        if (game.gi && game.gi.isOnHomzone && !game.gi.isOnHomzone()) return dc("not home");
        var stack = null;
        try {
            (game.gi.mCurrentPlayer.getBuffsSortedForStarMenu() || []).forEach(function (b) {
                if (stack || !b || b.IsExhausted || (b.GetWaitingForServer && b.GetWaitingForServer())) return;
                var d = b.GetBuffDefinition && b.GetBuffDefinition();
                if (!d || !d.GetName_string || typeof b.GetUniqueId !== "function") return;
                var dn = String(d.GetName_string()), shown = dn;
                try { shown = String(loca.GetText("RES", dn) || dn); } catch (_) {}
                if (dn === want || dn.toLowerCase() === want.toLowerCase() || shown.toLowerCase() === want.toLowerCase()) stack = b;   // 0.7.8: by name or shown name
            });
        } catch (_) {}
        if (!stack) { buffRefused[String(grid)] = Date.now(); return dc("buff not in the star menu"); }
        var was = null;
        if (acts) { was = String(mbA.buffName || ""); }   // 0.8.8: the declare is the buff changing
        var sAB = viaAdapter(function (A) { return A.sendAction("APPLY_BUFF", 0, grid, 0, stack.GetUniqueId(), { stack: stack }); });   // 0.8.25
        if (!sAB.ok && sAB.retry) { note("buffer @" + grid + " " + want + " waits: " + sAB.reason); return { fact: "wait", reason: sAB.reason }; }   // 0.8.26: transient, not a decline
        if (!sAB.ok) { buffRefused[String(grid)] = Date.now(); return dc(sAB.reason); }
        buffSent[String(grid)] = Date.now(); saveBuffSent();
        note("buffer @" + grid + " ex " + want + " (order by " + (order.by || "?") + (order.why ? ", " + order.why : "") + ")");
        tk41Act("promise", grid, { actor: "buff applier", buff: want, by: order.by, why: order.why, replace: acts ? true : null, was: was });   // 0.8.8: was "execute"
        return { fact: "ex" };
    }

    /* ---------- execute: one paced sequence of server actions ---------- */
    function execute(rows) {
        var c = ctrl();
        rows = rows || last;
        if (!c) return;
        var actions = [], jobsKinds = [];   // 0.7.3
        function pushA(kind, fn) { actions.push(fn); jobsKinds.push(kind); }
        var maxSearch = Number(pol("control.maxActionsPerCycle", 5)) || 5, nSearch = 0;
        var groups = null;
        rows.forEach(function (job) {
            if (job.fact !== "pm") return;
            if (job.ars === "demolish") pushA(job.ars, function () {
                var out = c.sendDemolish(job.grid, { name: job.slot && job.slot.name ? String(job.slot.name) : "" });   // 0.8.14: the building decided on
                note("demolish [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.fact || out.error || out.reason)) || ""));
                var okD = !!(out && (out.fact === "ex" || out.ok));   // 0.8.9: the game took it = promise (was "execute")
                tk51Act(okD ? "promise" : "decline", job.grid, { actor: okD ? "game (order taken)" : "game / safeguard", rule: job.rule, resource: job.resource, result: out && (out.fact || out.error || out.reason), reason: okD ? null : String(out && (out.reason || out.error || out.fact) || "refused") });
                return out;
            });
            else if (job.ars === "buff" && applier()) pushA(job.ars, function () {   // 0.9.1: the buff applier executes TK41 once it is ready
                var B = applier(); if (!B) return { fact: "wait", reason: "buff applier not ready" };
                if (job.order && job.order.kind === "zone") return B.startLoveTree(job.order);
                if (job.order) return B.applyBuff(job.order);
                return B.applyChosen({ grid: job.grid, resource: job.resource, name: job.name || (job.slot && job.slot.name) || "", request: job.request || null, rule: "R-BUFF-CHOICE", by: "construction manager" });
            });
            else if (job.ars === "buff" && job.order && job.order.kind === "zone") pushA(job.ars, function () { return startLoveTree(job.order); });   // 0.8.1
            else if (job.ars === "buff" && job.order) pushA(job.ars, function () { return applyBuff(job.order); });   // 0.7.7
            else if (job.ars === "buff") pushA(job.ars, function () {
                var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone);
                var bld = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(job.grid));
                function dcM(reason) { note("buff @" + job.grid + " dc " + reason); tk41Act("decline", job.grid, { actor: "buff applier", rule: "R-BUFF-CHOICE", resource: job.resource, reason: reason }); }   // 0.8.8: recorded
                if (!bld) { dcM("no building"); return; }
                if (bld.productionBuff != null) { dcM("already buffed"); return; }
                if (bld.IsUpgradeInProgress && bld.IsUpgradeInProgress()) { dcM("upgrading"); return; }
                if (busy(job.grid)) { dcM("order in progress"); return; }
                if (buffOnItsWay(job.grid)) { dcM("buff on its way"); return; }   // 0.6.5
                if (game.gi && game.gi.isOnHomzone && !game.gi.isOnHomzone()) { dcM("not home"); return; }
                if (!groups) groups = buffGroups();
                var bldName = bld.GetBuildingName_string ? String(bld.GetBuildingName_string()) : (job.name || "");
                var pick = chooseBuff(job, groups, bldName);
                if (!pick) { buffRefused[String(job.grid)] = Date.now(); dcM("no accepted buff in the star menu (retry after 10 min)"); return; }
                var stack = null, si;
                for (si = 0; si < pick.g.stacks.length; si++) if (!pick.g.stacks[si].IsExhausted) { stack = pick.g.stacks[si]; break; }
                if (!stack) { dcM("stack exhausted"); return; }
                var sBC = viaAdapter(function (A) { return A.sendAction("APPLY_BUFF", 0, Number(job.grid), 0, stack.GetUniqueId(), { stack: stack }); });   // 0.8.25
                if (!sBC.ok && sBC.retry) { note("buff [R-BUFF-CHOICE] @" + job.grid + " waits: " + sBC.reason); return { fact: "wait", reason: sBC.reason }; }   // 0.8.26
                if (!sBC.ok) { buffRefused[String(job.grid)] = Date.now(); dcM(sBC.reason); return; }
                pick.g.used += 1;
                buffSent[String(job.grid)] = Date.now(); saveBuffSent();   // 0.6.5
                var rid = "R-BUFF-CHOICE";
                note("buff [" + rid + "] " + job.resource + " @" + job.grid + " ex " + pick.g.loc + " (" + pick.how + ")");
                tk41Act("promise", job.grid, { actor: "buff applier", rule: rid, resource: job.resource, buff: pick.g.def, how: pick.how });   // 0.8.8: was "execute"
                return { fact: "ex" };
            });
            else if (job.ars === "build") pushA(job.ars, function () {
                var out = c.sendBuild({ resourceType: job.resource, grid: job.grid }, true);
                if (out && out.fact === "ex") { markOrder(job.grid, "build"); workSent(job.grid, job.resource); }   // 0.8.0
                else if (out) { var wk = work["build@" + job.grid]; if (wk) { wk.why = "blue waits: " + (out.reason || out.error || out.fact) + (out.missing ? " (" + out.missing + ")" : ""); wk.at = Date.now(); saveWork(); } }
                if (out && out.missing) missingAt[job.resource] = { at: Date.now(), what: String(out.missing) };
                note("build [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.reason || out.error || out.fact)) || "") + (out && out.missing ? " missing " + out.missing : ""));
                var wkA = work["build@" + job.grid] || {}, queueWait = !!(out && out.fact === "wait" && /queue-full|previous order not confirmed/.test(String(out.reason || "")));   // 0.8.15
                if (queueWait) { if (!wkA.promised) { wkA.promised = Date.now(); saveWork(); record("c", { tk: "TK21", act: "promise", actor: "construction composer", rule: job.rule, resource: job.resource, grid: job.grid, reason: "on the agenda; realised when the build queue has a place" }); } }
                else if (out && out.fact === "ex" && wkA.promised) { /* already promised while it waited: the order taken realises the promise */ }
                else record("c", { tk: "TK21", act: out && out.fact === "ex" ? "promise" : "decline", actor: out && out.fact === "ex" ? "game (order taken)" : "game / blue", rule: job.rule, resource: job.resource, grid: job.grid, result: out && (out.reason || out.error || out.fact), missing: out && out.missing });
                return out;
            });
            else if (job.ars === "upgrade") pushA(job.ars, function () {
                if (upInProgress(job.grid)) { note("upgrade @" + job.grid + " not sent: a composition is in progress"); return { fact: "dc", reason: "TK21 in progress" }; }
                var sl = job.slot || {};
                tk31Act("request", job.grid, { actor: "construction manager", resource: job.resource, name: sl.name || "", from: Number(job.level) || 0, reason: "level " + job.level + " < " + targetLevel(job.resource, sl.name) });
                var out = c.sendUpgrade(job.grid, true);
                var okU = !!(out && (out.fact === "ex" || out.ok));
                if (okU) { markOrder(job.grid, "upgrade"); tk31Act("promise", job.grid, { actor: "game (order taken)", resource: job.resource, from: Number(job.level) || 0 }); }
                else tk31Act("decline", job.grid, { actor: "game / safeguard", resource: job.resource, reason: String(out && (out.reason || out.error || out.fact) || "refused") });   // 0.8.7: rests in "declined" until a renewed request
                note("upgrade [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.fact || out.error || out.reason)) || ""));
                return out;
            });
            else if (job.ars === "search" && nSearch++ < maxSearch) pushA(job.ars, function () {
                var out = c.sendSearch(job.resource, true, { replacement: !!job.replacement, luckyFind: !!job.lf });   // 0.6.4
                note("search [" + job.rule + "] " + job.resource + " " + ((out && (out.error || out.reason || (out.ok ? "sent" : ""))) || ""));
                var sid = job.resource + "#" + Date.now() + "#" + (++searchSeq);   // 0.8.10: one transaction per search
                var dReq = null; try { var I1 = isl(); if (I1 && I1.depositMap) dReq = JSON.stringify(I1.depositMap(job.resource)); } catch (_) {}   // v3.41 ARS-11-05: the deposits at the request
                tk11Act("request", sid, { actor: "specialist manager (geo)", initiator: "specialist manager (geo)", rule: job.rule, resource: job.resource, reason: job.reason, geo: out && out.geo, geoName: out && out.geoName, lf: job.lf ? true : null, depositMapAtRequest: dReq });
                if (!(out && out.ok)) tk11Act("decline", sid, { actor: "game / blue", resource: job.resource, reason: String(out && (out.error || out.reason) || "refused") });
                if (out && out.ok && out.geo) verifySearch(job.resource, out.geo, out.geoName, sid);   // 0.6.7
                return out;
            });
        });
        if (!actions.length) return;
        var interval = paceMs();
        note("send sequence " + actions.length + " actions, " + interval + " ms apart");
        record("pace", { ms: interval, actions: actions.length });
        var lastDemo = -1; jobsKinds.forEach(function (kd, k) { if (kd === "demolish") lastDemo = k; });   // 0.7.3
        var startAt = 0; try { var Mx = cmgr(), Dx = dsmgr(); if (Mx && typeof Mx.sendingMs === "function") startAt = Number(Mx.sendingMs()) || 0; if (Dx && typeof Dx.sendingMs === "function") startAt = Math.max(startAt, Number(Dx.sendingMs()) || 0); } catch (_) {}   // 0.9.2: after the construction manager's sequence
        actions.forEach(function (fn, k) {
            var extra = (lastDemo >= 0 && k > lastDemo && jobsKinds[k] === "search") ? 5000 : 0;
            setTimeout(function () {
                try {
                    if (c && typeof c.atHome === "function" && !c.atHome()) { note("away from home: action skipped"); return; }   // 0.6.9
                    var out = fn();
                    var t = trouble(out);
                    paceResult(!t, t);
                } catch (e) { note("send err " + e); paceResult(false, "exception " + e); record("i", { what: "send error", reason: String(e) }); }
            }, startAt + k * interval + extra);
        });
    }

    /* 0.6.7: 30 s after a send, the geologist must have a task; still idle means the game refused the search */
    function verifySearch(r, geoId, geoName, sid) {
        setTimeout(function () {
            try {
                var g = geologists().filter(function (x) { return x && String(x.id) === String(geoId); })[0];
                if (!g) return;
                if (g.idle) {
                    var x = searchRefused[r] || { n: 0 }; x.n += 1; x.at = Date.now(); searchRefused[r] = x;
                    note("search " + r + " refused by the game (" + x.n + "x); hold " + Math.round(searchBackoffMs(x.n) / 60000) + " min");
                    tk11Act("decline", sid, { actor: "game (observed)", resource: r, geoName: geoName, reason: "the game did not start the search (geologist idle after 30 s)", refusals: x.n, holdMin: Math.round(searchBackoffMs(x.n) / 60000) });   // 0.8.10: was "failed"
                } else {
                    if (searchRefused[r]) delete searchRefused[r];
                    tk11Act("promise", sid, { actor: "game (observed)", resource: r, geo: geoId, geoName: geoName });   // 0.8.10
                }
            } catch (e) { note("verify search " + e); }
        }, 30000);
    }

    /* ---------- 0.8.17: R-ADV-LOOT — the adventure manager advises an adventure for a short resource (ADR 0048) ---------- */
    var lootAt = 0, lootLast = [], lootSaid = {};
    function lootTick(now) {
        now = now || Date.now();
        if (now - lootAt < 600000) return lootLast;
        lootAt = now;
        var L = root.DMA_AdvLoot, D = root.DMA_Demo, AX = root.DMA_Adventure;
        if (!L || !D || !D.stockTrends) return lootLast;
        if (pol("adv.loot.on", true) === false || pol("adv.loot.on", true) === "false") { lootLast = []; return lootLast; }
        var star = {}, book = {};
        try { star = AX && AX.starCounts ? AX.starCounts() : {}; } catch (_) {}
        try { book = AX && AX.book ? AX.book() : {}; } catch (_) {}
        var trends = []; try { trends = D.stockTrends(Number(pol("adv.loot.windowHours", 6)) || 6); } catch (_) {}
        lootLast = L.advise(trends, { star: star, book: book, from: String(pol("adv.loot.from", "star")), horizonHours: Number(pol("adv.loot.horizonHours", 48)) || 48 });
        lootLast.forEach(function (a) {
            if (lootSaid[a.resource] && now - lootSaid[a.resource] < 6 * 3600000) return;
            lootSaid[a.resource] = now;
            note("R-ADV-LOOT " + L.text(a));
            record("i", { what: "adventure advice", rule: "R-ADV-LOOT", ars: "ARS-17-11", actor: "adventure manager", resource: a.resource, amount: a.amount, perHour: a.perHour,
                          hoursLeft: a.hoursLeft, play: a.play ? a.play.adventure : "", expected: a.play ? a.play.expected : 0, obtain: a.obtain ? a.obtain.adventure : "" });
        });
        return lootLast;
    }

    function tick() {
        try {
            var rows = assess();
            execute(rows);
            try { lootTick(); } catch (e) { note("R-ADV-LOOT err " + e); }   // 0.8.17
            return rows;
        } catch (e) {
            note("green tick err " + (e && e.message ? e.message : e));
            return [];
        }
    }

    function target(r) {
        var q = picture(facts())[r];
        if (!q) return null;
        return { capacity: q.capacity, proven: q.proven, spots: q.spots, seed: q.seed, occupied: q.occupied, empty: q.empty, due: q.due.length, open: q.open, lead: q.lead };
    }

    /* ---------- 0.9.0 (ADR 0074 step 1): the I-services of green behind an interface ---------- */
    function pic0() { return picture(facts()); }
    var compute = {
        capacity: function (r) { var q = pic0()[r]; return q ? q.capacity : null; },                               // R-CAP: the capacity of a resource
        targetLevel: targetLevel,                                                                                   // DFS-44, never above control's maximum (ELS-33)
        lead: function (r) { return leadSeconds(r); },                                                              // search lead time of r (seconds), without the margin
        due: function (r) { var q = pic0()[r]; return q ? q.due.map(function (m) { return { grid: m.grid, name: m.name, amount: m.amount, eta: m.eta }; }) : []; },   // mines whose deposit runs out within lead + margin
        gap: function (r) {                                                                                          // searches needed = empty spots + due mines without a free deposit - open searches (R-GAP / R-DUE)
            var q = pic0()[r]; if (!q) return { need: 0, empty: 0, due: 0, open: 0, replacement: false };
            var dueUncovered = Math.max(0, q.due.length - q.free.length), full = q.empty <= 0 && dueUncovered > 0;   // every spot occupied: the game refuses a search until a mine is demolished (R-DUE, 0.7.0)
            if (full) dueUncovered = 0;
            var need = q.empty + dueUncovered - q.open;
            return { need: Math.max(0, need), empty: q.empty, due: q.due.length, open: q.open, replacement: dueUncovered > 0, full: full, capacity: q.capacity };
        },
        low: function () {                                                                                           // R-DEMO: empty and low mines (not busy), by amount
            var th = Number(pol("demolish.threshold", 20)) || 20, pic = pic0(), out = { threshold: th, empty: [], low: [] }, r;
            for (r in pic) { if (!pic.hasOwnProperty(r) || QUARRY[r]) continue;
                pic[r].mines.filter(function (m) { return m.amount != null && !busy(m.grid); }).sort(function (a, b) { return Number(a.amount) - Number(b.amount); }).forEach(function (m) {
                    var a = Number(m.amount), e = { grid: m.grid, name: m.name, resource: r, amount: a };
                    if (a === 0) out.empty.push(e); else if (a > 0 && a <= th) out.low.push(e); });
            }
            return out;
        },
        buffNeeds: function () {                                                                                     // the constructions that need a buff (DFS-10/44/46/51): { rule, grid, name, resource, level }
            var out = [], slots = facts(), slotGrids = {}, i, s, requests = [];
            try { requests = JSON.parse(localStorage.getItem("dma.buffRequests.v1") || "[]") || []; } catch (_) {}
            var rq = {}; requests.forEach(function (x) { if (x && x.grid != null) rq[String(x.grid)] = x; });
            for (i = 0; i < slots.length; i++) { s = slots[i]; if (s && s.grid != null) slotGrids[String(s.grid)] = true;
                if (!isMineSlot(s)) continue;
                var lv = live(s.grid), buffed = lv ? lv.buffed : !!s.buffed, level = lv && lv.level ? lv.level : s.level, up = lv ? lv.upgrading : !!s.upgrading;
                if (buffed || up) continue;
                if (Number(level) < targetLevel(s.resource, s.name) && !rq[String(s.grid)]) continue;
                out.push({ rule: "R-BUFF-WHEN", grid: s.grid, name: s.name, resource: s.resource, level: level, request: rq[String(s.grid)] || null });
            }
            var m0 = null; try { m0 = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            ((m0 && m0.buildings) || []).forEach(function (b) {
                if (!b || slotGrids[String(b.grid)]) return;
                var d = eventDecl(b.name);
                if (d) { if (!b.buffed && pol("event." + d.event + ".buff.on", false) === true && eventRunningPic(d.event) === true) out.push({ rule: "R-EV-BUFF-WHEN", grid: b.grid, name: b.name, resource: d.label, level: b.level }); return; }
                var trains = MILITARY_RX.test(String(b.name || "")) ? trainsForTroops(b) : null;
                if ((!b.prod && trains === null) || b.buffed || prefFor(b.name) === "none" || trains === false || (trains !== true && !b.producing) || b.upgradeInProgress) return;
                var tl = Number(pol("ctype." + b.name + ".targetLevel", null)) || Number(pol("building.upgradeLevel." + b.name, 0)) || 0;
                if (tl && Number(b.level) < tl) return;
                out.push({ rule: "R-BUFF-PROD", grid: b.grid, name: b.name, resource: b.name, level: b.level });
            });
            return out;
        },
        buffChoice: function (grid, name, request) {                                                                          // the buff for a building: { def, loc, how } or null (the stock is the game's star menu)
            var d = eventDecl(name), pick = null;
            if (d) { var best = eventOptions(grid, name, allBuffGroups())[0]; return best ? { def: best.def, loc: best.loc, how: "event option" } : null; }
            var groups = buffGroups(), s = null; facts().forEach(function (x) { if (x && String(x.grid) === String(grid)) s = x; });
            pick = isMineSlot(s) ? chooseBuff({ grid: grid, request: request || null }, groups, name) : prodChoice(grid, name, groups, prefFor(name));
            return pick ? { def: pick.g.def, loc: pick.g.loc, how: pick.how } : null;
        },
        buffPref: function (name) { return prefFor(name); },                                                        // 0.9.2: the player's choice for a building type ("none" = never)
        trainsForTroops: trainsForTroops,                                                                           // 0.9.2: DFS-51 (null: not a barracks)
        eventDecl: eventDecl, eventRunning: eventRunningPic,                                                        // 0.9.2: the event's declaration for a building name; the running event from the picture
        eventBuildings: eventBuildings,                                                                             // 0.9.2: the buildings a running event type brings
        session: function () {                                                                                      // 0.9.2: one decision cycle's buff picks; take() counts a pick against the stock, as the rules did inline
            var groups = null, all = null;
            return {
                prodPick: function (grid, name) { if (!groups) groups = buffGroups(); return prodChoice(grid, name, groups, prefFor(name)); },
                eventPick: function (grid, name) { if (!all) all = allBuffGroups(); return eventOptions(grid, name, all)[0] || null; },
                take: function (pick) { if (pick && pick.g) pick.g.used += 1; }
            };
        },
        eventPlan: eventPlan,
        eventOptions: function (grid, name) { return eventOptions(grid, name).map(function (o) { return { buff: o.loc, def: o.def, percent: o.percent, hours: o.hours, available: o.available, extra: o.extra }; }); },
        loveTreePlan: function () { var p = loveTreePlan(); return { ok: p.ok, reason: p.reason || "ready", grid: p.grid, level: p.level, type: p.type, recipeName: p.recipeName || "", effect: p.effect }; },
        lootAdvice: function () { return JSON.parse(JSON.stringify(lootLast)); }
    };
    var agenda = {   /* remembering the construction agenda (ADR 0045): the construction manager's list of waiting constructions; dma-worklist.json */
        list: function () { return JSON.parse(JSON.stringify(work)); },
        want: function (grid, r, why) { var ch = workWant(grid, r, why); if (ch) saveWork(); return ch; },
        sent: function (grid, r) { workSent(grid, r); },   // workSent writes the list itself
        get: function (grid) { var it = work["build@" + grid]; return it ? JSON.parse(JSON.stringify(it)) : null; },   // 0.9.2
        update: function (grid, fields) { var it = work["build@" + grid], k; if (!it) return false; for (k in fields) if (fields.hasOwnProperty(k)) it[k] = fields[k]; saveWork(); return true; },   // 0.9.2: blue's reason, the promise given while it waited
        review: function (freeGrids, queued) { var ch = workReview(freeGrids, queued); if (ch) saveWork(); return ch; }
    };

    root.DMA_Green = {
        facts: facts, picture: pic0, pictureOf: picture, live: live, compute: compute, agenda: agenda,   // 0.9.0; 0.9.2: pictureOf(slots) for a caller that enriched the slots
        busy: busy,   // 0.9.1: for the buff applier's truth clause
        version: VERSION,
        rules: function () { return JSON.parse(JSON.stringify(RULES)); },
        param: param,
        pace: function () { return { ms: paceMs(), clean: pace.clean, errors: pace.errors }; },
        assess: assess,
        last: function () { var M = cmgr(), D = dsmgr(); return (M && typeof M.last === "function" ? M.last() : []).concat(D && typeof D.last === "function" ? D.last() : [], last); },   // 0.9.2: the construction manager's rows first, as the rank sorts them
        targetLevel: targetLevel,   // 0.8.29: for the tests
        tick: tick,
        target: target,
        workList: function () { return JSON.parse(JSON.stringify(work)); },   // 0.8.0
        upgrades: function () { return root.DMA_Tx ? root.DMA_Tx.list({ tk: "TK21", open: true }).filter(function (t) { return String(t.key).indexOf("@") > 0; }) : []; },   // 0.8.15   // 0.8.4: open TK31 from the C-fact memory
        workReview: function () { var ch = workReview(null, null); if (ch) saveWork(); return ch; },   // 0.8.0 (tests, console)
        eventPlan: eventPlan,            // 0.7.4
        applyBuff: applyBuff,            // 0.7.7: the buffer — any order { grid, buff, by, why }
        lootAdvice: function () { return JSON.parse(JSON.stringify(lootLast)); },   // 0.8.17
        lootTick: lootTick,              // 0.8.17 (tests, console)
        loveTreePlan: function () { var p = loveTreePlan(); return { ok: p.ok, reason: p.reason || "ready", grid: p.grid, level: p.level, recipe: p.recipeName || "" }; },   // 0.8.1
        startLoveTree: startLoveTree,    // 0.8.1
        eventCandidates: function () {   // 0.7.5: building names in the scan that look like an event building (diagnosis)
            var m = null, out = [];
            try { m = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            var c = (m && m.counts && (m.counts.buildingAll || m.counts.building)) || {};
            Object.keys(c).forEach(function (n) { if (/pumpkin|cemeter|grave/i.test(n)) out.push(n + " x" + c[n] + (eventDecl(n) ? " (declared)" : "")); });
            return out;
        },
        eventOptions: function (grid, name) { return eventOptions(grid, name).map(function (o) { return { buff: o.loc, def: o.def, percent: o.percent, hours: o.hours, available: o.available, extra: o.extra }; }); },
        retract: function (grid, reason) {
            var n = 0;
            try { if (ctrl() && ctrl().retractBuild) ctrl().retractBuild(grid, reason || "green retract"); } catch (_) {}
            note("retract @" + grid + " " + (reason || "") + " blue=" + n);
            return n;
        }
    };
    if (!root.DMA_Buffer) root.DMA_Buffer = { version: VERSION, actor: "buff applier", tk: "TK41", applyBuff: applyBuff, startLoveTree: startLoveTree };   // 0.8.20: the red role; 0.9.1: only when the buff applier is not there
    note("green rules " + VERSION + " loaded (" + RULES.length + " rules, ticked by DMA_Demo)");
})(typeof window !== "undefined" ? window : this);
