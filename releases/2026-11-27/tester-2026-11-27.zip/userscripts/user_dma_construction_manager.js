/*
 * DMA Construction manager 0.1.0 — actor role AR20 "construction manager" (case kind CONSTRUCTION, TK20; it requests TK21, TK41 and TK51), ADR 0074 step 3.
 * Author, 2026-11-16: "green is geen constructie manager. green is de onthouder en de berekenaar, verder niks."
 *
 * 0.1.8 (2026-11-19, ADR 0087 addendum, live 13:55-17:30 UTC): (a) R-MASONS-FIRST reads the masons from the game's map
 *   as well as from the slots (at 14:09 four saltpetre builds slipped through while two masons stood below target);
 *   (b) rule R-TOOL-RESERVE: no build, and no upgrade of a kind whose build cost holds tools (masons exempt), while the
 *   tool stock is below policy build.toolReserve (default 20,000; 0 = off). Tools fell from 27,110 to 1,413 in 3.5 h.
 *   Unit: tests/unit/cm-masons-first.test.js (both). Integration: tests/integration/dma-construction-manager-handover.test.js.
 * 0.1.7 (2026-11-19, ADR 0087, author: "graniet werkt met masons ... de upgrade van de masons is eenmalig en blijvend"): rule
 *   R-MASONS-FIRST. While a granite mason stands below its target level (building.upgradeLevel.Granite), a build whose cost
 *   holds granite (control.buildCosts: saltpetre and titanium mines, 2,000 each) is not requested ("dc", reason names the
 *   masons); the granite is kept for the mason upgrades. Policy build.masonsFirst = false switches it off. Live 13:13 UTC: four
 *   mason upgrades were taken by the game and never started while eleven saltpetre/titanium builds waited for the same granite.
 *   Unit: tests/unit/cm-masons-first.test.js. Integration: tests/integration/dma-construction-manager-handover.test.js (no
 *   granite in that world: nothing held).
 * 0.1.6 (2026-11-19, ADR 0084, live check 08:49 UTC: R-BUFF-WHEN requested a buff 5 times for workflow copper mines 6420/6154 —
 *   declined only because the star menu held no accepted buff): facts() keeps a workflow spot whose mine reads amount 0 (so an
 *   empty player mine is still cleared), and a just-built workflow mine can read amount 0; R-BUFF-WHEN now skips every workflow
 *   spot (wfOwns), like R-BUFF-PROD since 0.1.5.
 *   Unit expectation: R-BUFF-WHEN gives no TK41 for a workflow spot with a basic mine at amount 0. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js (that case, with the real managers).
 * 0.1.5 (2026-11-19, ADR 0084, live): R-BUFF-PROD walks every production building of control's map and skips the mine slots of the
 *   facts — but the facts no longer hold a workflow's spots, so the workflow's own copper mine (demolished a minute later) got a buff
 *   (6775, 05:14 UTC, a wasted "Employee of the Month Badge"). A building on a spot a workflow holds is skipped too.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.1.4 (2026-11-18, ADR 0084 Workflows / Deposit Cycling, point 7 "the plan adapts"): the spots of a workflow that is on are no production spots: facts() leaves
 *   them out (no build, upgrade, buff or demolish by R-SLOT / R-PRIO / R-UPG / R-BUFF-* / R-DEMO-*) EXCEPT a mine whose deposit is empty (amount 0): R-DEMO-EMPTY
 *   still clears it, so a running-out mine of the player on a picked spot becomes a free spot for the workflow (live 2026-11-18: every iron and copper spot is occupied), and the review of the open TK21 compositions leaves the
 *   workflow's own "<grid>@1" requests to the workflow (it revokes them itself). TK51 is reviewed as every TK51. Without user_dma_workflows.js nothing changes.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.1.3 (2026-11-17, UAT 2026-11-17 finding F2; the manual says "Without a target nothing is upgraded"): the manager's own fallback for the target level (used only when green's compute interface has no targetLevel) was 2.
 *   It is 0 now: no target = no target, so no R-UPG request is made for a resource without one (green 0.9.4 answers 0 for it). A stored target works as before.
 *   Unit: tests/unit/dma-construction-manager.test.js (an explicit upg.IronOre = 0 removes the R-UPG request of the level-1 mine, 2 brings it back). Integration: tests/integration/green-no-target-nothing-upgraded.test.js.
 * 0.1.2 (2026-11-16, ADR 0075 R-2/R-3, backbone v3.19, ARS-20-11 "for each [resource] that needs more production"; coordinator batch item 3.5): the manager reads which resources NEED MORE PRODUCTION (DFS-54) from the resource
 *   supply manager (DMA_SupplyManager.moreProduction(); it reads, it does not ask: the picture and the agenda stay as they are) and raises production for them FIRST, within the player's own limits: a free deposit of such
 *   a resource goes to the front of the build candidates (R-PRIO, before the shortfall order), its mines to the front of the upgrade candidates (R-UPG; the target level and the safeguard still hold) and of the
 *   buff candidates (R-BUFF-WHEN). A change of the list is recorded as the fact "needs more production" (TK20, per resource, once per change). Makers that are not mines (workyards) are not built here: the manager's
 *   rules know mines and deposits only. Without the supply manager nothing changes.
 *   Unit: tests/unit/dma-construction-manager-more-production.test.js (the order of the candidates with and without the list). Integration: tests/integration/dma-construction-more-production-flow.test.js (real policy,
 *   transactions, agents, green, construction manager and supply manager: a short ore's free spot is built before another ore's with the larger shortfall).
 * 0.1.1 (2026-11-16, ADR 0074 step 3b; the author: "filling a deposit is the same transaction as a buff", D-5): the manager also requests the FILLERS — TK41, buff sort "deposit filler", rule R-EV-FILL — moved from
 *   the event module (event 0.2.17 recorded the request itself). requestFills(round) takes the event manager's reading of a round { type, event, plan: [{ grid, add }], uid, before: { grid: amount }, now, report }:
 *   per building it records the AR20 request and orders the buff applier (applyFill) to execute it, 3 s apart; a transient hold is retried 1.5 s later up to 5 times and then the request is revoked
 *   (report.revoked); a taken send waits to be SEEN: the deposit read again must have grown (declare by the applier, accept by the manager), else after 10 min revoke promise, allow, decline — the review of the
 *   fills runs in tick(). The event module keeps only the reading (which event runs, which buildings are fillable, how much each gets). fills() answers the counters.
 *   Unit: tests/unit/dma-construction-manager-fill.test.js (request, order, retry and revoke, declare + accept only when the deposit grows, not-shown revocation). Integration: tests/integration/dma-construction-manager-fill-tx.test.js.
 * 0.1.0 (2026-11-16, ADR 0074 step 3): the AR20 decisions that lived in green 0.8.29 / 0.9.x, moved VERBATIM: the request rules R-SLOT, R-PRIO (build), R-UPG (upgrade, TK21 above level 1),
 *   R-BUFF-WHEN, R-BUFF-PROD, R-ZONE-LOVETREE, R-EV-BUFF-WHEN, R-EV-COUNTER (TK41), R-DEMO-EMPTY / R-DEMO-LAND / R-DEMO-LOW (TK51, requested by AR20), the reviews tk31Review, tk41Review and tk51Review
 *   (declare / accept / revoke against the game; the TK51 request is now AR20's own act, actor "construction manager", where green wrote "demolish manager" — ADR 0074 section 1) and the hand-off of the orders: control sends builds, upgrades and demolitions, the buff applier (AR41) executes TK41. The manager reads green
 *   only through its interface (DMA_Green.facts / live / pictureOf / param / compute.* / agenda.*); the work list stays green's memory (agenda.want / sent / review / get / update). It does not scan
 *   (ADR 0040), sends nothing itself (ADR 0073: control and the applier send), and is ticked by the agents' cycle under the same "game not responding" pause as green.
 *   Presence and readiness (ADR 0074 section 3): check() is true when green's interface, control and a READY buff applier are there; green 0.9.2 then emits no AR20 row and runs no AR20 review; without
 *   this file, or while check() is false, green decides as before (rollback = remove the file). Known difference: green deleted its "buff on its way" marker the moment the mine showed buffed; the applier's
 *   marker expires by itself after 10 min, and the manager reads only the unbuffed buildings, so the answer is the same except for a building whose buff was removed within those minutes.
 *   GLOBAL: DMA_ConstructionManager = { version, owner "construction manager", actor, ready, check, tick, assess, last, demolished, busy, sendingMs }.
 *   Unit: tests/unit/dma-construction-manager.test.js (each rule gives its row and its TK request through the real policy; nothing is sent while a switch is off; not ready without the applier).
 *   Integration: tests/integration/dma-construction-manager-handover.test.js (real transactions, agents, adapter, applier, green and manager: one order per construction, the pattern request -> promise -> declare
 *   -> accept, green emits no AR20 row; with the manager removed the same orders go out).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.8";
    var ORES = ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];
    var QUARRY = { Stone: 1, Marble: 1, Granite: 1 };
    var RANK = { demolish: 0, buff: 1, build: 2, upgrade: 3, search: 4 };
    var MILITARY_RX = /^(Barracks|EliteBarracks)$/;
    var BUFF_SENT_MS = 10 * 60 * 1000;
    var last = [], demolishedLast = {}, seqAt = 0, seqMs = 0, ready = false;

    /* ---------- what the manager reads: green's interface, the policy, control, the C-fact memory ---------- */
    function G() { return root.DMA_Green || null; }
    function CP() { var g = G(); return (g && g.compute) || {}; }
    function AG() { var g = G(); return (g && g.agenda) || { want: function () { return false; }, review: function () { return false; }, sent: function () {}, get: function () { return null; }, update: function () { return false; } }; }
    function sess() { var c = CP(); return typeof c.session === "function" ? c.session() : { prodPick: function () { return null; }, eventPick: function () { return null; }, take: function () {} }; }
    function note(s) {
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
            if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200);
            root.__DMA_CYCLE_AT = Date.now();
        } catch (_) {}
    }
    function pol(k, d) {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; }
        } catch (_) {}
        return d;
    }
    function param(id, name) { var g = G(); return g && typeof g.param === "function" ? g.param(id, name) : undefined; }
    function ctrl() { return root.DMA_Control || null; }
    function cmem() { return root.DMA_Tx || null; }
    function wfOwns(grid) { try { var W = root.DMA_Workflows; return !!(W && typeof W.ownsGrid === "function" && W.ownsGrid(grid)); } catch (_) { return false; } }   // ADR 0084
    function facts() { var g = G(), s = g && typeof g.facts === "function" ? g.facts() : []; return (s || []).filter(function (x) { return !(x && wfOwns(x.grid)) || (x.mine && Number(x.amount) === 0); }); }   // 0.1.4 (ADR 0084): an EMPTY mine on a workflow spot stays, so R-DEMO-EMPTY clears it
    function live(grid) { var g = G(); return g && typeof g.live === "function" ? g.live(grid) : null; }
    function picture(slots) { var g = G(); return g && typeof g.pictureOf === "function" ? g.pictureOf(slots) : {}; }
    function targetLevel(r, name) { var c = CP(); return typeof c.targetLevel === "function" ? c.targetLevel(r, name) : 0; }   // 0.1.3 (UAT F2): without green no target is invented (was 2)
    /* 0.1.7 (author 2026-11-19: "graniet werkt met masons, dus we bouwen nooit mijnen, de upgrade van de masons is eenmalig en
       blijvend"): a mason upgrade is a lasting gain, a new saltpetre or titanium mine spends 2,000 granite. While a granite mason
       stands below its target level (and policy build.masonsFirst is not false), no build whose cost holds granite is requested:
       the granite is kept for the mason upgrades. Answers "" (nothing waits) or e.g. "4608 at 3 < 7". */
    function masonsFirst(slots) {
        if (pol("build.masonsFirst", true) === false) return "";
        var out = [], seen = {}, i, sl, t;
        function consider(grid, name, level) {
            if (seen[String(grid)] || !/mason/i.test(String(name || ""))) return;
            seen[String(grid)] = true;
            t = Number(targetLevel("Granite", name)) || 0;
            if (t > 0 && Number(level) > 0 && Number(level) < t) out.push(grid + " at " + level + " < " + t);
        }
        // 0.1.8: the game's own map first (live 14:09: the slots carried no mason and four saltpetre builds slipped through)
        try { var m = ctrl() && ctrl().map && ctrl().map(), bs = (m && m.buildings) || []; for (i = 0; i < bs.length; i++) consider(bs[i].grid, bs[i].name, bs[i].uiLevel != null ? bs[i].uiLevel : bs[i].level); } catch (_) {}
        for (i = 0; i < (slots || []).length; i++) { sl = slots[i]; if (sl && sl.resource === "Granite") consider(sl.grid, sl.name, sl.level); }
        return out.join(", ");
    }
    /* 0.1.8 (author 2026-11-19, live: tools fell from 27,110 to 1,413 in 3.5 h): R-TOOL-RESERVE. A build, or an upgrade of a
       kind whose build cost holds tools, is not requested while the tool stock is below policy build.toolReserve (default
       20,000; 0 switches it off). Granite masons are exempt (their upgrades cost granite and planks, and they last). */
    function toolsShort() {
        var res = Number(pol("build.toolReserve", 20000)) || 0; if (res <= 0) return "";
        var n = null; try { var D = root.DMA_Demo, st = D && typeof D.stockNow === "function" ? D.stockNow() : null; if (st && st.Tool != null) n = Number(st.Tool); } catch (_) {}
        return n != null && n < res ? "tools " + Math.round(n) + " < reserve " + res : "";
    }
    function needsTools(r) {
        try { var c = ctrl(), k = c && typeof c.buildCosts === "function" ? c.buildCosts(r) : null; return !!(k && Number(k.Tool) > 0); } catch (_) { return false; }
    }
    function needsGranite(r) {
        try { var c = ctrl(), k = c && typeof c.buildCosts === "function" ? c.buildCosts(r) : null; return !!(k && Number(k.Granite) > 0); } catch (_) { return false; }
    }
    function isMineSlot(s) {
        return !!(s && (s.mine || /mine|mason|quarry/i.test(String(s.name || ""))) && !s.depleted);
    }
    function geologists() {
        try { return (ctrl() && ctrl().geologists && ctrl().geologists()) || []; } catch (_) { return []; }
    }
    function applier() {   // the buff applier (AR41), when it is there and ready
        try { var B = root.DMA_Buffer; if (B && B.owner === "buff applier" && (typeof B.check === "function" ? B.check() : B.ready === true)) return B; } catch (_) {}
        return null;
    }
    function refusedHeld(grid) { var B = applier(); return !!(B && B.refused(grid)); }   // the game refused every buff for the grid, less than 10 min ago
    function buffOnItsWay(grid) { var B = applier(); return !!(B && B.onItsWay(grid)); }

    /* ---------- busy grids (recent build/upgrade order) ---------- */
    var BUSY_MS = 15 * 60 * 1000, recentOrder = {};
    function markOrder(grid, kind) { recentOrder[String(grid)] = { kind: kind, at: Date.now() }; }
    function busy(grid) {
        var r = recentOrder[String(grid)];
        if (r && Date.now() - r.at < BUSY_MS) return r.kind;
        if (r) delete recentOrder[String(grid)];
        try { var c = ctrl(); if (c && c.hasBuildOrder && c.hasBuildOrder(grid)) return "build"; } catch (_) {}
        return "";
    }
    var missingAt = {};   /* missing materials (resource reservation declined) */

    /* ---------- 0.8.2/0.8.4: TK31 (upgrade) — the upgrade manager's acts are C-facts; R-UPG reads them from the C-fact memory ---------- */
    function cmem() { return root.DMA_Tx || null; }
    /* 0.8.15: an upgrade is TK21 composing to a level above 1 — the case key is "<grid>@<level>" */
    function upOpen(grid) {                                  // the open composition above level 1 on a grid (any state), or null
        var M = cmem(); if (!M) return null;
        var l = M.list({ tk: "TK21", open: true }).filter(function (t) { return String(t.key).indexOf(String(grid) + "@") === 0; });
        return l.length ? l[0] : null;
    }
    function upInProgress(grid) { var t = upOpen(grid), M = cmem(); return t && M ? M.inProgress("TK21", t.key) : null; }
    function tk31Act(act, grid, extra) {
        var from = extra && extra.from != null ? Number(extra.from) : null, t0 = from == null ? upOpen(grid) : null;
        if (from == null && t0) from = Number(t0.data && (t0.data.from != null ? t0.data.from : t0.data.fromLevel)) || 0;
        var to = (Number(from) || 0) + 1;
        var o = { tk: "TK21", act: act, rule: "R-UPG", grid: Number(grid), key: String(grid) + "@" + to, to: to }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        if (o.actor === "upgrade manager") o.actor = "construction manager";
        record("c", o);
    }
    function tk31Revoke(grid, why, extra) {                 // 0.8.6: DEMO 4 — the initiator revokes its request; the game allows (tacit)
        var o = { actor: "construction manager", reason: why }, k; if (extra) for (k in extra) o[k] = extra[k];
        tk31Act("revoke request", grid, o);
        tk31Act("allow", grid, { actor: "game (tacit)" });
    }
    /* the open TK31 of a grid, reviewed against the game (execute / declare + accept / cancel / revoke); null when none */
    function tk31Review(grid, s) {
        var M = cmem(); if (!M) return null;
        var t = upInProgress(grid);                             // 0.8.7: a declined one is not in progress; 0.8.15 TK21 <grid>@<level>
        if (!t) return null;
        var from = Number(t.data.from != null ? t.data.from : t.data.fromLevel) || 0;
        var lv = s ? Number(s.level) || 0 : 0, nm = s ? String(s.name || "") : "", up = !!(s && s.upgrading);
        if (!s) { try { var L = live(grid); if (L) { lv = Number(L.level) || 0; nm = L.name; up = !!L.upgrading; s = L; } } catch (_) {} }
        if (!s) { tk31Revoke(grid, "the mine is gone"); return null; }
        if (lv < from || (t.data.name && nm && t.data.name !== nm)) { tk31Revoke(grid, "another building on the grid (rebuilt)", { level: lv }); return null; }
        if (t.state === "requested") return upInProgress(grid);
        if (lv > from && !up) {
            tk31Act("declare", grid, { actor: "game (observed)", level: lv, from: from });
            tk31Act("accept", grid, { actor: "construction manager", level: lv, from: from });
            return null;
        }
        if (up && t.state === "promised" && !(t.history || []).some(function (h) { return h.act === "execute"; })) tk31Act("execute", grid, { actor: "game (observed)", from: from });   // 0.8.12: once
        var rh = Number(param("R-UPG", "revokeHours")) || 0;
        if (rh > 0 && !up && t.state === "promised" && Date.now() - t.since > rh * 3600000) {
            var rel = ctrl() && typeof ctrl().releaseUpgradeOrder === "function" ? ctrl().releaseUpgradeOrder(grid) : { ok: false, reason: "no control" };   // 0.8.16
            if (rel && rel.ok) { tk31Revoke(grid, "the game did not start it within " + rh + " h; " + rel.reason); return null; }
        }
        return upInProgress(grid);
    }
    /* ---------- 0.8.8: TK41 (buff application) — C-facts of the buffer, reviewed against the game ---------- */
    var TK41_INITIATOR = { "R-BUFF-WHEN": "construction manager", "R-BUFF-PROD": "construction manager", "R-ZONE-LOVETREE": "construction manager", "R-EV-BUFF-WHEN": "construction manager", "R-EV-COUNTER": "construction manager" };   // 0.8.21: AR20 (backbone v3.16 D-3)
    function tk41Act(act, grid, extra) {
        var o = { tk: "TK41", act: act, grid: Number(grid) }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    function mapBuilding(grid) {
        try { var m = ctrl() && ctrl().map && ctrl().map(), bs = (m && m.buildings) || [], i; for (i = 0; i < bs.length; i++) if (String(bs[i].grid) === String(grid)) return bs[i]; } catch (_) {}
        return null;
    }
    function zoneBuffRunning(effect) {
        try { var zb = game.gi.mZoneBuffManager; return !!(effect && zb && zb.isBuffRunning && zb.isBuffRunning(effect)); } catch (_) { return false; }
    }
    function promisedAt(t) {
        var i; for (i = t.history.length - 1; i >= 0; i--) if (t.history[i].act === "promise" && !t.history[i].note) return Number(t.history[i].at) || t.since;   // 0.8.9: not a repeated one
        return t.since;
    }
    /* every TK41 in progress: declare + accept when the game shows the buff; revoke request + allow when it is lost */
    function tk41Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now();
        M.list({ tk: "TK41", open: true }).forEach(function (t0) {
            var t = M.inProgress("TK41", t0.key); if (!t || t.revoking) return;
            var d = t.data || {}, grid = t.key, init = d.initiator || "construction manager", shown = false, gone = false;
            if (d.zone || d.rule === "R-ZONE-LOVETREE") shown = zoneBuffRunning(d.buff);
            else {
                var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone), b = null;
                try { b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid)); } catch (_) { b = null; }
                if (!b) gone = true;
                else if (d.replace) { var mb = mapBuilding(grid), bn = mb ? String(mb.buffName || "") : ""; shown = t.state === "promised" && !!(bn && bn !== String(d.was || "")); }
                else shown = b.productionBuff != null;
            }
            function revoke(why) { tk41Act("revoke request", grid, { actor: init, reason: why }); tk41Act("allow", grid, { actor: "buff applier (tacit)" }); }
            if (gone) { revoke("the building is gone"); return; }
            if (shown && (t.state === "promised" || t.state === "requested")) {
                tk41Act("declare", grid, { actor: "buff applier (game observed)", buff: d.buff });
                tk41Act("accept", grid, { actor: init, buff: d.buff });
                return;
            }
            if (t.state === "promised" && now - promisedAt(t) >= BUFF_SENT_MS) { revoke("the game did not show the buff within " + Math.round(BUFF_SENT_MS / 60000) + " min"); return; }
            if (t.state === "requested" && now - t.since >= BUFF_SENT_MS) revoke("the buffer did not take it up within " + Math.round(BUFF_SENT_MS / 60000) + " min");
        });
    }

    /* ---------- 0.8.9: TK51 (mine demolition) — reviewed against the game; declare + accept, or revoke when lost ---------- */
    var TK51_LOST_MS = 10 * 60000;
    function tk51Act(act, grid, extra) {
        var o = { tk: "TK51", act: act, grid: Number(grid) }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        record("c", o);
    }
    function tk51Review() {
        var M = cmem(); if (!M) return;
        var now = Date.now();
        M.list({ tk: "TK51", open: true }).forEach(function (t0) {
            var t = M.inProgress("TK51", t0.key); if (!t || t.revoking) return;
            var d = t.data || {}, grid = t.key, init = d.initiator || "construction manager", b = null, nm = "";
            try { var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone); b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid)); } catch (_) { b = null; }
            try { nm = b && b.GetBuildingName_string ? String(b.GetBuildingName_string()) : ""; } catch (_) { nm = ""; }
            var gone = !b || !/mine|mason|quarry/i.test(nm) || (d.name && nm !== String(d.name));
            if (gone) {
                tk51Act("declare", grid, { actor: "game (observed)", name: d.name, reason: b ? "another building on the grid" : "the mine is gone" });
                tk51Act("accept", grid, { actor: init, name: d.name });
                return;
            }
            var since = t.since, i;
            for (i = t.history.length - 1; i >= 0; i--) if (t.history[i].act === "promise" && !t.history[i].note) { since = Number(t.history[i].at) || since; break; }   // the promise that counts, not a repeated one
            if (now - since < TK51_LOST_MS) return;
            tk51Act("revoke request", grid, { actor: init, reason: t.state === "promised" ? "the game did not demolish it within 10 min" : "not answered within 10 min" });
            tk51Act("allow", grid, { actor: "game (tacit)" });
        });
    }


    function safeUpgrade(slot) {
        var C = root.DMA_Control;
        if (!C || typeof C.guardUpgrade !== "function") return "control without safeguard";   // fail closed
        try { return C.guardUpgrade(slot.grid) || ""; } catch (e) { return "safeguard error " + e; }
    }
    function record(kind, data) {
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {}
    }
    var ARS_TK = { search: "TK11", build: "TK21", upgrade: "TK21", buff: "TK41", demolish: "TK51" };   // 0.8.15: an upgrade is TK21
    var declineSeen = {}, DECLINE_REPEAT_MS = 3600000;   // 0.6.1: decline recorded on change, else hourly

    /* ---------- self-correcting pace ---------- */
    var pace = { ms: null, clean: 0, errors: 0 };
    function paceMs() {
        if (pace.ms == null) pace.ms = Number(pol("control.sendIntervalMs", 1500)) || 1500;
        return pace.ms;
    }
    function paceResult(ok, what) {
        var floor = Number(pol("control.sendIntervalMinMs", 700)) || 700;
        if (ok) {
            pace.clean += 1;
            if (pace.clean >= 20 && pace.ms > floor) { pace.ms = Math.max(floor, Math.round(pace.ms * 0.9)); pace.clean = 0; note("pace faster: " + pace.ms + " ms"); record("pace", { ms: pace.ms, why: "20 clean actions" }); }
        } else {
            pace.errors += 1;
            pace.clean = 0;
            pace.ms = Math.min(6000, paceMs() * 2);
            note("pace slower: " + pace.ms + " ms after " + what);
            record("pace", { ms: pace.ms, why: what });
        }
    }
    function trouble(out) {
        var e = out && (out.error || out.reason);
        return e && /zone|ready|connect|server|timeout|socket|lost/i.test(String(e)) ? String(e) : "";
    }

    function row(rule, ars, fact, s, r, reason, extra) {
        var o = { rule: rule, ars: ars, fact: fact, grid: s ? s.grid : "", resource: r, reason: reason, slot: s || null };
        if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        return o;
    }

    /* 0.1.2: the resources that need more production (DFS-54), read from the resource supply manager */
    var moreSeen = "";
    function moreProd() {
        var m = {};
        try { var S = root.DMA_SupplyManager; if (S && typeof S.moreProduction === "function") m = S.moreProduction() || {}; } catch (_) { m = {}; }
        var sig = Object.keys(m).sort().join(",");
        if (sig !== moreSeen) { moreSeen = sig; Object.keys(m).forEach(function (r) { record("p", { tk: "TK20", fact: "needs more production", resource: r, amount: m[r].amount, rule: "ARS-20-11" }); }); }
        return m;
    }
    function assess() {
        var slots = facts();
        var on = {
            geo: pol("geo.auto", false) === true, build: pol("build.auto", false) === true,
            upgrade: pol("upgrade.auto", false) === true, buff: pol("buff.auto", false) === true,
            demo: pol("demo.auto", false) === true
        };
        note("construction manager " + VERSION + " assess slots=" + slots.length + " geo=" + on.geo + " build=" + on.build + " upgrade=" + on.upgrade + " buff=" + on.buff + " demo=" + on.demo);
        var i, j, s, r, q;
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!isMineSlot(s)) continue;
            var lv = live(s.grid);
            if (lv) { if (lv.level) s.level = lv.level; s.upgrading = lv.upgrading; s.buffed = lv.buffed; }
            s.busy = busy(s.grid);
        }
        var more = moreProd();
        var pic = picture(slots);   // green computes the per-resource picture from the enriched slots (DMA_Green.pictureOf)
        var rows = [];

        tk51Review();   // 0.8.9: before any new TK51 request of this cycle
        /* --- demolish (ARS-51-02) --- */
        var demolished = {};
        if (on.demo) {
            var threshold = Number(pol("demolish.threshold", 20)) || 20;
            var landLead = param("R-DEMO-LAND", "leadSeconds");
            var cD = ctrl(), idleGeos = geologists().filter(function (g) { return g && g.idle && !(cD && cD.isReserved && cD.isReserved(g.id)); }).length;   // 0.7.2
            for (r in pic) {
                if (!pic.hasOwnProperty(r) || QUARRY[r]) continue;
                q = pic[r];
                var budget = { free: q.free.length, open: q.open };
                var byAmount = q.mines.filter(function (m) { return m.amount != null && !m.busy; })
                    .sort(function (a, b) { return Number(a.amount) - Number(b.amount); });
                for (j = 0; j < byAmount.length; j++) {
                    s = byAmount[j];
                    if (Number(s.amount) === 0) { rows.push(row("R-DEMO-EMPTY", "demolish", "pm", s, r, "deposit empty")); demolished[s.grid] = true; }
                }
                var returning = q.openSoon.filter(function (t) { return t > 0 && t <= landLead; }).length;
                var emptyNow = q.empty;
                for (j = 0; j < byAmount.length && returning > emptyNow; j++) {
                    s = byAmount[j];
                    if (demolished[s.grid]) continue;
                    if (!(Number(s.amount) <= threshold)) { rows.push(row("R-DEMO-LAND", "demolish", "dc", s, r, "lowest mine has " + s.amount + " left, above the threshold " + threshold + "; the find waits")); break; }   // 0.6.8
                    rows.push(row("R-DEMO-LAND", "demolish", "pm", s, r, "geologist returns within " + landLead + " s and R has no empty spot; lowest mine (" + s.amount + " left)"));
                    demolished[s.grid] = true;
                    emptyNow += 1;
                }
                for (j = 0; j < byAmount.length; j++) {
                    s = byAmount[j];
                    if (demolished[s.grid]) continue;
                    var a = Number(s.amount);
                    if (!(a > 0 && a <= threshold)) continue;
                    if (budget.free > 0) { budget.free -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", replacement: free deposit")); }
                    else if (budget.open > 0) { budget.open -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", replacement: geologist out")); }
                    else if (q.empty <= 0 && idleGeos > 0) { idleGeos -= 1; demolished[s.grid] = true; rows.push(row("R-DEMO-LOW", "demolish", "pm", s, r, "low " + a + ", every spot occupied: makes room, a search follows")); }   // 0.7.2
                    else rows.push(row("R-DEMO-LOW", "demolish", "dc", s, r, "low " + a + ", no replacement left"));
                }
            }
        }

        tk41Review();   // 0.8.8: before any new TK41 request of this cycle
        /* --- upgrade and buff candidates --- */
        var upgradeCand = [], buffCand = [], seenTk31 = {};
        var requests = [];
        try { requests = JSON.parse(localStorage.getItem("dma.buffRequests.v1") || "[]") || []; } catch (_) {}
        var requestGrids = {};
        requests.forEach(function (rq) { if (rq && rq.grid != null) requestGrids[String(rq.grid)] = rq; });
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!isMineSlot(s) || demolished[s.grid]) continue;
            var max = targetLevel(s.resource, s.name);
            var req = requestGrids[String(s.grid)];
            if (s.buffed && req) { delete requestGrids[String(s.grid)]; req = null; }
            var openT = tk31Review(s.grid, s);   // 0.8.2: declare/accept happen whether Upgrade is on or off
            if (openT) seenTk31[String(s.grid)] = true;
            if (on.upgrade && Number(s.level) < max) {
                if (openT) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "TK31 " + openT.state + " at level " + (openT.data.from != null ? openT.data.from : openT.data.fromLevel) + ": waiting for the declare"));
                else if (s.busy) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, s.busy + " order in progress"));
                else if (s.upgrading) rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "upgrading"));
                else upgradeCand.push(s);
            }
            if ((on.buff || req) && !s.buffed && !wfOwns(s.grid)) {   // 0.1.6: never a workflow's mine (ADR 0084)
                if (buffOnItsWay(s.grid)) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "buff on its way (sent less than 10 min ago)"));
                else if (s.busy) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, s.busy + " order in progress"));
                else if (s.upgrading) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "upgrading"));
                else if (Number(s.level) < max && !req) rows.push(row("R-BUFF-WHEN", "buff", "dc", s, s.resource, "level " + s.level + " < target " + max));
                else if (refusedHeld(s.grid)) rows.push(row("R-BUFF-CHOICE", "buff", "dc", s, s.resource, "game refused every buff; retry after 10 min"));
                else buffCand.push({ s: s, req: req });
            }
        }
        try { localStorage.setItem("dma.buffRequests.v1", JSON.stringify(Object.keys(requestGrids).map(function (k) { return requestGrids[k]; }))); } catch (_) {}
        buffCand.sort(function (a, b) { return ((more[b.s.resource] ? 1 : 0) - (more[a.s.resource] ? 1 : 0)) || (Number(b.s.level) || 0) - (Number(a.s.level) || 0); });
        var maxBuff = param("R-BUFF-WHEN", "maxPerCycle");
        for (i = 0; i < buffCand.length; i++) {
            s = buffCand[i].s;
            rows.push(row("R-BUFF-WHEN", "buff", i < maxBuff ? "pm" : "dc", s, s.resource,
                i < maxBuff ? ("at target level " + s.level + ", not buffed" + (buffCand[i].req ? " (player request)" : "")) : ("wait: max " + maxBuff + " per cycle"),
                { level: s.level, name: s.name, request: buffCand[i].req || null }));
        }

        /* --- build (ARS-20-11): only for free queue slots, by priority --- */
        var qn = null;
        try { qn = ctrl() && ctrl().queueNow && ctrl().queueNow(); } catch (_) {}
        var slotsFree = qn && qn.free != null ? Math.max(0, Number(qn.free)) : 0;
        if (qn && qn.slots != null && qn.used != null) slotsFree = Math.min(slotsFree, Math.max(0, Number(qn.slots) - Number(qn.used)));
        var qInfo = qn ? ("slots=" + qn.slots + " used=" + qn.used + " clientFree=" + qn.free + " free=" + slotsFree) : "queue unknown";
        var queued = (qn && qn.grids) || {};
        if (on.build) {
            var pauseMs = param("R-PRIO", "missingPauseSeconds") * 1000;
            var buildCand = [];
            var masonsBelow = masonsFirst(slots);   // 0.1.7: granite goes to the mason upgrades first
            var toolLow = toolsShort();   // 0.1.8
            for (r in pic) {
                if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0) continue;
                q = pic[r];
                for (j = 0; j < q.free.length; j++) {
                    s = q.free[j];
                    if (queued[String(s.grid)] || busy(s.grid)) { rows.push(row("R-SLOT", "build", "dc", s, r, "already ordered")); continue; }
                    if (missingAt[r] && Date.now() - missingAt[r].at < pauseMs) { rows.push(row("R-PRIO", "build", "dc", s, r, "materials missing: " + (missingAt[r].what || "?"))); continue; }
                    if (toolLow && needsTools(r)) { rows.push(row("R-TOOL-RESERVE", "build", "dc", s, r, toolLow)); continue; }
                    if (masonsBelow && needsGranite(r)) { rows.push(row("R-MASONS-FIRST", "build", "dc", s, r, "granite is kept for the mason upgrades (" + masonsBelow + ")")); continue; }
                    buildCand.push({ s: s, r: r, more: more[r] ? 1 : 0, shortfall: Math.max(0, q.capacity - q.mines.length) / Math.max(1, q.capacity), amount: Number(s.amount) || 0 });
                }
            }
            buildCand.sort(function (a, b) { return (b.more - a.more) || (b.shortfall - a.shortfall) || (b.amount - a.amount); });
            var workChanged = false, freeGrids = {};   // 0.8.0
            for (r in pic) { if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0) continue; for (j = 0; j < pic[r].free.length; j++) freeGrids[String(pic[r].free[j].grid)] = true; }
            for (i = 0; i < buildCand.length; i++) {
                var bc = buildCand[i];
                if (slotsFree > 0) {
                    slotsFree -= 1;
                    rows.push(row("R-SLOT", "build", "pm", bc.s, bc.r, "queue slot free; priority " + (i + 1) + " (shortfall " + Math.round(bc.shortfall * 100) + "%, " + bc.amount + " units)", { amount: bc.amount }));
                    if (AG().want(bc.s.grid, bc.r, "queue slot free; priority " + (i + 1))) workChanged = true;
                } else {
                    rows.push(row("R-SLOT", "build", "dc", bc.s, bc.r, "waiting for a build-queue slot (promise deferred)"));
                    if (AG().want(bc.s.grid, bc.r, "waiting for a build-queue slot")) workChanged = true;
                }
            }
            for (r in pic) {   // 0.8.0: a candidate waiting for materials is still work
                if (!pic.hasOwnProperty(r) || QUARRY[r] || ORES.indexOf(r) < 0 || !(missingAt[r] && Date.now() - missingAt[r].at < pauseMs)) continue;
                for (j = 0; j < pic[r].free.length; j++) { s = pic[r].free[j]; if (!queued[String(s.grid)] && !busy(s.grid) && AG().want(s.grid, r, "materials missing: " + (missingAt[r].what || "?"))) workChanged = true; }
            }
            if (AG().review(freeGrids, queued)) workChanged = true;
        }

        /* --- 0.8.2: open TK31 on grids that were not among this cycle's mines (gone or not a mine slot) --- */
        if (cmem()) cmem().list({ tk: "TK21", open: true }).filter(function (t) { return t.state !== "declined" && String(t.key).indexOf("@") > 0 && !(t.data && t.data.workflow); }).forEach(function (t) { var g = String(t.key).split("@")[0]; if (!seenTk31[g]) { var sx = null; for (var q = 0; q < slots.length; q++) if (String(slots[q].grid) === g && isMineSlot(slots[q])) sx = slots[q]; if (!sx) tk31Review(g, null); } });

        /* --- upgrades take the slots that are left --- */
        var useQueue = param("R-SLOT", "upgradesUseQueue");
        upgradeCand.sort(function (a, b) { return ((more[b.resource] ? 1 : 0) - (more[a.resource] ? 1 : 0)) || (Number(a.level) || 0) - (Number(b.level) || 0); });
        for (i = 0; i < upgradeCand.length; i++) {
            s = upgradeCand[i];
            // 0.6.2 SAFEGUARD (incident 2026-10-24): only a kind control has verified, below its maximum level
            var toolLowU = toolsShort();
            if (toolLowU && needsTools(s.resource) && !/mason/i.test(String(s.name || ""))) { rows.push(row("R-TOOL-RESERVE", "upgrade", "dc", s, s.resource, toolLowU)); continue; }
            var whyK = safeUpgrade(s);
            if (whyK) { rows.push(row("R-UPG", "upgrade", "dc", s, s.resource, "safeguard: " + whyK)); continue; }
            if (!useQueue || slotsFree > 0) {
                if (useQueue) slotsFree -= 1;
                rows.push(row("R-UPG", "upgrade", "pm", s, s.resource, "level " + s.level + " < " + targetLevel(s.resource, s.name), { level: s.level }));
            } else {
                rows.push(row("R-SLOT", "upgrade", "dc", s, s.resource, "waiting for a build-queue slot"));
            }
        }

        /* --- 0.7.8: counters (R-EV-COUNTER): a trick on a building is answered with a Treat --- */
        var ctrs = [];
        try { ctrs = (root.DMA_Event && root.DMA_Event.counters) ? root.DMA_Event.counters() : []; } catch (_) { ctrs = []; }
        if (ctrs.length) {
            var cMax = param("R-EV-COUNTER", "maxPerCycle"), cN = 0, cm = null;
            try { cm = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            ((cm && cm.buildings) || []).forEach(function (b) {
                var bn = String(b.buffName || "").toLowerCase();
                if (!bn) return;
                ctrs.forEach(function (c) {
                    if (bn.indexOf(String(c.when).toLowerCase()) < 0) return;
                    if (CP().eventRunning(c.event) !== true) return;   // 0.8.21: only while the picture shows the event
                    var es = { grid: b.grid, name: b.name, resource: b.name };
                    if (buffOnItsWay(b.grid)) { rows.push(row("R-EV-COUNTER", "buff", "dc", es, b.name, c.when + " on it; " + c.give + " on its way")); return; }
                    if (cN >= cMax) { rows.push(row("R-EV-COUNTER", "buff", "dc", es, b.name, "wait: max " + cMax + " per cycle")); return; }
                    cN += 1;
                    rows.push(row("R-EV-COUNTER", "buff", "pm", es, b.name, c.when + " on it (" + b.buffName + "): order " + c.give,
                        { order: { grid: b.grid, buff: c.give, by: "construction manager", why: c.label } }));
                });
            });
        }

        /* --- 0.7.7: the event manager's orders to the buffer (R-EV-BUFF-WHEN / R-EV-BUFF-CHOICE, ADR 0029) --- */
        var evMax = param("R-EV-BUFF-WHEN", "maxPerCycle"), evN = 0, evS = sess();
        CP().eventBuildings().forEach(function (b) {
            if (pol("event." + b.event + ".buff.on", false) !== true) return;
            var evr = CP().eventRunning(b.event);   // 0.8.21: the running event from the picture (ARS-20-11 given)
            if (evr !== true) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", { grid: b.grid, name: b.name, resource: b.label }, b.label, evr === undefined ? "no events picture (location manager)" : "the event is not running")); return; }
            var es = { grid: b.grid, name: b.name, resource: b.label };
            if (b.buffed) return;
            if (buffOnItsWay(b.grid)) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "buff on its way (sent less than 10 min ago)")); return; }
            if (busy(b.grid)) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "order in progress")); return; }
            if (evN >= evMax) { rows.push(row("R-EV-BUFF-WHEN", "buff", "dc", es, b.label, "wait: max " + evMax + " per cycle")); return; }
            var best = evS.eventPick(b.grid, b.name);
            if (!best) { rows.push(row("R-EV-BUFF-CHOICE", "buff", "dc", es, b.label, "no buff in stock for this building")); return; }
            evS.take(best); evN += 1;
            rows.push(row("R-EV-BUFF-WHEN", "buff", "pm", es, b.label, "order to the buffer: " + best.loc + " (+" + best.extra + " " + (b.unit || "") + " in " + best.hours + " h)",
                { order: { grid: b.grid, buff: best.def, by: "construction manager", why: "+" + best.extra + " " + (b.unit || "") } }));
        });

        /* --- 0.8.18: R-BUFF-PROD (buff manager): every production building at its determined level --- */
        if (on.buff && param("R-BUFF-PROD", "on") !== false) {
            var pm0 = null; try { pm0 = ctrl() && ctrl().map && ctrl().map(); } catch (_) {}
            var slotGrids = {}; slots.forEach(function (x) { if (x && x.grid != null) slotGrids[String(x.grid)] = true; });
            var pMax = param("R-BUFF-PROD", "maxPerCycle"), pN = 0, pS = sess();
            ((pm0 && pm0.buildings) || []).forEach(function (b) {
                var trains = b && MILITARY_RX.test(String(b.name || "")) ? CP().trainsForTroops(b) : null;   // 0.8.23: DFS-51 (null: not a barracks)
                if (!b || (!b.prod && trains === null) || slotGrids[String(b.grid)] || wfOwns(b.grid) || CP().eventDecl(b.name)) return;   // 0.1.5: not a workflow's mine
                if (b.buffed) return;   // the applier's "on its way" marker expires by itself
                var ps = { grid: b.grid, name: b.name, resource: b.name, level: b.level };
                var pref = CP().buffPref(b.name);
                if (pref === "none") return;
                if (trains === false) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "not training for the troops (DFS-51)")); return; }   // 0.8.23
                if (trains !== true && !b.producing) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "not producing (stopped or waiting for input)")); return; }
                if (b.upgradeInProgress) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "upgrading")); return; }
                var tl = Number(pol("ctype." + b.name + ".targetLevel", null)) || Number(pol("building.upgradeLevel." + b.name, 0)) || 0;   // 0.8.21: construction type policy (AT70) first
                if (tl && Number(b.level) < tl) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "level " + b.level + " < determined level " + tl)); return; }
                if (buffOnItsWay(b.grid)) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "buff on its way (sent less than 10 min ago)")); return; }
                if (busy(b.grid)) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "order in progress")); return; }
                if (refusedHeld(b.grid)) { rows.push(row("R-BUFF-PROD-CHOICE", "buff", "dc", ps, b.name, "game refused; retry after 10 min")); return; }
                if (pN >= pMax) { rows.push(row("R-BUFF-PROD", "buff", "dc", ps, b.name, "wait: max " + pMax + " per cycle")); return; }
                var pick = pS.prodPick(b.grid, b.name);
                if (!pick) { rows.push(row("R-BUFF-PROD-CHOICE", "buff", "dc", ps, b.name, "no accepted buff in stock for this type")); return; }
                pS.take(pick); pN += 1;
                rows.push(row("R-BUFF-PROD", "buff", "pm", ps, b.name, "producing at level " + b.level + ", not buffed: " + pick.g.loc + " (" + pick.how + ")",
                    { order: { grid: b.grid, buff: pick.g.def, by: "construction manager", why: "R-BUFF-PROD " + pick.how } }));
            });
        }

        /* --- 0.8.1: R-ZONE-LOVETREE (buff manager) --- */
        if (on.buff && param("R-ZONE-LOVETREE", "on") !== false) {
            var lt = CP().loveTreePlan();
            if (lt.ok) rows.push(row("R-ZONE-LOVETREE", "buff", "pm", { grid: lt.grid, name: "LoveTree" }, "Love Tree", "ready: " + lt.recipeName + " (level " + lt.level + ")",
                { order: { kind: "zone", grid: lt.grid, level: lt.level, by: "construction manager", why: "R-ZONE-LOVETREE" } }));
            else if (lt.grid != null) rows.push(row("R-ZONE-LOVETREE", "buff", "dc", { grid: lt.grid, name: "LoveTree" }, "Love Tree", lt.reason));
        }
        rows.sort(function (a, b) { return (RANK[a.ars] != null ? RANK[a.ars] : 9) - (RANK[b.ars] != null ? RANK[b.ars] : 9); });   // 0.7.3: demolish (rank 0) was sorted last ("0 || 9")
        last = rows; demolishedLast = demolished;
        rows.forEach(function (x) {
            var tk = ARS_TK[x.ars] || x.ars;
            if (x.fact === "pm") {
                if (x.ars === "demolish") { var ds = x.slot || {}; tk51Act("request", x.grid, { initiator: "construction manager", actor: "construction manager", rule: x.rule, resource: x.resource, name: ds.name || null, amount: ds.amount != null ? Number(ds.amount) : null, reason: x.reason }); return; }   // 0.8.9
                if (x.ars === "buff") { tk41Act("request", x.grid, { initiator: TK41_INITIATOR[x.rule] || "construction manager", actor: TK41_INITIATOR[x.rule] || "construction manager", rule: x.rule, resource: x.resource, reason: x.reason, buff: x.order && x.order.buff, zone: x.order && x.order.kind === "zone" ? true : null, replace: x.order && x.order.replace ? true : null }); return; }   // 0.8.8
                if (x.ars !== "upgrade" && x.ars !== "search") record("c", { tk: tk, act: "request", rule: x.rule, resource: x.resource, grid: x.grid, reason: x.reason });   // 0.8.10: a search records its request with the send
                return;
            }   // 0.8.3: TK31 acts come from the book
            // 0.6.1: a decline is recorded when it first appears, when its reason changes, and at least hourly
            // while it holds; `repeats` says how many cycles the same decline held since the last record.
            var key = tk + "|" + x.rule + "|" + x.resource + "|" + (x.grid == null ? "" : x.grid);
            var seen = declineSeen[key], now = Date.now();
            if (!seen || seen.reason !== x.reason || now - seen.at >= DECLINE_REPEAT_MS) {
                record("c", { tk: tk, act: "assess", outcome: "not now", rule: x.rule, resource: x.resource, grid: x.grid, reason: x.reason, repeats: seen ? seen.n : 0,
                              key: x.ars === "upgrade" && x.grid != null ? String(x.grid) + "@" + ((Number(x.slot && x.slot.level) || 0) + 1) : undefined });   // 0.8.15: an upgrade's assessment belongs to the composition to the next level   // 0.8.5: the initiator's own assessment, not an executor's decline
                declineSeen[key] = { reason: x.reason, at: now, n: 0 };
            } else {
                seen.n += 1;
            }
        });
        var pm = rows.filter(function (x) { return x.fact === "pm"; }).length;
        note("construction manager assess pm=" + pm + " dc=" + (rows.length - pm) + " queue " + qInfo);
        rows.forEach(function (x) { if (x.fact === "pm" || x.ars === "search") note("construction manager [" + x.rule + "] " + x.ars + " " + x.resource + " @" + x.grid + " " + x.fact + " " + x.reason); });
        var dcs = {};
        rows.forEach(function (x) {
            if (x.fact === "pm" || x.ars === "search") return;
            var key = x.rule + "|" + x.ars + "|" + x.resource + "|" + x.reason;
            if (!dcs[key]) dcs[key] = { x: x, grids: [] };
            dcs[key].grids.push(x.grid);
        });
        Object.keys(dcs).forEach(function (k) {
            var d = dcs[k];
            note("construction manager [" + d.x.rule + "] " + d.x.ars + " " + d.x.resource + " dc " + d.x.reason + " @" + d.grids.slice(0, 6).join(",") + (d.grids.length > 6 ? " +" + (d.grids.length - 6) : ""));
        });
        return rows;
    }

    /* ---------- execute: one paced sequence of server actions ---------- */
    function execute(rows) {
        var c = ctrl();
        rows = rows || last;
        if (!c) return;
        var actions = [], jobsKinds = [];   // 0.7.3
        function pushA(kind, fn) { actions.push(fn); jobsKinds.push(kind); }
        rows.forEach(function (job) {
            if (job.fact !== "pm") return;
            if (job.ars === "demolish") pushA(job.ars, function () {
                var out = c.sendDemolish(job.grid, { name: job.slot && job.slot.name ? String(job.slot.name) : "" });   // 0.8.14: the building decided on
                note("demolish [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.fact || out.error || out.reason)) || ""));
                var okD = !!(out && (out.fact === "ex" || out.ok));   // 0.8.9: the game took it = promise (was "execute")
                tk51Act(okD ? "promise" : "decline", job.grid, { actor: okD ? "game (order taken)" : "game / safeguard", rule: job.rule, resource: job.resource, result: out && (out.fact || out.error || out.reason), reason: okD ? null : String(out && (out.reason || out.error || out.fact) || "refused") });
                return out;
            });
            else if (job.ars === "buff") pushA(job.ars, function () {   // the buff applier executes TK41 (AR41); the manager is ready only while the applier is
                var B = applier(); if (!B) return { fact: "wait", reason: "buff applier not ready" };
                if (job.order && job.order.kind === "zone") return B.startLoveTree(job.order);
                if (job.order) return B.applyBuff(job.order);
                return B.applyChosen({ grid: job.grid, resource: job.resource, name: job.name || (job.slot && job.slot.name) || "", request: job.request || null, rule: "R-BUFF-CHOICE", by: "construction manager" });
            });
            else if (job.ars === "build") pushA(job.ars, function () {
                var out = c.sendBuild({ resourceType: job.resource, grid: job.grid }, true);
                if (out && out.fact === "ex") { markOrder(job.grid, "build"); AG().sent(job.grid, job.resource); }   // 0.8.0
                else if (out) { AG().update(job.grid, { why: "blue waits: " + (out.reason || out.error || out.fact) + (out.missing ? " (" + out.missing + ")" : ""), at: Date.now() }); }
                if (out && out.missing) missingAt[job.resource] = { at: Date.now(), what: String(out.missing) };
                note("build [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.reason || out.error || out.fact)) || "") + (out && out.missing ? " missing " + out.missing : ""));
                var wkA = AG().get(job.grid) || {}, queueWait = !!(out && out.fact === "wait" && /queue-full|previous order not confirmed/.test(String(out.reason || "")));   // 0.8.15
                if (queueWait) { if (!wkA.promised) { wkA.promised = Date.now(); AG().update(job.grid, { promised: wkA.promised }); record("c", { tk: "TK21", act: "promise", actor: "construction composer", rule: job.rule, resource: job.resource, grid: job.grid, reason: "on the agenda; realised when the build queue has a place" }); } }
                else if (out && out.fact === "ex" && wkA.promised) { /* already promised while it waited: the order taken realises the promise */ }
                else record("c", { tk: "TK21", act: out && out.fact === "ex" ? "promise" : "decline", actor: out && out.fact === "ex" ? "game (order taken)" : "game / blue", rule: job.rule, resource: job.resource, grid: job.grid, result: out && (out.reason || out.error || out.fact), missing: out && out.missing });
                return out;
            });
            else if (job.ars === "upgrade") pushA(job.ars, function () {
                if (upInProgress(job.grid)) { note("upgrade @" + job.grid + " not sent: a composition is in progress"); return { fact: "dc", reason: "TK21 in progress" }; }
                var sl = job.slot || {};
                tk31Act("request", job.grid, { actor: "construction manager", resource: job.resource, name: sl.name || "", from: Number(job.level) || 0, reason: "level " + job.level + " < " + targetLevel(job.resource, sl.name) });
                var out = c.sendUpgrade(job.grid, true);
                var okU = !!(out && (out.fact === "ex" || out.ok));
                if (okU) { markOrder(job.grid, "upgrade"); tk31Act("promise", job.grid, { actor: "game (order taken)", resource: job.resource, from: Number(job.level) || 0 }); }
                else tk31Act("decline", job.grid, { actor: "game / safeguard", resource: job.resource, reason: String(out && (out.reason || out.error || out.fact) || "refused") });   // 0.8.7: rests in "declined" until a renewed request
                note("upgrade [" + job.rule + "] " + job.resource + " @" + job.grid + " " + ((out && (out.fact || out.error || out.reason)) || ""));
                return out;
            });
        });
        if (!actions.length) return;
        var interval = paceMs();
        note("send sequence " + actions.length + " actions, " + interval + " ms apart");
        record("pace", { ms: interval, actions: actions.length });
        var hadDemo = jobsKinds.indexOf("demolish") >= 0; seqAt = Date.now(); seqMs = actions.length * interval + (hadDemo ? 5000 : 0);   // the search sequence of green follows this one (5 s after a demolition, as before)
        actions.forEach(function (fn, k) {
            setTimeout(function () {
                try {
                    if (c && typeof c.atHome === "function" && !c.atHome()) { note("away from home: action skipped"); return; }   // 0.6.9
                    var out = fn();
                    var t = trouble(out);
                    paceResult(!t, t);
                } catch (e) { note("send err " + e); paceResult(false, "exception " + e); record("i", { what: "send error", reason: String(e) }); }
            }, k * interval);
        });
    }


    /* ---------- 0.1.1: fillers (TK41, buff sort "deposit filler") ---------- */
    var fillPending = [], fillStat = { requested: 0, verified: 0, notShown: 0 }, VERIFY_FIRST_MS = 20000, VERIFY_MS = 10 * 60000;
    function fillAct(act, cs, actor, extra) {
        try { var o = { tk: "TK41", act: act, caseId: cs.id, grid: cs.grid, actor: actor, initiator: "construction manager", rule: "R-EV-FILL", buffSort: "deposit filler", event: cs.event }, k;
              for (k in (extra || {})) o[k] = extra[k];
              record("c", o); } catch (_) {}
    }
    function depositAmount(gi, grid) {   // the deposit at a grid, read again
        var amt = null;
        try { gi.mCurrentPlayerZone.mStreetDataMap.mDepositContainer.forEach(function (d) { try { if (amt === null && d && Number(d.GetGrid()) === Number(grid)) amt = Number(d.GetAmount()); } catch (_) {} }); } catch (_) {}
        return amt == null || isNaN(amt) ? null : amt;
    }
    function verifyFills(now) {   // declare only what is seen
        now = now || Date.now();
        var gi = null, keep = [];
        try { gi = root.game && root.game.gi; } catch (_) {}
        fillPending.forEach(function (pf) {
            var amt = gi ? depositAmount(gi, pf.grid) : null, cs = { id: pf.id, grid: pf.grid, event: pf.event };
            if (amt !== null && amt > pf.before) {
                fillAct("declare", cs, "buff applier", { amount: pf.add, seen: amt - pf.before, before: pf.before, after: amt });
                fillAct("accept", cs, "construction manager", {});
                fillStat.verified += 1; try { if (pf.report && pf.report.verified) pf.report.verified(pf); } catch (_) {} return;
            }
            if (now - pf.at >= VERIFY_MS) {
                var why = "the deposit did not grow (" + pf.before + " -> " + (amt === null ? "not readable" : amt) + ")";
                fillAct("revoke promise", cs, "buff applier", { reason: why });
                fillAct("allow", cs, "construction manager", { revoked: "promise" });
                fillAct("decline", cs, "buff applier", { reason: why });
                fillStat.notShown += 1; try { if (pf.report && pf.report.notShown) pf.report.notShown(pf); } catch (_) {} return;
            }
            keep.push(pf);
        });
        fillPending = keep;
        return { verified: fillStat.verified, notShown: fillStat.notShown, pending: keep.length };
    }
    function requestFills(round) {
        var B = applier();
        if (!B || typeof B.applyFill !== "function") return { ok: false, reason: "buff applier not ready for fills" };
        var now = round.now || Date.now(), plan = round.plan || [], noTimer = !!root.DMA_EVENT_NO_TIMER || typeof root.setTimeout !== "function";
        plan.forEach(function (p, i) {
            var cs = { id: "fill@" + p.grid + "@" + now, grid: p.grid, event: round.event || round.type }, tries = 0;
            fillAct("request", cs, "construction manager", { amount: p.add, reason: "needs filling (DFS-45)" });
            fillStat.requested += 1;
            var send = function () {
                var r = B.applyFill({ id: cs.id, grid: p.grid, amount: p.add, uid: round.uid, event: cs.event });
                if (r && r.fact === "wait") {   // transient: wait, do not decline
                    tries += 1;
                    if (tries < 5 && !noTimer) { root.setTimeout(send, 1500); return; }
                    fillAct("revoke request", cs, "construction manager", { reason: r.reason });
                    try { if (round.report && round.report.revoked) round.report.revoked(r.reason); } catch (_) {}
                    return;
                }
                if (!r || r.fact !== "ex") return;   // the applier declined and recorded it
                fillPending.push({ id: cs.id, grid: p.grid, event: cs.event, add: p.add, before: (round.before && round.before[p.grid]) || 0, at: now, report: round.report });
                if (!noTimer) root.setTimeout(function () { try { verifyFills(); } catch (_) {} }, VERIFY_FIRST_MS);
            };
            if (i === 0 || noTimer) send(); else root.setTimeout(send, i * 3000);
        });
        return { ok: true, requested: plan.length };
    }

    function tick() {
        try { if (fillPending.length) verifyFills(); } catch (_) {}   // the fills in flight are reviewed every cycle, also with every switch off
        try {
            var rows = assess();
            execute(rows);
            return rows;
        } catch (e) {
            note("construction manager tick err " + (e && e.message ? e.message : e));
            return [];
        }
    }
    /* readiness (ADR 0074 section 3): green's interface, control, and a ready buff applier */
    function check() {
        var g = G(), c = ctrl(), ok = false;
        try { ok = !!(g && g.compute && typeof g.compute.session === "function" && typeof g.pictureOf === "function" && g.agenda && typeof g.agenda.want === "function" && typeof g.param === "function" &&
                      c && typeof c.sendBuild === "function" && typeof c.sendUpgrade === "function" && typeof c.sendDemolish === "function" && applier()); } catch (_) { ok = false; }
        ready = ok; if (api) api.ready = ok;
        return ok;
    }
    var api = {
        version: VERSION, owner: "construction manager", actor: "construction manager", ready: false, check: check, tick: tick, assess: assess,
        last: function () { return last.slice(); },
        demolished: function () { var o = {}, k; for (k in demolishedLast) if (demolishedLast.hasOwnProperty(k)) o[k] = demolishedLast[k]; return o; },   // the grids this cycle's demolitions clear, for the search rules (R-GAP, R-DUE)
        busy: busy, requestFills: requestFills, verifyFills: verifyFills, fills: function () { return { requested: fillStat.requested, verified: fillStat.verified, notShown: fillStat.notShown, pending: fillPending.length }; },
        sendingMs: function () { return Math.max(0, seqAt + seqMs - Date.now()); }   // how long this manager's own paced sequence of orders still runs
    };
    root.DMA_ConstructionManager = api;
    check();
    note("construction manager " + VERSION + " loaded, ready=" + api.ready);
})(typeof window !== "undefined" ? window : this);
