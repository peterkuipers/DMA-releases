/*
 * DMA Workflows 0.2.0 — ADR 0084 (workflows) and ADR 0085 (the workflow grammar). A workflow is a named, switchable set of
 * EXISTING actor roles and business rules applied to SELECTED FACTS. It adds no transaction kind and no actor role.
 *
 * 0.2.7 (2026-11-19, author: "iron wordt niet gebouwd"; live: TK21 6059@1 for iron was taken by the game at 05:59 UTC, never built,
 *   reported "lost" by control at 06:09 — but the transaction stayed "promised", so "no open transaction" waited for the site for
 *   over two hours): a workflow TK21 the game promised (not deferred) that is older than LOST_MS (12 min), with no building on the
 *   spot and not in the build queue, is LOST: the initiator revokes its request (revoke request + allow) and the next tick orders
 *   again. Restart-safe: judged from the transaction's own time, not from memory. A refused order (decline) is not repeated for
 *   RETRY_MS (5 min), so a grid control skips is not requested every tick. LOST_MS / RETRY_MS <= 0 disable these.
 *   Unit: tests/unit/dma-workflows-lost-order.test.js. Integration: tests/integration/dma-workflows-lost-order-rebuild.test.js.
 * 0.2.6 (2026-11-19, live measurement with tools/user_dma_probe_cycle.js; author: "the deposit must vanish to let the geo find new"):
 *   destroying a FINISHED mine makes its deposit vanish (copper 6775, 824 ore left: deposit gone 4.5 s after the order); destroying it
 *   while it is still being built leaves the deposit (overnight 18->19 Nov: 433 demolitions 12 s after the order, the deposits stayed,
 *   an endless rebuild loop with hardly any search). So the workflow's own mine is demolished only when it is FINISHED — on the spot and
 *   no longer in the build queue (control.queueNow().grids) — IF "construction finished"; the follow-up after a build checks again every
 *   5 s (at most 10 minutes) until it is. Loop guard: after the workflow demolished on a spot, a deposit still shown there is not built
 *   on again for GUARD_MS (the picture may lag); still there after twice that, the spot is stopped and reported ("deposit stays after
 *   demolition") instead of looping.
 * 0.2.5 (2026-11-18; author: "uitgesteld is plannen in de toekomst, dus promised voor de toekomst, dus beloofd, maar door implementatie
 *   later uitgevoerd, moet passen in ons demo denken"): when control answers a construction with "wait" (e.g. "previous order not
 *   confirmed", the queue full) the TK21 is PROMISED, not declined — the construction is planned, its execution waits for the
 *   implementation (as the construction manager's "realised when the build queue has a place"). The promise carries deferred: true;
 *   every cycle the workflow sends the deferred order again WITHOUT a new request, until control takes it (then it is this workflow's
 *   build) or answers a real refusal (then the initiator revokes its request: revoke request + allow). After a restart a deferred
 *   promise is the workflow's build only when a building stands on the spot.
 * 0.2.4 (2026-11-18, live check): (1) DEFECT — after a restart the open TK21 "<grid>@1" requests were taken as this workflow's builds
 *   whatever their state, so a DECLINED one (control: "previous order not confirmed") held its spot at "construction ordered; waiting for
 *   the site" for ever (live: Copper 6420 and 6775 since 18:28). Only a TK21 in progress (requested, promised, declared) counts now, a
 *   declined one is renewed by a new request (DEMO 4: declined -> request), and a remembered build whose TK21 is no longer in progress on an
 *   empty or deposit spot is forgotten. (2) A paced request whose case is already under way (another send of the same cycle or the
 *   follow-up took it) is skipped instead of sent: no "safeguard refused" for a demolition that has just happened (live 19:08:11).
 *   (3) stats(): per workflow and resource, since the client started — cycles (own mine demolished), mines cleared, builds, searches,
 *   searches out, the last act — for the WORKFLOWS overview.
 * 0.2.3 (2026-11-18, live; author: "als een geo vindt, actie wordt verzocht maar ze zijn er allemaal al, wordt het alleen geaccepteerd als
 *   een mijn voor die tijd leeg raakt of gepland is afgebroken te worden, anders declined"; live: the game answered a copper search with
 *   "you already have too many deposits of this type"): the rightness of a TK11 request is now assessed BEFORE it is made — IF "a spot is
 *   free when the search ends": capacity of the resource - deposits on the island now - searches already out (every geologist on that
 *   resource, DMA's own and the workflow's) + what leaves before the search ends (mines that run out within the search lead, open
 *   demolitions of that resource, this workflow's own sites, which it demolishes at once) >= 1. Each request of the cycle takes one.
 *   Read from green's picture (DMA_Green.pictureOf over all facts, the same figures the deposit search manager's R-GAP / R-DUE use);
 *   without green's picture the condition does not hold (fail closed: no search the game would decline).
 * 0.2.2 (2026-11-18, live; author: "alles zo snel mogelijk"): as fast as the client allows. (1) The requests of one cycle are sent one after
 *   another at control's pace (control.sendIntervalMs, at least 1.1 s), after the construction manager's and the deposit search manager's own
 *   sequences, instead of all at once (live: the second demolition of a cycle was declined by control's 1 s demolish pace and waited a whole cycle).
 *   (2) A promised construction or demolition is followed up by the workflow itself (FOLLOW_MS after the order: 12 s, as Zingu's 10 s) instead of
 *   waiting for the next agents' cycle: the site is demolished, the emptied spot gets its search, a left deposit its construction. A follow-up
 *   does not schedule another follow-up (one level), and runs only while the workflow is ready. Timers go through api.later (tests replace it).
 * 0.2.1 (2026-11-18, ADR 0084 addendum; author: "Laat de speler kiezen of het in moet gaan bij het leeglopen of afbreken van de mijn, of dat het direct
 *   in moet door het nu al afbreken van de mijnen"): Deposit Cycling gets a start choice per resource (workflow.dc.<R>.start): "empty" (default) waits
 *   until the player's mine on a picked spot runs out (the construction manager clears it with R-DEMO-EMPTY), "now" demolishes the player's mine on a
 *   picked spot at once — rule R-WF-DC-CLEAR (WHEN building on spot, IF player's mine, start now, basic mine, no open TK51, THEN TK51 { clear }).
 *   The TK51 request lets a mine that this workflow did not build go ONLY for a clearing rule whose start resolves to "now" at the moment of the
 *   request, and still ONLY a basic mine (never industrial, endless or tribute); the level lock stays for the workflow's own builds.
 *   With start "empty" a picked spot is not the workflow's while the player's mine stands there (ownsGrid answers ""), so the construction manager keeps
 *   buffing, upgrading and demolishing it (R-DEMO-EMPTY / R-DEMO-LOW) as always; once it is gone the workflow takes the spot.
 * 0.2.0 (2026-11-18, ADR 0085; author: "Als <deze workflow> <actief is> En <voorwaarde x> Dan <stuur geo uit> <van type>"):
 *   a workflow is DATA in the DEMO action-rule form (ARS): WITH = "facts" (the facts the player selects; geologists are allocated),
 *   WHEN = "when" (an event read from the location manager's picture), IF = "assess" (named conditions on facts), THEN = "then" (a REQUEST of an existing
 *   transaction kind, carried out by the existing actor role); "with" and "if" are keywords the client's engine refuses as property names. This file is the interpreter plus the vocabulary; Deposit
 *   Cycling is no longer code but the first definition (DEFINITIONS), rewritten in that form with the same behaviour as 0.1.0.
 *   Vocabulary — WHEN: "building on spot", "deposit on spot", "spot empty". IF: "built by this workflow", "basic mine",
 *   "level at most", "no open transaction", "no search under way", "build queue keeps free", "stock above reserve",
 *   "allocated geologist idle". THEN: "request TK21" (construction to level 1), "request TK51" (demolition; revokes this
 *   workflow's TK21), "request TK11" (deposit search with the bound geologist). A definition that names anything else is
 *   refused by validate()/register(): a player can only request, never send a game action.
 *   SAFETY stays in the action, not in the rule (ADR 0085 point 3): "request TK51" itself checks the three locks of ADR 0084
 *   point 6 (own TK21, basic mine, level <= 1) whatever the IF says; control's demolish safeguard is the next lock.
 * 0.1.0 (2026-11-18, ADR 0084): Deposit Cycling in code (R-WF-DC-BUILD / -DEMO / -SEARCH), allocation, ownsGeo / ownsGrid.
 *
 *   Reads green's interface (facts / live) and the location manager's stock picture (DMA_Demo.stockNow); does not scan
 *   (ADR 0040); sends only through control (ADR 0073); ticked by the agents' cycle after the deposit search manager.
 *   GLOBAL: DMA_Workflows = { version, ready, check, tick, assess, list, definitions, vocabulary, validate, register,
 *   config, ownsGeo, ownsGrid, basicMines, allocated, last, resources }.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js, tests/unit/dma-workflows-grammar.test.js.
 *   Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 */
(function (root) {
    "use strict";
    var VERSION = "0.2.7";
    var RESOURCES = ["BronzeOre", "IronOre", "GoldOre", "Coal", "TitaniumOre", "Salpeter"];

    /* ---------- the built-in definitions: data, in the action-rule form (ADR 0085) ---------- */
    var DEFINITIONS = [{
        id: "deposit-cycling", label: "Deposit Cycling", by: "Zingu",
        per: { name: "R", values: RESOURCES },
        on: "rule:workflow.dc.$R.on",
        start: "rule:workflow.dc.$R.start",
        facts: {
            spots: { kind: "spots", resource: "$R", grids: "rule:workflow.dc.$R.grids" },
            geos: { kind: "geologists", types: "rule:workflow.dc.$R.geoTypes", count: "rule:workflow.dc.$R.geoCount", allocate: true }
        },
        rules: [
            { id: "R-WF-DC-DEMO", when: { event: "building on spot", of: "spots" },
              assess: [{ cond: "built by this workflow" }, { cond: "basic mine", resource: "$R" }, { cond: "level at most", level: 1 }, { cond: "construction finished" }, { cond: "no open transaction", tk: "TK51" }],
              then: { request: "TK51", actor: "construction manager" } },
            { id: "R-WF-DC-CLEAR", when: { event: "building on spot", of: "spots" },
              assess: [{ cond: "player's mine" }, { cond: "start now", start: "rule:workflow.dc.$R.start" }, { cond: "basic mine", resource: "$R" }, { cond: "no open transaction", tk: "TK51" }],
              then: { request: "TK51", actor: "construction manager", clear: true, start: "rule:workflow.dc.$R.start" } },
            { id: "R-WF-DC-BUILD", when: { event: "deposit on spot", of: "spots" },
              assess: [{ cond: "no open transaction", tk: "TK21" }, { cond: "deposit gone after our demolition" }, { cond: "build queue keeps free", places: "rule:workflow.dc.$R.keepFree" },
                   { cond: "stock above reserve", resource: "$R", on: "rule:workflow.dc.$R.reserve.on", reserve: "rule:workflow.dc.$R.reserve" }],
              then: { request: "TK21", actor: "construction manager", resource: "$R" } },
            { id: "R-WF-DC-SEARCH", when: { event: "spot empty", of: "spots" },
              assess: [{ cond: "no search under way", resource: "$R" }, { cond: "a spot is free when the search ends", resource: "$R" }, { cond: "allocated geologist idle", of: "geos" }],
              then: { request: "TK11", actor: "deposit search manager", resource: "$R" } }
        ]
    }];
    var defs = DEFINITIONS.slice();

    var last = [], ready = false, alloc = {}, allocSig = {};
    var ours = {}, deferred = {}, demolishedAt = {}, stopped = {};   // deferred: "<workflow>|<grid>" of a TK21 promised for later (0.2.5)   // "<workflow>|<grid>" -> { at } of a TK21 this workflow requested on a bare deposit

    function G() { return root.DMA_Green || null; }
    function ctrl() { return root.DMA_Control || null; }
    function cmem() { return root.DMA_Tx || null; }
    function polGet(k, d) {
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {}
        return d;
    }
    function note(s) {
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
            if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200);
        } catch (_) {}
    }
    function record(kind, data) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {} }
    function list(v) {
        if (v == null || v === "") return [];
        if (typeof v === "string") v = v.split(",");
        var out = [], i; for (i = 0; i < v.length; i++) { var s = String(v[i] == null ? "" : v[i]).trim(); if (s && out.indexOf(s) < 0) out.push(s); }
        return out;
    }
    /* a parameter: a literal, or "rule:<policy key>" read from the player policy; "$R" is the instance value */
    function val(x, inst, dflt) {
        if (typeof x === "string") {
            var s = inst ? x.split("$" + inst.name).join(inst.value) : x;
            if (s.indexOf("rule:") === 0) return polGet(s.slice(5), dflt);
            return s;
        }
        return x == null ? dflt : x;
    }

    /* ---------- instances: one per value of "per" ---------- */
    function instances() {
        var out = [];
        defs.forEach(function (d) {
            var vals = d.per && d.per.values ? d.per.values : [""];
            vals.forEach(function (v) { out.push({ def: d, name: d.per ? d.per.name : "", value: v, key: d.id + (v ? "|" + v : "") }); });
        });
        return out;
    }
    function isOn(inst) { return val(inst.def.on, inst, false) === true; }
    function spotsOf(inst) { var w = inst.def.facts && inst.def.facts.spots; return w ? list(val(w.grids, inst, [])) : []; }
    function config(r) {   // the Deposit Cycling settings of a resource, as the console shows them
        var k = function (x) { return "workflow.dc." + r + "." + x; };
        return {
            resource: r, on: polGet(k("on"), false) === true, grids: list(polGet(k("grids"), [])), geoTypes: list(polGet(k("geoTypes"), [])),
            geoCount: Math.max(0, Number(polGet(k("geoCount"), 0)) || 0), keepFree: Math.max(0, Number(polGet(k("keepFree"), 1)) || 0),
            reserveOn: polGet(k("reserve.on"), true) !== false, reserve: Math.max(0, Number(polGet(k("reserve"), 1000)) || 0), start: polGet(k("start"), "empty") === "now" ? "now" : "empty"
        };
    }

    /* ---------- facts ---------- */
    function slotAt(grid) {
        var g = G(), s = []; try { s = g && typeof g.facts === "function" ? g.facts() || [] : []; } catch (_) { s = []; }
        for (var i = 0; i < s.length; i++) if (String(s[i].grid) === String(grid)) return s[i];
        return null;
    }
    function live(grid) { var g = G(); try { return g && typeof g.live === "function" ? g.live(grid) : null; } catch (_) { return null; } }
    function basicMines(r) {   // the verified basic mine names of a resource (control's list; demolish not forbidden)
        var c = ctrl(), k = {}, out = [], n; try { k = c && typeof c.kinds === "function" ? c.kinds() || {} : {}; } catch (_) { k = {}; }
        for (n in k) if (k.hasOwnProperty(n) && k[n] && k[n].resource === r && k[n].demolish !== false && /Mine$/.test(n)) out.push(n);
        return out;
    }
    function stock(name) {
        try { var D = root.DMA_Demo, s = D && typeof D.stockNow === "function" ? D.stockNow() : null; if (s && s[name] != null) return Number(s[name]) || 0; } catch (_) {}
        return null;
    }
    function geologists() { try { var c = ctrl(); return (c && c.geologists && c.geologists()) || []; } catch (_) { return []; } }

    /* ---------- WITH: allocation of geologists (ADR 0084 point 4) ---------- */
    function allocate() {
        var geos = geologists(), next = {}, by = {};
        instances().forEach(function (inst) {
            var w = inst.def.facts && inst.def.facts.geos;
            if (!w || !w.allocate || !isOn(inst)) return;
            var types = list(val(w.types, inst, [])), count = Math.max(0, Number(val(w.count, inst, 0)) || 0);
            if (!types.length) { by[inst.key] = []; return; }
            var mine = geos.filter(function (g) { return g && g.id != null && types.indexOf(String(g.typeId)) >= 0 && !next[String(g.id)]; })
                           .sort(function (a, b) { return String(a.id) < String(b.id) ? -1 : 1; });
            if (count > 0) mine = mine.slice(0, count);
            by[inst.key] = mine.map(function (g) { return String(g.id); });
            mine.forEach(function (g) { next[String(g.id)] = inst.key; });
        });
        alloc = next;
        instances().forEach(function (inst) {
            var sig = (by[inst.key] || []).join(",");
            if (sig !== (allocSig[inst.key] || "")) {
                allocSig[inst.key] = sig;
                record("p", { fact: sig ? "geologists allocated to workflow" : "geologists released by workflow", workflow: inst.def.id, resource: inst.value || null, geologists: sig, actor: "stock of specialists (allocation)" });
            }
        });
        return by;
    }
    function ownsGeo(id) { return id != null && !!alloc[String(id)]; }
    /* a picked spot is the workflow's when it is on and, with start "empty", once the player's mine there is gone (0.2.1): until then the
       spot stays a production spot, so the construction manager keeps buffing, upgrading and demolishing that mine as always */
    function playerMineOn(inst, grid) { var lv = live(grid); return !!(lv && lv.name && !ours[inst.def.id + "|" + grid]); }
    function ownsGrid(grid) {
        var all = instances(), i, inst;
        for (i = 0; i < all.length; i++) {
            inst = all[i];
            if (!isOn(inst) || spotsOf(inst).indexOf(String(grid)) < 0) continue;
            if (inst.def.start != null && val(inst.def.start, inst, "empty") !== "now" && playerMineOn(inst, grid)) continue;
            return inst.value || inst.def.id;
        }
        return "";
    }

    /* ---------- transactions ---------- */
    var declinedAt = {};   // 0.2.7: "<workflow>|<grid>" -> when the game refused this workflow's last TK21
    function lostOrder(t, e) {   // promised by the game (not deferred), older than LOST_MS, no building on the spot, not in the build queue
        if (!t || t.state !== "promised" || (t.data && t.data.deferred === true) || !(api.LOST_MS > 0)) return false;
        if (e.lv && e.lv.name) return false;
        var at = Number(t.at || t.since || 0); if (!at || Date.now() - at < api.LOST_MS) return false;
        var q = null, cc = ctrl(); try { q = cc && typeof cc.queueNow === "function" ? cc.queueNow() : null; } catch (_) { q = null; }
        if (!q || (q.grids && q.grids[String(e.grid)])) return false;   // cannot read the queue, or it is queued: not lost
        return true;
    }
    function openTx(tk, k) { var M = cmem(); if (!M) return null; try { return M.inProgress(tk, k) || null; } catch (_) { return null; } }
    var counts = {}, since = Date.now();   // 0.2.4: per "<workflow>|<resource>" since the client started
    function count(x, what) { var k = x.workflow + "|" + x.resource, c0 = counts[k] = counts[k] || { cycles: 0, cleared: 0, builds: 0, searches: 0, lastAt: 0, last: "" }; c0[what] += 1; c0.lastAt = Date.now(); c0.last = what + (x.grid ? " @" + x.grid : ""); }
    function act(tk, a, extra) { var o = { tk: tk, act: a }, k; for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k]; record("c", o); }
    function rebuildOurs() {   // after a restart: the open TK21 "<grid>@1" requests carry their workflow
        var M = cmem(); if (!M || typeof M.list !== "function") return;
        try { M.list({ tk: "TK21", open: true }).forEach(function (t) {
            if (!(t.data && t.data.workflow && /@1$/.test(String(t.key)) && M.inProgress("TK21", t.key))) return;   // 0.2.4: in progress only
            var g = String(t.key).split("@")[0], k = t.data.workflow + "|" + g, lv = live(g);
            if (t.data.deferred === true && !(lv && lv.name)) { deferred[k] = true; return; }   // 0.2.5: promised for later, not built yet
            if (!ours[k]) ours[k] = { at: t.since };
        }); } catch (_) {}
    }
    function searchesOpen(wf, r) {
        var M = cmem(); if (!M || typeof M.list !== "function") return 0;
        try { return M.list({ tk: "TK11", open: true }).filter(function (t) { return t.data && t.data.workflow === wf && t.data.resource === r && t.state !== "declined"; }).length; } catch (_) { return 0; }
    }

    /* ---------- the vocabulary (ADR 0085): WHEN events, IF conditions, THEN requests ---------- */
    var EVENTS = {   // exactly one holds per spot
        "building on spot": function (e) { return !!(e.lv && e.lv.name); },
        "deposit on spot": function (e) { return !(e.lv && e.lv.name) && !!(e.slot && !e.slot.mine && !e.slot.depleted); },
        "spot empty": function (e) { var empty = !(e.lv && e.lv.name) && !(e.slot && !e.slot.mine && !e.slot.depleted); if (empty) { delete demolishedAt[e.wf + "|" + e.grid]; delete stopped[e.wf + "|" + e.grid]; } return empty; }
    };
    /* a condition answers "" when it holds, else the reason; it may bind a value to the row (e.bind) */
    var CONDITIONS = {
        "built by this workflow": function (e) { return ours[e.wf + "|" + e.grid] ? "" : "a building of the player stands here (" + e.lv.name + "): skipped"; },
        "player's mine": function (e) { return ours[e.wf + "|" + e.grid] ? "built by this workflow" : ""; },
        "start now": function (e, c) { return val(c.start, e.inst, "empty") === "now" ? "" : "the player's mine (" + e.lv.name + ") stays until it runs empty or is demolished (start: when empty or demolished)"; },
        "basic mine": function (e, c) { var r = val(c.resource, e.inst, ""); return basicMines(r).indexOf(String(e.lv.name)) >= 0 ? "" : "safeguard: not the basic mine of " + r + ": " + e.lv.name; },
        "construction finished": function (e) {   // 0.2.6: on the spot and no longer in the build queue
            var q = null, cc = ctrl(); try { q = cc && typeof cc.queueNow === "function" ? cc.queueNow() : null; } catch (_) { q = null; }
            if (q && q.grids && q.grids[String(e.grid)]) return "the mine is still being built (in the build queue)";
            return "";
        },
        "deposit gone after our demolition": function (e) {   // 0.2.6: loop guard
            var k = e.wf + "|" + e.grid, at = demolishedAt[k]; if (!at || !(api.GUARD_MS > 0)) return "";
            if (stopped[k]) return "stopped: the deposit stays after our demolition";
            var age = Date.now() - at;
            if (age < api.GUARD_MS) return "demolished " + Math.round(age / 1000) + " s ago; waiting for the deposit to vanish";
            if (age < 2 * api.GUARD_MS) return "";
            stopped[k] = true; record("p", { fact: "deposit stays after demolition", workflow: e.wf, grid: e.grid, resource: e.inst.value, seconds: Math.round(age / 1000) });
            return "stopped: the deposit stays after our demolition";
        },
        "level at most": function (e, c) { return Number(e.lv.level) > Number(c.level) ? "safeguard: level " + e.lv.level + " is above " + c.level : ""; },
        "no open transaction": function (e, c) {
            if (c.tk === "TK51") return openTx("TK51", String(e.grid)) ? "demolition under way" : "";
            if (c.tk === "TK21" && ours[e.wf + "|" + e.grid] && !openTx("TK21", e.grid + "@1") && !(e.lv && e.lv.name)) delete ours[e.wf + "|" + e.grid];   // 0.2.4: no longer in progress, nothing built: forget it
            if (c.tk === "TK21" && deferred[e.wf + "|" + e.grid] && openTx("TK21", e.grid + "@1")) { e.bind.deferred = true; return ""; }   // 0.2.5: send the promised order now
            if (c.tk === "TK21") {   // 0.2.7: an order the game took but never built is lost: the initiator revokes it and orders again
                var dk7 = e.wf + "|" + e.grid, t7 = openTx("TK21", e.grid + "@1");
                if (t7 && lostOrder(t7, e)) {
                    act("TK21", "revoke request", { workflow: e.wf, key: e.grid + "@1", grid: Number(e.grid), actor: "construction manager", reason: "the game took the order " + Math.round((Date.now() - Number(t7.at || t7.since)) / 60000) + " min ago but nothing is built or queued: the order is lost" });
                    act("TK21", "allow", { workflow: e.wf, key: e.grid + "@1", grid: Number(e.grid), actor: "game (tacit)" });
                    delete ours[dk7]; t7 = null;
                }
                if (ours[dk7] || t7) return "construction ordered; waiting for the site";
                var d7 = declinedAt[dk7]; if (d7 && Date.now() - d7 < api.RETRY_MS) return "the last order was refused " + Math.round((Date.now() - d7) / 1000) + " s ago; next try after " + Math.round(api.RETRY_MS / 60000) + " min";
                return "";
            }
            return "";
        },
        "no search under way": function (e, c) {
            var r = val(c.resource, e.inst, ""), k = e.inst.key;
            if (e.cycle.open[k] == null) e.cycle.open[k] = searchesOpen(e.wf, r);
            if (e.cycle.open[k] > 0) { e.cycle.open[k] -= 1; return "search under way"; }
            return "";
        },
        "a spot is free when the search ends": function (e, c) {
            var r = val(c.resource, e.inst, ""), k = "free|" + r;
            if (e.cycle.open[k] == null) e.cycle.open[k] = freeAtEnd(r);
            var f = e.cycle.open[k];
            if (typeof f === "string") return f;
            if (f < 1) return "no spot of " + r + " will be free when the search ends (the game would decline it)";
            e.cycle.open[k] = f - 1; return "";
        },
        "allocated geologist idle": function (e, c) {
            var w = e.inst.def.facts && e.inst.def.facts[c.of], mine = e.cycle.by[e.inst.key] || [];
            if (!w || !list(val(w.types, e.inst, [])).length) return "no geologist types selected";
            var used = e.cycle.usedGeo, idle = e.cycle.geos.filter(function (g) { return g && g.idle && mine.indexOf(String(g.id)) >= 0 && !used[String(g.id)]; });
            if (!idle.length) return "no allocated geologist idle (" + mine.length + " allocated)";
            used[String(idle[0].id)] = 1; e.bind.geo = String(idle[0].id); e.bind.geoName = idle[0].name;
            return "";
        },
        "build queue keeps free": function (e, c) {
            var keep = Math.max(0, Number(val(c.places, e.inst, 1)) || 0), free = e.cycle.free;
            if (free != null && free - 1 < keep) return "build queue: " + free + " free, " + keep + " kept for regular building";
            e.bind.takesQueue = true; return "";
        },
        "stock above reserve": function (e, c) {
            if (val(c.on, e.inst, true) === false) return "";
            var r = val(c.resource, e.inst, ""), reserve = Math.max(0, Number(val(c.reserve, e.inst, 0)) || 0), costs = {}, k, cc = ctrl();
            try { costs = cc && typeof cc.buildCosts === "function" ? cc.buildCosts(r) || {} : {}; } catch (_) { costs = {}; }
            for (k in costs) if (costs.hasOwnProperty(k)) { var have = stock(k); if (have != null && have - Number(costs[k]) < reserve) return "reserve: " + k + " " + have + " would fall below " + reserve; }
            return "";
        }
    };
    function freeAtEnd(r) {   // capacity - deposits now - searches out + leaving before the search ends; a string when it cannot be read
        var Gr = G(), q = null;
        try { if (Gr && typeof Gr.pictureOf === "function" && typeof Gr.facts === "function") q = (Gr.pictureOf(Gr.facts() || []) || {})[r] || null; } catch (_) { q = null; }
        if (!q || q.capacity == null) return "no picture of " + r + " to assess the search";
        var leaving = (q.due || []).length, M = cmem(), grids = {}, k;
        (q.mines || []).concat(q.free || []).forEach(function (s) { grids[String(s.grid)] = 1; });
        try { if (M && M.list) M.list({ tk: "TK51", open: true }).forEach(function (t) { if (t.state !== "declined" && grids[String(t.key)]) leaving += 1; }); } catch (_) {}
        for (k in ours) if (ours.hasOwnProperty(k)) { var g = k.split("|")[1]; if (grids[g] && !openTx("TK51", g)) leaving += 1; }   // the workflow's own sites go at once
        return Number(q.capacity) - Number(q.occupied || 0) - Number(q.open || 0) + leaving;
    }
    /* the requests: the only things a workflow can do. Each carries its own fixed safety. */
    var REQUESTS = {
        TK21: function (x, c) {
            var k21 = x.grid + "@1", out, dk = x.workflow + "|" + x.grid;
            if (x.deferred) {   // 0.2.5: the promise stands; only the execution is tried again
                if (!deferred[dk] || !openTx("TK21", k21)) return { ok: false, skipped: true, reason: "no deferred order" };
                out = c.sendBuild({ resourceType: x.resource, grid: Number(x.grid), workflow: x.workflow }, true);
                if (out && out.fact === "ex") { delete deferred[dk]; count(x, "builds"); ours[dk] = { at: Date.now() }; }
                else if (!(out && out.fact === "wait")) { delete deferred[dk]; act("TK21", "revoke request", { workflow: x.workflow, key: k21, grid: Number(x.grid), actor: x.actor, reason: "the deferred construction was refused: " + String((out && (out.reason || out.error)) || "refused") }); act("TK21", "allow", { workflow: x.workflow, key: k21, grid: Number(x.grid), actor: "game (tacit)" }); }
                return out;
            }
            if (openTx("TK21", k21)) return { ok: false, skipped: true, reason: "already under way" };   // 0.2.4
            act("TK21", "request", { workflow: x.workflow, key: k21, grid: Number(x.grid), to: 1, rule: x.rule, actor: x.actor, initiator: x.actor, resource: x.resource, reason: x.reason });
            out = c.sendBuild({ resourceType: x.resource, grid: Number(x.grid), workflow: x.workflow }, true);
            if (out && out.fact === "ex") { count(x, "builds"); ours[x.workflow + "|" + x.grid] = { at: Date.now() }; act("TK21", "promise", { workflow: x.workflow, key: k21, grid: Number(x.grid), actor: "game (order taken)", rule: x.rule }); }
            else if (out && out.fact === "wait") { deferred[dk] = true; act("TK21", "promise", { workflow: x.workflow, key: k21, grid: Number(x.grid), actor: "construction composer", rule: x.rule, deferred: true, reason: "planned: executed when " + String(out.reason || "control can take it") }); }   // 0.2.5: promised for later
            else { declinedAt[dk] = Date.now(); act("TK21", "decline", { workflow: x.workflow, key: k21, grid: Number(x.grid), actor: "game / blue", rule: x.rule, reason: String((out && (out.reason || out.error)) || "refused") }); }
            return out;
        },
        TK51: function (x, c) {
            if (openTx("TK51", String(x.grid))) return { ok: false, skipped: true, reason: "already under way" };   // 0.2.4: the same cycle or the follow-up took it
            if (x.wasOwn && !ours[x.workflow + "|" + x.grid]) return { ok: false, skipped: true, reason: "already demolished" };   // ours at the assessment, gone since
            var lv = live(x.grid), nm = lv ? String(lv.name || "") : "", why = "";   // the three locks of ADR 0084 point 6, whatever the rule said
            var own = !!ours[x.workflow + "|" + x.grid];
            if (!own && !(x.clear && x.start === "now")) why = "not built by this workflow";
            else if (basicMines(x.resource).indexOf(nm) < 0) why = "not the basic mine of " + x.resource + ": " + (nm || "?");
            else if (own && lv && Number(lv.level) > 1) why = "level " + lv.level + " is above 1";
            if (why) { note("workflow " + x.workflow + " SAFEGUARD refused demolish @" + x.grid + ": " + why); record("p", { fact: "safeguard refused", kind: "workflow demolish", why: why, grid: x.grid, workflow: x.workflow }); return { ok: false, reason: why }; }
            act("TK51", "request", { workflow: x.workflow, grid: Number(x.grid), rule: x.rule, actor: x.actor, initiator: x.actor, name: nm, reason: x.reason });
            var out = c.sendDemolish(Number(x.grid), { name: nm });
            if (out && out.ok) {
                act("TK51", "promise", { workflow: x.workflow, grid: Number(x.grid), actor: "game (order taken)", name: nm });
                count(x, own ? "cycles" : "cleared"); demolishedAt[x.workflow + "|" + x.grid] = Date.now();
                var k = x.grid + "@1";
                if (openTx("TK21", k)) { act("TK21", "revoke request", { workflow: x.workflow, key: k, grid: Number(x.grid), actor: x.actor, reason: "the mine is demolished, the construction is no longer wanted" }); act("TK21", "allow", { workflow: x.workflow, key: k, grid: Number(x.grid), actor: "game (tacit)" }); }
                delete ours[x.workflow + "|" + x.grid];
            } else act("TK51", "decline", { workflow: x.workflow, grid: Number(x.grid), actor: "game / blue", reason: String((out && (out.reason || out.error)) || "refused") });
            return out;
        },
        TK11: function (x, c) {
            if (!x.geo || !ownsGeo(x.geo)) return { ok: false, reason: "no allocated geologist bound" };   // only a geologist this workflow holds
            var sid = x.resource + "#wf#" + Date.now() + "#" + x.geo;
            var out = c.sendSearch(x.resource, true, { replacement: true, geoId: x.geo, workflow: x.workflow });
            act("TK11", "request", { workflow: x.workflow, search: sid, actor: x.actor, initiator: x.actor, rule: x.rule, resource: x.resource, geo: x.geo, geoName: x.geoName, reason: x.reason });
            if (!(out && out.ok)) act("TK11", "decline", { workflow: x.workflow, search: sid, actor: "game / blue", resource: x.resource, reason: String((out && (out.error || out.reason)) || "refused") });
            else { count(x, "searches"); if (typeof c.verifySearch === "function") c.verifySearch(x.resource, out.geo || x.geo, out.geoName || x.geoName, sid); }
            return out;
        }
    };
    var ACTORS = { TK21: "construction manager", TK51: "construction manager", TK11: "deposit search manager" };   // the existing initiators
    var WITH_KINDS = { spots: 1, geologists: 1 };

    /* ---------- validate / register: a player definition may only use the vocabulary ---------- */
    function validate(d) {
        var errs = [];
        if (!d || typeof d !== "object") return ["not a definition"];
        if (!d.id || !/^[a-z0-9-]+$/.test(String(d.id))) errs.push("id: lower-case letters, digits and dashes");
        if (d.on == null) errs.push("on: a switch (a literal or rule:<key>)");
        var w = d.facts || {}, n; for (n in w) if (w.hasOwnProperty(n) && !WITH_KINDS[w[n] && w[n].kind]) errs.push("facts." + n + ": unknown kind " + (w[n] && w[n].kind));
        if (!d.rules || !d.rules.length) errs.push("rules: at least one");
        (d.rules || []).forEach(function (r, i) {
            var at = "rules[" + i + "] " + (r && r.id || "");
            if (!r || !r.id) errs.push(at + ": id");
            if (!r || !r.when || !EVENTS[r.when.event]) errs.push(at + ": unknown WHEN " + (r && r.when && r.when.event));
            if (r && r.when && (!w[r.when.of] || w[r.when.of].kind !== "spots")) errs.push(at + ": WHEN must name a spots selection");
            (r && r.assess || []).forEach(function (c) { if (!c || !CONDITIONS[c.cond]) errs.push(at + ": unknown IF " + (c && c.cond)); if (c && c.of && !w[c.of]) errs.push(at + ": IF names an unknown selection " + c.of); });
            if (!r || !r.then || !REQUESTS[r.then.request]) errs.push(at + ": THEN must request one of " + Object.keys(REQUESTS).join(", ") + " (got " + (r && r.then && (r.then.request || JSON.stringify(r.then))) + ")");
            else if (r.then.actor && r.then.actor !== ACTORS[r.then.request]) errs.push(at + ": " + r.then.request + " is requested by the " + ACTORS[r.then.request]);
            if (r && r.then && r.then.request === "TK11" && !(r.assess || []).some(function (c) { return c && c.cond === "allocated geologist idle"; })) errs.push(at + ": a search needs the IF \"allocated geologist idle\"");
        });
        return errs;
    }
    function register(d) {
        var errs = validate(d);
        if (errs.length) return { ok: false, errors: errs };
        var copy = JSON.parse(JSON.stringify(d));
        defs = defs.filter(function (x) { return x.id !== copy.id || DEFINITIONS.indexOf(x) >= 0; });
        if (defs.some(function (x) { return x.id === copy.id; })) return { ok: false, errors: ["id " + copy.id + " is built in"] };
        defs.push(copy);
        record("p", { fact: "workflow registered", workflow: copy.id, rules: copy.rules.length });
        return { ok: true, id: copy.id };
    }

    /* ---------- assess: for each instance that is on, each spot, the rule whose WHEN holds ---------- */
    function assess() {
        var rows = [], by = allocate(), c = ctrl(), q = null;
        rebuildOurs();
        try { q = c && typeof c.queueNow === "function" ? c.queueNow() : null; } catch (_) { q = null; }
        var cycle = { by: by, geos: geologists(), usedGeo: {}, open: {}, free: q && q.free != null ? Number(q.free) : null };
        instances().forEach(function (inst) {
            if (!isOn(inst)) return;
            var d = inst.def, r = inst.value, grids = spotsOf(inst);
            if (!grids.length) { rows.push({ rule: d.id, ars: "-", fact: "dc", resource: r, grid: "", reason: "no spots selected", workflow: d.id }); return; }
            grids.forEach(function (grid) {
                var e = { inst: inst, wf: d.id, grid: String(grid), slot: slotAt(grid), lv: live(grid), cycle: cycle, bind: {} };
                d.rules.forEach(function (rule) {
                    if (!EVENTS[rule.when.event](e)) return;
                    var why = "", i;
                    for (i = 0; i < (rule.assess || []).length && !why; i++) why = CONDITIONS[rule.assess[i].cond](e, rule.assess[i]) || "";
                    var x = { rule: rule.id, ars: rule.then.request, fact: why ? "dc" : "pm", resource: val(rule.then.resource, inst, r) || r, grid: String(grid), workflow: d.id,
                              actor: ACTORS[rule.then.request], reason: why || rule.when.event };
                    if (rule.then.clear) { x.clear = true; x.start = val(rule.then.start, inst, "empty"); }
                    if (rule.then.request === "TK51") x.wasOwn = !!ours[d.id + "|" + grid];
                    if (!why && e.bind.deferred) { x.deferred = true; x.reason = "promised earlier: the order goes now"; }
                    if (!why) { if (e.bind.takesQueue && cycle.free != null) cycle.free -= 1; if (e.bind.geo) { x.geo = e.bind.geo; x.geoName = e.bind.geoName; } }
                    rows.push(x);
                });
            });
        });
        last = rows;
        rows.forEach(function (x) { note("workflow " + x.workflow + " [" + x.rule + "] " + x.resource + " " + (x.grid || "") + " " + x.fact + " " + x.reason); });
        return rows;
    }
    var FOLLOW_MS = 12000, following = false, followAt = 0, followPending = false;
    function later(fn, ms) { return api.later(fn, ms); }
    function startAfterOthers() {   // after the construction manager's and the deposit search manager's own send sequences
        var t = 0;
        try { var CM = root.DMA_ConstructionManager; if (CM && CM.ready && typeof CM.sendingMs === "function") t = Math.max(t, Number(CM.sendingMs()) || 0); } catch (_) {}
        try { var DS = root.DMA_DepositSearchManager; if (DS && DS.ready && typeof DS.sendingMs === "function") t = Math.max(t, Number(DS.sendingMs()) || 0); } catch (_) {}
        return t;
    }
    function execute(rows, isFollow) {
        var c = ctrl(); if (!c) return;
        var jobs = (rows || last).filter(function (x) { return x.fact === "pm" && REQUESTS[x.ars]; });
        if (!jobs.length) return;
        var gap = Math.max(1100, Number(polGet("control.sendIntervalMs", 1500)) || 1500), start = isFollow ? 0 : startAfterOthers(), moved = false, n = 0;
        jobs.forEach(function (x, k) {
            later(function () {
                var out = null;
                try { out = REQUESTS[x.ars](x, c); } catch (e) { note("workflow " + x.workflow + " send err " + e); }
                if (out && (out.ok || out.fact === "ex") && (x.ars === "TK21" || x.ars === "TK51")) moved = true;
                n += 1;
                if (n === jobs.length && moved && !isFollow) follow();
            }, start + k * gap);
        });
    }
    function follow(n) {   // the site, the emptied spot or the left deposit is handled without waiting for the next cycle
        n = n || 0; if (!n && (following || followPending)) return;   // 0.2.6: one pending follow-up at a time
        followAt = Date.now(); followPending = true;
        later(function () {
            followPending = false;
            if (following) return; following = true; var again = false;
            try { if (check()) { var r = assess(); execute(r, true); note("workflows follow-up: " + r.filter(function (x) { return x.fact === "pm"; }).length + " request(s)");
                again = r.some(function (x) { return /still being built/.test(x.reason || ""); }); } }   // 0.2.6: look again in 5 s, at most 10 minutes
            catch (e) { note("workflows follow-up err " + e); }
            following = false;
            if (again && n < 120) follow(n + 1);
        }, n ? 5000 : FOLLOW_MS);
    }
    function tick() {
        try { if (!check()) return []; var r = assess(); execute(r); return r; }
        catch (e) { note("workflows tick err " + (e && e.message ? e.message : e)); return []; }
    }
    function check() {
        var g = G(), c = ctrl(), ok = false;
        try { ok = !!(g && typeof g.facts === "function" && typeof g.live === "function" && c && typeof c.sendBuild === "function" && typeof c.sendDemolish === "function" &&
                      typeof c.sendSearch === "function" && typeof c.kinds === "function" && typeof c.geologists === "function"); } catch (_) { ok = false; }
        ready = ok; api.ready = ok; return ok;
    }
    var api = {
        version: VERSION, ready: false, GUARD_MS: 60000, LOST_MS: 720000, RETRY_MS: 300000, check: check, tick: tick, later: function (fn, ms) { return setTimeout(fn, ms); }, assess: assess, resources: RESOURCES.slice(),
        list: function () { return defs.map(function (d) { return { id: d.id, label: d.label, by: d.by, resources: d.per ? d.per.values.slice() : [], configs: d.id === "deposit-cycling" ? RESOURCES.map(config) : [] }; }); },
        definitions: function () { return JSON.parse(JSON.stringify(defs)); },
        vocabulary: function () { return { when: Object.keys(EVENTS), assess: Object.keys(CONDITIONS), then: Object.keys(REQUESTS).map(function (t) { return t + " (" + ACTORS[t] + ")"; }), facts: Object.keys(WITH_KINDS) }; },
        validate: validate, register: register,
        config: config, ownsGeo: ownsGeo, ownsGrid: ownsGrid, basicMines: basicMines,
        allocated: function () { var o = {}, k; for (k in alloc) if (alloc.hasOwnProperty(k)) o[k] = alloc[k]; return o; },
        last: function () { return last.slice(); },
        stats: function (wf, r) {   // 0.2.4: counters since the client started, searches out now, allocated geologists
            var c0 = counts[wf + "|" + r] || { cycles: 0, cleared: 0, builds: 0, searches: 0, lastAt: 0, last: "" }, out = {}, k;
            for (k in c0) if (c0.hasOwnProperty(k)) out[k] = c0[k];
            out.since = since; out.out = 0; out.allocated = 0;
            try { var M = cmem(); if (M && M.list) out.out = M.list({ tk: "TK11", open: true }).filter(function (t) { return t.data && t.data.workflow === wf && t.data.resource === r && M.inProgress("TK11", t.key); }).length; } catch (_) {}
            for (k in alloc) if (alloc.hasOwnProperty(k) && alloc[k] === wf + "|" + r) out.allocated += 1;
            return out;
        }
    };
    root.DMA_Workflows = api;
    check();
    note("workflows " + VERSION + " loaded, ready=" + api.ready);
})(typeof window !== "undefined" ? window : this);
