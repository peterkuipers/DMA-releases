/*
 * DMA heartbeat 0.1.1 — the freeze check, as a module.
 * 0.1.1 (2026-10-30, ADR 0030): no heartbeat file write while a visit hold is on.
 *
 * Author, 2026-10-27: "restore everything step by step and test that it all works as it should; above all the freeze
 * must never happen again." This module acts on nothing. It only measures, so that every restore step can be judged
 * against the same numbers.
 *
 * Every 60 s it appends one line to dma-heartbeat-YYYY-MM-DD.jsonl next to the client:
 *   t      ISO time
 *   inst   a random id per script load (two different ids in the same minute = two client instances)
 *   home   on the home island (game.gi.isOnHomzone)
 *   memMB / privMB   Flash heap / process memory (System.totalMemory / privateMemory)
 *   lagMax / lagSum  ms: how late a 1 s timer fired, worst and summed over the minute (UI-thread stalls; a freeze
 *                    shows as a large lagMax or as a missing minute)
 *   stock  a checksum of a few store amounts (unchanged for a long time at home = stale client)
 *   mods   on the first line and every 30 min: the versions of the DMA modules that are loaded
 *
 * Unit expectation: one line per minute with the fields above; lag is measured from a 1 s timer.
 * Integration expectation: in the client, the file grows by ~1 line a minute; a frozen client leaves a gap.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.1";
    var inst = Math.random().toString(36).slice(2, 8);
    var lagMax = 0, lagSum = 0, last = Date.now(), lines = 0;
    function G() { try { return (typeof game !== "undefined") ? game : root.game; } catch (_) { return null; } }
    function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
    function append(o) {
        try {
            var A = airApi(); if (!A || !A.File) return;
            var f = new A.File(A.File.applicationDirectory.resolvePath("dma-heartbeat-" + o.t.slice(0, 10) + ".jsonl").nativePath);
            var st = new A.FileStream(); st.open(f, A.FileMode.APPEND); st.writeUTFBytes(JSON.stringify(o) + "\n"); st.close();
        } catch (_) {}
    }
    function mods() {
        var out = {};
        ["DMA_Control", "DMA_Demo", "DMA_Green", "DMA_Chat", "DMA_Mail", "DMA_Trade", "DMA_Quest", "DMA_Help", "DMA_Console", "GCAF_PlayerPolicy"].forEach(function (n) {
            try { var m = root[n]; if (m) out[n] = String(m.version || m.VERSION || "?"); } catch (_) {}
        });
        return out;
    }
    function stockSum() {
        try {
            var g = G(), bag = g && g.getResources && g.getResources(); if (!bag || !bag.GetResourceAmount) return null;
            var s = 0; ["Stone", "Plank", "Tool", "Coal", "Iron", "Gold", "Bread", "Sausage"].forEach(function (r) { try { s += Number(bag.GetResourceAmount(r)) || 0; } catch (_) {} });
            return s;
        } catch (_) { return null; }
    }
    function visitHold() { try { var C = root.DMA_Control; return !!(C && C.visit && C.visit.held()); } catch (_) { return false; } }   // 0.1.1 (ADR 0030)
    function beat() {
        if (visitHold()) return;
        var o = { t: new Date().toISOString(), inst: inst, v: VERSION, lagMax: lagMax, lagSum: lagSum };
        try { var gm = G(), g = gm && gm.gi; if (g && typeof g.isOnHomzone === "function") o.home = !!g.isOnHomzone(); } catch (_) {}
        try { var Sy = root.runtime && root.runtime.flash && root.runtime.flash.system && root.runtime.flash.system.System;
              if (Sy) { o.memMB = Math.round(Number(Sy.totalMemory) / 1048576); if (Sy.privateMemory != null) o.privMB = Math.round(Number(Sy.privateMemory) / 1048576); } } catch (_) {}
        o.stock = stockSum();
        if (lines % 30 === 0) o.mods = mods();
        lines += 1; lagMax = 0; lagSum = 0;
        append(o);
    }
    function tick() {
        var now = Date.now(), late = now - last - 1000;
        if (late > 0) { lagSum += late; if (late > lagMax) lagMax = late; }
        last = now;
    }
    root.DMA_Heartbeat = { version: VERSION, inst: inst, beat: beat, tick: tick };
    try { if (typeof setInterval === "function") { setInterval(tick, 1000); setInterval(beat, 60000); } } catch (_) {}
})(typeof window !== "undefined" ? window : this);
