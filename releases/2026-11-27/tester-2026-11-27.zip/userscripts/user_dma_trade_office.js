/*
 * 0.1.5 (2026-11-18, ADR 0083 addendum): the never-pay list and the market-price ratio are rules the player switches on
 *   or off (supply.office.neverPay.on, supply.office.minMarketRatio.on, both default on); with the ratio rule off the
 *   price is not checked (an offer with a known price still ranks before one without). The never-pay list is a set.
 *   Unit: tests/unit/dma-trade-office.test.js (rule off: the never-pay resource and a ratio below 1.5 are accepted).
 *   Integration: tests/integration/dma-supply-rules-flow.test.js.
 * DMA Trade office buyer 0.1.4 — the means "a purchase at the trade office" of the resource supply manager (AR66), ADR 0075 R-2 / R-4. It is the buyer of a TK25 whose set is PURCHASE, market "trade office".

 * 0.1.4 (2026-11-16, ADR 0076, author "Ja" to the market-price proposal; he judged own-cost-favourable oil offers not favourable: "olie is onbetaalbaar"): the buyer judges an offer by the MARKET price, not by the own-cost value list.
 *   (1) offers() feeds every read of the panel to DMA_Market.observe(list, now) when that module is loaded (ADR 0040: the keeper does not scan; the buyer, which reads the panel anyway, feeds it).
 *   (2) quote(resource, amount) now picks, among the offers of another player that sell the resource, the one with the best market ratio (market value of what we get / market value of what we pay, DMA_Market.ratio),
 *       and only an offer for which ALL hold: ratio >= policy supply.office.minMarketRatio (default 1.5); the paid resource is not in policy supply.office.neverPay (default "Oilseed, Oil"); the stock holds the
 *       pay amount; and paying leaves the stock of the paid resource at or above what is reserved for it (DMA_SupplyManager.needs(), when loaded) plus policy supply.office.keepPayStock (default 0).
 *       No market price for either side (DMA_Market missing, or fewer than 3 offers behind a price) = not quoted. The own-cost value list (DMA_Value) is no longer used here; it stays for deciding what to make.
 *       The quote carries its ratio. buy() and buyId() are unchanged.
 *   Unit: tests/unit/dma-trade-office.test.js (quote: best market ratio wins; ratio below 1.5, a neverPay resource, a stock that cannot pay, a reserved or kept stock and an unknown price are each refused; offers() feeds the keeper).
 *   Integration: tests/integration/dma-trade-office-buy.test.js (real policy, keeper, buyer and supply manager: only an offer at least 1.5 times better at the market price is bought; oil and oilseed are never paid).
 *
 * 0.1.3 (2026-11-16, live test of buyId 43198303): offers() read only the first 200 items of the panel's vector, while the live panel holds 456 and the chosen offer sat at
 *   position 420+, so buyId answered "not found in the loaded Trade Office list". offers() now reads every item, up to MAX_ITEMS 2000. Nothing else changes.
 *   Unit: tests/unit/dma-trade-office.test.js (an item at position 450 of a 460-item vector is found by buyId). Integration: tests/integration/dma-trade-office-buy.test.js (unchanged flow).
 * 0.1.2 (2026-11-16, coordinator: live findings of probe 0.2.3). The panel's items are ServerState::cTradeObject { tradeID, senderID, senderName, slotPos, slotType, totalLots, remainingLots (-1 = unknown),
 *   isAffordable, offer: dResourceVO {name_string, amount} or dBuffVO {buffName_string, resourceName_string, amount}, costs: dResourceVO }. normalise follows it: id = tradeID, offer/costs from the VOs, lots =
 *   totalLots, lotsRemaining = remainingLots, or totalLots when -1; an offer that is a dBuffVO with a buffName is a buff (never quoted). The old dTradeOfferVO reading stays as a fallback.
 *   The accept message (dAcceptTradeVO { senderID, offer, uniqueID, id, slotPos, slotType, costs }) is built from the live item: id = tradeID, senderID, slotPos, slotType, offer = item.offer, costs = item.costs;
 *   uniqueID is left unset. Sent through the adapter as ACCEPT_TRADE_MARKET, only when dma-trade-office-confirmed.json says confirmed.
 *   One-shot test command: file dma-trade-office-cmd.json { act: "buyId", tradeID } (read every 5 s, marked done when read): with the confirm file present and the item in the loaded Trade Office list, not own and
 *   affordable, sends ONE accept and appends to dma-trade-office.jsonl the result and the stock of the offered and the paid resource before and 10 s after; refuses (and writes why) otherwise.
 *   Unit: tests/unit/dma-trade-office.test.js (cTradeObject items; accept VO fields; buyId refusals and one accept). Integration: tests/integration/dma-trade-office-buy.test.js (supply manager buys; accept carries tradeID).
 * 0.1.1 (2026-11-16, coordinator: the live probe 0.2.0 showed the panel's items carry a Communication.VO::dBuffVO { resourceName_string, buffName_string, amount } in "offer", not a dTradeOfferVO). normalise reads
 *   the offered item from offerRes, or else from the dBuffVO itself (resourceName_string, amount; buffName_string marks it a buff and so never bought), and the price from costsRes / costs / price on the offer
 *   or on the item; a field not found stays null, and a quote needs both sides, so an item whose price is not found is never chosen. Still inert until dma-trade-office-confirmed.json; the exact price field
 *   follows the probe 0.2.1 "offers-shape" output.
 *   Unit: tests/unit/dma-trade-office.test.js (dBuffVO-shaped item is a buff and is not quoted; price aliases). Integration: tests/integration/dma-trade-office-buy.test.js (unchanged flow).
 * 0.1.0 (2026-11-16, ADR 0075 follow-up, coordinator batch item 3.6 "trade-office probe, then buyer"): NEW.
 *   READS the market offers of the Trade Office panel (the player's own UI picture; the probe tool user_dma_probe_trade.js 0.2.0 "offers" lists the same members): globalFlash.gui members whose name has
 *   "trade", their mAvailableOfferVector / mOffersOnDisplay / tradeObjects, each item a dTradeObjectVO { offer: dTradeOfferVO { offerRes, costsRes, lots, slotType }, senderID, lotsRemaining, remainingTime }.
 *   quote(resource, amount) -> { offerId, lots, perLot, pay: { resource, amount } } or null: the offer of another player that sells the resource, with lots remaining, that we can pay from the stock the agents
 *     remember (DMA_Demo.stockNow()), the cheapest by own-cost value (DMA_Value) of what we pay; a buff offer or an offer in a resource without a value is never chosen.
 *   buy(resource, amount, quote) -> { ok, caseId, sent } : accepts the offer lot by lot (at most 10 lots) with the registered ACCEPT_TRADE_MARKET (1051) message through the Game Interface Adapter (ADR 0073),
 *     dAcceptTradeVO { uniqueID: the offer's id, costs: the offer's costs }. INERT until the author's client has confirmed the field names: the file dma-trade-office-confirmed.json { "confirmed": true } (written
 *     after the probe output of "offers" and "accept" has been read) must exist; without it buy() refuses with the reason and sends nothing. The supply manager only calls buy() after its own favourable-in-value test.
 *   The module does not scan on a timer (ADR 0040: it reads the panel when asked) and starts nothing by itself.
 *   GLOBAL: DMA_TradeOffice = { version, owner "trade office buyer", ready, check, offers, quote, buy, confirmed }.
 *   Unit: tests/unit/dma-trade-office.test.js (offers read and normalised; quote picks the cheapest affordable offer of another player; buy refused until confirmed, then one accept per lot with the offer's id).
 *   Integration: tests/integration/dma-trade-office-buy.test.js (real policy, transactions, agents, adapter, supply manager and buyer: the supply manager buys after 30 minutes and the 1051 message reaches the game).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.5", MAX_ITEMS = 2000, CONFIRM = "dma-trade-office-confirmed.json", MAX_LOTS = 10, OUT = "dma-trade-office.jsonl", CMD = "dma-trade-office-cmd.json";
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function G() { try { return (typeof game !== "undefined") ? game : root.game; } catch (_) { return root.game || null; } }
    function readJson(name) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new A.FileStream(); st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function rd(o, k) { try { return o[k]; } catch (_) { return undefined; } }
    function memberNames(o) {
        try { var x = String(root.runtime.flash.utils.describeType(o)), re = /<(?:variable|accessor)\s+name="([^"]+)"/g, m, out = []; while ((m = re.exec(x)) !== null && out.length < 300) out.push(m[1]); return out; } catch (_) { return Object.keys(o || {}); }
    }
    function resOf(x) {
        if (x == null) return null;
        var n = rd(x, "name_string"); if (n == null) n = rd(x, "resourceName_string"); if (n == null) n = rd(x, "name");
        var a = rd(x, "amount"); if (a == null) a = rd(x, "value");
        if (n == null && typeof x === "string") n = x;
        return n == null ? null : [String(n), a == null ? null : Number(a)];
    }
    function first(o, ks) { var i, v; for (i = 0; i < ks.length; i++) { v = rd(o, ks[i]); if (v != null) return v; } return null; }
    function buffOf(x) { var b = x == null ? null : rd(x, "buffName_string"); return b != null && b !== "" ? String(b) : null; }
    function num(v) { return v != null && v !== "" && !isNaN(Number(v)) ? Number(v) : null; }
    function normalise(t, myId) {
        var of = rd(t, "offer") || t, live = rd(t, "tradeID") != null, gives = live ? rd(t, "offer") : (rd(of, "offerRes") || (buffOf(of) != null || rd(of, "resourceName_string") != null ? of : null)),
            pays = live ? rd(t, "costs") : (first(of, ["costsRes", "costs", "price"]) || first(t, ["costsRes", "costs", "price"]));
        var total = live ? num(rd(t, "totalLots")) : num(rd(of, "lots")), rem = num(rd(t, live ? "remainingLots" : "lotsRemaining"));
        var o = { id: live ? String(rd(t, "tradeID")) : (rd(t, "uniqueID") != null ? String(rd(t, "uniqueID")) : (rd(t, "slotPos") != null ? "slot" + rd(t, "slotPos") : null)), sender: num(rd(t, "senderID")),
                  senderName: rd(t, "senderName") != null ? String(rd(t, "senderName")) : null, slotPos: num(rd(t, "slotPos")), slotType: num(rd(t, "slotType")), affordable: rd(t, "isAffordable") == null ? null : !!rd(t, "isAffordable"),
                  offer: resOf(gives), costs: resOf(pays), buff: !!(rd(of, "offerBuff") || rd(of, "costsBuff") || buffOf(gives) || buffOf(pays)),
                  lots: total, lotsRemaining: live ? (rem != null && rem >= 0 ? rem : total) : rem, remainingTime: num(rd(t, "remainingTime")), _raw: t };
        o.own = myId != null && o.sender != null && Number(o.sender) === Number(myId);
        return o;
    }
    function offers() {
        var out = [], gui = null, g = G();
        try { gui = root.globalFlash && root.globalFlash.gui; } catch (_) {}
        var myId = null; try { myId = g.gi.mCurrentPlayer.GetPlayerId(); } catch (_) {}
        if (!gui) return out;
        memberNames(gui).filter(function (n) { return /trade/i.test(n); }).forEach(function (n) {
            var p = rd(gui, n); if (!p || out.length) return;
            ["mAvailableOfferVector", "mOffersOnDisplay", "tradeObjects"].forEach(function (k) {
                var v = rd(p, k); if (v == null || out.length) return;
                try { if (typeof v.toArray === "function") v = v.toArray(); else if (v.source && v.source.length != null) v = v.source; } catch (_) {}
                var i, len = 0; try { len = Number(v.length) || 0; } catch (_) {}
                for (i = 0; i < len && i < MAX_ITEMS; i++) { try { out.push(normalise(v[i], myId)); } catch (_) {} }
            });
        });
        try { if (out.length && root.DMA_Market && typeof root.DMA_Market.observe === "function") root.DMA_Market.observe(out, Date.now()); } catch (_) {}   // 0.1.4: the keeper learns from every read
        return out;
    }
    function stock() { try { return (root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow()) || {}; } catch (_) { return {}; } }
    function pol(k, d) {
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {}
        return d;
    }
    function polNum(k, d) { var v = Number(pol(k, d)); return isNaN(v) ? d : v; }
    function ruleOn(k) { var v = pol(k, true); return !(v === false || String(v) === "false"); }   // 0.1.5
    function neverPay() {   // 0.1.4: a list (array or comma-separated text); compared without case
        if (!ruleOn("supply.office.neverPay.on")) return [];   // 0.1.5: the player switched the rule off
        var v = pol("supply.office.neverPay", ["Oilseed", "Oil"]); if (typeof v === "string") v = v.split(",");
        return (v || []).map(function (x) { return String(x).trim().toLowerCase(); }).filter(Boolean);
    }
    function reserved(res) { try { var S = root.DMA_SupplyManager, n = S && typeof S.needs === "function" && S.needs(); return n && n[res] ? Number(n[res].amount) || 0 : 0; } catch (_) { return 0; } }
    function quote(resource, amount) {
        amount = Math.ceil(Number(amount) || 0); if (!(amount > 0)) return null;
        var st = stock(), best = null, M = root.DMA_Market, minRatio = polNum("supply.office.minMarketRatio", 1.5), checkRatio = ruleOn("supply.office.minMarketRatio.on"), never = neverPay(), keep = polNum("supply.office.keepPayStock", 0);
        if (!M || typeof M.ratio !== "function") return null;
        offers().forEach(function (o) {
            if (o.own || o.buff || !o.offer || !o.costs || o.offer[0] !== resource || !(o.offer[1] > 0) || !(o.costs[1] > 0) || !(o.lotsRemaining > 0) || !o.id) return;
            var lots = Math.min(MAX_LOTS, Math.ceil(amount / o.offer[1])); if (lots > o.lotsRemaining) return;
            var payRes = o.costs[0], pay = o.costs[1] * lots, have = Number(st[payRes] || 0);
            if (never.indexOf(String(payRes).toLowerCase()) >= 0) return;                         // never paid with (oil, oilseed)
            var ratio = M.ratio(resource, o.offer[1] * lots, payRes, pay);
            if (checkRatio && (ratio == null || !(ratio >= minRatio))) return;   // unknown price, or not clearly better than the market
            if (ratio == null) ratio = -1;   // 0.1.5: the ratio rule is off: a known price still ranks first
            if (have < pay || have - pay < reserved(payRes) + keep) return;                       // we do not have it, or it is reserved / kept
            if (!best || ratio > best.ratio) best = { offerId: o.id, lots: lots, perLot: o.offer[1], pay: { resource: payRes, amount: pay }, ratio: ratio, _o: o };
        });
        if (!best) return null;
        var q = { offerId: best.offerId, lots: best.lots, perLot: best.perLot, pay: best.pay, ratio: best.ratio }; Object.defineProperty(q, "_o", { value: best._o, enumerable: false }); return q;
    }
    function confirmed() { var c = readJson(CONFIRM); return !!(c && c.confirmed === true); }
    function acceptVo(Def, o) {   // dAcceptTradeVO from the live item; uniqueID stays unset
        var vo = new Def(), t = o._raw;
        if (rd(t, "tradeID") != null) { vo.id = Number(rd(t, "tradeID")); vo.senderID = Number(rd(t, "senderID") || 0); vo.slotPos = Number(rd(t, "slotPos") || 0); vo.slotType = Number(rd(t, "slotType") || 0); vo.offer = rd(t, "offer"); vo.costs = rd(t, "costs"); }
        else { vo.uniqueID = o.id; vo.costs = rd(rd(t, "offer") || t, "costsRes"); }
        return vo;
    }
    function buy(resource, amount, q) {
        if (!confirmed()) return { ok: false, reason: "the accept message is not confirmed yet (" + CONFIRM + ")" };
        q = q || quote(resource, amount); if (!q || !q._o) return { ok: false, reason: "no offer" };
        var A = root.GCAF_GameInterface, Def = null; try { Def = root.swmmo.getDefinitionByName("Communication.VO::dAcceptTradeVO"); } catch (_) {}
        if (!A || typeof A.sendMessage !== "function") return { ok: false, reason: "the game interface adapter is not loaded" };
        if (!Def) return { ok: false, reason: "dAcceptTradeVO is not known to the client" };
        var sent = 0, i, last = null;
        for (i = 0; i < q.lots; i++) {
            var vo = acceptVo(Def, q._o);
            last = A.sendMessage("ACCEPT_TRADE_MARKET", vo, null, null);
            if (!last || last.ok !== true) break; sent += 1;
        }
        return sent > 0 ? { ok: true, sent: sent, caseId: "purchase@" + resource + "@" + q.offerId + "@" + Date.now() } : { ok: false, reason: (last && last.reason) || "refused" };
    }
    function append(row) { try { var A = air_(), st = new A.FileStream(); row.t = new Date().toISOString(); row.v = VERSION; st.open(new A.File(A.File.applicationDirectory.resolvePath(OUT).nativePath), A.FileMode.APPEND); st.writeUTFBytes(JSON.stringify(row) + "\n"); st.close(); } catch (_) {} }
    function snap(names) { var st = stock(), o = {}; names.forEach(function (n) { o[n] = st[n] != null ? st[n] : null; }); return o; }
    function buyId(tradeID) {   // one test purchase of one lot of the listed offer; every refusal is written
        var id = String(tradeID), row = { act: "buyId", tradeID: id };
        function no(why) { row.ok = false; row.reason = why; append(row); return row; }
        if (!confirmed()) return no("not confirmed (" + CONFIRM + ")");
        var o = null; offers().forEach(function (x) { if (x.id === id) o = x; });
        if (!o) return no("not found in the loaded Trade Office list");
        if (o.own) return no("own offer"); if (o.affordable === false) return no("not affordable"); if (!o.offer || !o.costs) return no("offer or costs not readable");
        var nm = [o.offer[0], o.costs[0]], before = snap(nm), r = buy(o.offer[0], o.offer[1], { offerId: o.id, lots: 1, perLot: o.offer[1], pay: { resource: o.costs[0], amount: o.costs[1] }, _o: o });
        row.ok = !!r.ok; row.reason = r.reason || null; row.sent = r.sent || 0; row.offer = o.offer; row.costs = o.costs; row.before = before; append(row);
        if (r.ok) { try { setTimeout(function () { append({ act: "buyId-after", tradeID: id, stock: snap(nm), before: before }); }, 10000); } catch (_) {} }
        return row;
    }
    function tick() {
        var c = readJson(CMD); if (!c || c.done) return;
        c.done = true; c.doneAt = new Date().toISOString();
        try { var A = air_(), st = new A.FileStream(); st.open(new A.File(A.File.applicationDirectory.resolvePath(CMD).nativePath), A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(c)); st.close(); } catch (_) {}
        try { if (c.act === "buyId" && c.tradeID != null) buyId(c.tradeID); } catch (e) { append({ act: c.act, error: String(e).slice(0, 200) }); }
    }
    function check() { var ok = false; try { ok = !!(root.GCAF_GameInterface && typeof root.GCAF_GameInterface.sendMessage === "function"); } catch (_) {} api.ready = ok; return ok; }
    var api = { version: VERSION, owner: "trade office buyer", ready: false, check: check, offers: offers, quote: quote, buy: buy, confirmed: confirmed, buyId: buyId };
    root.DMA_TradeOffice = api; check();
    try { setInterval(tick, 5000); } catch (_) {}
})(typeof window !== "undefined" ? window : this);
