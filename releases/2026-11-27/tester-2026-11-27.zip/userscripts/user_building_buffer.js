// Building buffer 0.1.2
//
// 0.1.2 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C7 of the migration): the module no longer
//   calls game.gi.SendServerAction and no longer opens control's permit (0.1.0's permit("buff") calls are gone). send() calls
//   GCAF_GameInterface.sendAction("APPLY_BUFF", 0, grid, 0, uniqueId, { stack }): the adapter's guard (a verified kind, any other
//   kind only if the game's own check accepts the stack, never a tribute, never a buffed building), holds and pace decide; its
//   refusal is the skipped reason shown after the counts ("the client refused the send" is replaced by the adapter's reason; no
//   adapter loaded = "game interface adapter not loaded"). The module's own reads (ELS-32 by grid, IsApplyable) stay: the
//   executor checks its truth clauses when it acts. Nothing else changes.
//   Unit: tests/unit/building-buffer-els32.test.js (an adapter refusal is the skipped reason, nothing sent). Integration:
//   tests/integration/building-buffer-with-control.test.js (real control + adapter; the free building gets its buff through the
//   adapter, the permit is closed again).
// 0.1.1 (2026-11-16, architect verdict on PR #382): tributes (*_Mini) are refused like the buff manager does
//   (user_dma_buff_manager.js: /_Mini$/i -> "tribute: <name>"): right before the send, a building whose name read by grid
//   ends in _Mini is skipped with the reason "tribute: <name>" and nothing is sent; the window no longer lists them
//   (they are left out like residences). Nothing else changes.
//   Unit: tests/unit/building-buffer-els32.test.js (a tribute is refused, nothing sent). Integration:
//   tests/integration/building-buffer-with-control.test.js (with the real control, a tribute chosen in the window gets
//   nothing through control's wrapper; the free building still gets its buff).
// 0.1.0 (2026-11-16, backbone v3.16, ADR 0071 D-4: ELS-32 "[buff] is applied implies that not [buff] meets a running
//   buff" = ADR 0067 "never buff a buffed building"; reconciliation R-12; review T3: the module had no VERSION): the first
//   versioned build. Changes, all in the apply step:
//   (1) ELS-32 at the act: right before each send the building is read again BY GRID from the game
//       (GetBuildingFromGridPosition), not from the list built when the window opened; a production buff on it -> the
//       building is skipped with the reason "already buffed: <name of the running buff>" (ADR 0067); no building there ->
//       "no building"; a building that cannot be read -> "building not readable" (fail closed). The game's own
//       IsApplyable check stays after it.
//   (2) Control's SendServerAction wrapper passes action 61 only while permit("buff") is open (the same gap the tester
//       found for premium): the send is wrapped in DMA_Control.permit("buff", true/false) when control is loaded, and a
//       send the client refuses (false) is counted as skipped "the client refused the send", not as applied.
//   (3) onDone(applied, skipped, reasons) — the reasons per skipped building, shown after the counts.
//   VERSION and an internal test hook (BuildingBuffer._t) are exported. The window and its choices are unchanged.
//   Unit: tests/unit/building-buffer-els32.test.js. Integration: tests/integration/building-buffer-with-control.test.js.
//
// Lists your production buildings on your home island that are not buffed yet,
// suggests the best buff per building based on the buffs (and amounts) in your
// star menu, lets you change the choice per building and applies all at once.
//
// Suggestion: buildings are handled from highest to lowest level; each gets the
// strongest buff it can take that is still available. Strength = production
// bonus (%) × duration, so the most extra production per buff comes first.
// Population buildings (residences) are left out. A toggle (on by default)
// keeps Bag of Rainbow Snow for endless mines only.

var BuildingBuffer = (function () {
    var VERSION = "0.1.2";
    var SCRIPT_CONST = {
        PREFIX: 'BBF',
        APPLY_DELAY: 1000,
        APPLY_BUFF: 61,             // COMMAND.APPLY_BUFF
        BUFF_TYPE_TIMED: 0,         // Enums.BUFF_TYPE.TIMED (production buffs)
        TARGET_BUILDING: 0,         // Enums.BUFF_TARGET_TYPE.BUILDING
        APPLIANCE_PLAYER: 0,        // Enums.BUFF_APPLIANCE_MODE.PLAYER
        EXCLUDED: ['Area'],         // area buffs hit several buildings at once, leave them out
        RESIDENCE_UI: 'residence',  // building UI type of population buildings
        RAINBOW_SNOW: 'ProductivityBuffLvl12',  // Bag of Rainbow Snow
        ENDLESS_MARK: 'Endless',    // endless mines, e.g. BronzeMineEndless
        SETTINGS_KEY: 'BBF_SETTINGS'
    };

    var settingsState = {
        rainbowOnlyEndless: true    // Bag of Rainbow Snow only on endless mines
    };

    var TXT = {
        title:        'Building buffer',
        building:     'Building',
        level:        'Level',
        buff:         'Buff',
        none:         '- none -',
        noBuff:       'No suitable buff in star menu',
        buffsTitle:   'Buffs in star menu',
        available:    'Available',
        assigned:     'Assigned',
        bonus:        'Bonus',
        duration:     'Duration',
        overAssigned: 'You assigned more buffs than you have. Change the selection first.',
        nothing:      'All production buildings are buffed.',
        notHome:      'This only works on your home island.',
        noneSelected: 'No buffs are selected.',
        suggest:      'Suggest',
        clear:        'Clear all',
        refresh:      'Refresh',
        apply:        'Apply all',
        applying:     'Applying: {0} / {1}',
        done:         'Done: {0} buff(s) applied, {1} skipped.',
        summary:      '{0} unbuffed building(s), {1} with a buff selected.',
        goTo:         'Click to go to this building',
        rainbowOnly:  'Use Bag of Rainbow Snow only on endless mines'
    };

    var ids = {
        modal:     SCRIPT_CONST.PREFIX + '_Modal',
        buffs:     SCRIPT_CONST.PREFIX + '_Buffs',
        list:      SCRIPT_CONST.PREFIX + '_List',
        status:    SCRIPT_CONST.PREFIX + '_Status',
        suggest:   SCRIPT_CONST.PREFIX + '_SuggestBtn',
        clear:     SCRIPT_CONST.PREFIX + '_ClearBtn',
        refresh:   SCRIPT_CONST.PREFIX + '_RefreshBtn',
        applyBtn:  SCRIPT_CONST.PREFIX + '_ApplyBtn',
        rainbow:   SCRIPT_CONST.PREFIX + '_RainbowChk',
        tooltip:   SCRIPT_CONST.PREFIX + '_Tooltip'
    };

    var isRunning = false;
    var buffGroups = [];    // { key, name, description, icon, percent, duration, score, stacks: [cBuff], available }
    var buildings  = [];    // { building, grid, name, level, options: [groupIdx], choice: groupIdx | -1 }

    // ─── Settings ─────────────────────────────────────────────────────────────

    function loadSettings() {
        try { $.extend(settingsState, settings.read(null, SCRIPT_CONST.SETTINGS_KEY)); } catch (e) { debug(e); }
    }

    function saveSettings() {
        try {
            settings.settings[SCRIPT_CONST.SETTINGS_KEY] = {};
            settings.store(settingsState, SCRIPT_CONST.SETTINGS_KEY);
        } catch (e) { debug(e); }
    }

    // ─── Game Data ────────────────────────────────────────────────────────────

    function isTribute(name) { return /_Mini$/i.test(String(name || "")); }   // 0.1.1: as the buff manager (tributes are not buffed)
    function isResidence(bui) {
        try {
            if (bui.GetGOContainer().ui == SCRIPT_CONST.RESIDENCE_UI) return true;
        } catch (e) {}
        return bui.GetBuildingName_string().indexOf('Residence') !== -1;
    }

    function isEndlessMine(buiName) {
        return buiName.indexOf(SCRIPT_CONST.ENDLESS_MARK) !== -1;
    }

    // Buff rules on top of the game's own check
    function isAllowedOn(group, buiName) {
        if (settingsState.rainbowOnlyEndless && group.defName === SCRIPT_CONST.RAINBOW_SNOW) {
            return isEndlessMine(buiName);
        }
        return true;
    }

    function isExcluded(buff) {
        var keys = [buff.GetBuffDefinition().GetName_string(), buff.GetType()].join('|');
        for (var i = 0; i < SCRIPT_CONST.EXCLUDED.length; i++) {
            if (keys.indexOf(SCRIPT_CONST.EXCLUDED[i]) !== -1) return true;
        }
        return false;
    }

    function locaText(group, key, params) {
        try { if (loca.exist(group, key)) return loca.GetText(group, key, params); } catch (e) {}
        return '';
    }

    function getBuffName(buff) {
        var defName = buff.GetBuffDefinition().GetName_string();
        return locaText('RES', defName) || loca.getLabel(defName, [buff.GetAmount(), buff.GetResourceName_string()]);
    }

    function getBuffDescription(buff) {
        var defName = buff.GetBuffDefinition().GetName_string();
        return locaText('DES', defName, [buff.GetAmount().toString(), buff.GetResourceName_string()]);
    }

    // Single-target production buffs from the star menu, grouped per buff type
    function loadBuffGroups() {
        var groups = {};
        game.gi.mCurrentPlayer.getBuffsSortedForStarMenu().forEach(function (buff) {
            try {
                if (buff.IsExhausted || buff.GetWaitingForServer()) return;
                var def = buff.GetBuffDefinition();
                if (def.GetBuffType() != SCRIPT_CONST.BUFF_TYPE_TIMED) return;
                if (def.GetTargetType() != SCRIPT_CONST.TARGET_BUILDING) return;
                if (isExcluded(buff)) return;

                var key = def.GetName_string() + '|' + buff.GetResourceName_string();
                if (!groups[key]) {
                    var percent  = def.getProductivityOutputPercent() || 0;
                    var duration = def.getDuration(SCRIPT_CONST.APPLIANCE_PLAYER) || 0;
                    groups[key] = {
                        key:         key,
                        defName:     def.GetName_string(),
                        name:        getBuffName(buff),
                        description: getBuffDescription(buff),
                        icon:        buff.GetBuffIconData(),
                        percent:     percent,
                        duration:    duration,
                        score:       Math.max(percent, 1) * Math.max(duration, 1),
                        stacks:      [],
                        available:   0
                    };
                }
                groups[key].stacks.push(buff);
                groups[key].available += buff.GetAmount();
            } catch (e) { debug(e); }
        });

        return Object.keys(groups).map(function (k) { return groups[k]; })
            .sort(function (a, b) { return b.score - a.score || a.name.localeCompare(b.name); });
    }

    // Same check the game does when you drop a buff on a building
    function canApply(buff, building) {
        try {
            var result = buff.IsApplyable(game.gi.mCurrentPlayer, game.gi, building.GetGrid());
            return result !== null && typeof result === 'object';
        } catch (e) { return false; }
    }

    function loadBuildings() {
        var myId = game.gi.mCurrentPlayer.GetPlayerId();
        var list = [];
        game.gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector().forEach(function (bui) {
            try {
                if (bui == null || bui.getPlayerID() != myId) return;
                if (bui.productionBuff != null) return;         // already buffed
                if (isResidence(bui)) return;                   // population buildings are left out

                var name = bui.GetBuildingName_string();
                if (isTribute(name)) return;                    // 0.1.1: tributes (*_Mini) are left out
                var options = [];
                buffGroups.forEach(function (group, idx) {
                    if (isAllowedOn(group, name) && canApply(group.stacks[0], bui)) options.push(idx);
                });
                // Show production buildings even without a fitting buff; others only if a buff fits
                if (!options.length && bui.GetResourceCreation() == null) return;

                list.push({
                    building: bui,
                    grid:     bui.GetGrid(),
                    buiName:  name,
                    name:     loca.GetText('BUI', name),
                    level:    bui.GetUpgradeLevel(),
                    options:  options,
                    choice:   -1
                });
            } catch (e) { debug(e); }
        });

        return list.sort(function (a, b) {
            return a.name.localeCompare(b.name) || b.level - a.level;
        });
    }

    // ─── Suggestion ───────────────────────────────────────────────────────────

    function suggest() {
        var left = buffGroups.map(function (g) { return g.available; });
        buildings.forEach(function (b) { b.choice = -1; });

        buildings.slice()
            .sort(function (a, b) { return b.level - a.level; })
            .forEach(function (b) {
                // options are already ordered from strongest to weakest buff
                for (var i = 0; i < b.options.length; i++) {
                    var idx = b.options[i];
                    if (left[idx] > 0) {
                        b.choice = idx;
                        left[idx]--;
                        return;
                    }
                }
            });
    }

    function getAssignedCounts() {
        var counts = buffGroups.map(function () { return 0; });
        buildings.forEach(function (b) { if (b.choice >= 0) counts[b.choice]++; });
        return counts;
    }

    // ─── Applier ──────────────────────────────────────────────────────────────

    function takeStack(group, used) {
        for (var i = 0; i < group.stacks.length; i++) {
            var stack = group.stacks[i];
            if (!stack.IsExhausted && stack.GetAmount() - (used[i] || 0) > 0) {
                used[i] = (used[i] || 0) + 1;
                return stack;
            }
        }
        return null;
    }

    /* 0.1.0 (ELS-32 / ADR 0067): what the game shows on the grid right now; null = the buff may go */
    function buffRefusal(grid) {
        var b, pb;
        try { b = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(grid)); } catch (e) { return { why: "building not readable" }; }
        if (!b) return { why: "no building" };
        var nm = "";
        try { nm = typeof b.GetBuildingName_string === "function" ? String(b.GetBuildingName_string()) : ""; } catch (e) { return { why: "building not readable" }; }
        if (isTribute(nm)) return { why: "tribute: " + nm };   // 0.1.1: as the buff manager
        try { pb = b.productionBuff; } catch (e) { return { why: "building not readable" }; }
        if (pb != null) {
            var n = "";
            try { var d = (pb.GetBuffDefinition && pb.GetBuffDefinition()) || pb.buffDefinition; n = d && d.GetName_string ? String(d.GetName_string()) : ""; } catch (e) { n = ""; }
            return { why: "already buffed: " + (n || "a buff") };
        }
        return { building: b };
    }

    function send(grid, stack) {   // 0.1.2 (ADR 0073): the adapter owns the send; answers true or the reason it was refused
        var A = window.GCAF_GameInterface, r;
        if (!A) return "game interface adapter not loaded";
        r = A.sendAction("APPLY_BUFF", 0, Number(grid), 0, stack.GetUniqueId(), { stack: stack });
        return r && r.ok ? true : ((r && r.reason) || "no answer from the adapter");
    }

    function applyAll(onProgress, onDone) {
        var jobs = buildings.filter(function (b) { return b.choice >= 0; });
        var queue   = new TimedQueue(SCRIPT_CONST.APPLY_DELAY);
        var usedPerGroup = buffGroups.map(function () { return {}; });
        var done = 0, applied = 0, skipped = 0, reasons = [];

        jobs.forEach(function (job) {
            queue.add(function () {
                try {
                    var group = buffGroups[job.choice];
                    var at = buffRefusal(job.grid);             // 0.1.0: ELS-32, read again by grid right before sending
                    if (at.why) { skipped++; reasons.push({ grid: job.grid, name: job.name, why: at.why }); return; }
                    var stack = takeStack(group, usedPerGroup[job.choice]);
                    if (!stack) { skipped++; reasons.push({ grid: job.grid, name: job.name, why: "no buff left in the star" }); return; }
                    if (!canApply(stack, at.building)) { skipped++; reasons.push({ grid: job.grid, name: job.name, why: "the game does not accept this buff here" }); return; }
                    var sent = send(job.grid, stack);   // 0.1.2: true, or the adapter's reason
                    if (sent === true) applied++;
                    else { skipped++; reasons.push({ grid: job.grid, name: job.name, why: sent }); }
                } catch (e) {
                    debug(e);
                    skipped++; reasons.push({ grid: job.grid, name: job.name, why: "error: " + e });
                } finally {
                    done++;
                    onProgress(done, jobs.length);
                    if (done === jobs.length) onDone(applied, skipped, reasons);
                }
            });
        });

        if (queue.len() > 0) queue.run();
        else onDone(0, 0, []);
    }

    // ─── UI ───────────────────────────────────────────────────────────────────

    function formatDuration(ms) {
        if (!ms || ms <= 0) return '-';
        var minutes = Math.round(ms / 60000);
        var h = Math.floor(minutes / 60), m = minutes % 60;
        return h > 0 ? h + 'h' + (m ? ' ' + m + 'm' : '') : m + 'm';
    }

    function buffIcon(group) {
        try { return getImageByModule(group.icon[0], group.icon[1], 24, 24) + '&nbsp;'; } catch (e) { return ''; }
    }

    function renderBuffSummary() {
        var counts = getAssignedCounts();
        var over = false;
        var html = '<h5>' + TXT.buffsTitle + '</h5>' + createTableRow([
            [5, TXT.buff],
            [2, TXT.bonus],
            [2, TXT.duration],
            [1, TXT.available],
            [2, TXT.assigned]
        ], true);

        buffGroups.forEach(function (group, idx) {
            var tooMany = counts[idx] > group.available;
            if (tooMany) over = true;
            html += createTableRow([
                [5, '<span class="' + SCRIPT_CONST.PREFIX + '_buffName" data-idx="' + idx + '" style="cursor:help;">' +
                    buffIcon(group) + group.name + '</span>'],
                [2, group.percent ? '+' + group.percent + '%' : '-'],
                [2, formatDuration(group.duration)],
                [1, group.available],
                [2, counts[idx], tooMany ? 'buffNotReady' : '']
            ]);
        });

        $('#' + ids.buffs).html(buffGroups.length ? '<div class="container-fluid">' + html + '</div><br>' : '');

        var selected = buildings.filter(function (b) { return b.choice >= 0; }).length;
        var status = TXT.summary.format(buildings.length, selected);
        if (over) status += ' ' + TXT.overAssigned;
        $('#' + ids.status).text(status);
        $('#' + ids.applyBtn).prop('disabled', isRunning || over || selected === 0);
    }

    function renderBuildings() {
        var $list = $('#' + ids.list).empty();
        if (!buildings.length) {
            $list.html('<p class="text-center" style="padding:20px;">' + TXT.nothing + '</p>');
            return;
        }

        var html = createTableRow([
            [6, TXT.building],
            [1, TXT.level],
            [5, TXT.buff]
        ], true);

        buildings.forEach(function (b, bIdx) {
            var icon = '';
            try { icon = getImageTag(b.buiName, '24px') + '&nbsp;'; } catch (e) {}

            var select;
            if (!b.options.length) {
                select = '<small>' + TXT.noBuff + '</small>';
            } else {
                select = '<select class="form-control input-sm ' + SCRIPT_CONST.PREFIX + '_select" data-idx="' + bIdx + '">' +
                    '<option value="-1">' + TXT.none + '</option>';
                b.options.forEach(function (gIdx) {
                    var g = buffGroups[gIdx];
                    select += '<option value="' + gIdx + '"' + (b.choice === gIdx ? ' selected' : '') + '>' +
                        $('<div>').text(g.name).html() + ' (' + g.available + ')</option>';
                });
                select += '</select>';
            }

            html += createTableRow([
                [6, '<span class="' + SCRIPT_CONST.PREFIX + '_goto" data-grid="' + b.grid + '" title="' + TXT.goTo +
                    '" style="cursor:pointer;">' + icon + b.name + '</span>'],
                [1, b.level],
                [5, select]
            ]);
        });

        $list.html('<div class="container-fluid">' + html + '</div>');
    }

    function reload() {
        if (isRunning) return;
        hideTooltip();
        if (!game.gi.isOnHomzone()) {
            game.showAlert(TXT.notHome);
            return;
        }
        buffGroups = loadBuffGroups();
        buildings  = loadBuildings();
        suggest();
        renderBuildings();
        renderBuffSummary();
    }

    function setButtonsDisabled(disabled) {
        $('#' + ids.suggest + ', #' + ids.clear + ', #' + ids.refresh + ', #' + ids.applyBtn + ', #' + ids.rainbow).prop('disabled', disabled);
        $('.' + SCRIPT_CONST.PREFIX + '_select').prop('disabled', disabled);
    }

    function handleApply() {
        if (isRunning) return;
        if (!buildings.some(function (b) { return b.choice >= 0; })) {
            game.showAlert(TXT.noneSelected);
            return;
        }
        isRunning = true;
        setButtonsDisabled(true);

        applyAll(function (done, total) {
            $('#' + ids.status).text(TXT.applying.format(done, total));
        }, function (applied, skipped, reasons) {
            game.showAlert(TXT.done.format(applied, skipped) + ((reasons || []).length ? " — " + reasons.map(function (r) { return r.name + ": " + r.why; }).join("; ") : ""));   // 0.1.0
            // Give the server a moment before re-reading buildings and star menu
            setTimeout(function () {
                isRunning = false;
                setButtonsDisabled(false);
                reload();
            }, SCRIPT_CONST.APPLY_DELAY * 3);
        });
    }

    function handleSelectChange() {
        var b = buildings[parseInt($(this).attr('data-idx'), 10)];
        if (!b) return;
        b.choice = parseInt($(this).val(), 10);
        renderBuffSummary();
    }

    function handleGoTo() {
        try {
            $('#' + ids.modal).modal('hide');
            game.zone.ScrollToGrid(parseInt($(this).attr('data-grid'), 10));
        } catch (e) { debug(e); }
    }

    // ─── Tooltip ──────────────────────────────────────────────────────────────

    function escapeHtml(text) {
        return $('<div>').text(text).html().replace(/\r?\n/g, '<br>');
    }

    function getTooltip() {
        var $tip = $('#' + ids.tooltip);
        if (!$tip.length) {
            $tip = $('<div>', { id: ids.tooltip }).css({
                position:      'fixed',
                zIndex:        100000,
                maxWidth:      '320px',
                padding:       '8px 10px',
                background:    'rgba(20, 15, 5, 0.95)',
                border:        '1px solid #7a5c00',
                borderRadius:  '5px',
                color:         '#ffe082',
                fontSize:      '12px',
                pointerEvents: 'none'
            }).hide().appendTo('body');
        }
        return $tip;
    }

    function showTooltip(e) {
        var group = buffGroups[parseInt($(this).attr('data-idx'), 10)];
        if (!group) return;
        getTooltip()
            .html('<b>' + escapeHtml(group.name) + '</b>' +
                  (group.description ? '<br>' + escapeHtml(group.description) : ''))
            .show();
        moveTooltip(e);
    }

    function moveTooltip(e) {
        var $tip = getTooltip();
        var left = e.clientX + 15;
        var top  = e.clientY + 15;
        if (left + $tip.outerWidth() > $(window).width())   left = e.clientX - $tip.outerWidth() - 10;
        if (top + $tip.outerHeight() > $(window).height()) top  = e.clientY - $tip.outerHeight() - 10;
        $tip.css({ left: left, top: top });
    }

    function hideTooltip() {
        getTooltip().hide();
    }

    // ─── Bootstrap ────────────────────────────────────────────────────────────

    function openModal() {
        try {
            if (!game.gi.isOnHomzone()) {
                game.showAlert(TXT.notHome);
                return;
            }

            loadSettings();

            $("div[role='dialog']:not(#" + ids.modal + "):visible").modal('hide');
            $('#' + ids.modal).remove();
            createModalWindow(ids.modal, TXT.title);

            var $modal = $('#' + ids.modal);
            $modal.find('.modal-body').html(
                '<div class="checkbox" style="margin-top:0;"><label>' +
                    '<input type="checkbox" id="' + ids.rainbow + '"' + (settingsState.rainbowOnlyEndless ? ' checked' : '') + '> ' +
                    TXT.rainbowOnly + '</label></div>' +
                '<div id="' + ids.buffs + '"></div>' +
                '<p id="' + ids.status + '" class="text-center"></p>' +
                '<div id="' + ids.list + '"></div>'
            );
            $modal.find('.modal-footer').prepend([
                $('<button>', { id: ids.suggest, 'class': 'btn btn-primary pull-left' }).text(TXT.suggest),
                $('<button>', { id: ids.clear, 'class': 'btn btn-primary pull-left' }).text(TXT.clear),
                $('<button>', { id: ids.refresh, 'class': 'btn btn-primary pull-left' }).text(TXT.refresh),
                $('<button>', { id: ids.applyBtn, 'class': 'btn btn-success' }).text(TXT.apply)
            ]);

            $modal.off('click', '#' + ids.suggest).on('click', '#' + ids.suggest, function () {
                suggest(); renderBuildings(); renderBuffSummary();
            });
            $modal.off('click', '#' + ids.clear).on('click', '#' + ids.clear, function () {
                buildings.forEach(function (b) { b.choice = -1; });
                renderBuildings(); renderBuffSummary();
            });
            $modal.off('click', '#' + ids.refresh).on('click', '#' + ids.refresh, reload);
            $modal.off('change', '#' + ids.rainbow).on('change', '#' + ids.rainbow, function () {
                settingsState.rainbowOnlyEndless = $(this).is(':checked');
                saveSettings();
                reload();
            });
            $modal.off('click', '#' + ids.applyBtn).on('click', '#' + ids.applyBtn, handleApply);
            $modal.off('change', '.' + SCRIPT_CONST.PREFIX + '_select')
                .on('change', '.' + SCRIPT_CONST.PREFIX + '_select', handleSelectChange);
            $modal.off('click', '.' + SCRIPT_CONST.PREFIX + '_goto')
                .on('click', '.' + SCRIPT_CONST.PREFIX + '_goto', handleGoTo);

            var nameSel = '.' + SCRIPT_CONST.PREFIX + '_buffName';
            $modal.off('mouseenter mousemove mouseleave', nameSel)
                .on('mouseenter', nameSel, showTooltip)
                .on('mousemove',  nameSel, moveTooltip)
                .on('mouseleave', nameSel, hideTooltip);
            $modal.off('hidden.bs.modal', hideTooltip).on('hidden.bs.modal', hideTooltip);

            reload();
            $modal.not(':visible').modal({ backdrop: 'static' });
        } catch (e) {
            debug(e);
        }
    }

    function init() {
        try {
            window.OpenBuildingBufferModal = openModal;
            addToolsMenuItem(TXT.title, window.OpenBuildingBufferModal);
        } catch (e) {
            debug(e);
        }
    }

    return { version: VERSION, init: init, openModal: openModal,
             _t: { buffRefusal: buffRefusal, applyAll: applyAll, set: function (g, b) { buffGroups = g; buildings = b; } } };   // 0.1.0: test hook
})();

BuildingBuffer.init();
