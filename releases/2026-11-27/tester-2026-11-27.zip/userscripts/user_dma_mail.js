/*
 * DMA Mail manager 0.2.5 — actor role "mail manager" (switch Mail, policy mail.auto, default OFF).
 * 0.2.12 (2026-11-17, UAT 2026-11-17 finding F6, the live checker's I6: a TK61 mail round "promised" for 32 h): three ways in which a round could stay open in the book are closed. (1) the first step of a round ran outside
 *   any try/catch (startRound -> step): an exception there left `round` set with no timer and no end - the round "promised" for ever and no later round could start; it is now ended as an error. (2) a round that has run
 *   longer than its own limit (ROUND_MAX_MS 90 s) plus 30 s, because no step ran any more, is ended by the tick ("time limit"). (3) every tick, when no round runs, an open TK61 case of the book that is neither the
 *   running round nor a request still waiting for its round and whose last act is older than a round can last (a promised one: 2.5 min, a requested one: 10 min) is ended by its executor - revoke promise, allow
 *   (tacit), decline for a promised case, revoke request, allow for a requested one - with the reason; this also closes the cases a restart left behind when the "open" note of dma-mail-round.json (0.2.11) was never written
 *   or already gone. No game action, nothing is collected. Nothing else changes; the 0.2.11 note stays.
 *   Live check (CLAUDE.md: a change to how a kind ends updates its live checks in the same PR): tests/live/check_release_invariants.py I6 measures a declined or rejected case from its discussion start (discAt, transactions
 *   0.4.20) - an orphan round closed now is not 32 h old; the limits TK61 2 h and TK41 2 h stay. Unit/integration: tests/integration/live-limits-declined.test.js.
 *   Unit: tests/unit/dma-mail-orphan-round.test.js (an exception in the first step ends the round with a decline; a stuck round is ended by the tick; a promised case of no running round is revoked, allowed and declined
 *   once, a requested one is revoked; the running round and a waiting request are left alone). Integration: tests/integration/dma-mail-round.test.js (the whole round in the book) and
 *   tests/integration/dma-mail-orphan-in-book.test.js (a book restored with a promised round of 32 h ago: the first tick of the mail manager closes it and the live checker's I6 limit holds).
 * 0.2.11 (2026-11-09, author: "Ja" — repair what the TX page showed: TK61 round@1794113078218 promised since 2026-11-08
 *   04:44, cut off by a client restart): a round that starts writes its case to dma-mail-round.json ("open"); the end
 *   of the round removes it. At start, an "open" round left in that file (the client restarted during it) is ended in
 *   the book: revoke promise, allow (tacit), decline "the client restarted during the round".
 *   Unit: tests/unit/dma-mail-orphan.test.js; integration: live, after a restart during a mail round the TX page holds
 *   no TK61 of that round.
 * 0.2.10 (2026-11-09, live: Gunpowder loot stayed in the inbox): group "advloot" — the "Adventure … has ended" loot mails
 *   (MAIL_TYPE 19, control 0.2.89) — collected like the other loot; rule mail.loot.advloot (default on).
 *   Unit: tests/unit/dma-mail-advloot.test.js; integration: live, after a Gunpowder run the pumpkin fillers reach the star
 *   at the next round.
 * 0.2.9 (2026-11-02, live: the client did not load 0.2.8 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.2.8 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   TK61 records the full DEMO 4 pattern, one instance per ROUND (case round@start): request (the player, a schedule
 *   or another actor role: r.by; a player's "collect now" is the request of the round it starts) -> promise (mail
 *   manager, when the round starts) -> execute (mails collected) -> declare (the round ended) -> accept (the requester,
 *   tacit). A round that collected nothing because it could not do its work (refused, cannot open, no gateway, visit
 *   hold, away, error) is revoke promise + allow (tacit) + decline, with the reason (was a "decline" in the middle of a
 *   round that was then still declared). The collect refusal itself is information. Behaviour unchanged.
 *   Unit/integration expectation: dma-mail-manager / dma-mail-round tests; tests/unit/dma-demo4-acts.test.js.
 * 0.2.7 (2026-11-01, test day: 701 treasure mails waiting, yet every round collected one batch of 10): the pending mark of
 *   a batch made the next step of the same round linger and close. Within a round, the batch's mails are checked
 *   against the inbox: gone -> the mark is cleared and the next batch follows (max 10 batches); still there -> up to
 *   3 steps of waiting, then the round ends as before (the 0.2.2 breaker is unchanged across rounds and restarts).
 *   Unit/integration: dma-mail-manager.test.js (25 mails -> 3 batches in one round).
 * 0.2.6 (2026-10-30, live 0.2.5: a round every 10 s although mail.everyMin = 30): the AIR client's Date.parse does not read
 *   an ISO date, so the last round read as "never" and every tick was due. The last round now carries atMs (a number),
 *   and that is what due() reads. Unit expectation: a round 10 s ago is not due. Integration: dma-mail-manager.test.js.
 * 0.2.5 (2026-10-30, ADR 0030 addendum 4; author: "Het openen van de mail moet dus op een rustig moment gedaan worden, dat
 *   is de taak van de mail manager, het hoeft dus niet periodiek. Het kan ook adhoc. Houd bij wanneer de laatste keer is
 *   geweest en open op een rustig moment, doe wat je moet doen en sluit hem weer"; live: the game's mail window, opened
 *   by the scripts and never closed, took every input on the map): the mail manager is the only actor that opens the
 *   mail window, and it does so in a MAIL ROUND: open -> ask the inbox headers -> wait for them (max 8 s) -> collect the
 *   loot mails of the kinds switched on, 10 per batch, 3 s apart (max 10 batches) -> stay open a little longer when
 *   another actor asked (trade, help: 20 s) -> close. The round is a task for the BLUE MANAGER (DMA_Control.blue,
 *   author: "een blauwe manager die bijhoudt wat qua implementatie allemaal gedaan dient te worden ... en wanneer
 *   waarvoor tijd is"): the mail manager puts it on the blue task list, the blue manager starts it at a quiet moment
 *   (home, no hold, nothing queued, no server action for 20 s), and the round reports done when the window is closed.
 *   A round is asked for when it is due — mail.everyMin since the
 *   last round (switch on) — or asked for ad hoc: requestRound(by) by the gateway on behalf of trade / help, or the
 *   player's "collect now". Every round ends with the window closed, also when it is cut short (a hold, 90 s). The last
 *   round is kept in dma-mail-round.json (when, by, mails, kinds) and survives a restart.
 *   Unit expectation:        not quiet -> no round; quiet + due -> open, headers, collect, close; requestRound while off
 *                            -> a round at the next quiet moment; a hold during the round -> closed at once.
 *   Integration expectation: tests/integration/dma-mail-round.test.js.
 * 0.2.4 (2026-10-25, author: "when I go to another island the orders carry on; they must stop"): no tick while the
 *   player is on another island (DMA_Control.atHome() false); requests wait until he is home.
 *
 * 0.2.3 (2026-10-25, live: the client reloaded at 15:20 and the breaker did not trip — the AIR client's localStorage does
 *  not survive a restart): the pending collect is kept in the file dma-mail-pending.json.
 * 0.2.2 (2026-10-25, live: the client lost its server connection right after a collect): a collect is first written as
 *  "pending" (localStorage dma.mail.pending.v1). If the scripts start again within 5 minutes of a pending collect (the
 *  client reloads after a lost connection) or the same mails are still waiting two runs later, the mail manager
 *  SUSPENDS itself (status.suspended with the reason, a p-fact) instead of trying again every minute; the MAIL page
 *  shows it and "Resume" clears it. A collect that took effect clears the pending mark.
 * 0.2.1 (2026-10-25, author: "a button on the mail rules to run them once per line? and are there settings for the waiting
 *  time before it is emptied again, what is the situation now?"): the run interval is the policy rule mail.everyMin
 *  (default 1 minute; was fixed at 60 s); collectNow(kind) collects that kind once, now, whatever the switch and the
 *  tick say — the player's own act — in batches of up to 20 mails, 2 s apart, until none of that kind waits (max 10
 *  batches). Status carries nextRunAt.
 * 0.2.0 (2026-10-25, author: "it is part of mail automation; during an event you may have to save the loot, so you
 *  must be able to switch it off. One general switch and a separate page with settings based on facts"): renamed from
 *  the loot collector (file user_dma_loot.js -> user_dma_mail.js); one switch (mail.auto) for all mail handling; per
 *  kind of loot a rule (mail.loot.treasure / adventure / fragment / expedition) and the destination
 *  (mail.loot.toStorage), all set on the console's MAIL page, which shows the facts: waiting mails per kind,
 *  collected per kind, the last collection. Collecting is still the game's own collect, explorer loot only.
 *
 *
 * 0.1.0 (2026-10-25, author: "emptying the loot mails can be automated too? also with a switch"):
 *  every minute, while the switch is ON, the collector reads the inbox (control's trade gateway: the whole inbox via
 *  the mail view's pager) and collects the explorer loot mails — treasure, adventure and expedition finds — through
 *  control.collectLootMails, the game's own "collect" (DISMISS_MAILS with claim). Into the star menu, or into the
 *  storage when the policy rule loot.toStorage is true. No other mail is ever touched (control decides the types).
 *  Every collection is recorded as a fact (tk TK61, act execute) and written to dma-loot-status.json.
 *
 * DEMO: TK61 loot collecting — self-activated by the loot collector when the switch is on and loot mails exist;
 * executed by the game's collect; the stored loot is the product.
 */
(function (root) {
    "use strict";
    var VERSION = "0.2.12";
    var state = { startedAt: null, ticks: 0, collected: 0, runs: 0, last: null, lastError: "", switchedOn: false, waiting: 0, waitingBy: {}, collectedBy: {}, groups: {} };
    var timer = null;
    var TICK_MS = 10000;
    function runMs() { var p = pol(), v = 1; try { if (p) v = Number(p.get("mail.everyMin")) || 1; } catch (_) {} return Math.max(1, Math.min(1440, v)) * 60000; }   // 0.2.1

    function note(s) { state.lastError = String(s).slice(0, 300); }
    function pol() { try { var p = root.GCAF_PlayerPolicyInstance; return p && typeof p.get === "function" ? p : null; } catch (_) { return null; } }
    function on() { var p = pol(); try { return !!(p && p.get("mail.auto") === true); } catch (_) { return false; } }
    function toStorage() { var p = pol(); try { return !!(p && p.get("mail.loot.toStorage") === true); } catch (_) { return false; } }
    var GROUPS = ["treasure", "adventure", "fragment", "expedition", "advloot"];   // 0.2.10
    function groups() {
        var p = pol(), g = {};
        GROUPS.forEach(function (k) { var v = true; try { if (p) v = p.get("mail.loot." + k) !== false; } catch (_) {} g[k] = v; });
        return g;
    }
    function gw() { return root.DMA_Control && root.DMA_Control.trade; }
    /* 0.2.2: circuit breaker — never a disconnect loop */
    var PKEY = "dma.mail.pending.v1";
    function airF() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function fileRead(name) {
        try { var a = airF(); if (!a) return null; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function fileWrite(name, obj) {
        try { var a = airF(); if (!a) return false; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    function pending() {
        var f = fileRead("dma-mail-pending.json"); if (f && f.pending !== undefined) return f.pending;   // 0.2.3: the file first
        try { return JSON.parse(root.localStorage.getItem(PKEY) || "null"); } catch (_) { return null; }
    }
    function setPending(p) {
        fileWrite("dma-mail-pending.json", { format: "dma-mail-pending/1", pending: p || null });
        try { if (p) root.localStorage.setItem(PKEY, JSON.stringify(p)); else root.localStorage.removeItem ? root.localStorage.removeItem(PKEY) : root.localStorage.setItem(PKEY, "null"); } catch (_) {}
    }
    function suspend(why) {
        state.suspended = why; note("suspended: " + why); setPending(null);
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { tk: "TK61", fact: "mail manager suspended", reason: why }); } catch (_) {}
    }
    function checkPending(now, waitingNow) {
        var p = pending(); if (!p) return;
        if (now - p.at > 10 * 60000) { setPending(null); return; }
        var still = (p.ids || []).filter(function (id) { return (waitingNow || []).indexOf(id) >= 0; }).length;
        if (!still) { setPending(null); return; }                                  // it took effect
        p.checks = (p.checks || 0) + 1; setPending(p);
        if (p.checks >= 2) suspend("the same " + still + " mails were still waiting after a collect");
    }
    function record(act, data) {
        var o = { tk: "TK61", act: act, actor: "mail manager" }, k;
        if (round && round.caseId) o.caseId = round.caseId;            // 0.2.8: one instance per round
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function info(what, data) {                                 // 0.2.8: not a coordination act
        var o = { tk: "TK61", what: what, actor: "mail manager" }, k;
        if (round && round.caseId) o.caseId = round.caseId;
        for (k in data) if (data.hasOwnProperty(k)) o[k] = data[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", o); } catch (_) {}
    }
    function writeStatus(now) {
        try {
            var a = (typeof air !== "undefined") ? air : root.air; if (!a) return;
            var f = a.File.applicationDirectory.resolvePath("dma-mail-status.json"), file = new a.File(f.nativePath);
            var st = new a.FileStream(); st.open(file, a.FileMode.WRITE);
            st.writeUTFBytes(JSON.stringify({ format: "dma-mail-status/1", version: VERSION, at: new Date(now).toISOString(), state: state }, null, 1)); st.close();
        } catch (e) { note("status " + e); }
    }
    function away() { try { var C = root.DMA_Control; return !!(C && typeof C.atHome === "function" && !C.atHome()); } catch (_) { return false; } }   // 0.2.4
    function isQuiet() { try { var C = root.DMA_Control; return !!(C && typeof C.quiet === "function" && C.quiet()); } catch (_) { return false; } }   // 0.2.5
    /* 0.2.5: the mail round — open at a quiet moment, do the work, close */
    var STEP_MS = 3000, HEADERS_WAIT_MS = 8000, ROUND_MAX_MS = 90000, LINGER_MS = 20000, ROUND_FILE = "dma-mail-round.json";
    var round = null, asked = null, lastRound = null, askedCases = {};
    /* 0.2.12 (UAT 2026-11-17 F6): a TK61 case of a round that is not running is not left open. The book (DMA_Tx) shows every open TK61 case; one that is neither the running round nor a request
       still waiting for its round, and whose last act is older than a round can last (ROUND_MAX_MS) plus a minute (a request: ten minutes), belongs to a round that ended without its end being
       recorded - the client restarted and the "open" note of dma-mail-round.json was lost or never written, a round whose own end did not run. The mail manager is the executor: a promised case is
       ended as a round that could not do its work (revoke promise, allow, decline - the reason says what was found), a requested one is revoked (revoke request, allow). No game action. */
    function closeOrphans(now) {
        var T = root.DMA_Tx, list = [], i, t, key, age, who = "mail manager";
        try { list = (T && typeof T.list === "function") ? T.list({ tk: "TK61", open: true }) : []; } catch (_) { list = []; }
        for (i = 0; i < list.length; i++) {
            t = list[i]; key = String(t.key);
            if ((round && round.caseId === key) || (asked && asked.caseId === key) || askedCases[key] && (state.queued || asked)) continue;
            age = now - (Number(t.at) || now);
            var o = { tk: "TK61", actor: who, caseId: key }, w = "no round of this case is running (found open, last act " + Math.round(age / 60000) + " min ago)";
            var rc = function (act, d) { var x = {}, k; for (k in o) x[k] = o[k]; x.act = act; for (k in d) if (d.hasOwnProperty(k)) x[k] = d[k]; try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", x); } catch (_) {} };
            if (t.revoking || (t.state !== "promised" && t.state !== "requested")) continue;
            if (t.state === "promised" && age > ROUND_MAX_MS + 60000) { note("closed an orphan round " + key + ": " + w); rc("revoke promise", { reason: w }); rc("allow", { actor: who + " (tacit)" }); rc("decline", { reason: w }); }
            else if (t.state === "requested" && age > 10 * 60000) { note("revoked an orphan request " + key + ": " + w); rc("revoke request", { reason: w }); rc("allow", { actor: who + " (tacit)" }); delete askedCases[key]; }
        }
    }
    function loadLastRound() { var f = fileRead(ROUND_FILE); lastRound = f && f.last ? f.last : null; return lastRound; }
    function lastRoundAt() { return lastRound && Number(lastRound.atMs) > 0 ? Number(lastRound.atMs) : 0; }   // 0.2.6: never Date.parse
    function requestRound(by, grp, cs) {
        if (round || state.queued) return { fact: "pm", reason: round ? "a round is running" : "on the blue task list" };
        if (!asked) asked = { by: String(by || "ad hoc"), groups: grp || null, at: Date.now(), caseId: cs || null };
        if (cs) askedCases[String(cs)] = Date.now();   // 0.2.12: a request of a player's collect-now is known until its round has ended
        state.asked = asked.by; return { fact: "pm", reason: "at the next quiet moment" };
    }
    function due(now) { return on() && now - lastRoundAt() >= runMs(); }
    var roundDone = null;
    function submitRound(by, grp, cs) {   // the blue manager decides when
        var C = root.DMA_Control;
        if (!C || !C.blue || typeof C.blue.submit !== "function") return null;
        state.queued = by;
        return C.blue.submit("mail round", by, function (done) { state.queued = null; roundDone = done; startRound(Date.now(), by, grp, cs); }, { maxMs: ROUND_MAX_MS + 10000 });
    }
    function startRound(now, by, grp, cs) {
        round = { by: by, groups: grp || state.groups, startedAt: now, phase: "open", batches: 0, n: 0, kinds: {}, ids: [], headersAt: 0, checked: false, caseId: cs || ("round@" + now) };
        state.round = { by: by, startedAt: new Date(now).toISOString() };
        fileWrite(ROUND_FILE, { format: "dma-mail-round/1", last: lastRound, open: { caseId: round.caseId, by: by, startedAt: now } });   // 0.2.11
        if (!cs) record("request", { round: true, by: by, actor: by });   // 0.2.8: a player's collect-now recorded it already
        record("promise", { round: true, by: by });
        try { step(); } catch (e) { note("round " + e); endRound("error"); }   // 0.2.12 (UAT F6): an exception in the first step left the round open for ever (no timer, no end)
    }
    function later() { if (root.DMA_MAIL_NO_TIMER || root.DMA_LOOT_NO_TIMER) return; root.setTimeout(function () { try { step(); } catch (e) { note("round " + e); endRound("error"); } }, STEP_MS); }
    function step(now) {
        if (!round) return;
        now = now || Date.now();
        var G = gw(), r = round;
        if (!G) return endRound("no gateway");
        var C = root.DMA_Control;
        if (C && C.visit && C.visit.held()) return endRound("visit hold");
        if (now - r.startedAt >= ROUND_MAX_MS) return endRound("time limit");
        if (r.phase === "open") {
            var o = G.openMailWindow ? G.openMailWindow("mail manager", ROUND_MAX_MS + 5000) : { ok: false, reason: "no open" };
            if (!o.ok) return endRound("cannot open: " + o.reason);
            r.openedBy = o.by; r.phase = "headers"; return later();
        }
        if (r.phase === "headers") { try { G.requestInboxHeaders(); } catch (_) {} r.headersAt = now; r.phase = "wait"; return later(); }
        if (r.phase === "wait") {
            var have = 0; try { have = (G.lootMails ? G.lootMails() : []).length; } catch (_) {}
            if (!have && now - r.headersAt < HEADERS_WAIT_MS) return later();
            try { state.waitingBy = G.lootCounts() || {}; } catch (_) {}
            r.phase = "collect";
        }
        if (r.phase === "collect") {
            if (!r.checked) { r.checked = true; var ids = []; try { ids = G.lootMails().map(function (m) { return Number(m.id); }); } catch (_) {} checkPending(now, ids); }
            var pb = pending();   // 0.2.7: this round's own last batch: gone from the inbox -> go on with the next batch
            if (pb && !state.suspended && pb.at >= r.startedAt) {
                var idsNow = []; try { idsNow = G.lootMails().map(function (m) { return Number(m.id); }); } catch (_) {}
                var stillThere = (pb.ids || []).filter(function (id) { return idsNow.indexOf(Number(id)) >= 0; }).length;
                if (!stillThere) { setPending(null); r.waitP = 0; }
                else if ((r.waitP = (r.waitP || 0) + 1) <= 3) return later();
            }
            if (state.suspended || pending()) { r.phase = "linger"; }
            else {
                var res = null; try { res = G.collectLootMails({ toStorage: toStorage(), groups: r.groups }); } catch (e) { res = { ok: false, reason: String(e) }; }
                if (res && res.ok && res.n) {
                    setPending({ at: now, ids: res.ids || [] });
                    r.n += res.n; r.batches += 1; r.ids = r.ids.concat(res.ids || []);
                    var kk; for (kk in (res.kinds || {})) if (res.kinds.hasOwnProperty(kk)) { r.kinds[kk] = (r.kinds[kk] || 0) + res.kinds[kk]; state.collectedBy[kk] = (state.collectedBy[kk] || 0) + res.kinds[kk]; }
                    state.collected += res.n;
                    if (r.batches < 10) return later();
                } else if (res && !res.ok) { note(res.reason || "refused"); r.refused = res.reason || "refused"; info("collect refused", { reason: r.refused }); }   // 0.2.8
                r.phase = "linger"; r.lingerFrom = now;
            }
        }
        if (r.phase === "linger") {   // another actor asked for the inbox: keep it open for it a little while
            if (!r.lingerFrom) r.lingerFrom = now;
            if (r.by !== "mail manager" && r.by !== "player" && now - r.lingerFrom < LINGER_MS) return later();
            return endRound("done");
        }
    }
    function endRound(why) {
        var r = round, r0 = round, G = gw(), now = Date.now();
        round = null; state.round = null; if (r0 && r0.caseId) delete askedCases[String(r0.caseId)];
        try { if (G && G.closeMailWindow) G.closeMailWindow(); } catch (_) {}
        if (!r) return;
        lastRound = { at: new Date(now).toISOString(), atMs: now, by: r.by, mails: r.n, kinds: r.kinds, ended: why, sec: Math.round((now - r.startedAt) / 1000) };
        fileWrite(ROUND_FILE, { format: "dma-mail-round/1", last: lastRound });
        state.lastRound = lastRound; state.runs += 1;
        var o = { tk: "TK61", actor: "mail manager", caseId: r.caseId };   // 0.2.8: the round is closed; record against its case
        function rc(act, d) { var x = {}, k; for (k in o) x[k] = o[k]; x.act = act; for (k in d) if (d.hasOwnProperty(k)) x[k] = d[k]; try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", x); } catch (_) {} }
        var failed = !r.n && (r.refused || /^(cannot open|no gateway|visit hold|away|error|time limit)/.test(String(why)));
        if (r.n) {
            state.last = { at: lastRound.at, n: r.n, kinds: r.kinds, into: toStorage() ? "storage" : "star menu", by: r.by };
            rc("execute", { mails: r.n, kinds: r.kinds, into: state.last.into, ids: r.ids, by: r.by });
        }
        if (failed) { var why2 = r.refused ? "collect refused: " + r.refused : String(why); rc("revoke promise", { reason: why2 }); rc("allow", { actor: r.by + " (tacit)" }); rc("decline", { reason: why2, sec: lastRound.sec }); }
        else { rc("declare", { round: true, by: r.by, mails: r.n, ended: why, sec: lastRound.sec }); rc("accept", { actor: r.by + " (tacit)" }); }
        writeStatus(now);
        var d = roundDone; roundDone = null; if (d) d(why);
    }
    function tick(now) {
        if (away()) { state.away = true; if (round) endRound("away"); return; } state.away = false;
        now = now || Date.now();
        state.ticks += 1;
        state.switchedOn = on();
        state.groups = groups();
        state.nextRunAt = on() ? new Date(Math.max(now, lastRoundAt() + runMs())).toISOString() : null;
        state.quiet = isQuiet();
        if (round && now - round.startedAt >= ROUND_MAX_MS + 30000) { note("round stuck for " + Math.round((now - round.startedAt) / 1000) + " s"); endRound("time limit"); }   // 0.2.12: no step ends it any more
        else if (!round) { try { closeOrphans(now); } catch (e) { note("orphans " + e); } }
        if (round || state.queued || state.suspended) { if (state.ticks % 6 === 0) writeStatus(now); return; }
        if (asked || due(now)) {
            var a = asked; asked = null; state.asked = null;
            submitRound(a ? a.by : "mail manager", a && a.groups ? a.groups : null, a && a.caseId ? a.caseId : null);
        }
        if (state.ticks % 6 === 0) writeStatus(now);
    }
    function start() {
        if (timer) return;
        state.startedAt = new Date().toISOString();
        loadLastRound(); state.lastRound = lastRound;
        try { var f0 = fileRead(ROUND_FILE); if (f0 && f0.open && f0.open.caseId && !round) {   // 0.2.11: a round cut off by a restart
            var why0 = "the client restarted during the round", by0 = f0.open.by || "mail manager";
            [["revoke promise", { reason: why0 }], ["allow", { actor: by0 + " (tacit)" }], ["decline", { reason: why0 }]].forEach(function (a) {
                var x = { tk: "TK61", act: a[0], actor: "mail manager", caseId: f0.open.caseId }, k; for (k in a[1]) x[k] = a[1][k];
                try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", x); } catch (_) {} });
            fileWrite(ROUND_FILE, { format: "dma-mail-round/1", last: lastRound }); } } catch (_) {}
        var p0 = pending();                                                        // 0.2.2: started again right after a collect?
        if (p0 && Date.now() - p0.at < 5 * 60000) suspend("the client restarted within 5 minutes of a collect (connection lost?)");
        if ((root.DMA_MAIL_NO_TIMER || root.DMA_LOOT_NO_TIMER)) return;
        timer = root.setInterval(function () { try { tick(); } catch (e) { note("tick " + e); } }, TICK_MS);
    }
    /* 0.2.1: the player's one-off "collect now" for one kind; 0.2.5: an ad hoc round for that kind at the next quiet moment */
    function collectNow(kind, done) {
        var one = {};
        GROUPS.forEach(function (k) { one[k] = k === kind; });
        if (!one[kind]) { if (done) done({ ok: false, reason: "unknown kind " + kind }); return { ok: false, reason: "unknown kind " + kind }; }
        if (state.suspended) { var sx = { ok: false, reason: "suspended: " + state.suspended + " (Resume on the MAIL page)" }; if (done) done(sx); return sx; }
        var cs0 = "round@" + Date.now();
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", { tk: "TK61", act: "request", actor: "player", caseId: cs0, kind: kind, by: "player" }); } catch (_) {}   // 0.2.8: the request of the round it starts
        var r = requestRound("player", one, cs0);
        if (done) done({ ok: true, n: 0, reason: "a mail round for " + kind + " " + r.reason });
        return { ok: true, started: false, reason: r.reason };
    }
    root.DMA_Mail = root.DMA_Loot = {
        version: VERSION,
        tick: tick,
        step: step,                 // 0.2.5 (tests drive the round step by step)
        requestRound: requestRound, // 0.2.5
        lastRound: function () { return lastRound ? JSON.parse(JSON.stringify(lastRound)) : null; },
        collectNow: collectNow,
        resume: function () { state.suspended = ""; setPending(null); note(""); return true; },
        status: function () { return JSON.parse(JSON.stringify(state)); }
    };
    start();
})(typeof window !== "undefined" ? window : this);
