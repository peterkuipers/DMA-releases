/*
 * 0.5.22 (2026-11-04, author: "ja"): Bagster's "Peter can we do a RT" (01:30:19 UTC) came 9 s after the chat was observed
 *   again after a restart; the quiet minute dropped it as login replay. Within that minute a line is now replay only when
 *   the same sender and text are in the inbox from before this load; a line never stored is handled at once.
 *   Unit: tests/unit/dma-chat-replay.test.js; integration: live, an RT asked within a minute after a restart is a request.
 * 0.5.21 (2026-11-01, test day: 21% of the logged guild lines were duplicates): every channel (re)join ("Welcome to
 *   <room>") makes the client replay the room's history with the current time. A line seen before (same room, sender
 *   and text, within 3 h) that arrives in the 15 s after a welcome is a replay: not logged again and not given to
 *   recent() (the loot-spot run would read an old "pls" as a new request). Lines first seen in a replay are logged but
 *   kept out of recent() too. The welcome line itself is not logged.
 *   Unit: dma-chat-replay.test.js; integration: the GP offer after a room switch counts only new requests.
 * 0.5.20 (2026-10-31, live: "Chat switch is off" right after a restart while it is on): without a policy instance the
 *   Chat switch is read from dma-policy.json. Unit: chat tests; integration: the GP offer after a restart.
 * 0.5.19 (2026-10-31, live: "ik zie geen post?" — "guild room unknown" right after a restart): the guild room falls
 *   back to the selected guild channel (name=gc_…) and to the room kept in dma-chat-room.json.
 *   Unit: chat tests; integration: the GP offer is posted right after a restart.
 * 0.5.18 (2026-10-31, live: "uitnodiging lijkt fout te gaan" — "2x ls GP" stayed in the queue): the watcher (reading and
 *   sending) also runs during an adventure run's loot-spot phase (LS_*), whatever the visit hold says.
 *   Unit: chat tests; integration: GP Run once posts and reads the requests on the adventure.
 * 0.5.17 (2026-10-31, author: "nee met ls uitnodiging en alles"): sayLs(text) puts an approved loot-spot line in the
 *   guild chat (the only guild exception to whisperOnly; config lsGuild:false turns it off). Unit: validate passes an
 *   ls guild item while whisperOnly holds; integration: GP run posts "2x ls GP".
 * 0.5.16 (2026-10-31, author: "de demo actiehandelingen moeten ondersteund worden"): recent(sinceAt) gives the recent
 *   chat lines with their channel, ownName() the player's name — read only, for learning the loot-spot communication.
 *   Unit: existing chat tests; integration: a GP demonstration records the guild lines.
 * 0.5.15 (2026-10-31, live: "RT werd zojuist gevraagd" during YWC and nothing happened): the watcher also runs during a
 *   visit hold while our own adventure run fights (DMA_Control.rtAwayOk), so RT requests reach the trade acceptor.
 *   Unit: hold + rtAwayOk ticks, hold alone does not; integration: an RT asked during an adventure fight.
 * 0.5.14 (2026-10-31, author: "herstart ... en de guilde chat selecteert"; live after a restart: backToGuild "not
 *   done: no guild channel remembered"): when no guild channel is remembered, backToGuild() searches the chat view's
 *   display tree (depth 6, at most 400 objects) for a channel/data/room object that looks like the guild channel, and
 *   remembers it; what it saw is in dma-chat-status.json (state.guildSearch, state.guildSearchSeen) for the next step.
 *   Unit expectation:        a view whose second child carries {channel:{name:"guild"}} is found and selected.
 *   Integration expectation: after a restart the guild tab is in front within 5 minutes (console 0.1.55 retries).
 *
 * 0.5.13 (2026-10-30, author: "na de RT kun je terug naar de guild chat en de mail sluiten"): DMA_Chat.backToGuild() —
 *   the guild channel the view showed last is remembered (readSelected) and put back as the selected channel when another
 *   tab (e.g. the whisper with the RT partner) is in front; selectGuild() stays the fallback. Called by the trade acceptor
 *   when its RT is over. Reading and sending are unchanged (the observer reads every room whatever tab is shown).
 *   Unit expectation:        with a remembered guild channel and a whisper selected, backToGuild() sets selectedChannel to
 *                            the guild one and returns true; with nothing remembered and no selectMethod it returns false.
 *   Integration expectation: after a live RT the chat panel shows the guild tab again (status selectedChannel = Guild).
 * 0.5.11 (2026-10-30, ADR 0030): the watcher's tick does nothing while the location manager holds blue work for a visit.
 * 0.5.10 (2026-10-27, author: "for now no automatic replies in the chat"): config noSend:true is a hard kill on the
 *   send side (DEFAULT true: only a config with noSend:false can send) — the Chat switch may be on (the watcher reads and relays to Claude), and nothing is ever sent.
 *   Unit expectation: canSend() false whenever noSend is true. Integration: with Chat on, dma-chat-sent.jsonl stays empty.
 * DMA guild-chat bridge 0.2.0 (user_dma_chat.js).
 * 0.5.9 (2026-10-26, author: "someone will say in the chat that you must tell me something or do something — then you do
 *   that here; just say you will do it and place a message to me in this chat"): "tell / ask / remind Peter ...",
 *   "zeg tegen Peter ...", "Peter needs to ..." is a RELAY — reply "@X: will do!", the line is written to
 *   dma-chat-relay.jsonl for the player's session, never routed as a help request and never carried out. Live: Wendigo1979
 *   "Tell Peter he needs to call me back" was answered "how much of what?".
 *
 * 0.2.0 (2026-10-24)
 *  - Reading uses the mechanism the client's own scripts/7-notify.js uses (VERIFIED in the client
 *    source): game.gi.channels.ZONE.addPropertyObserver("CHAT_MESSAGE", game.getTracker(name, fn)).
 *    event.data.room names the room ("gc…" guild, "gco…" officers, "trade", "global…", "news"),
 *    event.data.text the text, event.data.getExtension("bbmsg").mPlayerName the sender.
 *    readMode "observer" is the default: it only listens, replaces nothing, and so avoids U5.
 *  - Each inbox line also carries the room id; the guild room id is kept for sending ($room).
 *  - The probe also inventories game.gi.channels and the first GUILD message object (member
 *    names and room id only; never its text, never a non-guild message).
 *  - Outbox lines may carry "source" and "lang" (the author's original before translation);
 *    they are copied to the sent log for traceability and never posted.
 *
 * 0.5.4 (2026-10-25, author: another player will test the scripts without Claude watching): nothing is specific to
 *   this player any more. The words come from the console (policy chat.words, e.g. "Peter"); without words nothing
 *   is a mention. The player's own name is read from the game (mCurrentPlayer.GetPlayerName_string), the config
 *   ownName only as fallback, and a line that repeats a text this script queued is never a mention (no loop even
 *   when the name cannot be read). Defaults: notify send on, acknowledgement "@{sender}: got it, {name} will get
 *   back to you soon." ({name} = the first word). Sending needs the config sendEnabled OR the Chat switch ON
 *   (default OFF), so a new player's client sends nothing until he switches Chat on.
 *   DMA_Chat.words() / ownerName() for the trade module. A legacy config mentionWords is moved into the policy once.
 * 0.5.12 (2026-10-30, author: "so if <name> asks Peter can we do a RT, you can whisper to that person by "/w <name>" and
 *   all communication is in that way, the rest will stay the same"; live the same day: a whisper arrives as a chat message
 *   whose room is the partner's name — "Bets333" for our own line, "bets333" for theirs): RT BY WHISPER. Every message the
 *   trade acceptor says to a guild member ("@<name>: …", tags rt-*) is sent as a WHISPER to that member (MessageVO room =
 *   the name, groupMessage false), never in the guild chat. A whisper that asks for an RT is an RT request like the guild
 *   one; the member's later whispers reach the trade acceptor through linesFrom as before. Config whisperOnly (default
 *   false; true in the author's dma-chat-config.json): the script sends nothing to the guild chat at all — only whispers. The rest stays the same (noSend and the Chat
 *   switch still decide whether anything is sent).
 *   Unit expectation:        say("@Bets333: RT ok …", "rt-pm") -> one whisper item to Bets333 with text "RT ok …"; a guild
 *                            ack is rejected when whisperOnly is set; a whisper "RT pls" is an RT request.
 *   Integration expectation: tests/integration/dma-chat-whisper.test.js.
 * 0.5.3 (2026-10-25): the console switch "Chat" (policy chat.auto, actor role chat watcher) decides whether the watcher
 *   acts: off -> no acknowledgement of a "Peter" mention and no RT request taken in. Reading and recording the
 *   chat go on (observation, not action); a message the author approved (outbox) is still sent.
 * 0.5.2 (2026-10-25): DMA_Chat.linesFrom(sender, sinceAt) — the recent guild lines of one sender (last 300, in memory),
 *   so the trade acceptor can read the requester's accept or reject after its declaration.
 * 0.5.1 (2026-10-25): an RT request is taken each time it is asked (outside the login replay), not once a day by text;
 *   the same sender asking twice within 2 min counts once. Found live: Sizzler79 asked again after a restart and was ignored.
 * 0.5.8 (2026-10-25, live: Zingu asked "peter help 10 stone" again a minute later, after the author changed a rule ("try
 *   again please") — swallowed as a repeat): the same help request counts as one only within 20 s (helpRepeatMs), which
 *   still catches a doubled chat event but lets a deliberate retry through.
 * 0.5.7 (2026-10-25, live: Zingu's "peter help me for 10 pinewood" right after his hardwood request got no answer):
 *   the 2-minute dedup of help requests is per sender AND text — a different request is a new request.
 * 0.5.6 (2026-10-25, author: "if someone changes his mind you must always be able to undo it"): a mention that revokes
 *   ("cancel", "undo", "never mind", "changed my mind", "take back", "laat maar", "terugdraaien" ...) is neither
 *   acknowledged nor routed as a help request — the trade acceptor and the helper read it from linesFrom and handle it.
 * 0.5.5 (2026-10-25, author: guild help and star trades): a mention that asks for a star trade ("star trade", "ST",
 *   "star") or for help with a resource ("help", "need", "can I have", "give me", "spare", "hulp", "nodig") is a request
 *   for the helper / star trader (DMA_Chat.helpRequests, kind "star" | "help"), not an acknowledgement. Order: star,
 *   RT, help, else the fixed acknowledgement. The same sender asking the same kind twice within 2 min is one request.
 * 0.5.0 (2026-10-25): "Peter … RT" is a round-trade request (dma-trade-requests.jsonl, DMA_Chat.rtRequests) answered
 *   with rtReply; DMA_Chat.say() lets the trade module post its result.
 * 0.4.1 (2026-10-25): no acknowledgement during the login history replay or for a mention already seen in 24 h;
 *   the echo of a notify send is awaited before sending (it arrives synchronously).
 * 0.4.0 (2026-10-25): sendMode "notify" — the chat's own PureMVC notification "sendMessage" with a MessageVO
 *   (found in client.swf); optional fixed acknowledgement of a "Peter" mention (mentionAck), rate-limited.
 * 0.3.2 (2026-10-25): guild lines that name the player ("Peter") also go to dma-chat-mentions.jsonl — reported, never acted on.
 * 0.3.1 (2026-10-25): the send presses Enter as a keyDown (keyCode 13) on the input; a plain "enter" Event did not send.
 * 0.3.0 (2026-10-24): send route "input" (U3 from the 0.2.1 probe): the approved text is put in the chat
 *   view's input and the input's "enter" event is dispatched, only while the selected channel is the guild;
 *   the send is confirmed when the same text comes back through CHAT_MESSAGE. The status shows the selected channel.
 * 0.2.1 (2026-10-24): the probe also inventories the chat view, its input and the BlueFire component (read-only).
 * 0.1.0 (2026-10-24): prototype, file bridge, probe, config-driven select/hook/poll/send.
 *
 * Lets the player follow and take part in the guild chat remotely: incoming guild messages are
 * appended to a file next to the client, and messages the player dictated are read from another
 * file and posted to the guild channel. A remote Claude session reads and writes those files
 * through the linked computer. Proposal: docs/proposals/guild-chat-bridge.md.
 *
 * Files (air.File in File.applicationDirectory, i.e. the tso_portable folder; localStorage does
 * not survive a restart; settings.json is never touched):
 *   dma-chat-in.jsonl     written by this module   one line per incoming message {time,sender,text,channel}
 *   dma-chat-out.jsonl    written by the remote session, only READ here   {id,text,channel,verbatim:true,createdAt}
 *   dma-chat-sent.jsonl   written by this module   one line per handled outbox id {id,status,reason,at,...}
 *   dma-chat-status.json  written by this module   heartbeat + state, every 30 s
 *   dma-chat-probe.json   written by this module   read-only inventory of the chat panel (once per start)
 *   dma-chat-config.json  optional, written by the player/remote session; merged over DEFAULTS
 *
 * UNVERIFIED API (nothing below has been observed in the live client; every name is configurable
 * and defaults to "off" so a first deploy only probes and never acts):
 *   - U1 how the guild channel is selected            -> config.selectMethod / selectArgs   (default null)
 *   - U2 RESOLVED in 0.2.0: readMode "observer" (CHAT_MESSAGE, as in the client's 7-notify.js);
 *        "hook" | "poll" remain as alternatives
 *        hook: config.hookMethod is wrapped (pass-through); poll: config.pollPath is a message list
 *   - U3 how a message is sent to a channel via server -> config.sendMethod / sendArgs     (default null)
 *   - U4 RESOLVED for reading: guild rooms start with "gc" but not "gco" (7-notify.js); the label in
 *        the files is config.guildChannel ("guild"); whether sending wants the room id is part of U3
 *   - U5 whether an AS3 method on mChatPanel can be replaced from JS at all (dma-control does this
 *        for gi.SendServerAction, which may be a different kind of object)
 * VERIFIED in reference scripts only (legacy-reference/): globalFlash.gui.mChatPanel exists;
 *   PutMessageToChannelWithoutServer("news", date, text, ...) shows a LOCAL line (not sent);
 *   game.gi.mQuestClientCallbacks.mGameInterface.mChatPanel.addChatMessage(text, 0) shows a local line.
 *   Neither sends to the server, so neither is used for sending.
 *
 * Safety (decision 0008, provisional): this module never composes or translates text. verbatim:true
 * means "exactly the text the author approved" (possibly Claude's translation of his Dutch, shown
 * to him and approved per message). It sends only outbox lines that carry verbatim:true,
 * each at most once (a failed send is recorded and NOT retried), at most one per
 * minSendIntervalMs, and only while config.sendEnabled is true (default false).
 *
 * Architecture note: the platform's Game Interface Adapter is still a stub, so the access to the
 * chat panel is isolated in one section (chatPanel/callPanel) to be moved there when it exists.
 * The module modifies no other module and no game state except the configured chat calls.
 */
(function (root) {
    "use strict";
    if (root.DMA_Chat && root.DMA_Chat.version) return;

    var VERSION = "0.5.22";
    var FILES = {
        inbox: "dma-chat-in.jsonl",
        outbox: "dma-chat-out.jsonl",
        sent: "dma-chat-sent.jsonl",
        status: "dma-chat-status.json",
        probe: "dma-chat-probe.json",
        config: "dma-chat-config.json",
        mentions: "dma-chat-mentions.jsonl",
        rtRequests: "dma-trade-requests.jsonl",
        relay: "dma-chat-relay.jsonl"                      // 0.5.9: messages for the player, relayed to him
    };
    var DEFAULTS = {
        enabled: true,
        guildChannel: "guild",          // U4
        recordChannels: ["guild", "other"],   // 0.5.12: "other" = whispers (room = the partner's name)
        selectMethod: null,             // U1
        selectArgs: ["$channel"],
        readMode: "observer",           // "observer" (verified) | "hook" | "poll" | "none"
        guildRoomPrefix: "gc",
        officersRoomPrefix: "gco",
        hookMethod: null,
        hookArgs: { channel: 0, time: 1, sender: 2, text: 3 }, // index into the hooked call's arguments, or "obj" mapping below
        hookArgIsObject: false,         // true: arguments[0] is a message object, fields found by name
        pollPath: null,                 // dotted path from the chat panel to an array-like message list
        noSend: true,                   // 0.5.10: hard kill, default ON — nothing is sent unless the config sets noSend:false
        sendEnabled: false,             // kill switch for the send side; 0.5.4: the Chat switch ON also enables it (canSend)
        sendMethod: null,               // U3 (sendMode "panel")
        sendMode: "notify",             // 0.5.4 default; "panel": call mChatPanel[sendMethod]; "input": the chat view's input + "enter" (0.3.0)
        confirmMs: 15000,
        mentionWords: [],               // 0.5.4: legacy; the words live in the policy (chat.words), set in the console
        ownName: "",                    // 0.5.4: read from the game; this is only the fallback
        mentionAck: "@{sender}: got it, {name} will get back to you soon.",   // 0.5.4 default; {name} = the first word
        ackPerSenderMs: 600000,         // at most one acknowledgement per sender per 10 min
        ackPerHour: 6,                  // and at most 6 an hour
        replayQuietMs: 60000,
        rtRepeatMs: 120000,
        helpRepeatMs: 20000,   // 0.5.8
        rtReply: null,                  // 0.5.0: the promise/decline is the trade module's (the executor), not the chat's
        sayPerHour: 12,                 // 0.5.0: internal messages (trade results) per hour           // 0.4.1: no acknowledgement in the first minute after the chat is observed (history replay)               // "input": how long to wait for the own text to come back as a guild message
        sendArgs: ["$channel", "$text"],
        minSendIntervalMs: 5000,
        maxTextLength: 200,
        whisperOnly: false,             // 0.5.12: true = nothing to the guild chat, only whispers (set in dma-chat-config.json)
        tickMs: 2000,
        statusEveryMs: 30000
    };
    var NAME_RE = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

    var cfg = clone(DEFAULTS);
    var state = {
        startedAt: null, panel: false, select: "not configured", read: "not configured", send: "disabled",
        hooked: false, observing: false, guildRoom: null, pollSeen: 0, messageProbed: false, received: 0, sent: 0, rejected: 0, failed: 0, lastSendAt: 0,
        lastError: "", lastStatusAt: 0, probed: false, selectedChannel: null, confirmed: 0, unconfirmed: 0, mentions: 0, observedSince: 0
    };
    var pendingConfirm = null;
    var msgCtor = null;          // 0.4.0: the class of an incoming MessageVO, to build an outgoing one
    var ackQueue = [], ackSender = {}, ackTimes = [], mentionSeen = {};
    var rtRequests = [], sayTimes = [];      // 0.5.0: round-trade requests from the guild chat; internal messages   // { id, text, at } while an "input" send waits for its echo
    var handled = {};       // outbox id -> status (from dma-chat-sent.jsonl + this run)
    var recentLines = [];   // 0.5.2: last 300 guild lines { at, sender, text }
    var rtSeen = {};        // 0.5.1: sender -> time of the last RT request taken
    var seenKeys = [];      // dedupe of incoming messages
    var seenSet = {};
    var replayUntil = {};   // 0.5.21: room -> ms until which incoming lines are the join replay
    var textSeenAt = {};    // 0.5.21: room|sender|text -> ms last seen
    var textSeenKeys = [];
    var timer = null;

    function clone(o) { return JSON.parse(JSON.stringify(o)); }
    function nowIso(t) { return new Date(t || Date.now()).toISOString(); }
    function note(s) { state.lastError = String(s).slice(0, 300); try { if (root.debug) root.debug("[DMA_Chat] " + s); } catch (_) {} }

    /* ---------- files (air.File, same pattern as user_dma_demo_agents.js) ---------- */
    function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function appFile(name) {
        try {
            var A = airApi();
            if (!A || !A.File || !A.File.applicationDirectory) return null;
            return new A.File(A.File.applicationDirectory.resolvePath(name).nativePath);
        } catch (_) { return null; }
    }
    function readText(name) {
        try {
            var A = airApi(), f = appFile(name);
            if (!f || !f.exists) return null;
            var st = new A.FileStream();
            st.open(f, A.FileMode.READ);
            var s = st.readUTFBytes(st.bytesAvailable);
            st.close();
            return s;
        } catch (e) { note("read " + name + ": " + e); return null; }
    }
    function writeText(name, text, append) {
        try {
            var A = airApi(), f = appFile(name);
            if (!A || !f) return false;
            var st = new A.FileStream();
            st.open(f, append ? A.FileMode.APPEND : A.FileMode.WRITE);
            st.writeUTFBytes(text);
            st.close();
            return true;
        } catch (e) { note("write " + name + ": " + e); return false; }
    }
    function appendLine(name, obj) { return writeText(name, JSON.stringify(obj) + "\n", true); }
    function readJson(name) { var t = readText(name); if (!t) return null; try { return JSON.parse(t); } catch (_) { return null; } }   // 0.5.19
    function writeJson(name, obj) { return writeText(name, JSON.stringify(obj), false); }
    function readLines(name) {
        var s = readText(name), out = [], i, l;
        if (!s) return out;
        var parts = s.split(/\r?\n/);
        for (i = 0; i < parts.length; i++) {
            l = parts[i].trim();
            if (!l) continue;
            try { out.push(JSON.parse(l)); } catch (_) { out.push({ __bad: l.slice(0, 120) }); }
        }
        return out;
    }

    /* ---------- config ---------- */
    function loadConfig() {
        cfg = clone(DEFAULTS);
        var s = readText(FILES.config);
        if (!s) return;
        try {
            var c = JSON.parse(s), k;
            for (k in c) if (c.hasOwnProperty(k) && DEFAULTS.hasOwnProperty(k)) cfg[k] = c[k];
        } catch (e) { note("config: " + e); }
        ["selectMethod", "hookMethod", "sendMethod"].forEach(function (k) {
            if (cfg[k] != null && !NAME_RE.test(String(cfg[k]))) { note("config " + k + " refused: not a plain method name"); cfg[k] = null; }
        });
        if (cfg.pollPath != null && !/^[A-Za-z_$][A-Za-z0-9_$]*(\.[A-Za-z_$][A-Za-z0-9_$]*)*$/.test(String(cfg.pollPath))) { note("config pollPath refused"); cfg.pollPath = null; }
        if (!(cfg.minSendIntervalMs >= 3000)) cfg.minSendIntervalMs = 3000; // never faster than one per 3 s
        if (cfg.sendMode !== "panel" && cfg.sendMode !== "input" && cfg.sendMode !== "notify") { note("config sendMode refused"); cfg.sendMode = "panel"; }
        if (cfg.mentionAck != null && (typeof cfg.mentionAck !== "string" || cfg.mentionAck.length > 120 || /[\r\n]/.test(cfg.mentionAck))) { note("config mentionAck refused"); cfg.mentionAck = null; }
    }

    /* ---------- chat panel access (to move into the Game Interface Adapter) ---------- */
    function chatPanel() {
        try { if (root.globalFlash && root.globalFlash.gui && root.globalFlash.gui.mChatPanel) return root.globalFlash.gui.mChatPanel; } catch (_) {}
        try {
            var gi = root.game && root.game.gi;
            var p = gi && gi.mQuestClientCallbacks && gi.mQuestClientCallbacks.mGameInterface && gi.mQuestClientCallbacks.mGameInterface.mChatPanel;
            if (p) return p;
        } catch (_) {}
        return null;
    }
    function runtimeDate(t) {
        try { if (root.runtime && root.runtime.Date) return new root.runtime.Date(t); } catch (_) {}
        try { if (root.window && root.window.runtime && root.window.runtime.Date) return new root.window.runtime.Date(t); } catch (_) {}
        return new Date(t);
    }
    function buildArgs(tpl, vars) {
        return (tpl || []).map(function (a) {
            if (a === "$channel") return vars.channel;
            if (a === "$text") return vars.text;
            if (a === "$room") return state.guildRoom;
            if (a === "$date") return runtimeDate(vars.time || Date.now());
            return a;
        });
    }
    function callPanel(method, args) {
        var p = chatPanel();
        if (!p) throw new Error("no chat panel");
        if (typeof p[method] !== "function") throw new Error("chat panel has no method " + method);
        return p[method].apply(p, args);
    }
    function pathGet(obj, path) {
        var parts = String(path).split("."), o = obj, i;
        for (i = 0; i < parts.length; i++) { if (o == null) return null; o = o[parts[i]]; }
        return o;
    }

    /* ---------- probe (read-only inventory; calls nothing on the panel) ---------- */
    var INTEREST = /chat|channel|guild|clan|message|msg|send|post|tab|select|whisper|receive|incoming|history|line/i;
    function probe() {
        var p = chatPanel(), out = { format: "dma-chat-probe/1", version: VERSION, at: nowIso(), panel: !!p, keys: [], describe: null, interesting: [] };
        if (p) {
            try { for (var k in p) out.keys.push(k + ":" + typeof p[k]); } catch (e) { out.keysError = String(e); }
            try {
                var rt = root.runtime || (root.window && root.window.runtime);
                var dt = rt && rt.flash && rt.flash.utils && rt.flash.utils.describeType;
                if (typeof dt === "function") {
                    var x = String(dt(p));
                    var names = [], re = /<(method|accessor|variable|constant)\s+name="([^"]+)"/g, m;
                    while ((m = re.exec(x)) !== null) names.push(m[1] + ":" + m[2]);
                    var cls = /<type\s+name="([^"]+)"/.exec(x);
                    out.describe = { type: cls ? cls[1] : null, members: names };
                }
            } catch (e) { out.describeError = String(e); }
            var all = out.keys.concat(out.describe ? out.describe.members : []);
            out.interesting = all.filter(function (n) { return INTEREST.test(n); });
        }
        // 0.2.1: inventory the chat VIEW as well (read-only): the mediator has no send method, so the send
        // route (U3) and the tab selection (U1) must be on the view, its input, or the BlueFire component.
        try {
            var app = root.swmmo && root.swmmo.application, views = {};
            var VIEW_RE = /send|submit|enter|input|message|msg|text|room|channel|tab|select|index|guild|chat|post|key/i;
            var slim = function (inv) {
                if (!inv) return inv;
                inv.members = (inv.members || []).filter(function (n) { return /^variable:/.test(n) || VIEW_RE.test(n); });
                inv.keys = (inv.keys || []).filter(function (n) { return VIEW_RE.test(n); });
                return inv;
            };
            if (app && app.GAMESTATE_ID_CHAT_PANEL) {
                var v = app.GAMESTATE_ID_CHAT_PANEL;
                views.chatPanelView = slim(inventory(v));
                if (v.chatInput) views.chatInput = slim(inventory(v.chatInput));
            }
            if (app && app.blueFireComponent) views.blueFireComponent = slim(inventory(app.blueFireComponent));
            if (p && typeof p.getViewComponent === "function") {
                var vc = p.getViewComponent();
                if (vc) views.mediatorView = slim(inventory(vc));
            }
            out.views = views;
        } catch (e) { out.viewsError = String(e); }
        try {
            var chs = root.game && root.game.gi && root.game.gi.channels;
            if (chs) { out.channels = []; for (var c in chs) out.channels.push(c); }
        } catch (e) { out.channelsError = String(e); }
        state.probed = true;
        writeText(FILES.probe, JSON.stringify(out, null, 1), false);
        return out;
    }

    function inventory(o) {
        var r = { keys: [], members: [] };
        try { for (var k in o) r.keys.push(k + ":" + typeof o[k]); } catch (e) { r.keysError = String(e); }
        try {
            var rt = root.runtime || (root.window && root.window.runtime);
            var dt = rt && rt.flash && rt.flash.utils && rt.flash.utils.describeType;
            if (typeof dt === "function") {
                var x = String(dt(o)), re = /<(method|accessor|variable|constant)\s+name="([^"]+)"/g, m;
                while ((m = re.exec(x)) !== null) r.members.push(m[1] + ":" + m[2]);
                var cls = /<type\s+name="([^"]+)"/.exec(x);
                r.type = cls ? cls[1] : null;
            }
        } catch (e) { r.describeError = String(e); }
        return r;
    }
    function probeMessage(d) {
        if (state.messageProbed) return;
        state.messageProbed = true;
        try {
            var s = readText(FILES.probe), out = s ? JSON.parse(s) : { format: "dma-chat-probe/1" };
            out.message = inventory(d);
            out.message.room = String(d.room);          // the room id only, never the text
            writeText(FILES.probe, JSON.stringify(out, null, 1), false);
        } catch (e) { note("probe message: " + e); }
    }

    /* ---------- incoming ---------- */
    function roomLabel(room) {
        room = String(room || "");
        if (room.indexOf(cfg.officersRoomPrefix) === 0) return "officers";
        if (room.indexOf(cfg.guildRoomPrefix) === 0) return cfg.guildChannel;
        if (room === "trade" || room === "help" || room === "news") return room;
        if (room.indexOf("global") === 0) return "global";
        return room ? "other" : null;
    }
    function onChatEvent(event) {
        try {
            var d = event && event.data;
            if (!d || !d.text) return;
            var sender = null;
            try { var bb = d.getExtension && d.getExtension("bbmsg"); if (bb && bb.mPlayerName) sender = String(bb.mPlayerName); } catch (_) {}
            if (sender == null) sender = pick(d, ["from", "sender", "userName"]);
            var label = roomLabel(d.room);
            if (label === cfg.guildChannel) { if (state.guildRoom !== String(d.room)) { try { writeJson("dma-chat-room.json", { room: String(d.room), at: new Date().toISOString() }); } catch (_) {} } state.guildRoom = String(d.room); probeMessage(d); if (!msgCtor && d.constructor) msgCtor = d.constructor; }
            if (pendingConfirm && String(d.text) === pendingConfirm.text && (pendingConfirm.to ? String(d.room || "").toLowerCase() === pendingConfirm.to.toLowerCase() : label === cfg.guildChannel)) {
                state.confirmed += 1;
                appendLine(FILES.sent, { id: pendingConfirm.id, status: "confirmed", reason: pendingConfirm.to ? "seen in the whisper with " + pendingConfirm.to : "seen in the guild chat", at: nowIso(), channel: pendingConfirm.to ? "whisper" : "guild", to: pendingConfirm.to || undefined, text: pendingConfirm.text });
                pendingConfirm = null;
            }
            receive({ channel: label, room: String(d.room), sender: sender, text: String(d.text), time: pick(d, ["time", "timestamp", "date"]) });
        } catch (e) { note("chat event: " + e); }
    }
    function installObserver() {
        try {
            if (root.__dmaChatObserver) { state.observing = true; state.read = "observer: CHAT_MESSAGE"; if (!state.observedSince) state.observedSince = Date.now(); return true; }
            var g = root.game, z = g && g.gi && g.gi.channels && g.gi.channels.ZONE;
            if (!z || typeof z.addPropertyObserver !== "function" || typeof g.getTracker !== "function") { state.read = "observer: channels not available"; return false; }
            z.addPropertyObserver("CHAT_MESSAGE", g.getTracker("dmaChatTracker", function (ev) { var C = root.DMA_Chat; if (C && C._onChatEvent) C._onChatEvent(ev); }));
            root.__dmaChatObserver = true;
            state.observing = true; state.read = "observer: CHAT_MESSAGE"; state.observedSince = Date.now();
            return true;
        } catch (e) { state.read = "observer failed: " + String(e).slice(0, 120); return false; }
    }
    function pick(o, names) {
        for (var i = 0; i < names.length; i++) {
            try { var v = o[names[i]]; if (v != null && v !== "") return v; } catch (_) {}
        }
        return null;
    }
    function normalize(raw) {
        // raw is either {channel,time,sender,text} already or a game object found by field names
        var rm = pick(raw, ["room"]);
        var ch = pick(raw, ["channel", "channelName", "mChannel", "channelId", "type"]);
        var sn = pick(raw, ["sender", "from", "userName", "username", "playerName", "mSender", "name"]);
        var tx = pick(raw, ["text", "message", "msg", "body", "mText", "mMessage"]);
        var tm = pick(raw, ["time", "date", "timestamp", "mTime", "mDate"]);
        return { channel: ch == null ? null : String(ch), sender: sn == null ? null : String(sn), text: tx == null ? null : String(tx), time: tm, room: rm == null ? null : String(rm) };
    }
    function timeIso(t) {
        if (t == null) return nowIso();
        try {
            if (typeof t === "number") return nowIso(t);
            if (t.getTime) return nowIso(Number(t.getTime()));
            var d = new Date(String(t));
            if (!isNaN(d.getTime())) return d.toISOString();
        } catch (_) {}
        return nowIso();
    }
    function wanted(channel) {
        var list = cfg.recordChannels || [cfg.guildChannel];
        return list.indexOf(channel) >= 0;
    }
    function receive(raw) {
        try {
            var m = normalize(raw);
            if (m.text == null || !wanted(m.channel)) return false;
            var line = { time: timeIso(m.time), sender: m.sender, text: m.text, channel: m.channel };
            if (m.room) line.room = m.room;
            var key = line.time + "|" + line.sender + "|" + line.text;
            if (seenSet[key]) return false;
            var nowR = Date.now(), roomK = String(line.room || line.channel || "");
            if (/OccupantVO/.test(String(line.sender || "")) && /^Welcome to /.test(String(line.text || ""))) {   // 0.5.21
                replayUntil[roomK] = nowR + 15000; return false;
            }
            var tk = roomK + "|" + line.sender + "|" + line.text, inReplay = nowR < (replayUntil[roomK] || 0);
            var before = textSeenAt[tk];
            if (before == null) { textSeenKeys.push(tk); if (textSeenKeys.length > 2000) delete textSeenAt[textSeenKeys.shift()]; }
            textSeenAt[tk] = nowR;
            if (inReplay && before != null && nowR - before < 3 * 3600000) { state.replayed = (state.replayed || 0) + 1; return false; }
            seenSet[key] = 1; seenKeys.push(key);
            if (seenKeys.length > 500) delete seenSet[seenKeys.shift()];
            if (appendLine(FILES.inbox, line)) state.received += 1;
            if (inReplay) { state.replayed = (state.replayed || 0) + 1; return true; }   // 0.5.21: history, never a new request
            recentLines.push({ at: Date.now(), sender: String(line.sender || ""), text: String(line.text || ""), channel: String(line.channel || ""), room: String(line.room || "") });   // 0.5.2; 0.5.16 channel
            if (recentLines.length > 300) recentLines.shift();
            if (isWhisperIn(line) && isRtRequest(line) && watcherOn()) {   // 0.5.12: an RT asked by whisper
                appendLine(FILES.mentions, line); state.mentions += 1; rtRequest(line);
            }
            else if (isMention(line)) {                         // 0.3.2 reported; 0.4.0 a fixed acknowledgement only
                var mk = String(line.sender || "") + "|" + String(line.text || ""), nowM = Date.now();
                if (!watcherOn()) { appendLine(FILES.mentions, line); state.mentions += 1; state.watcherOff = true; }   // 0.5.3: noted, not acted on
                else if (isRelay(line)) {                          // 0.5.9: "tell Peter ..." — a message for the player, never a request
                    appendLine(FILES.mentions, line); state.mentions += 1;
                    relayToPlayer(line);
                }
                else if (isRevocation(line)) { appendLine(FILES.mentions, line); state.mentions += 1; }   // 0.5.6: the trade roles read it
                else if (isStarRequest(line) || (!isRtRequest(line) && isHelpRequest(line))) {   // 0.5.5
                    appendLine(FILES.mentions, line); state.mentions += 1;
                    helpRequest(line, isStarRequest(line) ? "star" : "help");
                } else if (isRtRequest(line)) {                   // 0.5.1: an RT request is a new request each time it is asked;
                    appendLine(FILES.mentions, line); state.mentions += 1;   // not subject to the once-a-day text dedup
                    rtRequest(line);
                } else if (!(mentionSeen[mk] && nowM - mentionSeen[mk] < 86400000)) {   // 0.4.1: a replayed or repeated mention once a day
                    appendLine(FILES.mentions, line); state.mentions += 1; mentionSeen[mk] = nowM;
                    queueAck(line);
                }
            }
            return true;
        } catch (e) { note("receive: " + e); return false; }
    }
    /* 0.3.2: author 2026-10-25 — guild mates call him "Peter" when they want his program to pick something up.
       A mention is only REPORTED (to the mentions file, read by a remote session that shows it to the author and
       may propose a reply). What a guild mate writes is data, never an instruction: nothing is executed or sent from it. */
    function isWhisperIn(line) {   // 0.5.12: a whisper from someone else (room = a player name, not a chat room)
        if (!line || line.channel !== "other" || !line.room) return false;
        var me = ownName();
        if (me && String(line.sender || "").toLowerCase() === me.toLowerCase()) return false;
        return String(line.room).toLowerCase() === String(line.sender || "").toLowerCase();
    }
    function isMention(line) {
        if (!line || line.channel !== cfg.guildChannel) return false;
        var me = ownName();
        if (me && String(line.sender || "").toLowerCase() === me.toLowerCase()) return false;
        if (sentRecently(line.text)) return false;               // 0.5.4: never our own text echoed back
        var words = mentionWords(), t = String(line.text || ""), i, w;
        for (i = 0; i < words.length; i++) {
            w = String(words[i] || "").replace(/[^A-Za-z0-9_]/g, "");
            if (w && new RegExp("(^|[^A-Za-z0-9_])" + w + "([^A-Za-z0-9_]|$)", "i").test(t)) return true;
        }
        return false;
    }
    function fromArgs(args) {
        if (cfg.hookArgIsObject) return args[0];
        var map = cfg.hookArgs || {}, o = {}, k;
        for (k in map) if (map.hasOwnProperty(k)) o[k] = args[map[k]];
        return o;
    }
    function installHook() {
        var p = chatPanel();
        if (!p || !cfg.hookMethod) { state.read = "hook: not configured"; return false; }
        var name = cfg.hookMethod, orig = p[name];
        if (typeof orig !== "function") { state.read = "hook: no method " + name; return false; }
        if (orig.__dmaChat) { state.hooked = true; return true; }
        var wrapper = function () {
            var r = orig.apply(this, arguments);
            try { receive(fromArgs(arguments)); } catch (_) {}
            return r;
        };
        wrapper.__dmaChat = true;
        try { p[name] = wrapper; } catch (e) { state.read = "hook refused: " + e; return false; }
        if (p[name] !== wrapper) { state.read = "hook refused: assignment did not take (U5)"; return false; }
        state.hooked = true; state.read = "hook: " + name;
        return true;
    }
    function itemAt(list, i) {
        try { if (typeof list.getItemAt === "function") return list.getItemAt(i); } catch (_) {}
        return list[i];
    }
    function pollOnce() {
        var p = chatPanel();
        if (!p || !cfg.pollPath) { state.read = "poll: not configured"; return; }
        var list = pathGet(p, cfg.pollPath);
        var n = list == null ? null : Number(list.length);
        if (n == null || isNaN(n)) { state.read = "poll: " + cfg.pollPath + " is not a list"; return; }
        state.read = "poll: " + cfg.pollPath;
        if (state.pollSeen === -1 || n < state.pollSeen) state.pollSeen = n; // first sight or list was trimmed: skip history
        for (var i = state.pollSeen; i < n; i++) receive(itemAt(list, i));
        state.pollSeen = n;
    }

    /* ---------- outgoing ---------- */
    function loadHandled() {
        var lines = readLines(FILES.sent);
        for (var i = 0; i < lines.length; i++) if (lines[i] && lines[i].id) handled[String(lines[i].id)] = lines[i].status;
        var men = readLines(FILES.mentions), t;                 // 0.4.1: mentions already seen survive a restart
        for (i = 0; i < men.length; i++) if (men[i] && men[i].sender != null) {
            t = Date.parse(men[i].time) || 0;
            mentionSeen[String(men[i].sender) + "|" + String(men[i].text || "")] = t;
        }
    }
    function mark(item, status, reason) {
        var id = String(item.id);
        handled[id] = status;
        state[status === "sent" ? "sent" : status === "failed" ? "failed" : "rejected"] += 1;
        var rec = { id: id, status: status, reason: reason || "", at: nowIso(), channel: item.channel || cfg.guildChannel, text: item.text };
        if (item.to) rec.to = String(item.to);   // 0.5.12
        if (typeof item.source === "string") rec.source = item.source;
        if (typeof item.lang === "string") rec.lang = item.lang;
        if (item.ack) rec.ack = true;
        appendLine(FILES.sent, rec);
    }
    function validate(item) {
        if (!item || item.__bad) return "unreadable line";
        if (item.verbatim !== true) return "not marked verbatim";
        if (typeof item.text !== "string" || !item.text.trim()) return "empty text";
        if (item.text.length > cfg.maxTextLength) return "longer than " + cfg.maxTextLength;
        if (/[\u0000-\u001f]/.test(item.text)) return "contains a control character or line break";
        if (item.to) { if (!/^[A-Za-z0-9_ .-]{2,30}$/.test(String(item.to))) return "bad whisper name"; return null; }   // 0.5.12: a whisper
        if (item.ls === true && cfg.lsGuild !== false && (item.channel || cfg.guildChannel) === cfg.guildChannel) return null;   // 0.5.17: an approved loot-spot line (author 2026-10-31: "met ls uitnodiging en alles")
        if (cfg.whisperOnly !== false) return "guild chat off: only whispers are sent (whisperOnly)";   // 0.5.12
        if ((item.channel || cfg.guildChannel) !== cfg.guildChannel) return "only the guild channel is allowed";
        return null;
    }
    /* ---------- the chat view (0.3.0; GUI.Components::ChatPanel, read from the 0.2.1 probe) ---------- */
    function chatView() {
        try { var app = root.swmmo && root.swmmo.application; if (app && app.GAMESTATE_ID_CHAT_PANEL) return app.GAMESTATE_ID_CHAT_PANEL; } catch (_) {}
        try { var p = chatPanel(); if (p && typeof p.getViewComponent === "function") return p.getViewComponent(); } catch (_) {}
        return null;
    }
    function describeChannel(c) {
        if (c == null) return null;
        if (typeof c !== "object") return String(c);
        var out = [], names = ["name", "id", "room", "roomName", "label", "channel", "type"], i, v;
        for (i = 0; i < names.length; i++) { try { v = c[names[i]]; if (v != null && typeof v !== "object" && typeof v !== "function") out.push(names[i] + "=" + v); } catch (_) {} }
        if (!out.length) { try { out.push(String(c)); } catch (_) { out.push("?"); } }
        return out.join(" ").slice(0, 200);
    }
    var guildChannelRef = null;                               // 0.5.13: the guild channel object, as last seen selected
    function looksGuild(d) {
        d = String(d || "").toLowerCase();
        if (!d) return false;
        if (state.guildRoom && d.indexOf(String(state.guildRoom).toLowerCase()) >= 0) return true;
        return d.indexOf(String(cfg.guildChannel).toLowerCase()) >= 0 && d.indexOf("officer") < 0;
    }
    function readSelected() {
        try {
            var v = chatView(), c = v ? v.selectedChannel : null;
            state.selectedChannel = v ? describeChannel(c) : null;
            if (c && typeof c === "object" && looksGuild(state.selectedChannel)) guildChannelRef = c;   // 0.5.13
        } catch (e) { state.selectedChannel = "error: " + String(e).slice(0, 80); }
        return state.selectedChannel;
    }
    /* 0.5.14: after a restart no guild channel is remembered. Look for it in the chat view's display tree (tab
       buttons / channel views carry the channel as data, channel or room) and remember what looks like guild. */
    var guildSearch = [];
    function findGuildChannel(v) {
        var seen = 0, found = null;
        guildSearch = [];
        function look(o, depth) {
            if (!o || found || depth > 6 || seen > 400) return;
            seen += 1;
            ["channel", "data", "room", "chatChannel", "selectedChannel"].forEach(function (k) {
                if (found) return;
                try { var c = o[k]; if (c && typeof c === "object") { var d = describeChannel(c); if (guildSearch.length < 30) guildSearch.push(k + ": " + d); if (looksGuild(d)) found = c; } } catch (_) {}
            });
            var n = 0; try { n = Number(o.numChildren) || 0; } catch (_) {}
            for (var i = 0; i < n && !found; i++) { try { look(o.getChildAt(i), depth + 1); } catch (_) {} }
        }
        try { look(v, 0); } catch (_) {}
        state.guildSearch = (found ? "found: " + describeChannel(found) : "not found") + " (" + seen + " objects)";
        state.guildSearchSeen = guildSearch.slice(0, 30);
        return found;
    }
    function backToGuild() {                                  // 0.5.13: put the guild tab in front again
        if (guildSelected()) { state.backToGuild = "already guild"; return true; }
        var how = "";
        try { var v = chatView(); if (v && !guildChannelRef) { guildChannelRef = findGuildChannel(v); if (guildChannelRef) how = "found in the view"; }   // 0.5.14
              if (v && guildChannelRef) { v.selectedChannel = guildChannelRef; how = how || "remembered channel"; } } catch (e) { how = "set failed: " + String(e).slice(0, 60); }
        if (!guildSelected() && selectGuild()) how = "selectGuild";
        var ok = guildSelected();
        state.backToGuild = (ok ? "ok via " : "not done: ") + (how || "no guild channel remembered") + " at " + nowIso();
        return ok;
    }
    function guildSelected() { return looksGuild(readSelected()); }
    function enterEvent() {
        // 0.3.1: live 2026-10-25 a plain Event("enter") reached no listener that sends (unconfirmed). mx TextInput
        // turns a keyDown with keyCode 13 into its own FlexEvent.ENTER, which the chat mediator listens to.
        var rt = root.runtime || (root.window && root.window.runtime);
        var K = rt && rt.flash && rt.flash.events && rt.flash.events.KeyboardEvent;
        if (typeof K !== "function") throw new Error("no flash.events.KeyboardEvent in this runtime");
        return new K("keyDown", true, false, 13, 13);
    }
    /* 0.4.0 — U3 found in the client's own code (client.swf, BlueFire): the chat sends a PureMVC notification
       "sendMessage" (BlueFireFacade.SEND_MESSAGE) whose body is a MessageVO with room, text and groupMessage;
       SendMessageCommand fills in sender, receiver and time and hands it to XIFF. The mediator's own
       sendNotification is the public way in. Guild room only (gc_…, never gco_…). */
    function messageVoClass() {
        var n1 = "com.bluebyte.bluefire.api.model.vo::MessageVO", n2 = "com.bluebyte.bluefire.api.model.vo.MessageVO", C = null;
        try { if (root.game && typeof root.game.def === "function") C = root.game.def(n1); } catch (_) {}
        try { if (!C && root.swmmo && typeof root.swmmo.getDefinitionByName === "function") C = root.swmmo.getDefinitionByName(n1); } catch (_) {}
        try { if (!C && root.swmmo && typeof root.swmmo.getDefinitionByName === "function") C = root.swmmo.getDefinitionByName(n2); } catch (_) {}
        return C || msgCtor;
    }
    function sendViaNotify(text) {
        if (cfg.noSend !== false) throw new Error("noSend: sending is switched off");   // 0.5.10: last line of defence
        var room = String(state.guildRoom || "");
        /* 0.5.19 (live: right after a restart "2x ls GP" failed with "guild room unknown" — the room is learned from the
           first guild line): fall back to the selected guild channel's name, then to the room kept from earlier */
        if (!room) { var mS = /name=(gc_[0-9]+)/.exec(String(state.selectedChannel || "") + " " + String(state.guildSearch || "")); if (mS) room = mS[1]; }
        if (!room) { try { var kept = readJson("dma-chat-room.json"); if (kept && kept.room) room = String(kept.room); } catch (_) {} }
        if (room && !state.guildRoom) state.guildRoom = room;
        if (!room || room.indexOf(String(cfg.guildRoomPrefix)) !== 0 || room.indexOf(String(cfg.officersRoomPrefix)) === 0) throw new Error("guild room unknown: " + room);
        var p = chatPanel();
        if (!p || typeof p.sendNotification !== "function") throw new Error("chat mediator has no sendNotification");
        var C = messageVoClass();
        if (typeof C !== "function") throw new Error("no MessageVO class");
        var vo = new C();
        vo.room = room; vo.text = String(text); vo.groupMessage = true;
        p.sendNotification("sendMessage", vo);
    }
    function sendWhisperViaNotify(to, text) {   // 0.5.12: a whisper is a message whose room is the partner's name
        if (cfg.noSend !== false) throw new Error("noSend: sending is switched off");
        var p = chatPanel();
        if (!p || typeof p.sendNotification !== "function") throw new Error("chat mediator has no sendNotification");
        var C = messageVoClass();
        if (typeof C !== "function") throw new Error("no MessageVO class");
        var vo = new C();
        vo.room = String(to); vo.text = String(text); vo.groupMessage = false;
        p.sendNotification("sendMessage", vo);
    }
    /* 0.5.0 — a "Peter … RT" message is a round-trade request: recorded for the trade module (user_dma_trade.js),
       which accepts ONLY an exact mirror pair of trade mails from that sender (decision 0010). */
    /* 0.5.4: everything player-specific is read, not written into the script */
    function pol() { try { var p = root.GCAF_PlayerPolicyInstance; return p && typeof p.get === "function" ? p : null; } catch (_) { return null; } }
    function mentionWords() {
        var p = pol(), raw = null;
        try { if (p) raw = p.get("chat.words"); } catch (_) {}
        var list = (raw != null && String(raw).replace(/\s/g, "") !== "") ? String(raw).split(/[,;]/) : (cfg.mentionWords || []);
        return list.map(function (w) { return String(w).replace(/^\s+|\s+$/g, ""); }).filter(function (w) { return w.length > 0; });
    }
    var ownNameSeen = "";
    function ownName() {
        if (ownNameSeen) return ownNameSeen;
        var paths = [function () { return root.game.gi.mCurrentPlayer; }, function () { return root.swmmo.application.mGameInterface.mCurrentPlayer; },
                     function () { return root.mGeneralInterface.mCurrentPlayer; }, function () { return root.game.gi.mHomePlayer; }];
        for (var i = 0; i < paths.length; i++) {
            try { var pl = paths[i](); var n = pl && (pl.GetPlayerName_string ? pl.GetPlayerName_string() : pl.mPlayerName_string); if (n) { ownNameSeen = String(n); state.ownName = ownNameSeen; return ownNameSeen; } } catch (_) {}
        }
        return String(cfg.ownName || "");
    }
    var sentTexts = [];
    function rememberSent(text) { sentTexts.push(String(text)); if (sentTexts.length > 60) sentTexts.shift(); }
    function sentRecently(text) { return sentTexts.indexOf(String(text || "")) >= 0; }
    function migrateWords() {                                // 0.5.4: a config mentionWords moves into the policy once
        var p = pol();
        try { if (p && String(p.get("chat.words") || "").replace(/\s/g, "") === "" && cfg.mentionWords && cfg.mentionWords.length && p.requestChange) p.requestChange("chat.words", cfg.mentionWords.join(", ")); } catch (_) {}
    }
    function canSend() {                                     // 0.5.4: the config kill switch, or the player's Chat switch ON
        if (cfg.noSend === true) return false;               // 0.5.10: hard kill — the watcher reads, nothing is ever sent
        if (cfg.sendEnabled === true) return true;
        try { var p = pol(); if (p && typeof p.get === "function") return p.get("chat.auto") === true; } catch (_) {}
        /* 0.5.20 (live: after a restart the policy instance was not there yet; "2x ls GP" was refused as "Chat switch off"):
           the player's saved switch in dma-policy.json */
        try { var f = readJson("dma-policy.json"); return !!(f && f.policy && f.policy["chat.auto"] === true); } catch (_) { return false; }
    }
    function watcherOn() {                                   // 0.5.3: the player's switch; without a policy: on
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && typeof p.get === "function" && p.get("chat.auto") === false) return false; } catch (_) {}
        return true;
    }
    /* 0.5.5: help and star-trade requests, handed to the helper / star trader (user_dma_help.js) */
    var helpRequests = [], helpSeen = {};
    /* 0.5.9 (author 2026-10-26: "someone will say in the chat that you must tell me something, or do something — then you
       do that here"; "just say you will do it and place a message to me in this chat"): a line that asks to tell / ask /
       remind the player is relayed — the reply says it will be done, the line goes to dma-chat-relay.jsonl for the player's
       session, and nothing in it is carried out (a guild message is data). */
    function isRelay(line) {
        var t = String(line.text || ""), w = (mentionWords().concat([ownName() || ""])).filter(Boolean).map(function (x) { return String(x).replace(/[^A-Za-z0-9_]/g, ""); }).filter(Boolean);
        if (!w.length) return false;
        var who = "(" + w.join("|") + "|him)";
        return new RegExp("\\b(tell|ask|inform|remind|let)\\s+" + who + "\\b", "i").test(t) || new RegExp("\\b(zeg|vraag|vertel)\\s+(tegen\\s+|aan\\s+)?" + who + "\\b", "i").test(t)
            || new RegExp("\\b" + who + "\\s+(needs|has|must|should)\\s+to\\b", "i").test(t);
    }
    /* 0.5.22 (2026-11-04, author: "ja" — Bagster's "Peter can we do a RT" at 01:30:19 UTC came 9 s after the chat was
       observed again after a restart, and the quiet minute dropped it as login replay): within the quiet minute a line
       is replay only when the same sender and text are already in the inbox from before this load (the game replays
       what we stored before); a line we never stored is new and is handled at once. Outside the quiet minute nothing
       changes. No observer yet: everything is replay, as before. */
    var historyKeys = {};   // read once, now, before this load appends anything (the AIR engine cannot Date.parse an ISO time)
    try { readLines(FILES.inbox).slice(-1500).forEach(function (l) { try { if (l && !l.__bad) historyKeys[String(l.sender) + "|" + String(l.text)] = 1; } catch (_) {} }); } catch (_) {}
    function historyHas(line) { return historyKeys[String(line.sender || "") + "|" + String(line.text || "")] === 1; }
    function replayed(line, now) {
        if (!state.observedSince) return true;
        if (now - state.observedSince >= cfg.replayQuietMs) return false;
        return historyHas(line);
    }
    var relaySeen = {};
    function relayToPlayer(line) {
        var now = Date.now(), who = String(line.sender || ""), k = who + "|" + String(line.text || "").toLowerCase();
        if (replayed(line, now)) return;   // never from the login replay (0.5.22: by the inbox history, not by the clock alone)
        if (relaySeen[k] && now - relaySeen[k] < 3600000) return;
        relaySeen[k] = now;
        appendLine(FILES.relay, { time: nowIso(now), sender: who, text: String(line.text || ""), relayed: false });
        state.relayed = (state.relayed || 0) + 1;
        say("@" + who.replace(/[^A-Za-z0-9_ .-]/g, "") + ": will do!", "relay-" + now);
    }
    function isRevocation(line) { return /\b(cancel+(ed)?|undo|never\s*mind|nvm|changed my mind|reverse|take (it )?back|laat maar|terugdraaien|annuleer|niet meer nodig)\b/i.test(String(line.text || "")); }
    function isStarRequest(line) { var t = String(line.text || ""); return /star[\s-]?trade|\bstar\b/i.test(t) || /(^|[^A-Za-z0-9])ST([^A-Za-z0-9]|$)/.test(t); }
    function isHelpRequest(line) { return /\b(help|need|needs|could (you|u) (give|send|spare)|can (i|you|u) (get|have|give|send)|give me|send me|spare|hulp|nodig)\b/i.test(String(line.text || "")); }
    function helpRequest(line, kind) {
        var now = Date.now(), who = String(line.sender || ""), k = who + "|" + kind + "|" + String(line.text || "").toLowerCase();   // 0.5.7
        if (replayed(line, now)) return;   // never from the login replay (0.5.22: by the inbox history, not by the clock alone)
        if (helpSeen[k] && now - helpSeen[k] < cfg.helpRepeatMs) return;   // 0.5.8
        helpSeen[k] = now;
        helpRequests.push({ time: nowIso(now), at: now, sender: who, text: String(line.text || ""), kind: kind });
        if (helpRequests.length > 50) helpRequests.shift();
        state.helpRequests = (state.helpRequests || 0) + 1;
    }
    function isRtRequest(line) { return /(^|[^A-Za-z0-9])RT([^A-Za-z0-9]|$)|round[\s-]?trade/i.test(String(line.text || "")); }
    function rtRequest(line) {
        var now = Date.now(), who = String(line.sender || "");
        if (replayed(line, now)) return;   // never from the login replay (0.5.22: by the inbox history, not by the clock alone)
        if (rtSeen[who] && now - rtSeen[who] < cfg.rtRepeatMs) return;    // 0.5.1: the same sender asking twice within 2 min is one request
        rtSeen[who] = now;
        var req = { time: nowIso(now), at: now, sender: who, text: String(line.text || "") };
        rtRequests.push(req);
        if (rtRequests.length > 50) rtRequests.shift();
        appendLine(FILES.rtRequests, { time: req.time, sender: who, text: req.text });
        state.rtRequests = (state.rtRequests || 0) + 1;
        if (cfg.rtReply) say(cfg.rtReply.replace("{sender}", who.replace(/[^A-Za-z0-9_ .-]/g, "")), "rt-" + now);
    }
    function say(text, tag) {
        if (!canSend()) return false;
        var now = Date.now();
        sayTimes = sayTimes.filter(function (t) { return now - t < 3600000; });
        if (sayTimes.length >= cfg.sayPerHour) { note("say: hourly limit reached"); return false; }
        sayTimes.push(now);
        rememberSent(text);
        var mW = /^@([A-Za-z0-9_ .-]{2,30}):\s*([\s\S]+)$/.exec(String(text));   // 0.5.12: "@name: …" -> a whisper to name
        if (mW && /^rt-/.test(String(tag || ""))) {
            rememberSent(mW[2]);
            ackQueue.push({ id: "say-" + (tag || now) + "-" + Math.floor(Math.random() * 1e6), text: mW[2], to: mW[1], channel: "whisper", verbatim: true, ack: true });
            return true;
        }
        ackQueue.push({ id: "say-" + (tag || now) + "-" + Math.floor(Math.random() * 1e6), text: String(text), channel: "guild", verbatim: true, ack: true });
        return true;
    }
    function queueAck(line) {
        if (!cfg.mentionAck || !canSend()) return;
        var now = Date.now(), who = String(line.sender || "");
        // 0.4.1: on login the client replays recent chat history with the current time; never acknowledge
        // during the replay, nor a mention (same sender + text) already seen in the last 24 hours.
        if (replayed(line, now)) return;   // 0.5.22

        if (ackSender[who] && now - ackSender[who] < cfg.ackPerSenderMs) return;
        ackTimes = ackTimes.filter(function (t) { return now - t < 3600000; });
        if (ackTimes.length >= cfg.ackPerHour) return;
        ackSender[who] = now; ackTimes.push(now);
        var text = cfg.mentionAck.replace("{sender}", who.replace(/[^A-Za-z0-9_ .-]/g, "")).replace("{name}", (mentionWords()[0] || ownName() || "the player").replace(/[^A-Za-z0-9_ .-]/g, ""));
        rememberSent(text);
        ackQueue.push({ id: "ack-" + line.time + "-" + who, text: text, channel: "guild", verbatim: true, ack: true });
    }
    function sendViaInput(text) {
        if (cfg.noSend !== false) throw new Error("noSend: sending is switched off");   // 0.5.10
        var v = chatView();
        if (!v) throw new Error("no chat view");
        var input = v.chatInput || v.messageInput;
        if (!input) throw new Error("chat view has no input");
        if (!guildSelected()) throw new Error("selected channel is not the guild: " + state.selectedChannel);
        input.text = text;
        input.dispatchEvent(enterEvent());
    }
    function checkConfirm(now) {
        if (!pendingConfirm || now - pendingConfirm.at < cfg.confirmMs) return;
        var item = pendingConfirm; pendingConfirm = null;
        state.unconfirmed += 1;
        if (cfg.sendMode === "input") { try { var v = chatView(), input = v && (v.chatInput || v.messageInput); if (input && String(input.text) === item.text) input.text = ""; } catch (_) {} }
        appendLine(FILES.sent, { id: item.id, status: "unconfirmed", reason: "no guild echo within " + cfg.confirmMs + " ms", at: nowIso(now), channel: "guild", text: item.text });
    }

    function processOutbox(now) {
        if (!canSend()) { state.send = "disabled"; return; }
        checkConfirm(now);
        if (cfg.sendMode === "input" || cfg.sendMode === "notify") { state.send = cfg.sendMode === "notify" ? "send: notification sendMessage" : "send: input + enter"; if (pendingConfirm) return; }
        else if (!cfg.sendMethod) { state.send = "send: not configured"; return; }
        else state.send = "send: " + cfg.sendMethod;
        var lines = ackQueue.concat(readLines(FILES.outbox)), i, item, why;   // 0.4.0: acknowledgements first
        for (i = 0; i < lines.length; i++) {
            item = lines[i];
            if (item && item.__bad) continue;               // a line being written; never id-less handling
            if (!item || item.id == null || handled[String(item.id)]) continue;
            why = validate(item);
            if (why) { if (item.ack) ackQueue.splice(ackQueue.indexOf(item), 1); mark(item, "rejected", why); continue; }
            if (now - state.lastSendAt < cfg.minSendIntervalMs) return; // one per interval; rest waits
            state.lastSendAt = now;
            try {
                if (cfg.noSend !== false) throw new Error("noSend: sending is switched off");   // 0.5.10
                if (item.ack) ackQueue.splice(ackQueue.indexOf(item), 1);
                if (item.to) {   // 0.5.12: whisper
                    pendingConfirm = { id: String(item.id), text: String(item.text), at: now, to: String(item.to) };
                    try { sendWhisperViaNotify(item.to, item.text); } catch (eW) { pendingConfirm = null; throw eW; }
                } else if (cfg.sendMode === "notify") {
                    // 0.4.1: the client echoes our own line synchronously inside sendNotification, so wait for it first
                    pendingConfirm = { id: String(item.id), text: String(item.text), at: now };
                    try { sendViaNotify(item.text); } catch (eN) { pendingConfirm = null; throw eN; }
                } else if (cfg.sendMode === "input") {
                    var v0 = chatView(), in0 = v0 && (v0.chatInput || v0.messageInput);
                    if (in0 && String(in0.text || "") !== "") { state.lastSendAt = 0; return; }   // the player is typing: wait, never overwrite
                    sendViaInput(item.text);
                    pendingConfirm = { id: String(item.id), text: String(item.text), at: now };
                } else {
                    callPanel(cfg.sendMethod, buildArgs(cfg.sendArgs, { channel: cfg.guildChannel, text: item.text, time: now }));
                }
                mark(item, "sent", "");
            } catch (e) { mark(item, "failed", String(e).slice(0, 200)); }
            return;                                         // at most one per tick
        }
    }

    /* ---------- lifecycle ---------- */
    function selectGuild() {
        if (!cfg.selectMethod) { state.select = "not configured"; return false; }
        try { callPanel(cfg.selectMethod, buildArgs(cfg.selectArgs, { channel: cfg.guildChannel })); state.select = "selected via " + cfg.selectMethod; return true; }
        catch (e) { state.select = "failed: " + String(e).slice(0, 120); return false; }
    }
    function writeStatus(now) {
        state.lastStatusAt = now;
        readSelected();
        var pending = 0, lines = readLines(FILES.outbox);
        for (var i = 0; i < lines.length; i++) if (lines[i] && lines[i].id != null && !handled[String(lines[i].id)]) pending += 1;
        writeText(FILES.status, JSON.stringify({ format: "dma-chat-status/1", version: VERSION, at: nowIso(now), pending: pending, state: state,
            config: { guildChannel: cfg.guildChannel, guildRoom: state.guildRoom, readMode: cfg.readMode, sendEnabled: cfg.sendEnabled, minSendIntervalMs: cfg.minSendIntervalMs } }, null, 1), false);
    }
    var ready = false;
    var wordsMigrated = false;
    function rtAway() { try { var C = root.DMA_Control, A = root.DMA_Adventure; if (A && typeof A.learning === "function" && A.learning()) return true; try { var st = A && A.status ? A.status() : null; if (st && !st.stopped && /^(LS_|QUESTS)/.test(String(st.state))) return true; } catch (_) {} /* 0.5.18: the loot-spot phase needs the chat (read + send) */ return !!(C && typeof C.rtAwayOk === "function" && C.rtAwayOk()); } catch (_) { return false; } }   // 0.5.15; 0.5.16: also while a demonstration is learned
    function visitHold() { try { var C = root.DMA_Control; return !!(C && C.visit && C.visit.held()); } catch (_) { return false; } }   // 0.5.11 (ADR 0030)
    function tick(now) {
        if (visitHold() && !rtAway()) return;   // 0.5.11: a visit hold stops the watcher too (it listens on the ZONE channel); 0.5.15: not during our adventure fight
        if (!wordsMigrated && pol()) { wordsMigrated = true; migrateWords(); ownName(); }   // 0.5.4
        now = now || Date.now();
        if (!cfg.enabled) return;
        state.panel = !!chatPanel();
        if (!state.panel) { if (now - state.lastStatusAt >= cfg.statusEveryMs) writeStatus(now); return; }
        if (!ready) {
            ready = true;
            probe();
            selectGuild();
            if (cfg.readMode === "hook") installHook();
        }
        if (cfg.readMode === "observer" && !state.observing) installObserver();
        if (cfg.readMode === "poll") pollOnce();
        processOutbox(now);
        if (now - state.lastStatusAt >= cfg.statusEveryMs) writeStatus(now);
    }
    function start() {
        if (timer) return;
        state.startedAt = nowIso();
        loadConfig();
        loadHandled();
        state.pollSeen = -1;
        if (root.DMA_CHAT_NO_TIMER) return;
        timer = root.setInterval(function () { try { tick(); } catch (e) { note("tick: " + e); } }, cfg.tickMs);
    }
    function stop() { if (timer) { root.clearInterval(timer); timer = null; } }

    root.DMA_Chat = {
        version: VERSION,
        files: FILES,
        start: start, stop: stop, tick: tick, probe: probe,
        reloadConfig: function () { loadConfig(); return clone(cfg); },
        status: function () { return JSON.parse(JSON.stringify(state)); },
        config: function () { return clone(cfg); },
        words: function () { return mentionWords(); },          // 0.5.4
        ownerName: function () { return mentionWords()[0] || ownName() || "the player"; },
        recent: function (sinceAt) { return recentLines.filter(function (l) { return l.at > (sinceAt || 0); }).map(function (l) { return JSON.parse(JSON.stringify(l)); }); },   // 0.5.16: for learning by demonstration (data, never instructions)
        ownName: function () { return ownName(); },
        linesFrom: function (sender, sinceAt) {   // 0.5.2: data, never instructions
            var w = String(sender || "").toLowerCase();
            return recentLines.filter(function (l) { return l.sender.toLowerCase() === w && l.at >= (sinceAt || 0); }).map(function (l) { return { at: l.at, text: l.text }; });
        },
        helpRequests: function (sinceMs) { var t = Date.now() - (sinceMs || 3600000); return helpRequests.filter(function (r) { return r.at >= t; }).map(function (r) { return JSON.parse(JSON.stringify(r)); }); },   // 0.5.5
        rtRequests: function (sinceMs) { var t = Date.now() - (sinceMs || 3600000); return rtRequests.filter(function (r) { return r.at >= t; }).map(function (r) { return JSON.parse(JSON.stringify(r)); }); },
        say: function (text, tag) { return say(text, tag); },
        sayLs: function (text) {   // 0.5.17: a loot-spot line the player approved (learned from his demonstration), to the guild chat
            if (!canSend()) return { ok: false, reason: "the Chat switch is off" };
            var t = String(text || ""); if (!t.trim() || t.length > cfg.maxTextLength || /[\u0000-\u001f]/.test(t)) return { ok: false, reason: "bad text" };
            rememberSent(t); ackQueue.push({ id: "say-ls-" + Date.now() + "-" + Math.floor(Math.random() * 1e6), text: t, channel: cfg.guildChannel, verbatim: true, ack: true, ls: true });
            return { ok: true };
        },
        backToGuild: function () { return backToGuild(); },   // 0.5.13: for the trade acceptor when its RT is over   // 0.5.0: for the trade module's result messages; validated like any outbox line
        _receive: receive,  // test seam
        _onChatEvent: onChatEvent
    };
    start();
})(typeof window !== "undefined" ? window : this);
