# 2. The DMA Console: a tour

Open it from the client's **Tools** menu: **DMA Console**. It is one window. The main screen shows the state of your
island; twelve buttons along the bottom open the pages (the last one, **FEEDBACK**, makes a report for Discord: see [07-reporting.md](07-reporting.md)). The pages have a **Back** button in their footer that returns to the main screen,
and the window's **Close** button closes the whole console. DMA keeps working
when the console is closed; the console is only a view with some controls.

Changes you make on any page are saved at once in `dma-policy.json`. A change that DMA refuses (for instance a number
outside the allowed range) is shown in red next to the control, with the reason, and the old value comes back.

## The main screen

From top to bottom:

1. **The switch bar.** One small switch per self-starting part of DMA. Dark = off, lit = on. All are **off** in a new
   installation. Hover a switch to see what it controls.

   | Switch | Key | What it switches on |
   |---|---|---|
   | Island | `island.auto` | The location manager: it observes your island and keeps the one picture all others read |
   | Geo | `geo.auto` | The specialist manager for geologists: sends them to search for deposits |
   | Expo | `expo.auto` | The specialist manager for explorers: sends them on expeditions |
   | Build | `build.auto` | The building manager: builds mines |
   | Upgrade | `upgrade.auto` | The upgrade (construction) manager: upgrades mines to their target level |
   | Buff | `buff.auto` | The buff manager: buffs mines and production buildings |
   | Demolish | `demo.auto` | The demolish manager: demolishes mines that have run low |
   | Chat | `chat.auto` | The chat watcher: replies when your chat reply word is used, takes in RT requests |
   | Mail | `mail.auto` | The mail manager: collects explorer loot mails |
   | Quest | `quest.auto` | The quest manager: claims finished quests, picks up collectables |
   | Event | `event.auto` | The event manager: fills event buildings, event buffs, counters, event quests |
   | Trade | `trade.auto` | Round trades, help trades and star trades, by the rules on the TRADE page |
   | Troops | `troops.auto` | The troop manager: keeps the army at its target strength |
   | Supply | `supply.auto` | The resource supply manager: a short resource is made, raised, or (if allowed) bought |

   The switches Troops, Supply and Event appear in the bar because the program lists them as switches; if your console
   shows fewer, the version line tells which console version you have. Zombie hunt and Premium have **no switch** in the
   bar: they are settings (`zombie.auto`, `premium.setting`), see [03-features.md](03-features.md).

2. **Idle geos, Demolish Threshold and Chat reply word.** *Idle geos* is a counter of geologists waiting.
   *Demolish Threshold* (`demolish.threshold`) is the amount left in a deposit at or below which a mine may be
   demolished by the Demolish switch (when the field is empty the program uses 20). *Chat reply word* (`chat.words`) is the word in a guild message that makes the chat
   watcher answer, normally **your own name** (for example `Joe`; several words separated by commas). It is empty in a
   new installation, so the chat watcher answers nobody until you fill it in.

3. **The actors line.** One short entry per self-starting part: its name, its state (`off`, `blocked`, `idle`,
   `acting`, `error`) and the reason when it is not acting. Hover for more. This is where you see *why* something does
   not happen ("switch off", "waiting for stock", "visit hold").

4. **The version line.** The loaded modules and their versions.

5. **The main table.** One row per resource of your home island. The columns, from the left: the resource (click the
   row to open its slots), **have** (mines / masons you have), **cap** (how many the game limits you to; read-only),
   **status**, **free** (free deposits), **buffed** (buffed mines / masons), **time**, one more cell, **GEO** and
   **UPG**. The cells under *time* and the one after it show a dash for now. The two last columns are the editable ones:
   - **GEO** is a drop-down with the **geologist type** that searches for this resource: *(auto)* (no type chosen for
     this resource: the general preferred type `search.preferredType` if you set one, otherwise any geologist) or one
     of the types (Geologist, Jolly Geologist, ...). It is the rule `geo.<Resource>`.
   - **UPG** is the **upgrade target level** for this resource, the rule `upg.<Resource>`. The drop-down starts with
     the dash (**no target**) and then offers the levels **1 up to the maximum level of the construction type** (6 for
     the mines, 7 for the stone, marble and granite quarries). The program never orders a level above the registered
     maximum of the type, even when the game itself reports a higher one. **A new installation shows the dash for every
     resource: nothing is upgraded until you choose a level** (and the **Upgrade** switch is on). Choosing the dash
     again removes the target.
   Click a row to see its slots (grid, status, time) and to jump to a building.

6. **The log.** The latest messages of the console. **Copy log** copies it; send it with a report.

**Footer buttons:** SPEC, BUFF, TRADE, MAIL, QUEST, ADVS, EVENT, VALUE, TROOPS, TX open the pages; **Refresh** re-reads
the island; **Copy log**; **Close**.

## SPEC: specialists

Three tabs, one for **geologists**, **explorers** and **generals**.

- Each tab lists your specialists with the skills the game reports for them, and the books (Manuscript, Tome, Codex)
  that the next skill needs, against your stock (green = enough, red = not enough).
- **Geologists:** per type you can set the skills by hand. A "recommended build" does **not exist** in this release: the
  preset builds of the author's island were removed (decision 0078), so the button reports "no recommended build for
  <type>". The skills you set by hand are kept.
- **Explorers:** an *explorer template* (`expo.template`: Daily, Event or Adventure) with an **Apply** button, and a
  per-type task ("Set type"). The default is **Daily**. Explorers that are not fully skilled are listed; they are sent
  anyway unless you set "skill first" for them.
- **Skilling and naming:** per kind a rule to skill first, and a prefix/suffix for the names. Renaming all specialists
  asks for a confirmation first.

Needs the **Geo** or **Expo** switch for anything to happen. Looking is free.

## BUFF

> **Read this before you press Apply.** On this page **Apply** is not only "save my choice". It saves your choices *and*
> asks DMA to buff the mines you chose a buff for, **at the next cycle (within about half a minute) and also when the
> Buff switch is off.** A buff is a game item that is used up. Press Apply only for choices you mean to be carried out
> now.

**What the page shows.** *Every* building of your home island (not only the unbuffed ones), one row each: building,
level and a drop-down with the buffs in your star menu (with the amounts you have). The line above the list ("N
unbuffed, M selected") counts the rows shown by the filter, not only the unbuffed buildings: a building that carries a
buff already is still listed. At the top: the checkbox *Use Bag of Rainbow Snow only on endless mines* (on by default;
it only steers **Suggest**), a **Filter** box (part of a building name), a category selector (All, Mines, Masons,
Production, Residence), **Apply to all** with a buff drop-down and the button **Set**, and **Select unbuffed**. The
summary table lists the buffs in your star menu with their bonus, duration and how many of them your choices use (red =
more than you have). **When the page opens, every row of a building type for which you saved a preference already shows
that buff as its choice.** Pressing Apply straight away therefore asks for a buff on every unbuffed mine of such a type.

**What each control does.**

| Control | What it does | Saved? | Sends a buff? |
|---|---|---|---|
| Drop-down per building | Chooses the buff for that building in the page. | no | no |
| **Suggest** | Fills the choices: highest building level first, each building gets the strongest buff it can take that is still available. Respects the filter and the Rainbow Snow box. | no | no |
| **Select unbuffed** | Chooses the first buff in the list for the rows (matching the filter and category) that carry no buff and have no choice yet. | no | no |
| **Take current** | Reads the buff that a building carries right now and makes it the choice (rows matching the filter). | **yes, at once**: the preference of the building *type* | no |
| **Apply to all ... Set** | Chooses that buff for all rows matching the filter text. | **yes, at once**: the preference of every building *type* in those rows (with an empty filter: every type) | no |
| **Apply** | See below. | yes | **yes, for mines** |
| **Back** | Returns to the main table. | - | - |

**What Apply does, exactly.**
1. For every row with a choice it saves the **preference for the building type** (`buff.prefs`: building name -> buff).
   Several rows of one type with different choices: the last row of that type wins. The preference is what the **Buff
   switch** uses when it buffs buildings of that type; saving it sends nothing.
2. It writes the list of **per-building requests** (building, buff) that DMA keeps in the client's browser store
   (`dma.buffRequests.v1`; the list is replaced by every Apply).
3. At its next cycle the **construction manager** reads those requests. For each request on a **mine, mason or quarry
   slot** that is **not buffed**, not upgrading and without an order on its way, it asks the buff applier to send the
   buff you chose (transaction TK41). **This happens even when the Buff switch is off**: a request is your explicit
   order. A request on any other building (a production building, a residence) is not carried out; only its type
   preference is saved. A request is dropped once the building carries a buff.
4. The buff is sent only through the **Game Interface Adapter**, which refuses a building that already carries a buff
   (unless the buff is one that replaces the running one, by the registered buff actions), a tribute (`*_Mini`) and a
   building it does not know. Nothing is sent to a buffed building. A refusal is shown in the log and on the TX page.

The value "none" for a type (never buff this type) is read by the buff manager, but this page does **not** offer it: a
dash means "no choice" and saves nothing.

## TRADE (and its help page)

The rules for guild trades, with the actual numbers beside them: **Max per item** (`trade.cap`), **Safety margin**
(`trade.marginPct`), waiting times (`trade.waitMin`, `graceMin`, `expireMin`, `acceptMin`), how often more time may be
asked (`trade.extensions`), requests per player per hour (`trade.perSenderHour`), and the ask interval for star trades
(`trade.ask.everyMin`). Ticks for **round trades** (`trade.rt.on`), **help trades** (`trade.help.on`) and **star
trades** (`trade.star.on`). A second block holds the help rules per player level and the star-trade rules (`help.*`,
`star.*`). The HELP sub-page lists what a guild member can say to you ("Joe help 5K stone", with your own chat reply
word). Needs the **Trade** and **Chat** switches.

## MAIL

Four ticks for the kinds of explorer loot mail DMA may collect (treasure, adventure finds, map fragments, expedition
loot), with how many are waiting and how many were collected. The mailbox is opened at most every 30 minutes
(`mail.everyMin`, see [04-settings-reference.md](04-settings-reference.md)).
Untick a kind to leave it in your mailbox (for instance during an event). A further setting (`mail.loot.toStorage`) sends
loot to the storage instead of the star menu. No other mail is ever touched. Needs the **Mail** switch.

## QUEST

The quest manager's page. Shows the Event switch and the Quest switch with every category you may tick: guild, daily,
weekly, ghost ship, starfall, event, main, side, building-bonus loops, and the actions *claim*, *start*, *collect*
(collectables), *icons* (pick up the icons over buildings), *pay* (pay a guild quest from storage), *pick-up*. Below it
the table "What the quest manager watches" (per category: on, open, rewards ready, needs you) and the executors per task
kind. A **collect now** button picks up collectables at once. Needs the **Quest** switch (and **Event** for event quests).

## ADVS: adventures

Per adventure (Arctic Explosion **AE**, Ali Baba the Young Woodcutter **YWC**, The Valiant Little Tailor **VLT**, Ali Baba
and the First Thief **FT**, Gunpowder **GP**, and your own **OWN**): an on switch, the number of runs in a row, the
templates it plays, the stock to keep in your star, loot spots, and the army checks. A card **All adventures** lists the
adventures in your star. The general rules (`adv.*`) sit at the top. All adventure switches are **off**, and adventures
play only from your own Mundane templates; none are supplied.

**Versions and their kinds.** Open an adventure (▶) to see its versions. **New version** asks for a kind:

| Kind | What it is |
|---|---|
| **blocks** | Templates with block entries. Needs *ALL: allow blocks* (`adv.blocks.on`). |
| **without blocks (waves)** | Each attack template is one wave. A camp starts as soon as no other live camp watches the way of its attacker; on each camp the main leaves only when its wave is fighting. After a wave the same generals come back, recover and are loaded for the next wave. Block entries are refused. |
| **camp by camp** | One camp at a time, in the template's order. |
| **own Mundane** | Your own Mundane folder, analysed and played. |
| **author's Mundane** | A shared folder (with a `generals.json`). The analysis checks your generals against it: the same general, the same type equally skilled, the same type with fewer skill points, an alternative general whose capacity holds the army (not simulated), or none. Camps nobody of yours can cover are named. |

**Advice.** Some adventures carry advice, shown in orange in the open row. *Bonaberti Business: do not use blocks.* A
Bonaberti version that has block entries gets a warning in its analysis.

**Finish camp by camp (emergency).** Next to **Stop**, and in the open row of an adventure that has a version. It ends an
adventure whatever version it was started with: a run going on switches to camp by camp at its next step; a stopped run
resumes the open adventure camp by camp. One camp at a time, the retreat on interception stays on. A camp whose way is
still watched waits while another camp whose way is clear goes first. It stops when no remaining camp can be reached or
when a camp survives all its attackers; check your losses, then press it again.

## EVENT

The running events and their rules: fill switch, event buffs ("buff its buildings"), the buildings' base rates, the
buffs you exclude, the counters, and the names the game uses for the event. Shows the "Parts of the event": which part
is on, who executes it, and whether it "needs you" (no executor). Needs the **Event** switch (and **Buff** for event
buffs).

## VALUE

A read-only list of every good with its value through the production chain, in building-minutes and in coins. Nothing
here acts. A notice appears when the game's definitions differ from the ones DMA carries.

## TROOPS

Per unit kind: the army (free units), what is in training, and an editable **target strength** with the shortfall. The
three buttons Normal, Elite, Expedition show or hide a group (your choice is remembered). The cell colours: red = below
target and nothing in training, orange = below target and in training, green = on or over target. Expedition units have
no editable target. Needs the **Troops** switch.

## TX: transactions

Every transaction DMA knows, with its real status ("requested", "promised", "declared", "accepted" ...), grouped by
kind, with a kind filter, an "open only" tick, a **Live** tick and **Refresh**. Click a row to open its history. This is
the page to read when you ask "what exactly did DMA do?", and the data behind it is in `dma-transactions.json` (see
[05-files.md](05-files.md)).

## RULES: every business rule

Every rule DMA follows is on this page, grouped (switches, island scan, client and mines, quest book, trades, short
resources and the trade office, premium and zombie hunt, adventures, troops, safety) and filterable: type a word of the
rule or of its key in the filter field and press Enter. Each rule has the control that fits it:

| Kind | Control |
|---|---|
| on / off | a tick |
| number | a field, with the allowed range next to it (a value outside it is refused in red) |
| choice | a drop-down list (for example `premium.setting`: off / always / event) |
| text | a field |
| a list of resources | a **choose…** button that opens a checklist: the goods grouped as *raw* (made without inputs), *made* (from inputs) and *other goods in your storage*, with a filter, and *all* / *none* per group; **Save** stores your choice |

A rule that has a value **and** an on/off is two rows: the on/off says whether the rule is applied at all, the value
says how. Example, the trade office: *wait until a resource has been short for a while* (on/off) and *a resource must
be short for at least … minutes* (30); *apply the market-price ratio* (on/off) and *at least … times better than the
market price* (1.5); *apply the never-pay list* (on/off) and *never pay with these resources* (Oilseed, Oil).

A change is saved at once (green line at the top) or refused with its reason (red). Nothing on this page acts by
itself: a rule only matters when its part's switch is on.

## Reading what the console tells you

| You see | It means |
|---|---|
| A switch is dark | That part does nothing at all |
| Actor state `off`, reason "switch off" | Same |
| Actor state `blocked` | It would act but a guard says no; the reason says which |
| Actor state `idle` | On, and nothing to do now |
| Actor state `acting` | It is working now |
| Actor state `error` | Something failed; copy the log into your report |
