# 3. The features, one by one

For every feature this page says **what it needs**, **what it spends**, **what guards it** and **how to stop it**.
The keys in `code style` are the settings of [04-settings-reference.md](04-settings-reference.md). A feature is only
active when its switch is on; in a new installation **all are off**.

**How to stop any feature:** switch it off in the switch bar (or untick it on its page). It stops giving new orders at
its next turn. Orders already given to the game (a building under construction, a trade already sent, a geologist
already travelling) are carried out by the game and are not recalled.

## Island (observing)

- **What it does.** Reads your home island once at start-up and then follows the game's events, so that all other parts
  work from one and the same picture. Nothing else scans or polls.
- **Needs.** Nothing. **Spends.** Nothing; it only reads.
- **Guards.** It pauses while you travel to or stand on another island (`location.scan.pauseAway`, resumes 60 s after
  you are home, `location.scan.resumeSec`). A **visit hold** puts all work on hold automatically when you visit another
  island (`location.visit.auto`, ends by itself after at most 120 minutes, `location.visit.maxMin`). At start-up all
  work waits 180 s for the island to load (`location.startup.holdSec`).
- **Stop.** Switch Island off. Everything that depends on the picture then has nothing to act on.

## Geo: geologists

- **What it does.** Keeps your deposits filled: when a resource has fewer mines than spots (plus mines that will run out
  soon), it sends an idle geologist to search. For iron and marble at their proven limit it may send one geologist with
  Lucky Find to look for the one extra deposit.
- **Needs.** An idle geologist; a resource that you allow (`search.resourcesEnabled`, by default Stone, Bronze Ore,
  Marble, Iron Ore, Gold Ore, Coal, Granite, Titanium Ore, Saltpeter) and, by default, only the operational sectors of
  your island (`search.inPlayOnly`).
- **Spends.** Geologist time. Nothing else. (Skill books are spent only if you skill by hand on the SPEC page.)
- **Guards.** At most the number of searches the gap requires; never more than the capacity the island has shown;
  a preferred geologist type (`search.preferredType`) when you set one.
- **Stop.** Switch Geo off.

## Expo: explorers

- **What it does.** Sends idle explorers on the task of the active **template** (`expo.template`: Daily, Event or
  Adventure; default **Daily**) and the per-type task you set on the SPEC page.
- **Needs.** An idle explorer.
- **Spends.** Explorer time. Books are spent **only** when explorers are skilled automatically ("skill first" set for a
  specialist) and the books are in stock. Explorers that are not fully skilled are sent anyway.
- **Guards.** One transaction per send, recorded; quest searches are ordered by the quest manager, not by guesswork
  (see Quest).
- **Stop.** Switch Expo off.

## Build: building mines

- **What it does.** Builds a mine where a resource is furthest below its capacity, richest deposit first.
- **Needs.** A free deposit spot, a free slot in the build queue, and **all** the materials in your storage. If one
  material is missing, the build is declined with the reason ("missing 40 Marble") and nothing is spent.
- **Spends.** The build materials of the mine (for example a Copper Mine: 30 pine planks and 45 stone).
- **Guards.** Only building kinds on the verified list; one construction per free queue slot; a resource that lacked
  materials is skipped for a while (10 minutes).
- **Stop.** Switch Build off. A mine already under construction is finished by the game.

## Upgrade: raising mines to their target level

- **What it does.** Upgrades a mine that is below its target level, one level at a time.
- **Needs.** A target level for the building kind (the BUFF/main table cells `upg.<resource>` and the per-kind rules
  `building.upgradeLevel.<Building>` / `ctype.<Kind>.targetLevel`) and the upgrade materials and tools in storage.
  Without a target nothing is upgraded.
- **Spends.** The upgrade materials and tools of each level.
- **Guards.** **Never above the building's maximum level** (the maximum per kind is part of the verified list). Never
  tributes, mini mines or endless mines. A new building kind the list does not know is declined and reported once.
  Every upgrade is written to the upgrade ledger (`dma-upgrade-ledger.json`) so that the same order is not sent twice.
  An upgrade the game did not start within 2 hours is revoked (`rule.R-UPG.revokeHours`).
- **Stop.** Switch Upgrade off.

## Buff: buffing mines and production buildings

- **What it does.** Buffs a mine that stands at its target level, is not buffed, not upgrading and not busy. A second
  rule (R-BUFF-PROD) does the same for production buildings that are producing. A third starts your highest-level
  **Love Tree** as soon as its cooldown has ended.
- **Needs.** Buff items in your star menu (stock above the minimum of 20 kept for production buildings).
- **Spends.** Buff items from your star menu: your choice per building type (BUFF page), otherwise the strongest buff the
  game accepts. Event buffs are used only when you tick them on the EVENT page.
- **Guards.** **Never buffs a building that already carries a buff.** At most 3 buffs per turn. Rainbow Snow only on endless
  mines (tick on the BUFF page). A type set to "none" is never buffed. The game's own check (is this buff applicable?)
  decides before an order is sent.
- **One exception to the switch: the BUFF page's Apply.** Buffs you choose per mine on the BUFF page and confirm with
  **Apply** are carried out at the next cycle **also when the Buff switch is off**, for mines, masons and quarries that
  carry no buff (see the box at the top of the BUFF page in [02-console-tour.md](02-console-tour.md)).
- **Stop.** Switch Buff off. That does not cancel buffs you already asked for with Apply; to withdraw them set the rows to the
  dash on the BUFF page and press Apply again (the list of requests is replaced by what the page holds).

## Demo: demolishing low mines

- **What it does.** Demolishes a mine whose deposit is empty, or has run down to the threshold, when a replacement
  exists or is on its way, so that the new find has room.
- **Needs.** The threshold (`demolish.threshold`; when it is empty the program uses 20).
- **Spends.** The mine. A demolition returns 25 % of the build cost, whatever the level. **A demolition cannot be undone.**
- **Guards.** Only verified building kinds; never tributes or endless mines; one demolition per replacement; if the
  remaining amount cannot be read, it declines ("no remaining fact") rather than guess.
- **Stop.** Switch Demo off. If you are not sure, **leave Demo off** during the first days.

## Chat and Trade: round trades (RT)

- **What it does.** A guild member asks you for a round trade (in the guild chat, with your chat reply word, or by
  whisper). DMA promises it, waits for the trades the member sends you, **accepts them**, sends back exact mirror trades,
  and declares "RT done". After 30 minutes of silence it counts the RT as accepted.
- **Needs.** Switches **Chat** and **Trade**, and your **chat reply word** set on the main screen, and `trade.rt.on`
  (on by default once Trade is on).
- **Spends.** The goods you send back, which equal what you received. Both trades net to zero. Your stock must cover
  both sides, plus a safety margin (`trade.marginPct`).
- **Guards.** Per item at most `trade.cap` (100). At most 2 requests per player per hour. A trade that does not match is
  **declined with the reason**. **All replies go as whispers** to the member, never to the guild chat. The member can
  withdraw by whispering "close it" (also "forget it", "no need", "leave it", "skip it", "no rt"); DMA then revokes the
  request. More time is given when the member addresses you ("Joe, wait"), at most 3 times.
- **Stop.** Switch Trade or Chat off, or untick round trades on the TRADE page.

## Trade: help trades and star trades

- **What they do.** *Help trade:* a guild member asks you for a resource ("Joe help 5K stone"); DMA gives it for a
  small payment (`help.costRes`, default 1 Fish). *Star trade:* a trade through the star between two players.
- **Needs.** Switch Trade, and **their own ticks** (`trade.help.on`, `trade.star.on`), both **off** by default.
- **Spends.** The resources given. The gift limits depend on the **asker's level** (`help.t1` ... `help.t4`: times per
  day, per week, maximum per request), keep a floor of 100,000 in stock (`help.floor`), and never more than 20 % of the
  stock in one gift (`help.floorPct`).
- **Guards.** The limits above, requests per player per hour, a plenty rule when your storage is nearly full.
- **Stop.** Untick help/star on the TRADE page, or switch Trade off.
- **Asking yourself.** `trade.ask.on` (star trade when a storage is full) and `trade.rt.ask.on` (ask the guild for a
  round trade) make DMA **write in the guild chat on its own**. Both are **off**; set them on the RULES page.

## Supply: short resources and the trade office

- **What it does.** When a resource runs short it first makes it itself (`supply.make.on`), then raises production
  (build, upgrade or buff a maker, `supply.produce.on`). Optionally it **buys at the trade office** and, as a last
  resort, **asks a guild member to sell** it.
- **Needs.** Switch Supply. Buying needs **more**: `supply.office.on` (off by default) **and** a file
  `dma-trade-office-confirmed.json` with `{"confirmed": true}` next to the client. **That file is not in the pack, so
  nothing is ever bought in this test.** Do not create it unless the developers ask you to; it will become a tick on the
  RULES page once the buyer has been proven on a real purchase.
- **Spends.** (Only with the confirm file.) Goods to pay the offer.
- **Guards (each one is your rule, on the RULES page).** Only when the resource has been short for 30 minutes
  (`supply.office.afterMin`, with its on/off); only an offer at least 1.5 times better than the **market price** the
  console has seen in the trade office (`supply.office.minMarketRatio`, with its on/off — off means the price is not
  checked); **never paying with** the resources on your never-pay list (`supply.office.neverPay`, a checklist, default
  Oilseed and Oil, with its on/off); never above 100 % of the value list for a guild purchase
  (`supply.office.maxPricePct`); at most 3 purchases a day. Asking a guild member to sell is off by default
  (`supply.guild.on`), only after own making had 120 minutes (`supply.guild.afterMin`, with its on/off), at most 2 a day.
- **Stop.** Switch Supply off.

## Mail: collecting loot

- **What it does.** Opens the mailbox at a quiet moment (at most every 30 minutes) and collects explorer loot mails of
  the kinds you ticked: treasure, adventure finds, map fragments, expedition loot.
- **Needs.** Switch Mail. **Spends.** Nothing. **Guards.** No other mail is ever touched; the kinds are ticks on the MAIL page.
- **Stop.** Switch Mail off.

## Quest: the quest book

- **What it does.** Claims finished quests, starts new ones, picks up collectables and the icons over buildings, pays a
  guild quest from storage, picks up finished productions, and routes the explorer searches of a quest to the explorer
  manager, which sends the **fastest explorer**.
- **Needs.** Switch Quest.
- **Spends.** Only for quests you tick: the goods a **guild quest** asks, paid **from your storage** (`quest.pay.on`),
  and explorer time for search quests. **Never gems.**
- **Guards.** **Only the ticked categories** (`quest.do.*`); event quests also need the Event switch; reward claims
  and starts have their own ticks (`quest.claim.on`, `quest.start.on`). A quest with a task that needs you stays in the
  "needs you" column.
- **Stop.** Switch Quest off, or untick a category.

## Event

- **What it does.** While an event runs (for example Halloween): fills the event buildings, buffs them when you ticked
  that, swaps counter buffs ("tricks" for "treats"), and takes up event quests.
- **Needs.** Switch Event; for event buffs also Buff. **Spends.** Resources to fill event buildings, buffs from the star.
- **Guards.** Each part has its own tick on the EVENT page, and you can exclude buffs per event.
- **Stop.** Switch Event off.

## Troops

- **What it does.** Keeps the army at a **target strength per unit kind** (TROOPS page). It reorders a barracks' training
  rows so the units you need are trained first, and adds rows when units are short.
- **Needs.** Switch Troops and a target (without a target nothing happens). **Spends.** The training cost of the added rows.
- **Guards.** Never while the queue waits for the server, never the row in production, never away from home. **Nothing
  is cancelled**; it only reorders.
- **Stop.** Switch Troops off.

## Zombie hunt

- **What it does.** Attacks zombie camps (crypts) when they appear, with up to four generals nearest to the crypt.
- **Needs.** `zombie.auto` set to on (no switch in the bar; a setting) and generals loaded with units. `zombie.generals`
  names the generals; empty = the four it chooses itself.
- **Spends.** Troops lost in the fights.
- **Guards.** Only a general with a path to the crypt; a general whose attack did not start is not sent again to that crypt.
- **Stop.** Set `zombie.auto` off.

## Premium

- **What it does.** Applies a premium item from **your star menu** a few minutes before premium ends (the shortest item first).
- **Needs.** `premium.setting` = `always` or `event`. **Spends.** One premium item, at most one per 15 minutes.
- **Guards.** **No shop and no gems.** Only on the home island.
- **Stop.** Set `premium.setting` to `off`.

## Adventures

- **What they do.** Run an adventure through the Mundane templates you own, with the star method, loot spots
  offered to the guild (offers appear in the guild chat, for example "2x ls GP"), and advice which adventure
  fills a stock that runs out (`adv.loot.*`).
- **Needs.** The adventure on (`adv.<name>.on`, ADVS page), templates, and the adventure in your star.
- **Spends.** The adventure item, **troops lost in the fight**, instant-destroy buffs. A *block* can lose its army;
  blocks are off by default (`adv.blocks.on`).
- **Guards.** The army must be full before sending (`checkArmy`), a minimum of adventures to keep in the star
  (`minStock`), a retreat on interception, a refusal of a step that a watched camp would break.
- **Kinds of version.** blocks, without blocks (waves, generals reused), camp by camp, own Mundane, author's Mundane
  (checked against your generals). See [02-console-tour.md](02-console-tour.md#advs-adventures).
- **Advice.** Bonaberti Business: do not use blocks. The full chapter, with the five phases, the star method, the load
  margin and Bonaberti Business in two waves step by step, is [09-adventures.md](09-adventures.md).
- **Stop.** Untick the adventure on the ADVS page, or press **Stop** on a running adventure.
- **Emergency.** **Finish camp by camp** ends any open adventure one camp at a time, whatever its version.

## Workflows: Deposit Cycling

A **workflow** is a set of DMA's existing roles and rules that you switch on for spots you pick. The first one is
**Deposit Cycling**, from Zingu's scripts (Copper.js and Iron_Deligent.js). It is for the **extra loot**: special
geologists bring treasures and items with a successful search, and a search only succeeds when there is a free spot for
its deposit when it ends. Deposit Cycling keeps your picked spots free, so those geologists can keep finding.

### How one cycle goes

1. A geologist from the workflow finds a deposit on a picked spot. The loot comes with that find (in your mail).
2. DMA builds a mine on the deposit.
3. DMA **waits until the mine is finished**, then demolishes it. A finished mine that is demolished takes its deposit
   with it, so the spot is empty again (measured: about 5 seconds). A mine demolished *while it is still being built*
   leaves the deposit behind, and the spot stays full; that is why DMA always waits.
4. The spot is empty, so the next search can succeed. Back to 1.

If a deposit does stay after DMA's demolish, DMA builds there again once; if it still stays, DMA stops on that spot and
writes "deposit stays after demolition" in the facts. It never loops.

### Which geologists

Use the same types as the scripts. Only these types bring the loot the scripts are for:

| Resource | Geologist types (type number) | Loot |
|---|---|---|
| Copper | Gingerbread (76), Geologist on Vacation (80), Marathon (89) | items, copper surplus |
| Iron | Diligent (59) | "Two treasures" |

The names DMA shows are read from the game itself.

### The WORKFLOWS page

Open it with the **WORKFLOWS** button. The page opens as an overview: one line per workflow, and per resource whether it
is on, its spots (with your labels), the geologists kept for it and the cycles done. Click a line to open its settings.
For each mine resource (copper, iron, gold, coal, titanium, saltpetre) you set:

- **on**: off by default.
- **Start**: *when your mine on the spot runs empty or is demolished* (default), or *now*: DMA demolishes your basic mine
  on a picked spot at once. Only a basic mine; never an industrial, endless or tribute mine.
- **Spots**: every spot where that resource can appear, the same on every home island, in a fixed order (Copper 1,
  Copper 2, ...). Give a spot your own label (for example "Cycle Cu 1"); the label stays, whether a deposit is there or
  not, and is shown wherever the spot is shown. Tick the spots the workflow may use.
- **Geologists**: the types (see the table above) and **how many** (0 = all of those types). While the workflow is on,
  these geologists are kept for it; DMA's normal searching does not use them.
- **Build queue**: how many places stay free for your regular building (default 1).
- **Reserve**: stop building while any good of the mine's build cost would fall below this amount (default on, 1000).

### Safety, always on

- DMA demolishes only a **basic** mine: the one this workflow built itself (level 1, finished), or, with Start *now*,
  yours on a picked spot. Industrial, endless and tribute mines are never touched.
- Picked spots are not used for production while the workflow is on: DMA does not build, upgrade, buff or demolish there
  for production, and DMA's normal deposit search does not fill them.
- A search is only sent when a picked spot will be free when the search ends.

### What it costs

Every cycle builds one mine (planks, stone and the other build goods of that mine). Keep the reserve on. Watch the stock
of the build goods for the first hours.

## What every part writes down

Every act is recorded as a transaction (see TX) and as a line in the daily facts file. That is how you check afterwards
what DMA did.
