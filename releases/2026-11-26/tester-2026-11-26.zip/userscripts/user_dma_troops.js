/*
 * Stable client filename: user_dma_troops.js
 * DMA Troop manager 0.1.9 — actor role "troop manager" (AR62, self-activating, TK62 "troop managing for [period] is
 * done") that has the troops the next planned adventure will lose ready in time, executed by the "trainer" (AR63, TK63
 * "[troop order] is trained" — the training itself is done by the game's barracks). Decision 0065.
 *
 * 0.1.9 (2026-11-22, author: "Aanmaken troepen optimaliseren"; live: 150 Swordsmen in 3 hours, the Elite Barracks alternating the
 *   Swordsman rows Bonaberti waits for with Mounted Swordsman rows for the target strength): R-TROOP-PLAN-FIRST — while a plan
 *   (planned losses or a refused start's want) still needs a unit kind beyond the free army and what is in training, a barracks
 *   that trains it gets no new rows of unit kinds only short of their target strength (their unsent orders are withdrawn), the
 *   planned unit kinds are ordered first, and R-TROOP-FRONT moves the planned rows to the front for wants too.
 *   Unit: tests/unit/dma-troops-want.test.js (planFirst; need() with wants).
 * 0.1.8 (2026-11-22, author: "De troop manager moet ze altijd op orde houden"; live: a Bonaberti start was refused, 1 983
 *   Swordsman missing, and nothing trained them because the plan held only YWC's losses): an adventure whose start is refused for
 *   want of troops writes what it needs at home into the plan (want(adventure, load) -> plan.wants[adventure].load); the planned
 *   need per unit kind is the largest of the planned losses and every such want (planned()); the want is cleared when that
 *   adventure starts (clearWant). Unit: tests/unit/dma-troops-want.test.js.
 * 0.1.7 (2026-11-18, author: "waarom zitten de barakken niet vol?"): an order counts as taken as soon as the queue holds more
 *   of the unit than before the send — at 400 % speed part of the row was already trained at the 120 s check, so taken orders
 *   were declined and their unit kind blocked for 30 minutes (21 of 41 orders on the night of 2026-11-18; both queues empty).
 *   Unit: tests/unit/dma-troops-fast-barracks.test.js. Integration: the barracks queues stay filled while a shortfall lasts.
 * Author, 2026-11-05: "start training Recruits in the barracks before it runs out"; 2026-11-13: "build the troops a planned
 * adventure will lose in advance (vooraf, je weet nu al wat je gaat verliezen), as long as the barracks have room";
 * "queued orders can always be cancelled except the one in production, so keep each order short"; "Ja, delete de rij en
 * vul hem opnieuw"; "Ga verder". Live 2026-11-13: the Elite Barracks held 64 Knight rows before the first Swordsman row
 * while Swordsmen were the shortfall of the next Bonaberti run — reordering by hand (probe ld qfront) moved them first.
 *
  * 0.1.6 (2026-11-16, live facts 13:21-13:26 UTC of 0.1.5; coordinator): TWO defects. (1) The Elite Barracks was never found: every elite unit was declined "no barracks trains <Unit>" although the
 *   author's Elite Barracks runs. 0.1.5 trusted the recipes of a barracks when they were readable — but on the real client the recipes read for the Elite Barracks do not list its units (false), so the
 *   group fallback (unit inputs 0.1.1: GetIsElite -> the Elite Barracks) never applied. Now the order of evidence is: (a) a row of the unit kind in a queue of the picture; (b) a barracks whose recipes
 *   list the unit kind; (c) otherwise the unit's group from the game (normal -> Barracks, elite -> EliteBarracks) when the picture shows that barracks — whether its recipes were unreadable or only
 *   do not list the unit (a wrong guess is caught by the "did not take the order" give-up and costs nothing: the allocation is released). The Barracks and the Elite Barracks are separate buildings
 *   with separate queues, so a normal and an elite order run in parallel (one order per unit kind at a time, one send per building at a time). WATCHER: the trainer records once per change which
 *   barracks it sees (one P-fact "barracks seen": name, grid, production type, the units its recipes list or null) and keeps it in the status file (state.barracks), so one live look settles the real
 *   building name and production type of the Elite Barracks. (2) "The barracks did not take the order" 120 s after every send although the game had taken it: the seen-in-queue check read the location
 *   manager's picture, which is sampled only every 5 minutes (agents 0.4.25: sampleStock), so the row appeared in it after the 120 s. Now the trainer reads the queue itself when it checks:
 *   gateway.live(building, unit) = the amount of that unit kind in the building's queue, the row in production included (the waiting-rows reader rows() leaves it out). before is taken live when the order is
 *   sent; "sent" -> "training" when the live amount reached before + amount; "training" -> trained when it fell back to before. With no live read the picture is used and the wait is 7 minutes (a picture
 *   is at most 5 minutes old), not 120 s. A row seen in training is taken: the order is declared when it is trained, never given up. Unit: tests/unit/dma-troops-live.test.js (the lookup with the
 *   false recipes of the Elite Barracks; a live read that sees the row while the picture does not; the picture-only wait). Integration: tests/integration/dma-troops-live-queues.test.js
 *   (client-shaped Barracks and Elite Barracks with the real gateway: elite and normal orders in parallel; the row appears in the live queue 200 s after the send while the picture stays old: training, then declared).
 * 0.1.5 (2026-11-16, live defect: the author set 16 targets, TK63 was requested, and the trainer declined EVERY order "no barracks trains <Unit>", conditions [false,true,true], with a Barracks and an Elite
 *   Barracks on the island): trainedIn() answered "a queue trains this unit kind" only when that unit kind was IN a queue right now (started row or waiting row of the picture) — an empty
 *   or busy-with-another-kind barracks trained nothing, so nothing could ever be ordered first. Now the trainer asks what the barracks CAN produce. SOURCE, in this order: (1) a row of that unit
 *   kind already in a queue of the location manager's picture (as before); (2) the game's own production-queue data: gateway.canTrain(building, unit) reads the recipes of the building's
 *   production type — global.timedProductions_vector[queue.mProductionType], whose recipes name their GetType() — for each barracks the picture shows (true / false / null = not readable);
 *   (3) when (2) cannot be read: the unit's group from the game (DMA_UnitInputs.group, unit inputs 0.1.1: GetIsElite) — the normal group is trained by the Barracks, the elite group by the
 *   Elite Barracks (the client's buildings; the unit groups' source) — provided the picture shows that barracks. A unit kind no shown barracks can produce (expedition units, an island without an
 *   Elite Barracks) is still declined "no barracks trains <Unit>". WATCHER: the probe tool user_dma_probe_timed 0.1.2 dumps each barracks' name, level, production type and the units it can
 *   produce, so one live run shows whether (2) reads on the real client; the trainer's decline record names the way the barracks was found (via: queue | recipes | group). A declined order is
 *   renewed by the 0.1.3 rule once its conditions changed (at most every 30 min). Unit: tests/unit/dma-troops-barracks.test.js (the lookup: queue, recipes, group fallback, unreadable,
 *   expedition, no barracks). Integration: tests/integration/dma-troops-barracks-live-shape.test.js (a client-shaped Barracks and Elite Barracks with empty queues, the real picture sampler
 *   and the real gateway: Recruit goes to the Barracks, Knight to the Elite Barracks, an expedition unit is declined).
 * 0.1.4 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C8 of the migration): the troop manager does
 *   not send itself. Its gateway's two sends — the new row (91) and the move of a row to the front (1028) — go through the Game
 *   Interface Adapter, GCAF_GameInterface.sendMessage("START_TIMED_PRODUCTION" / "PRODUCTION_MOVE_TOP", vo): holds, pace per class
 *   "production" (300 ms) and the command table apply. The gateway answers true/false as before and keeps the adapter's refusal in
 *   G.refusal() ({ reason, retry }). The executor records the answer: on a transient refusal (a hold, the pace) the order stays
 *   allocated and is sent on the next tick ("waits: <reason>", no decline); on any other refusal the TK63 promise is revoked and
 *   declined with the adapter's reason (was: "the order could not be sent"). The row is marked "waiting for server" only after the
 *   send was taken. No adapter loaded = refused "game interface adapter not loaded". The adapter's own integration test
 *   (game-interface-adapter-troops) showed that the two sends reach the game exactly as before.
 *   Unit: tests/unit/dma-troops.test.js (an adapter refusal: retry waits, a hard refusal declines with its reason).
 *   Integration: tests/integration/game-interface-adapter-troops.test.js (the real troop gateway and the real adapter: both sends reach the
 *   game with the same command, zone and value object as before; a hold refuses with retry).
 * 0.1.3 (2026-11-16, architect on PR #399): a DECLINED troop order is no longer requested again every 6 s tick. The
 *   declined case is kept (state.declined[unit kind]: reason, the conditions it was judged on, when); a new troop order
 *   for that unit kind is requested only when its reason may have changed AND at most every 30 minutes: the conditions
 *   the trainer judged (a barracks queue trains the unit kind, its unit inputs are known, troops.order) differ from those
 *   at the decline, or the reason is not one of those (no material allocator, an allocation the allocator declined, a
 *   row the barracks never showed). A unit kind whose shortfall is gone forgets its declined case.
 *   Unit: tests/unit/dma-troops.test.js (a declined order is not requested again within 30 min; after 30 min with the
 *   same conditions it is not either; once the barracks trains the unit kind it is, after 30 min). Integration:
 *   tests/integration/dma-troops-tx.test.js (an unknown unit kind over 100 ticks gives one TK63 request, not 100).
 * 0.1.2 (2026-11-16, backbone v3.17 — ADR 0072 T-1 … T-6, model PR #388, reconciliation R-21): the player sets the troop
 *   strength; the troop manager trains up to it.
 *   (T-1/T-2, DFS-49) the troop shortfall per unit kind = max(0, target strength (policy 0.2.63 unitPolicies(), the UNIT
 *   POLICY) + planned losses (dma-troops-plan.json: losses x runs, optional now) - army (the free army of the location
 *   manager's troop picture) - in training (the row in production and every waiting row of the barracks queues)). No
 *   target and no plan: nothing to do.
 *   (ARS-62-11) ONE TK63 PER TROOP ORDER: per unit kind with a shortfall the troop manager requests one troop order of
 *   min(troops.rowSize, shortfall) units ("troop@<unit>#<n>"), one per unit kind at a time. The executor is recorded as
 *   AR63 "troop order trainer" (was "trainer").
 *   (ARS-63-02) the trainer promises when a barracks queue trains the unit kind, the unit inputs are known
 *   (DMA_UnitInputs 0.1.0: settlers and weapons per unit, from the client with a registered copy) and troops.order is
 *   on; else it declines with the reason.
 *   (T-3, ARS-63-03 / ARS-60-05-AR63) before training, the trainer requests TK60 MATERIAL ALLOCATING for the order's
 *   settlers and weapons (inputs x amount) from the material allocator (DMA_Control.allocate, control 0.2.98) and accepts
 *   it once declared; while the stock is short the allocator has requested TK64 and the order waits ("waiting for
 *   material").
 *   (ARS-63-04) allocated -> the trainer sends the order (START_TIMED_PRODUCTION 91, as before; never while the queue
 *   waits for the server) and executes; once the queue shows the row the game has taken the materials and the
 *   allocation is released; when the queue has trained as many units as it held before plus the order, the trainer
 *   declares and the troop manager accepts (ARS-63-05). A row the barracks never shows within 2 minutes, or a declined
 *   allocation, ends the order: revoke promise (trainer) -> allow (troop manager) -> decline. An order no longer needed
 *   before it was sent is withdrawn: revoke request (troop manager) -> allow (trainer), its allocation released.
 *   (T-5) the troop manager never buffs: buffing a barracks while it trains is the construction manager's (green).
 *   (T-6) no barracks on/off — there was none in this module and none is added.
 *   R-TROOP-FRONT (0.1.0) stays: the rows the plan needs first move to the front of their queue; the moves are now
 *   information facts ("troop row moved to the front"), not TK63 cases.
 *   Unit: tests/unit/dma-troops.test.js (shortfall = target + plan - army - training; one order per unit kind; the TK63
 *   pattern with TK60 first; waits for material; sent -> released -> trained -> declared/accepted; declines; a target
 *   lowered withdraws an unsent order) and tests/unit/dma-troops-revoke.test.js (replayed through DMA_Tx: withdrawn and
 *   given-up orders leave nothing open, nothing foreign). Integration: tests/integration/dma-troops-tx.test.js (the real
 *   policy with a stored target of 50 Recruits, the C-fact memory hooked on DMA_Demo.record, and stand-ins shaped as
 *   DMA_UnitInputs 0.1.0 (#397) and control 0.2.98's allocate (#398): two troop orders whose TK60 and TK63 end accepted,
 *   one waits for material first; a lowered target withdraws an unsent order; off by default; nothing foreign).
 * 0.1.1 (2026-11-16, architecture review 2026-11-16 findings #4 (High), #12/§5.2 and #17 (Low)):
 *   (#4) the revocation of an open TK63 case was written as act "revoke-request" — not a DEMO act, so the C-fact memory
 *   counted it foreign, the case stayed "promised" and the following "allow" was "not after promised": every plan or need
 *   change left an orphan TK63 until the 48 h sweep. It is now "revoke request" (EO2 ch. 8), answered by the trainer's
 *   "allow", so the case is void. (#12) The switch troops.auto falls back to OFF when no policy is loaded (the policy
 *   registers it, default off, since policy 0.2.58). (#17) The header's colour words: the trainer's work is original
 *   production (O), not "blue"; R-TROOP-FRONT is computing (I, green). No behaviour change beyond the act name and the default.
 *   Unit: tests/unit/dma-troops-revoke.test.js (the troop manager's facts replayed through DMA_Tx: after a plan change the
 *   old case is void, nothing is foreign). Integration: tests/integration/dma-troops-tx.test.js (troops, the C-fact
 *   memory hooked on DMA_Demo.record and the real policy: a need that falls to 0 leaves no open TK63; switched off by default).
 *
 * THE PLAYER'S FACTS:
 *   dma-troops-plan.json {adventure, runs, losses: {unit: lost per run}, source}  — the plan: what the next adventure
 *                    loses per run (from the simulator / the Mundane bill) and how many runs; no plan = nothing to do.
 *   troops.auto      switch (default off; 0.1.1)
 *   troops.order     may the trainer order new rows when the queue holds too few (default on)
 *   troops.rowSize   units per new row (default 25 — short rows stay changeable)
 *   troops.maxMoves  moves per tick (default 1; a tick is 6 s)
 * COMPUTING (I-organisation, green; rule R-TROOP-FRONT, computed here from the location manager's troop picture, DMA_Demo.troops(), ADR 0040):
 *   need(unit)  = losses(unit) x runs - free(unit), at least 0
 *   rows(unit)  = ceil(need / row size); the FRONT of a queue are the first sum(rows) waiting rows; the rule holds when
 *                 the front holds only the chosen rows (the first rows(unit) waiting rows of each needed unit).
 *   short(unit) = rows(unit) - waiting rows of that unit in its queue (> 0: new rows to order).
 * THE TRAINER (AR63, executor of TK63 — original production; it reads the queue itself when it acts — truth clauses;
 *   the server sends are its implementation): a chosen row behind the first row that
 *   is not chosen is moved to the top (PRODUCTION_MOVE_TOP 1028, dTimedProductionQueueChangeVO, ADR 0064), the last
 *   such row first, so the rows already in front keep their place; a short unit gets new rows (START_TIMED_PRODUCTION
 *   91, dTimedProductionVO) in the queue that already trains it. Never while the queue waits for the server, never the
 *   row in production, never away from home. Nothing is cancelled: reorder, do not cancel (ADR 0064 addendum).
 *
 * TK63, one case per building and unit ("troops:<building>:<unit>#<n>"): request (troop manager: need, rows) ->
 * promise (trainer: the rows are there or ordered) | decline (no queue trains this unit; not allowed to order) ->
 * execute (moves / orders) -> declare (the front holds the rows) -> accept (troop manager, tacit). A plan change or a
 * need that falls to 0 ends the open case: revoke request (troop manager) -> allow (trainer); the case is void.
 *
 * Unit expectation:        tests/unit/dma-troops.test.js — need from plan and free army; the front rule; the move picks
 *                          the last chosen row behind the first non-chosen row; a short unit is ordered once; no move
 *                          while busy or away; no plan -> nothing; the TK63 pattern is recorded.
 * Integration expectation: live, with dma-troops-plan.json for Bonaberti r10, the Elite Barracks front holds the
 *                          Swordsman rows the run still needs and dma-troops-status.json shows need, front and the case.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.9";
    if (root.DMA_Troops && root.DMA_Troops.version) return;
    var STATUS = "dma-troops-status.json", PLAN = "dma-troops-plan.json", TICK_MS = 6000;

    /* ---------------- gateway: the picture, the game, the files, the facts (replaced in the tests) ---------------- */
    function gameGateway() {
        var R = root;
        function g() { return R.game; }
        var refusal = null;   // 0.1.4 (ADR 0073): the adapter's answer to the last send that was refused
        function viaAdapter(fn) {
            var A = R.GCAF_GameInterface, r; refusal = null;
            if (!A) { refusal = { reason: "game interface adapter not loaded", retry: false }; return false; }
            try { r = fn(A); } catch (e) { r = { ok: false, reason: "send failed: " + e }; }
            if (r && r.ok) return true;
            refusal = { reason: (r && r.reason) || "no answer from the adapter", retry: !!(r && r.retry) }; return false;
        }
        function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
        function building(name) {
            try { var v = g().gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector();
                  for (var i = 0; v && i < v.length; i++) { try { if (v[i] && String(v[i].GetBuildingName_string()) === name) return v[i]; } catch (_) {} } } catch (_) {}
            return null;
        }
        return {
            now: function () { return Date.now(); },
            atHome: function () { try { var C = R.DMA_Control; if (C && typeof C.atHome === "function") return !!C.atHome(); } catch (_) {} try { return !!g().gi.isOnHomzone(); } catch (_) { return false; } },
            rule: function (k, d) { try { var P = R.GCAF_PlayerPolicyInstance, v = P && P.get ? P.get(k) : undefined; return v == null || v === "" ? d : v; } catch (_) { return d; } },
            picture: function () { try { return R.DMA_Demo && R.DMA_Demo.troops ? R.DMA_Demo.troops() : null; } catch (_) { return null; } },
            /* the trainer's own read of one queue, when it acts: waiting rows with id, type, amount; busy = waits for the server */
            rows: function (name) {
                var b = building(name); if (!b) return null;
                var q = b.productionQueue, v = q ? q.mTimedProductions_vector : null, out = { busy: false, rows: [] };
                for (var i = 0; v && i < v.length; i++) { var r = v[i];
                    try { if (r.GetWaitingForServer && r.GetWaitingForServer()) out.busy = true; } catch (_) {}
                    if (i === 0 && r.HasStarted()) continue;
                    out.rows.push({ id: r.GetUniqueID(), type: String(r.GetType()), amount: Number(r.GetAmount()) || 0 }); }
                return out;
            },
            refusal: function () { return refusal; },
            /* 0.1.5: can this barracks produce this unit kind? the recipes of its production type (the game's own data): true / false, null = not readable */
            canTrain: function (name, unit) {
                try { var b = building(name); if (!b) return null;
                      var tp = R.swmmo.getDefinitionByName("global").timedProductions_vector, rec = tp ? tp[b.productionQueue.mProductionType] : null;
                      if (!rec || !rec.length) return null;
                      for (var i = 0; i < rec.length; i++) { try { if (String(rec[i].GetType()) === unit) return true; } catch (_) {} }
                      return false; } catch (_) { return null; }
            },
            /* 0.1.6: the units a barracks' recipes list (null = not readable) and the amount of one unit kind in its queue now, the row in production included (null = not readable) */
            recipeUnits: function (name) {
                try { var b = building(name); if (!b) return null; var rec = R.swmmo.getDefinitionByName("global").timedProductions_vector[b.productionQueue.mProductionType]; if (!rec || !rec.length) return null;
                      var out = []; for (var i = 0; i < rec.length; i++) { try { out.push(String(rec[i].GetType())); } catch (_) {} } return out; } catch (_) { return null; }
            },
            live: function (name, unit) {
                try { var b = building(name); if (!b) return null; var v = b.productionQueue.mTimedProductions_vector, n = 0;
                      if (!v) return null; for (var i = 0; i < v.length; i++) { try { if (String(v[i].GetType()) === unit) n += Number(v[i].GetAmount()) || 0; } catch (_) {} } return n; } catch (_) { return null; }
            },
            unitGroup: function (unit) { try { var U = R.DMA_UnitInputs; return U && typeof U.group === "function" ? U.group(unit) : null; } catch (_) { return null; } },
            moveTop: function (name, id) {
                var b = building(name); if (!b) return false;
                var q = b.productionQueue, vo = new (R.swmmo.getDefinitionByName("Communication.VO::dTimedProductionQueueChangeVO"))();
                vo.productionType = q.mProductionType; vo.itemID = id;
                if (!viaAdapter(function (A) { return A.sendMessage("PRODUCTION_MOVE_TOP", vo); })) return false;
                q.SetAllProductionWaitingForServer(true);   // 0.1.4: marked only after the send was taken
                return true;
            },
            order: function (name, unit, amount) {
                var b = building(name); if (!b) return false;
                var vo = new (R.swmmo.getDefinitionByName("Communication.VO::dTimedProductionVO"))();
                vo.productionType = b.productionQueue.mProductionType; vo.type_string = unit; vo.amount = amount; vo.stacks = 1; vo.buildingGrid = b.GetGrid();
                return viaAdapter(function (A) { return A.sendMessage("START_TIMED_PRODUCTION", vo); });
            },
            fileRead: function (name) {
                try { var a = airApi(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
                      var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
            },
            fileWrite: function (name, obj) {
                try { var a = airApi(), f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath), st = new a.FileStream();
                      st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); return true; } catch (_) { return false; }
            },
            record: function (kind, data) { try { if (R.DMA_Demo && R.DMA_Demo.record) R.DMA_Demo.record(kind, data); } catch (_) {} },
            /* 0.1.2 (v3.17): the unit policy (policy 0.2.63 unitPolicies), the unit inputs (DMA_UnitInputs 0.1.0), and
               the material allocator (control 0.2.98 allocate / allocation) */
            targets: function () {
                try { var P = R.GCAF_PlayerPolicyInstance, out = {};
                      if (!P) return out;
                      if (typeof P.unitPolicies === "function") return P.unitPolicies() || {};
                      if (typeof P.entries === "function") P.entries(["^unit\\.[A-Za-z0-9_]+\\.targetStrength$"]).forEach(function (e) { if (Number(e.value) > 0) out[e.ruleId.split(".")[1]] = Number(e.value); });   // a policy before 0.2.63
                      return out; } catch (_) { return {}; }
            },
            inputs: function (unit) { try { var U = R.DMA_UnitInputs; return U && typeof U.inputs === "function" ? U.inputs(unit) : null; } catch (_) { return null; } },
            allocate: function (m) { try { var C = R.DMA_Control; return C && typeof C.allocate === "function" ? C.allocate(m) : null; } catch (_) { return null; } },
            allocation: function (id) { try { var C = R.DMA_Control; return C && C.allocation ? C.allocation.get(id) : null; } catch (_) { return null; } },
            release: function (id, why) { try { var C = R.DMA_Control; return !!(C && C.allocation && C.allocation.release(id, why)); } catch (_) { return false; } },
            log: function (m) { try { if (typeof R.debug === "function") R.debug("DMA Troops " + VERSION + ": " + m); } catch (_) {} }
        };
    }

    /* ---------------- green: R-TROOP-FRONT and DFS-49 (pure) ---------------- */
    function need(plan, free) {   // the plan's need beyond the free army: what R-TROOP-FRONT puts in front of the queue (0.1.9: losses and wants)
        var out = {}, P = planned(plan), u;
        for (u in P) if (P.hasOwnProperty(u)) { var n = Math.round((Number(P[u]) || 0) - (Number(free && free[u]) || 0)); if (n > 0) out[u] = n; }
        return out;
    }
    /* 0.1.9 R-TROOP-PLAN-FIRST (author 2026-11-22: "Aanmaken troepen optimaliseren"; live: the Elite Barracks alternated a Swordsman row
       the Bonaberti start waits for with a Mounted Swordsman row that only fills the target strength — 30 min per unit against 15 —
       so 150 Swordsmen came in 3 hours): a unit kind only short of its target strength gets no new row in a barracks while a unit
       kind trained there is still needed by a plan (a refused start or planned losses, beyond the free army and what is in training);
       an unsent order of it is withdrawn. Pure: given the plan's needs per unit kind and the building of each unit kind. */
    function planFirst(sf, planNeed, buildingOf) {
        var busy = {}, wait = {}, u;
        for (u in planNeed) if (planNeed.hasOwnProperty(u) && planNeed[u] > 0 && buildingOf(u)) busy[buildingOf(u)] = true;
        for (u in sf) if (sf.hasOwnProperty(u) && !(planNeed[u] > 0) && busy[buildingOf(u)]) wait[u] = true;
        return wait;
    }
    /* 0.1.2: in training per unit kind = the row in production plus every waiting row (the location manager's picture) */
    function training(pic) {
        var out = {}, qs = (pic && pic.queues) || {}, n;
        for (n in qs) if (qs.hasOwnProperty(n)) {
            var q = qs[n];
            if (q.started && q.started.type) out[q.started.type] = (out[q.started.type] || 0) + (Number(q.started.amount) || 0);
            (q.runs || []).forEach(function (r) { out[r[0]] = (out[r[0]] || 0) + (Number(r[1]) || 0) * (Number(r[2]) || 1); });
        }
        return out;
    }
    /* 0.1.8 (author 2026-11-22: "De troop manager moet ze altijd op orde houden"): what the plans want at home per unit kind —
       the planned losses (losses x runs) and, per adventure whose start was refused for want of troops, the loose troops that
       start needs (plan.wants[adventure].load, written by want()); the largest of them counts (the runs take turns) */
    function planned(plan) {
        var out = {}, runs = Math.max(0, Number(plan && plan.runs) || 0), L = (plan && plan.losses) || {}, W = (plan && plan.wants) || {}, u, a;
        for (u in L) if (L.hasOwnProperty(u)) out[u] = Math.max(out[u] || 0, (Number(L[u]) || 0) * runs);
        for (a in W) if (W.hasOwnProperty(a)) { var ld = (W[a] && W[a].load) || {}; for (u in ld) if (ld.hasOwnProperty(u)) out[u] = Math.max(out[u] || 0, Number(ld[u]) || 0); }
        return out;
    }
    /* 0.1.2: DFS-49 the troop shortfall of [unit policy] = max(0, target strength + planned (0.1.8: losses or a start's load) - army - in training) */
    function shortfall(targets, plan, free, inTraining) {
        var out = {}, P = planned(plan), kinds = {}, u;
        for (u in (targets || {})) if (targets.hasOwnProperty(u)) kinds[u] = true;
        for (u in P) if (P.hasOwnProperty(u)) kinds[u] = true;
        for (u in kinds) {
            var n = Math.round((Number(targets && targets[u]) || 0) + (Number(P[u]) || 0) - (Number(free && free[u]) || 0) - (Number(inTraining && inTraining[u]) || 0));
            if (n > 0) out[u] = n;
        }
        return out;
    }
    /* which rows of one queue must be in front: per needed unit the number of rows, and the units it cannot cover */
    function front(rows, needs, rowSize) {
        var have = {}, k = {}, short = {}, u, total = 0;
        rows.forEach(function (r) { have[r.type] = (have[r.type] || 0) + 1; });
        for (u in needs) if (needs.hasOwnProperty(u)) {
            var amt = 0; rows.some(function (r) { if (r.type === u) { amt = r.amount; return true; } return false; });
            var want = Math.ceil(needs[u] / (amt || rowSize));
            if (!have[u]) continue;                       /* not trained here */
            k[u] = Math.min(want, have[u]); total += k[u];
            if (want > have[u]) short[u] = want - have[u];
        }
        var seen = {}, chosen = rows.map(function (r) { if (!k[r.type]) return false; seen[r.type] = (seen[r.type] || 0) + 1; return seen[r.type] <= k[r.type]; });
        var p = chosen.indexOf(false), behind = [];
        if (p >= 0) for (var i = p + 1; i < rows.length; i++) if (chosen[i]) behind.push(i);
        return { rows: k, length: total, short: short, firstOther: p, behind: behind, holds: behind.length === 0 };
    }
    /* 0.1.5: the barracks that trains a unit kind — { name, via } or null. (1) a row of the unit kind in a queue of the picture; (2) the recipes of the barracks' production type
       (G.canTrain: true/false/null); (3) not readable: the unit's group (G.unitGroup, from the game) -> the Barracks (normal) or the Elite Barracks (elite) when the picture shows it */
    var BARRACKS_OF_GROUP = { normal: "Barracks", elite: "EliteBarracks" };
    function barracksFor(pic, unit, G) {
        var qs = (pic && pic.queues) || {}, n, names = [], i;
        for (n in qs) if (qs.hasOwnProperty(n)) {
            names.push(n);
            if (qs[n].started && qs[n].started.type === unit) return { name: n, via: "queue" };
            if ((qs[n].runs || []).some(function (r) { return r[0] === unit; })) return { name: n, via: "queue" };
        }
        for (i = 0; i < names.length; i++) {
            var can = null; try { can = G && typeof G.canTrain === "function" ? G.canTrain(names[i], unit) : null; } catch (_) { can = null; }
            if (can === true) return { name: names[i], via: "recipes" };
        }
        var g = null; try { g = G && typeof G.unitGroup === "function" ? G.unitGroup(unit) : null; } catch (_) { g = null; }   // 0.1.6: the group decides when no recipe lists the unit (readable or not)
        var want = BARRACKS_OF_GROUP[g]; if (want && names.indexOf(want) >= 0) return { name: want, via: "group" };
        return null;
    }
    function trainedIn(pic, unit, G) { var b = barracksFor(pic, unit, G); return b ? b.name : null; }
    function times(inp, n) { var o = {}, k; for (k in (inp || {})) if (inp.hasOwnProperty(k)) o[k] = Number(inp[k]) * n; return o; }

    /* ---------------- the manager (AR62) and the trainer (AR63) ---------------- */
    var MANAGER = "troop manager", TRAINER = "troop order trainer", SEEN_MS = 120000, PICTURE_SEEN_MS = 7 * 60000, RENEW_MS = 30 * 60000;   // 0.1.3: RENEW_MS
    function createManager(G) {
        G = G || gameGateway();
        var st = G.fileRead(STATUS) || {};
        var state = { version: VERSION, orders: st.orders || {}, declined: st.declined || {}, n: Number(st.n) || 0, last: st.last || "", planSig: st.planSig || "" };
        var dirty = false;
        function save() { state.at = new Date(G.now()).toISOString(); G.fileWrite(STATUS, state); dirty = false; }
        function say(m) { if (state.last !== m) { state.last = m; dirty = true; G.log(m); } }
        function on(k, d) { var v = G.rule(k, d); return !(v === false || String(v) === "false"); }
        function c63(act, o, actor, extra) {
            var d = { tk: "TK63", act: act, caseId: o.id, unit: o.unit, amount: o.amount, building: o.building || null, actor: actor }, k;
            for (k in (extra || {})) d[k] = extra[k];
            G.record("c", d); dirty = true;
        }
        function c60(act, o, extra) {
            var d = { tk: "TK60", act: act, caseId: o.mat, troopOrder: o.id, actor: TRAINER }, k;
            for (k in (extra || {})) d[k] = extra[k];
            G.record("c", d); dirty = true;
        }
        function end(o) { delete state.orders[o.unit]; dirty = true; }
        /* 0.1.3: what the trainer judges a troop order on — a declined order is renewed only when this changed */
        function conditions(u, pic) { return JSON.stringify([!!trainedIn(pic, u, G), !!G.inputs(u), on("troops.order", true)]); }
        function declined(o, why, pic, judged) { state.declined[o.unit] = { id: o.id, reason: why, at: G.now(), conditions: judged ? conditions(o.unit, pic) : null }; dirty = true; }
        /* the trainer gives up a promised order: revoke promise -> allow -> decline (EO2 §8.2.6.3) */
        function giveUp(o, why) {
            if (o.mat && o.matHeld) G.release(o.mat, why);
            c63("revoke promise", o, TRAINER, { reason: why }); c63("allow", o, MANAGER, {}); c63("decline", o, TRAINER, { reason: why });
            declined(o, why, null, false);   // 0.1.3: a reason the conditions do not show: renewed after 30 min
            end(o);
        }
        /* the manager withdraws an order no longer needed, before it was sent */
        function withdraw(o, why) {
            if (o.mat) { G.release(o.mat, why); }
            c63("revoke request", o, MANAGER, { reason: why }); c63("allow", o, TRAINER, {});
            end(o);
        }
        /* ARS-62-11: request one troop order */
        function requestOrder(u, amount) {
            state.n += 1;
            var o = state.orders[u] = { id: "troop@" + u + "#" + state.n, unit: u, amount: amount, state: "requested", since: G.now() };
            c63("request", o, MANAGER, { reason: "troop shortfall (DFS-49)" });
            return o;
        }
        /* ARS-63-02 / ARS-63-03 / ARS-63-04 and the execution: one step per tick */
        function advance(o, pic, t) {
            if (o.state === "requested") {
                var bf = barracksFor(pic, o.unit, G), b = bf ? bf.name : null, inp = G.inputs(o.unit);
                if (!on("troops.order", true)) { c63("decline", o, TRAINER, { reason: "ordering switched off (troops.order)" }); declined(o, "ordering switched off (troops.order)", pic, true); end(o); return "declined"; }
                if (!b) { c63("decline", o, TRAINER, { reason: "no barracks trains " + o.unit, barracks: Object.keys((pic && pic.queues) || {}) }); declined(o, "no barracks trains " + o.unit, pic, true); end(o); return "declined"; }
                if (!inp) { c63("decline", o, TRAINER, { reason: "the unit inputs of " + o.unit + " are not known" }); declined(o, "the unit inputs of " + o.unit + " are not known", pic, true); end(o); return "declined"; }
                o.building = b; o.needs = times(inp, o.amount); o.state = "promised";
                c63("promise", o, TRAINER, { needs: o.needs, barracks: b, via: bf.via });
                o.mat = "mat@" + o.id;
                c60("request", o, { needs: o.needs });   // ARS-63-03: its settlers and weapons are set aside first
                var a = G.allocate({ id: o.mat, needs: o.needs, by: TRAINER, troopOrder: o.id });
                if (!a) { giveUp(o, "no material allocator (control 0.2.98)"); return "no allocator"; }
                if (a.fact === "dc") { giveUp(o, "material allocating declined: " + (a.reason || "")); return "declined"; }
                o.matHeld = true; o.state = "allocating";
                if (a.fact === "da") { c60("accept", o, {}); o.state = "allocated"; }   // ARS-60-05-AR63
                else o.lacking = a.lacking || null;
                return o.state;
            }
            if (o.state === "allocating") {
                var al = G.allocation(o.mat) || G.allocate({ id: o.mat, needs: o.needs, by: TRAINER, troopOrder: o.id });
                if (al && al.state === "declared") { c60("accept", o, {}); o.state = "allocated"; o.lacking = null; return "allocated"; }
                o.lacking = al && al.lacking || o.lacking; return "waiting for material";
            }
            if (o.state === "allocated") {
                var q = G.rows(o.building);
                if (!q) { giveUp(o, "the barracks " + o.building + " is gone"); return "declined"; }
                if (q.busy) return "busy";
                var lv0 = typeof G.live === "function" ? G.live(o.building, o.unit) : null;   // 0.1.6: the queue read now, not the picture
                o.before = lv0 != null ? lv0 : Number(t[o.unit] || 0); o.beforeLive = lv0 != null;
                if (!G.order(o.building, o.unit, o.amount)) {   // 0.1.4 (ADR 0073): the adapter's answer
                    var rf = (G.refusal && G.refusal()) || null;
                    if (rf && rf.retry) return "waits: " + rf.reason;
                    giveUp(o, (rf && rf.reason) || "the order could not be sent"); return "declined";
                }
                o.state = "sent"; o.sentAt = G.now();
                c63("execute", o, TRAINER, { order: o.amount });
                return "ordered";
            }
            if (o.state === "sent") {
                var lv1 = typeof G.live === "function" ? G.live(o.building, o.unit) : null, seen = o.beforeLive && lv1 != null ? lv1 : Number(t[o.unit] || 0), waitMs = o.beforeLive && lv1 != null ? SEEN_MS : PICTURE_SEEN_MS;
                /* 0.1.7 (author 2026-11-18 02:35: "waarom zitten de barakken niet vol?" — both barracks queues stood empty while 21 of 41
                   orders that night were declined "the barracks did not take the order"; the game took them: at 400 % speed a Recruit
                   trains in 46 s, so at the 120 s check the row held fewer than before + amount and the order was declined, its unit
                   kind then blocked for 30 minutes): the order is taken as soon as the queue holds MORE of the unit than before */
                if (seen > o.before || seen >= o.before + o.amount) {   // the row is in the queue: the game took the materials
                    G.release(o.mat); o.matHeld = false; o.state = "training"; o.trainingFrom = o.before + o.amount; dirty = true; return "training";
                }
                if (G.now() - o.sentAt > waitMs) { giveUp(o, "the barracks did not take the order"); return "declined"; }
                return "waiting for the queue";
            }
            if (o.state === "training") {   // [troop order] is trained once the queue trained as many units as before plus it
                var lv2 = typeof G.live === "function" && o.beforeLive ? G.live(o.building, o.unit) : null, now2 = lv2 != null ? lv2 : Number(t[o.unit] || 0);
                if (now2 <= o.before) { c63("declare", o, TRAINER, {}); c63("accept", o, MANAGER, {}); end(o); return "trained"; }   // ARS-63-04 / ARS-63-05
                return "training";
            }
            return o.state;
        }
        /* 0.1.6 watcher: which barracks the picture shows, with the production type and the units its recipes list; one P-fact when that changes */
        function seenBarracks(pic) {
            var qs = (pic && pic.queues) || {}, list = Object.keys(qs).sort().map(function (n) {
                var us = null; try { us = typeof G.recipeUnits === "function" ? G.recipeUnits(n) : null; } catch (_) { us = null; }
                return { name: n, grid: qs[n].grid, type: qs[n].type, units: us }; });
            var sig = JSON.stringify(list); if (sig === state.barracksSig) return;
            state.barracksSig = sig; state.barracks = list; dirty = true; G.record("p", { tk: "TK63", fact: "barracks seen", barracks: list });
        }
        function tick() {
            if (!on("troops.auto", false))   /* 0.1.1: default off (review #12) */ { say("switched off"); if (dirty) save(); return "off"; }
            if (!G.atHome()) { say("away"); if (dirty) save(); return "away"; }
            var plan = G.fileRead(PLAN), pic = G.picture(), targets = G.targets() || {};
            if (!pic) { say("waiting for the location manager's troop picture"); if (dirty) save(); return "no picture"; }
            if (plan && (plan.losses || plan.wants)) {
                var sig = JSON.stringify([plan.adventure, plan.runs, plan.losses, plan.wants || {}]);
                if (sig !== state.planSig) { state.planSig = sig; dirty = true; G.record("p", { tk: "TK62", fact: "troop plan", adventure: plan.adventure, runs: plan.runs, losses: plan.losses, wants: plan.wants || null, source: plan.source || null }); }
            }
            seenBarracks(pic);
            var t = training(pic), sf = shortfall(targets, plan, pic.free, t), did = "ok";
            state.shortfall = sf; state.targets = targets; state.plan = plan ? { adventure: plan.adventure, runs: plan.runs } : null; state.training = t;
            /* the open troop orders: one step each; withdrawn when no longer needed before they were sent */
            Object.keys(state.orders).forEach(function (u) {
                var o = state.orders[u];
                if (!(sf[u] > 0) && ["requested", "promised", "allocating", "allocated"].indexOf(o.state) >= 0) { withdraw(o, "no longer needed"); return; }
                var r = advance(o, pic, t); if (r !== o.state) did = r;
            });
            Object.keys(state.declined).forEach(function (u) { if (!(sf[u] > 0)) { delete state.declined[u]; dirty = true; } });   // 0.1.3
            /* 0.1.9 R-TROOP-PLAN-FIRST: what the plans still need beyond the free army and what is in training */
            var pn = need(plan, pic.free), planNeed = {};
            Object.keys(pn).forEach(function (u) { var n = pn[u] - (Number(t[u]) || 0); if (n > 0) planNeed[u] = n; });
            var waitFor = planFirst(sf, planNeed, function (u) { return trainedIn(pic, u, G); });
            Object.keys(waitFor).forEach(function (u) { var o = state.orders[u]; if (o && ["requested", "promised", "allocating", "allocated"].indexOf(o.state) >= 0) withdraw(o, "planned troops first (R-TROOP-PLAN-FIRST)"); });
            state.planFirst = Object.keys(planNeed).length ? { planned: planNeed, waiting: Object.keys(waitFor) } : null;
            /* ARS-62-11: a new troop order per unit kind with a shortfall and no order still before the queue */
            var rowSize = Number(G.rule("troops.rowSize", 25)) || 25;
            Object.keys(sf).sort(function (a, b) { return (planNeed[b] > 0 ? 1 : 0) - (planNeed[a] > 0 ? 1 : 0) || (a < b ? -1 : a > b ? 1 : 0); }).forEach(function (u) {   // 0.1.9: planned units first
                if (state.orders[u]) return;   // one troop order per unit kind at a time (short orders stay changeable)
                if (waitFor[u]) return;        // 0.1.9: the barracks trains what a plan needs first
                var dc = state.declined[u];   // 0.1.3: a declined order is renewed only when its reason may have changed, at most every 30 min
                if (dc) {
                    if (G.now() - dc.at < RENEW_MS) return;
                    if (dc.conditions && dc.conditions === conditions(u, pic)) return;
                    delete state.declined[u]; dirty = true;
                }
                var nw = requestOrder(u, Math.min(rowSize, sf[u]));
                var r = advance(nw, pic, t); did = r;
            });
            /* R-TROOP-FRONT (0.1.0): the rows the plan needs first move to the front of their queue (information) */
            if (plan && (plan.losses || plan.wants)) {   // 0.1.9: the wants of refused starts too
                var needs = need(plan, pic.free), byB = {};
                Object.keys(needs).forEach(function (u) { var b = trainedIn(pic, u, G); if (b) (byB[b] = byB[b] || {})[u] = needs[u]; });
                Object.keys(byB).forEach(function (b) {
                    var q = G.rows(b); if (!q) return;
                    var f = front(q.rows, byB[b], rowSize);
                    state.front = state.front || {}; state.front[b] = { length: f.length, behind: f.behind.length, holds: f.holds };
                    if (q.busy || !f.behind.length) return;
                    var moves = Math.max(1, Number(G.rule("troops.maxMoves", 1)) || 1);
                    for (var m = 0; m < moves && m < f.behind.length; m++) {
                        var idx = f.behind[f.behind.length - 1 - m], r = q.rows[idx];
                        if (G.moveTop(b, r.id)) { did = "moved"; G.record("i", { tk: "TK62", fact: "troop row moved to the front", building: b, unit: r.type, rule: "R-TROOP-FRONT" }); dirty = true; }
                    }
                });
            }
            say(Object.keys(sf).length ? "shortfall " + JSON.stringify(sf) + (state.planFirst ? "; planned first " + JSON.stringify(state.planFirst.planned) + (state.planFirst.waiting.length ? ", waiting: " + state.planFirst.waiting.join(", ") : "") : "") + " — " + did : (Object.keys(targets).length || (plan && plan.losses) ? "at strength" : "nothing to do (no target strength, no plan)"));
            if (dirty) save();
            return did;
        }
        return { tick: tick, state: function () { return state; } };
    }

    var mgr = null, timer = null;
    function start() {
        if (root.DMA_TROOPS_NO_TIMER) return;
        mgr = createManager();
        timer = setInterval(function () { try { mgr.tick(); } catch (e) { try { if (typeof root.debug === "function") root.debug("DMA Troops tick: " + e); } catch (_) {} } }, TICK_MS);
    }
    /* 0.1.8: an adventure whose start was refused for want of troops tells the troop manager what it needs at home (want); once it
       starts, its want is cleared (clear) so the troops loaded into its generals are not trained again */
    function editPlan(f) { try { var G = gameGateway(), p = G.fileRead(PLAN) || {}; p.wants = p.wants || {}; f(p); G.fileWrite(PLAN, p); return true; } catch (_) { return false; } }
    function want(adventure, load, why) { return editPlan(function (p) { p.wants[String(adventure)] = { load: load, why: String(why || ""), at: new Date().toISOString() }; }); }
    function clearWant(adventure) { return editPlan(function (p) { delete p.wants[String(adventure)]; }); }
    root.DMA_Troops = { version: VERSION, createManager: createManager, gameGateway: gameGateway, need: need, front: front, trainedIn: trainedIn, barracksFor: barracksFor, planned: planned, planFirst: planFirst, want: want, clearWant: clearWant,
                        shortfall: shortfall, training: training,   // 0.1.2
                        status: function () { return mgr ? mgr.state() : null; } };
    start();
})(typeof window !== "undefined" ? window : this);
