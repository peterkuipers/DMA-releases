/*
 * DMA Spots 0.1.0 — ADR 0086. The registered copy of the deposit spots of a home island: per resource, every grid where a
 * deposit can appear, in a fixed order (grid ascending) that numbers them (Iron 01, Iron 02, ...). The same on every home
 * island; a game fact (source: the game). Copy of docs/05-ontology/dma/facts/deposit-spots.yaml (tests/unit/dma-spots.test.js
 * keeps them equal).
 *
 * 0.1.0 (2026-11-18, ADR 0086; author: "alle mogelijke locaties bekend ... vaste volgorde en de speler kan hem een label geven.
 *   Deze blijft dus ongeacht wat is gevonden of niet"): list(r) answers the spots of a resource in order with their number;
 *   numberOf(grid) the resource and number of a grid; observe(r, grid) is the watcher (ADR 0042): a deposit on a grid that is
 *   not registered is recorded once as "reference fact differs" (a new spot) and kept in extra(r), so the console still shows
 *   it (as new) until the registered copy is extended. Reads nothing of the game itself: the location manager calls observe
 *   for every deposit it sees (agents 0.4.42).
 *   GLOBAL: DMA_Spots = { version, list, numberOf, observe, extra, resources }.
 *   Unit: tests/unit/dma-spots.test.js. Integration: tests/integration/dma-spots-console.test.js.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.0";
    var SPOTS = {"Stone": [4660, 4664, 4666, 5019, 6236, 7754, 7931, 8104, 10155],
        "BronzeOre": [6154, 6420, 6775, 9735, 10005, 10089],
        "Marble": [1460, 1735, 1991, 2077, 2536, 3257, 5284, 5372, 7218, 7711, 8064, 8996],
        "IronOre": [933, 1020, 1725, 1907, 2078, 2697, 3407, 3670, 3672, 5123, 5484, 5750, 5837, 5882, 6059, 7356, 7887, 8151, 11580, 12997, 13285, 13373],
        "GoldOre": [768, 1388, 1563, 1739, 3081, 8668, 9201, 9377, 11864, 12006, 13515],
        "Coal": [1438, 1613, 1794, 4956, 5577, 5664],
        "Granite": [1936, 4785, 7991, 11537, 11774, 11890, 12925, 13287],
        "TitaniumOre": [697, 5228, 5238, 5502, 7545, 12288, 13425, 13934],
        "Salpeter": [785, 1224, 7814, 9776, 11804, 13160, 13846]};
    var extra = {}, seen = {};
    function record(kind, data) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {} }
    function list(r) {
        var g = SPOTS[r] || [], out = [], i;
        for (i = 0; i < g.length; i++) out.push({ grid: g[i], no: i + 1, resource: r, registered: true });
        (extra[r] || []).forEach(function (x) { out.push({ grid: x, no: null, resource: r, registered: false }); });
        return out;
    }
    function numberOf(grid) {
        var r, i; grid = Number(grid);
        for (r in SPOTS) if (SPOTS.hasOwnProperty(r)) { i = SPOTS[r].indexOf(grid); if (i >= 0) return { resource: r, no: i + 1 }; }
        return null;
    }
    function observe(r, grid) {
        grid = Number(grid); if (!r || isNaN(grid)) return false;
        if (SPOTS[r] && SPOTS[r].indexOf(grid) >= 0) return true;
        var k = r + "|" + grid; if (seen[k]) return false; seen[k] = 1;
        (extra[r] = extra[r] || []).push(grid);
        record("p", { fact: "reference fact differs", what: "deposit spot", resource: r, grid: grid, source: "the game (a deposit on a grid that is not registered)", copy: "docs/05-ontology/dma/facts/deposit-spots.yaml" });
        return false;
    }
    root.DMA_Spots = {
        version: VERSION, list: list, numberOf: numberOf, observe: observe, resources: Object.keys(SPOTS),
        extra: function (r) { return (extra[r] || []).slice(); },
        registered: function () { return JSON.parse(JSON.stringify(SPOTS)); }
    };
})(typeof window !== "undefined" ? window : this);
