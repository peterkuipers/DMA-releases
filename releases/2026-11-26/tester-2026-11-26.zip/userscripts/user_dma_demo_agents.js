/*
 * 0.4.46 (2026-11-24, ADR 0096; author: "dan ga ik door op de laatst bekende situatie, totdat de verbinding zich herstelt"):
 *   a map that control 0.2.117 marks incomplete (the game gave no buildings) withdraws the picture and is not taken, however
 *   long it lasts; the last picture stays and the managers wait until a complete scan has settled again. Before, a loss
 *   that held 60 s was taken as the truth, so a long gap in the game's lists would have written false "mine gone" facts.
 *   Unit: tests/unit/dma-picture-complete.test.js (incomplete map). Integration: tests/integration/dma-picture-incomplete-scan.test.js.
 * 0.4.45 (2026-11-24, ADR 0096; author: "dan kunnen alle managers dus pas van start gaan als het eilandbeeld compleet is, wie
 *   meldt dat en dus ook een bedrijfsregel"): business rule R-PICTURE-COMPLETE. The location manager declares its island
 *   picture complete (fact "island picture complete") when it is at home and two scans island.picture.settleSec apart
 *   (default 60) see the same mines and masons; it withdraws it (fact "island picture withdrawn") on leaving home, at client start, on a
 *   suspect scan and on a scan that loses many mines at once — such a scan is not taken into the picture (no false "mine
 *   gone"), and its counts per mine kind are recorded to find the cause. Until the declaration the managers (geo, build,
 *   upgrade, buff, demolition, workflows, expo) set no agenda. Replaces the 0.4.9 start heuristic (> 50 buildings, then 90 s),
 *   which did not close on a return home. DMA_Demo.picture() gives the fact to every other manager.
 *   Live incident 2026-11-24: all 17 masons left the picture for one scan every 8-10 min all night; at 02:30 a titanium mine
 *   went into the build queue in such a gap, with too little granite, because R-MASONS-FIRST saw no mason.
 *   Unit: tests/unit/dma-picture-complete.test.js. Integration: tests/integration/dma-picture-gate-build.test.js.
 * 0.4.44 (2026-11-23, author: "Heb je dus ook de kortste tijd om het verlies weer op te bouwen"): the troop picture names each
 *   barracks' level (GetUpgradeLevel, the game's) — the Mundane generator's quickestRebuild takes it as that barracks' speed.
 *   Unit: tests/unit/dma-troop-picture-level.test.js.
 * 0.4.43 (2026-11-20, ADR 0088 S-3; author: "Iemand verantwoordelijk voor de voorraad moet toegang hebben tot de verbruik gegevens om te
 *   kunnen voorspellen wanneer iets in de problemen komt"): the stock series also holds the STAR — every star item the player holds (adventures,
 *   buffs, AddResource packs), keyed "star:<name>" or "star:<name>:<resource>" (e.g. "star:Adventure:1001NightsFirstThief"), summed over its
 *   stacks, read with the same 5-minute sample (game.gi.mCurrentPlayer.getAvailableBuffs_vector). stockTrends() gives their pace like any
 *   resource, so the stock-responsible role sees an adventure or a buff run out.
 *   Unit expectation:        a star item sampled 3 times falling 1 per hour gives perHour -1 under "star:Adventure:1001NightsFirstThief".
 *   Integration expectation: live, stockTrends(6) lists "star:Adventure:1001NightsFirstThief" with its amount after an hour.
 * 0.4.42 (2026-11-18, ADR 0086): every deposit the location manager sees is handed to the spot watcher (DMA_Spots.observe), which records a
 *   deposit on a grid that is not a registered spot. Unit: tests/unit/dma-spots.test.js. Integration: tests/integration/dma-spots-console.test.js.
 * 0.4.41 (2026-11-18, ADR 0084): the cycle also ticks the workflows (DMA_Workflows, Deposit Cycling) after the deposit search manager, under the same pause, when ready;
 *   island().spotGrids(r) answers the fixed list of spots per resource (every deposit grid ever observed) for the WORKFLOWS page.
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.4.40 (2026-11-18, ADR 0083 point 3; live 08:36 UTC: "48 explorers idle again" restarted the client, which did not
 *   come back for 4.5 h): a "game not responding" suspicion still pauses the actors, but restarts the client only when
 *   the player switched on control.selfRestart.on (default off) AND the stock has stood still for at least 5 minutes
 *   (DMA_Control.restart.staleMinutes): idle explorers alone are not proof that the game hangs.
 *   Unit: tests/unit/dma-suspect-restart.test.js (off: held; on with moving stock: held; on with 5 min still: restart).
 *   Integration: tests/integration/dma-self-restart-off.test.js.
 * DMA DEMO agents 0.2.0 — the self-starting actor roles of the island.
 *
 * The player decides per self-starter (policy switches) whether it self-activates.
 * 0.4.39 (2026-11-17, UAT 2026-11-17 finding F2): the status of a mine ("mine-low" when its level is below the upgrade target) read the target with a fallback of 2 when the player had set none. The fallback is 0 now
 *   (no target = no target), so a level-1 mine of a resource without a target is "mine-unbuffed" / "mine-buffed", not "mine-low". A stored target keeps its meaning. Green 0.9.4, control 0.2.112 and the construction
 *   manager 0.1.3 plan and send no upgrade without a target either.
 *   Unit: tests/unit/dma-agents-no-upgrade-target.test.js (slot status of a level-1 mine with and without a target). Integration: tests/integration/green-no-target-nothing-upgraded.test.js (green's side with the real policy).
 * 0.4.38 (2026-11-17, live comparison of 0.4.37's computed table with the learned table): the learned GetNeededTime is in GAME time, not
 *   real time: the running task collects mClientDeltaTime x timeBonus / 100 (decompiled cSpecialistTask: remaining = (needed - collected)
 *   / timeBonus x 100). Measured/computed was exactly the explorer type's time bonus / 100 (Lucky 3.0, Keener 2.0, Pirate 0.5, Humble
 *   1.0). Learned values are now converted to real ms (needed / timeBonus x 100) before they are stored; the durations file moves to
 *   format /2 and a /1 file (raw values) is ignored on load, so learning restarts. Nothing else changes.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js and tests/unit/dma-explorer-computed-duration.test.js (explorers with time bonus 150 and 200: the game time is converted, calibration ratio as before). Integration: unchanged.
 * 0.4.37 (2026-11-17, author: "Als je in het spel de expos selecteert en de specifieke zoektocht voor alle expos, geeft hij per individuele expo de exacte tijd, die kun je alvast overnemen en alsnog in de praktijk meten en bijstellen"; ADR 0077 addendum):
 *   the exact search time of each explorer is COMPUTED the way the game's specialist panel does (cSpecialistPanel.calculateSkillsOnTaskDuration), and used at once for choosing the explorer of a quest search order; the learned GetNeededTime
 *   table (0.4.36) keeps measuring and corrects it. (1) computeSearchMs(spec, main, sub): dur = global.specialistTaskDefinitions_vector[main].subtasks_vector[sub].duration; key = subDef.mainTask.taskName_string + subDef.taskType_string;
 *   over skill tree items + spec.skills items with level > 0, every ModifierVO of level_vector[level - 1] with (type_string empty or = key) and modifier_string "searchtime" does: if value != 0 then dur = value; dur = dur * multiplier + adder;
 *   result dur / spec.GetSpecialistDescription().GetTimeBonus() * 100. Every step is guarded: null when anything is unreadable. `global` is reached as the probes reach it: root.swmmo.getDefinitionByName("global") (root.global as fallback).
 *   Our task keys map to (main, sub) through the TASK table (advShort "2,0" ...). (2) Choice for a quest order: duration = own-id learned median, else computed, else type learned median, else none; source "learned:id" / "computed" (or
 *   "computed x cal") / "learned:type" / "none"; lowest first, unknowns last in the old order; recorded on the TK16 case and the TK73 execute fact. (3) Calibration: when a GetNeededTime is learned for an explorer and the computed value for the same
 *   (explorer, key) is available, both and the ratio are stored (dma-explorer-durations.json: calib per key: samples, count, median ratio); when the median ratio of a key over >= 3 samples differs from 1 by more than 2%, computed values of that key
 *   are multiplied by it ("computed x cal"). dma-explorer-orders.json shows per key the computed vs measured median ratio and n. (4) Once per start dma-explorer-orders.json holds a table of the computed durations of every explorer (idle and busy)
 *   for the four adventure searches in minutes (id, type, short, medium, long, veryLong), to compare with the game's overview.
 *   Unit: tests/unit/dma-explorer-computed-duration.test.js (the formula with value override, multiplier, adder, type filter, time bonus; guards; choice precedence; calibration; the table) and tests/unit/dma-explorer-search-orders.test.js (unchanged expectations).
 *   Integration: tests/integration/dma-quest-explorer-orders.test.js (quest manager + explorer manager: the explorer with the shortest computed time is sent on the quest's order, before anything is measured).
 * 0.4.36 (2026-11-17, author "ja", ADR 0077 addendum): the idle explorer for a quest search order (TK73) is the one that is fastest at THAT search, and the duration is LEARNED from practice, like the market prices (ADR 0076);
 *   nothing extra is sent and nothing in the game is changed. Live finding (dma-explorer-orders.json of 0.4.35): the explorer object has no duration method (the guessed GetTaskDuration / getTaskDuration / GetSearchDuration /
 *   getSearchDuration readers of 0.4.34 never matched: removed), but the RUNNING task object (explorer.GetTask()) has the zero-argument getter GetNeededTime = the real needed time of this search for this explorer (skills and
 *   traits included). (1) Learning: for each explorer that one of the module's open TK16 cases (the template sends and the order sends; the case carries the search key) shows busy, task.GetNeededTime() is read ONCE per
 *   send (only explorers tk16Review reads already: ADR 0040, no own scan) and kept per explorer id AND per explorer type name per search key: last value, count, median of the last 5. The value is kept RAW (the unit, ms or s,
 *   is not assumed: it is compared like with like; the status file shows one sample of GetNeededTime / GetRemainingTime / GetCollectedTime / GetBonusTime / GetTaskProgress raw so the unit can be read from it). The table is
 *   persisted to dma-explorer-durations.json (air FileStream, at most once a minute, loaded on start; a send already learned is not counted twice after a restart). (2) Choosing for a quest order: among the idle explorers the one
 *   with the lowest known duration for the search key (its own id's median first, else its type's median) goes first; explorers with no measurement follow in the old order. The TK16 case and the TK73 execute fact carry
 *   duration, durationSource ("learned:id" / "learned:type" / "none") and pick. (3) The template sends are unchanged: only quest orders use the learned choice. (4) dma-explorer-orders.json also holds the learned table summary
 *   (keys measured, explorers measured, per key) and the raw task-time sample.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js (learning from a fake task with GetNeededTime once per send, median of the last 5, persistence and reload, choice order own id > type > none, fallback to the old order, the template unchanged, the summary in the status file).
 *   Integration: tests/integration/dma-quest-explorer-orders.test.js (quest manager + explorer manager: the explorers that learned a shorter time at a search are the ones sent on the quest's order).
 * 0.4.35 (2026-11-16, live 20:52 UTC after 0.4.34 / quest 0.1.32 were deployed): (1) the quest manager 0.1.33 REJECTS a declared TK73 while the game's count is below the amount (two cases declared by the old 0.4.33,
 *   search:4434616.0#2 count 0/2 and search:4448052.0#0 count 0/4, stayed "declared"); DEMO: declare -> reject when the product does not hold, then the executor goes on. A "rejected" order is now open work like a promised one:
 *   needed = amount - progress (the game's count through the quest manager's reading), in flight = our own TK16 sends of the order still in progress (plus those finished since the count was last read), explorers are sent while
 *   in flight < needed, and it is DECLARED again only at the game's count (progress at the amount, or the trigger finished); a withdrawal (revoke request) is still allowed. A case restored from the persisted book in
 *   "declared" or "rejected" is handled the same way (the book is read every tick). (2) Diagnosis for the best-explorer choice, which read no duration live (the TK16 cases of the order carry duration "" and source ""): a status
 *   file dma-explorer-orders.json, written at most once a minute through the air FileStream, holds the open orders (key, task, amount, progress, in flight, sent, state, ...) and, once found, the describeType method and accessor
 *   names of ONE explorer object and of its task object (names only, those containing ur, ime, ask, kill, earch or peed, any case, at most 80 each) and the results of the zero-argument getters among them (get / is / has / can) called
 *   on that explorer. Nothing else changes.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js (a rejected order is resumed: needed = amount - progress, in flight bounds the sends, declared again only at the game's count; the status file and its describeType part).
 *   Integration: tests/integration/dma-quest-explorer-orders.test.js (quest manager + explorer manager: a restored "declared" case at 0/2 is rejected and the explorer manager sends again).
 * 0.4.34 (2026-11-16, live finding on "Finding New Routes" (uid 4434616.0): the long / very long TK73 orders were DECLARED "all N searches sent and the explorers are back" about 20 minutes after the send while the game's own
 *   counter was still 0; the game keeps a per-trigger count (dQuestTriggerVO { status, deltaStart }), the quest manager 0.1.32 reads it and answers DMA_Quest.searchProgress(key)): (1) CAUSE of the early declare: the old rule declared
 *   from the explorer manager's OWN bookkeeping - the sends it counted (orderSent / data.sent) reached the number asked and no TK16 of the order was in progress any more - and "no TK16 in progress" is only what this module
 *   observed of the explorers (GetTask() == null seen, a decline after 3 idle minutes that was not taken back once orderSent was empty after a restart, "no longer listed"), never what the game counted; a long search takes hours,
 *   so any TK16 that closed early ended the order. (2) The order is now driven by the game's count (ADR 0040: read through the quest manager's picture, not by a scan of our own): needed = amount - progress; in flight = our own
 *   TK16 sends of the order that are still in progress, plus those finished since the quest manager last read the count (and for a minute after, the game's count lags); explorers are sent while in flight < needed, so a search
 *   that ended without the count rising is not counted and is sent again. TK73 is DECLARED only when the game's count reaches the amount or the trigger is finished (status 1) - never from our own sends. (3) For a quest search the
 *   idle explorer that does it fastest is chosen: the duration of that search for each idle explorer is read from the game object (GetTaskDuration / getTaskDuration / GetSearchDuration with the search's category and
 *   sub-task) and the shortest goes first; an explorer whose duration cannot be read goes after those that can, in the old order (all unreadable = the old order, noted once with the duration-like methods of the explorer object
 *   so the reader can be fixed live). The chosen explorer, the duration and its source are recorded on the TK16 case and on the TK73 execute fact. searchOrders() lists amount, progress, inFlight, left, gameDone.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js (declare only on the game's count; a long search 20 minutes on with the specialist busy is not declared; a TK16 closed early / a decline after a restart does not declare and is
 *   sent again; in flight bounds the sends; the fastest explorer is chosen, fallback when no duration). Integration: tests/integration/dma-explorer-orders-policy.test.js, tests/integration/dma-quest-explorer-orders.test.js.
 * 0.4.33 (2026-11-16, found by the integration test of quest 0.1.31 (ADR 0077): a repeatable quest asks the same case key again after its first order was accepted): the count of searches sent on a
 *   search order (orderSent, kept in memory so a restart-proof book count and the batch in flight agree) is forgotten once the order is no longer open in the transaction book; before, a
 *   renewed order with the same key started with the old count, saw nothing left to send and declared at once. Nothing else changes.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js (the same key asked again after the first order closed is sent in full). Integration: tests/integration/dma-explorer-orders-policy.test.js (unchanged, green).
 * 0.4.32 (2026-11-16, ADR 0077 / backbone v3.21, author 2026-11-16 "ja": "when a ticked quest asks for specialists' searches, the explorer manager sends as many explorers on exactly that
 *   search as needed; afterwards they return to the normal template"): the explorer manager is the executor AR73 of TK73 "search order completing". It reads the open TK73 cases the quest manager
 *   requested (transaction book; key search:<quest uid>#<task index>; fields task = advShort | advMedium | advLong | advVeryLong, searches = how many, sent = how many sent), promises one it may do
 *   (the Expo switch is on, the task is an adventure search), and sends idle explorers on exactly that search BEFORE the template, through the same send path and guards as the template
 *   (skill hold, "skill first", sent within 2 min, the batch lock): each send is a TK16 (its request fact carries order = the case key) and an execute fact on TK73 with sent = n; it never
 *   sends beyond searches. It declares when all searches are sent and every explorer of the order is back, allows a revoke request of the quest manager, and declines a task that is not an adventure
 *   search. A send the game did not start (the TK16 decline) is taken back from the count. Every other explorer goes on the template as before; no policy is changed. searchOrders() lists the orders.
 *   Unit: tests/unit/dma-explorer-search-orders.test.js (promise, the count, none beyond, template for the rest, decline of a foreign task, allow of a revoke, declare when back).
 *   Integration: tests/integration/dma-explorer-orders-policy.test.js (explorer manager + transaction book + the real player policy: the Expo switch decides, the template policy stays; 2 short, 2 medium, 2 long, none beyond). The full flow with the quest manager is tested with quest 0.1.31 (next PR).
 * 0.4.31 (2026-11-16, Specialists page; the coordinator): the location manager's stock picture also holds the skill books (Manuscript, Tome, Codex — the names the game's own quest facts and dma-skills.json use), and
 *   stockNow() answers the last sample ({ resource: amount }) so a page can show books needed against books in stock. Unit: tests/unit/dma-stock-books.test.js (the books are sampled and stockNow reads them).
 *   Integration: tests/integration/dma-stock-books-picture.test.js (the books reach the picture from the game's resources).
 * 0.4.30 (2026-11-16, ADR 0074 step 4): the cycle also ticks the deposit search manager (DMA_DepositSearchManager, AR10) after the construction manager and before green, under the same pause, when it is ready.
 *   Unit: tests/unit/dma-agents-construction-tick.test.js (order manager, search manager, green). Integration: tests/integration/dma-deposit-search-handover.test.js.
 * 0.4.29 (2026-11-16, ADR 0074 step 3): the cycle also ticks the construction manager (DMA_ConstructionManager, AR20) before green, under the same "game not responding" pause, when the manager is ready (check());
 *   its rows join green's for the status summary. Without the manager nothing changes. Unit: tests/unit/dma-agents-construction-tick.test.js (ticked once per cycle before green, not when not ready; it sits in the branch that the "game not responding" pause already skips).
 *   Integration: tests/integration/dma-construction-manager-handover.test.js.
 * 0.4.28 (2026-11-16, architect verdict on PR #386): (1) the events picture carries over the event manager's full lookup
 *  (event 0.2.12 gameEventManager): game.gi.mEventManager, then swmmo.application.mGameInterface.mEventManager, then the
 *  class Events::EventManager (static, or its getInstance()). (2) "could not read" is distinguishable from "no event
 *  running": eventRunning(prefixes) answers undefined when the picture is unreadable (no picture yet, or no event manager
 *  found — the picture then says readable false and why), null when it is readable and no such event runs;
 *  anyEventRunning() answers undefined / false / true the same way; eventsReadable() answers the question itself. A read
 *  error after a good read keeps the last picture (unchanged). Consumers that test "!x" keep treating unreadable as
 *  not running.
 *  Unit expectation:        tests/unit/dma-events-picture.test.js (the three lookups; undefined vs null vs a running event).
 *  Integration expectation: tests/integration/dma-events-picture-flow.test.js (with the real policy: an event manager
 *                           reached only through swmmo is read; a client without one gives undefined, not null).
 * 0.4.27 (2026-11-16, backbone v3.16 (ADR 0071 D-3/D-5; MTK01 names the running events) and its addendum (model PR
 *  #384: DFS-48 "an event of [event name] is running", ARS-76-11, ARS-77-02); reconciliation R-13 "running events into the
 *  location manager's picture" (ADR 0040)): the location manager also keeps the EVENTS PICTURE {at, readable, running:
 *  [{name, start, stop}]} — the game's running events (Events:EventManager GetActiveEventNames, GetEventStartDate,
 *  GetEventStopDate), read at most once a minute at the end of every wake (no game event exists for it; ADR 0040 §1).
 *  events() returns it; eventRunning(prefixes) answers DFS-48 for an event name: the first running event whose game name
 *  starts with one of the prefixes (case ignored), else null; anyEventRunning() answers "an event is running" (DFS-41's
 *  given). The zombie hunt (Halloween only) and premium ("during an event") read it instead of the game. Nothing else
 *  changes; the event manager's own observation is moved here later (its own proposal).
 *  Unit expectation:        tests/unit/dma-events-picture.test.js (sampled once a minute; prefixes; not readable -> no
 *                           event running; a read error keeps the last picture).
 *  Integration expectation: tests/integration/dma-events-picture-flow.test.js (the agents' wake with the real policy keeps
 *                           the picture; Halloween's game name is found by the policy's event.halloween.gameNames).
 * 0.4.26 (2026-11-16, architecture review 2026-11-16 findings #5 and #8, ADR 0040): the location manager also keeps the
 *  PREMIUM PICTURE {at, until}: the end of the player's premium (cPlayerData.GetPremiumUntil, epoch ms), read at most
 *  once a minute at the end of every wake (no event exists for it; ADR 0040 §1 allows the read of a game value where no
 *  event exists). premium() returns it; the premium keeper (user_dma_premium.js 0.1.2) reads it and no longer reads the
 *  game itself. Nothing else changes.
 *  Unit expectation:        tests/unit/dma-premium-picture.test.js (sampled once a minute; null until read; a read
 *                           error keeps the last picture).
 *  Integration expectation: tests/integration/dma-premium-picture-flow.test.js (agents + premium 0.1.2 when present:
 *                           the keeper plans on the picture the location manager keeps).
 * 0.4.25 (2026-11-13, ADR 0065, author: "Ga verder" — troops for the next adventure are built in advance): the location
 *  manager also keeps the TROOP PICTURE, sampled with the stock (every 5 min): the free army (the client's armyFreeInfo
 *  after updateFreeArmyInfo) and the production queue of every military building (Barracks, EliteBarracks) as runs of
 *  equal rows [type, amount per row, rows, first index], read with named getters only (GetType, GetAmount, HasStarted;
 *  lesson 2026-11-05: no reflection over game collections). troops() returns the last picture; the troop manager
 *  (user_dma_troops.js) reads it and never reads the game itself (ADR 0040).
 *  Unit expectation:        tests/unit/dma-troops.test.js (the picture's shape is what the manager plans on).
 *  Integration expectation: five minutes after start DMA_Demo.troops() lists the free army and the Elite Barracks runs.
 * 0.4.20 (2026-11-05, ADR 0048, author: "maak er maar een business rule van" — which adventure for a short resource):
 *  the location manager also keeps the STOCK SERIES: every 5-min sample of every resource the player holds (the game's
 *  names and labels), 36 h in memory, seeded after a restart from the facts log of today and yesterday. stockTrends(h)
 *  gives per resource amount, change per hour (least squares over h hours) and hours left. The facts log is unchanged.
 *  Unit expectation:        three samples falling 100/h give perHour -100 and hoursLeft = amount / 100.
 *  Integration expectation: an hour after start stockTrends(1) lists the island's resources with their pace.
 * 0.4.19 (2026-11-03, author: "expos are not send away"): "game not responding" (explorers idle again after their send)
 *   paused the self-starters for 30 min, again and again (ten times on 2026-11-03); only a client restart made the game
 *   take sends again. The pause now also asks DMA_Control.restart.now — at most once an hour, never during an
 *   adventure's sends or attacks. Unit: tests/unit/dma-suspect-restart.test.js; integration: live, the next pause is
 *   followed by a restart and TK16 promises within 10 min after it.
 * 0.4.18 (2026-11-02, ADR 0038 migration step 5, author: "Voor de specialisten geldt hetzelfde ... als een zoekactie
 *   afgesloten is en een nieuwe zoekactie wordt gestart kan de oude transactie informatie naar het historie document"):
 *   TK16 (exploration) is one transaction per send, keyed by its search id (explorer id@send time), with the full DEMO 4
 *   pattern; what the specialist manager sends is unchanged. request (specialist manager (expo), with the explorer's id,
 *   name and search) -> promise (the game, observed: the explorer has a task) | decline (still idle 3 min after the send:
 *   "the game did not start the search") -> declare (the game, observed: the explorer is idle again) -> accept
 *   (specialist manager). An explorer no longer listed: revoke request + allow. The facts go through DMA_Demo.record, so
 *   the C-fact memory sees them (before, the local record call bypassed it).
 *   Unit/integration expectation: tests/integration/dma-tk16-transaction.test.js.
 * 0.4.24 (2026-11-10, author "Kijk online of je meer informatie hierover kunt vinden" — then "Ja"): "Best" by search
 *   length (docs/02-discovery/explorer-types.md): the length decides WHAT is found. Royal, Adventurous, Love Struck, Bold
 *   and Princess Zoe on adventure SHORT (the author's daily adventures — Horseback, Traitors, The Siege, Witch, Sleepy Reef
 *   — come from short; cheapest; per-search buffs / tokens); Keener and Intrepid on adventure VERY LONG (their extra
 *   rolls on the rare ones: Young Woodcutter, VLT); Candid and Emphatic on treasure PROLONGED (gold, platinum).
 *   Unit/integration: tests/integration/dma-expo-best-template.test.js.
 * 0.4.23 (2026-11-10, author: "zoek uit welke expos goed zijn in het vinden van avonturen, welke voor treasure en
 *   eventueel andere items zodat we een template kunnen maken dat elke expo type zoekt waar hij het beste in is"):
 *   (1) the task codes are read from the loader's own menu (scripts/4-specialists.js explorerDropSpec): treasure short
 *   1,0 / medium 1,1 / long 1,2 / very long 1,3 / prolonged ("Longest") 1,6 / Travelling Erudite (artefacts, needs the
 *   skill) 1,4 / Bean a Collada (rarity, needs the skill) 1,5; adventure search short 2,0 / medium 2,1 / long 2,2 / very
 *   long 2,3. Before, "prolonged" sent 1,4 (Travelling Erudite) and "artifact" sent 2,0 (a short ADVENTURE search);
 *   "artifact" stays an alias of 2,0 so a stored preference keeps doing what it did. (2) template "Best": every
 *   explorer type on the search it is best at (docs/02-discovery/explorer-types.md, source settlersonlinewiki.eu).
 *   (3) an explorer sent on Travelling Erudite / Bean a Collada without that skill goes on a very long treasure search.
 *   Unit: tests/integration/dma-expo-best-template.test.js; integration: live, the log shows each type on its search.
 * 0.4.22 (2026-11-10, ADR 0058 addendum; author: "Kun je kiezen voor alles hernoemen?" — "Ja"): namePlan(kind) gives,
 *   per specialist of the type, its name now, whether it is an own name and the name automatic naming would give it,
 *   by the player's spec.<type>.renameScope: "new" (nobody now), "unnamed" (default: those with the game's standard
 *   name) or "all" (everyone, renumbered 1..n in a stable order). An own name is the game's nickname form — a bold
 *   name followed by "(type)" (live dma-skills.json 2026-11-10: "<b>CG01</b> (Charming Geologist)"); the standard name
 *   is the bold type alone. The new name is prefix + number + suffix, the number the next free one of the type. The
 *   rename itself waits for the game call. Unit: tests/unit/dma-name-plan.test.js; integration: the console preview.
 * 0.4.21 (2026-11-10, ADR 0058; author: "Voor de specialisten hadden we afgesproken dat gecontroleerd zou worden of ze
 *   volledig geskilled zijn. Zo niet dan heeft de speler de kans die bij specialist te selecteren, zodat hij eerst
 *   geskilled wordt voordat hij gebruikt wordt, of tweede instelling, als er niet genoeg boeken zijn hem tot die tijd
 *   gebruiken, wel telkens controleren voor gebruik" — 16:55: "waarom staat de keuze van de specialisten voor het
 *   skillen er nog niet?"): per specialist the player's choice spec.use[<id>] = "first" (not used until fully skilled)
 *   or "use" (default: used until the books are there; skilled first when an executor can). BEFORE EVERY USE the
 *   specialist's own skill tree is read from the game (getSkillTree: sum of points against the tree's maxPoints), not
 *   a cached file. mayUse(item) answers for any specialist (explorers here; geologists through control's pick;
 *   generals for the roles that use them); specialistSkillState(kind) lists them with their choice for the console;
 *   setUseMode(id, mode) stores the choice. Skilling with books and renaming wait for the game calls (ADR 0058).
 *   Unit: tests/integration/dma-expo-fully-skilled.test.js (first: held and listed; use: sent; live tree read wins over
 *   the cache). Integration: live, an explorer set to "first" stays home and shows "waiting for skilling".
 * 0.4.17 (2026-10-30, author: "stuur de expos die niet volledig geskilled zijn ook maar uit, dus als je de books niet in huis
 *   hebt, stuur je ze wel uit, als je voldoende books hebt, dan skill je hem voordat je hem uitstuurt"): replaces the 0.4.13
 *   hold. An explorer that is not fully skilled (or whose skills are unknown) is SENT, unless a skill executor exists and
 *   reports it can skill this explorer now with the books in stock — then it is handed to that executor and sent on a
 *   later tick, once skilled. The executor is DMA_Control.skillExplorer(dotId) -> {started|cannot, reason}, with
 *   DMA_Control.canSkillExplorer(dotId) -> {ok, reason}; until it exists every explorer goes out (counted as
 *   "sent unskilled"). explorerSkillState() keeps listing them for the console.
 *   Unit expectation:        no canSkillExplorer -> a 20/31 explorer is in toSend; canSkillExplorer ok -> skillExplorer is
 *                            called once, the explorer is not sent this tick; canSkillExplorer not ok -> sent.
 *   Integration expectation: on the next expo round the explorers marked ✗ in the console go out too.
 * 0.4.16 (2026-10-29, live after 0.4.15: still "send 1/3: capacity 13 (proven), occupied 8" for Stone while every
 *   geologist came back with "too many deposits"): (1) for quarries (Stone, Marble, Granite) the mason stands BESIDE its
 *   deposit, so depositsNow counted both — the stone proof of 13 was 8 deposits + 5 masons. Now only the deposit counts.
 *   (2) A miss while a proof stands lowers a proof that is above the deposits that exist now ("capacity proof lowered");
 *   before, a standing proof ignored every miss. Only for quarries — the miscount was theirs; a depleted mine that still
 *   stands may count for the game, and lowering a mine proof on it would stop searches after its demolition.
 *   Unit expectation:        8 stone deposits + 5 masons -> depositsNow("Stone") = 8; proof 13 + a miss -> 8.
 *   Integration expectation: green then requests no Stone search (tests/integration/dma-capacity-proof-quarry.test.js).
 * 0.4.15 (2026-10-29, author: "terwijl geos terug komen zonder steen gevonden te hebben worden geos uitgestuurd voor
 *   steen"; the game: "Geologist failed ... Stones deposit, because you already have too many deposits of this type"):
 *   a stone deposit that runs out goes, and the next find lands on a NEW spot. That new spot withdrew the capacity proof,
 *   capacity fell back to the spots ever seen (gone ones included), and green sent several geologists at once — each
 *   came back without a find, proved the limit again, and the next new spot withdrew it again. A proof is now kept when a
 *   new spot appears; it is raised only when more deposits of R exist now than it allows (fact "capacity proof raised" /
 *   "capacity proof kept"), and a stored proof is no longer withdrawn on load because a spot came later.
 *   Unit expectation:        proven Stone = 2; a deposit goes and a new spot appears (2 exist) -> proven stays 2.
 *   Integration expectation: after that new spot, green requests no Stone search (tests/integration/dma-capacity-proof-kept.test.js).
 * 0.4.10 (2026-10-26, author: "today a new event starts, set the explorer template to event, tuned to bring in as many
 *   event items as possible"; guild chat tips: "lots of prolonged", "12 per prolonged"): (1) the active template is the
 *   rule expo.template (Daily | Event | Adventure); in a template other than Daily the template decides the search per
 *   explorer type, with "*" for every type it does not name; (2) the suspect rule counted explorers back within 15 min
 *   as "send had no effect" — fast explorers (Princess Zoe, Royal Explorer ...) finish a short search inside 15 min, so the
 *   pause every 32 min last night was false; now only an explorer idle again within 3 min counts.
 * 0.4.9 (2026-10-25, scheduled check: "game not responding" at 17:09, 17:37, 18:04, 18:19 UTC — each within minutes of a
 *   client restart — "N explorers idle again within 15 min of their send": the explorers were sent while the island was
 *   still loading (18:16:50, a minute after the 18:16 restart), the game ignored them, and the suspect rule paused every
 *   actor for 30 min. The 90 s grace of 0.4.8 ran from the moment the scripts load, which is before the login and the
 *   island. Now the grace runs from the moment the home island is loaded (its buildings are there: more than 50), and
 *   90 s after that the actors start.
 * 0.4.8 (2026-10-25, author: "the game gets slower and slower and the island hardly loads"): (1) a start-up grace —
 *   the first 90 s after the scripts load in the AIR client (window.runtime) no scan and no manager acts, so the
 *   island loads first; (2) the stock sample
 *   carries the client's memory (System.totalMemory / privateMemory, MB), so a growth can be tied to a time and a cause.
 * 0.4.7 (2026-10-25, author: "when I go to another island the orders carry on; they must stop"): while the player is
 *   on another island (DMA_Control.atHome() false) the tick does nothing — no scan (it would read the other island as
 *   ours), no managers; p-facts "away from home" / "back home".
 * 0.4.14 (2026-10-28, author: "with the event they must go as short as possible, except a few that must go longer;
 *   that can all be found online and must be in the template"): the Event template sends every explorer on a SHORT
 *   treasure search (Halloween 2026: 2-4 pumpkins per search, settlersonlinewiki.eu), except Romantic and Blacktree
 *   (long: their bonus starts there) and Benevolent (very long: its extra buff starts there). Replaces 0.4.10's
 *   "*": "prolonged".
 * 0.4.13 (2026-10-27; 0.4.11–0.4.12 are taken by the unmerged branch claude/expo-instant-return; author: "you can only send out expos that are fully skilled; if not, they must be presented on a
 *   list in the expo screen of our console"): the specialist manager sends an explorer only when its skill tree is
 *   full (points read from the game >= the tree's maxPoints). An explorer whose tree is not full, or whose skills
 *   could not be read, is not sent; DMA_Demo.explorerSkillState() lists them for the console (reason "not fully
 *   skilled N/M" or "skills unknown").
 * One tick (DMA_Control's manager loop, 30 s) runs the actors in a fixed order:
 *   1. Location manager   (island.auto)  observes the island -> memory.slots (green facts)
 *   2. Managers in green  (geo/build/upgrade/buff/demo.auto) assess and request
 *   3. Specialist manager (expo.auto)    sends explorers by template
 * Executors that a manager initiates have no switch of their own.
 * Each actor reports its state (off / blocked / idle / acting) for the console.
 *
 * 0.2.0 (2026-10-24)
 *  - Switches are read from the Player Policy only (no "dma.switches" side store).
 *  - Green is ticked here only; green no longer runs its own timer.
 *  - Legacy in-module managers removed: green is the single decider.
 *  - Actor status: DMA_Demo.actors().
 *  - Scan memory no longer overwrites player preferences (specPrefs/buffPrefs were lost on every scan).
 *  - Operational resources: DMA_Demo.operational() = resource kinds seen on the island
 *    (deposit, depleted deposit or mine), now or in the persisted grid history.
 *  - Explorers: every idle explorer, task from the chosen preference, else the default
 *    template ("Daily"), else "short"; a sent explorer is not sent again for 2 minutes.
 *  - The shared cycle log is appended to, not overwritten.
 *
 * 0.2.1 (2026-10-24, from the live test of 0.2.0)
 *  - Explorers: an explorer is marked as sent when it is queued, and no new batch starts while
 *    one is still being sent. 0.2.0 queued explorers again every 30 s while a batch of ~100
 *    (1 per second) was still running, so many got a second send.
 *  - Demolish threshold default 20 everywhere (the info line used 80, green 20).
 *
 * 0.2.2 (2026-10-24): explorer preferences are the player's facts and live in the Player
 *  Policy ("expo.prefs"), which persists to dma-policy.json; localStorage does not survive a
 *  client restart. Read when sending (the policy instance is created after this file loads).
 *
 * 0.3.0 (2026-10-24): the location manager keeps an island memory that survives a restart,
 *  file dma-island.json next to the client (air.File; localStorage does not survive). Facts:
 *  - spots: every deposit grid ever observed per resource (deposit, mine on it, depleted)
 *    -> capacity(R) = number of distinct spots. A spot never disappears from memory.
 *  - rate: per mine grid, amount samples -> measured units/second -> eta(grid) seconds; a rate
 *    counts only after a window of 15 minutes (shorter windows read 19..98/h for one mine type).
 *  - searches: geologist sends seen in DMA_Control (_dmaSearchTrack); on return, whether a new
 *    spot appeared for that resource. A return without a new spot while the island showed no
 *    free spot proves the capacity: capacityProven(R).
 *  API: DMA_Demo.island() -> { capacity(R), proven(R), spots(R), eta(grid), rate(grid), searches() }.
 *
 * 0.3.1 (2026-10-24, live): a capacity counts as proven only after two returns without a new spot
 *  while no spot was free (the first live returns came after 35-140 s, which may be the game
 *  refusing at once or an early detection; one return is not enough evidence). Proofs stored by
 *  0.3.0 on a single return are withdrawn on load.
 *
 * 0.4.5 (2026-10-25, live: "Geologist failed ... too many deposits of this type", and a new geo went out for iron at
 *  once): a search that returns without a new spot proves the capacity on the FIRST return, and the proven capacity is
 *  the number of deposits that exist now (spots ever seen include deposits that have gone). capacity(R) no longer
 *  raises a proof to the spots seen. A proof is withdrawn when a new spot appears, as before.
 *
 * 0.4.6 (2026-10-25, author: "for iron and marble an extra deposit is possible with a geo with Lucky Find; send it
 *  out until the extra deposit is found"; forum: "your geo gets a chance on finding one more iron deposit than the
 *  maximum"): for IronOre and Marble a proven limit leaves ONE extra deposit open to a Lucky Find geologist —
 *  island().lfWanted(R) says so until it is found. The new spot then raises the proof by one and marks it lfDone
 *  (not withdrawn), so no further LF search goes out for that resource.
 *
 * 0.4.0 (2026-10-24, author: "keep all facts, as DEMO intends"): a facts log, append-only, one JSON
 *  line per fact, one file per day next to the client: dma-facts-YYYY-MM-DD.jsonl (air.File APPEND).
 *  - c-acts: every request/promise/decline/execute green and the executors produce
 *    (DMA_Demo.record("c", {...}): tk/ars, rule, act, resource, grid, reason, result).
 *  - p-facts observed by the location manager: new spot, mine appeared/gone, search returned,
 *    capacity proven.
 *  - stock: every 5 minutes the amount of every production good in the store (game.getResources()).
 *  The log is the remembering kind of the I-organisation made physical; nothing is overwritten.
 *  Buff preferences per building type are the player's facts: stored in the policy ("buff.prefs").
 * No tso settings.json.
 */
(function (root) {
    "use strict";
    var VERSION = "0.4.46";
    var memory = { scannedAt: 0, slots: [], buffPrefs: {}, buffAreas: {}, specPrefs: {}, specTemplates: {} };
    var logLines = [];

    function note(s) {
        var line = new Date().toISOString().slice(11, 19) + " " + s;
        logLines.push(line);
        if (logLines.length > 80) logLines.shift();
        try {
            if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = [];
            root.__DMA_CYCLE_LOG.push(line);
            if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200);
            root.__DMA_CYCLE_AT = Date.now();
        } catch (_) {}
    }
    function pol(k, d) {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && p.get) {
                var v = p.get(k);
                if (v != null && v !== "") return v;
            }
        } catch (_) {}
        return d;
    }
    function on(key) { return pol(key, false) === true; }

    /* ---------- actor status (read by the console) ---------- */
    var ACTORS = [
        { key: "island.auto",  label: "Island",  actor: "location-manager",        needs: [] },
        { key: "geo.auto",     label: "Geo",     actor: "specialist-manager/geo",  needs: ["island.auto"], ars: "search" },
        { key: "expo.auto",    label: "Expo",    actor: "specialist-manager/expo", needs: [] },
        { key: "build.auto",   label: "Build",   actor: "building-manager",        needs: ["island.auto"], ars: "build" },
        { key: "upgrade.auto", label: "Upgrade", actor: "upgrade-manager",         needs: ["island.auto"], ars: "upgrade" },
        { key: "buff.auto",    label: "Buff",    actor: "buff-manager",            needs: ["island.auto"], ars: "buff" },
        { key: "demo.auto",    label: "Demo",    actor: "demolish-manager",        needs: ["island.auto"], ars: "demolish" }
    ];
    var status = {};
    function actorList() {
        try {
            var p = root.GCAF_PlayerPolicyInstance;
            if (p && typeof p.switches === "function") {
                var sw = p.switches(), i, out = [];
                for (i = 0; i < sw.length; i++) {
                    var known = null, j;
                    for (j = 0; j < ACTORS.length; j++) if (ACTORS[j].key === sw[i].key) known = ACTORS[j];
                    out.push({ key: sw[i].key, label: sw[i].label, actor: sw[i].actor, needs: sw[i].needs || [], ars: known ? known.ars : null });
                }
                return out;
            }
        } catch (_) {}
        return ACTORS;
    }
    function setStatus(key, state, reason) {
        status[key] = { state: state, reason: reason || "", at: Date.now() };
    }
    function actors() {
        var list = actorList(), out = [], i, a, s;
        for (i = 0; i < list.length; i++) {
            a = list[i];
            s = status[a.key] || { state: on(a.key) ? "idle" : "off", reason: "", at: 0 };
            if (on(a.key) && s.state === "off") s = { state: "idle", reason: "starts next cycle", at: s.at };
            if (!on(a.key) && s.state !== "off") s = { state: "off", reason: "", at: s.at };
            out.push({ key: a.key, label: a.label, actor: a.actor, on: on(a.key), state: s.state, reason: s.reason, at: s.at });
        }
        return out;
    }

    /* ---------- island memory (persisted) ---------- */
    var ISLAND_FILE = "dma-island.json";
    var island = { format: "dma-island/1", spots: {}, rates: {}, searches: [], proven: {} };
    function airApi() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
    function appFile(name) {
        try {
            var A = airApi();
            if (!A || !A.File || !A.File.applicationDirectory) return null;
            return new A.File(A.File.applicationDirectory.resolvePath(name).nativePath);
        } catch (_) { return null; }
    }
    function readIsland() {
        try {
            var A = airApi(), f = appFile(ISLAND_FILE);
            if (!f || !f.exists) return;
            var st = new A.FileStream();
            st.open(f, A.FileMode.READ);
            var d = JSON.parse(st.readUTFBytes(st.bytesAvailable));
            st.close();
            if (d && d.spots) {
                island.spots = d.spots || {};
                island.rates = d.rates || {};
                for (var rk in island.rates) {
                    if (island.rates.hasOwnProperty(rk) && island.rates[rk] && (island.rates[rk].t1 - island.rates[rk].t0) < 900000) island.rates[rk].ups = null;
                }
                island.searches = d.searches || [];
                island.proven = d.proven || {};
                island.lastSpotAt = d.lastSpotAt || {};
                for (var pk in island.proven) {
                    if (!island.proven.hasOwnProperty(pk)) continue;
                    var pv = island.proven[pk];
                    if (!(pv && pv.misses >= 1)) delete island.proven[pk];   // 0.4.5: one miss proves; 0.4.15: a later spot no longer withdraws it
                }
            }
        } catch (_) {}
    }
    var lastIslandWrite = 0;
    function writeIsland(force) {
        var now = Date.now();
        if (!force && now - lastIslandWrite < 60000) return;
        lastIslandWrite = now;
        try {
            var A = airApi(), f = appFile(ISLAND_FILE);
            if (!f) return;
            if (island.searches.length > 300) island.searches = island.searches.slice(-300);
            var st = new A.FileStream();
            st.open(f, A.FileMode.WRITE);
            island.savedAt = new Date().toISOString();
            island.snapshot = (memory.slots || []).map(function (sl) {
                return { r: sl.resource, g: sl.grid, a: sl.amount, m: !!sl.mine, l: sl.level, b: !!sl.buffed, u: !!sl.upgrading, d: !!sl.depleted, n: sl.name, st: sl.status };
            });
            st.writeUTFBytes(JSON.stringify(island));
            st.close();
        } catch (_) {}
    }
    readIsland();

    /* ---------- facts log (append-only, one file per day) ---------- */
    var factBuf = [];
    function record(kind, data) {
        try {
            var o = { t: new Date().toISOString(), k: kind };
            for (var key in data) if (data.hasOwnProperty(key) && data[key] !== undefined && data[key] !== null && data[key] !== "") o[key] = data[key];
            factBuf.push(o);
            if (factBuf.length > 2000) factBuf.splice(0, factBuf.length - 2000);
        } catch (_) {}
    }
    function flushFacts() {
        if (!factBuf.length) return;
        try {
            var A = airApi();
            var f = appFile("dma-facts-" + new Date().toISOString().slice(0, 10) + ".jsonl");
            if (!A || !f) return;
            var st = new A.FileStream();
            st.open(f, A.FileMode.APPEND);
            st.writeUTFBytes(factBuf.map(function (o) { return JSON.stringify(o); }).join("\n") + "\n");
            st.close();
            factBuf = [];
        } catch (e) { note("facts log err " + e); }
    }
    var STOCK = ["Stone", "Marble", "Granite", "Wood", "RealWood", "ExoticWood", "MahoganyWood", "Plank", "RealPlank", "ExoticPlank", "MahoganyPlank",
                 "Tool", "BronzeOre", "Bronze", "IronOre", "Iron", "Steel", "Coal", "GoldOre", "Gold", "Coin", "TitaniumOre", "Titanium", "Salpeter",
                 "Gunpowder", "Brick", "Water", "Corn", "Flour", "Bread", "Fish", "Meat", "Sausage", "Horse", "BronzeSword", "IronSword", "SteelSword",
                 "Bow", "Longbow", "Crossbow", "Cannon", "Wheel", "Carriage", "Pinewood", "Hardwood", "Copper", "Platinum", "PlatinumOre",
                 "Manuscript", "Tome", "Codex"];   // 0.4.31: the skill books
    var lastStockAt = 0;
    function sampleStock(now) {
        if (now - lastStockAt < 300000) return;
        lastStockAt = now;
        var bag = null, out = {}, n = 0, i, v;
        try { bag = game.getResources && game.getResources(); } catch (_) {}
        if (!bag || !bag.GetResourceAmount) return;
        for (i = 0; i < STOCK.length; i++) {
            try { v = bag.GetResourceAmount(STOCK[i]); } catch (_) { v = null; }
            if (v != null && !isNaN(Number(v)) && Number(v) > 0) { out[STOCK[i]] = Number(v); n += 1; }
        }
        if (n) { var memo = { s: out }; try { var Sy = root.runtime && root.runtime.flash && root.runtime.flash.system && root.runtime.flash.system.System; if (Sy) { memo.memMB = Math.round(Number(Sy.totalMemory) / 1048576); if (Sy.privateMemory != null) memo.privMB = Math.round(Number(Sy.privateMemory) / 1048576); } } catch (_) {} record("stock", memo); }   // 0.4.8: memory
        rememberStock(now, bag);   // 0.4.20
        try { sampleTroops(now); } catch (_) {}   // 0.4.25
    }

    /* ---------- 0.4.25: the troop picture (ADR 0065) ---------- */
    var MILITARY = /^(Barracks|EliteBarracks)$/, troopPicture = null;
    function sampleTroops(now) {
        var pic = { at: now, free: {}, queues: {} }, R = root, k;
        try { if (typeof R.updateFreeArmyInfo === "function") R.updateFreeArmyInfo(true); var fi = R.armyFreeInfo || {};
              for (k in fi) if (fi.hasOwnProperty(k) && !isNaN(Number(fi[k]))) pic.free[k] = Number(fi[k]); } catch (_) {}
        try {
            var bv = game.gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector();
            for (var i = 0; bv && i < bv.length; i++) {
                var b = bv[i], nm = ""; if (!b) continue;
                try { nm = String(b.GetBuildingName_string()); } catch (_) { continue; }
                if (!MILITARY.test(nm) || pic.queues[nm]) continue;
                var q = b.productionQueue, v = q ? q.mTimedProductions_vector : null, n = v ? v.length : 0, runs = [], last = null, started = null;
                for (var j = 0; j < n; j++) {
                    var r = v[j], ty = String(r.GetType()), am = Number(r.GetAmount()) || 0;
                    if (j === 0 && r.HasStarted()) { started = { type: ty, amount: am }; continue; }
                    if (last && last[0] === ty && last[1] === am) last[2] += 1; else { last = [ty, am, 1, j]; runs.push(last); }
                }
                var lv = null; try { lv = Number(b.GetUpgradeLevel()); } catch (_) { lv = null; }   // 0.4.44
                pic.queues[nm] = { grid: Number(b.GetGrid()), type: q ? q.mProductionType : null, rows: n, started: started, runs: runs, level: lv > 0 ? lv : null };
            }
        } catch (_) {}
        troopPicture = pic;
    }
    /* ---------- 0.4.26: the premium picture (review 2026-11-16 #5/#8, ADR 0040) ---------- */
    var premiumPicture = null, lastPremiumAt = 0;
    /* ---------- 0.4.27: the events picture (MTK01 running events; DFS-48) ---------- */
    var eventsPicture = null, lastEventsAt = 0;
    function sampleEvents(now) {
        if (lastEventsAt && now - lastEventsAt < 60000) return eventsPicture;
        lastEventsAt = now;
        var em = findEventManager();
        if (!em) { eventsPicture = { at: now, readable: false, why: "no event manager", running: [] }; return eventsPicture; }   // 0.4.28
        try {
            var raw = em.GetActiveEventNames(), names = [], i, out = [];
            if (raw && typeof raw.length === "number") for (i = 0; i < raw.length; i++) names.push(String(raw[i]));
            else if (raw && typeof raw.forEach === "function") raw.forEach(function (n) { names.push(String(n)); });
            names.forEach(function (n) {
                var st = null, sp = null;
                try { var d1 = em.GetEventStartDate(n); st = d1 && d1.getTime ? d1.getTime() : (typeof d1 === "number" ? d1 : null); } catch (_) {}
                try { var d2 = em.GetEventStopDate(n); sp = d2 && d2.getTime ? d2.getTime() : (typeof d2 === "number" ? d2 : null); } catch (_) {}
                out.push({ name: n, start: st, stop: sp });
            });
            eventsPicture = { at: now, readable: true, running: out };
        } catch (_) { /* keep the last picture */ }
        return eventsPicture;
    }
    /* 0.4.28: the event manager's full lookup, carried over from event 0.2.12 gameEventManager (architect, PR #386) */
    function findEventManager() {
        var gi = null, em = null, sw = null;
        try { gi = (typeof game !== "undefined" && game && game.gi) ? game.gi : null; } catch (_) {}
        try { em = gi && gi.mEventManager; } catch (_) { em = null; }
        if (em && typeof em.GetActiveEventNames === "function") return em;
        try { sw = (typeof swmmo !== "undefined") ? swmmo : root.swmmo; } catch (_) { sw = null; }
        try { em = sw && sw.application && sw.application.mGameInterface && sw.application.mGameInterface.mEventManager; } catch (_) { em = null; }
        if (em && typeof em.GetActiveEventNames === "function") return em;
        try {
            var cls = sw && typeof sw.getDefinitionByName === "function" && sw.getDefinitionByName("Events::EventManager");
            if (cls && typeof cls.GetActiveEventNames === "function") return cls;
            if (cls && typeof cls.getInstance === "function") { em = cls.getInstance(); if (em && typeof em.GetActiveEventNames === "function") return em; }
        } catch (_) {}
        return null;
    }
    function eventsReadable() { return !!(eventsPicture && eventsPicture.readable); }   // 0.4.28
    function eventRunning(prefixes, now) {
        var p = eventsPicture, list = (Object.prototype.toString.call(prefixes) === "[object Array]" ? prefixes : String(prefixes || "").split(",")).map(function (x) { return String(x).replace(/^\s+|\s+$/g, "").toLowerCase(); }).filter(function (x) { return !!x; });
        if (!p || !p.readable) return undefined;   // 0.4.28: could not read — not "no event running"
        now = now || Date.now();
        for (var i = 0; i < p.running.length; i++) {
            var e = p.running[i], n = String(e.name).toLowerCase();
            if (e.stop && e.stop <= now) continue;
            for (var j = 0; j < list.length; j++) if (n.indexOf(list[j]) === 0) return JSON.parse(JSON.stringify(e));
        }
        return null;
    }
    function anyEventRunning(now) {
        var p = eventsPicture; if (!p || !p.readable) return undefined; now = now || Date.now();   // 0.4.28
        return p.running.some(function (e) { return !(e.stop && e.stop <= now); });
    }
    function samplePremium(now) {
        if (lastPremiumAt && now - lastPremiumAt < 60000) return premiumPicture;
        lastPremiumAt = now;
        try { var u = Number(game.gi.mCurrentPlayer.GetPremiumUntil()); if (!isNaN(u)) premiumPicture = { at: now, until: u }; } catch (_) {}
        return premiumPicture;
    }
    /* ---------- 0.4.20: the stock series (ADR 0048) ----------
       Every stock sample of every resource the player holds (the game's own names and labels) is kept in memory for
       STOCK_KEEP_MS; after a restart the series is seeded from the facts log of today and yesterday ("stock" lines).
       stockTrends() gives per resource the amount now, the change per hour (least squares over the window) and the
       hours until it is gone at that pace. Managers read it; only the location manager samples. */
    var STOCK_KEEP_MS = 36 * 3600000, stockSeries = [], stockLabels = {}, stockSeeded = false;
    function rememberStock(now, bag) {
        var s = {}, n = 0, v, i, r, nm;
        try {
            v = bag.GetPlayerResources_vector ? bag.GetPlayerResources_vector() : null;
            for (i = 0; v && i < v.length; i++) {
                r = v[i]; if (!r) continue;
                nm = String(r.name_string != null ? r.name_string : (r.GetName_string ? r.GetName_string() : ""));
                if (!nm) continue;
                s[nm] = Number(r.amount) || 0; n += 1;
                if (!stockLabels[nm]) { try { if (typeof loca !== "undefined" && loca.GetText) stockLabels[nm] = String(loca.GetText("RES", nm) || ""); } catch (_) {} }
            }
        } catch (_) {}
        if (!n) { for (i = 0; i < STOCK.length; i++) { try { var a = bag.GetResourceAmount(STOCK[i]); if (a != null && !isNaN(Number(a))) { s[STOCK[i]] = Number(a); n += 1; } } catch (_) {} } }
        if (!n) return;
        try { var av = game.gi.mCurrentPlayer.getAvailableBuffs_vector(), si, bv, bn, br, ba;   // 0.4.43: the star (ADR 0088 S-3)
              for (si = 0; av && si < av.length; si++) { try { bv = av[si]; if (!bv) continue; bn = String(bv.GetBuffDefinition().GetName_string()); br = "";
                  try { br = String(bv.GetResourceName_string() || ""); } catch (_) {} ba = Number(bv.GetAmount()) || 0;
                  var sk = "star:" + bn + (br ? ":" + br : ""); s[sk] = (s[sk] || 0) + ba; } catch (_) {} } } catch (_) {}
        seedStock();
        stockSeries.push({ t: now, s: s });
        while (stockSeries.length && now - stockSeries[0].t > STOCK_KEEP_MS) stockSeries.shift();
    }
    function seedStock() {
        if (stockSeeded) return;
        stockSeeded = true;
        var A = airApi(), d, k, f, st, lines, j, o, seed = [];
        for (k = 1; k >= 0; k--) {
            d = new Date(Date.now() - k * 86400000).toISOString().slice(0, 10);
            try {
                f = appFile("dma-facts-" + d + ".jsonl");
                if (!A || !f || !f.exists) continue;
                st = new A.FileStream(); st.open(f, A.FileMode.READ); lines = st.readUTFBytes(st.bytesAvailable).split("\n"); st.close();
                for (j = 0; j < lines.length; j++) {
                    if (lines[j].indexOf('"k":"stock"') < 0) continue;
                    try { o = JSON.parse(lines[j]); if (o && o.s) seed.push({ t: Date.parse(o.t), s: o.s }); } catch (_) {}
                }
            } catch (_) {}
        }
        seed = seed.filter(function (x) { return x.t && Date.now() - x.t <= STOCK_KEEP_MS; });
        stockSeries = seed.concat(stockSeries);
    }
    function stockTrends(windowHours) {
        seedStock();   // after a restart the series is there before the first sample
        var w = (Number(windowHours) || 6) * 3600000, last = stockSeries[stockSeries.length - 1], out = [];
        if (!last) return out;
        var pts = stockSeries.filter(function (x) { return last.t - x.t <= w; });
        Object.keys(last.s).forEach(function (nm) {
            var xs = [], ys = [];
            pts.forEach(function (p) { if (p.s[nm] != null) { xs.push((p.t - last.t) / 3600000); ys.push(Number(p.s[nm])); } });
            if (xs.length < 3 || xs[xs.length - 1] - xs[0] < (w / 3600000) / 2) return;   // at least half the window seen
            var mx = 0, my = 0, i, sxx = 0, sxy = 0;
            for (i = 0; i < xs.length; i++) { mx += xs[i]; my += ys[i]; }
            mx /= xs.length; my /= ys.length;
            for (i = 0; i < xs.length; i++) { sxx += (xs[i] - mx) * (xs[i] - mx); sxy += (xs[i] - mx) * (ys[i] - my); }
            var slope = sxx ? sxy / sxx : 0, amt = Number(last.s[nm]) || 0;
            out.push({ id: nm, label: stockLabels[nm] || "", amount: amt, perHour: slope, hoursLeft: slope < 0 ? amt / -slope : Infinity, samples: xs.length });
        });
        return out;
    }
    var LF_RES = { IronOre: 1, Marble: 1 };                   // 0.4.6: one extra deposit possible with Lucky Find
    function lfWanted(r) {
        var pv = island.proven[r];
        return !!(pv && LF_RES[r] && !pv.lfDone && depositsNow(r) >= pv.capacity);
    }
    var QUARRY_RES = { Stone: 1, Marble: 1, Granite: 1 };     // 0.4.16: a mason stands beside its deposit, not on it
    function depositsNow(r) {                                 // 0.4.5: deposits of R on the island now (with or without a mine)
        var n = 0, i, s;
        for (i = 0; i < (memory.slots || []).length; i++) {
            s = memory.slots[i];
            if (!s || s.resource !== r || s.depleted) continue;
            if (QUARRY_RES[r] && (s.mine || /mine|mason|quarry/i.test(String(s.name || "")))) continue;   // 0.4.16: count the deposit, not its mason
            n += 1;
        }
        return n;
    }
    function spotCount(r) {
        var g = island.spots[r] || {}, n = 0, k;
        for (k in g) if (g.hasOwnProperty(k)) n += 1;
        return n;
    }
    /* deposits seen in this scan (the deposit container lists the deposit under a mine as well) */
    function learnSpots(deposits, now) {
        var i, d;
        for (i = 0; i < deposits.length; i++) {
            d = deposits[i];
            if (!d || d.grid == null || !d.name) continue;
            try { if (root.DMA_Spots && typeof root.DMA_Spots.observe === "function") root.DMA_Spots.observe(d.name, d.grid); } catch (_) {}   // 0.4.42 (ADR 0086): the spot watcher
            if (!island.spots[d.name]) island.spots[d.name] = {};
            var sp = island.spots[d.name][String(d.grid)];
            if (!sp) {
                island.spots[d.name][String(d.grid)] = sp = { first: now };
                if (!island.lastSpotAt) island.lastSpotAt = {};
                island.lastSpotAt[d.name] = now;
                if (island.proven[d.name] && LF_RES[d.name] && !island.proven[d.name].lfDone) {   // 0.4.6: the Lucky Find extra
                    var pv0 = island.proven[d.name];
                    island.proven[d.name] = { capacity: pv0.capacity + 1, at: now + 1, misses: pv0.misses, lfDone: true };
                    record("p", { fact: "lucky find extra deposit", resource: d.name, grid: d.grid, capacity: pv0.capacity + 1 });
                    note("island " + d.name + ": Lucky Find extra deposit @" + d.grid + ", limit now " + (pv0.capacity + 1));
                } else if (island.proven[d.name]) {
                    /* 0.4.15: a new spot is a deposit that moved (a depleted one went, a find landed elsewhere), not a
                       higher limit. The proof stays; it is raised only when more deposits exist NOW than it allows. */
                    var pvN = island.proven[d.name], nowN = depositsNow(d.name);
                    if (nowN > pvN.capacity) {
                        record("p", { fact: "capacity proof raised", resource: d.name, was: pvN.capacity, capacity: nowN, grid: d.grid });
                        note("island capacity proof of " + d.name + " raised to " + nowN + ": new spot @" + d.grid);
                        pvN.capacity = nowN;
                    } else {
                        record("p", { fact: "capacity proof kept", resource: d.name, capacity: pvN.capacity, depositsNow: nowN, grid: d.grid });
                    }
                }
                note("island new spot " + d.name + " @" + d.grid + " (" + spotCount(d.name) + " known)");
                record("p", { fact: "spot found", resource: d.name, grid: d.grid, amount: d.amount, spots: spotCount(d.name) });
            }
            sp.last = now;
            sp.amount = d.amount;
            sp.depleted = !!d.depleted;
        }
    }
    /* measured depletion rate per mine: samples reset when level or buff state changes */
    var prevMines = null;
    function learnMines(slots) {
        var cur = {}, i, s, g;
        for (i = 0; i < slots.length; i++) { s = slots[i]; if (s && s.mine && !s.depleted) cur[String(s.grid)] = { r: s.resource, l: s.level, n: s.name }; }
        if (prevMines) {
            for (g in cur) if (cur.hasOwnProperty(g)) {
                if (!prevMines[g]) record("p", { fact: "mine constructed", resource: cur[g].r, grid: g, level: cur[g].l, name: cur[g].n });
                else if (prevMines[g].l !== cur[g].l && cur[g].l) record("p", { fact: "mine level", resource: cur[g].r, grid: g, from: prevMines[g].l, level: cur[g].l });
            }
            for (g in prevMines) if (prevMines.hasOwnProperty(g) && !cur[g]) record("p", { fact: "mine gone", resource: prevMines[g].r, grid: g, level: prevMines[g].l });
        }
        prevMines = cur;
    }
    function learnRates(slots, now) {
        var i, s, r, key;
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (!s || !s.mine || s.amount == null || s.depleted) continue;
            key = String(s.grid);
            r = island.rates[key];
            var state = (s.level || 0) + "/" + (s.buffed ? 1 : 0);
            if (!r || r.state !== state || Number(s.amount) > Number(r.a0)) {
                island.rates[key] = { state: state, t0: now, a0: Number(s.amount), t1: now, a1: Number(s.amount), ups: r && r.ups || null };
                continue;
            }
            if (Number(s.amount) < Number(r.a1)) {
                r.t1 = now;
                r.a1 = Number(s.amount);
                if (r.t1 - r.t0 >= 900000 && r.a0 > r.a1) r.ups = (r.a0 - r.a1) / ((r.t1 - r.t0) / 1000);   /* >= 15 min: production drops in cycle steps */
            }
        }
    }
    /* geologist sends tracked by DMA_Control; a return without a new spot proves the capacity */
    var openSearch = {};
    function learnSearches(now) {
        var track = {};
        try { track = root._dmaSearchTrack || {}; } catch (_) {}
        var id;
        for (id in track) {
            if (!track.hasOwnProperty(id) || openSearch[id]) continue;
            var t = track[id];
            openSearch[id] = { resource: t.resource, start: t.start || now, spotsAtStart: spotCount(t.resource), freeAtStart: freeSpots(t.resource) };
        }
        for (id in openSearch) {
            if (!openSearch.hasOwnProperty(id) || track[id]) continue;
            var o = openSearch[id];
            delete openSearch[id];
            var found = spotCount(o.resource) > o.spotsAtStart;
            island.searches.push({ resource: o.resource, start: o.start, end: now, seconds: Math.round((now - o.start) / 1000), newSpot: found });
            record("p", { fact: "search returned", resource: o.resource, seconds: Math.round((now - o.start) / 1000), newSpot: found, freeAtStart: o.freeAtStart });
            /* 0.4.5 (live 2026-10-25: "Geologist failed ... because you already have too many deposits of this type", and a
               new geo went out for iron at once): a return without a new spot IS the game saying the limit is reached.
               One miss proves it, and the capacity is the number of deposits that exist NOW — not the spots ever seen,
               which include deposits that have since gone (iron: 22 seen, 20 exist, the game's limit). */
            /* 0.4.16 (quarries): a miss while a proof stands is the game's word too: a proof above the deposits that exist now
               is lowered to them (a stored proof of 13 stone counted 5 masons beside their 8 deposits). */
            if (!found && QUARRY_RES[o.resource] && island.proven[o.resource] && !island.proven[o.resource].lfDone && depositsNow(o.resource) < island.proven[o.resource].capacity) {
                var pvL = island.proven[o.resource], lowN = depositsNow(o.resource);
                record("p", { fact: "capacity proof lowered", resource: o.resource, was: pvL.capacity, capacity: lowN });
                note("island capacity proof of " + o.resource + " lowered " + pvL.capacity + " -> " + lowN + " (a search came back without a new spot)");
                pvL.capacity = lowN; pvL.at = now; pvL.misses = (pvL.misses || 0) + 1;
            }
            if (!found && !island.proven[o.resource]) {
                var misses = island.searches.filter(function (x) { return x.resource === o.resource && !x.newSpot && x.end >= (island.lastSpotAt && island.lastSpotAt[o.resource] || 0); }).length;
                var nowCap = depositsNow(o.resource);
                island.proven[o.resource] = { capacity: nowCap, at: now, misses: misses };
                record("p", { fact: "capacity proven", resource: o.resource, capacity: nowCap, misses: misses, spotsSeen: spotCount(o.resource) });
                note("island capacity proven " + o.resource + " = " + nowCap + " (a search came back without a new spot)");
            }
            note("island search return " + o.resource + " " + Math.round((now - o.start) / 60000) + " min " + (found ? "new spot" : "no new spot"));
        }
    }
    /* free spot = a known spot of R with nothing on it now (not a deposit, not a mine) */
    function freeSpots(r) {
        var g = island.spots[r] || {}, n = 0, k, i, occupied = {};
        for (i = 0; i < (memory.slots || []).length; i++) {
            var s = memory.slots[i];
            if (s && s.resource === r) occupied[String(s.grid)] = true;
        }
        for (k in g) if (g.hasOwnProperty(k) && !occupied[k]) n += 1;
        return n;
    }
    function islandApi() {
        return {
            capacity: function (r) { return island.proven[r] ? island.proven[r].capacity : spotCount(r); },   // 0.4.5: a proof is not raised by stale spots
            proven: function (r) { return !!island.proven[r]; },
            lfWanted: function (r) { return lfWanted(r); },           // 0.4.6
            spots: spotCount,
            spotGrids: function (r) { return Object.keys(island.spots[r] || {}); },   // 0.4.41 (ADR 0084): the fixed list of spots per resource
            freeSpots: freeSpots,
            rate: function (grid) { var x = island.rates[String(grid)]; return x && x.ups ? x.ups : null; },
            eta: function (grid, amount) {
                var x = island.rates[String(grid)];
                if (!x || !x.ups) return null;
                var a = amount != null ? Number(amount) : Number(x.a1);
                return a > 0 ? Math.round(a / x.ups) : 0;
            },
            searches: function () { return island.searches.slice(); },
            save: function () { writeIsland(true); }
        };
    }

    function realLevel(b) {        // 0.2.19 incident: GetUIUpgradeLevel may be a fixed UI overwrite; take the higher of real and UI
        try { if (root.DMA_Control && typeof root.DMA_Control.levelOf === "function") return Number(root.DMA_Control.levelOf(b)) || 0; } catch (_) {}
        var r = 0, u = 0;
        try { r = Number(b.GetUpgradeLevel ? b.GetUpgradeLevel() : b.mUpgradeLevel) || 0; } catch (_) {}
        try { u = Number(b.GetUIUpgradeLevel ? b.GetUIUpgradeLevel() : 0) || 0; } catch (_) {}
        return Math.max(r, u);
    }
    function liveAt(grid) {
        var out = { name: "", level: 0, upgrading: false, buffed: false, mine: false, amount: null };
        try {
            var zone = game.zone || (game.gi && game.gi.mCurrentPlayerZone);
            var b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid));
            if (!b) return out;
            out.name = b.GetBuildingName_string ? String(b.GetBuildingName_string()) : "";
            out.level = realLevel(b);                  // 0.4.4: real level, not the UI overwrite
            out.upgrading = !!(b.IsUpgradeInProgress && b.IsUpgradeInProgress());
            var pb = b.productionBuff;
            if (pb && pb.IsActive && game.gi) out.buffed = !!pb.IsActive(game.gi.GetClientTime());
            else out.buffed = !!(pb);
            out.mini = /_Mini$/i.test(out.name);   // 0.4.1: event mini mines (tributes) are not upgradable and use no regular spot
            // 0.4.3: a building is a mine for the self-starters ONLY when its kind is on control's verified list
            out.unknown = /mine|mason|quarry/i.test(out.name) && !/deposit|depleted|mountain/i.test(out.name) && !knownKind(out.name);
            out.mine = knownKind(out.name);
            try {
                if (b.GetAmount) out.amount = b.GetAmount();
                else if (b.GetResourceAmount) out.amount = b.GetResourceAmount();
            } catch (_) {}
        } catch (_) {}
        return out;
    }

    function overlayMine(slot, live) {
        if (!slot) return slot;
        var liveIsMine = !!(live && live.mine);   // 0.4.3: only a verified kind
        if (!liveIsMine && !slot.mine) return slot;
        if (liveIsMine) {
            slot.mine = true;
            slot.level = live.level || slot.level || 1;
            slot.upgrading = !!live.upgrading;
            slot.buffed = !!live.buffed;
            slot.name = live.name || slot.name;
            if (slot.amount == null && live.amount != null) slot.amount = live.amount;
        }
        var tgt = Number(pol("building.upgradeLevel." + slot.resource, 0));
        if (slot.depleted) slot.status = "depleted";
        else if (slot.upgrading) slot.status = "upgrading";
        else if (Number(slot.level) < tgt) slot.status = "mine-low";
        else if (!slot.buffed) slot.status = "mine-unbuffed";
        else slot.status = "mine-buffed";
        return slot;
    }

    /* ---------- 0.4.45 (ADR 0096): the location manager declares the island picture complete ----------
       Business rule R-PICTURE-COMPLETE: no manager sets an agenda while the location manager has not declared its picture
       complete. The location manager declares it when it is at home and two scans at least island.picture.settleSec apart
       (default 60) see the same mines and masons; it withdraws the declaration on leaving home, at client start,
       on a suspect scan, and on a scan that loses many mines at once (live 2026-11-24: all 17 masons left the picture for one
       scan every 8-10 min, and at 02:30 a titanium mine went into the build queue in such a gap). Such a scan is not taken
       into the picture: the last complete picture stays, and the scan's own counts are recorded to find the cause. A loss
       that holds for the settle time is real and is taken. */
    var picture = { complete: false, since: Date.now(), why: "client start", sig: null, sigAt: 0, declaredAt: 0, mines: 0, brokenSig: null, brokenAt: 0 };
    function pictureSettleMs() { var v = Number(pol("island.picture.settleSec", 60)); return (v >= 0 ? v : 60) * 1000; }
    function pictureWithdraw(why, extra) {
        picture.sig = null; picture.sigAt = 0;
        if (!picture.complete) { picture.why = why; return; }
        picture.complete = false; picture.since = Date.now(); picture.why = why;
        var o = { fact: "island picture withdrawn", rule: "R-PICTURE-COMPLETE", actor: "location manager", reason: why }, k;
        for (k in (extra || {})) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        record("p", o); note("island picture withdrawn: " + why);
    }
    function mineCount(slots) { var n = 0; (slots || []).forEach(function (s) { if (s && s.mine && !s.depleted) n += 1; }); return n; }
    /* the location manager's verdict on one scan: "take" it into the picture, or "broken" (keep the last complete picture) */
    function pictureJudge(map, slots, now) {
        var nb = Number(map && map.seen && map.seen.buildings) || ((map && map.buildings) || []).length, nm = mineCount(slots);
        var sig = String(nm);   // the mines and masons: other buildings (collectibles, drops) come and go
        if (map && map.home === false) { pictureWithdraw("away from home"); return "take"; }
        if (map && map.incomplete) {   // 0.4.46: control 0.2.117 marks a scan without buildings; no measurement, however long it lasts
            pictureWithdraw("scan incomplete: " + map.incomplete, { buildingsAt: map.buildingsAt || null, seen: map.seen });
            picture.brokenSig = null;
            return "broken";
        }
        if (picture.mines > 0) {   // measured against the last picture taken, declared or not
            var lost = picture.mines - nm;
            if (lost >= Math.max(3, Math.ceil(picture.mines * 0.25))) {
                if (picture.brokenSig !== sig) { picture.brokenSig = sig; picture.brokenAt = now; }
                if (now - picture.brokenAt < pictureSettleMs()) {
                    var by = {}, c = (map && map.counts && map.counts.building) || {}, k;
                    for (k in c) if (c.hasOwnProperty(k) && /mine|mason|quarry/i.test(k)) by[k] = c[k];
                    pictureWithdraw("a scan lost " + lost + " of " + picture.mines + " mines at once", { mines: nm, was: picture.mines, buildings: nb, seen: map && map.seen, minesByKind: by });
                    return "broken";
                }
            }
        }
        picture.brokenSig = null; picture.mines = nm;   // taken into the picture
        if (!picture.complete) {
            if (nb <= 50) { picture.sig = null; picture.why = "the island is still loading (" + nb + " buildings)"; return "take"; }
            if (picture.sig !== sig) { picture.sig = sig; picture.sigAt = now; picture.why = "settling: the same island must be seen for " + Math.round(pictureSettleMs() / 1000) + " s"; return "take"; }
            if (now - picture.sigAt >= pictureSettleMs()) {
                picture.complete = true; picture.since = now; picture.declaredAt = now; picture.why = "";
                record("p", { fact: "island picture complete", rule: "R-PICTURE-COMPLETE", actor: "location manager", buildings: nb, mines: nm, settledSec: Math.round((now - picture.sigAt) / 1000) });
                note("island picture complete: " + nb + " buildings, " + nm + " mines");
            }
        }
        return "take";
    }
    function pictureGate() { return !!(root.runtime || root.DMA_PICTURE_GATE); }   // the gate needs a live client (as the 0.4.9 start gate did); tests switch it on

    /* Scan executor: walk island, remember slots. */
    var lastScanAt = 0;
    function execScan() {
        var now = Date.now();
        if (now - lastScanAt < 8000) {
            note("scan skip recent, slots=" + (memory.slots || []).length);
            return { fact: "ac", reason: "cached", slots: (memory.slots || []).length };
        }
        var ctrl = root.DMA_Control;
        if (!ctrl || !ctrl.scan) { note("scan no ctrl"); return { fact: "dc", reason: "no-scan-executor" }; }
        note("scan calling ctrl.scan");
        ctrl.scan();
        lastScanAt = now;
        var map = ctrl.map ? ctrl.map() : {};
        note("scan map deposits=" + (map.deposits || []).length + " buildings=" + (map.buildings || []).length);
        /* 0.4.2: a scan that suddenly loses many deposits is a broken view of the island, not a fact */
        var nDep = (map.deposits || []).length;
        if (memory.lastDepCount && nDep < memory.lastDepCount * 0.75 && memory.lastDepCount - nDep >= 5) {
            suspect("scan lost deposits: " + memory.lastDepCount + " -> " + nDep);
            pictureWithdraw("scan lost deposits: " + memory.lastDepCount + " -> " + nDep);   // 0.4.45
            return { fact: "dc", reason: "scan suspect" };
        }
        memory.lastDepCount = nDep;
        var slots = [];
        var seen = {};
        var i, d, live, bld;
        for (i = 0; i < (map.deposits || []).length; i++) {
            d = map.deposits[i];
            if (!d || d.grid == null) continue;
            live = liveAt(d.grid);
            seen[String(d.grid)] = true;
            if (live.mini || live.unknown) { if (live.unknown) unknownKind(live.name, d.grid); continue; }   // 0.4.1/0.4.3: not a free spot, not ours
            slots.push(overlayMine(slotOf(d.name, d.grid, d.amount, !!d.depleted, live), live));
        }
        for (i = 0; i < (map.buildings || []).length; i++) {
            bld = map.buildings[i];
            if (!bld || bld.grid == null) continue;
            if (!/mine|mason|quarry/i.test(String(bld.name || ""))) continue;
            if (/deposit|depleted|mountain/i.test(String(bld.name || ""))) continue;
            if (/_Mini$/i.test(String(bld.name || ""))) continue;   // 0.4.1: mini mines are outside the self-starters' scope
            if (!knownKind(bld.name)) { unknownKind(bld.name, bld.grid); continue; }   // 0.4.3: declined by default
            live = liveAt(bld.grid);
            if (!live.mine) live = { name: bld.name, level: Number(bld.uiLevel || bld.level) || 1, upgrading: !!bld.upgradeInProgress, buffed: false, mine: true, amount: null };
            if (seen[String(bld.grid)]) {
                for (var k = 0; k < slots.length; k++) {
                    if (String(slots[k].grid) === String(bld.grid)) {
                        if (!slots[k].resource) slots[k].resource = resourceOf(bld.name) || slots[k].resource;
                        overlayMine(slots[k], live);
                    }
                }
                continue;
            }
            seen[String(bld.grid)] = true;
            slots.push(slotOf(resourceOf(bld.name), bld.grid, live.amount, false, live));
        }
        var known = {};
        slots.forEach(function (s) {
            if (!s.resource || s.grid == null) return;
            if (!known[s.resource]) known[s.resource] = {};
            known[s.resource][String(s.grid)] = true;
        });
        if (pictureJudge(map, slots, now) === "broken") {   // 0.4.45: a broken view is not taken; the last complete picture stays
            note("scan broken: the picture keeps " + picture.mines + " mines");
            return { fact: "dc", reason: "picture broken" };
        }
        memory.scannedAt = Date.now();
        memory.slots = slots;
        memory.queueFree = map.queueFree;
        memory.known = known;
        try {
            learnSpots(map.deposits || [], memory.scannedAt);
            learnMines(slots);
            learnRates(slots, memory.scannedAt);
            learnSearches(memory.scannedAt);
            sampleStock(memory.scannedAt);
            writeIsland(false);
        } catch (e) { note("island memory err " + e); }
        note("scan executor ac slots=" + slots.length + " unbuffed=" + slots.filter(function (s) { return s.status === "mine-unbuffed"; }).length);
        checkRules(slots);
        return { fact: "ac", slots: slots.length };
    }

    function checkRules(slots) {
        var i, s, margin = Number(pol("demolish.threshold", 20)) || 20;
        var unb = 0, low = 0;
        for (i = 0; i < slots.length; i++) {
            s = slots[i];
            if (s.status === "mine-unbuffed") unb += 1;
            if (s.mine && !s.depleted && s.amount != null && Number(s.amount) > 0 && Number(s.amount) <= margin) low += 1;
        }
        note("rules buff-due=" + unb + " demolish-due=" + low + " margin=" + margin);
    }

    function resourceOf(name) {
        name = String(name || "");
        if (/copper|bronze/i.test(name)) return "BronzeOre";
        if (/iron/i.test(name)) return "IronOre";
        if (/gold/i.test(name)) return "GoldOre";
        if (/coal/i.test(name)) return "Coal";
        if (/titanium/i.test(name)) return "TitaniumOre";
        if (/salpeter|saltpeter/i.test(name)) return "Salpeter";
        if (/marble/i.test(name)) return "Marble";
        if (/granite/i.test(name)) return "Granite";
        if (/stone|mason/i.test(name) && !/marble|granite/i.test(name)) return "Stone";
        return "";
    }
    function slotOf(resource, grid, amount, depleted, live) {
        var tgt = Number(pol("building.upgradeLevel." + resource, 0));
        var lv = live.level || 0;
        if (live.mine && lv < 1) lv = 1;
        var status = "deposit";
        if (depleted) status = "depleted";
        else if (live.mine && live.upgrading) status = "upgrading";
        else if (live.mine && lv < tgt) status = "mine-low";
        else if (live.mine && !live.buffed) status = "mine-unbuffed";
        else if (live.mine) status = "mine-buffed";
        return {
            resource: resource, grid: grid, amount: amount, depleted: depleted,
            mine: live.mine, level: lv, upgrading: live.upgrading, buffed: live.buffed,
            name: live.name, status: status
        };
    }


    /* ---------- operational resources: kinds the island has (sectors that are operational) ---------- */
    function operational() {
        var seen = {}, i, s, r, out = [];
        for (i = 0; i < (memory.slots || []).length; i++) {
            s = memory.slots[i];
            if (s && s.resource) seen[s.resource] = true;
        }
        var known = memory.known || {};
        for (r in known) if (known.hasOwnProperty(r) && r) seen[r] = true;
        for (r in island.spots) if (island.spots.hasOwnProperty(r) && r) seen[r] = true;
        for (r in seen) if (seen.hasOwnProperty(r)) out.push(r);
        return out;
    }

    /* ---------- managers in green: status from green's last assessment ---------- */
    function summariseGreen(rows) {
        var list = actorList(), i, a, j, r, pm, dc, why;
        for (i = 0; i < list.length; i++) {
            a = list[i];
            if (!a.ars) continue;
            if (!on(a.key)) { setStatus(a.key, "off", ""); continue; }
            var blockedBy = [];
            for (j = 0; j < (a.needs || []).length; j++) if (!on(a.needs[j])) blockedBy.push(a.needs[j]);
            if (blockedBy.length && !(memory.slots || []).length) {
                setStatus(a.key, "blocked", "needs " + blockedBy.join(", ") + " (no island facts)");
                continue;
            }
            pm = 0; dc = 0; why = "";
            for (j = 0; j < (rows || []).length; j++) {
                r = rows[j];
                if (r.ars !== a.ars) continue;
                if (r.fact === "pm") pm += 1;
                else { dc += 1; if (!why) why = (r.resource ? r.resource + ": " : "") + r.reason; }
            }
            if (pm) setStatus(a.key, "acting", pm + " request(s)" + (dc ? ", " + dc + " declined" : ""));
            else setStatus(a.key, "idle", dc ? why : "nothing to do");
        }
    }

    /* ---------- the tick ---------- */
    var ticking = false, wasAway = false, loadedAt = Date.now();   // 0.4.7, 0.4.8 (0.4.45: the 0.4.9 start heuristic gave way to the declared picture)
    /* 0.4.3 — SAFEGUARD (incident 2026-10-24): the self-starters act only on building kinds control has verified
       (DMA_Control.upgradableKind). An unknown mine-like kind is declined by default and recorded once. */
    var LOCAL_KINDS = { IronMine: 1, BronzeMine: 1, CopperMine: 1, GoldMine: 1, CoalMine: 1, TitaniumMine: 1, SalpeterMine: 1,
                        Mason: 1, StoneMason: 1, MarbleMason: 1, GraniteMason: 1, BronzeMineEndless: 1 };
    function knownKind(name) {
        var n = String(name || "").replace(/^\s+|\s+$/g, "");
        try { if (root.DMA_Control && typeof root.DMA_Control.upgradableKind === "function") return !!root.DMA_Control.upgradableKind(n); } catch (_) {}
        return Object.prototype.hasOwnProperty.call(LOCAL_KINDS, n);
    }
    var unknownSeen = {};
    function unknownKind(name, grid) {
        var n = String(name || "?");
        if (unknownSeen[n]) return;
        unknownSeen[n] = true;
        record("p", { fact: "unknown building kind", name: n, grid: grid, decision: "declined by default" });
        note("unknown building kind " + n + " @" + grid + ": declined by default");
    }
    /* 0.4.2: when the game stops responding (live 2026-10-24 14:06: black map, deposits gone from the scan,
       sends 'accepted' without effect for 17 h), the self-starters pause instead of repeating. */
    var PAUSE_MS = 1800000, pausedUntil = 0, pauseWhy = "";
    /* 0.4.19 (2026-11-03, author: "premium is not on, expos are not send away, what is going on?"): the pause alone
       did not end it — on 2026-11-03 it fired ten times (00:27 … 12:31 UTC, up to 109 explorers idle after their send)
       and only a client restart made the game take sends again. So a pause also asks the control module to restart the
       client: at most once an hour (dma-suspect-restart.json), never while an adventure run sends generals or attacks. */
    var SUSPECT_RESTART_GAP = 3600000;
    function suspectFile(obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air; if (!a || !a.File) return root.__DMA_SUSPECT_FILE = (obj === undefined ? root.__DMA_SUSPECT_FILE : obj);
              var f = new a.File(a.File.applicationDirectory.resolvePath("dma-suspect-restart.json").nativePath), st = new a.FileStream();
              if (obj === undefined) { if (!f.exists) return null; st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); }
              st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return obj; } catch (_) { return null; }
    }
    var SUSPECT_STALE_MIN = 5;   // 0.4.40
    function restartOnSuspect(why, now) {
        var C = root.DMA_Control;
        if (!C || !C.restart || typeof C.restart.now !== "function") return { ok: false, reason: "no control module" };
        var f = suspectFile() || {}, last = Number(f.lastRestartAt) || 0;
        if (now - last < SUSPECT_RESTART_GAP) return { ok: false, reason: "a restart for this less than an hour ago" };
        if (pol("control.selfRestart.on", false) !== true) return { ok: false, reason: "self-restart is off (control.selfRestart.on)" };   // 0.4.40 (ADR 0083)
        var sm = 0; try { sm = typeof C.restart.staleMinutes === "function" ? Number(C.restart.staleMinutes(now)) || 0 : 0; } catch (_) { sm = 0; }
        if (sm < SUSPECT_STALE_MIN) return { ok: false, reason: "the stock still moves (" + sm + " min still): the game carries out other work" };   // 0.4.40: a second signal
        try { var AV = root.DMA_Adventure; if (AV && typeof AV.restartSafe === "function" && !AV.restartSafe()) return { ok: false, reason: "an adventure run sends generals or attacks" }; } catch (_) {}
        var r = C.restart.now("game not responding: " + why, now) || { ok: false, reason: "no answer" };
        if (r.ok) suspectFile({ lastRestartAt: now, why: why });
        return r;
    }
    function suspect(why) {
        var now = Date.now();
        if (pausedUntil <= now) {
            record("p", { fact: "game not responding", why: why, pauseMin: PAUSE_MS / 60000 });
            var rr = restartOnSuspect(why, now);   // 0.4.19
            record("p", { fact: "client restart for game not responding", result: rr.ok ? "restarting" : "held", why: rr.ok ? why : rr.reason });
        }
        pausedUntil = now + PAUSE_MS;
        pauseWhy = why;
        note("PAUSE " + why);
    }
    function paused() { return pausedUntil > Date.now(); }
    function away() { try { var C = root.DMA_Control; return !!(C && typeof C.atHome === "function" && !C.atHome()); } catch (_) { return false; } }   // 0.4.7
    function wake() {
        if (ticking) return;
        if (away()) {                                                    // 0.4.7: on another island — no scan, no acts
            ["island.auto", "geo.auto", "build.auto", "upgrade.auto", "buff.auto", "demo.auto", "expo.auto"].forEach(function (k) { if (on(k)) setStatus(k, "paused", "away from home"); });
            if (!wasAway) { wasAway = true; record("p", { fact: "away from home", decision: "all actors paused" }); note("away from home: paused"); }
            pictureWithdraw("away from home"); flushFacts();   // 0.4.45 (ADR 0096): back home, the picture must settle again
            return;
        }
        if (wasAway) { wasAway = false; record("p", { fact: "back home", decision: "actors resume" }); }
        ticking = true;
        try {
            /* 1. location manager */
            if (on("island.auto")) {
                try {
                    var sc = execScan();
                    setStatus("island.auto", "acting", (memory.slots || []).length + " slots" + (sc && sc.reason === "cached" ? " (cached)" : ""));
                } catch (e) { setStatus("island.auto", "error", String(e && e.message ? e.message : e)); note("island err " + e); }
            } else {
                setStatus("island.auto", "off", (memory.slots || []).length ? "facts from " + Math.round((Date.now() - memory.scannedAt) / 60000) + " min ago" : "");
            }
            /* 0.4.45 (ADR 0096, R-PICTURE-COMPLETE): the managers set no agenda until the location manager declared its picture complete */
            var waitPicture = pictureGate() && !picture.complete;
            if (waitPicture) {
                var wp = "waiting for the island picture" + (picture.why ? " (" + picture.why + ")" : "");
                ["geo.auto", "build.auto", "upgrade.auto", "buff.auto", "demo.auto", "expo.auto"].forEach(function (k) { if (on(k)) setStatus(k, "starting", wp); });
                note(wp);
            }
            /* 2. managers in green */
            var rows = [];
            if (waitPicture) {
                /* status set above */
            } else if (paused()) {
                note("paused: " + pauseWhy);
                ["geo.auto", "build.auto", "upgrade.auto", "buff.auto", "demo.auto", "expo.auto"].forEach(function (k) { if (on(k)) setStatus(k, "paused", "game not responding: " + pauseWhy); });
            } else if (root.DMA_Green && typeof root.DMA_Green.tick === "function") {
                try { var CMgr = root.DMA_ConstructionManager; if (CMgr && typeof CMgr.check === "function" && CMgr.check()) rows = CMgr.tick() || []; } catch (e) { note("construction manager tick " + e); }   // 0.4.29: AR20, before green's search rows
                try { var DSMgr = root.DMA_DepositSearchManager; if (DSMgr && typeof DSMgr.check === "function" && DSMgr.check()) rows = rows.concat(DSMgr.tick() || []); } catch (e) { note("deposit search manager tick " + e); }   // 0.4.30: AR10
                try { var WFl = root.DMA_Workflows; if (WFl && typeof WFl.check === "function" && WFl.check()) rows = rows.concat(WFl.tick() || []); } catch (e) { note("workflows tick " + e); }   // 0.4.41 (ADR 0084)
                try { rows = rows.concat(root.DMA_Green.tick() || []); } catch (e) { note("green tick " + e); }
            } else {
                note("green not loaded: managers idle");
            }
            if (!paused() && !waitPicture) summariseGreen(rows);
            /* 3. specialist manager, explorers */
            try { tk16Review(); } catch (_) {}   // 0.4.18: also when Expo is off, so every send ends
            try { tk73Review(); } catch (_) {}   // 0.4.32: the explorer manager answers the quest manager's search orders
            try { writeDurations(false); } catch (_) {}    // 0.4.36: the learned durations, at most once a minute
            try { writeOrdersFile(false); } catch (_) {}   // 0.4.35: the status file of the open orders, at most once a minute
            if (paused() || waitPicture) {
                /* status already set above */
            } else if (on("expo.auto")) {
                try {
                    var n = sendExplorers();
                    setStatus("expo.auto", n > 0 ? "acting" : "idle", n > 0 ? n + " explorer(s) sent" : "no idle explorer");
                } catch (e) { setStatus("expo.auto", "error", String(e)); note("expo err " + e); }
            } else {
                setStatus("expo.auto", "off", "");
            }
        } finally {
            try { if (!memory.scannedAt || Date.now() - memory.scannedAt < 60000) sampleStock(Date.now()); } catch (_) {}
            try { samplePremium(Date.now()); } catch (_) {}   // 0.4.26
            try { sampleEvents(Date.now()); } catch (_) {}   // 0.4.27
            flushFacts();
            ticking = false;
        }
    }

    /* ---------- explorers ---------- */
    var DEFAULT_TEMPLATE = "Daily";
    var BUILTIN_TEMPLATES = {
        Daily: { "Romantic Explorer": "long", "Humble Explorer": "short", "Blacktree Explorer": "long", "Lucky Explorer": "advShort", "Savage Scout": "medium", "Explorer": "advShort" },   // 0.4.23: "artifact" was 2,0, an adventure search
        /* 0.4.14 (author 2026-10-28: "during the event as short as possible, except a few that must go longer"):
           short for every type, longer only where the explorer's own bonus starts at a longer search
           (en.tsomaps.com/handbook/explorers): Romantic 12x on long+, Blacktree buff on long+, Benevolent buff on very long+. */
        Event: { "*": "short", "Romantic Explorer": "long", "Blacktree Explorer": "long", "Benevolent Explorer": "veryLong" },
        /* 0.4.23: every type on the search it is best at (docs/02-discovery/explorer-types.md) */
        Best: { "*": "short",
            "Intrepid Explorer": "advVeryLong", "Keener Explorer": "advVeryLong", "Adventurous Explorer": "advShort", "Royal Explorer": "advShort",
            "Love Struck Explorer": "advShort", "Princess Zoe": "advShort", "Bold Explorer": "advShort", "Nora the Explorer": "advVeryLong",
            "Explorer": "advShort", "Experienced Explorer": "advShort", "Savage Scout": "advShort",
            "Candid Explorer": "prolonged", "Emphatic Explorer": "prolonged", "Courageous Explorer": "veryLong", "Bewitching Explorer": "veryLong",
            "Lovely Explorer": "veryLong", "Pirate Explorer": "veryLong", "Humble Explorer": "medium", "Romantic Explorer": "long", "Scared Explorer": "short",
            "Snowy Explorer": "erudite", "Motherly Explorer": "erudite", "Lucky Explorer": "erudite",
            "Benevolent Explorer": "prolonged", "Blacktree Explorer": "long", "Chummy Explorer": "veryLong", "Ghost Explorer": "short",
            "Fluffy Butte Explorer": "short", "Rina the Explorer": "short" }
    };
    var TASK = { short: "1,0", medium: "1,1", long: "1,2", veryLong: "1,3", prolonged: "1,6", erudite: "1,4", bean: "1,5",   // 0.4.23: the loader's menu
                 advShort: "2,0", advMedium: "2,1", advLong: "2,2", advVeryLong: "2,3", artifact: "2,0" };                    // "artifact": old name of 2,0
    var NEEDS_SKILL = { erudite: "travellingErudite", bean: "beanAColada" };                                                   // 0.4.23
    var sentAt = {};
    var expoSending = false;
    function templates() {
        try { if (root.DMA_EXP_TEMPLATES) return root.DMA_EXP_TEMPLATES; } catch (_) {}
        return BUILTIN_TEMPLATES;
    }
    function defaultTemplate() {
        var t = templates();
        var name = String(pol("expo.template", DEFAULT_TEMPLATE) || DEFAULT_TEMPLATE);   // 0.4.10
        return t[name] || t[DEFAULT_TEMPLATE] || BUILTIN_TEMPLATES[DEFAULT_TEMPLATE];
    }
    /* 0.4.13: fully-skilled state (0.4.17: no longer a gate — a not-fully-skilled explorer is skilled first when possible, else sent). */
    function dotIdOf(item) {
        try {
            var u = item.GetUniqueID && item.GetUniqueID();
            if (!u) return "";
            if (u.uniqueID1 != null) return String(u.uniqueID1) + "." + String(u.uniqueID2 || 0);
            if (u.UniqueID1 != null) return String(u.UniqueID1) + "." + String(u.UniqueID2 || 0);
            if (u.toKeyString) return String(u.toKeyString());
        } catch (_) {}
        return "";
    }
    function liveSkill(item) {                                   // 0.4.21: the game's own tree, read at the moment of use
        try {
            var tree = typeof item.getSkillTree === "function" ? item.getSkillTree() : null; if (!tree) return null;
            var def = typeof tree.getDefinition === "function" ? tree.getDefinition() : null;
            var max = Number(def && def.maxPoints) || 0, pts = typeof tree.getSumPoints === "function" ? Number(tree.getSumPoints()) || 0 : null;
            if (!(max > 0) || pts == null) return null;
            return { full: pts >= max, points: pts, max: max, reason: pts >= max ? "" : "not fully skilled " + pts + "/" + max, live: true };
        } catch (_) { return null; }
    }
    function skillStateOf(item) {
        var lv = liveSkill(item); if (lv) return lv;
        var r = null;
        try { var C = root.DMA_Control; if (C && C.skillsOf) r = C.skillsOf(dotIdOf(item)); } catch (_) {}
        if (!r || r.noTree || !r.tree || !(Number(r.tree.maxPoints) > 0)) return { full: false, points: null, max: null, reason: "skills unknown" };
        var pts = Number(r.points) || 0, max = Number(r.tree.maxPoints);
        return { full: pts >= max, points: pts, max: max, reason: pts >= max ? "" : "not fully skilled " + pts + "/" + max };
    }
    /* 0.4.21 (ADR 0058): the player's choice per specialist, and whether he may be used now */
    var KIND_BASE = { general: 0, explorer: 1, geologist: 2 };
    function useModes() { var m = pol("spec.use", null); return (m && typeof m === "object") ? m : {}; }
    function useMode(id) { var m = useModes()[String(id)]; return m === "first" ? "first" : "use"; }
    function setUseMode(id, mode) {
        var m = JSON.parse(JSON.stringify(useModes()));
        if (mode === "first") m[String(id)] = "first"; else delete m[String(id)];
        try { var inst = root.GCAF_PlayerPolicyInstance; if (inst && inst.requestChange) inst.requestChange("spec.use", m); } catch (_) {}
        return useMode(id);
    }
    function mayUse(item) {
        var st = skillStateOf(item), id = dotIdOf(item), mode = useMode(id);
        if (st.full) return { ok: true, mode: mode, state: st };
        if (mode === "first") return { ok: false, mode: mode, state: st, why: "waiting for skilling (" + (st.points == null ? "skills unknown" : st.points + "/" + st.max) + ")" };
        return { ok: true, mode: mode, state: st, why: "used until the books are there (" + st.reason + ")" };
    }
    function specialistSkillState(kind) {
        var base = KIND_BASE[kind] != null ? KIND_BASE[kind] : 1, out = [];
        (game.getSpecialists && game.getSpecialists() || []).forEach(function (item) {
            try {
                if (!item || !(item.GetBaseType && Number(item.GetBaseType()) === base)) return;
                if (item.getPlayerID && item.getPlayerID() == -1) return;
                var rawName = ""; try { rawName = item.getName && (item.getName(false) || item.getName(true)) || ""; } catch (_) {}
                var st = skillStateOf(item), id = dotIdOf(item), m = mayUse(item);
                out.push({ id: id, name: String(rawName).replace(/<[^>]*>/g, "").trim() || kind, full: st.full, points: st.points, max: st.max,
                           reason: st.reason, mode: useMode(id), held: !m.ok, idle: !(item.GetTask && item.GetTask() != null) });
            } catch (_) {}
        });
        return out;
    }
    /* 0.4.22 (ADR 0058 addendum): the naming plan per type — computed only, nothing is renamed here */
    var KIND_KEY = { general: "gen", explorer: "expo", geologist: "geo" };
    function nameParts(raw) {
        var t = String(raw || ""), m = /^\s*<b>([^<]*)<\/b>\s*(?:<font[^>]*>\s*\(([^)]*)\)\s*<\/font>)?/i.exec(t);
        if (m) return { name: m[1].trim(), type: m[2] ? m[2].trim() : m[1].trim(), own: !!m[2] };
        var plain = t.replace(/<[^>]*>/g, "").trim(); return { name: plain, type: plain, own: false };
    }
    function namePlan(kind) {
        var key = KIND_KEY[kind] || "expo", base = KIND_BASE[kind] != null ? KIND_BASE[kind] : 1;
        var scope = String(pol("spec." + key + ".renameScope", "unnamed")), pre = String(pol("spec." + key + ".prefix", "") || ""), suf = String(pol("spec." + key + ".suffix", "") || "");
        var rows = [];
        (game.getSpecialists && game.getSpecialists() || []).forEach(function (item) {
            try {
                if (!item || !(item.GetBaseType && Number(item.GetBaseType()) === base)) return;
                if (item.getPlayerID && item.getPlayerID() == -1) return;
                var raw = ""; try { raw = item.getName && (item.getName(false) || item.getName(true)) || ""; } catch (_) {}
                var np = nameParts(raw); rows.push({ id: dotIdOf(item), from: np.name, type: np.type, own: np.own });
            } catch (_) {}
        });
        rows.sort(function (a, b) { return String(a.id).localeCompare(String(b.id), undefined, { numeric: true }); });
        function esc(x) { return x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
        var re = new RegExp("^" + esc(pre) + "(\\d+)" + esc(suf) + "$"), used = {}, n = 0;
        if (scope === "all") rows.forEach(function (r) { r.to = pre + (++n) + suf; });
        else {
            rows.forEach(function (r) { var m = re.exec(r.from); if (r.own && m) used[Number(m[1])] = 1; });
            rows.forEach(function (r) { if (scope === "unnamed" && !r.own) { do { n += 1; } while (used[n]); used[n] = 1; r.to = pre + n + suf; } });
        }
        rows.forEach(function (r) { if (r.to === r.from) delete r.to; });
        return { kind: kind, scope: scope, prefix: pre, suffix: suf, rows: rows, changes: rows.filter(function (r) { return r.to; }).length };
    }
    function explorerSkillState() {
        var out = [];
        var specs = game.getSpecialists && game.getSpecialists();
        (specs || []).forEach(function (item) {
            try {
                if (!item || !(item.GetBaseType && Number(item.GetBaseType()) === 1)) return;
                if (item.getPlayerID && item.getPlayerID() == -1) return;
                var rawName = ""; try { rawName = item.getName && (item.getName(false) || item.getName(true)) || ""; } catch (_) {}
                var st = skillStateOf(item);
                out.push({ id: dotIdOf(item), name: String(rawName).replace(/<[^>]*>/g, "").trim() || "Explorer", full: st.full, points: st.points, max: st.max, reason: st.reason,
                           idle: !(item.GetTask && item.GetTask() != null) });
            } catch (_) {}
        });
        return out;
    }
    /* 0.4.18: TK16 — one transaction per send, reviewed against the explorers */
    function cfact(o) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); else record("c", o); } catch (_) {} }
    function tk16Review() {
        var M = root.DMA_Tx; if (!M) return;
        var now = Date.now(), byId = {};
        try { (game.getSpecialists() || []).forEach(function (item) { try { var uid = item.GetUniqueID && item.GetUniqueID(), sid = uid && uid.toKeyString && uid.toKeyString().split(".")[0]; if (sid) byId[sid] = item; } catch (_) {} }); } catch (_) { return; }
        M.list({ tk: "TK16", open: true }).forEach(function (t) {
            if (!M.inProgress("TK16", t.key) || t.revoking) return;
            var d = t.data || {}, item = byId[String(d.specId)], busy = false;
            try { busy = !!(item && item.GetTask && item.GetTask() != null); } catch (_) {}
            function act(a, x) { var o = { tk: "TK16", act: a, search: t.key, spec: d.spec }, k; for (k in x) o[k] = x[k]; cfact(o); }
            if (!item) { act("revoke request", { actor: "specialist manager (expo)", reason: "the explorer is no longer listed" }); act("allow", { actor: "game (tacit)" }); return; }
            if (busy && (t.state === "requested" || t.state === "promised")) { try { learnFrom(item, t, d); } catch (_) {} }   // 0.4.36: the game's needed time of this send, learned once
            if (t.state === "requested" && busy) { act("promise", { actor: "game (observed)" }); return; }
            if (t.state === "requested" && !busy && now - t.since >= 180000) {
                act("decline", { actor: "game (observed)", reason: "the game did not start the search (explorer idle 3 min after the send)" });
                if (d.order && orderSent[d.order] > 0) { orderSent[d.order] -= 1; t73("execute", d.order, { sent: orderSent[d.order], reason: "a send the game did not start is taken back" }); }   // 0.4.32
                return; }
            if (t.state === "promised" && !busy) { act("declare", { actor: "game (observed)", reason: "the explorer is back" }); act("accept", { actor: "specialist manager (expo)" }); }
        });
    }
    /* 0.4.32 (ADR 0077): TK73 "search order completing" - the explorer manager (AR73) executes what the quest manager (AR71) asks:
       sends idle explorers on exactly the searched task, before the template, until the number asked is sent */
    var ORDER_ACTOR = "explorer manager", orderSent = {};
    /* 0.4.34: the game's count of an order's task, through the quest manager's reading (ADR 0040); the order's own `done` (carried by the request) when the quest manager does not answer */
    function gameCount(key, d) {
        var Q = root.DMA_Quest, r = null, amount = Number(d.asked) || Number(d.searches) || 0, progress = Number(d.done) || 0, status = false, at = 0;
        try { if (Q && typeof Q.searchProgress === "function") r = Q.searchProgress(key); } catch (_) { r = null; }
        if (r) { if (r.progress != null && isFinite(Number(r.progress))) progress = Number(r.progress); if (Number(r.amount) > 0) amount = Number(r.amount); status = r.done === true; at = Number(r.at) || 0; }
        return { amount: amount, progress: progress, status: status, at: at, done: status || (amount > 0 && progress >= amount) };
    }
    function orderBook() {
        var M = root.DMA_Tx, out = [], now = Date.now(), tk16 = [];
        if (!M || typeof M.list !== "function") return out;
        try { tk16 = M.list({ tk: "TK16" }).filter(function (t) { return t.data && t.data.order; }); } catch (_) { tk16 = []; }
        try {
            M.list({ tk: "TK73", open: true }).forEach(function (t) {
                var d = t.data || {}, g = gameCount(t.key, d), sent = Math.max(Number(d.sent) || 0, orderSent[t.key] || 0), inflight = 0, pending = 0;
                tk16.forEach(function (x) {
                    if (x.data.order !== t.key || (Number(x.since) || 0) < (Number(t.since) || 0)) return;   // a send of an earlier order with the same key (a repeatable quest) is not this order's
                    if (x.state === "requested" || x.state === "promised" || x.state === "declared" || x.revoking) inflight += 1;
                    else if (x.state === "accepted" && ((Number(x.at) || 0) > g.at || now - (Number(x.at) || 0) < 60000) && now - (Number(x.at) || 0) < 10 * 60000) pending += 1;   // finished, the game's count not read again yet
                });
                var needed = g.done ? 0 : Math.max(0, g.amount - g.progress);
                out.push({ key: t.key, state: t.state, revoking: t.revoking || "", quest: d.quest || "", task: String(d.task || ""), asked: g.amount, amount: g.amount, progress: g.progress, gameDone: g.done,
                           needed: needed, inFlight: inflight, pending: pending, sent: sent, left: Math.max(0, needed - inflight - pending), since: t.since });
            });
        } catch (_) {}
        var live = {}; out.forEach(function (o) { live[o.key] = true; });
        Object.keys(orderSent).forEach(function (k) { if (!live[k]) delete orderSent[k]; });   // a closed order is forgotten: the same key can come again (a repeatable quest)
        out.sort(function (a, b) { return (a.since || 0) - (b.since || 0); });
        return out;
    }
    function t73(act, key, x) { var o = { tk: "TK73", act: act, caseId: key, actor: ORDER_ACTOR }, k; for (k in (x || {})) o[k] = x[k]; cfact(o); }
    function tk73Review() {
        var M = root.DMA_Tx; if (!M) return;
        orderBook().forEach(function (o) {
            if (o.revoking) { t73("allow", o.key, { reason: "the quest manager withdrew the order" }); return; }   // rv-rq: allowed, the sends already made are not recalled
            if (o.state === "requested") {
                if (!TASK[o.task] || !/^adv/.test(o.task)) { t73("decline", o.key, { reason: "not an adventure search the explorers can be sent on: " + (o.task || "no task") }); return; }
                if (!on("expo.auto")) return;                                  // the Expo switch is the player's: the order waits
                if (o.asked > 0) t73("promise", o.key, { task: o.task, searches: o.asked });
                return;
            }
            if ((o.state === "promised" || o.state === "rejected") && o.amount > 0 && o.gameDone)   // 0.4.34: declared on the game's count only (progress reached the amount, or the trigger is finished) - never on our own sends; 0.4.35: also again after a reject
                t73("declare", o.key, { sent: o.sent, progress: o.progress, amount: o.amount, reason: "the game counts " + o.progress + " of " + o.amount + " searches done" });
        });
    }
    function searchOrders() { return orderBook(); }
    /* 0.4.35: dma-explorer-orders.json - the open orders, and (once found) what the game's explorer and task objects offer that looks like a duration, so the best-explorer choice can be fixed from the file */
    var ORDERS_FILE = "dma-explorer-orders.json", ORDERS_MS = 60000, lastOrdersWrite = 0, ordersProbe = { explorer: null, task: null, getters: null };
    var NAME_RE = /ur|ime|ask|kill|earch|peed/i, GETTER_RE = /^(get|is|has|can)/i;
    function dtXml(o) { try { var rt = root.runtime || (root.window && root.window.runtime), dt = rt && rt.flash && rt.flash.utils && rt.flash.utils.describeType; return typeof dt === "function" ? String(dt(o)) : ""; } catch (_) { return ""; } }
    function members(o) {   // names only: { methods: [...], accessors: [...], noArg: [method names without a parameter], readable: [accessor names that can be read] }
        var x = dtXml(o), out = { methods: [], accessors: [], noArg: [], readable: [] }, re, m, nm, seen = {};
        if (!x) return null;
        re = /<method\b[^>]*?(?:\/>|>[\s\S]*?<\/method>)/g;
        while ((m = re.exec(x)) !== null) {
            nm = /name="([^"]+)"/.exec(m[0]); if (!nm || !NAME_RE.test(nm[1]) || seen["m" + nm[1]]) continue;
            seen["m" + nm[1]] = 1; if (out.methods.length < 80) out.methods.push(nm[1]);
            if (!/<parameter\b/.test(m[0])) out.noArg.push(nm[1]);
        }
        re = /<accessor\b[^>]*>/g;
        while ((m = re.exec(x)) !== null) {
            nm = /name="([^"]+)"/.exec(m[0]); if (!nm || !NAME_RE.test(nm[1]) || seen["a" + nm[1]]) continue;
            seen["a" + nm[1]] = 1; if (out.accessors.length < 80) out.accessors.push(nm[1]);
            if (!/access="writeonly"/.test(m[0])) out.readable.push(nm[1]);
        }
        return out;
    }
    function shown(v) {
        if (v == null) return null;
        if (typeof v === "number" || typeof v === "boolean") return v;
        if (typeof v === "function") return "[function]";
        try { return String(v).slice(0, 120); } catch (_) { return "[object]"; }
    }
    function probeOrders() {
        if (ordersProbe.explorer && ordersProbe.task) return;
        var specs = null, firstExp = null, withTask = null, i, item, tk;
        try { specs = game.getSpecialists && game.getSpecialists(); } catch (_) { specs = null; }
        if (!specs) return;
        for (i = 0; i < specs.length; i++) {
            item = specs[i]; if (!item) continue;
            try { if (!(item.GetBaseType && Number(item.GetBaseType()) === 1)) continue; } catch (_) { continue; }
            if (!firstExp) firstExp = item;
            try { tk = item.GetTask && item.GetTask(); } catch (_) { tk = null; }
            if (tk != null) { withTask = { item: item, task: tk }; break; }
        }
        if (!ordersProbe.explorer && firstExp) {
            var mem = members(firstExp), res = {}, names = [], n;
            if (mem) {
                mem.noArg.forEach(function (k) { if (GETTER_RE.test(k)) names.push(k); });
                mem.readable.forEach(function (k) { names.push(k); });
                names = names.slice(0, 40);
                names.forEach(function (k) {
                    try { n = firstExp[k]; res[k] = typeof n === "function" ? shown(n.call(firstExp)) : shown(n); } catch (e) { res[k] = "error: " + String(e).slice(0, 80); }
                });
            }
            ordersProbe.explorer = mem || { error: "describeType not available" };
            ordersProbe.getters = res;
        }
        if (!ordersProbe.task && withTask) ordersProbe.task = members(withTask.task) || { error: "describeType not available" };
    }
    function writeOrdersFile(force) {
        var now = Date.now();
        if (!force && now - lastOrdersWrite < ORDERS_MS) return false;
        lastOrdersWrite = now;
        try {
            probeOrders();
            var A = airApi(), f = appFile(ORDERS_FILE); if (!A || !f) return false;
            var orders = orderBook().map(function (o) { return { key: o.key, task: o.task, amount: o.amount, progress: o.progress, inFlight: o.inFlight, pending: o.pending, sent: o.sent, needed: o.needed, left: o.left, gameDone: o.gameDone, state: o.state, revoking: o.revoking }; });
            var st = new A.FileStream(); st.open(f, A.FileMode.WRITE);
            st.writeUTFBytes(JSON.stringify({ format: "dma-explorer-orders/1", version: VERSION, at: new Date(now).toISOString(), orders: orders,
                explorerObject: ordersProbe.explorer, taskObject: ordersProbe.task, explorerGetters: ordersProbe.getters, durations: durationSummary() }));
            st.close();
            return true;
        } catch (_) { return false; }
    }
    /* the promised orders with searches still to send, as a working list for one batch */
    function openOrders() { return orderBook().filter(function (o) { return (o.state === "promised" || o.state === "rejected") && !o.revoking && o.left > 0 && /^adv/.test(o.task) && TASK[o.task]; }).map(function (o) { o.reserved = 0; return o; }); }
    /* 0.4.36: the learned durations. The game computes the real needed time of a search only when it starts (skills and traits included); the running task object has GetNeededTime. It is read once per send of an
       explorer the module already reads (tk16Review) and kept raw, per explorer id and per explorer type name, per search key: { last, n, recent (the last 5), median, c (the TK16 case last learned from) }. */
    var DUR_FILE = "dma-explorer-durations.json", DUR_MS = 60000, durLoaded = false, durDirty = false, lastDurWrite = 0, durSample = null;
    var learned = { byId: {}, byType: {} };
    var calib = {};   // 0.4.37: per search key { n, ratios: [last 20 measured / computed (uncalibrated)], median, samples: [last 20 { id, computed, measured, ratio }] }
    function medianOf(a) { var b = a.slice().sort(function (x, y) { return x - y; }), n = b.length; return n ? (n % 2 ? b[(n - 1) / 2] : (b[n / 2 - 1] + b[n / 2]) / 2) : null; }
    function learnInto(m, who, key, v, c) {
        var w = m[who] || (m[who] = {}), e = w[key] || (w[key] = { last: null, n: 0, recent: [], median: null, c: "" });
        e.last = v; e.n += 1; e.recent.push(v); if (e.recent.length > 5) e.recent.shift(); e.median = medianOf(e.recent); e.c = c;
    }
    function loadDurations() {
        if (durLoaded) return;
        try {
            var A = airApi(), f = appFile(DUR_FILE); if (!A || !f) return;   // the air runtime is not there (yet): try again later
            durLoaded = true;
            if (!f.exists) return;
            var st = new A.FileStream(); st.open(f, A.FileMode.READ);
            var d = JSON.parse(st.readUTFBytes(st.bytesAvailable)); st.close();
            if (d && d.byId && d.byType && d.format === "dma-explorer-durations/2") { learned.byId = d.byId; learned.byType = d.byType; if (d.calib && typeof d.calib === "object") calib = d.calib; note("explorer durations loaded: " + Object.keys(learned.byId).length + " explorers"); }
        } catch (_) { durLoaded = true; }
    }
    function writeDurations(force) {
        var now = Date.now();
        if (!durDirty || (!force && now - lastDurWrite < DUR_MS)) return false;
        lastDurWrite = now;
        try {
            var A = airApi(), f = appFile(DUR_FILE); if (!A || !f) return false;
            var st = new A.FileStream(); st.open(f, A.FileMode.WRITE);
            st.writeUTFBytes(JSON.stringify({ format: "dma-explorer-durations/2", version: VERSION, at: new Date(now).toISOString(), unit: "ms of real time (GetNeededTime / time bonus x 100)", byId: learned.byId, byType: learned.byType, calib: calib }));
            st.close(); durDirty = false;
            return true;
        } catch (_) { return false; }
    }
    function typeOf(item) {
        var raw = ""; try { raw = item.getName && (item.getName(false) || item.getName(true)) || ""; } catch (_) {}
        return nameParts(raw).type || String(raw).replace(/<[^>]*>/g, "").trim();
    }
    function zeroArg(o, n) { try { return typeof o[n] === "function" ? shown(o[n]()) : null; } catch (_) { return null; } }
    /* a busy explorer of an open TK16 case: read the needed time of its running task once per send */
    function learnFrom(item, t, d) {
        var key = String(d.task || ""), sid = String(d.specId), tk, v, who, e, tb;
        if (!key || !sid) return;
        loadDurations();
        e = learned.byId[sid] && learned.byId[sid][key];
        if (e && e.c === t.key) return;   // this send is learned already (also after a restart)
        try { tk = item.GetTask && item.GetTask(); } catch (_) { tk = null; }
        if (!tk || typeof tk.GetNeededTime !== "function") return;
        try { v = Number(tk.GetNeededTime()); } catch (_) { return; }
        if (!isFinite(v) || v <= 0) return;   // not known yet: read again on a later tick
        /* 0.4.38: GetNeededTime is in game time; the task collects timeBonus/100 per real ms (cSpecialistTask), so real time = needed / timeBonus x 100 */
        tb = typeof item.GetSpecialistDescription === "function" ? NaN : 100;   // an object without a description (tests' fakes): bonus 100
        try { if (tb !== 100) tb = Number(item.GetSpecialistDescription().GetTimeBonus()); } catch (_) { tb = NaN; }
        if (!isFinite(tb) || tb <= 0) return;
        v = v / tb * 100;
        who = typeOf(item);
        learnInto(learned.byId, sid, key, v, t.key);
        if (who) learnInto(learned.byType, who, key, v, t.key);
        durDirty = true;
        try { calibrate(item, sid, key, v); } catch (_) {}   // 0.4.37
        durSample = { explorer: sid, type: who, key: key, GetNeededTime: v, GetRemainingTime: zeroArg(tk, "GetRemainingTime"), GetCollectedTime: zeroArg(tk, "GetCollectedTime"), GetBonusTime: zeroArg(tk, "GetBonusTime"), GetTaskProgress: zeroArg(tk, "GetTaskProgress"), at: new Date().toISOString() };
    }
    /* 0.4.37: the exact search time, computed the way the game's specialist panel does (cSpecialistPanel.calculateSkillsOnTaskDuration); null when anything is unreadable */
    function gameGlobal() {
        var g = null;
        try { g = root.swmmo && typeof root.swmmo.getDefinitionByName === "function" ? root.swmmo.getDefinitionByName("global") : null; } catch (_) { g = null; }
        if (!g) { try { g = root.global || null; } catch (_) { g = null; } }
        return g;
    }
    function vecList(v) {
        var out = [], i, n;
        if (!v) return out;
        try { if (typeof v.forEach === "function") { v.forEach(function (x) { out.push(x); }); return out; } } catch (_) {}
        try { if (typeof v.toArray === "function") return vecList(v.toArray()); } catch (_) {}
        n = Number(v.length) || 0;
        for (i = 0; i < n; i++) { try { out.push(typeof v.getItemAt === "function" ? v.getItemAt(i) : v[i]); } catch (_) { out.push(null); } }
        return out;
    }
    function vecAt(v, i) { var l = vecList(v); return i >= 0 && i < l.length ? l[i] : null; }
    function computeSearchMs(spec, main, sub, g) {
        try {
            g = g || gameGlobal(); main = Number(main); sub = Number(sub);
            if (!spec || !g || !isFinite(main) || !isFinite(sub)) return null;
            var mainDef = vecAt(g.specialistTaskDefinitions_vector, main), subDef = mainDef ? vecAt(mainDef.subtasks_vector, sub) : null;
            if (!subDef) return null;
            var dur = Number(subDef.duration);
            if (!isFinite(dur) || dur <= 0 || !subDef.mainTask) return null;
            var key = String(subDef.mainTask.taskName_string) + String(subDef.taskType_string);
            var tree = typeof spec.getSkillTree === "function" ? spec.getSkillTree() : null;
            if (!tree || typeof tree.getItems_vector !== "function") return null;
            var skills = vecList(tree.getItems_vector());
            if (spec.skills && typeof spec.skills.getItems_vector === "function") skills = skills.concat(vecList(spec.skills.getItems_vector()));
            var i, j, sk, lv, def, mods, mod, mv, mm, ad;
            for (i = 0; i < skills.length; i++) {
                sk = skills[i]; if (!sk || typeof sk.getLevel !== "function") continue;
                lv = Number(sk.getLevel()); if (!(lv > 0)) continue;
                def = typeof sk.getDefinition === "function" ? sk.getDefinition() : null;
                mods = def ? vecAt(def.level_vector, lv - 1) : null;
                if (!mods) return null;
                mods = vecList(mods);
                for (j = 0; j < mods.length; j++) {
                    mod = mods[j]; if (!mod) continue;
                    if (!(String(mod.type_string || "").length === 0 || String(mod.type_string) === key)) continue;
                    if (String(mod.modifier_string || "").toLowerCase() !== "searchtime") continue;
                    mv = Number(mod.value); mm = Number(mod.multiplier); ad = Number(mod.adder);
                    if (!isFinite(mv) || !isFinite(mm) || !isFinite(ad)) return null;
                    if (mv !== 0) dur = mv;
                    dur = dur * mm + ad;
                }
            }
            var desc = typeof spec.GetSpecialistDescription === "function" ? spec.GetSpecialistDescription() : null;
            var tb = desc && typeof desc.GetTimeBonus === "function" ? Number(desc.GetTimeBonus()) : NaN;
            if (!isFinite(tb) || tb <= 0) return null;
            var r = dur / tb * 100;
            return isFinite(r) && r > 0 ? r : null;
        } catch (_) { return null; }
    }
    /* our search key -> the game's (main, sub), through the TASK table */
    function computedRaw(item, key) {
        var t = TASK[key], p = t ? String(t).split(",") : null;
        return p && p.length === 2 ? computeSearchMs(item, p[0], p[1]) : null;
    }
    function calFactor(key) {
        var c = calib[key];
        if (!c || !(c.n >= 3) || !isFinite(Number(c.median)) || !(c.median > 0)) return 1;
        return Math.abs(c.median - 1) > 0.02 ? c.median : 1;
    }
    /* the computed duration corrected by what practice showed for this key: { v, cal } or null */
    function computedDuration(item, key) {
        var raw = computedRaw(item, key); if (raw == null) return null;
        var f = calFactor(key);
        return { v: raw * f, cal: f !== 1 };
    }
    function calibrate(item, sid, key, measured) {
        var raw = computedRaw(item, key); if (raw == null || !(measured > 0)) return;
        var c = calib[key] || (calib[key] = { n: 0, ratios: [], median: null, samples: [] }), ratio = measured / raw;
        c.n += 1; c.ratios.push(ratio); if (c.ratios.length > 20) c.ratios.shift();
        c.samples.push({ id: sid, computed: raw, measured: measured, ratio: ratio }); if (c.samples.length > 20) c.samples.shift();
        c.median = medianOf(c.ratios); durDirty = true;
    }
    function calibrationSummary() {
        var out = {}; Object.keys(calib).forEach(function (k) { var c = calib[k]; out[k] = { n: c.n, medianRatio: c.median, applied: calFactor(k) !== 1 }; });
        return out;
    }
    /* once per start: the computed durations (minutes) of every explorer, idle and busy, for the four adventure searches, to compare with the game's overview */
    var computedTable = null;
    function computeTable() {
        if (computedTable) return computedTable;
        var rows = [], any = false, specs = null;
        try { specs = game.getSpecialists && game.getSpecialists(); } catch (_) { specs = null; }
        (specs || []).forEach(function (item) {
            try {
                if (!item || !(item.GetBaseType && Number(item.GetBaseType()) === 1)) return;
                var uid = item.GetUniqueID && item.GetUniqueID(), sid = uid && uid.toKeyString && uid.toKeyString().split(".")[0];
                if (!sid) return;
                function mins(k) { var r = computedRaw(item, k); if (r == null) return null; any = true; return Math.round(r / 60000 * 100) / 100; }
                rows.push({ id: sid, type: typeOf(item), short: mins("advShort"), medium: mins("advMedium"), long: mins("advLong"), veryLong: mins("advVeryLong") });
            } catch (_) {}
        });
        if (any) computedTable = { unit: "minutes (uncalibrated)", rows: rows };
        return computedTable;
    }
    /* 0.4.36 / 0.4.37: the known duration of this search for this explorer: its own id's learned median, else computed, else its type's learned median; { v, source } or null */
    function learnedDuration(specId, type, key, item) {
        loadDurations();
        var e = learned.byId[String(specId)] && learned.byId[String(specId)][key], cd;
        if (e && e.median != null) return { v: e.median, source: "learned:id" };
        cd = item ? computedDuration(item, key) : null;
        if (cd) return { v: cd.v, source: cd.cal ? "computed\u00d7cal" : "computed" };
        e = type && learned.byType[type] && learned.byType[type][key];
        if (e && e.median != null) return { v: e.median, source: "learned:type" };
        return null;
    }
    function durationSummary() {
        var keys = {}, ids = Object.keys(learned.byId), types = Object.keys(learned.byType), byKey = {};
        ids.forEach(function (i) { Object.keys(learned.byId[i]).forEach(function (k) { keys[k] = 1; (byKey[k] || (byKey[k] = { explorers: 0, types: 0 })).explorers += 1; }); });
        types.forEach(function (ty) { Object.keys(learned.byType[ty]).forEach(function (k) { keys[k] = 1; (byKey[k] || (byKey[k] = { explorers: 0, types: 0 })).types += 1; }); });
        return { keysMeasured: Object.keys(keys).length, explorersMeasured: ids.length, typesMeasured: types.length, byKey: byKey, sample: durSample, calibration: calibrationSummary(), computedTable: computeTable() };
    }
    /* the idle explorer for an order's search: the lowest known (learned) duration goes first; those with no measurement follow in the old order (none known = the old order) */
    function pickFor(order, cands) {
        var best = null, bestV = Infinity, first = null;
        cands.forEach(function (c) {
            if (c.order) return;
            if (!first) first = c;
            var d = learnedDuration(c.specId, c.type, order.task, c.item);
            c.dur = d;
            if (d && d.v < bestV) { best = c; bestV = d.v; }
        });
        if (best) return { c: best, how: "shortest learned duration" };
        return first ? { c: first, how: "no duration learned, old order" } : null;
    }
    function sendExplorers() {
        if (expoSending) { note("expo batch still sending, skip"); return 0; }
        try { tk73Review(); } catch (_) {}   // 0.4.32: promise the orders asked first
        var orders = openOrders();            // 0.4.32 (ADR 0077)
        var prefs = specPrefs();
        var dflt = defaultTemplate();
        var toSend = [];
        var now = Date.now();
        var specs = game.getSpecialists && game.getSpecialists();
        if (!specs || !specs.length) { note("expo no specialists"); return 0; }
        var held = 0;       // 0.4.17: idle explorers handed to the skill executor first
        var unskilled = 0;  // 0.4.17: not fully skilled, sent anyway
        var waiting = 0;    // 0.4.21: not fully skilled, the player chose "skill first"
        var backIdle = 0;   // 0.4.2: explorers idle again within 15 min of a send: the send had no effect
        specs.forEach(function (item) {
            if (!item) return;
            try {
                if (item.GetTask && item.GetTask() != null) return;
                if (!(item.GetBaseType && Number(item.GetBaseType()) === 1)) return;
                if (item.getPlayerID && item.getPlayerID() == -1) return;
                var uid = item.GetUniqueID && item.GetUniqueID();
                var specId = uid && uid.toKeyString && uid.toKeyString().split(".")[0];
                if (!specId) return;
                if (sentAt[specId] && now - sentAt[specId] < 120000) return;
                var mu = mayUse(item);                                                  // 0.4.21: read live, before every use
                if (!mu.state.full) {                                                   // 0.4.17 (was the 0.4.13 hold)
                    var C = root.DMA_Control, dot = dotIdOf(item), can = null;
                    try { if (C && typeof C.canSkillExplorer === "function" && typeof C.skillExplorer === "function") can = C.canSkillExplorer(dot); } catch (_) { can = null; }
                    if (can && can.ok) {
                        var r = null; try { r = C.skillExplorer(dot); } catch (eS) { r = { cannot: true, reason: String(eS) }; }
                        if (r && r.started) { held += 1; return; }                     // skilled first, sent on a later tick
                    }
                    if (!mu.ok) { waiting += 1; return; }                               // 0.4.21: the player chose "skill first"
                    unskilled += 1;                                                     // no books / no executor: send anyway
                }
                if (sentAt[specId] && now - sentAt[specId] < 180000) backIdle += 1;   // 0.4.10: 3 min, not 15 (fast explorers finish short searches)
                var rawName = "";
                try { rawName = item.getName && (item.getName(false) || item.getName(true)) || ""; } catch (_) {}
                var name = String(rawName).replace(/<[^>]*>/g, "").trim();
                var tplName = String(pol("expo.template", DEFAULT_TEMPLATE) || DEFAULT_TEMPLATE);   // 0.4.10
                var ty = nameParts(rawName).type || name;                                            // 0.4.23: by TYPE, also for a nicknamed explorer
                function by(m) { if (!m) return null; if (m[ty]) return m[ty]; if (m[name]) return m[name]; var lk = String(ty).toLowerCase(), k;
                    for (k in m) if (m.hasOwnProperty(k) && String(k).toLowerCase() === lk) return m[k]; return null; }
                var search = tplName !== DEFAULT_TEMPLATE ? (by(dflt) || dflt["*"] || by(prefs) || "short") : (by(prefs) || by(dflt) || dflt["*"] || "short");
                if (NEEDS_SKILL[search]) { var hs = null; try { var C2 = root.DMA_Control; if (C2 && C2.hasSkill) hs = C2.hasSkill(dotIdOf(item), NEEDS_SKILL[search]); } catch (_) {}
                    if (hs === false) search = "veryLong"; }                                                       // 0.4.23: no skill for it -> very long treasure
                var task = TASK[search] || TASK.short, orderKey = "";
                sentAt[specId] = now;
                toSend.push({ specId: specId, task: task, name: name, type: ty, search: search, chosen: !!prefs[name], order: orderKey, item: item });
            } catch (e) { note("expo skip " + e); }
        });
        /* 0.4.32 / 0.4.36: a promised search order goes before the template, and takes the idle explorer with the lowest learned duration for that search */
        orders.forEach(function (o) {
            while (o.left - o.reserved > 0) {
                var pk = pickFor(o, toSend); if (!pk) break;
                o.reserved += 1; pk.c.order = o.key; pk.c.search = o.task; pk.c.task = TASK[o.task]; pk.c.chosen = false;
                pk.c.duration = pk.c.dur ? pk.c.dur.v : null; pk.c.durationSource = pk.c.dur ? pk.c.dur.source : "none"; pk.c.pick = pk.how;
            }
        });
        if (backIdle >= 3) { suspect(backIdle + " explorers idle again within 15 min of their send"); return 0; }
        if (held) note("expo skilling first " + held);
        if (unskilled) note("expo sending " + unskilled + " not fully skilled (no books or no skill executor)");
        if (waiting) note("expo waiting for skilling " + waiting + " (the player's choice: skill first)");
        if (!toSend.length) return 0;
        if (typeof sendSpecPacket !== "function") { note("expo dc: sendSpecPacket missing"); return 0; }
        var i = 0;
        expoSending = true;
        function next() {
            if (i >= toSend.length) { expoSending = false; note("expo sent " + toSend.length); return; }
            var it = toSend[i++];
            try {
                sendSpecPacket(it.specId, it.task);
                if (it.order) {   // 0.4.32: the send for a quest's order: TK16 as ever (its initiator is AR73 here), counted on the order
                    orderSent[it.order] = (orderSent[it.order] || 0) + 1;
                    cfact({ tk: "TK16", act: "request", actor: "specialist manager (expo)", initiator: ORDER_ACTOR, search: it.specId + "@" + Date.now(), specId: it.specId, spec: it.name, task: it.search, chosen: false, order: it.order,
                           duration: it.duration != null ? it.duration : "", durationSource: it.durationSource || "none", pick: it.pick || "" });   // 0.4.34: the chosen explorer and its duration on the TK16 case
                    t73("execute", it.order, { sent: orderSent[it.order], spec: it.name, task: it.search, duration: it.duration != null ? it.duration : "", durationSource: it.durationSource || "none", pick: it.pick || "" });
                } else
                cfact({ tk: "TK16", act: "request", actor: "specialist manager (expo)", initiator: "specialist manager (expo)", search: it.specId + "@" + Date.now(), specId: it.specId, spec: it.name, task: it.search, chosen: it.chosen });   // 0.4.18
                note("expo " + it.name + " " + it.search + (it.order ? " (quest order " + it.order + ")" : it.chosen ? "" : " (default)"));
            } catch (e) { note("expo err " + it.name + " " + e); }
            setTimeout(next, 1000);
        }
        next();
        return toSend.length;
    }

    function specPrefs() {
        var p = pol("expo.prefs", null);
        if (p && typeof p === "object") { memory.specPrefs = p; return p; }
        if (!memory.specPrefs) memory.specPrefs = {};
        return memory.specPrefs;
    }
    function saveSpecPrefs() {
        try {
            var inst = root.GCAF_PlayerPolicyInstance;
            if (inst && inst.requestChange) inst.requestChange("expo.prefs", JSON.parse(JSON.stringify(memory.specPrefs || {})));
        } catch (_) {}
        try { localStorage.setItem("dma.specPrefs", JSON.stringify(memory.specPrefs || {})); } catch (_) {}
    }
    function loadSpecPrefs() {
        try {
            var s = localStorage.getItem("dma.specPrefs");
            if (s) { memory.specPrefs = JSON.parse(s) || {}; note("specPrefs loaded " + Object.keys(memory.specPrefs).length); }
        } catch (_) {}
    }

    root.DMA_Demo = {
        version: VERSION,
        tick: function () { wake(); },
        memory: function () { return memory; },
        pause: function () { return { paused: paused(), until: pausedUntil, why: pauseWhy }; },
        picture: function () { return { complete: picture.complete, since: picture.since, why: picture.why, declaredAt: picture.declaredAt, mines: picture.mines, gate: pictureGate() }; },   // 0.4.45 (ADR 0096): every manager reads this one fact
        operational: operational,
        island: islandApi,
        record: record,
        stockTrends: stockTrends,   // 0.4.20 (ADR 0048)
        stockNow: function () { var l = stockSeries[stockSeries.length - 1]; return l ? JSON.parse(JSON.stringify(l.s)) : {}; },   // 0.4.31
        troops: function () { return troopPicture; },   // 0.4.25 (ADR 0065)
        premium: function () { return premiumPicture; },   // 0.4.26 (review 2026-11-16 #5/#8)
        samplePremium: samplePremium,                       // 0.4.26: the location manager's read, for the unit expectation
        events: function () { return eventsPicture ? JSON.parse(JSON.stringify(eventsPicture)) : null; },   // 0.4.27 (MTK01 running events)
        eventRunning: eventRunning, anyEventRunning: anyEventRunning, eventsReadable: eventsReadable,   // 0.4.28: eventsReadable      // 0.4.27: DFS-48 / "an event is running"
        sampleEvents: sampleEvents,                                         // 0.4.27: for the unit expectation
        actors: actors,
        writeOrdersFile: writeOrdersFile,   // 0.4.35: dma-explorer-orders.json (also for the unit expectation)
        log: function () { return logLines.slice(); },
        setBuffPref: function (name, buff, area) {
            var bp = pol("buff.prefs", null);
            memory.buffPrefs = (bp && typeof bp === "object") ? JSON.parse(JSON.stringify(bp)) : (memory.buffPrefs || {});
            if (buff) memory.buffPrefs[name] = buff; else delete memory.buffPrefs[name];
            try { var inst = root.GCAF_PlayerPolicyInstance; if (inst && inst.requestChange) inst.requestChange("buff.prefs", JSON.parse(JSON.stringify(memory.buffPrefs))); } catch (_) {}
        },
        getBuffPrefs: function () {
            var bp = pol("buff.prefs", null);
            if (bp && typeof bp === "object") memory.buffPrefs = bp;
            return memory.buffPrefs || {};
        },
        clearBuffPrefs: function () {
            memory.buffPrefs = {};
            try { var inst = root.GCAF_PlayerPolicyInstance; if (inst && inst.requestChange) inst.requestChange("buff.prefs", {}); } catch (_) {}
        },
        setBuffArea: function (grid, radius) { memory.buffAreas[grid] = radius; },
        getBuffAreas: function () { return memory.buffAreas; },
        setSpecPref: function (type, search) {
            specPrefs();
            memory.specPrefs[type] = search;
            saveSpecPrefs();
        },
        getSpecPrefs: function () { return specPrefs(); },
        loadSpecPrefs: loadSpecPrefs,
        clearSpecPrefs: function () {
            memory.specPrefs = {};
            saveSpecPrefs();
        },
        saveSpecTemplate: function (name, prefs) { memory.specTemplates[name] = prefs; },
        getSpecTemplates: function () { return Object.keys(memory.specTemplates).length ? memory.specTemplates : null; },
        sendExplorers: sendExplorers,
        tk16Review: tk16Review,   // 0.4.18
        tk73Review: tk73Review, searchOrders: searchOrders,   // 0.4.32 (ADR 0077)
        computeSearchMs: computeSearchMs, calibration: function () { return JSON.parse(JSON.stringify(calib)); }, learnedDuration: learnedDuration, writeDurations: writeDurations, durations: function () { return JSON.parse(JSON.stringify(learned)); },   // 0.4.36: (specId, type, key) -> { v, source } or null
        suspect: suspect, restartOnSuspect: restartOnSuspect,   // 0.4.19 (tests)
        explorerSkillState: explorerSkillState,                      // 0.4.13
        mayUse: mayUse, specialistSkillState: specialistSkillState, setUseMode: setUseMode, useMode: useMode,   // 0.4.21 (ADR 0058)
        namePlan: namePlan, nameParts: nameParts                       // 0.4.22
    };
    loadSpecPrefs();
    loadDurations();   // 0.4.36
    note("DEMO agents " + VERSION + " loaded");
})(typeof window !== "undefined" ? window : this);
