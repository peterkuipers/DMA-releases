/*
 * 0.1.4 (2026-11-20, ADR 0088 S-3/S-4; author: "Iemand verantwoordelijk voor de voorraad moet toegang hebben tot de verbruik gegevens om te
 *   kunnen voorspellen wanneer iets in de problemen komt. Dus oil seed productie moet omhoog. Kijk ook naar de avonturen die veel oil seed
 *   opleveren"): the manager FORECASTS. With supply.forecast.on (default off) it reads the location manager's trends (DMA_Demo.stockTrends,
 *   supply.forecast.windowHours, default 6) — resources and star items ("star:<name>[:<resource>]") — and a good that runs out within
 *   supply.forecast.horizonHours (default 48) is short by what the horizon would consume beyond the stock (source "forecast"), also when no
 *   order waits for it. The MEANS come from green's supply graph (DMA_Green.supply / DMA_SupplyGraph), in the order of ADR 0075:
 *     make     a production-house recipe (e.g. Balloon Dog at the Balloon Market) or a building: a TK64 batch for the player, naming the
 *              house and the recipe; the recipe's INPUTS that the stock does not cover for it are listed for more production (DFS-54),
 *              so the construction manager raises e.g. oilseed — the chain one level down;
 *     produce  more production of the good itself (DFS-54), as before;
 *     adventure an adventure in the star whose loot yields it: listed with its yield per run and the runs needed (adventures(), and the
 *              status file), for the adventure manager's agenda; with none in the star, the best one to obtain is named;
 *     then the trade office and the guild as before. A forecast need that no own means covers is a help notice for the player.
 *   Unit: tests/unit/supply-manager-forecast.test.js (a falling star item within the horizon is short; outside it is not; the Balloon Dog is made at
 *   the Balloon Market and its oilseed listed for more production; the adventure with the most oilseed per run in the star is named; forecast off:
 *   nothing). Integration: tests/integration/supply-forecast-graph.test.js (real policy, supply graph, value and loot modules).
 */
/*
 * 0.1.3 (2026-11-18, ADR 0083 addendum, author: "30 minuten te kort, is een bedrijfsregel met instelbaar fact type"):
 *   the 30 min before the trade office and the 120 min before the guild are rules (supply.office.afterMin(.on),
 *   supply.guild.afterMin(.on)); the never-pay list and the price ratio each have an on/off. Nothing is typed here any more.
 *   Unit: tests/unit/dma-supply-manager.test.js (afterMin 10: the office at 10 min; afterMin.on off: at once; ratio off:
 *   any price; never-pay off: Oil allowed). Integration: tests/integration/dma-supply-rules-flow.test.js.
 * DMA Resource supply manager 0.1.2 — actor role AR66 "resource supply manager" (case kind TK66 "resource supply managing", self-activating; it requests TK64 and TK25), ADR 0075 (backbone v3.19).

 * 0.1.2 (2026-11-16, ADR 0076, author "Ja" to the market-price proposal; "olie is onbetaalbaar", "you have to develop a good sense for that, what is cheap and what is expensive"): DFS-53 is redefined. favourable() no longer
 *   compares own-cost values: an offer is favourable when the market value of what we get is at least policy supply.office.minMarketRatio (default 1.5) times the market value of what we pay (DMA_Market.ratio, the
 *   market price keeper), and the paid resource is not in policy supply.office.neverPay (default "Oilseed, Oil"); an offer in a resource without a market price is not favourable. The own-cost value list stays for
 *   deciding what to make ourselves (makers()). The office rule is unchanged otherwise: still only after 30 min of shortness, within the day's quota, the guild last. maxPricePct now only prices a guild purchase.
 *   Unit: tests/unit/dma-supply-manager.test.js (favourable: ratio threshold, neverPay, unknown price; the office buys only a favourable offer). Integration: tests/integration/dma-supply-flow.test.js (a short resource is bought
 *   at the office only when the offer is at least 1.5 times better at the market price; the flow of the means is unchanged).
 *
 * 0.1.1 (2026-11-16, tester on the ADR 0075 stack): (1) READY includes the switch. `ready` is now a live reading: the transaction memory and the agents' stock are there AND the Supply switch (supply.auto) is on, re-evaluated on every
 *   read. Before, ready was true from load whatever the switch said, so control (0.2.108) stopped asking for making while the manager (switch off = the default) did nothing: a short allocation was asked by nobody. With the switch off
 *   ready is false and control asks as before; switched off later, control takes the asking back (control 0.2.109). (2) The guild chat is the LAST resort in fact, not by timer: it is asked only when own means do not cover (making and raising
 *   production are off or impossible for the resource, or their 2 h are over) AND the trade office cannot cover (switch off, module missing or not ready, no favourable offer, the day's quota used) AND the need is 30 min old; while the office
 *   still has quota and a favourable offer, or a purchase placed less than 30 min ago is pending, the guild is not asked. Unit: tests/unit/dma-supply-manager.test.js (ready follows the switch live; the guild only when the office cannot cover) (ready follows the switch live). Integration: tests/integration/dma-supply-flow.test.js (the office keeps buying while it has quota; the guild once the quota is used).
 * 0.1.0 (2026-11-16, ADR 0075 follow-up, coordinator batch item 3.2): NEW. One role decides HOW a short resource is obtained (R-3), in the author's order of means (R-2):
 *   NEEDS (read, not scanned: ADR 0040): the lacking amounts of control's open allocations (DMA_Control.allocation.list(), TK60 "promised"), and the open "pay from storage" tasks of the quest
 *   manager's ticked categories that the stock does not cover (DMA_Quest.quests(), type 18, not done) against the stock the agents remember (DMA_Demo.stockNow()). The troop need reaches the
 *   allocator through its troop orders, so it arrives as an allocation. A resource is SHORT (DFS-52) when its need exceeds what is being made (open TK64 batches, ours or control's).
 *   MEANS, in order, per short resource, each only when its policy rule allows it (policy 0.2.67, all off or on as stated there):
 *     1. OWN MEANS — make it: a TK64 request to the resource producer (AR64, held by the player; the batch is a notice in dma-production-requests.json) when the value list knows a building that
 *        makes it (supply.make.on); and raise production: the resource is listed as "needs more production" (DFS-54) for the construction manager, who builds, upgrades or buffs a maker
 *        (supply.produce.on). The cheaper in value is the player's batch or the building: both are requested, the first to deliver wins and the other is withdrawn when the stock covers.
 *     2. TRADE OFFICE — after officeAfterMs() (30 min) still short: a purchase at the trade office when it is favourable at the market price (DFS-53, DMA_Market, ADR 0076): what we get is worth at least
 *        supply.office.minMarketRatio times what we pay, never paid with Oilseed or Oil; at most supply.office.maxPerDay per day. Through DMA_TradeOffice.buy (the buyer; not loaded yet = this means is skipped).
 *     3. GUILD CHAT, the LAST resort — only when own means and the office cannot cover (0.1.1; see above): "who sells me X?" through DMA_Help.askPurchase, at most supply.guild.maxPerDay and one per
 *        supply.guild.everyMin. A purchase is a TK25 with the set PURCHASE (resource, amount, market), the buyer role; the transaction kind is not new (R-4).
 *   TK66 per period (one hour): request (AR66 itself) -> promise; the TK64 / TK25 instances are requested inside it; declared when every instance is accepted (the stock covers the need: observed)
 *   or at the end of the period (the open batches are then withdrawn: revoke request -> allow), accepted at once; the next period starts at the next tick. A period without a short resource is
 *   declared and accepted in the same tick (the book shows the manager is alive).
 *   Clock: its own, one look a minute (not the agents' cycle), paused while the player is away from home. Presence and readiness (as ADR 0074 section 3): the module acts only while the Supply switch (supply.auto) is on and check() is true (the transaction memory is there). Without this file
 *   control's allocator still asks for making (until the allocator change of the same batch); with both, control's open batches count as "being made", so nothing is asked twice.
 *   GLOBAL: DMA_SupplyManager = { version, owner "resource supply manager", actor, ready, check, tick, assess, needs, short, moreProduction, favourable, last }.
 *   Unit: tests/unit/dma-supply-manager.test.js (needs, shortness, the order of the means, the limits, the value test, the period). Integration:
 *   tests/integration/dma-supply-flow.test.js (real policy, transactions and agents with a fake control / quest / office / help: a short resource is requested for making, listed for production, then
 *   bought at the office, then asked in the guild chat; limits hold; TK66 is requested, promised, declared and accepted in the book).
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.4";
    var ACTOR = "resource supply manager", PRODUCER = "resource producer", TK = "TK66";
    var PENDING_MS = 30 * 60000;   // 0.1.3: implementation, not a rule: a placed or refused purchase is not repeated for 30 min (the goods travel)
    var PERIOD_MS = 3600000, MIN_TICK_MS = 55000, DAY_MS = 86400000;
    var STATUS = "dma-supply-status.json";
    var ready = false, advWants = {}, helps = [], toldHelp = {}, bought = {}, officeFail = {}, last = [], period = null, firstShort = {}, batches = {}, buys = [], asks = [], moreProd = {}, lastTickAt = 0, seq = 0;

    function pol(k, d) {
        try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {}
        return d;
    }
    function on(k, d) { var v = pol(k, d); return !(v === false || String(v) === "false"); }
    function off(k) { var v = pol(k, false); return v === true || String(v) === "true"; }
    function num(k, d) { var v = Number(pol(k, d)); return isNaN(v) ? d : v; }
    /* 0.1.3 (ADR 0083 addendum): the waiting times are the player's rules (on/off and minutes), no longer typed here */
    function officeAfterMs() { return on("supply.office.afterMin.on", true) ? Math.max(0, num("supply.office.afterMin", 30)) * 60000 : 0; }
    function guildAfterMs() { return on("supply.guild.afterMin.on", true) ? Math.max(0, num("supply.guild.afterMin", 120)) * 60000 : 0; }
    function record(kind, data) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {} }
    function note(s) {
        try { if (!root.__DMA_CYCLE_LOG) root.__DMA_CYCLE_LOG = []; root.__DMA_CYCLE_LOG.push(new Date().toISOString().slice(11, 19) + " " + s);
              if (root.__DMA_CYCLE_LOG.length > 200) root.__DMA_CYCLE_LOG.splice(0, root.__DMA_CYCLE_LOG.length - 200); root.__DMA_CYCLE_AT = Date.now(); } catch (_) {}
    }
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function readJson(name) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new A.FileStream(); st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function writeJson(name, obj) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath), st = new A.FileStream(); st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (_) {}
    }

    /* ---------- what the manager reads (it scans nothing) ---------- */
    function stock() { try { return (root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow()) || {}; } catch (_) { return {}; } }
    function valueBy() { try { var V = root.DMA_Value, s = V && V.state && V.state(); return (s && s.result && s.result.by) || {}; } catch (_) { return {}; } }
    function makers(r) { var x = valueBy()[r]; if (x && x.building && x.seconds > 0) return true; return waysOf(r).some(function (w) { return w.kind === "produce" || w.kind === "make"; }); }   // a building the economy definitions know makes it; 0.1.4: or a way in green's graph
    function openBatchesOfControl() {   // control's own (legacy) batches, never our own that control lists back
        try { var C = root.DMA_Control; return ((C && C.allocation && C.allocation.batches && C.allocation.batches()) || []).filter(function (b) { return b && b.by !== ACTOR; }); } catch (_) { return []; }
    }
    function allocationLacks() {
        var out = {};
        try { var C = root.DMA_Control, l = (C && C.allocation && C.allocation.list && C.allocation.list()) || [];
              l.forEach(function (a) { if (!a || a.state !== "promised" || !a.lacking) return; Object.keys(a.lacking).forEach(function (r) { out[r] = (out[r] || 0) + Number(a.lacking[r] || 0); }); }); } catch (_) {}
        return out;
    }
    function questLacks(st) {
        var out = {};
        try {
            if (pol("quest.auto", false) !== true) return out;
            var Q = root.DMA_Quest, qs = (Q && Q.quests && Q.quests()) || [];
            qs.forEach(function (q) {
                if (q.mode === 12 || q.mode === 11 || q.collected || pol("quest.do." + q.category, true) === false) return;
                (q.tasks || []).forEach(function (t) {
                    if (t.done || t.type !== 18 || !t.what || !(t.amount > 0)) return;
                    var short = t.amount - Number(st[t.what] || 0); if (short > 0) out[t.what] = (out[t.what] || 0) + short;
                });
            });
        } catch (_) {}
        return out;
    }
    /* 0.1.4 (ADR 0088): the forecast from the location manager's trends */
    function goodOf(id) { var m = /^star:(?:Adventure:|AddResource:)?(.+)$/.exec(String(id)); return m ? m[1] : String(id); }
    function graph() { try { return (root.DMA_Green && root.DMA_Green.supply) || root.DMA_SupplyGraph || null; } catch (_) { return null; } }
    function forecastLacks() {
        var out = {};
        if (!off("supply.forecast.on")) return out;
        try { var D = root.DMA_Demo, tr = (D && D.stockTrends && D.stockTrends(num("supply.forecast.windowHours", 6))) || [], H = num("supply.forecast.horizonHours", 48);
              tr.forEach(function (t) { if (!t || !(t.perHour < 0) || !(t.hoursLeft <= H)) return; var need = Math.ceil(-t.perHour * H - (Number(t.amount) || 0)); if (need > 0) out[t.id] = { amount: need, hoursLeft: t.hoursLeft }; }); } catch (_) {}
        return out;
    }
    /* DFS-52: the need per resource beyond the stock, minus what is being made */
    function needs() {
        var st = stock(), a = allocationLacks(), q = questLacks(st), f = forecastLacks(), out = {}, k;
        for (k in a) if (a.hasOwnProperty(k)) out[k] = { amount: a[k], sources: ["allocation"] };
        for (k in q) if (q.hasOwnProperty(k)) { if (!out[k]) out[k] = { amount: 0, sources: [] }; out[k].amount += q[k]; out[k].sources.push("quest payment"); }
        for (k in f) if (f.hasOwnProperty(k)) { if (!out[k]) out[k] = { amount: 0, sources: [] }; if (f[k].amount > out[k].amount) out[k].amount = f[k].amount; out[k].sources.push("forecast"); out[k].hoursLeft = Math.round(f[k].hoursLeft * 10) / 10; }
        return out;
    }
    /* 0.1.4: the ways green knows, split by kind */
    function waysOf(r) { var G = graph(); try { return G ? G.ways(goodOf(r)) : []; } catch (_) { return []; } }
    function produced(r) { var x = valueBy()[r]; if (x && x.building && x.seconds > 0) return true; return waysOf(r).some(function (w) { return w.kind === "produce"; }); }
    function makeWay(r) { return waysOf(r).filter(function (w) { return w.kind === "make"; })[0] || null; }
    function adventureFor(r, amount) {
        var st = stock(), loots = waysOf(r).filter(function (w) { return w.kind === "loot" && w.via && w.yields > 0; });
        if (!loots.length) return null;
        loots.sort(function (a, b) { return b.yields - a.yields; });
        var inStar = loots.filter(function (w) { return Number(st["star:Adventure:" + w.via] || 0) > 0; })[0], pick = inStar || loots[0];
        return { adventure: pick.via, name: pick.adventure || pick.via, perRun: Math.round(pick.yields * 10) / 10, runs: Math.max(1, Math.ceil(amount / pick.yields)),
                 inStar: inStar ? Number(st["star:Adventure:" + pick.via]) : 0, obtain: !inStar };
    }
    /* what is being made counts as covering only while it is "in time": a batch asked less than officeAfterMs() ago (the player makes it) */
    function beingMade(r, now) {
        now = now || Date.now(); var n = 0;
        if (batches[r] && batches[r].state === "requested" && now - batches[r].at < officeAfterMs()) n += batches[r].amount;
        openBatchesOfControl().forEach(function (b) { if (b && b.resource === r && !(b.since != null && now - (typeof b.since === "number" ? b.since : Date.parse(b.since)) >= officeAfterMs())) n += Number(b.amount || 0); });
        return n;
    }
    function short(now) {
        var nd = needs(), out = {};
        Object.keys(nd).forEach(function (r) { var s = Math.ceil(nd[r].amount - beingMade(r, now)); if (s > 0) out[r] = { amount: s, need: Math.ceil(nd[r].amount), sources: nd[r].sources, hoursLeft: nd[r].hoursLeft }; });
        return out;
    }
    /* DFS-53 (ADR 0076): the offer is favourable by the MARKET price: what we get is worth at least minMarketRatio times what we pay, and we do not pay with a resource on the never-pay list */
    function neverPay() {
        if (!on("supply.office.neverPay.on", true)) return [];   // 0.1.3
        var v = pol("supply.office.neverPay", ["Oilseed", "Oil"]); if (typeof v === "string") v = v.split(",");
        return (v || []).map(function (x) { return String(x).trim().toLowerCase(); }).filter(Boolean);
    }
    function favourable(quote, r, amount, minRatio) {
        var M = root.DMA_Market, pay = quote && quote.pay;
        if (!M || typeof M.ratio !== "function" || !pay || !(amount > 0) || !(pay.amount > 0)) return false;
        if (neverPay().indexOf(String(pay.resource).toLowerCase()) >= 0) return false;
        if (!on("supply.office.minMarketRatio.on", true)) return true;   // 0.1.3: the player switched the price check off
        var ratio = M.ratio(r, amount, pay.resource, pay.amount), min = minRatio != null ? Number(minRatio) : num("supply.office.minMarketRatio", 1.5);
        return ratio != null && ratio >= min;
    }
    function dayCount(list, now) { return list.filter(function (t) { return now - t < DAY_MS; }).length; }

    /* ---------- TK66 (the period) ---------- */
    function c66(act, extra) {
        var d = { tk: TK, act: act, caseId: period.id, actor: ACTOR, period: period.id }, k; for (k in (extra || {})) d[k] = extra[k];
        record("c", d);
    }
    function openPeriod(now) {
        seq += 1; period = { id: "supply@" + new Date(now).toISOString().slice(0, 13) + "#" + seq, at: now, instances: 0 };
        c66("request"); c66("promise");
    }
    function closePeriod(now, why) {
        if (!period) return;
        Object.keys(batches).forEach(function (r) {   // an open batch of this period is withdrawn (revoke request -> allow), like the allocator's
            var b = batches[r]; if (b.state !== "requested") return;
            record("c", { tk: "TK64", act: "revoke request", caseId: b.id, actor: ACTOR, resource: r, amount: b.amount, reason: why });
            record("c", { tk: "TK64", act: "allow", caseId: b.id, actor: PRODUCER + " (player, tacit)", resource: r, amount: b.amount });
            b.state = "withdrawn";
        });
        c66("declare", { reason: why }); c66("accept");
        period = null; moreProd = {};
    }
    function requestBatch(r, amount, now) {
        var b = { id: "batch@" + r + "@" + now + "#" + (++seq), amount: Math.ceil(amount), state: "requested", at: now };
        batches[r] = b; period.instances += 1;
        record("c", { tk: "TK64", act: "request", caseId: b.id, actor: ACTOR, resource: r, amount: b.amount, executor: PRODUCER, heldBy: "player (APT: no module yet)", period: period.id });
        record("p", { fact: "production batch for the player", tk: "TK64", caseId: b.id, resource: r, amount: b.amount, notice: true });
        return b;
    }
    function writeNotice() {
        var open = Object.keys(batches).map(function (r) { return batches[r].state === "requested" ? { id: batches[r].id, resource: r, amount: batches[r].amount, since: new Date(batches[r].at).toISOString(), house: batches[r].house || null, recipe: batches[r].recipe || null } : null; }).filter(Boolean);
        writeJson("dma-production-supply-requests.json", { format: "dma-production-supply-requests/1", version: VERSION, at: new Date().toISOString(),
            note: "You hold the resource producer role (AR64): the resource supply manager asks you to make these batches; it withdraws a batch once the stock covers it.", open: open });
    }

    /* ---------- the means, per short resource ---------- */
    function assess(now) {
        now = now || Date.now();
        var rows = [], st = stock(), sh = short(now), nd = needs();
        Object.keys(firstShort).forEach(function (r) { if (!nd[r]) delete firstShort[r]; });   // the need is gone: forget the age
        Object.keys(nd).forEach(function (r) { if (!firstShort[r]) firstShort[r] = now; });     // the age of a need runs while it is open, whatever is being made
        Object.keys(batches).forEach(function (r) {   // the stock covers the need: the batch is accepted (observed)
            var b = batches[r]; if (b.state !== "requested") return;
            if (!nd[r]) { b.state = "accepted"; record("c", { tk: "TK64", act: "declare", caseId: b.id, actor: PRODUCER + " (observed)", resource: r, amount: b.amount }); record("c", { tk: "TK64", act: "accept", caseId: b.id, actor: ACTOR, resource: r }); rows.push({ rule: "ARS-66-12", resource: r, means: "make", result: "accepted" }); }
        });
        moreProd = {};
        Object.keys(advWants).forEach(function (r) { if (!sh[r]) delete advWants[r]; });
        Object.keys(sh).forEach(function (r) {
            var age = now - firstShort[r], s = sh[r], did = [];
            /* 1. own means */
            var mw = makeWay(r);
            if (on("supply.make.on", true) && makers(r) && !(batches[r] && batches[r].state === "requested")) { var bt = requestBatch(r, s.amount, now); if (mw) { bt.house = mw.via; bt.recipe = mw.recipe; } did.push("make"); }
            if (on("supply.produce.on", true) && produced(r)) { moreProd[r] = { resource: r, amount: s.amount, since: new Date(firstShort[r]).toISOString() }; did.push("more production"); }
            if (mw && on("supply.produce.on", true)) {   // 0.1.4: the recipe's inputs the stock does not cover get more production (one level down the chain)
                var orders = Math.ceil(s.amount / (mw.yields || 1));
                (mw.inputs || []).forEach(function (i) { var lack = Math.ceil(i.amount * orders - Number(st[i.good] || 0)); if (lack > 0 && produced(i.good)) { moreProd[i.good] = { resource: i.good, amount: lack, since: new Date(firstShort[r]).toISOString(), forGood: goodOf(r) }; did.push("more production of " + i.good); } });
            }
            if (on("supply.adventure.on", true)) { var av = adventureFor(r, s.amount); if (av) { advWants[r] = av; did.push((av.obtain ? "obtain adventure " : "adventure ") + av.name); } else delete advWants[r]; }
            if (s.sources.indexOf("forecast") >= 0 && !did.length) {
                var hk = r + "@" + new Date(firstShort[r]).toISOString(); if (!toldHelp[hk]) { toldHelp[hk] = 1; var ht = goodOf(r) + " runs out in ~" + (s.hoursLeft != null ? s.hoursLeft : "?") + " h and DMA has no own means for it: please look.";
                    helps.push({ at: new Date(now).toISOString(), text: ht }); if (helps.length > 20) helps.shift(); record("p", { fact: "the resource supply manager asks the player for help", actor: ACTOR, resource: r, text: ht }); }
            }
            /* 2. the trade office, when favourable in value */
            var O = root.DMA_TradeOffice, officeCan = false, officeOn = off("supply.office.on") && O && typeof O.buy === "function" && dayCount(buys, now) < num("supply.office.maxPerDay", 3);
            var pendingBuy = !!(bought[r] && now - bought[r] < PENDING_MS), quote = null, refused = !!(officeFail[r] && now - officeFail[r] < PENDING_MS);
            if (officeOn && !pendingBuy) { try { quote = typeof O.quote === "function" ? O.quote(r, s.amount) : null; } catch (_) { quote = null; } }
            if (officeOn) officeCan = !refused && (pendingBuy || !!(quote && favourable(quote, r, s.amount)));   // the office covers while it has quota and an offer (or a purchase is on its way)
            if (officeOn && age >= officeAfterMs() && !pendingBuy && officeCan) {
                var res = O.buy(r, s.amount, quote);
                if (!res || res.ok === false) { officeFail[r] = now; officeCan = false; }   // the buyer refused (e.g. not confirmed yet): the office does not cover
                if (res && res.ok !== false) { buys.push(now); bought[r] = now; period.instances += 1; did.push("trade office"); record("c", { tk: "TK25", act: "request", caseId: res.caseId || ("purchase@" + r + "@" + now), actor: ACTOR, set: "PURCHASE", resource: r, amount: s.amount, market: "trade office", period: period.id }); }
            }
            /* 3. the guild chat, the LAST resort: only when own means and the office cannot cover */
            var H = root.DMA_Help, lastAsk = asks.length ? asks[asks.length - 1] : 0;
            var ownCovers = (on("supply.make.on", true) || on("supply.produce.on", true)) && makers(r) && age < guildAfterMs();
            if (off("supply.guild.on") && age >= officeAfterMs() && !ownCovers && !officeCan && H && typeof H.askPurchase === "function" && dayCount(asks, now) < num("supply.guild.maxPerDay", 2) && now - lastAsk >= num("supply.guild.everyMin", 120) * 60000) {
                var ask = H.askPurchase(r, s.amount, { maxPricePct: num("supply.office.maxPricePct", 100) });
                if (ask && ask.ok !== false) { asks.push(now); period.instances += 1; did.push("guild chat"); record("c", { tk: "TK25", act: "request", caseId: ask.caseId || ("purchase@" + r + "@" + now), actor: ACTOR, set: "PURCHASE", resource: r, amount: s.amount, market: "guild chat", period: period.id }); }
            }
            rows.push({ rule: "ARS-66-11", resource: r, short: s.amount, need: s.need, sources: s.sources, ageMin: Math.round(age / 60000), means: did });
        });
        return rows;
    }
    function tick(now) {
        now = now || Date.now();
        if (!off("supply.auto") || !check()) return [];
        if (lastTickAt && now - lastTickAt < MIN_TICK_MS) return last;
        lastTickAt = now;
        try {
            if (!period) openPeriod(now);
            var rows = assess(now);
            writeNotice();
            var open = Object.keys(batches).some(function (r) { return batches[r].state === "requested"; });
            if (!Object.keys(firstShort).length && !open) closePeriod(now, "nothing short");
            else if (now - period.at >= PERIOD_MS) closePeriod(now, "end of the period");
            last = rows;
            writeJson(STATUS, { format: "dma-supply-status/1", version: VERSION, at: new Date(now).toISOString(), short: short(now), moreProduction: moreProd, adventures: advWants, help: helps, buys: buys, asks: asks, rows: rows });
            return rows;
        } catch (e) { note("supply manager tick err " + (e && e.message ? e.message : e)); return []; }
    }
    function present() { var ok = false; try { ok = !!(root.DMA_Demo && typeof root.DMA_Demo.record === "function" && typeof root.DMA_Demo.stockNow === "function"); } catch (_) { ok = false; } return ok; }
    function check() { ready = present() && off("supply.auto"); return ready; }   // 0.1.1: ready = present AND the Supply switch on, read live
    var api = {
        version: VERSION, owner: ACTOR, actor: ACTOR, check: check, tick: tick, assess: assess, needs: needs, short: short, favourable: favourable,
        batches: function () { return Object.keys(batches).filter(function (r) { return batches[r].state === "requested"; }).map(function (r) { return { id: batches[r].id, resource: r, amount: batches[r].amount, since: new Date(batches[r].at).toISOString(), by: ACTOR }; }); },   // the open batches (control's TX row reads them)
        moreProduction: function () { return JSON.parse(JSON.stringify(moreProd)); },
        adventures: function () { return JSON.parse(JSON.stringify(advWants)); }, forecast: forecastLacks, goodOf: goodOf,   // 0.1.4
        last: function () { return last.slice(); }
    };
    /* the counters of the day survive a restart: read back from the status file */
    (function () { var s = readJson(STATUS); if (s) { buys = (s.buys || []).filter(Number); asks = (s.asks || []).filter(Number); } })();
    Object.defineProperty(api, "ready", { enumerable: true, get: function () { return present() && off("supply.auto"); } });   // 0.1.1: live, never stale
    root.DMA_SupplyManager = api;
    check();
    /* its own clock (it is a self-activating role): one look a minute; tests set DMA_SUPPLY_NO_TIMER */
    if (!root.DMA_SUPPLY_NO_TIMER && typeof root.setInterval === "function") { try { root.setInterval(function () { try { var C = root.DMA_Control; if (C && typeof C.atHome === "function" && !C.atHome()) return; tick(); } catch (_) {} }, 60000); } catch (_) {} }
    note("resource supply manager " + VERSION + " loaded, ready=" + api.ready);
})(typeof window !== "undefined" ? window : this);
