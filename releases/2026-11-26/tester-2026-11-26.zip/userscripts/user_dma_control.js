/*
 * 0.2.118 (2026-11-24, managers evaluation Q2; live probe_ld 0.1.80 qtriggers): the scan's "select this building" triggers
 *   (finds().triggers) come from the first quest pool the game answers on — GetClientQuestPool(), GetQuestPool(),
 *   mNewQuestManager.GetQuestPool() — because mQuestClientCallbacks.mClientQuestPool is not readable from a script. Since
 *   2026-11-01 that path left finds().triggers empty, so the quest manager never selected the building-bonus loops
 *   (Depositorium, FlyingHouse, Offshorelighthouse, DimensionalRift, HauntedMansion_pop).
 *   Unit: tests/unit/dma-control-quest-pool.test.js. Integration: tests/integration/dma-quest-select-bonus.test.js (control + adapter
 *   0.2.9 + quest 0.1.34 + the transaction book).
 * 0.2.117 (2026-11-24, ADR 0096; author: "als de live verbinding verbreekt ... dan ga ik door op de laatst bekende situatie,
 *   totdat de verbinding zich herstelt"): live, one scan in about ten saw 1176 deposits and 0 buildings, and the 17 masons
 *   (the only mines not on a deposit) left the picture. The scan read the game's second building list only when the vector
 *   was missing, not when it was empty; now it reads it in both cases (map.buildingSource vector | container | none). A home
 *   scan that still sees deposits but no buildings is incomplete: the last known buildings stay in the map (map.buildingsAt
 *   says when they were seen), map.incomplete says why, and the policy does not learn from it. The location manager withdraws
 *   its picture on such a map (agents 0.4.46), however long it lasts.
 *   Unit: tests/unit/dma-control-scan-empty.test.js. Integration: live, the facts log no longer shows 17 "mine gone" followed
 *   30 s later by 17 "mine constructed"; end to end with the location manager in the integration test of agents 0.4.46.
 * 0.2.116 (2026-11-19, author: "gebruik de snelste geos om graniet te zoeken"): pickGeoFor takes, for a resource in policy
 *   geo.fastestFor (default ["Granite"]), the idle geologist with the shortest game-predicted search time for it. Unit:
 *   tests/unit/dma-control-geo-fastest.test.js. Integration: tests/integration/dma-control-geo-pick-by-game-name.test.js
 *   (copper is not in the list: its preference is unchanged).
 * 0.2.115 (2026-11-19, ADR 0042; author: "Is that a question for me?" on the wrong geologist names): the typed table
 *   GEO_TYPE_NAMES (10 of 12 ids wrong, e.g. 59 "Gingerbread" is the Diligent Geologist) is gone. A type's name is read
 *   from the game (Specialists::cSpecialist description getName_string, loca SPE when present); the copper preference
 *   (BRONZE_PREF) and the Conscientious/Versed extra-deposit check now key on that name, so they hit the types they meant.
 *   Unit: tests/unit/dma-control-geo-type-names.test.js. Integration: tests/integration/dma-control-geo-pick-by-game-name.test.js.
 * 0.2.114 (2026-11-18, ADR 0084 Workflows / Deposit Cycling): the geologists a workflow allocated are reserved for every
 *   other user (isReserved asks DMA_Workflows.ownsGeo); sendSearch(resource, fromBlue, { geoId }) sends exactly that
 *   geologist (the workflow's own allocation, still a geologist, still idle); sendBuild({ resourceType, grid, workflow })
 *   does not need the Build switch (the workflow has its own), and the free-deposit pick skips the spots of a workflow
 *   that is on (DMA_Workflows.ownsGrid); buildCosts(resource) answers the build cost of a mine (for the reserve rule).
 *   Unit: tests/unit/dma-workflows-deposit-cycling.test.js (control part: reserved, geoId, workflow build).
 *   Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.2.113 (2026-11-18, ADR 0083 point 3; live 2026-11-18 08:36 UTC: a "game not responding" self-restart did not come
 *   back and the client stood still for 4.5 h): the stale watch restarts the client only when the player switched on
 *   control.selfRestart.on (default off); otherwise it still counts and says "self-restart off". restart.staleMinutes()
 *   tells how long the stock has stood still, the second signal the agents now require. A requested restart (console,
 *   dma-restart-request.json) is unchanged.
 *   Unit: tests/unit/dma-stale-watch.test.js (self-restart off: no restart after 30 min; on: as before).
 *   Integration: tests/integration/dma-self-restart-off.test.js.
 * Stable client filename: user_dma_control.js
 * Replace this file in place. Version is inside (DMA_Control.version).
 * Current: 0.2.116
 */
/*
 * DMA Control 0.2.19
 * Phase: cartography only.
 *
 * 0.2.112 (2026-11-17, UAT 2026-11-17 finding F2; the manual says "Without a target nothing is upgraded"): sendUpgrade() fell back to a target of 2 (3 for TitaniumOre) when the policy held no upgrade target
 *   for the ore, so a fresh install that switched Upgrade on upgraded 48 level-1 mines to level 2. With no target (upg.<Ore> and building.upgradeLevel.<Ore> both absent or 0) it now returns
 *   { ok: false, error: "no-target" } before anything is sent; a stored target works as before (at-max, the maximum level of the type, the tools check). Green 0.9.4 already plans no upgrade without a target.
 *   Unit: tests/unit/dma-control-upgrade-no-target.test.js (a mine of level 1 with no target: refused "no-target", nothing sent; target 3: the order goes). Integration: tests/integration/green-no-target-nothing-upgraded.test.js (green's side with the real policy).
 * 0.2.111 (2026-11-17, tester release, review audit item 3 "the pack must work without a Claude session"): the STALE WATCH (0.2.80) restarts the client when the stock
 *   checksum stands still for control.staleRestartMin (default 10). It exists to catch a game that stops carrying out what the scripts order - so it only has something
 *   to watch while an automation is ON. With every switch OFF (a new player, UAT-01) a quiet island with a full storage is not a stale client, and the watch would have
 *   restarted a tester's client about once an hour. Now: the watch counts only while at least one self-starter switch (policy SWITCHES), the zombie hunt, the premium
 *   setting or an adventure runner is on; with none on it reports state "no automation on" and counts nothing. When the policy cannot be asked, the watch behaves as before.
 *   Unit: tests/unit/dma-stale-watch-needs-automation.test.js (all off: no restart after 30 min; one switch on: the restart as before; zombie hunt, premium and an adventure count too).
 *   Integration: tests/integration/pack-fresh-policy-nothing-acts.test.js (the whole pack with a fresh policy runs its timers, the stale watch among them, and nothing acts); live: I10 of tests/live/check_release_invariants.py is run with automation on, as before.
 * 0.2.110 (2026-11-16, author "ja": the four technical known-failing defects; tester kf-buff-wrapper-guard; adapter 0.2.7 first): the SendServerAction wrapper, the BACKSTOP of ADR 0073 point 4, guards buff
 *   action 61 as it guards 60 (ADR 0009, ADR 0067, ELS-32): a buff is refused for a building that cannot be read, a tribute (*_Mini), a kind that is not on the verified list, and a building that already
 *   carries a buff. A send that carries the adapter's mark (permit ctx.adapter === true, written only by the Game Interface Adapter, adapter 0.2.7) is NOT re-judged at all: the adapter's buff guard (readable, tribute, kind, game's own
 *   check, BUFF ACTION exception, and its own exemptions for away sends and zone buffs, whose grid is not on the home island) has already run and owns it; a permit opened by anything else is guarded here. WHERE THE GUARD LIVES: in the adapter (ADR 0073 point 2); this is only the wrapper's backstop,
 *   and it is effective only when the game ever takes the wrapper (api.wrapper()). Every refusal is recorded as "safeguard refused" and answers false.
 *   Unit: tests/unit/buff-wrapper-guard.test.js (moved from tests/known-failing/kf-buff-wrapper-guard.test.js: tribute, unknown kind, already buffed and unreadable are refused; a verified unbuffed mine goes; a marked
 *   send is left to the adapter). Integration: tests/integration/game-interface-adapter-control.test.js (real control + adapter, wrapper installed: the adapter's own buff still reaches the game).
 * 0.2.109 (2026-11-16, tester on the ADR 0075 stack, tests/unit/kf-supply-off-nobody-makes.test.js moved into the suite): control takes the asking back. The supply manager's `ready` now includes the Supply switch (supply manager 0.1.1);
 *   when it is not ready (file missing, or the player switched Supply off — the default) allocate() asks for the making as before, and recheck() (every minute) asks for every promised allocation that is still short and has no open batch,
 *   so an allocation promised while the manager was ready and left unattended after the switch went off is asked by control again. Never none: either the supply manager or the allocator asks. Unit: tests/unit/kf-supply-off-nobody-makes.test.js and
 *   tests/unit/control-allocate-no-making.test.js. Integration: tests/integration/dma-allocate-supply-handover.test.js.
 * 0.2.108 (2026-11-16, ADR 0075 R-3, backbone v3.19; coordinator batch item 3.4): the material allocator no longer asks for making. TK64 is requested by the resource supply manager (AR66, user_dma_supply_manager.js);
 *   AR60 sets aside only what is in stock. While the supply manager is loaded and ready (DMA_SupplyManager.ready) allocate() promises a short allocation as before (TK60 promise, "lacking" kept, rechecked and declared
 *   when the stock covers it) but requests NO TK64 batch and writes no notice; the supply manager reads the lacking amounts through allocation.list(). allocation.batches() then answers the supply manager's open
 *   batches (the TX page row keeps working). Without the supply manager file (rollback) control asks as before. Nothing else changes.
 *   Unit: tests/unit/control-allocate-no-making.test.js (with a ready supply manager: promise, no TK64 fact, no notice, batches() from the manager; without: the old TK64 request). Integration:
 *   tests/integration/dma-allocate-supply-handover.test.js (real control, transactions and supply manager: a short allocation is promised, the supply manager - not the allocator - requests TK64 once, the stock covers it,
 *   the allocation is declared and the batch accepted).
 * 0.2.107 (2026-11-16, ADR 0074 step 4): verifySearch(resource, geoId, geoName, sid) — the OBSERVED declare of TK11's executor (AR11, which control fills), moved from green: 30 s after a search was sent the
 *   geologist must have a task. Idle: the game did not start it -> TK11 decline by "game (observed)" and a hold on that resource that doubles from 30 min (searchBackoff, up to 4 h); busy: TK11 promise by
 *   "game (observed)" and the hold ends. searchHeld(resource) answers the hold ({ n, at, holdMs } or null) for the deposit search manager's rules. Nothing else changes.
 *   Unit: tests/unit/dma-control-verify-search.test.js (idle -> decline + hold, busy -> promise + hold ends, backoff doubles). Integration: tests/integration/dma-deposit-search-handover.test.js.
 * 0.2.106 (2026-11-16, URGENT; the author: a maximum level of 7 corrupts the island — the coordinator's reading of his "Ja" to 0.2.105 was wrong): the
 *   registered maximum of IronMine, BronzeMine, GoldMine, CoalMine, TitaniumMine and SalpeterMine is 6 again (MAX_LEVEL_REGISTERED and construction-types.yaml, the
 *   content of #444 reverted; 0.2.105 is withdrawn). HARD RULE, in the code (maxLevelOf) and in a test: the maximum the game reports may only LOWER the limit,
 *   never raise it above the registered copy — the limit is min(game, registered) — and the registered copy changes only on the author's EXPLICIT
 *   confirmation of the value itself (a watcher difference is a fact for him, not a licence). Where a type has no registered copy the game's value is the only source.
 *   Unit: tests/unit/control-max-level-never-raised.test.js (game says 7, registered 6 -> 6, the upgrade at level 6 is refused; game says 5 -> 5),
 *   tests/unit/control-max-level-registered.test.js (the code equals the file: six mines at 6). Integration: tests/integration/dma-els33-decline.test.js.
 * 0.2.104 (2026-11-16, ADR 0073 migration, coordinator batch item 2; needs adapter 0.2.3): the mail and trade messages go through the Game
 *   Interface Adapter. sendMail(name, vo, zone) calls GCAF_GameInterface.sendMessage with the registered names ACCEPT_TRADE_MAIL (1050),
 *   DECLINE_TRADE (1053), INITIATE_TRADE (1049), GET_INBOX_HEADERS (1175), GET_INBOX_BODY (1177), DISMISS_MAILS (1201); no module sends a
 *   message to the server itself any more. A refusal (adapter missing, start-up hold) is booked as a refusal and nothing is removed from
 *   the mail window: acceptRoundTrade sends the second side only when the first went; acceptRoundSet books only what went out. The
 *   atHome / rtAwayOk reading stays control's own agenda.
 *   Unit: tests/unit/control-mail-via-adapter.test.js (every mail function sends through the adapter by its registered name; a refusal
 *   sends nothing further and removes nothing). Integration: tests/integration/game-interface-adapter-control.test.js (real adapter + control: the inbox request reaches the game in both worlds).
 * 0.2.103 (2026-11-16, tester batch on ADR 0073; coordinator): once the wrapper IS effective (0.2.102 reads it back), it must not defeat the adapter's rule
 *   for the adventure's own sends. (1) permit(name, true, ctx) keeps the context the adapter passes for the one call; the
 *   wrapper's visit-hold check lets a send through when ctx.away is true — only the start-up hold still refuses. (2) The wrapper
 *   remembers why it refused last (api.lastBlock(): reason, retry, at); a visit or start-up hold refusal carries retry: true, so
 *   the adapter can answer retry for a hold that came from the wrapper (adapter 0.2.1). Integration:
 *   tests/integration/wrapper-allows-away-sends.test.js (moved from tests/known-failing/kf-wrapper-refuses-away-sends).
 * 0.2.102 (2026-11-16, ADR 0073 THE SEND-OWNER RULE point 4, approved by the author 2026-11-16 "ja"; PR D of the migration, after the senders): the
 *   wrapper no longer CLAIMS success. wrapCommits() reads every assignment back (gi.SendServerAction, zone.SendDestructBuildingCommand,
 *   gi.SendTogglePauseBuilding must now BE the wrapper) — the ActionScript interface ignores the assignment (ADR 0064, Error #1037),
 *   so until now control reported "armed" with a wrapper that was not in the send path. It records the P-fact "wrapper installed"
 *   (installed: yes | no, and which of the three) once per state change, logs "armed" only when the wrapper is really there, and
 *   says in the log that the adapter guards the sends when it is not. When the game refused the assignment control stops: the
 *   500 ms timer ends (it retried up to 40 times) and the wrap is tried again only after a reload (a new module instance) or by the
 *   test hook wrapNow(). api.wrapper() answers { installed, action, demolish, pause, checkedAt }. The wrapper stays as a backstop
 *   when it does take hold; the adapter (0.2.0) is the owner of every send either way.
 *   Unit: tests/unit/control-wrapper-selfcheck.test.js (an interface that ignores the assignment -> "wrapper installed: no" once,
 *   no retry, installed: false; one that takes it -> "yes" once, a later no-op check records nothing new).
 *   Integration: tests/integration/game-interface-adapter-control.test.js (real control + adapter in both worlds).
 * 0.2.101 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16 "ja"; PR C9 of the migration): control's own senders no
 *   call gi.SendServerAction / zone.SendDestructBuildingCommand and no longer open their own permit. sendBuild (50), sendUpgrade
 *   (60), sendBuff (61, a building) and the geologist search fallback (95/1) send through the Game Interface Adapter
 *   (BUILD, UPGRADE_BUILDING, APPLY_BUFF, SPECIALIST_TASK); sendDemolish through GCAF_GameInterface.sendDemolish. The adapter
 *   owns the guards (it asks control's guardUpgrade / kinds(), so the safeguard of 0.2.15 is now ALSO in the live send path, not only
 *   in the wrapper the ActionScript interface ignores), the holds, the pace, and opens control's permit for exactly the one call.
 *   An adapter refusal comes back as { ok: false, fact: "dc", reason }. The wrapper stays as a backstop (the adapter's permit lets
 *   its own calls through it). Not migrated here, by design: the search's primary path sendSpecPacket (the game's own function —
 *   the game sends it) and the trade / mail messages (1050, 1051 …; ADR 0010 trade gateway; a later PR with its own command
 *   class). No adapter loaded = refused "game interface adapter not loaded" (fail closed).
 *   Unit: tests/unit/dma-safeguard.test.js and tests/unit/dma-release-safety.test.js (the safeguard and upgrade tests now run through the adapter: each sender reaches it by its name, a refusal is the dc reason).
 *   Integration: tests/integration/control-senders-through-adapter.test.js (real control + adapter, wrapper installed AND absent:
 *   a verified mine buffed, a tribute / buffed building refused, an upgrade at the maximum level refused, a demolish of a verified
 *   kind sent and of a tribute refused; permits closed again).
 * 0.2.100 (2026-11-16, follow-up of #398 / #404): (1) retractBuild() no longer calls the retired rgb module's retract
 *   (architect assessment #403, step 2: the readers go with each module's next version; the call always returned 0).
 *   (2) Live checks (CLAUDE.md, #402: a TK change updates them in the same PR; tester report D3: TK63 had no limit):
 *   tests/live/check_release_invariants.py I6 limits TK60 24 h, TK63 24 h and TK64 48 h (v3.17: material allocating
 *   waits for material, a troop order trains up to a row, a production batch is the player's). Nothing else changes.
 *   Unit: tests/unit/no-dma-rgb-in-src.test.js (control is off the list of rgb readers) and
 *   tests/unit/control-allocate-troop-order.test.js (control no longer reads the rgb global; the live limits name TK60, TK63, TK64).
 *   Integration: tests/integration/live-limits-v317.test.js (the checker on a staged dma-transactions.json: TK64 open
 *   50 h and TK60 / TK63 open 30 h FAIL I6; 10 h passes).
 * 0.2.99 (2026-11-16, architect on PR #398): (1) a TK64 batch is NOT declared "produced" when the stock later covers the
 *   shortfall: nobody observed it being produced. The allocator withdraws it instead: revoke request (material
 *   allocator), allow (resource producer, player, tacit), reason "covered from stock". The allocation itself is declared
 *   as before. A batch whose allocation is released before that is withdrawn the same way, reason "allocation
 *   released". (2) The player holds the producer role (AR64), so every open batch is a VISIBLE NOTICE for him: a P-fact
 *   "production batch for the player" {resource, amount} when it is requested, and the file dma-production-requests.json
 *   {open: [{id, resource, amount, since}]} rewritten on every change (allocation.batches() returns the same list).
 *   Not done (follow-up): allocations and open batches are kept in memory only; a client restart forgets them (the
 *   requester asks again; the notice file stays until the next change).
 *   Unit: tests/unit/control-allocate-troop-order.test.js (covered later -> the batch is withdrawn, not declared; the
 *   notice file lists the open batch and is empty after the withdrawal; release withdraws). Integration:
 *   tests/integration/dma-allocate-tk60-tk64.test.js (with the C-fact memory: the batch ends void (revoke request
 *   allowed), not accepted; the TK60 ends accepted; nothing foreign).
 * 0.2.98 (2026-11-16, backbone v3.17 — ADR 0072 T-3 / T-4, model PR #388, reconciliation R-21): MATERIAL ALLOCATING
 *   (TK60, executor AR60 "material allocator") for a TROOP ORDER, as for a construction: the material may have no
 *   construction (PT06 now 0..1; PT18 "the troop order of [material]"). allocate({id, needs, by, troopOrder}) is the
 *   allocator's answer to a TK60 request the requester (AR63 troop order trainer, or AR21 construction upgrader) has
 *   recorded:
 *     rightness (ARS-60-02): the requester is a construction upgrader or a troop order trainer, else decline;
 *     the free stock (availableQty: live stock minus every allocation and every waiting build order) covers every
 *     resource -> the amounts are set aside (the same localAlloc a construction uses), promise, execute, declare;
 *     it does not -> promise ("or what it lacks is produced") and, per lacking resource, TK64 RESOURCE PRODUCING is
 *     requested (ARS-60-03) for a PRODUCTION BATCH {resource, amount} — with no link to its use (T-4). AR64 "resource
 *     producer" is held by the player (APT, no module yet): the request is recorded, nothing is sent.
 *   recheck() (every allocation tick and on each allocate call): a promised allocation whose resources the free stock
 *   now covers is set aside and declared (ARS-60-04); a batch it waited for is then promised (tacit) and declared by
 *   "resource producer (player, stock observed)" and accepted by the allocator (ARS-64-05). release(id) gives the amounts back (the trainer
 *   calls it once the game took them, or when the order is revoked: revoke request -> allow). Facts: TK60 promise /
 *   decline / execute / declare / allow by the material allocator; TK64 request / accept by the material allocator.
 *   The requester records its own request, accept or reject. Nothing else changes; a construction's own allocation
 *   (promiseBuildResources) is unchanged.
 *   Unit: tests/unit/control-allocate-troop-order.test.js (covered -> declared and the stock is no longer free for the
 *   next request; short -> promised + one TK64 per lacking resource; recheck after the stock grew -> declared and the
 *   batch accepted; wrong requester -> declined; release frees the amounts). Integration:
 *   tests/integration/dma-allocate-tk60-tk64.test.js (control + the C-fact memory: a troop order's TK60 ends accepted,
 *   its TK64 batch is open until the stock covers it, then accepted; nothing foreign).
 * 0.2.97 (2026-11-16, tester on PR #379; ADR 0046 / architect rule A6): a hold file WITHOUT a holds list is no longer
 *   "no hold". A single flat hold object ({by, why, setAt, until} — the shape ADR 0046 names for one hold) is read as
 *   that one hold; any other object without a holds list ({} included) counts as unreadable = HELD ("no holds list"),
 *   as an empty or broken file does since 0.2.94. Nothing else changes.
 *   Unit: tests/unit/control-hold-unreadable.test.js ({}, {"by":..} without until, [] all hold; a flat hold object
 *   holds by its own name); the tester's kf-control-hold-shape now passes and is tests/unit/control-hold-shape.test.js. Integration: tests/integration/dma-restart-hold-unreadable.test.js (restartWatch with a request: {} and a
 *   flat hold object both hold; a holds list that has ended lets the restart through).
 * 0.2.96 (2026-11-16, the author rejected CL-51a (D-6; model PR #383, reconciliation R-18): "corrupt mines can no longer
 *   occur because no upgrade is done when it is not possible" (ELS-33, 0.2.95)): the corrupt-mine REPAIR is RETIRED.
 *   R-REPAIR-CORRUPT (0.2.71: repairTick demolished, through sendDemolish, a verified mine whose real level the game does
 *   not define, and recorded a TK51 request/promise) no longer acts: no demolition, no TK51 fact, and the rule
 *   control.repairCorrupt is no longer read (pbc-player-policy drops it in the same series). What stays is the
 *   DETECTION, as a notice to the player: every 2 min at home, a corrupt mine found (the same test as before: real
 *   level above the maximum and no definition in the game for it) is recorded ONCE per grid as the fact "corrupt mine
 *   noticed" {name, grid, level, max, act: "none"} and listed in dma-repair-status.json (state "notice only"), so a
 *   corrupt mine that already exists is reported, not demolished. The ARS-51-02 extra check R-REPAIR-CORRUPT leaves
 *   docs/05-ontology/dma-implementation/checks.yaml in this change.
 *   Unit: tests/unit/dma-upgrade-ledger-repair.test.js and tests/unit/dma-release-safety.test.js (R3: found and noticed,
 *   nothing demolished, no TK51; a policy that still says control.repairCorrupt true changes nothing). Integration:
 *   tests/integration/dma-corrupt-mine-notice.test.js (real policy + control, fresh and with a stored repairCorrupt
 *   true: nothing demolished, one notice per corrupt mine, the status file lists it) and the tester's
 *   kf-fresh-policy-repair-demolish, moved to tests/integration/fresh-policy-no-demolish.test.js.
 * 0.2.95 (2026-11-16, backbone v3.16 addendum D-6 (model PR #381, ADR 0071 addendum): ELS-33 "[construction] is
 *   upgraded to [level] implies that [level] is at most the maximum level of the construction type of [construction]";
 *   ARS-21-02: the construction upgrader declines an upgrading beyond the maximum, even when asked. ADR 0042: every fact
 *   has a source and a watcher):
 *   (1) The maximum level is no longer the typed KINDS.maxLevel. Its source is the GAME: the highest level n for which a
 *   building of the type has a definition (GetUpgradeLevelBonusesForLevel(1..n) all defined), read once per type from
 *   the first building of that type the guard sees. The REGISTERED COPY is docs/05-ontology/dma/facts/construction-
 *   types.yaml (highest_level), mirrored here as MAX_LEVEL_REGISTERED and held equal to the file by
 *   tests/unit/control-max-level-registered.test.js. The WATCHER: when the game's value differs from the registered
 *   copy, the fact "reference fact differs" {fact: maximum level, type, game, registered} is recorded once per type and
 *   the LOWER of the two is used until the copy is updated (fail safe). Neither known -> the upgrade is refused
 *   ("maximum level unknown"). KINDS keeps what is DMA's own decision (ADR 0009: which kinds, upgrade/demolish allowed);
 *   the corrupt-mine repair and control.upgradeHeadroom read the same maximum.
 *   (2) Every refusal of guardUpgrade on a path that would SEND (sendUpgrade and the SendServerAction wrapper) is now
 *   also the construction upgrader's TK21 decline with the reason: {tk: "TK21", act: "decline", actor: "construction
 *   upgrader", key: "<grid>@<level + 1>" (the key green's R-UPG request uses), reason, rule: "ELS-33" when it is the
 *   maximum, else "safeguard"}. guardUpgrade itself stays a pure query (green asks it as a pre-check).
 *   Unit: tests/unit/control-max-level-registered.test.js (the registered copy equals construction-types.yaml; every
 *   upgradable kind has one) and tests/unit/control-els33.test.js (game max read from definitions; differs -> one fact,
 *   the lower used; unknown -> refused; at the maximum -> refused and a TK21 decline with the reason; a level-1-maximum
 *   type is never upgraded). Integration: tests/integration/dma-els33-decline.test.js (green's R-UPG request and
 *   control's refusal meet in the C-fact memory: the TK21 instance ends declined with the ELS-33 reason, by the
 *   construction upgrader; nothing reaches the server).
 * 0.2.94 (2026-11-16, architect rule A6 in the review addendum; tester re-run 2026-11-16, known-failing
 *   kf-control-hold-unreadable): control's restart-hold reader treated an unreadable dma-restart-hold.json as NO hold and
 *   restarted — restart.now() (stale watch, "game not responding", the console) and the request watcher alike. A6: "a
 *   hold file that cannot be read counts as held for any reader that would kill or restart the client". Now a hold file
 *   that exists but is empty (0 bytes, e.g. mid-write), is not JSON, or has no holds list is an active hold by
 *   "unreadable hold file" (the reason is in dma-restart-status.json), re-read every call; nobody's name passes it. A
 *   missing file is still no hold. The watchdog tool (0.1.1) already did this. Nothing else changes.
 *   Unit: tests/unit/control-hold-unreadable.test.js (the tester's test, moved from tests/known-failing, + a 0-byte file,
 *   a JSON without holds, a missing file -> restart allowed, a readable hold -> held, the 6 h cap). Integration:
 *   tests/integration/dma-restart-hold-unreadable.test.js (a remote session's restart request through the watcher: held
 *   while the hold file is truncated or empty, "held" status naming it, restarts once the file is readable and empty of holds).
 * 0.2.93 (2026-11-16, architecture review 2026-11-16 finding #1, Critical; packaging blocker §5.1): the 0.2.92 watchdog
 *   (keep-awake, dma-alive.json, dma-relaunch.cmd, the Windows scheduled task "DMA watchdog") is no longer part of control.
 *   It moved, unchanged in purpose, to the opt-in tool src/tools/user_dma_watchdog.js 0.1.0: rules control.watchdog and
 *   control.keepAwake default OFF, never in a tester pack, and the relaunch line is stored DPAPI-protected (current
 *   Windows user) instead of as a plain .cmd with the session's CLIENT_AUTHRANDOM. Control writes no login token to disk:
 *   a plain dma-relaunch.cmd left by 0.2.92 is deleted once at load (api.plainRelaunch() says "removed" | "none").
 *   The self-restart (restart.now, 0.2.61) is unchanged: it passes the token to the new process as an argument, not
 *   through a file. Not location management's work (AR81): implementation only, no DEMO role.
 *   Unit: tests/unit/dma-control-no-watchdog.test.js (load registers no task, starts no process, writes no file that
 *   holds the token, removes a plain dma-relaunch.cmd). Integration: tests/integration/dma-watchdog-optin.test.js
 *   (control + the tool with a fresh policy: nothing registered, nothing written; with control.watchdog on: the task is
 *   registered and no file on disk holds the token).
 * 0.2.89 (2026-11-09, live: the loot of eight Gunpowder runs stayed in the inbox — the "Adventure … has ended" mail was
 *   not a loot type): MAIL_TYPE.ADVENTURE_WON_LOOT (19, read from the client's Enums::MAIL_TYPE with probe 0.1.43) is a
 *   loot type of the new group "advloot", collected by the mail manager like the explorer loot (the game's collect).
 *   Author 2026-11-09: "today you only play adventures to reach that number" (768 pumpkin fillers).
 * 0.2.88 (2026-11-09, author: "Buffing is always good when at the determined level"; ADR 0040): the island picture
 *   keeps every production building (one with a resource creation) past the scan cap of 400 (the island has 1,012
 *   buildings), and records for it prod: true and producing: true while its production is active and in state 0 (not
 *   waiting for input, not stopped). Green's R-BUFF-PROD reads these facts; nothing else changes.
 * 0.2.87 (2026-11-08, live A Giant Battle: the agents' "game not responding" restart (3 explorers idle again) restarted
 *   the client at 16:27 although the AGB session held it, ADR 0046): restartClient itself refuses while a restart hold is
 *   active, so no caller can go around a hold. Reason "restart hold by <by>".
 *   Unit: tests/unit/dma-control-restart-hold-all.test.js. Integration: with a hold set, a "game not responding" suspicion
 *   logs "held" and the client keeps running.
 *
 * 0.2.86 (2026-11-05, author 09:16 Dubai: "praat met elkaar over wanneer de client herstart mag worden en wanneer
 *   niet" — two sessions restarted the client under each other's adventure run): RESTART HOLD. Any session (or tool) that
 *   must not be interrupted writes dma-restart-hold.json {holds: [{by, why, setAt, until}]} next to the client. While a
 *   hold is active (until in the future, at most 6 h after setAt) the watcher restarts nothing: status "held" names
 *   by/why/until, and a waiting request stays valid until 15 min after the last hold ended (not 15 min after it was
 *   written). The holder removes its entry (or lets it run out) when done. ADR 0046.
 *   Unit: tests/unit/dma-control-restart.test.js (held, then restarts after the hold ends); integration: a remote
 *   session's deploy request waits while the adventure session's hold is on, and restarts once it is lifted.
 * 0.2.85 (2026-11-04, author 14:19: "Ja" — an upgrade the game did not start within 2 h is revoked by the construction
 *   manager): releaseUpgradeOrder(grid) drops the ledger's order for a grid ONLY when the game shows no upgrade running
 *   (IsUpgradeInProgress false, no start time) and the level is still the level the order was given at; otherwise it
 *   refuses and the order stays. The guard is unchanged: before any new order it still reads the live level, a running
 *   upgrade and the ledger.
 *   Unit expectation: dma-upgrade-revoke.test.js (not running, same level -> dropped; running -> refused, kept).
 *   Integration expectation: the 14 upgrades promised since 2026-11-02/03 are revoked once and requested again.
 * 0.2.84 (2026-11-04, backbone v3.12, ADR 0041): the upgrade ledger's information facts name TK21 (construction composing)
 *   instead of TK31. Nothing else changes. Unit/integration expectation: the ontology guard reports no TK31 in control.
 * 0.2.83 (2026-11-04, decompiled client.swf: cBuilding draws the pickup icon when productionQueue
 *   .mTimedProductions_vector[0].readyForDeliver; the queue's waitForPickup only says the building is of a kind whose
 *   production is picked up by hand (a constructor flag), so 0.2.82 listed Mayorhouse/Bookbinder although nothing was
 *   ready): a pickup is a building whose queue waits for pickup AND whose first production is readyForDeliver and not
 *   already waiting for the server.
 *   Unit expectation: dma-control-finds.test.js (waitForPickup without a ready production is no pickup).
 *   Integration expectation: finds().pickups is empty while no icon shows.
 * 0.2.82 (2026-11-04, author: "de hartjes zijn er weer, de verrekijker en de kadootjes, hadden we dat niet geautomatiseerd?"
 *   — "Ook met de collectables geldt de locatie manager doet een scan. Wellicht is er een event handler voor deze
 *   collectables, zo ja gebruiken, anders scan herhalen"; probe user_dma_probe_pickups 0.1.1–0.2.0, 2026-11-02..04): the
 *   icons over buildings (hearts, telescope, gifts, a finished Tome ...) are TIMED PRODUCTIONS waiting to be picked up —
 *   the building's productionQueue.waitForPickup is true (the building's own waitForPickup stays false; no quest trigger).
 *   The location manager's scan notes them as finds.pickups (api.finds), beside the collectibles. Two client events,
 *   proven live by the probe, start a scan at once instead of waiting for the 45-s cycle: TIMED_PRODUCTION
 *   .timedProducedItems (a production completed or was picked up) and ZONE.COLLECTIBLES_UPDATED (carries the count);
 *   at most one event scan per 5 s. The managers still only read the picture (ADR 0040).
 *   Unit expectation: a building whose productionQueue.waitForPickup is true is in finds().pickups, one with false is not.
 *   Integration expectation: after the event, finds().pickups lists Mayorhouse/Bookbinder while their icon shows.
 * 0.2.81 (2026-11-02, release test of pack 02c, finding F-D: the ledger held CoalMine @5664 "ordered at level 1"
 *   from 02:29 UTC; that mine was demolished at 02:40 and a new CoalMine built on the same grid at 02:45 — same name, same
 *   level 1 — so the guard read the old order as the new mine's and refused every upgrade of it for ten hours). A ledger
 *   entry belongs to a BUILDING, not to a grid: the upgrade watch (every 20 s, at home) drops an entry when its grid holds
 *   no building, or another kind, on two watches in a row at least 35 s apart (fact "upgrade ledger entry dropped:
 *   building gone"). No entry expires by time (incident 2026-11-01 stands). An entry left by a building that was
 *   replaced before 0.2.81 is removed by hand once, with the facts as the proof (test report 2026-11-02 release 02c).
 *   Unit: tests/unit/dma-release-safety.test.js (watch block: gone twice -> dropped; gone once -> kept; a running
 *   upgrade's entry is never dropped). Integration: live, after a demolition the grid's entry leaves the ledger within
 *   a minute, and the rebuilt mine is upgraded again.
 * 0.2.92 (author 2026-11-11: the client stopped at 06:29Z when the laptop slept and could only come back through the
 *   launcher's PLAY, which a remote session cannot click): (1) keep the computer awake while the client runs
 *   (NativeApplication.systemIdleMode = KEEP_AWAKE, rule control.keepAwake, default on); (2) every minute write
 *   dma-alive.json {at, atMs, version} — written in every view, unlike the heartbeat that pauses while visiting;
 *   (3) every 5 minutes write dma-relaunch.cmd — the self-restart command line (client64.exe "tso://?…flexid=…&authrandom=…")
 *   of this session; (4) write dma-watchdog.ps1 and register it once as the Windows scheduled task "DMA watchdog"
 *   (every 5 minutes, rule control.watchdog, default on): when dma-alive.json is older than 10 minutes, no restart hold
 *   is active and no relaunch was tried in the last 15 minutes, it stops client/client64 processes and runs
 *   dma-relaunch.cmd; every step is logged in dma-watchdog.log. Whether a session survives a long sleep is unknown —
 *   the log will show it; if not, the launcher (PLAY) remains the way back.
 * 0.2.91 (2026-11-10, ADR 0058, agents 0.4.21): a geologist the player set to "skill first" that is not fully skilled
 *   (his tree read from the game at the pick) is not taken for a search: priorityGeoFor, the PBC's preferred geologist
 *   and pickGeoFor ask DMA_Demo.mayUse first. Unit: tests/unit/dma-geo-skill-first.test.js; integration: live, such a
 *   geologist stays home and the Specialists screen lists him as waiting for skilling.
 * 0.2.90 (2026-11-10, release test 2026-11-10 findings F3/F4/F5; author: "ja" to proving the cause first): the client
 *   was lost after a self-restart (11-07; 11-10 08:18-12:51 UTC and 01:22-02:37). The loader gives every start a new
 *   AIR id (index.html updateApplication); if that write fails, the new start is handed to the running instance and
 *   nothing is left once this process exits. RESTART TRACE: every restart appends a line to dma-restart-log.jsonl —
 *   phase "restart" {reason, by, uptimeSec, idBefore, idAfter, renewed, exe} before the exit — and every load appends
 *   phase "loaded" {id, sinceRestartSec}. A restart whose "loaded" line never follows is a lost restart, with its id
 *   evidence. Also: (F4) the trace is the history of requested and own restarts; (F5) a stale client whose restart is
 *   refused records "client stale" once per refusal reason with result "held", not "restart" every minute; the
 *   session that owns the active restart hold (request "by" = hold "by") may restart through it (a controlled test).
 *   Unit: tests/unit/dma-control-restart.test.js (trace lines, owner passes the hold, others wait); tests/unit/
 *   dma-stale-watch.test.js. Integration: live, a series of requested restarts each leaves restart + loaded lines.
 * 0.2.80 (2026-11-02, release test of pack 02c: the client went STALE — the game stopped carrying anything out while
 *   the scripts ran on — on 2026-11-01 10:59-13:07 UTC and on 2026-11-02 04:08-07:10 UTC: the heartbeat's stock checksum
 *   did not change for 129 and 182 minutes, the mail manager "collected" the same 10 mails six times, nothing was
 *   built; in normal play the checksum never stays the same for more than 2 minutes (heartbeats of 11-01 and 11-02).
 *   Incident 2026-10-27 showed the same). STALE WATCH: every 60 s at home, without a visit hold, the same checksum as
 *   the heartbeat (Stone, Plank, Tool, Coal, Iron, Gold, Bread, Sausage) is read; unchanged for control.staleRestartMin
 *   (default 10, 0 = off) the client is restarted the self-restart way (fact "client stale", status in
 *   dma-restart-status.json), at most once per hour (the time is kept in dma-stale.json: localStorage does not survive
 *   a restart), never while blue work or an adventure's sends run (the same conditions as a requested restart).
 *   Unit: tests/unit/dma-stale-watch.test.js (unchanged 9 min: nothing; 10 min: one restart and the fact; within the
 *   hour: held; a changing checksum resets; away or visit hold: no count; off at 0). Integration: a frozen client is
 *   restarted within about 11 minutes (tests/live/check_release_invariants.py I10).
 * 0.2.79 (2026-11-02, author: "je kijkt bij het geven van de opdracht voor een upgrade altijd naar zijn huidige level.
 *   Als deze upgrade eenmaal loopt wordt een nieuwe upgrade niet gegeven. Een manuele upgrade is waarschijnlijk ook af
 *   te vangen met een event handler" — "die kan gewoon nog mee met de release"). A read-only probe on the live client
 *   (src/tools/user_dma_probe_upgrade.js) showed for GoldMine @8668 (DMA's order 07:40 UTC; the game's answer is the same
 *   for an order by hand): while the upgrade runs IsUpgradeInProgress() is true, GetUpgradeStartTime() is non-zero and
 *   mBuildingUpgradeProgress climbs; at the end the level reads 2 and the flags clear. No BUILDING-channel event fires.
 *   So an upgrade by hand is SEEN while it runs, and:
 *   - upgradeWatch (every 20 s): a mine or mason whose upgrade runs and that the ledger does not hold at its level is put
 *     in the ledger — an order by hand is then held exactly like DMA's own, also after it ends and also after a restart
 *     (the 2026-11-01 failure was a level read that stayed behind after the upgrades ended);
 *   - the guard also refuses while GetUpgradeStartTime() > 0 (a second signal next to IsUpgradeInProgress);
 *   - the headroom of 0.2.78 is no longer needed and defaults OFF (control.upgradeHeadroom = true turns it back on).
 *   Unit: tests/unit/dma-release-safety.test.js (watch block). Integration: live, an upgrade by hand appears in
 *   dma-upgrade-ledger.json within 20 s and DMA orders nothing for that mine until a higher level shows.
 * 0.2.78 (2026-11-02, release audit before the testers' pack; author: "vooral als de mogelijkheid bestaat dat hun eiland
 *   corrupt raakt door de foute upgrade van een mijn"). An independent audit of every upgrade and demolish path found:
 *   - R1 an upgrade DMA did not send (ordered by hand, or by another script) is invisible to the ledger; with DMA's own
 *     order on top the mine can pass the game's last defined level. Now an upgrade is ordered only when the game also
 *     defines the level AFTER the next one (headroom for one unseen order), unless the player turns
 *     control.upgradeHeadroom off. DMA therefore never orders a mine's last defined level; the player does that by hand.
 *   - R2 a ledger entry that cannot be written was only logged; after a restart the ledger was empty and the order could
 *     be repeated. Now every write is read back; a failed write blocks every further upgrade (fail closed) until the
 *     client restarts with a readable ledger.
 *   - R3 the corrupt-mine repair demolished on "level above KINDS.maxLevel" alone, with the higher of real and UI
 *     level, and went ahead when IsUpgradeInProgress was missing. Now it reads the real level only, demolishes only
 *     when the game itself has no definition for that level (GetUpgradeLevelBonusesForLevel(level) == null, the method
 *     present), and waits when the game cannot say whether an upgrade runs.
 *   - R5 the ledger is written under both the caller's grid and the building's own GetGrid() when they differ, and the
 *     guard reads both.
 *   - sendUpgrade: an exception in the pre-send checks returns without sending (fail closed), and the ledger records the
 *     level and name read BEFORE the send (a re-read after the send could miss the building and record level 0).
 *   - R4 sendDemolish(grid, expect): when the caller says which building it expects (name), a different building on the
 *     grid is refused.
 *   Unit: tests/unit/dma-release-safety.test.js. Integration: dma-safeguard, dma-upgrade-ledger-repair, dma-mini-mines.
 * 0.2.77 (2026-11-02, author: "upgrades komen niet in de bouwrij"): an upgrade does not take a build-queue slot. Running
 *   upgrades and upgrade orders no longer count as occupied slots, sendUpgrade no longer waits for a free slot or for
 *   an unconfirmed build, and an upgrade order no longer holds back the next build. The one-by-one rule and the
 *   in-flight slot of 0.2.76 apply to build orders only. The one-open-upgrade-per-building ledger is unchanged.
 *   Unit: tests/unit/dma-build-queue-one-by-one.test.js (a running upgrade leaves free unchanged; an upgrade goes while
 *   a build is in flight and does not block the next build). Integration: dma-build-order-lost.test.js passes.
 * 0.2.76 (2026-11-02, author: "komt de verloren bouwopdracht doordat de bouwrij vol zit en dan geen opdracht accepteert
 *   (stilzwijgend)? Dan zul je voor het versturen moeten kijken of de bouwrij vol is en de gehele lijst met goedgekeurde
 *   bouwopdrachten 1 voor 1 afwerken tot die agenda leeg is"; facts 2026-11-02 01:42: three builds sent within 3 s on one
 *   "queue slot free" reading, then four upgrades — the upgrades were carried out, all builds were "lost"): the game
 *   refuses an order silently when the build queue is full, and queueNow only counted what the game's queue vector
 *   already showed. Now
 *   - an order sent less than BUILD_CONFIRM_MS (90 s) ago that the game does not show yet (not in the queue, no
 *     building on its grid, no upgrade running) holds a queue slot ("in flight");
 *   - a running upgrade that is not in the queue vector holds a queue slot too;
 *   - sendBuild and sendUpgrade wait (fact "wait", reason "previous order not confirmed") while an earlier build or
 *     upgrade is in flight, so the approved orders (green's work list) go to the game one by one, each after the
 *     previous one is seen in the queue, until the list is empty.
 *   Lost detection (10 min) and the 2 h skip are unchanged.
 *   Unit: tests/unit/dma-build-queue-one-by-one.test.js (second order waits until the first is in the queue; a running
 *   upgrade outside the vector lowers free). Integration: tests/integration/dma-build-order-lost.test.js still passes;
 *   live, no TK21 "lost" while the queue is full.
 * 0.2.75 (2026-11-02, test of this version: after 30 upgrades sent live the file dma-upgrade-ledger.json did not
 *   exist — the ledger was only written by the SendServerAction wrapper, which evidently does not take hold on the
 *   client's game object, so the one-open-upgrade safeguard of 0.2.71 never had an entry): sendUpgrade writes the ledger
 *   entry itself, right after the game took the order (the wrapper still does too when it holds; the entry is the
 *   same). Behaviour otherwise unchanged; green's TK31 rule was and is the first guard.
 *   Unit: dma-upgrade-ledger-repair.test.js (without the wrapper: a second order at the same level is refused and the
 *   ledger file exists). Integration: live, dma-upgrade-ledger.json appears with the next upgrade.
 * 0.2.74 (2026-11-02, live: the client did not load 0.2.73 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.2.73 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   - TK21 "lost" / "skipped" are not coordination acts: they are recorded as information (kind "i", what: lost /
 *     skipped) — the coordination of a dropped order is green's revoke request + allow (0.8.6). Behaviour unchanged.
 *   - TK-BLUE (the blue manager's task list): every task is its own case (kind#submit time) and the pattern is
 *     complete: request (by whoever submitted it) -> promise (blue starts it) -> declare (it ended, with why) ->
 *     accept (the submitter, tacit). Behaviour unchanged.
 *   Unit: dma-demo4-acts (no non-DEMO act literal left); integration: the blue task tests unchanged.
 *
 * 0.2.72 (2026-11-02, ADR 0038 migration step 3 — TK51): R-REPAIR-CORRUPT records its demolition as DEMO 4 C-facts:
 *   request (initiator "repair (control)", with the mine's name, level and maximum) -> promise (the game took the destruct
 *   command; was "execute") | decline (refused, with the reason). Declare (the mine is gone) and accept are made by
 *   green 0.8.9's TK51 review, like every TK51. What is sent is unchanged (one demolish per corrupt mine per 10 min).
 *   Unit: a level-8 IronMine gives request + promise for its grid; the safeguard refusing gives request + decline.
 *   Integration: tests/integration/dma-tk51-transaction.test.js (repair then green: declare + accept).
 *
 * 0.2.71 (2026-11-01, live: IronMine @2078 and TitaniumMine @13425 at level 8, "-2147483648 %" in the client): the
 *   one-open-upgrade ledger was in localStorage, which the AIR client does not keep, so it never refused; ten upgrade
 *   orders per mine went out while DMA read "level 2", and the game carried them out past the maximum. The ledger is now in memory and in
 *   dma-upgrade-ledger.json, an unreadable ledger refuses (fail closed), and an entry stays until the game shows the
 *   level change (no 12 h expiry). Ledger expectations: order at level 2 -> a second order at level 2 is refused
 *   ("has not shown yet"), also after a restart; level 3 shown -> one new order allowed; mine rebuilt at level 1 -> allowed.
 *   REPAIR rule R-REPAIR-CORRUPT (policy control.repairCorrupt, default on): a verified mine above its maximum level is
 *   demolished (not while its upgrade runs; once per 10 min), first run 4 min after load, then every 2 min.
 *   Unit: IronMine level 8 (max 6) -> one demolish; level 6 -> none; upgrading -> waits.
 *   Integration: after a restart @2078 (level 8) and @13425 (level 7) are demolished; the building manager rebuilds them.
 *
 * 0.2.70 (2026-10-31, author: "de demo actiehandelingen moeten ondersteund worden"): rtAwayOk is also true while the
 *   player himself is on his own adventure (no run going); a run keeps FIGHT-only. Unit: rt-away test; integration: RT
 *   while demonstrating GP.
 * 0.2.69 (2026-10-31, author: learning by demonstration): onServerAction(fn) lets a module watch every server action
 *   (read only) before it is sent. Unit: a watcher sees SendServerAction(61, 0, grid, 0, id); integration: GP demo.
 * 0.2.68 (2026-10-31, live: after a restart on the adventure the snapshot was empty, so no RT): the home-stock snapshot
 *   is kept in dma-home-stock.json and read at load. Unit: rt-away test unchanged; integration: RT after a restart on YWC.
 * 0.2.67 (2026-10-31, live: a restart cut the spread YWC attack): a restart request waits while
 *   DMA_Adventure.restartSafe() is false. Unit: restartWatch with an unsafe adventure returns null and reports waiting.
 * 0.2.66 (2026-10-31, author: "zouden we de RT aan kunnen laten tijdens de adventures?" — "ja"): away from home the
 *   round trade uses a home-stock snapshot (every minute at home, max 3 h old, booked with the trades accepted away);
 *   rtAwayOk() = not home + fresh snapshot + our adventure run in FIGHT. Unit: away + FIGHT + fresh snapshot accepts with
 *   the snapshot stock, away without a run refuses; integration: an RT during a YWC fight.
 * 0.2.65 (2026-10-31, live: the ADVS page showed "visit hold on since 09:19 UTC" an hour later, with the client at
 *   home): an automatic hold requested while the client never left home (a zone loading after a restart, or the viewed
 *   zone not yet the home zone) waited for a "left home" that never came and held all blue work up to 120 minutes. Such
 *   a hold now ends after location.scan.resumeSec once home is settled (home, no zone loading, zone data present,
 *   viewed zone = home zone).
 *   Unit expectation:        a "location manager" hold with leftHome false is released resumeSec after home settles.
 *   Integration expectation: after a restart the hold is gone within about a minute.
 *
 * 0.2.64 (2026-10-31, live: the client restarted every 5 minutes after one request): the loader gives every restart
 *   a new AIR application id, so localStorage was empty after the restart and the same request fired again until it
 *   was 15 minutes old. The watcher now marks dma-restart-request.json {handled:true} before it restarts, and ignores
 *   a handled request.
 *   Unit expectation:        after a restart from a request the file says handled:true; a new instance with empty
 *                            storage does not restart again.
 *   Integration expectation: one request = one restart.
 *
 * 0.2.63 (2026-10-31): still no status in the client after 0.2.62. Two suspects fixed: the request time is parsed by
 *   hand (the client's WebKit may return NaN for an ISO date; "atMs" is accepted too), and the "watching" proof of life
 *   is written on the first 30 s tick instead of a setTimeout (the 60 s skills setTimeout never wrote either).
 *   Unit expectation:        parseIso("2026-10-31T01:41:59Z") = Date.UTC(...); a request with only atMs works.
 *   Integration expectation: dma-restart-status.json says "watching" 30 s after load.
 *
 * 0.2.62 (2026-10-31): the live test of 0.2.61 did not restart and wrote no status. The watcher now writes
 *   dma-restart-status.json 20 s after load ("watching"), on a read error, on a too-old request and on any exception.
 *   Unit expectation:        a broken request file gives state "read-error"; an old one "ignored".
 *   Integration expectation: after load the status file says "watching"; a fresh request restarts or names why not.
 *
 * 0.2.61 (2026-10-31, author: "Wellicht heb je hier iets aan terwijl je opnieuw kunt opstarten", with a community
 *   userscript that restarts the client itself): restart.now(reason) relaunches the client the way the loader does
 *   (index.html runNewApplication: a new client64/client.exe with the session's flexid + authrandom, no zoneid, so no
 *   login and no PLAY) and exits this process after 1 s. restart.watch() polls dma-restart-request.json {at, reason}
 *   every 30 s: a request newer than the last handled one and younger than 15 min restarts once. Never in the first
 *   5 min after load (no restart loop) and never while blue work runs (it waits for the next poll).
 *   Status in dma-restart-status.json.
 *   Unit expectation:        restart.url() keeps the loader's args, drops zoneid, sets flexid/authrandom; a request
 *                            older than the handled one or than 15 min does nothing; uptime < 5 min refuses.
 *   Integration expectation: after a deploy, writing dma-restart-request.json restarts the client into the game.
 *
 * 0.2.60 (2026-10-30, author: "na de RT kun je terug naar de guild chat en de mail sluiten"): gateway closeMailPanel() —
 *   closes the mail window when it is open, whoever opened it (closeMailPanelIfOurs only closes what the trade gateway
 *   opened itself). Open = the window has its panel on stage (mPanel present and not hidden). Never opens it.
 *   Unit expectation:        mailWindowOpen() false -> closeMailPanel() returns false and does not toggle; open -> one toggle.
 *   Integration expectation: after a live RT the mail window is closed.
 * 0.2.59 (2026-10-30, author: "waarom wordt er niks gebouwd"; live: two build orders (IronOre @5882, BronzeOre @10005) were
 *   sent at 12:10 UTC, the game never built them, and they stayed "already ordered" for an hour — an order was only
 *   forgotten when a mine stood on its grid; BronzeOre @10005 had been ordered three times that day and never built): a
 *   build order that is neither in the build queue nor a mine BUILD_LOST_MS (10 min) after it was sent is LOST — it is
 *   forgotten and recorded as a fact (TK21 "lost"). A grid lost twice is skipped for BUILD_SKIP_MS (2 h; fact TK21
 *   "skipped"), so a deposit the game refuses is not ordered again every ten minutes.
 *   Unit expectation:        a sent order without a queue entry or mine: 9 min -> still ordered; 11 min -> lost; the
 *                            second loss -> sendBuild on that grid refused for 2 h.
 *   Integration expectation: tests/integration/dma-build-order-lost.test.js.
 * 0.2.58 (2026-10-30, live 0.2.57: the signature fact read "ToggleMailWindow(event: flash.events::Event): void" — it is the
 *   click handler of the mail icon): the gateway opens and closes the mail window as the icon does, ToggleMailWindow(null).
 *   Unit expectation: openMailWindow calls ToggleMailWindow with one argument (null); close likewise.
 *   Integration expectation: dma-mail-round.test.js (the mock refuses a call without an argument, as the game does).
 * 0.2.57 (2026-10-30, live 0.2.56: openMailWindow failed with "ArgumentError: Error #1063" — gui.ToggleMailWindow takes
 *   arguments, so the scripts have never opened the mail window, not in 0.2.20-0.2.55 either; the freeze came from the
 *   inbox-header request itself): when the open fails, the gateway records once, as a fact TK-MAIL "toggle signature",
 *   the parameters of gui.ToggleMailWindow read from describeType (read-only), so the right call can be chosen.
 *   Unit expectation: a refused toggle yields one signature fact. Integration expectation: all tests pass.
 * 0.2.56 (2026-10-30, ADR 0030 addendum 4; author: "Het openen van de mail moet dus op een rustig moment gedaan worden, dat
 *   is de taak van de mail manager, het hoeft dus niet periodiek. Het kan ook adhoc. Houd bij wanneer de laatste keer is
 *   geweest en open op een rustig moment, doe wat je moet doen en sluit hem weer"): only the mail manager opens the
 *   game's mail window. ensureMailPanel no longer toggles it: when the window is not open it asks the mail manager for
 *   a round (DMA_Mail.requestRound(by)) and answers false. trade.openMailWindow(by, maxMs) / trade.closeMailWindow() are
 *   the mail manager's own acts: open refuses while a hold is on, never toggles a window the player has open, and the
 *   watchdog closes a window we opened after maxMs (default 15 s). quiet() says whether this is a quiet moment: home,
 *   no hold, the send queue empty, no blue task running, and no server action for 20 s (lastActionAt).
 *   THE BLUE MANAGER (author, same day: "Dat is dus een blauwe manager die bijhoudt wat qua implementatie allemaal gedaan
 *   dient te worden (taken lijst van de rest) en wanneer waarvoor tijd is"): DMA_Control.blue keeps the task list of the
 *   implementation work the other actors ask for — submit(kind, by, start) — and starts one task at a time, only at a
 *   quiet moment; the task calls done() when it has finished (closing what it opened). It remembers when each kind last
 *   ran (blue.last()). While a task runs, the send queue waits too, so the task has the client to itself. One task of a
 *   kind is queued at most once; a task that does not call done() is ended after its maxMs (default 120 s).
 *   Unit expectation:        ensureMailPanel -> no toggle, a round requested; openMailWindow -> one toggle, closed by the
 *                            watchdog after maxMs; quiet() false within 20 s of a server action, true after.
 *   Integration expectation: tests/integration/dma-mail-round.test.js.
 * 0.2.55 (2026-10-30, ADR 0030 addendum 3; live after 0.2.54: the island froze again 3 minutes after start, exactly when
 *   the startup hold ended; opening and closing the game's mail window by hand unfroze it): the "freeze" is the game's mail
 *   window that the mail gateway opens (gui.ToggleMailWindow) to read the inbox. It is not drawn, yet it takes every
 *   click and drag on the map, and nothing ever closed it (closeMailPanelIfOurs had no caller). A watchdog now closes a
 *   mail window the gateway opened itself 15 s after it opened it (MAIL_CLOSE_MS) — long enough for the inbox headers
 *   to arrive — every second, whichever actor asked for it (mail, help, trade). A window the player opened is never
 *   touched.
 *   Unit expectation:        ensureMailPanel opens once; 14 s -> still open; 16 s -> ToggleMailWindow again (closed),
 *                            mailOpenedByUs cleared; a window not opened by the gateway is never toggled.
 *   Integration expectation: tests/integration/dma-mail-window-close.test.js.
 * 0.2.54 (2026-10-30, ADR 0030 addendum 3; author: "het eiland bevriest weer, dat moet eerst opgelost worden"; live
 *   bisection of the *.auto switches: only mail.auto froze the home island at login — the mail manager's first tick, 10 s
 *   after the scripts load, opens the game's mail window (gui.ToggleMailWindow) and asks for 5000 inbox headers while the
 *   home zone is still loading): loading the HOME island at start is a zone load too. The location manager requests the
 *   visit hold at start (by "startup"); it is released location.startup.holdSec (policy 0.2.34, default 180) after the
 *   scripts started, once the player is home with the island data present. The mail gateway's own blue acts
 *   (ensureMailPanel, requestInboxHeaders) refuse while any hold is on, whoever calls them.
 *   Unit expectation:        at start held (by "startup"); 179 s -> held; 181 s with zone data -> released; held ->
 *                            ensureMailPanel false and no ToggleMailWindow.
 *   Integration expectation: tests/integration/dma-startup-hold.test.js; the other tests release the startup hold first.
 * 0.2.53 (2026-10-30, ADR 0030 addendum 2; author: "Maak de aanpassing als iemand naar een andere eiland gaat, stopt de scan
 *   automatisch"): the visit hold is requested AUTOMATICALLY, whoever travels. (1) gi.visitZone is wrapped: a call for a
 *   zone other than the home zone requests the hold before the game starts loading (by "visitZone"). (2) A travel
 *   watcher checks every second — away from home, a zone loading, or the viewed zone no longer the home zone — and
 *   requests the hold (by "location manager", why "auto: ...") when the player travels through the game's own buttons.
 *   The hold ends as before: home again for location.scan.resumeSec, visit.close(), or location.visit.maxMin. Rule
 *   location.visit.auto (policy 0.2.33, default on) switches the automatic request off.
 *   Unit expectation:        visitZone(other) -> held before the original runs; visitZone(home) -> no hold; isOnHomzone
 *                            false -> the watcher holds; location.visit.auto false -> no automatic hold.
 *   Integration expectation: tests/integration/dma-visit-hold-auto.test.js.
 * 0.2.52 (2026-10-30, ADR 0030; live: VLT still stuck with the hold on, the chat watcher and the other timers still ran):
 *   the geologist-return check and the skills file write also wait while a visit hold is on; chat 0.5.11, heartbeat
 *   0.1.1 and event 0.2.4 do the same, so a hold stops every blue activity of the scripts.
 * 0.2.51 (2026-10-30, ADR 0030; author: "als een blauwe transactie gevraagd wordt het te bezoeken eiland te laden, dan
 *   moet het verzoek zijn om de eiland scan van thuis tijdelijk stil te leggen, totdat het eiland weer gesloten wordt,
 *   alles op blauw niveau"; live: with every self-starter off, VLT loaded at once): VISIT HOLD. DMA_Control.visit.request(by,
 *   why) puts every blue activity of the home island on hold — scan, send queue, server actions other than the visit,
 *   the self-starters' cycle; atHome() reads false so mail, quest and the actors wait as when away — until
 *   visit.close(), or home again for location.scan.resumeSec after having left, or location.visit.maxMin (120).
 *   Facts TK-VISIT "hold requested" / "hold released".
 *   Unit expectation:        request -> scan reads nothing, a build action is refused, atHome() false; close -> scans again.
 *   Integration expectation: tests/integration/dma-visit-hold.test.js.
 * 0.2.50 (2026-10-30, VLT stuck on "Loading map..."): a server action the safeguard blocks is recorded as a fact
 *   (TK-SAFE "blocked", kind, nr; once a minute per kind and nr), so a blocked zone visit would show in the facts log.
 *   Unit expectation: a blocked action yields one fact per minute. Integration expectation: all tests pass.
 * 0.2.49 (2026-10-30, live after 0.2.48: VLT still "Loading map..." and no "scan paused" fact — none of the three signals
 *   fired during the visit): every server action the safeguard classifies as "other" is recorded once a minute as a fact
 *   TK-LOC "server action seen" (number, first args, home), to find the action a zone visit sends and tie the pause to it.
 *   Unit expectation:        an unknown action nr is recorded once per minute; known kinds are not.
 *   Integration expectation: no behaviour change; all tests pass.
 * 0.2.48 (2026-10-30, author: "wanneer je naar een eiland wil gaan om wat voor een reden dan ook, dan je het scannen van
 *   het home eiland tijdelijk opschort, tot dat je weer terug bent en dan kan de scan weer van start ... als business rule
 *   bij de location manager"; live: VLT stuck on "Loading map..." three times): scan() is skipped while the player is on
 *   another island, a zone is loading (the game's loading-zone panel visible) or the viewed zone changed; it resumes
 *   location.scan.resumeSec (default 60) after being home again. Facts TK-LOC "scan paused" / "scan resumed".
 *   Unit expectation:        isOnHomzone false -> scan() returns the old map and records "scan paused"; home again ->
 *                            no scan for 60 s, then "scan resumed" and a real scan.
 *   Integration expectation: tests/integration/dma-scan-pause-travel.test.js.
 * 0.2.47 (2026-10-29, author with a screenshot of red trick markers: "buildings still tricked, so I think you saw the
 *   wrong ones"): the map keeps at most MAP_CAP (400) buildings and the island has about 1,070, so tricked buildings past
 *   the cap were never seen — the 30 Treats went to the 30 tricked ones inside it. Now a building that carries a buff is
 *   never cut off (like a mine or an event building), and counts.buff counts every buff over ALL buildings.
 * 0.2.46 (2026-10-29, author: "a scan must be able to tell" which buildings carry a trick): the scan records per
 *   building the name of the buff on it (buffName: its definition's name, e.g. a Halloween trick), so the event manager
 *   can find tricked buildings from the island facts.
 * 0.2.45 (2026-10-29, author with a screenshot of the build queue: "De opdracht voor de bouw van een mijn gaat naar de
 *   queue, terwijl er geen grondstoffen gealloceerd zijn voor die bouw"): a construction waiting in the build queue has
 *   not taken its materials yet — the game takes them when it starts — but the allocation was released 60 s after the
 *   send, so the next promise counted the same stock again and a mine went into the queue with nothing allocated (red
 *   hammer). Now every mine order in the queue that has not started (progress 0 or unknown) holds its build costs:
 *   availableQty subtracts them. Read from the queue itself, so a client restart does not forget them.
 * 0.2.44 (2026-10-29, live): an event building is recognised with DMA_Event.match (case and underscores do not count).
 * 0.2.43 (2026-10-29, decision 0026, author: "Buff manager kijkt wat er gebuft moet worden aan de hand van de eiland
 *   feiten"): the one scan records per building whether it is buffed (productionBuff active), so the buff manager reads
 *   the island facts instead of the game; a building that the running event declares buffable (DMA_Event.buffable(),
 *   e.g. the pumpkin cemeteries) is never cut off by the map cap, like a mine.
 * 0.2.42 (2026-10-28, author: "there is only one scan, initiated by the location manager, for everyone"): the island
 *   scan also notes the collectibles (CollectionsManager.getBuildingIsCollectible) and the buildings with a
 *   "select this building" quest trigger; api.finds() hands them to the quest manager, which no longer scans itself.
 *   The map carries the counts (collectibles, questTriggers) for the facts and the console.
 * 0.2.41 (2026-10-27, author: "make sure the Alchemical has priority when searching for titanium"): pickGeoFor("TitaniumOre")
 *   takes an idle, unreserved Alchemical Geologist first (by type or name), before the geologist-search PBC's preference
 *   and the score; with none idle, the pick is as before. (The Alchemical's titanium finds mine 3x as fast and have a
 *   50% chance of 250 Gold Ore — settlersonlinewiki.eu.)
 * 0.2.40 (2026-10-25, author: "the game seems to get slower and slower and the island hardly loads; analyse and
 *   improve"): (1) a trade mail is parsed into a cTradeObject once and remembered by mail id (at most 400), instead of a
 *   new game object every few seconds for every mail by every actor; (2) no in-game alert per geologist send or
 *   construction ("DMA sent geologist ...", "DMA build ...") — each one was a UI panel, during the Marble loop about 600
 *   an hour; the console log and the facts keep them.
 * 0.2.39 (2026-10-25, author: "when I go to another island the orders carry on, and they must stop, because I cannot
 *   carry out other orders on that island; that is not right"): atHome() (game.gi.isOnHomzone) is exported, and every
 *   act this gateway sends — search, build, upgrade, demolish, friend trade, accepting a trade, collecting or declining
 *   mails — is declined with "away from home" while the player is on another island (the commands go to the zone the
 *   player is viewing). The actors pause on the same fact; this is the safety net under them.
 * 0.2.38 (2026-10-25, live: "peter star trade 400k brew" answered "I have no Brew" while brew is full):
 *   trade.resourceList() — every resource the player holds as the game names it (GetPlayerResources_vector), with
 *   amount, storage limit and the name shown (loca RES), so a requested word is matched to the game's own name.
 * 0.2.37 (2026-10-25, live: "@Zingu: sorry, I can't find you in the guild list" — Zingu is in the guild): the game's
 *    cFriendsList.GetGuildMemberByName_string compares username.toLowerCase() with its argument AS GIVEN, so it only
 *    finds a lowercase name. guildMember now passes the name in lowercase, and falls back to walking
 *    gi.GetCurrentPlayerGuild().members itself (case-insensitive).
 * 0.2.36 (2026-10-25, author: a star trade we ask for ourselves when a storage is full): storageOf(name) gives
 *    { amount, max, full } from the game's own resource object (amount, maxLimit — what the resource list's max arrow
 *    reads), max 1,625,500 as the observed fallback; acceptOneTrade(t, maxCost) accepts ONE trade mail (offer to us,
 *    costs we can pay, at most maxCost when given) — the star-trade asker accepts its trades one at a time so they
 *    never pass each other.
 * 0.2.35 (2026-10-25, author: "je moet een veiligheidsmarge inbouwen. Als iemand een resource wil RT waarvan we weinig
 *    hebben, dan wordt het verbruikt voordat we het terug kunnen sturen"): guardRoundSet(trades, cap, marginPct) — for
 *    every resource the set makes us PAY, we must already hold the amount plus marginPct % (default 100: twice the
 *    amount), without counting what the set brings in. Otherwise { why: "I have too little X ...", margin: true }.
 * 0.2.34 (2026-10-25, live: "Connection to the server has been lost" right after a loot collect): the DISMISS_MAILS
 *    request carried an ArrayCollection built from a JavaScript array, which the AIR bridge does not hand to Flash as
 *    an Array; the game's own cMailWindow.dismissSelectedMails builds an empty ArrayCollection and addItem()s each
 *    mail id. collectLootMails now does exactly that, ids as integers, at most 10 per request.
 * 0.2.33 (2026-10-25, author: guild help and star trades): the gateway can SEND a friend trade the way the game's own
 *    cTradingPanel.SendTrade does — INITIATE_TRADE (1049) with dTradeOfferVO { offerRes, costsRes, receipientId,
 *    lots 0, slotType FRIEND_TO_FRIEND (4), slotPos 0 } — guarded: execute allowed, a guild member known by name
 *    (globalFlash.gui.mFriendsList, id and playerLevel), two different resources, whole amounts, enough stock and a
 *    floor that stays in stock. guildMember(name) gives id, level and whether the game's trade delay has passed;
 *    tradeOutcomes(sender) lists the TRADE_ACCEPTED (4) / TRADE_DECLINED (5) mails of a sender; acceptReturnTrade
 *    accepts one trade that returns a star-trade resource (offer = that resource, costs at most a few units).
 * 0.2.32 (2026-10-25): loot mails are grouped (treasure, adventure, fragment, expedition); collectLootMails takes
 *    { toStorage, groups } and collects only the groups switched on; lootCounts() gives the waiting mails per group.
 * 0.2.31 (2026-10-25, author: automate emptying the loot mails): collectLootMails(toStorage) does what the game's own
 *    "collect or delete" does for collectable mails — DISMISS_MAILS (1201) with dDismissMailsRequestVO
 *    { mailsIDs_collection, claim: toStorage } — but ONLY for explorer loot: treasure (6, 41, 44, 45), adventure
 *    finds (25, 27, 42, 43) and expedition finds (53); at most 20 per call; nothing else is ever touched.
 * 0.2.30 (2026-10-25, author: Lucky Find extra deposit for iron / marble): sendSearch(r, _, { luckyFind: true })
 *    sends ONLY a geologist that has Lucky Find (read from the game; the typed-in value only without a tree), and
 *    declines "no idle geologist with Lucky Find" otherwise.
 * 0.2.29 (2026-10-25, author: "a multiple RT: 3 or more trades that, counted all up, net to zero"): guardRoundSet /
 *    acceptRoundSet — any number (2..8) of trades from ONE sender, one lot each, offer and costs different, each
 *    amount within the cap, net zero for EVERY resource, and an acceptance order the stock can pay step by step
 *    (simulated: each trade is paid with what is held, including what earlier trades delivered). The pair rule is
 *    its special case; guardRoundTrade / acceptRoundTrade stay for it.
 * 0.2.28 (2026-10-25, author: "he should redline your trades and tell you why"): declineTradeMails(trades) sends
 *    DECLINE_TRADE (1053, the game's own declineTrade: player id + dIntegerVO(mail id)) for trade mails of ONE
 *    sender only, then removes them from the list; refused for anything else.
 * 0.2.27 (2026-10-25, author: "a function to fish out the trades we need"): the whole inbox, not the visible page.
 *    The MailWindow view holds a PagerControl whose public pager model has source = all mails (cMailWindow sets
 *    pager.source = mMails); mailsList reads that first and falls back to the visible page (mailsList.dataProvider).
 * 0.2.26 (2026-10-25, live: 255 specialists read): kind comes from the tree name (geologist / explorer / general /
 *    transporter / admiral — base types 2 / 1 / 0 / 12 / 18); the last read is cached; skillsOf(id) and
 *    hasSkill(id, name) answer from the game; the geo pick for Lucky Find uses the real skill (luckyFind > 0)
 *    first, the typed-in value only when the game gives no tree.
 * 0.2.25 (2026-10-25): dma-skills.json is written on its own timer (60 s after load, then every 10 min), not only
 *    once control is "armed"; a failure is written into the file, so it can be read without the console.
 * 0.2.24 (2026-10-25, author: skills of geos, expos and gens per specialist): specialistSkills() reads every
 *    specialist's skill tree from the game (cSpecialist.getSkillTree -> cSkillTree items -> cSkill: id, name,
 *    level, position, definition: max levels, point type, books needed) and writes dma-skills.json (read only;
 *    nothing is changed in the game). The console can show the skills instead of the player typing them in.
 * 0.2.23 (2026-10-25): this client is Flex 3 (no FlexGlobals): the view is also sought as the panel's
 *    mUiElement (cGuiBaseElement) and under mx.core::Application.application.systemManager.
 * 0.2.22 (2026-10-25): live, pager is not visible from script either. The inbox is read from the open MailWindow
 *    view itself — found on the Flex display list (FlexGlobals.topLevelApplication.systemManager, popUpChildren),
 *    whose mailsList.dataProvider is public UI API.
 * 0.2.21 (2026-10-25): live, cMailWindow.mMails / mPanel / mMailCache are not visible from script (probe: undefined).
 *    The inbox is read through the public getter pager (PagerControl; setMailHeaderResponse sets pager.source =
 *    mMails) and a mail body through the public getMailInCache(id) / getMailFromList(id).
 * 0.2.20 (2026-10-25): the mail window counts as ready when its panel is visible OR the inbox list already
 *    holds mails (mPanel may not be readable from script); mailProbe() reports what is visible, for the status file.
 * 0.2.19 (2026-10-25) SAFEGUARD, incident BronzeMine @9735 upgraded to level 8 (island corrupt):
 *  - the level is the building's real mUpgradeLevel (GetUpgradeLevel), never only GetUIUpgradeLevel, which
 *    returns the container's mUILevelOverwrite (fixed at 1 for some mines) and hid 7 completed upgrades;
 *  - an upgrade goes only when the game itself allows it (IsUpgradeAllowed, not in progress, not initiated)
 *    and the next level has a definition (GetUpgradeLevelBonusesForLevel(level + 1) != null);
 *  - one open upgrade per building: a ledger (localStorage) remembers each order and its level; no second
 *    order to that grid until the game shows a higher level, or 12 h passed.
 *
 * 0.2.13 (2026-10-24):
 *  - predictSearch(resource): the shortest predicted search time (s) of an idle geologist for
 *    that resource, and the median of all geologists; the lead time a replacement search needs.
 *  - sendSearch(resource, fromBlue, opts): opts.replacement = true skips the executor's own
 *    "covered" check. Green decides that a low mine needs a replacement; the executor only
 *    checks that it can carry the search out (an idle geologist, a search code). Before, green
 *    requested and control declined the same search every cycle.
 *
 * Load AFTER DrunkenMinerAuto_0.0.4.2.js (or alone).
 * Does not write tso_client settings.json.
 * Blocks server commits until window.DMA_Control.permit(name) is used.
 *
 * Goal cycle (later phases, not this file):
 *   find deposit -> build mine if under cap -> upgrade -> buff ->
 *   watch depletion -> geologist search -> demolish/rebuild
 */
(function (root) {
    "use strict";

    var VERSION = "0.2.118";
    var OVERALL = "0.4.0";
    var SUITE_VERSION = "0.1.0";
    var PHASE = "geo-search";
    var MAP_CAP = 400;
    var SCAN_MS = 45000;

    var DEFAULT_MAX = {
        IronOre: 0, Marble: 0, BronzeOre: 0, Coal: 0, Granite: 0,
        GoldOre: 0, Stone: 0, TitaniumOre: 0, Salpeter: 0, Mason: 0
    };

    var blocked = {
        build: 0, upgrade: 0, buff: 0, specialist: 0, demolish: 0, pause: 0, other: 0
    };

    var permits = {
        build: false,
        upgrade: false,
        buff: false,
        specialist: false,
        demolish: false,
        pause: false
    };

    var map = {
        scannedAt: null,
        home: null,
        deposits: [],
        depleted: [],
        buildings: [],
        counts: {}
    };

    var debugLines = [];
    function log(msg) {
        var line = new Date().toISOString().slice(11, 19) + " " + String(msg);
        debugLines.push(line);
        if (debugLines.length > 200) debugLines.shift();
        try { root.__DMA_DEBUG = debugLines.slice(); } catch (_) {}
        try { localStorage.setItem("iso:dma.debugLog", debugLines.slice(-80).join("\n")); } catch (_) {}
        try { if (typeof debug === "function") debug(line); } catch (_) {}
    }

    function clone(v) {
        try { return JSON.parse(JSON.stringify(v)); } catch (_) { return null; }
    }

    function classifyAction(nr) {
        if (nr === 50) return "build";
        if (nr === 60) return "upgrade";
        if (nr === 61) return "buff";
        if (nr === 95) return "specialist";
        if (nr === 107) return "pause";
        return "other";
    }

    /* 0.2.15 — SAFEGUARD (incident 2026-10-24): the scripts may upgrade or demolish ONLY the building kinds
       named here, exactly, and never above their maximum level. Everything else is refused, whatever asks:
       tributes such as BronzeMine_Mini accept an upgrade order from the server and are then corrupt (level 2
       has no definition), after which the island no longer loads. A new kind is added here only after it has
       been verified in the game, with its maximum level. Fail closed: a building that cannot be read is refused. */
    var KINDS = {   // 0.2.95: the maximum level is no longer typed here (ELS-33, ADR 0042) — see maxLevelOf
        IronMine: { resource: "IronOre" },
        BronzeMine: { resource: "BronzeOre" },
        CopperMine: { resource: "BronzeOre" },
        GoldMine: { resource: "GoldOre" },
        CoalMine: { resource: "Coal" },
        TitaniumMine: { resource: "TitaniumOre" },
        SalpeterMine: { resource: "Salpeter" },
        Mason: { resource: "Stone" },
        StoneMason: { resource: "Stone" },
        MarbleMason: { resource: "Marble" },
        GraniteMason: { resource: "Granite" },
        // buff only: an endless mine is never upgraded and never demolished by DMA
        BronzeMineEndless: { resource: "BronzeOre", upgrade: false, demolish: false }
    };
    /* 0.2.95 (ELS-33, ADR 0042): the registered copy of the maximum level per construction type —
       docs/05-ontology/dma/facts/construction-types.yaml (highest_level); kept equal to it by
       tests/unit/control-max-level-registered.test.js. The source is the game (gameMaxLevel); this copy is what the
       watcher compares with. */
    var MAX_LEVEL_REGISTERED = {
        IronMine: 6, BronzeMine: 6, CopperMine: 6, GoldMine: 6, CoalMine: 6, TitaniumMine: 6, SalpeterMine: 6,
        Mason: 7, StoneMason: 7, MarbleMason: 7, GraniteMason: 7,
        BronzeMine_Mini: 1, IronMine_Mini: 1, TitaniumMine_Mini: 1
    };
    var maxFromGame = {}, maxDiffers = {};
    function gameMaxLevel(b) {
        if (!b || typeof b.GetUpgradeLevelBonusesForLevel !== "function") return null;
        var last = 0, l, d;
        for (l = 1; l <= 30; l++) { try { d = b.GetUpgradeLevelBonusesForLevel(l); } catch (_) { return null; } if (d == null) break; last = l; }
        return last >= 1 ? last : null;
    }
    /* HARD RULE (0.2.106): the game's maximum may only LOWER the limit, never raise it above the registered copy; the registered copy changes only on the author's explicit confirmation */
    function maxLevelOf(nm, b) {
        var reg = Object.prototype.hasOwnProperty.call(MAX_LEVEL_REGISTERED, nm) ? MAX_LEVEL_REGISTERED[nm] : null;
        var g = Object.prototype.hasOwnProperty.call(maxFromGame, nm) ? maxFromGame[nm] : null;
        if (g == null && b) { g = gameMaxLevel(b); if (g != null) maxFromGame[nm] = g; }
        if (g != null && reg != null && g !== reg && !maxDiffers[nm]) {
            maxDiffers[nm] = { game: g, registered: reg };
            try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "reference fact differs", what: "maximum level", type: nm, game: g, registered: reg,
                source: "the game (GetUpgradeLevelBonusesForLevel)", copy: "docs/05-ontology/dma/facts/construction-types.yaml", used: Math.min(g, reg) }); } catch (_) {}
            log("ELS-33 watcher: the maximum level of " + nm + " is " + g + " in the game, " + reg + " in the registered copy: " + Math.min(g, reg) + " is used");
        }
        if (g != null && reg != null) return Math.min(g, reg);
        return g != null ? g : reg;
    }
    function declineUpgrade(grid, why) {   // 0.2.95: the construction upgrader's TK21 decline (ARS-21-02)
        try {
            var b = buildingAt(grid), lv = b ? levelOf(b) : null, to = lv >= 0 ? lv + 1 : null;
            var o = { tk: "TK21", act: "decline", actor: "construction upgrader", grid: Number(grid), reason: String(why), rule: /maximum level/.test(String(why)) ? "ELS-33" : "safeguard" };
            if (to != null) { o.key = String(grid) + "@" + to; o.to = to; }
            if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o);
        } catch (_) {}
    }
    function kindOf(name) {
        var n = String(name || "").replace(/^\s+|\s+$/g, "");
        return Object.prototype.hasOwnProperty.call(KINDS, n) ? KINDS[n] : null;
    }
    function buildingAt(grid) {
        try {
            var gi = game.gi, zone = game.zone || (gi && gi.mCurrentPlayerZone);
            var b = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(Number(grid));
            if (!b && zone && zone.mStreetDataMap && zone.mStreetDataMap.GetBuildingByGridPos) b = zone.mStreetDataMap.GetBuildingByGridPos(Number(grid));
            return b || null;
        } catch (_) { return null; }
    }
    function nameOf(b) { try { return b && b.GetBuildingName_string ? String(b.GetBuildingName_string()) : ""; } catch (_) { return ""; } }
    /* 0.2.19 (incident 2026-10-25, BronzeMine @9735 upgraded 1 -> 8): GetUIUpgradeLevel() returns the GO container's
       mUILevelOverwrite when that is > 0, NOT the building's level. For some mines it is fixed at 1, so every
       reader saw "level 1" while mUpgradeLevel climbed, and each finished upgrade was ordered again. The real level
       is mUpgradeLevel (GetUpgradeLevel); a reader takes the HIGHER of the two, so neither can hide a level. */
    function realLevelOf(b) {
        var r = null, u = null;
        try { if (b && typeof b.GetUpgradeLevel === "function") r = Number(b.GetUpgradeLevel()); } catch (_) {}
        try { if (!(r >= 0) && b && b.mUpgradeLevel != null) r = Number(b.mUpgradeLevel); } catch (_) {}
        try { if (b && typeof b.GetUIUpgradeLevel === "function") u = Number(b.GetUIUpgradeLevel()); } catch (_) {}
        if (!(r >= 0)) return 0;                                 // the real level must be readable; the UI level alone is not enough
        return Math.max(r, u >= 0 ? u : 0);
    }
    function levelOf(b) { return realLevelOf(b); }
    /* 0.2.19: one open upgrade per building — an order is remembered with the level it was sent at, and no second
       order goes to that grid until the game shows a HIGHER real level.
       0.2.71 (incident 2026-11-01, IronMine @2078 and TitaniumMine @13425 ordered 10x at "level 2" between 10:47 and
       13:03 UTC while DMA read "level 2"; the game carried them out: level 8, the client shows -2147483648 %): the ledger lived in localStorage, which this AIR client does not keep — it never refused once.
       It is now kept in memory AND in dma-upgrade-ledger.json, and an entry no longer expires by time: it goes only
       when the game shows a higher level (done) or a lower one / another building (the mine was rebuilt). */
    var LEDGER_FILE = "dma-upgrade-ledger.json", ledgerMem = null;
    function ledgerFile(obj) {
        var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath(LEDGER_FILE).nativePath), st = new a.FileStream();
        if (obj) { st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return obj; }
        if (!f.exists) return {}; st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t) || {};
    }
    function hasAirFile() { try { var a = (typeof air !== "undefined") ? air : root.air; return !!(a && a.File && a.FileStream); } catch (_) { return false; } }
    function ledger() {
        if (ledgerMem) return ledgerMem;
        if (!hasAirFile()) { ledgerMem = {}; return ledgerMem; }    // no file system (outside the client): memory only
        try { ledgerMem = ledgerFile(); } catch (_) { ledgerMem = null; }
        return ledgerMem;                                          // null = unreadable file: guardUpgrade fails closed
    }
    var ledgerBroken = "";   // 0.2.78 (R2): set when a write cannot be confirmed; every further upgrade is refused
    function ledgerPut(grid, level, name, alsoGrid) {
        var l = ledger() || ledgerMem || (ledgerMem = {});
        var e = { at: Date.now(), level: level, name: name || "" };
        l[String(grid)] = e;
        if (alsoGrid != null && String(alsoGrid) !== String(grid)) l[String(alsoGrid)] = e;   // 0.2.78 (R5)
        ledgerMem = l;
        if (hasAirFile()) {
            try {
                ledgerFile(l);
                var back = ledgerFile();                                          // 0.2.78 (R2): read it back
                if (!back || !back[String(grid)] || Number(back[String(grid)].level) !== Number(level)) throw "read-back differs";
            } catch (eW) { ledgerBroken = String(eW); log("DMA Control " + VERSION + " upgrade ledger not written (upgrades blocked): " + eW); }
        }
    }
    function ledgerDrop(grid) {
        var l = ledger(); if (!l || !l.hasOwnProperty(String(grid))) return;
        delete l[String(grid)];
        if (hasAirFile()) try { ledgerFile(l); } catch (_) {}
    }
    /* 0.2.79: an upgrade by hand (or by another script) is seen while it runs and held in the ledger like DMA's own */
    var ledgerGone = {};   // 0.2.81: grid -> time its building was first seen gone
    function ledgerSweep(now) {
        var all = ledger(); if (!all) return 0;
        var n = 0, g;
        for (g in all) if (all.hasOwnProperty(g)) {
            var b = buildingAt(g), nm = nameOf(b), e = all[g];
            var gone = !b || (e && e.name && nm !== e.name);
            if (!gone) { delete ledgerGone[g]; continue; }
            if (!ledgerGone[g]) { ledgerGone[g] = now; continue; }
            if (now - ledgerGone[g] < 35000) continue;
            delete ledgerGone[g]; ledgerDrop(g); n += 1;
            try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", { tk: "TK21", what: "upgrade ledger entry dropped: building gone", grid: String(g), name: e && e.name, level: e && e.level, now: nm || "nothing" }); } catch (_) {}
        }
        return n;
    }
    function upgradeWatch(now) {
        if (!hasAirFile() && !ledgerMem) return 0;
        try { ledgerSweep(now || Date.now()); } catch (_) {}
        var n = 0;
        try {
            var v = game.gi.mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector(), i;
            for (i = 0; i < v.length; i++) {
                var b = v[i]; if (!b) continue;
                var nm = nameOf(b), k = kindOf(nm); if (!k || k.upgrade === false) continue;
                var running = callBool(b, "IsUpgradeInProgress") === true;
                if (!running) { try { running = typeof b.GetUpgradeStartTime === "function" && Number(b.GetUpgradeStartTime()) > 0; } catch (_) {} }
                if (!running) continue;
                var g = null; try { g = b.GetGrid(); } catch (_) {} if (g == null) continue;
                var lv = levelOf(b); if (!(lv >= 1)) continue;
                var all = ledger(); if (!all) continue;
                var led = all[String(g)];
                if (led && Number(led.level) >= lv && (!led.name || led.name === nm)) continue;   // already held
                ledgerPut(g, lv, nm);
                n += 1;
                try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", { tk: "TK21", what: "upgrade seen running, not ordered by DMA: held in the ledger", grid: String(g), name: nm, level: lv }); } catch (_) {}
            }
        } catch (_) {}
        return n;
    }
    function callBool(b, fn, arg) {                              // null when the game does not offer it
        try { if (b && typeof b[fn] === "function") return !!(arguments.length > 2 ? b[fn](arg) : b[fn]()); } catch (_) { return null; }
        return null;
    }
    /* returns "" when the action may go, else the reason it is refused */
    function guardUpgrade(grid) {
        var b = buildingAt(grid);
        if (!b) return "no readable building at " + grid;
        var nm = nameOf(b), k = kindOf(nm);
        if (!k || k.upgrade === false) return "kind not upgradable by DMA: " + (nm || "?");
        var lv = levelOf(b);
        if (!(lv >= 1)) return "level unreadable for " + nm;
        var mx = maxLevelOf(nm, b);   // 0.2.95: ELS-33, from the game with the registered copy
        if (mx == null) return nm + ": maximum level unknown (the game does not say and there is no registered copy)";
        if (lv >= mx) return nm + " at its maximum level " + mx + " (ELS-33)";
        // 0.2.19: the game's own conditions, fail closed when it does not answer
        if (callBool(b, "IsUpgradeInProgress") !== false) return nm + " upgrade in progress (or unreadable)";
        if (callBool(b, "IsUpgradeInitiated") === true) return nm + " upgrade already initiated";
        if (callBool(b, "IsUpgradeAllowed", false) !== true) return nm + " level " + lv + ": the game does not allow an upgrade";
        var bonus = null;
        try { if (typeof b.GetUpgradeLevelBonusesForLevel === "function") bonus = b.GetUpgradeLevelBonusesForLevel(lv + 1); } catch (_) { bonus = null; }
        if (bonus == null) return nm + " level " + (lv + 1) + " has no definition in the game";
        var st0 = null; try { if (typeof b.GetUpgradeStartTime === "function") st0 = Number(b.GetUpgradeStartTime()); } catch (_) { st0 = null; }
        if (st0 > 0) return nm + " an upgrade is running (start time set)";       // 0.2.79: second signal
        if (polVal("control.upgradeHeadroom", false) === true) {               // 0.2.78 (R1); 0.2.79: off by default, the watch covers it
            var bonus2 = null;
            try { bonus2 = b.GetUpgradeLevelBonusesForLevel(lv + 2); } catch (_) { bonus2 = null; }
            if (bonus2 == null || lv + 2 > mx) return nm + " level " + (lv + 1) + " is the last level: the player orders it by hand (control.upgradeHeadroom)";
        }
        if (ledgerBroken) return "upgrade ledger could not be written (" + ledgerBroken + "): upgrades blocked";   // 0.2.78 (R2)
        var all = ledger();
        if (!all) return "upgrade ledger unreadable (" + LEDGER_FILE + ")";   // 0.2.71: fail closed
        var own = null; try { own = b.GetGrid ? b.GetGrid() : null; } catch (_) { own = null; }
        var led = all[String(grid)] || (own != null ? all[String(own)] : null);   // 0.2.78 (R5)
        if (led) {
            if (lv > Number(led.level) || lv < Number(led.level) || (led.name && led.name !== nm)) ledgerDrop(grid);   // done, or rebuilt
            else return nm + " an upgrade was ordered at level " + led.level + " and has not shown yet";
        }
        return "";
    }
    function guardDemolish(b) {
        var nm = nameOf(b);
        if (!b) return "no readable building";
        var kd = kindOf(nm);
        if (!kd || kd.demolish === false) return "kind not demolishable by DMA: " + (nm || "?");
        return "";
    }
    /* 0.2.110: the wrapper's backstop for buff action 61; "" when it may go. The adapter owns the real guard (ADR 0073). */
    function guardBuffBackstop(grid) {
        if (permitCtx && permitCtx.adapter === true) return "";   // the adapter's guard has already judged this send (readable, tribute, kind, buffs; away and zone buffs are exempt there by its own rules, adapter 0.2.7)
        var b = buildingAt(grid);
        if (!b) return "no readable building at " + grid;
        var nm = nameOf(b);
        if (!nm) return "building not readable at " + grid;
        if (/_Mini$/i.test(nm)) return "tribute: " + nm;
        if (!kindOf(nm)) return "kind not verified for a buff: " + nm;
        if (b.productionBuff != null) return nm + " already buffed (ELS-32)";
        return "";
    }
    var refusals = [];
    function refuse(kind, why) {
        refusals.push({ at: Date.now(), kind: kind, why: why });
        if (refusals.length > 50) refusals.shift();
        log("DMA Control " + VERSION + " SAFEGUARD refused " + kind + ": " + why);
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "safeguard refused", kind: kind, why: why }); } catch (_) {}
    }

    /* 0.2.101 (ADR 0073): the adapter owns every send; control asks it by registered name */
    function viaAdapter(name, x, grid, y, payload, ctx) {
        var A = root.GCAF_GameInterface;
        if (!A) return { ok: false, reason: "game interface adapter not loaded" };
        try { return A.sendAction(name, x, grid, y, payload, ctx) || { ok: false, reason: "no answer from the adapter" }; } catch (e) { return { ok: false, reason: "send failed: " + e }; }
    }

    function allow(kind) {
        if (kind === "other") return true;
        return permits[kind] === true;
    }

    var lastBlockInfo = null, permitCtx = null;   // 0.2.103: why the wrapper refused last; the context of the open permit
    function rememberBlock(kind, nr) {
        blocked[kind] = (blocked[kind] || 0) + 1;
        lastBlockInfo = { reason: "blocked " + kind + " (SA " + nr + ")", retry: /hold/.test(String(kind)), at: Date.now() };
        log("DMA Control " + VERSION + " blocked " + kind + " (SA " + nr + ")");
        try { var k = kind + "|" + nr, now = Date.now(); if (!blockSeen[k] || now - blockSeen[k] > 60000) { blockSeen[k] = now; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { tk: "TK-SAFE", act: "blocked", kind: kind, nr: nr }); } } catch (_) {}   // 0.2.50
    }
    var blockSeen = {};

    function wrapSettings() {
        if (typeof settings === "undefined" || !settings || typeof settings.store !== "function") return false;
        if (settings.__dmaControlWrapped) return true;
        var origStore = settings.store;
        var origRead = settings.read;
        var mem = {};
        function ours(k) {
            k = String(k || "");
            return k.indexOf("gcaf.") === 0 || k.indexOf("GCAF") === 0 || k.indexOf("dma.") === 0 || k.indexOf("DM_") === 0;
        }
        settings.store = function (data, key) {
            var k = key != null ? String(key) : "";
            if (ours(k)) {
                mem[k] = data;
                try { localStorage.setItem("iso:" + k, JSON.stringify(data)); } catch (_) {}
                log("DMA Control isolated store " + k + " (not settings.json)");
                return true;
            }
            return origStore.apply(settings, arguments);
        };
        if (typeof origRead === "function") {
            settings.read = function (a, b) {
                var k = (b != null && b !== "") ? String(b) : (a != null ? String(a) : "");
                if (ours(k)) {
                    if (Object.prototype.hasOwnProperty.call(mem, k)) return mem[k];
                    try {
                        var raw = localStorage.getItem("iso:" + k);
                        if (raw) { mem[k] = JSON.parse(raw); return mem[k]; }
                    } catch (_) {}
                    return {};
                }
                return origRead.apply(settings, arguments);
            };
        }
        settings.__dmaControlWrapped = true;
        return true;
    }

    var wrapState = { installed: null, action: null, demolish: null, pause: null, checkedAt: null }, wrapKey = "", wrapRefused = false, zoneWrapFn = null;
    function noteWrapper(inst) {   // 0.2.102 (ADR 0073): "wrapper installed: yes/no", once per state change
        var key = JSON.stringify(inst), yes = inst.action === true;
        wrapState = { installed: yes, action: inst.action, demolish: inst.demolish, pause: inst.pause, checkedAt: Date.now() };
        if (key === wrapKey) return; wrapKey = key;
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "wrapper installed", installed: yes ? "yes" : "no", action: inst.action, demolish: inst.demolish, pause: inst.pause,
            why: yes ? "read back: the game interface holds control's wrapper" : "read back: the game interface ignored the assignment (ADR 0064, Error #1037); the adapter guards every send", by: "control " + VERSION }); } catch (_) {}
        log("DMA Control " + VERSION + " wrapper installed: " + (yes ? "yes" : "no") + (yes ? "" : " (the game interface ignores the assignment; the Game Interface Adapter guards the sends)"));
    }
    function wrapCommits(force) {
        var gi = null;
        try {
            gi = (typeof game !== "undefined" && game.gi) ? game.gi
                : (typeof swmmo !== "undefined" ? swmmo.application.mGameInterface : null);
        } catch (_) { gi = null; }
        if (!gi) return false;
        if (gi.__dmaControlWrapped) return true;
        if (wrapRefused && !force) return true;   // 0.2.102: the game refused the assignment; known, not retried until a reload

        var wrapSA = null, wrapD = null, wrapP = null;
        if (typeof gi.SendServerAction === "function") {
            var origSA = gi.SendServerAction;
            wrapSA = gi.SendServerAction = function (nr) {
                lastActionAt = Date.now();   // 0.2.56: a quiet moment is one without server actions
                tellWatchers(arguments);   // 0.2.69: learning by demonstration (adventure) sees every action, before it is sent
                var kind = classifyAction(nr);
                if (kind === "other") noteOtherAction(nr, arguments);   // 0.2.49
                if (kind !== "other" && visitHeld() && !(permitCtx && permitCtx.away === true && hold.by !== "startup")) { rememberBlock(kind + (hold.by === "startup" ? " (start-up hold)" : " (visit hold)"), nr); return false; }   // 0.2.51; 0.2.103: the adapter's away send passes the visit hold
                if (!allow(kind)) {
                    rememberBlock(kind, nr);
                    return false;
                }
                if (kind === "upgrade") {                       // 0.2.15 safeguard, on every path to the server
                    var whyU = guardUpgrade(arguments[2]);
                    if (whyU) { refuse("upgrade", whyU); declineUpgrade(arguments[2], whyU); return false; }   // 0.2.95: TK21 decline
                    var resU = origSA.apply(gi, arguments);
                    if (resU !== false) { var bU = buildingAt(arguments[2]); ledgerPut(arguments[2], levelOf(bU), nameOf(bU)); }   // 0.2.19, 0.2.71: file-backed
                    return resU;
                }
                if (kind === "buff") {                          // 0.2.110: the backstop for action 61 (ADR 0009, ADR 0067)
                    var whyB = guardBuffBackstop(arguments[2]);
                    if (whyB) { refuse("buff", whyB); return false; }
                }
                return origSA.apply(gi, arguments);
            };
        }

        if (typeof gi.visitZone === "function") {   // 0.2.53: a visit requests the hold before the zone loads
            var origVZ = gi.visitZone;
            gi.visitZone = function (zoneId) {
                try {
                    var homeId = homeZoneId();
                    if (polVal("location.visit.auto", true) !== false && (homeId == null || String(zoneId) !== String(homeId)))
                        requestVisit("visitZone", "zone " + zoneId);
                } catch (_) {}
                return origVZ.apply(gi, arguments);
            };
        }

        try {
            var zone = gi.mCurrentPlayerZone;
            if (zone && typeof zone.SendDestructBuildingCommand === "function" && !zone.__dmaControlWrapped) {
                var origD = zone.SendDestructBuildingCommand;
                wrapD = zone.SendDestructBuildingCommand = function (b) {
                    if (!allow("demolish")) {
                        rememberBlock("demolish", "destruct");
                        return false;
                    }
                    var whyD = guardDemolish(b);                    // 0.2.15 safeguard
                    if (whyD) { refuse("demolish", whyD); return false; }
                    return origD.apply(zone, arguments);
                };
                zone.__dmaControlWrapped = true; zoneWrapFn = wrapD;
            }
        } catch (_) {}

        if (typeof gi.SendTogglePauseBuilding === "function") {
            var origP = gi.SendTogglePauseBuilding;
            wrapP = gi.SendTogglePauseBuilding = function () {
                if (!allow("pause")) {
                    rememberBlock("pause", "toggle");
                    return false;
                }
                return origP.apply(gi, arguments);
            };
        }

        if (!wrapD && zoneWrapFn) wrapD = zoneWrapFn;
        var inst = { action: wrapSA ? gi.SendServerAction === wrapSA : null,   // 0.2.102: read back, never assumed
                     demolish: wrapD ? (function () { try { return gi.mCurrentPlayerZone.SendDestructBuildingCommand === wrapD; } catch (_) { return false; } })() : null,
                     pause: wrapP ? gi.SendTogglePauseBuilding === wrapP : null };
        noteWrapper(inst);
        if (inst.action === true) { gi.__dmaControlWrapped = true; wrapRefused = false; }
        else wrapRefused = true;
        return true;
    }

    function safeCall(obj, name, fallback) {
        try {
            if (!obj) return fallback;
            var fn = obj[name];
            if (fn == null) return fallback;
            var val = (typeof fn === "function") ? fn.call(obj) : fn;
            if (val == null || val === "") return fallback;
            return val;
        } catch (_) {}
        return fallback;
    }

    function tryName(item, name) {
        try {
            if (!item) return "";
            var fn = item[name];
            if (fn == null) return "";
            var val = (typeof fn === "function") ? fn.call(item) : fn;
            if (val == null) return "";
            return String(val);
        } catch (_) {
            try { return String(item[name]()); } catch (e2) { return ""; }
        }
    }

    function itemName(item) {
        if (!item) return "";
        var names = [
            tryName(item, "GetName_string"),
            tryName(item, "GetBuildingName_string"),
            tryName(item, "GetResourceName_string")
        ];
        try { if (item.name_string) names.push(String(item.name_string)); } catch (_) {}
        var i;
        for (i = 0; i < names.length; i++) {
            if (names[i]) return names[i];
        }
        return "";
    }

    function uniqueKeys(obj, limit) {
        var out = [];
        var k;
        for (k in obj) {
            if (obj.hasOwnProperty(k)) out.push(k + ":" + obj[k]);
            if (out.length >= (limit || 12)) break;
        }
        return out;
    }

    function canonOre(name) {
        var n = String(name || "");
        if (/BronzeOre|CopperOre|Copper(?!Mine)/i.test(n) && /Ore|Deposit|CopperOre/i.test(n)) return "BronzeOre";
        if (/^CopperOre$/i.test(n)) return "BronzeOre";
        if (/IronOre/i.test(n)) return "IronOre";
        if (/GoldOre/i.test(n)) return "GoldOre";
        if (/^Coal$/i.test(n) || /DepositCoal/i.test(n)) return "Coal";
        if (/TitaniumOre/i.test(n)) return "TitaniumOre";
        if (/Salpeter/i.test(n)) return "Salpeter";
        if (/^Stone$/i.test(n)) return "Stone";
        if (/^Marble$/i.test(n)) return "Marble";
        if (/^Granite$/i.test(n)) return "Granite";
        if (Object.prototype.hasOwnProperty.call(DEFAULT_MAX, n)) return n;
        return "";
    }
    function isOreName(name) {
        return !!canonOre(name);
    }

    function isMineName(name) {
        var n = String(name || "");
        return /Mine|Mason|Quarry/i.test(n);
    }
    /* 0.2.43: a building the running event declares buffable (DMA_Event, decision 0026) */
    function isEventName(name) {
        try { return !!(root.DMA_Event && root.DMA_Event.match && root.DMA_Event.match(name)); } catch (_) { return false; }
    }
    function prodInfo(item) {   // 0.2.88: a production building and whether it produces now
        var out = { prod: false, producing: false };
        try {
            var rc = typeof item.GetResourceCreation === "function" ? item.GetResourceCreation() : null;
            if (!rc) return out;
            out.prod = true;
            var st = typeof rc.GetProductionState === "function" ? rc.GetProductionState() : null;
            var act = typeof item.IsProductionActive === "function" ? item.IsProductionActive() : true;
            out.producing = !!act && Number(st) === 0;
        } catch (_) {}
        return out;
    }
    function buffNameOf(item) {   // 0.2.46
        try {
            var pb = item.productionBuff;
            if (pb == null) return "";
            var def = (pb.GetBuffDefinition && pb.GetBuffDefinition()) || pb.buffDefinition || null;
            var n = def && def.GetName_string ? def.GetName_string() : "";
            return n ? String(n) : "";
        } catch (_) { return ""; }
    }
    function buffedNow(item, gi) {
        try {
            var pb = item.productionBuff;
            if (pb == null) return false;
            if (pb.IsActive && gi && gi.GetClientTime) return !!pb.IsActive(gi.GetClientTime());
            return true;
        } catch (_) { return false; }
    }

    function oreLine(depositCounts) {
        var parts = [];
        var k;
        for (k in DEFAULT_MAX) {
            if (!DEFAULT_MAX.hasOwnProperty(k)) continue;
            var have = (depositCounts && depositCounts[k]) || 0;
            parts.push(k + ":" + have + "/" + DEFAULT_MAX[k]);
        }
        return parts.join(",");
    }

    function mineLine(buildingCounts) {
        var parts = [];
        var k;
        if (!buildingCounts) return "";
        for (k in buildingCounts) {
            if (!buildingCounts.hasOwnProperty(k)) continue;
            if (isMineName(k)) parts.push(k + ":" + buildingCounts[k]);
        }
        return parts.join(",");
    }

    /* 0.2.118 (live 2026-11-24, probe_ld 0.1.80 qtriggers): mQuestClientCallbacks.mClientQuestPool is not readable from a
       script, so the scan found no "select this building" trigger and the quest manager's select round (Q-4b) never fired
       since 2026-11-01. The game offers the same pool through GetClientQuestPool(), GetQuestPool() and
       mNewQuestManager.GetQuestPool(); all three answered ContainsTriggerCondition for Depositorium, FlyingHouse,
       Offshorelighthouse, DimensionalRift and HauntedMansion_pop. The source of the fact is the game (ADR 0042): take the
       first pool that answers. */
    function questPool(gi) {
        var c = [], i, p;
        try { var q = gi.mQuestClientCallbacks; if (q) { c.push(function () { return q.mClientQuestPool; }, function () { return q.GetClientQuestPool(); }, function () { return q.GetQuestPool(); }); } } catch (_) {}
        try { var n = gi.mNewQuestManager; if (n) c.push(function () { return n.GetQuestPool(); }); } catch (_) {}
        for (i = 0; i < c.length; i++) { p = null; try { p = c[i](); } catch (_) {} if (p && typeof p.ContainsTriggerCondition === "function") return p; }
        return null;
    }
    var lastFinds = { scannedAt: null, at: 0, home: false, collectibles: [], triggers: [], pickups: [] };
    function uniqNames(list) { var seen = {}, out = []; list.forEach(function (b) { var n = tryName(b, "GetBuildingName_string"); if (n && !seen[n]) { seen[n] = 1; out.push(n); } }); return out; }
    /* 0.2.48: the location manager's rule location.scan.pauseAway — no island scan while the player travels to or is on
       another island, or a zone is loading; resume location.scan.resumeSec after being home and loaded again. */
    var travel = { away: false, since: 0, homeAt: 0, viewed: null, reason: "" };
    function polVal(k, d) { try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {} return d; }
    function zoneLoading(gi) {
        var cands = [];
        try { cands.push(gi.mLoadingZonePanel); } catch (_) {}
        try { cands.push(swmmo.application.mLoadingZonePanel); } catch (_) {}
        try { cands.push(gi.mClientMessages && gi.mClientMessages.mLoadingZonePanel); } catch (_) {}
        for (var i = 0; i < cands.length; i++) { try { if (cands[i] && cands[i].visible) return true; } catch (_) {} }
        return false;
    }
    function travelState(now) {
        var gi = null, reason = "";
        try { gi = game.gi; } catch (_) {}
        if (!gi) return "";
        try { if (typeof gi.isOnHomzone === "function" && !gi.isOnHomzone()) reason = "on another island"; } catch (_) {}
        if (!reason && zoneLoading(gi)) reason = "a zone is loading";
        var v = null; try { v = gi.mCurrentViewedZoneID; } catch (_) {}
        if (!reason && travel.viewed != null && v != null && String(v) !== String(travel.viewed)) reason = "the viewed zone changed";
        if (reason) {
            if (!travel.away) { travel.away = true; travel.since = now; travel.reason = reason; locFact("scan paused", { reason: reason }); }
            travel.homeAt = 0;
            return reason;
        }
        if (travel.viewed == null && v != null) travel.viewed = v;
        if (travel.away) {
            if (!travel.homeAt) travel.homeAt = now;
            var wait = (Number(polVal("location.scan.resumeSec", 60)) || 0) * 1000;
            if (now - travel.homeAt < wait) return "home again, resuming in " + Math.ceil((wait - (now - travel.homeAt)) / 1000) + " s";
            travel.away = false; travel.viewed = v; locFact("scan resumed", { pausedSec: Math.round((now - travel.since) / 1000) });
        }
        return "";
    }
    function locFact(act, d) { try { var o = d || {}; o.tk = "TK-LOC"; o.act = act; o.actor = "location manager"; o.rule = "location.scan.pauseAway"; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", o); } catch (_) {} log("location " + act + (d && d.reason ? ": " + d.reason : "")); }

    /* 0.2.49: which server action does a zone visit send? Record every "other" action number once per minute as a
       fact (TK-LOC "server action seen"), so the location manager's pause can be tied to the visit itself. */
    var otherSeen = {};
    function noteOtherAction(nr, args) {
        try {
            var now = Date.now(), k = String(nr);
            if (otherSeen[k] && now - otherSeen[k] < 60000) return;
            otherSeen[k] = now;
            var a = []; for (var i = 1; i < Math.min(args.length, 5); i++) { var v = args[i]; a.push(v == null ? null : (typeof v === "object" ? "obj" : v)); }
            if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { tk: "TK-LOC", act: "server action seen", nr: nr, args: a, home: atHomeSafe() });
        } catch (_) {}
    }
    /* 0.2.69 (author: "een leerfunctie ... eerst voorgedaan hoe de speler het wil, en dat wordt opgeslagen en nagedaan"):
       other modules can watch the server actions (read only; a watcher cannot change or block an action) */
    var actionWatchers = [];
    function tellWatchers(args) { var a = Array.prototype.slice.call(args); actionWatchers.forEach(function (fn) { try { fn(a); } catch (_) {} }); }
    function atHomeSafe() { try { return !!game.gi.isOnHomzone(); } catch (_) { return null; } }

    function scan() {
        if (visitHeld()) { log("scan skipped: visit hold (" + hold.by + ")"); return map; }   // 0.2.51
        if (polVal("location.scan.pauseAway", true) !== false) {
            var tr = travelState(Date.now());
            if (tr) { log("scan skipped: " + tr); return map; }
        }
        log("scan start");
        var gi = null;
        try {
            gi = (typeof game !== "undefined" && game.gi) ? game.gi
                : (typeof swmmo !== "undefined" ? swmmo.application.mGameInterface : null);
        } catch (_) { log("scan no gi"); return map; }
        if (!gi || !gi.mCurrentPlayerZone || !gi.mCurrentPlayerZone.mStreetDataMap) { log("scan no zone"); return map; }

        var zone = gi.mCurrentPlayerZone;
        var sd = zone.mStreetDataMap;
        var deposits = [];
        var depleted = [];
        var buildings = [];
        var counts = {};
        var seen = { deposits: 0, buildings: 0 };
        var buildingSource = "none";   // 0.2.117
        /* 0.2.42 (author 2026-10-28: "there is only one scan, initiated by the location manager, for everyone"):
           the same walk over the buildings also notes the collectibles and the buildings that carry a
           "select this building" quest trigger (hearts, telescope, gifts, ...). The quest manager reads them
           here (api.finds) and no longer walks the island itself. */
        var finds = { collectibles: [], triggers: [], pickups: [] };
        var cmgr = null, qpool = null;
        try { var sw = (typeof swmmo !== "undefined") ? swmmo : root.swmmo; cmgr = sw.getDefinitionByName("Collections::CollectionsManager").getInstance(); } catch (_) {}
        qpool = questPool(gi);   // 0.2.118: the first pool the game answers on (mClientQuestPool is not readable from a script)
        function noteFinds(item, name) {
            if (!name) return;
            try { if (cmgr && cmgr.getBuildingIsCollectible(name)) finds.collectibles.push(item); } catch (_) {}
            try { if (qpool && qpool.ContainsTriggerCondition(1, 9, name, "buildingselected", name, null)) finds.triggers.push(item); } catch (_) {}
            try { var pq = item.productionQueue, pv = pq && pq.mTimedProductions_vector, p0 = pv && pv.length > 0 ? pv[0] : null; if (pq && pq.waitForPickup === true && p0 && p0.readyForDeliver === true && !(typeof p0.GetWaitingForServer === "function" && p0.GetWaitingForServer())) finds.pickups.push(item); } catch (_) {}   // 0.2.82; 0.2.83 ready only
        }

        function bump(bucket, key) {
            if (!key) key = "?";
            if (!counts[bucket]) counts[bucket] = {};
            counts[bucket][key] = (counts[bucket][key] || 0) + 1;
        }

        try {
            if (sd.mDepositContainer && typeof sd.mDepositContainer.forEach === "function") {
                sd.mDepositContainer.forEach(function (item) {
                    if (!item) return;
                    seen.deposits += 1;
                    var rec = {
                        grid: safeCall(item, "GetGrid", null),
                        name: tryName(item, "GetName_string"),
                        amount: safeCall(item, "GetAmount", safeCall(item, "GetResourceAmount", null))
                    };
                    if (!rec.name) return;
                    rec.rawName = rec.name;
                    rec.depleted = /Depleted/i.test(String(rec.name)) || Number(rec.amount) === 0;
                    var cn = canonOre(rec.name);
                    if (!cn) return;
                    rec.name = cn;
                    bump("depositAll", rec.name || "?");
                    bump("deposit", rec.name || "?");
                    if (deposits.length < MAP_CAP) deposits.push(rec);
                });
            }
        } catch (_) {}

        try {
            var bldVec = sd.GetBuildings_vector && sd.GetBuildings_vector();
            log("scan vec " + (bldVec ? bldVec.length : "null"));
            var masonCount = 0;
            if (bldVec && typeof bldVec.forEach === "function") {
                bldVec.forEach(function (item) {
                    if (!item) return;
                    seen.buildings += 1;
                    var name = tryName(item, "GetBuildingName_string") || itemName(item);
                    if (/mason/i.test(String(name || ""))) masonCount++;
                    var isDep = false;
                    try { isDep = typeof sd.IsADepletedDeposit === "function" && sd.IsADepletedDeposit(item); } catch (_) {}
                    bump("buildingAll", name || "?");
                    noteFinds(item, name);
                    var rec = {
                        grid: safeCall(item, "GetGridPosition", safeCall(item, "GetGrid", null)),
                        name: name,
                        level: realLevelOf(item) || safeCall(item, "GetUIUpgradeLevel", null),   // 0.2.19: real level
                        realLevel: safeCall(item, "GetUpgradeLevel", null),
                        uiLevel: safeCall(item, "GetUIUpgradeLevel", null),
                        upgradeInProgress: safeCall(item, "IsUpgradeInProgress", null),
                        depleted: isDep,
                        buffed: buffedNow(item, gi),   // 0.2.43
                        buffName: buffNameOf(item)     // 0.2.46
                    };
                    var pi = prodInfo(item); if (pi.prod) { rec.prod = true; rec.producing = pi.producing; }   // 0.2.88
                    bump("building", name);
                    if (/mason|granite/i.test(String(name || ""))) log("scan found " + name + " @" + rec.grid);
                    if (rec.buffName) bump("buff", rec.buffName);   // 0.2.47: over all buildings
                    if (buildings.length < MAP_CAP || isMineName(name) || isEventName(name) || rec.buffName || rec.prod) buildings.push(rec);   // 0.2.47: a buffed building is never cut off   // 0.2.14: a mine or mason is never cut off by the cap
                    if (isDep) {
                        if (depleted.length < MAP_CAP) depleted.push(rec);
                        bump("depleted", name);
                    }
                });
            }
            log("scan masons " + masonCount);
            /* 0.2.117: an empty vector is no measurement either — read the game's second list (live 2026-11-24: one scan in
               about ten saw 1176 deposits and 0 buildings, and the 17 masons left the picture) */
            if (seen.buildings > 0) buildingSource = "vector";
            if ((!bldVec || seen.buildings === 0) && sd.mBuildingContainer && typeof sd.mBuildingContainer.forEach === "function") {
                if (seen.buildings === 0) buildingSource = "container";
                sd.mBuildingContainer.forEach(function (item) {
                    if (!item) return;
                    seen.buildings += 1;
                    var name = tryName(item, "GetBuildingName_string") || itemName(item);
                    var isDep = false;
                    try { isDep = typeof sd.IsADepletedDeposit === "function" && sd.IsADepletedDeposit(item); } catch (_) {}
                    bump("buildingAll", name || "?");
                    noteFinds(item, name);
                    var rec = {
                        grid: safeCall(item, "GetGridPosition", safeCall(item, "GetGrid", null)),
                        name: name,
                        level: realLevelOf(item) || safeCall(item, "GetUIUpgradeLevel", null),   // 0.2.19: real level
                        realLevel: safeCall(item, "GetUpgradeLevel", null),
                        uiLevel: safeCall(item, "GetUIUpgradeLevel", null),
                        upgradeInProgress: safeCall(item, "IsUpgradeInProgress", null),
                        depleted: isDep,
                        buffed: buffedNow(item, gi),   // 0.2.43
                        buffName: buffNameOf(item)     // 0.2.46
                    };
                    var pi = prodInfo(item); if (pi.prod) { rec.prod = true; rec.producing = pi.producing; }   // 0.2.88
                    bump("building", name);
                    if (/mason|granite/i.test(String(name || ""))) log("scan found " + name + " @" + rec.grid);
                    if (rec.buffName) bump("buff", rec.buffName);   // 0.2.47: over all buildings
                    if (buildings.length < MAP_CAP || isMineName(name) || isEventName(name) || rec.buffName || rec.prod) buildings.push(rec);   // 0.2.47: a buffed building is never cut off   // 0.2.14: a mine or mason is never cut off by the cap
                    if (isDep) {
                        if (depleted.length < MAP_CAP) depleted.push(rec);
                        bump("depleted", name);
                    }
                });
            }
        } catch (_) {}

        var home = true;
        try { if (typeof gi.isOnHomzone === "function") home = !!gi.isOnHomzone(); } catch (_) {}

        var queue = [];
        var queueSlots = null;
        var queueUsed = null;
        var queueFree = null;
        try {
            var player = gi.mHomePlayer || gi.mCurrentPlayer;
            var bq = player && player.mBuildQueue;
            if (bq) {
                try { if (typeof bq.GetMaximumQueueSize === "function") queueSlots = bq.GetMaximumQueueSize(); } catch (_) {}
                try { if (queueSlots == null && typeof bq.GetTotalSlots === "function") queueSlots = bq.GetTotalSlots(); } catch (_) {}
                queueFree = null;
                try { if (typeof bq.GetTotalAvailableSlots === "function") queueFree = bq.GetTotalAvailableSlots(); } catch (_) {}
                try { if (queueFree == null && typeof bq.GetAvailableSlots === "function") queueFree = bq.GetAvailableSlots(); } catch (_) {}
                var vec = null;
                try { if (typeof bq.GetQueue_vector === "function") vec = bq.GetQueue_vector(); } catch (_) {}
                if (vec && typeof vec.forEach === "function") {
                    vec.forEach(function (item) {
                        if (!item) return;
                        var pct = safeCall(item, "GetProgress", safeCall(item, "GetBuildProgress", null));
                        if (pct != null && Number(pct) <= 1) pct = Math.round(Number(pct) * 100);
                        queue.push({
                            grid: safeCall(item, "GetGrid", safeCall(item, "GetGridPosition", null)),
                            name: itemName(item),
                            percent: pct
                        });
                    });
                } else if (vec && vec.length) {
                    var qi;
                    for (qi = 0; qi < vec.length; qi++) {
                        if (vec[qi]) queue.push({ name: itemName(vec[qi]), grid: safeCall(vec[qi], "GetGrid", null) });
                    }
                }
                queueUsed = queue.length;
                if (queueFree == null && queueSlots != null) queueFree = Math.max(0, Number(queueSlots) - Number(queueUsed || 0));
            }
        } catch (_) {}

        if (buildingSource === "container" && seen.buildings === 0) buildingSource = "none";
        /* 0.2.117 (ADR 0096): a home scan that sees deposits but no building in either list is incomplete. It is not taken as
           a measurement, however long it lasts: the last known buildings stay in the map, marked with when they were seen,
           and the map says it is incomplete so the location manager withdraws its picture until the lists are back. */
        var incomplete = "", prevMap = map;
        if (home && seen.buildings === 0 && seen.deposits > 0) {
            incomplete = "the game gave no buildings (" + seen.deposits + " deposits seen)";
            if (prevMap && prevMap.home && prevMap.buildings && prevMap.buildings.length) {
                buildings = prevMap.buildings;
                counts.building = (prevMap.counts && prevMap.counts.building) || counts.building;
            }
            log("scan incomplete: " + incomplete + (buildings.length ? "; keeping " + buildings.length + " buildings from " + (prevMap.buildingsAt || prevMap.scannedAt) : ""));
        }
        log("scan deposits=" + deposits.length + " buildings=" + buildings.length);
        map = {
            scannedAt: new Date().toISOString(),
            home: home,
            deposits: deposits,
            depleted: depleted,
            buildings: buildings,
            queue: queue,
            queueUsed: queueUsed,
            queueSlots: queueSlots,
            queueFree: queueFree,
            counts: counts,
            seen: seen,
            buildingSource: buildingSource,                                                        // 0.2.117
            incomplete: incomplete,                                                                // 0.2.117: "" when complete
            buildingsAt: incomplete && prevMap ? (prevMap.buildingsAt || prevMap.scannedAt) : null, // 0.2.117: when the kept buildings were seen
            truncated: deposits.length >= MAP_CAP || buildings.length >= MAP_CAP,
            collectibles: finds.collectibles.length,
            questTriggers: uniqNames(finds.triggers),
            pickups: uniqNames(finds.pickups)
        };
        lastFinds = { scannedAt: map.scannedAt, at: Date.now(), home: home, collectibles: finds.collectibles, triggers: finds.triggers, pickups: finds.pickups };

        if (root.DM_IsolatedSettings && typeof root.DM_IsolatedSettings.store === "function") {
            root.DM_IsolatedSettings.store("DMA_CONTROL_MAP_META", {
                scannedAt: map.scannedAt,
                home: map.home,
                depositCount: deposits.length,
                buildingCount: buildings.length,
                depletedCount: depleted.length,
                seen: seen,
                counts: counts
            });
        }
        try {
            if (!incomplete && typeof GCAF_PlayerPolicyInstance !== "undefined" &&   // 0.2.117: the policy learns from complete scans only
                GCAF_PlayerPolicyInstance &&
                typeof GCAF_PlayerPolicyInstance.observeScan === "function") {
                GCAF_PlayerPolicyInstance.observeScan(map);
            }
        } catch (_) {}
        return map;
    }

    var EXPECTED_PBCS = [
        { id: "pbc.location-management", keys: ["GCAF_LocationManagement", "GCAF_LocationManagementInstance"] },
        { id: "pbc.inventory-management", keys: ["GCAF_InventoryManagement", "GCAF_InventoryManagementInstance"] },
        { id: "pbc.geologist-search", keys: ["GCAF_GeologistSearch", "GCAF_GeologistSearchInstance"] },
        { id: "pbc.building-management", keys: ["GCAF_BuildingManagement", "GCAF_BuildingManagementInstance"] },
        { id: "pbc.buff-management", keys: ["GCAF_BuffManagement", "GCAF_BuffManagementInstance"] },
        { id: "pbc.demolish-management", keys: ["GCAF_DemolishManagement", "GCAF_DemolishManagementInstance"] },
        { id: "pbc.resource-management", keys: ["GCAF_ResourceManagement", "DM_PBCResource"] },
        { id: "pbc.operations-overview", keys: ["GCAF_OperationsOverview", "GCAF_OperationsOverviewInstance"] },
        { id: "pbc.player-policy", keys: ["GCAF_PlayerPolicy", "GCAF_PlayerPolicyInstance"] }
    ];

    function readModule(obj) {
        if (!obj) return null;
        var st = null;
        try {
            if (typeof obj.getStatus === "function") st = obj.getStatus();
        } catch (_) {}
        return {
            id: obj.id || (st && st.id) || "",
            name: obj.name || (st && st.name) || "",
            version: obj.version || (st && st.version) || "",
            started: !!(st && st.started) || obj.started === true,
            present: true
        };
    }

    function listPbcs() {
        var out = [];
        var i, spec, factory, inst, row;
        for (i = 0; i < EXPECTED_PBCS.length; i++) {
            spec = EXPECTED_PBCS[i];
            factory = null;
            inst = null;
            try { factory = root[spec.keys[0]]; } catch (_) {}
            try { inst = spec.keys[1] ? root[spec.keys[1]] : null; } catch (_) {}
            row = {
                id: spec.id,
                active: false,
                version: "",
                name: "",
                started: false,
                source: ""
            };
            if (inst) {
                row = readModule(inst) || row;
                row.id = row.id || spec.id;
                row.active = true;
                row.source = spec.keys[1];
            } else if (factory) {
                row = readModule(factory) || row;
                row.id = row.id || spec.id;
                row.active = true;
                row.started = false;
                row.source = spec.keys[0] + " (factory only)";
            }
            out.push(row);
        }
        out.push({
            id: "dma-control",
            name: "DMA Control",
            version: VERSION,
            active: true,
            started: true,
            source: "user_dma_control.js"
        });
        try {
            if (root.GCAF_GeologistSearchAdapter && root.GCAF_GeologistSearchAdapter.version) {
                out.push({
                    id: "adapter.geologist-search",
                    name: "Geologist Search Adapter",
                    version: String(root.GCAF_GeologistSearchAdapter.version),
                    active: true,
                    started: true,
                    source: "GCAF_GeologistSearchAdapter"
                });
            }
        } catch (_) {}
        return out;
    }

    function pbcStatusText() {
        var list = listPbcs();
        var bits = ["suite " + SUITE_VERSION, "control " + VERSION];
        var i, p;
        for (i = 0; i < list.length; i++) {
            p = list[i];
            if (p.id === "dma-control") continue;
            bits.push(p.id + ":" + (p.active ? (p.version || "?") : "off") + (p.started ? "+run" : ""));
        }
        return bits.join(" | ");
    }

    function summary() {
        return {
            version: VERSION,
            suiteVersion: SUITE_VERSION,
            phase: PHASE,
            pbcs: listPbcs(),
            permits: clone(permits),
            blocked: clone(blocked),
            maxLocations: clone(DEFAULT_MAX),
            bronze: clone(bronzeState),
            idleGeologists: collectIdleGeologists().length,
            map: {
                scannedAt: map.scannedAt,
                home: map.home,
                depositCount: (map.deposits || []).length,
                buildingCount: (map.buildings || []).length,
                depletedCount: (map.depleted || []).length,
                seen: clone(map.seen),
                truncated: !!map.truncated,
                counts: clone(map.counts)
            }
        };
    }



    var TOOLS_KEEP = {
        "Update": true,
        "Options": true,
        "DMA Console": true
    };

    function menuLabel(el) {
        try {
            var s = (el.textContent || el.innerText || "").replace(/\s+/g, " ").trim();
            return s;
        } catch (_) { return ""; }
    }

    function shouldKeepLabel(label) {
        if (!label) return true;
        if (TOOLS_KEEP[label]) return true;
        var k;
        for (k in TOOLS_KEEP) {
            if (TOOLS_KEEP.hasOwnProperty(k) && label.indexOf(k) === 0) return true;
        }
        return false;
    }

    function pruneToolsMenu() {
        var hidden = 0;
        try {
            var nodes = document.querySelectorAll("li, a, button, div, span");
            var i;
            for (i = 0; i < nodes.length; i++) {
                var n = nodes[i];
                if (!n || n.childElementCount > 3) continue;
                var label = menuLabel(n);
                if (!label || label.length > 40) continue;
                if (shouldKeepLabel(label)) continue;
                if (
                    label === "UserExample" ||
                    label === "Building List" ||
                    label === "Building Monitor" ||
                    label === "Send Explorers Event" ||
                    label === "Drunken Miner" ||
                    label === "DM Orchestration Control" ||
                    label.indexOf("G-CAF") === 0 ||
                    label.indexOf("DM Geo") === 0 ||
                    label.indexOf("DM Dispatch") === 0 ||
                    label.indexOf("DM Transaction") === 0 ||
                    label.indexOf("DM Location") === 0 ||
                    label.indexOf("DM Learn") === 0 ||
                    label === "DM Orchestration Control"
                ) {
                    n.style.display = "none";
                    hidden += 1;
                }
            }
        } catch (_) {}
        return hidden;
    }

    var SEARCH_CODES = {
        Stone: "0,0",
        BronzeOre: "0,1",
        Marble: "0,2",
        IronOre: "0,3",
        GoldOre: "0,4",
        Coal: "0,5",
        Granite: "0,6",
        TitaniumOre: "0,7",
        Salpeter: "0,8"
    };

    var bronzeState = {
        lastSendAt: 0,
        lastResult: null,
        sent: 0
    };

    function policyCap(r) {
        try {
            var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
            if (pol && typeof pol.effectiveCap === "function") return Number(pol.effectiveCap(r));
        } catch (_) {}
        return DEFAULT_MAX[r] || 0;
    }

    function depositCountFor(name) {
        var n = 0;
        var i, d, list;
        try {
            list = (map && map.deposits) || [];
            for (i = 0; i < list.length; i++) {
                d = list[i];
                if (d && d.name === name && !d.depleted) n += 1;
            }
            if (n) return n;
            if (map && map.counts && map.counts.depositAll && map.counts.depositAll[name]) {
                return map.counts.depositAll[name];
            }
        } catch (_) {}
        return n;
    }
    function depletedCountFor(name) {
        var n = 0, i, d, list;
        try {
            list = (map && map.deposits) || [];
            for (i = 0; i < list.length; i++) {
                d = list[i];
                if (d && d.name === name && d.depleted) n += 1;
            }
        } catch (_) {}
        return n;
    }

    function taskLabel(item) {
        try {
            var task = item.GetTask ? item.GetTask() : null;
            if (!task) return "";
            if (typeof loca !== "undefined" && loca.GetText && task.getTaskDefinition) {
                var def = task.getTaskDefinition();
                return loca.GetText("LAB", def.mainTask.taskName_string + def.taskType_string);
            }
            if (task.getTaskDefinition && task.getTaskDefinition().mainTask) return String(task.getTaskDefinition().mainTask.taskName_string || "");
        } catch (_) {}
        return "";
    }
    function resourceFromTaskLabel(label) {
        var t = String(label || "").toLowerCase();
        if (t.indexOf("copper") >= 0 || t.indexOf("bronze") >= 0) return "BronzeOre";
        if (t.indexOf("iron") >= 0) return "IronOre";
        if (t.indexOf("coal") >= 0) return "Coal";
        if (t.indexOf("gold") >= 0) return "GoldOre";
        if (t.indexOf("titanium") >= 0 || t.indexOf("alloy") >= 0) return "TitaniumOre";
        if (t.indexOf("saltpetre") >= 0 || t.indexOf("salpeter") >= 0) return "Salpeter";
        if (t.indexOf("stone") >= 0) return "Stone";
        if (t.indexOf("marble") >= 0) return "Marble";
        if (t.indexOf("granite") >= 0) return "Granite";
        return "";
    }
    var reservedGeo = {};
    var allocatedGeo = {};
    function reserveGeo(id) {
        if (id) reservedGeo[id] = Date.now() + 90000;
    }
    function isReserved(id) {
        try { var WFr = root.DMA_Workflows; if (id && WFr && typeof WFr.ownsGeo === "function" && WFr.ownsGeo(id)) return true; } catch (_) {}   // 0.2.114 (ADR 0084)
        if (!id || !reservedGeo[id]) return false;
        if (Date.now() > reservedGeo[id]) { delete reservedGeo[id]; return false; }
        return true;
    }
    function allocatedFor(resource) {
        var n = 0, k, a;
        for (k in allocatedGeo) {
            if (!allocatedGeo.hasOwnProperty(k)) continue;
            a = allocatedGeo[k];
            if (!a || Date.now() > a.until) { delete allocatedGeo[k]; continue; }
            if (a.resource === resource) n += 1;
        }
        return n;
    }
    function allocateGeo(resource) {
        var all = listGeologists();
        var i, g;
        for (i = 0; i < all.length; i++) {
            g = all[i];
            if (!g.idle || isReserved(g.id)) continue;
            reserveGeo(g.id);
            allocatedGeo[g.id] = { resource: resource, until: Date.now() + 90000 };
            return g.id;
        }
        return "";
    }
    function releaseGeo(id) {
        if (!id) return;
        delete reservedGeo[id];
        delete allocatedGeo[id];
    }
    function specDotId(item) {
        try {
            var u = item.GetUniqueID ? item.GetUniqueID() : (item.GetUniqueID && item.GetUniqueID());
            if (!u && item.GetUniqueID) u = item.GetUniqueID();
            if (!u) return "";
            if (u.uniqueID1 != null) return String(u.uniqueID1) + "." + String(u.uniqueID2 || 0);
            if (u.UniqueID1 != null) return String(u.UniqueID1) + "." + String(u.UniqueID2 || 0);
        } catch (_) {}
        return "";
    }

    /* 0.2.115 (ADR 0042): the name of a specialist type is a game fact. It is read from the game's own description of the
       type (Specialists::cSpecialist.GetSpecialistDescriptionForType(t).getName_string(), e.g. "DiligentGeologist") and
       shown as words ("Diligent Geologist"); the game's localised text (loca SPE) wins when it exists. No typed table: the
       former table had 10 of 12 ids wrong (59 "Gingerbread" is Diligent, 26 "Balanced" is Conscientious, ...). */
    var geoTypeNameCache = {};
    function camelWords(raw) {
        return String(raw || "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^\s+|\s+$/g, "");
    }
    function gameTypeName(typeId) {
        typeId = Number(typeId);
        if (geoTypeNameCache.hasOwnProperty(typeId)) return geoTypeNameCache[typeId];
        var n = "", raw = "";
        try {
            var sw = (typeof swmmo !== "undefined") ? swmmo : root.swmmo;
            var C = sw && sw.getDefinitionByName("Specialists::cSpecialist");
            var d = C && C.GetSpecialistDescriptionForType(typeId);
            raw = d ? String(d.getName_string() || "") : "";
        } catch (_) { raw = ""; }
        if (raw) {
            try { var L = (typeof loca !== "undefined") ? loca : root.loca; if (L && L.exist && L.exist("SPE", raw)) n = stripHtml(L.GetText("SPE", raw)); } catch (_) {}
            if (!n) n = camelWords(raw);
            geoTypeNameCache[typeId] = n;
        }
        return n;
    }

    /* Preference for Bronze/Copper only. Higher = pick first. 0.2.115: keyed on the type name the game gives (was keyed on
       ids that pointed at other types: "Chummy 100" went to Iron-Willed). Values unchanged. */
    var BRONZE_PREF = [
        [/Chummy/i, 100], [/Balanced/i, 80], [/Versed/i, 70], [/Conscientious/i, 60], [/^Geologist$/i, 40],
        [/Archeolog/i, 30], [/Gingerbread/i, 20], [/Gold-?hearted/i, 20], [/Iron-?Willed/i, 10], [/Diligent/i, 5], [/Thorough/i, 5]
    ];
    function bronzePref(typeName) {
        var i; typeName = String(typeName || "");
        for (i = 0; i < BRONZE_PREF.length; i++) if (BRONZE_PREF[i][0].test(typeName)) return BRONZE_PREF[i][1];
        return 15;
    }

    function formatSecs(sec) {
        sec = Number(sec || 0);
        if (!sec || sec < 0) return "";
        var m = Math.floor(sec / 60);
        var s = Math.floor(sec % 60);
        if (m >= 60) {
            var h = Math.floor(m / 60);
            m = m % 60;
            return h + "h" + (m < 10 ? "0" : "") + m + "m";
        }
        return m + "m" + (s < 10 ? "0" : "") + s + "s";
    }

    function stripHtml(s) {
        return String(s || "").replace(/<[^>]*>/g, "").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    }

    function knownTypeName(n) {
        n = stripHtml(n);
        if (!n) return "";
        var m = n.match(/\(([^)]*(?:Geologist|Digger)[^)]*)\)/i);
        if (m) return m[1].replace(/^\s+|\s+$/g, "");
        if (/^(?:geologist|digger)/i.test(n) || /geologist$/i.test(n) || /digger$/i.test(n)) return n;
        return "";
    }

    function specName(item) {
        var n = "";
        try { if (item.getName) n = stripHtml(item.getName(false) || ""); } catch (_) {}
        if (!n) { try { if (item.GetNickname) n = stripHtml(item.GetNickname() || ""); } catch (_) {} }
        if (!n) { try { if (item.GetName_string) n = stripHtml(item.GetName_string() || ""); } catch (_) {} }
        if (!n) { try { if (item.getName) n = stripHtml(item.getName(true) || ""); } catch (_) {} }
        return n;
    }

    function specTypeName(item, typeId) {
        var fromGame = gameTypeName(typeId);
        if (fromGame) return fromGame;
        var fromNick = knownTypeName(specName(item));
        if (fromNick) return fromNick;
        var tries = [
            function () { return item.getName && item.getName(true); },
            function () { return item.GetName_string && item.GetName_string(); },
            function () { return item.GetTypeName && item.GetTypeName(); },
            function () { return item.getTypeName && item.getTypeName(); },
            function () { return item.GetSpecialistName && item.GetSpecialistName(); },
            function () { return item.GetBaseName && item.GetBaseName(); }
        ];
        var i, n;
        for (i = 0; i < tries.length; i++) {
            try { n = knownTypeName(tries[i]()); } catch (_) { n = ""; }
            if (n) return n;
        }
        return "Type " + typeId;
    }

    function specTypeDump(item, typeId) {
        var out = ["type " + typeId];
        var keys = ["getName", "GetName_string", "GetTypeName", "getTypeName", "GetSpecialistName", "GetBaseName", "GetNickname"];
        var i, v;
        for (i = 0; i < keys.length; i++) {
            try {
                if (!item[keys[i]]) continue;
                v = keys[i] === "getName" ? item.getName(true) : item[keys[i]]();
                if (v) out.push(keys[i] + "=" + v);
            } catch (_) {}
        }
        return out.join(" | ");
    }

    function specTypeId(item) {
        try { return Number(item.GetType()); } catch (_) {}
        return 0;
    }

    function specTask(item) {
        try { return item.GetTask(); } catch (_) {}
        return null;
    }

    function specRemaining(item) {
        var task = specTask(item);
        var names = ["GetRemainingTime", "getRemainingTime", "GetRemainingSeconds", "GetTotalTime"];
        var i, src, v;
        for (i = 0; i < names.length; i++) {
            try {
                src = item[names[i]] ? item : task;
                if (!src) continue;
                v = src[names[i]]();
                v = Number(v);
                if (!isNaN(v) && v > 0) {
                    if (v > 100000) v = Math.round(v / 1000);
                    return v;
                }
            } catch (_) {}
            try {
                if (task && task[names[i]]) {
                    v = Number(task[names[i]]());
                    if (!isNaN(v) && v > 0) {
                        if (v > 100000) v = Math.round(v / 1000);
                        return v;
                    }
                }
            } catch (_) {}
        }
        return 0;
    }

    function specPredictedSeconds(item, resource) {
        var names = ["GetTaskDuration", "getTaskDuration", "GetSearchDuration", "GetDuration"];
        var i, v;
        for (i = 0; i < names.length; i++) {
            try {
                if (!item[names[i]]) continue;
                v = item[names[i]](SEARCH_CODES[resource] || resource);
                v = Number(v);
                if (!isNaN(v) && v > 0) return v;
            } catch (_) {}
            try {
                if (!item[names[i]]) continue;
                v = Number(item[names[i]]());
                if (!isNaN(v) && v > 0) return v;
            } catch (_) {}
        }
        return 0;
    }

    function describeGeo(item) {
        var typeId = specTypeId(item);
        var typeName = specTypeName(item, typeId);
        var task = specTask(item);
        var rem = specRemaining(item);
        var pred = specPredictedSeconds(item, "BronzeOre");
        var label = taskLabel(item);
        return {
            raw: item,
            name: specName(item),
            typeId: typeId,
            typeName: typeName,
            typeDump: gameTypeName(typeId) ? "" : specTypeDump(item, typeId),
            idle: !task,
            remainingSec: rem,
            remaining: formatSecs(rem),
            bronzePredictSec: pred,
            bronzePredict: pred ? formatSecs(pred) : "n/a",
            bronzeScore: bronzePref(typeName),
            id: specDotId(item),
            taskLabel: label,
            taskResource: resourceFromTaskLabel(label),
            extraDeposit: geoExtraDeposit(item, typeId, typeName)
        };
    }

    function geoExtraDeposit(item, typeId, typeName) {
        var name = typeName || gameTypeName(typeId) || specName(item) || "";
        if (/Conscientious/i.test(name)) return { kind: "always", source: "type" };
        if (/Versed/i.test(name)) return { kind: "chance50", source: "type" };
        var blob = "";
        var fns = ["GetSkills", "GetSkillTree", "GetActiveSkills", "GetSpecialistDescription", "GetDescription"];
        var i, v;
        for (i = 0; i < fns.length; i++) {
            try {
                v = item[fns[i]];
                v = typeof v === "function" ? v.call(item) : v;
                if (v) blob += " " + String(v);
            } catch (_) {}
        }
        if (/Lucky\s*Find/i.test(blob) || /LuckyFind/i.test(blob)) {
            return { kind: "chance15", source: "skill", resources: ["IronOre", "Marble"] };
        }
        return null;
    }

    function listGeologists() {
        var out = [];
        var seen = {};
        var list = [];
        function add(item) {
            if (!item) return;
            var id = "";
            try { id = specDotId(item); } catch (_) {}
            if (id && seen[id]) return;
            if (id) seen[id] = 1;
            var base = 0;
            try { base = item.GetBaseType(); } catch (_) {}
            var typeId = 0;
            try { typeId = Number(item.GetType()); } catch (_) {}
            var named = knownTypeName(specName(item));
            var isGeo = (base === 2) || !!named;
            if (!isGeo) {
                try {
                    var blob = "";
                    var fns = ["GetSpecialistDescription", "GetDescription", "GetTaskDescription"];
                    var i, v;
                    for (i = 0; i < fns.length; i++) {
                        v = item[fns[i]];
                        if (typeof v === "function") v = v.call(item);
                        if (v) blob += " " + String(v);
                    }
                    if (/geologist|deposit|search for/i.test(blob)) isGeo = true;
                } catch (_) {}
            }
            if (!isGeo) return;
            out.push(describeGeo(item));
        }
        try {
            if (typeof game !== "undefined" && game.getSpecialists) {
                var g = game.getSpecialists() || [];
                if (g && typeof g.forEach === "function") g.forEach(add);
            }
        } catch (_) {}
        try {
            var zone = null;
            try { zone = game.gi.mCurrentPlayerZone; } catch (_) {}
            if (!zone) try { zone = game.zone; } catch (_) {}
            if (zone && typeof zone.GetSpecialists_vector === "function") {
                var zv = zone.GetSpecialists_vector();
                if (zv && typeof zv.forEach === "function") {
                    var dump = [];
                    zv.forEach(function (it) {
                        if (!it) return;
                        var tid = 0, base = 0, nm = "", tsk = "";
                        try { tid = it.GetType(); } catch (_) {}
                        try { base = it.GetBaseType(); } catch (_) {}
                        try { nm = it.getName ? it.getName(false) : ""; } catch (_) {}
                        try { tsk = it.GetTask() ? "task" : "idle"; } catch (_) {}
                        if (base === 2 || /geo|digger/i.test(nm)) dump.push(tid + "/" + base + "=" + nm + " " + tsk);
                        add(it);
                    });
                    try {
                        var prev = localStorage.getItem("iso:dma.debugLog") || "";
                        localStorage.setItem("iso:dma.debugLog", (prev + "\nzone raw " + dump.join(", ")).slice(-12000));
                    } catch (_) {}
                }
            }
        } catch (_) {}
        out.sort(function (a, b) {
            if (a.idle !== b.idle) return a.idle ? -1 : 1;
            return b.bronzeScore - a.bronzeScore;
        });
        return out;
    }

    function collectIdleGeologists() {
        var idle = [];
        var all = listGeologists();
        var i;
        for (i = 0; i < all.length; i++) {
            if (all[i].idle) idle.push(all[i].raw);
        }
        return idle;
    }

    function pickBronzeGeo() {
        return pickGeoFor("BronzeOre");
    }

    function pbcInst() {
        try {
            if (root.GCAF_GeologistSearchInstance) return root.GCAF_GeologistSearchInstance;
        } catch (_) {}
        return null;
    }

    function geoMayUse(g) {                                                 // 0.2.91 (ADR 0058)
        try { var D = root.DMA_Demo; if (D && typeof D.mayUse === "function" && g && g.raw) return D.mayUse(g.raw).ok !== false; } catch (_) {}
        return true;
    }
    var PRIORITY_GEO = { TitaniumOre: /Alchemical/i };                      // 0.2.41
    function priorityGeoFor(resource) {
        var re = PRIORITY_GEO[resource]; if (!re) return null;
        var all = listGeologists(), i, g;
        for (i = 0; i < all.length; i++) {
            g = all[i];
            if (!g.idle || isReserved(g.id) || !geoMayUse(g)) continue;
            if (re.test(String(g.typeName || "") + " " + String(g.name || ""))) { log("geo pick " + resource + ": priority " + (g.name || g.typeName)); return g; }
        }
        return null;
    }
    /* 0.2.116 (author 2026-11-19: "gebruik de snelste geos om graniet te zoeken"): for a resource in policy geo.fastestFor
       (default ["Granite"]) the idle geologist the game predicts to finish the search soonest is sent (specPredictedSeconds,
       the game's own task duration for that resource); a geologist without a prediction is passed over; none predicted ->
       the normal pick. */
    function fastestGeoFor(resource) {
        var list = polVal("geo.fastestFor", ["Granite"]);
        if (typeof list === "string") list = list.split(/\s*,\s*/);
        if (!list || typeof list.indexOf !== "function" || list.indexOf(resource) < 0) return null;
        var all = listGeologists(), i, g, v, best = null, bestV = 0;
        for (i = 0; i < all.length; i++) {
            g = all[i];
            if (!g.idle || isReserved(g.id) || !geoMayUse(g)) continue;
            v = 0; try { v = specPredictedSeconds(g.raw, resource); } catch (_) { v = 0; }
            if (!(v > 0)) continue;
            if (!best || v < bestV) { best = g; bestV = v; }
        }
        if (best) log("geo pick " + resource + ": fastest " + (best.name || best.typeName) + " (" + Math.round(bestV / 60) + " min)");
        return best;
    }
    function pickGeoFor(resource, requireLF) {
        var prio = requireLF ? null : priorityGeoFor(resource);           // 0.2.41
        if (prio) return prio;
        var fast = requireLF ? null : fastestGeoFor(resource);            // 0.2.116
        if (fast) return fast;
        var inst = pbcInst();
        if (!requireLF && inst && typeof inst.preferredGeologist === "function") {
            var pref = inst.preferredGeologist(resource);
            if (pref && pref.raw && geoMayUse({ raw: pref.raw })) return describeGeo(pref.raw);   // 0.2.91: else the loop below picks
            if (pref && !pref.raw && geoMayUse(pref)) return pref;
        }
        var all = listGeologists();
        var best = null;
        var i, g, score, fn, lf;
        var wantLF = resource === "IronOre" || resource === "Marble";
        fn = (root.GCAF_GeologistSearch && root.GCAF_GeologistSearch.scoreFor) || null;
        for (i = 0; i < all.length; i++) {
            g = all[i];
            if (!g.idle || isReserved(g.id) || !geoMayUse(g)) continue;   // 0.2.91
            score = fn ? fn(g.typeId, resource) : g.bronzeScore;
            lf = false;
            var lfGame = null; try { lfGame = hasSkill(g.id, "luckyFind"); } catch (_) {}   // 0.2.26: the game first
            if (lfGame !== null) lf = lfGame;
            else { try { lf = !!(root.DMA_GeoSkills && root.DMA_GeoSkills.luckyFind && root.DMA_GeoSkills.luckyFind(g)); } catch (_) {} }
            if (!lf) lf = /Sophisticated|Soph/i.test(g.typeName || g.name || "");
            if (wantLF && resource === "IronOre" && i < 3) log("geo pick " + (g.typeName || g.name) + " lf=" + lf + " score=" + score);
            if (requireLF && !lf) continue;                     // 0.2.30: only a Lucky Find geologist
            if (wantLF && lf) { score += 1000; g._lucky = true; }
            if (!best || score > best._score) {
                g._score = score;
                best = g;
            }
        }
        return best;
    }

    function geoSearchOrder() {
        return ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];
    }

    function assessAllResources() {
        var inst = pbcInst();
        var out = [];
        var i, r, row, have, cap;
        var list = geoSearchOrder();
        for (i = 0; i < list.length; i++) {
            r = list[i];
            have = depositCountFor(r);
            cap = policyCap(r);
            row = { resourceType: r, have: have, cap: cap };
            if (inst && inst.assess) {
                row.assess = inst.assess(r);
            } else if (!SEARCH_CODES[r]) {
                row.assess = { ok: false, reason: "unknown-resource" };
            } else if (have >= cap) {
                row.assess = { ok: false, reason: "at-cap" };
            } else if (!pickGeoFor(r)) {
                row.assess = { ok: false, reason: "no-idle-geologist" };
            } else {
                row.assess = { ok: true };
            }
            out.push(row);
        }
        return out;
    }

    function firstUnderCap() {
        var rows = assessAllResources();
        var i;
        for (i = 0; i < rows.length; i++) {
            if (rows[i].assess && rows[i].assess.ok) return rows[i].resourceType;
        }
        return "";
    }

    function geoRosterText() {
        var all = listGeologists();
        var idle = [];
        var busy = [];
        var i, g, line;
        for (i = 0; i < all.length; i++) {
            g = all[i];
            line = g.typeName + (g.name ? " (" + g.name + ")" : "") +
                (g.idle ? " idle" : " busy " + (g.remaining || "?")) +
                " bronze~" + g.bronzePredict;
            if (g.idle) idle.push(line);
            else busy.push(line);
        }
        var pref = pickBronzeGeo();
        var prefLine = pref ? (pref.typeName + " score " + pref.bronzeScore + " ~" + pref.bronzePredict) : "none idle";
        return {
            preferred: prefLine,
            idleCount: idle.length,
            idle: idle,
            busy: busy
        };
    }

    var sendQ = [];
    var sending = false;
    var lastActionAt = 0;   // 0.2.56
    function quiet(now) {   // 0.2.56: home, no hold, nothing queued or sending, no blue task, no server action for 20 s
        now = now || Date.now();
        if (visitHeld() || !rawHome()) return false;
        if (sending || sendQ.length || blueTask.current) return false;
        return now - lastActionAt >= 20000;
    }
    /* 0.2.56: the blue manager — the task list of implementation work, and when there is time for what */
    var blueTask = { list: [], current: null, last: {} };
    function blueFact(act, t, extra) { try { var o = { tk: "TK-BLUE", act: act, actor: act === "request" || act === "accept" ? (t.by || "requester") : "blue manager", caseId: t.kind + "#" + t.at, kind: t.kind, by: t.by }, k; for (k in (extra || {})) o[k] = extra[k]; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {} }   // 0.2.73: a case per task
    function blueSubmit(kind, by, start, opts) {
        kind = String(kind); opts = opts || {};
        if (blueTask.current && blueTask.current.kind === kind) return { fact: "pm", reason: "running" };
        for (var i = 0; i < blueTask.list.length; i++) if (blueTask.list[i].kind === kind) return { fact: "pm", reason: "already on the list", position: i + 1 };
        var t = { kind: kind, by: String(by || ""), start: start, maxMs: Number(opts.maxMs) > 0 ? Number(opts.maxMs) : 120000, at: Date.now() };
        blueTask.list.push(t); blueFact("request", t);
        return { fact: "pm", reason: "at the next quiet moment", position: blueTask.list.length };
    }
    function blueDone(t, why) {
        if (blueTask.current !== t) return false;
        blueTask.current = null; blueTask.last[t.kind] = { at: Date.now(), by: t.by, ended: String(why || "done"), sec: Math.round((Date.now() - t.startedAt) / 1000) };
        blueFact("declare", t, { ended: String(why || "done") });
        blueFact("accept", t, { tacit: true });   // 0.2.73: the submitter accepts (tacit)
        return true;
    }
    function blueTick(now) {
        now = now || Date.now();
        var c = blueTask.current;
        if (c) { if (now - c.startedAt >= c.maxMs) blueDone(c, "time limit"); return c ? "running " + c.kind : ""; }
        if (!blueTask.list.length || !quiet(now)) return "";
        var t = blueTask.list.shift(); t.startedAt = now; blueTask.current = t; blueFact("promise", t);
        try { t.start(function (why) { blueDone(t, why); }); } catch (e) { log("blue task " + t.kind + " " + e); blueDone(t, "error"); }
        return "started " + t.kind;
    }
    function enqueue(kind, run) {
        sendQ.push({ kind: kind, run: run });
        if (sendQ.length === 1) log("send queue " + kind + " waiting " + sendQ.length);
        return { ok: true, fact: "queued", queue: sendQ.length };
    }
    function pump() {
        if (sending || !sendQ.length) return;
        if (visitHeld()) return;   // 0.2.51: queued commands wait for the visit to close
        if (blueTask.current) return;   // 0.2.56: a blue task has the client to itself
        var job = sendQ.shift();
        sending = true;
        try { job.run(); } catch (e) { log("send queue " + e); }
        sending = false;
        if (sendQ.length) log("send queue left " + sendQ.length);
    }
    if (typeof setInterval === "function") setInterval(pump, 2500);

    function predictSearch(resource) {
        var all = listGeologists(), i, v, best = 0, vals = [];
        for (i = 0; i < all.length; i++) {
            v = specPredictedSeconds(all[i].raw, resource);
            if (!v) continue;
            vals.push(v);
            if (all[i].idle && (!best || v < best)) best = v;
        }
        vals.sort(function (a, b) { return a - b; });
        return { idleBest: best || null, median: vals.length ? vals[Math.floor(vals.length / 2)] : null, samples: vals.length };
    }

    /* 0.2.39: the player is on his own island (commands go to the zone being viewed) */
    function atHome() { if (visitHeld()) return false; try { var g = game.gi; if (g && typeof g.isOnHomzone === "function") return !!g.isOnHomzone(); } catch (_) {} return true; }   // 0.2.51: a visit hold counts as away

    /* 0.2.51 (ADR 0030): VISIT HOLD — a blue transaction that asks the game to load another island first requests the hold.
       While it holds, ALL blue work on the home island waits: the island scan, every queued server command, the
       self-starters' cycle (they see atHome() false), mail and quest. It is released by visit.close(), or by itself when
       the player has been home again for location.scan.resumeSec after having left, or after location.visit.maxMin. */
    var hold = { on: false, by: "", why: "", at: 0, leftHome: false, homeAt: 0 };
    function rawHome() { try { var g = game.gi; if (g && typeof g.isOnHomzone === "function") return !!g.isOnHomzone(); } catch (_) {} return true; }
    function visitFact(act, d) { try { var o = d || {}; o.tk = "TK-VISIT"; o.act = act; o.actor = "location manager"; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", o); } catch (_) {} log("visit " + act); }
    function zoneDataPresent() { try { var g = game.gi; return !!(g && g.mCurrentPlayerZone && g.mCurrentPlayerZone.mStreetDataMap); } catch (_) { return false; } }
    function visitHeld() {
        if (!hold.on) return false;
        var now = Date.now(), home = rawHome();
        if (hold.by === "startup") {   // 0.2.54: the home island loading at start
            if (home && zoneDataPresent() && now - hold.at >= (Number(polVal("location.startup.holdSec", 180)) || 0) * 1000) { releaseVisit("home island loaded"); return false; }
            return true;
        }
        if (!home) { hold.leftHome = true; hold.homeAt = 0; }
        else if (hold.leftHome || (hold.by === "location manager" && homeSettled())) {   // 0.2.65: an auto hold that never left home (zone loading / viewed zone) ends once home is settled
            if (!hold.homeAt) hold.homeAt = now;
            if (now - hold.homeAt >= (Number(polVal("location.scan.resumeSec", 60)) || 0) * 1000) { releaseVisit("home again"); return false; }
        }
        if (now - hold.at >= (Number(polVal("location.visit.maxMin", 120)) || 120) * 60000) { releaseVisit("time limit"); return false; }
        return true;
    }
    function homeSettled() {
        try { var gi = game.gi, v = gi.mCurrentViewedZoneID, h = homeZoneId(); return rawHome() !== false && !zoneLoading(gi) && zoneDataPresent() && v != null && h != null && String(v) === String(h); } catch (_) { return false; }
    }
    function requestVisit(by, why) {
        if (!hold.on) { hold = { on: true, by: String(by || "player"), why: String(why || ""), at: Date.now(), leftHome: false, homeAt: 0 }; visitFact("hold requested", { by: hold.by, why: hold.why }); }
        return { fact: "pm", hold: JSON.parse(JSON.stringify(hold)) };
    }
    function releaseVisit(why) { if (!hold.on) return { fact: "dc", reason: "no hold" }; var was = hold; hold = { on: false, by: "", why: "", at: 0, leftHome: false, homeAt: 0 }; visitFact("hold released", { why: String(why || "closed"), heldSec: Math.round((Date.now() - was.at) / 1000) }); return { fact: "ac" }; }
    /* 0.2.53: whoever travels, the hold is requested automatically (rule location.visit.auto). */
    function homeZoneId() { try { var g = game.gi; if (g && g.mCurrentPlayer && typeof g.mCurrentPlayer.GetHomeZoneId === "function") return g.mCurrentPlayer.GetHomeZoneId(); } catch (_) {} return null; }
    function travelWatch() {
        if (hold.on) { visitHeld(); return hold.on ? "held" : "released"; }
        if (polVal("location.visit.auto", true) === false) return "";
        var gi = null; try { gi = game.gi; } catch (_) {}
        if (!gi) return "";
        var why = "";
        if (rawHome() === false) why = "on another island";
        else if (zoneLoading(gi)) why = "a zone is loading";
        else {
            var v = null, h = homeZoneId(); try { v = gi.mCurrentViewedZoneID; } catch (_) {}
            if (v != null && h != null && String(v) !== String(h)) why = "the viewed zone is not the home zone";
        }
        if (!why) return "";
        requestVisit("location manager", "auto: " + why);
        return why;
    }
    /* 0.2.107 (ADR 0074 step 4): AR11's observed declare of a search, and the hold after a refusal (moved from green 0.9.x) */
    var searchRefused = {};
    function searchBackoffMs(n) { return Math.min(4 * 3600000, 30 * 60000 * Math.pow(2, Math.max(0, n - 1))); }
    function searchHeld(r, now) { var x = searchRefused[r]; return x && (now || Date.now()) - x.at < searchBackoffMs(x.n) ? { n: x.n, at: x.at, holdMs: searchBackoffMs(x.n) } : null; }
    function tk11Fact(act, search, extra) {
        var o = { tk: "TK11", act: act, search: search }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k) && extra[k] != null) o[k] = extra[k];
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {}
    }
    function verifySearch(r, geoId, geoName, sid) {
        var later = typeof root.setTimeout === "function" ? root.setTimeout : setTimeout;
        later(function () {
            try {
                var g = listGeologists().filter(function (x) { return x && String(x.id) === String(geoId); })[0];
                if (!g) return;
                if (g.idle) {
                    var x = searchRefused[r] || { n: 0 }; x.n += 1; x.at = Date.now(); searchRefused[r] = x;
                    log("search " + r + " refused by the game (" + x.n + "x); hold " + Math.round(searchBackoffMs(x.n) / 60000) + " min");
                    tk11Fact("decline", sid, { actor: "game (observed)", resource: r, geoName: geoName, reason: "the game did not start the search (geologist idle after 30 s)", refusals: x.n, holdMin: Math.round(searchBackoffMs(x.n) / 60000) });
                } else {
                    if (searchRefused[r]) delete searchRefused[r];
                    tk11Fact("promise", sid, { actor: "game (observed)", resource: r, geo: geoId, geoName: geoName });
                }
            } catch (e) { log("verify search " + e); }
        }, 30000);
    }
    function sendSearch(resource, fromBlue, opts) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        opts = opts || {};
        if (!sending && !fromBlue) return enqueue("search", function () { sendSearch(resource, true, opts); });
        var cap = 0;
        try {
            var polS = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
            if (polS && polS.get) cap = Number(polS.get("location.caps." + resource)) || 0;
        } catch (_) {}
        if (!cap) cap = policyCap(resource);
        var have = 0;
        var mines = 0;
        try {
            var mem = (typeof DMA_Demo !== "undefined" && DMA_Demo.memory) ? DMA_Demo.memory() : null;
            var slots = (mem && mem.slots) || [];
            var si;
            for (si = 0; si < slots.length; si++) {
                if (slots[si].resource !== resource) continue;
                if (slots[si].depleted) continue;
                if (slots[si].mine || /mine|mason|quarry/i.test(String(slots[si].name || ""))) mines += 1;
                else have += 1;
            }
        } catch (_) {}
        if (!have && !mines) have = depositCountFor(resource);
        var dep = depletedCountFor(resource);
        var code = SEARCH_CODES[resource];
        if (!code) return { ok: false, error: "no search code" };
        var covered = mines + have;
        if (!opts.replacement && covered >= cap && dep === 0) return { ok: false, error: resource + " covered " + mines + "m+" + have + "f/" + cap };

        var picked = null;
        if (opts.geoId != null) {   // 0.2.114 (ADR 0084): the workflow's own allocated geologist, exactly that one
            var allG = listGeologists(), gi0;
            for (gi0 = 0; gi0 < allG.length; gi0++) if (String(allG[gi0].id) === String(opts.geoId)) picked = allG[gi0];
            if (!picked) return { ok: false, error: "geologist " + opts.geoId + " not listed" };
            if (!picked.idle) return { ok: false, error: "geologist " + opts.geoId + " is not idle" };
        } else picked = pickGeoFor(resource, !!opts.luckyFind);
        if (!picked) return { ok: false, error: opts.luckyFind ? "no idle geologist with Lucky Find" : "no idle geologist" };
        var typeName = String(picked.typeName || picked.name || "");
        if (!/geologist/i.test(typeName)) {
            return { ok: false, error: "not a geologist: " + typeName, resource: resource };
        }
        reserveGeo(picked.id);

        var geo = picked.raw;
        var dot = picked.id || specDotId(geo);
        if (!dot) return { ok: false, error: "no specialist id" };

        var parts = String(code).split(",");
        var a = parseInt(parts[0], 10);
        var b = parseInt(parts[1], 10);

        permit("specialist", true);
        var used = "";
        try {
            if (typeof sendSpecPacket === "function") {
                sendSpecPacket(dot, code);
                used = "sendSpecPacket";
            } else {
                var gi = (typeof game !== "undefined" && game.gi) ? game.gi : swmmo.application.mGameInterface;
                var uid = null;
                try { uid = geo.GetUniqueID(); } catch (_) {}
                var rSp = viaAdapter("SPECIALIST_TASK", 1, a, b, uid);   // 0.2.101 (ADR 0073)
                if (!rSp.ok) { permit("specialist", false); return { ok: false, error: rSp.reason, reason: rSp.reason }; }
                used = "SendServerAction95";
            }
        } catch (e) {
            permit("specialist", false);
            return { ok: false, error: String(e) };
        }
        permit("specialist", false);

        bronzeState.lastSendAt = Date.now();
        bronzeState.sent += 1;
        bronzeState.lastResult = {
            ok: true,
            resource: resource,
            code: code,
            via: used,
            geo: dot,
            geoName: picked.typeName,
            bronzePredict: picked.bronzePredict,
            have: have,
            mines: mines,
            covered: covered,
            cap: cap
        };
        try {
            // 0.2.40: no in-game alert per send (the log keeps it)
        } catch (_) {}
        log("search send " + typeName + " " + resource + " via " + used + (picked._lucky ? " lucky-find" : ""));
        try {
            if (!root._dmaSearchTrack) root._dmaSearchTrack = {};
            root._dmaSearchTrack[picked.id] = { resource: resource, name: typeName, start: Date.now(), lucky: !!picked._lucky };
        } catch (_) {}
        return bronzeState.lastResult;
    }

    function checkSearchReturns() {
        if (visitHeld()) return;   // 0.2.52 (ADR 0030)
        var track = root._dmaSearchTrack;
        if (!track) return;
        var list = listGeologists();
        var i, g, t, dur;
        for (i = 0; i < list.length; i++) {
            g = list[i];
            if (!g || !g.id || !track[g.id]) continue;
            if (!g.idle) continue;
            t = track[g.id];
            dur = Math.round((Date.now() - t.start) / 60000);
            log("search return " + t.name + " " + t.resource + " " + dur + "min" + (t.lucky ? " LF" : ""));
            delete track[g.id];
        }
    }
    if (typeof setInterval === "function") setInterval(checkSearchReturns, 10000);

    function maybeBronzeTick() {
        try {
            scan();
            if (!map.home) return;
            if (Date.now() - bronzeState.lastSendAt < 90000) return;
            sendSearch("BronzeOre");
        } catch (_) {}
    }

    var BUILD_TYPE = {
        BronzeOre: 36, Coal: 37, GoldOre: 46, IronOre: 50, TitaniumOre: 69, Salpeter: 63
    };

    var BUILD_COSTS = {
        Stone: { Plank: 40 },
        BronzeOre: { Plank: 30, Stone: 45 },
        Marble: { HardwoodPlank: 120, Stone: 150, Tool: 100 },
        IronOre: { HardwoodPlank: 250, Marble: 250, Tool: 200 },
        GoldOre: { HardwoodPlank: 1400, Marble: 1400, Tool: 1500 },
        Coal: { HardwoodPlank: 200, Marble: 200, Tool: 150 },
        Granite: { MahoganyPlank: 1500, Marble: 1500, Tool: 1500 },
        TitaniumOre: { ExoticWoodPlank: 2000, Granite: 2000, Tool: 1500 },
        Salpeter: { ExoticWoodPlank: 2000, Granite: 2000, Tool: 1500 }
    };
    var QTY_ALIAS = {
        HardwoodPlank: ["HardwoodPlank", "RealPlank"],
        ExoticWoodPlank: ["ExoticWoodPlank", "ExoticPlank"],
        Plank: ["Plank", "PinewoodPlank"],
        Tool: ["Tool", "Tools"],
        MahoganyPlank: ["MahoganyPlank", "Mahogany"]
    };
    var localAlloc = {};
    function liveQty(id) {
        var names = QTY_ALIAS[id] ? QTY_ALIAS[id].concat([id]) : [id];
        var i, n = 0, bag = null;
        try { if (typeof game !== "undefined" && game.getResources) bag = game.getResources(); } catch (_) {}
        for (i = 0; i < names.length; i++) {
            try { if (bag && bag.GetResourceAmount) n = Math.max(n, Number(bag.GetResourceAmount(names[i]) || 0)); } catch (_) {}
        }
        try {
            var res = (typeof GCAF_ResourceManagementInstance !== "undefined") ? GCAF_ResourceManagementInstance : null;
            if (res && res.getStockQuantity) n = Math.max(n, Number(res.getStockQuantity(id) || 0));
        } catch (_) {}
        return n;
    }
    /* 0.2.45: materials held by mine orders that wait in the build queue (not started: the game has not taken them) */
    function queuedBuildNeeds() {
        var out = {};
        try {
            var gi = (typeof game !== "undefined" && game.gi) ? game.gi : null;
            var player = gi && (gi.mHomePlayer || gi.mCurrentPlayer);
            var bq = player && player.mBuildQueue;
            var vec = bq && typeof bq.GetQueue_vector === "function" ? bq.GetQueue_vector() : null;
            if (!vec || typeof vec.forEach !== "function") return out;
            vec.forEach(function (item) {
                if (!item) return;
                var pct = safeCall(item, "GetProgress", safeCall(item, "GetBuildProgress", null));
                if (pct != null && Number(pct) > 0) return;                    // started: the game has taken the materials
                var k = kindOf(itemName(item));
                if (!k) {   // the queue item may not carry the name; the construction site on its grid does
                    var g = safeCall(item, "GetGrid", safeCall(item, "GetGridPosition", null));
                    if (g != null) k = kindOf(nameOf(buildingAt(g)));
                }
                var costs = k && k.resource ? BUILD_COSTS[k.resource] : null;
                if (!costs) return;
                for (var c in costs) if (costs.hasOwnProperty(c)) out[c] = Number(out[c] || 0) + Number(costs[c] || 0);
            });
        } catch (_) {}
        return out;
    }
    function availableQty(id) {
        var held = Number(localAlloc[id] || 0);
        try { held += Number(queuedBuildNeeds()[id] || 0); } catch (_) {}   // 0.2.45
        try {
            var res = (typeof GCAF_ResourceManagementInstance !== "undefined") ? GCAF_ResourceManagementInstance : null;
            if (res && res.getAllocatedQuantity) held = Math.max(held, Number(res.getAllocatedQuantity(id) || 0));
        } catch (_) {}
        return Math.max(0, liveQty(id) - held);
    }
    function promiseBuildResources(resource) {
        var costs = BUILD_COSTS[resource];
        if (!costs) return { fact: "dc", reason: "no-cost-table" };
        var needs = {}, k;
        for (k in costs) {
            if (!costs.hasOwnProperty(k)) continue;
            needs[k] = costs[k];
        }
        var res = null, pre;
        for (pre in needs) {   // 0.2.45: whatever path allocates, stock held by waiting queue orders is not free
            if (!needs.hasOwnProperty(pre)) continue;
            if (availableQty(pre) < Number(needs[pre] || 0)) return { fact: "wait", reason: "no-resources", missing: pre, have: availableQty(pre), need: Number(needs[pre] || 0), via: "queue" };
        }
        try { res = (typeof GCAF_ResourceManagementInstance !== "undefined") ? GCAF_ResourceManagementInstance : null; } catch (_) {}
        if (res && typeof res.requestAllocations === "function") {
            var alloc = res.requestAllocations(needs);
            if (!alloc || alloc.fact !== "pm") {
                return { fact: "wait", reason: "no-resources", missing: alloc && alloc.missing, have: alloc && alloc.have, need: alloc && alloc.need, costs: alloc && alloc.costs, via: "pbc" };
            }
            return {
                fact: "pm", needs: needs, via: "pbc",
                release: function () { try { res.releaseAllocations(needs); } catch (_) {} }
            };
        }
        var snap = {}, n, have;
        for (k in needs) {
            if (!needs.hasOwnProperty(k)) continue;
            n = Number(needs[k] || 0);
            have = availableQty(k);
            snap[k] = { need: n, have: have };
            if (have < n) return { fact: "wait", reason: "no-resources", missing: k, have: have, need: n, costs: snap, via: "live" };
        }
        for (k in needs) {
            if (!needs.hasOwnProperty(k)) continue;
            localAlloc[k] = Number(localAlloc[k] || 0) + Number(needs[k] || 0);
        }
        return {
            fact: "pm", needs: needs, costs: snap, via: "live",
            release: function () {
                var rk;
                for (rk in needs) {
                    if (!needs.hasOwnProperty(rk)) continue;
                    localAlloc[rk] = Math.max(0, Number(localAlloc[rk] || 0) - Number(needs[rk] || 0));
                }
            }
        };
    }
    /* ---------- 0.2.98 (v3.17, ADR 0072): material allocating (TK60) for a troop order; TK64 when short ---------- */
    var allocations = {}, allocN = 0, ALLOCATOR = "material allocator", PRODUCER = "resource producer";
    function allocFact(tk, act, o) {
        try { var d = { tk: tk, act: act }, k; for (k in o) if (o.hasOwnProperty(k)) d[k] = o[k]; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", d); } catch (_) {}
    }
    function lackOf(needs) {
        var out = {}, k, n = 0;
        for (k in needs) if (needs.hasOwnProperty(k)) { var want = Number(needs[k] || 0), have = availableQty(k); if (have < want) { out[k] = want - have; n += 1; } }
        return n ? out : null;
    }
    function setAside(a) { var k; for (k in a.needs) if (a.needs.hasOwnProperty(k)) localAlloc[k] = Number(localAlloc[k] || 0) + Number(a.needs[k] || 0); a.held = true; }
    function declareAlloc(a) {
        setAside(a); a.state = "declared";
        allocFact("TK60", "execute", { caseId: a.id, actor: ALLOCATOR, needs: a.needs });
        allocFact("TK60", "declare", { caseId: a.id, actor: ALLOCATOR, needs: a.needs, troopOrder: a.troopOrder || null });
        withdrawBatches(a, "covered from stock");   // 0.2.99: not declared "produced" — nobody saw it produced
    }
    /* 0.2.99: withdraw the open batches of an allocation (revoke request -> allow) */
    function withdrawBatches(a, why) {
        var n = 0;
        Object.keys(a.batches || {}).forEach(function (r) {
            var b = a.batches[r]; if (b.state !== "requested") return;
            allocFact("TK64", "revoke request", { caseId: b.id, actor: ALLOCATOR, resource: r, amount: b.amount, reason: why });
            allocFact("TK64", "allow", { caseId: b.id, actor: PRODUCER + " (player, tacit)", resource: r, amount: b.amount });
            b.state = "withdrawn"; b.why = why; n += 1;
        });
        if (n) writeBatchNotice();
        return n;
    }
    /* 0.2.99: the player holds AR64 — every open batch is a notice for him */
    function openBatches() {
        var out = [];
        Object.keys(allocations).forEach(function (id) { var a = allocations[id]; Object.keys(a.batches || {}).forEach(function (r) { var b = a.batches[r]; if (b.state === "requested") out.push({ id: b.id, resource: r, amount: b.amount, since: new Date(b.at || a.at).toISOString() }); }); });
        return out;
    }
    function writeBatchNotice() {
        try { var A = (typeof air !== "undefined") ? air : root.air, f = new A.File(A.File.applicationDirectory.resolvePath("dma-production-requests.json").nativePath), st = new A.FileStream();
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify({ format: "dma-production-requests/1", version: VERSION, at: new Date().toISOString(),
                  note: "You hold the resource producer role (AR64): DMA asks you to make these batches; it withdraws a batch once the stock covers it.", open: openBatches() }, null, 1)); st.close(); } catch (_) {}
    }
    /* ARS-60-03 (legacy asking, until AR66 does it): what it lacks is produced - a batch with a resource and an amount only (T-4) */
    function askMaking(a, lack) {
        Object.keys(lack).forEach(function (r) {
            var open = a.batches[r] && a.batches[r].state === "requested"; if (open) return;
            var b = a.batches[r] = { id: "batch@" + r + "@" + Date.now() + "#" + allocN, amount: Math.ceil(lack[r]), state: "requested" };
            allocFact("TK64", "request", { caseId: b.id, actor: ALLOCATOR, resource: r, amount: b.amount, executor: PRODUCER, heldBy: "player (APT: no module yet)" });
            b.at = Date.now();
            try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "production batch for the player", tk: "TK64", caseId: b.id, resource: r, amount: b.amount, notice: true }); } catch (_) {}   // 0.2.99
        });
    }
    function supplyReady() { try { var S = root.DMA_SupplyManager; return !!(S && S.ready); } catch (_) { return false; } }   // 0.2.108
    function allocate(m) {
        m = m || {};
        var id = String(m.id || ""), by = String(m.by || ""), needs = {}, k;
        if (!id) return { fact: "dc", reason: "no material id" };
        if (allocations[id]) { recheck(); return allocView(allocations[id]); }
        for (k in (m.needs || {})) if (m.needs.hasOwnProperty(k) && Number(m.needs[k]) > 0) needs[k] = Number(m.needs[k]);
        if (!/^(troop order trainer|construction upgrader)/.test(by)) {   // ARS-60-02 rightness
            allocFact("TK60", "decline", { caseId: id, actor: ALLOCATOR, reason: "the requester is not a construction upgrader or a troop order trainer" });
            return { fact: "dc", reason: "requester" };
        }
        if (!Object.keys(needs).length) { allocFact("TK60", "decline", { caseId: id, actor: ALLOCATOR, reason: "no amounts" }); return { fact: "dc", reason: "no amounts" }; }
        var a = allocations[id] = { id: id, needs: needs, by: by, troopOrder: m.troopOrder || null, construction: m.construction || null, state: "promised", at: Date.now(), batches: {}, held: false };
        allocN += 1;
        allocFact("TK60", "promise", { caseId: id, actor: ALLOCATOR, needs: needs, troopOrder: a.troopOrder });
        var lack = lackOf(needs);
        if (!lack) { declareAlloc(a); return allocView(a); }
        if (supplyReady()) { a.lacking = lack; return allocView(a); }   // 0.2.108: AR66 requests the making (TK64); AR60 sets aside only what is in stock
        askMaking(a, lack);
        writeBatchNotice();   // 0.2.99
        a.lacking = lack;
        return allocView(a);
    }
    function recheck() {
        var n = 0;
        Object.keys(allocations).forEach(function (id) { var a = allocations[id]; if (a.state !== "promised") return; var l = lackOf(a.needs); if (!l) { declareAlloc(a); a.lacking = null; n += 1; } else if (!supplyReady()) { askMaking(a, l); a.lacking = l; writeBatchNotice(); } });   // 0.2.109: take the asking back when AR66 is not ready
        return n;
    }
    function releaseAlloc(id, why) {
        var a = allocations[id]; if (!a) return false;
        if (a.held) { var k; for (k in a.needs) if (a.needs.hasOwnProperty(k)) localAlloc[k] = Math.max(0, Number(localAlloc[k] || 0) - Number(a.needs[k] || 0)); }
        withdrawBatches(a, "allocation released");   // 0.2.99
        if (why && a.state !== "declared") allocFact("TK60", "allow", { caseId: id, actor: ALLOCATOR, reason: String(why) });   // a revoked request
        delete allocations[id];
        return true;
    }
    function allocView(a) { return a ? JSON.parse(JSON.stringify({ fact: a.state === "declared" ? "da" : "pm", id: a.id, state: a.state, needs: a.needs, lacking: a.lacking || null, batches: a.batches })) : null; }
    var recentBuildGrids = {};
    var BUILD_LOST_MS = 10 * 60000, BUILD_SKIP_MS = 120 * 60000, buildLost = {};   // 0.2.59
    var BUILD_CONFIRM_MS = 90000;   // 0.2.76: a build order the game does not show yet holds a slot (0.2.77: builds only)
    function shownByGame(k, grids) {   // in the queue, or a building on the grid
        if (grids && grids[k]) return true;
        var b = null;
        try { b = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(k)); } catch (_) {}
        return !!b;
    }
    function inFlight(grids) {   // build orders sent < 90 s ago that the game does not show yet
        var out = [], k, now = Date.now();
        for (k in recentBuildGrids) {
            if (!recentBuildGrids.hasOwnProperty(k)) continue;
            var r = recentBuildGrids[k];
            if (r && r.at && now - r.at < BUILD_CONFIRM_MS && !shownByGame(k, grids)) out.push({ kind: "build", grid: k, at: r.at });
        }
        return out;
    }
    function waitForPrevious(grid) {   // 0.2.76: one by one — the previous order must be seen first
        var f = [];
        try { f = inFlight(queueNow().grids); } catch (_) {}
        if (!f.length) return null;
        return { ok: false, fact: "wait", reason: "previous order not confirmed", previous: f[0].kind + "@" + f[0].grid, grid: grid };
    }
    function buildFact(what, grid, d) { try { var o = d || {}; o.tk = "TK21"; o.what = what; o.actor = "build manager"; o.grid = String(grid); if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("i", o); } catch (_) {} log("build " + what + " @" + grid); }   // 0.2.73: information, not a coordination act
    function gridSkipped(grid) { var l = buildLost[String(grid)]; return !!(l && l.n >= 2 && Date.now() - l.at < BUILD_SKIP_MS); }
    function buildOrder(grid) {
        var rec = recentBuildGrids[String(grid)];
        if (!rec) return null;
        var q = null;
        try { q = queueNow(); } catch (_) {}
        var inQueue = !!(q && q.grids && q.grids[String(grid)]);
        var mine = false;
        try {
            var bld = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(grid));
            mine = !!(bld && /mine|mason|GraniteMason/i.test(String(bld.GetBuildingName_string ? bld.GetBuildingName_string() : "")));
        } catch (_) {}
        return {
            grid: String(grid),
            resource: rec.resource || "",
            fact: rec.fact || "ex",
            reason: rec.reason || "",
            inQueue: inQueue,
            mine: mine
        };
    }
    function retractBuild(grid, reason) {
        var key = String(grid);
        if (!recentBuildGrids[key]) return false;
        delete recentBuildGrids[key];
        log("retract build @" + key + " " + (reason || ""));
        return true;
    }
    function queueNow() {
        var out = { free: null, slots: null, used: 0, grids: {} };
        try {
            var gi = (typeof game !== "undefined" && game.gi) ? game.gi : null;
            var player = gi && (gi.mHomePlayer || gi.mCurrentPlayer);
            var bq = player && player.mBuildQueue;
            if (!bq) throw "no build queue";   // 0.2.76: still count orders in flight (below)
            try { if (typeof bq.GetMaximumQueueSize === "function") out.slots = bq.GetMaximumQueueSize(); } catch (_) {}
            try { if (out.slots == null && typeof bq.GetTotalSlots === "function") out.slots = bq.GetTotalSlots(); } catch (_) {}
            try { if (typeof bq.GetTotalAvailableSlots === "function") out.free = bq.GetTotalAvailableSlots(); } catch (_) {}
            try { if (out.free == null && typeof bq.GetAvailableSlots === "function") out.free = bq.GetAvailableSlots(); } catch (_) {}
            var vec = null;
            try { if (typeof bq.GetQueue_vector === "function") vec = bq.GetQueue_vector(); } catch (_) {}
            if (vec && typeof vec.forEach === "function") {
                vec.forEach(function (item) {
                    if (!item) return;
                    var g = safeCall(item, "GetGrid", safeCall(item, "GetGridPosition", null));
                    if (g != null) out.grids[String(g)] = true;
                    out.used += 1;
                });
            }
            if (out.free == null && out.slots != null) out.free = Math.max(0, Number(out.slots) - out.used);
        } catch (_) {}
        var extra = 0, k;
        for (k in recentBuildGrids) {
            if (!recentBuildGrids.hasOwnProperty(k)) continue;
            if (!out.grids[k]) {
                var bld = null;
                try { bld = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(k)); } catch (_) {}
                if (bld && /mine|mason/i.test(String(bld.GetBuildingName_string ? bld.GetBuildingName_string() : ""))) { delete recentBuildGrids[k]; delete buildLost[k]; continue; }
                var rec0 = recentBuildGrids[k];   // 0.2.59: sent, not queued, no mine after 10 min -> lost
                if (rec0 && rec0.at && Date.now() - rec0.at >= BUILD_LOST_MS) {
                    delete recentBuildGrids[k];
                    var l0 = buildLost[k] || { n: 0, at: 0 }; l0.n += 1; l0.at = Date.now(); buildLost[k] = l0;
                    buildFact("lost", k, { resource: rec0.resource, reason: "not in the build queue and no mine " + Math.round((Date.now() - rec0.at) / 60000) + " min after the order", times: l0.n });
                    if (l0.n >= 2) buildFact("skipped", k, { resource: rec0.resource, reason: "lost twice: this grid is skipped for " + (BUILD_SKIP_MS / 60000) + " min" });
                }
            }
        }
        try { extra = inFlight(out.grids).length; } catch (_) { extra = 0; }   // 0.2.76; 0.2.77: upgrades take no slot
        out.inFlight = extra;
        out.used += extra;
        if (out.free != null) out.free = Math.max(0, Number(out.free) - extra);
        return out;
    }
    function sendBuild(resourceOrAsg, fromBlue) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        if (!sending && !fromBlue) return enqueue("build", function () { sendBuild(resourceOrAsg, true); });
        var resource = resourceOrAsg;
        var gridForced = null, viaWorkflow = false;
        if (resourceOrAsg && typeof resourceOrAsg === "object") {
            resource = resourceOrAsg.resourceType;
            gridForced = resourceOrAsg.grid;
            viaWorkflow = !!resourceOrAsg.workflow && gridForced != null;   // 0.2.114 (ADR 0084)
        }
        var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
        var allowEx = false;
        try { allowEx = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        if (!allowEx) return { ok: false, error: "execute-off" };
        var auto = true;
        try { auto = !pol || pol.get("building.autoEnabled") !== false; } catch (_) {}
        if (!auto && !viaWorkflow) return { ok: false, error: "build-auto-off" };

        var loc = (typeof GCAF_LocationManagementInstance !== "undefined") ? GCAF_LocationManagementInstance : null;
        try { if (loc && loc.refresh) loc.refresh(); } catch (_) {}
        var free = loc && loc.freeDeposits ? loc.freeDeposits(resource) : [];
        try { var WFb = root.DMA_Workflows; if (WFb && typeof WFb.ownsGrid === "function" && free && free.filter) free = free.filter(function (d) { return !WFb.ownsGrid(d.grid); }); } catch (_) {}   // 0.2.114 (ADR 0084)
        var grid = gridForced;
        if (grid == null) {
            if (!free || !free.length) return { ok: false, error: "no-free-deposit" };
            grid = free[0].grid;
        }
        if (gridSkipped(grid)) return { ok: false, fact: "dc", reason: "grid skipped: two earlier orders were lost", grid: grid };   // 0.2.59
        var recentSend = recentBuildGrids[String(grid)];
        if (recentSend) {
            return { ok: false, fact: "dc", reason: "order already given", grid: grid };
        }
        var wPrev = waitForPrevious(grid); if (wPrev) return wPrev;   // 0.2.76
        var q = queueNow();
        if (q.grids[String(grid)]) return { ok: false, fact: "wait", reason: "queue-full", grid: grid };
        if (q.free != null && Number(q.free) < 1) return { ok: false, fact: "wait", reason: "queue-full", grid: grid, free: q.free };

        var promised = promiseBuildResources(resource);
        if (!promised || promised.fact !== "pm") {
            return {
                ok: false, fact: "wait", reason: "no-resources", grid: grid, resource: resource,
                missing: promised && promised.missing, have: promised && promised.have, need: promised && promised.need,
                costs: promised && promised.costs
            };
        }
        recentBuildGrids[String(grid)] = { resource: resource, fact: "pending", reason: "sending" };

        var typeNr = BUILD_TYPE[resource];
        if (typeNr == null && typeof _DM_mapItemToNumber === "function") {
            try {
                var mapped = _DM_mapItemToNumber(resource);
                if (mapped && mapped.number != null) typeNr = mapped.number;
            } catch (_) {}
        }
        if (typeNr == null) {
            if (promised.release) promised.release();
            return { ok: false, error: "no-build-mapping", grid: grid, resource: resource, costs: promised.needs };
        }

        var gi = null;
        try { gi = game.gi; } catch (_) {}
        if (!gi || typeof gi.SendServerAction !== "function") return { ok: false, error: "no-gi" };

        var rBd = viaAdapter("BUILD", typeNr, grid, 0, null), sent = !!rBd.ok;   // 0.2.101 (ADR 0073)
        if (!sent && promised && promised.release) promised.release();
        if (!sent) delete recentBuildGrids[String(grid)];
        if (sent) {
            recentBuildGrids[String(grid)] = { resource: resource, fact: "ex", reason: "sent", at: Date.now() };   // 0.2.59: at
            if (promised && promised.release) setTimeout(promised.release, 60000);
        }
        // 0.2.40: no in-game alert per construction (the log keeps it)
        log("build " + resource + " @" + grid + " type=" + typeNr + " " + (sent ? "ex" : "dc") + " resources " + ((promised && promised.via) || ""));
        return { ok: sent, fact: sent ? "ex" : "dc", grid: grid, resource: resource, type: typeNr, costs: promised && promised.needs, reason: sent ? undefined : rBd.reason };
    }

    var recentToolUse = { used: 0, until: 0 };
    function toolsLeft() {
        var have = null;
        try {
            var inv = (typeof GCAF_ResourceManagementInstance !== "undefined") ? GCAF_ResourceManagementInstance : null;
            if (inv && inv.getStockQuantity) have = Number(inv.getStockQuantity("Tool") || 0);
        } catch (_) {}
        if (have == null) return null;
        if (Date.now() > recentToolUse.until) recentToolUse.used = 0;
        return Math.max(0, have - recentToolUse.used);
    }
    function noteToolsUsed(n) {
        if (Date.now() > recentToolUse.until) recentToolUse.used = 0;
        recentToolUse.used += Number(n) || 0;
        recentToolUse.until = Date.now() + 20000;
    }
    function toolNeedFor(level) {
        return ({ 1: 50, 2: 150, 3: 300, 4: 500 })[Number(level)] || 50;
    }
    function sendUpgrade(grid, fromBlue) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        if (!sending && !fromBlue) return enqueue("upgrade", function () { sendUpgrade(grid, true); });
        var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
        var allowEx = false;
        try { allowEx = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        if (!allowEx) return { ok: false, error: "execute-off" };
        if (grid == null) return { ok: false, error: "no-grid" };
        grid = Number(grid);
        var callerGrid = grid, sentLevel = 0, sentName = "";   // 0.2.78 (R5)
        var gi = null;
        try { gi = game.gi; } catch (_) {}
        if (!gi || typeof gi.SendServerAction !== "function") return { ok: false, error: "no-gi" };
        var spentTools = 0;
        var whyG = guardUpgrade(grid);                          // 0.2.15: refused before anything else, fail closed
        if (whyG) { refuse("upgrade", whyG); declineUpgrade(grid, whyG); return { ok: false, fact: "dc", error: "safeguard", reason: whyG, grid: grid }; }   // 0.2.95: TK21 decline
        try {
            var zone = game.zone || (gi.mCurrentPlayerZone);
            var bld = zone && zone.GetBuildingFromGridPosition && zone.GetBuildingFromGridPosition(grid);
            if (!bld) return { ok: false, error: "no-building-on-grid", grid: grid };
            var bnm = "";
            try { bnm = bld.GetBuildingName_string ? String(bld.GetBuildingName_string()) : ""; } catch (_) {}
            if (/deposit|destroyable|mountain|depleted/i.test(bnm)) {
                return { ok: false, error: "not-a-mine", name: bnm, grid: grid };
            }
            try {
                if (bld.IsUpgradeInProgress && bld.IsUpgradeInProgress()) {
                    return { ok: false, error: "already-upgrading", name: bnm, grid: grid };
                }
            } catch (_) {}
            var lv = 1;
            lv = levelOf(bld) || 1;                                 // 0.2.19: real level, not the UI overwrite
            var ore = /copper|bronze/i.test(bnm) ? "BronzeOre" : /iron/i.test(bnm) ? "IronOre" : /gold/i.test(bnm) ? "GoldOre" : /coal/i.test(bnm) ? "Coal" : /titanium/i.test(bnm) ? "TitaniumOre" : /salpeter|saltpeter/i.test(bnm) ? "Salpeter" : /marble/i.test(bnm) ? "Marble" : /granite/i.test(bnm) ? "Granite" : /stone|mason/i.test(bnm) ? "Stone" : "";
            var max = 0;   // 0.2.112 (UAT F2): no target set = no target; the fallback 2 (3 for titanium) is gone
            try {
                if (pol && ore) {
                    max = Number(pol.get("upg." + ore)) || Number(pol.get("building.upgradeLevel." + ore)) || 0;
                }
            } catch (_) {}
            if (!max || max < 1) return { ok: false, error: "no-target", reason: "no upgrade target set for " + (ore || bnm), level: lv, name: bnm, grid: grid };
            if (lv >= max) return { ok: false, error: "at-max", level: lv, max: max, name: bnm, grid: grid };
            var needTools = toolNeedFor(lv);
            spentTools = needTools;
            var leftTools = toolsLeft();
            if (leftTools != null && leftTools < needTools) {
                return { ok: false, fact: "wait", reason: "no-tools", have: leftTools, need: needTools, grid: grid };
            }
            sentLevel = lv; sentName = bnm;                         // 0.2.78: what the ledger records
            if (bld && bld.GetGrid) grid = bld.GetGrid();
            try { log("upgrade send " + bnm + " @" + grid + " (queue not required)"); } catch (_) {}
        } catch (eU) { return { ok: false, fact: "dc", error: "upgrade check failed: " + eU, grid: grid }; }   // 0.2.78: fail closed
        if (!(sentLevel >= 1)) return { ok: false, fact: "dc", error: "level not read before the send", grid: grid };   // 0.2.78
        var rUp = viaAdapter("UPGRADE_BUILDING", 0, grid, 0, null), sent = !!rUp.ok;   // 0.2.101 (ADR 0073)
        if (sent) { try { ledgerPut(grid, sentLevel, sentName, callerGrid); } catch (eL) { ledgerBroken = String(eL); log("upgrade ledger " + eL); } }   // 0.2.75; 0.2.78: the level and name read before the send, both grids, fail closed
        if (sent && spentTools) noteToolsUsed(spentTools);
        log("upgrade @" + grid + " " + (sent ? "ex" : "dc"));
        return { ok: sent, fact: sent ? "ex" : "dc", grid: grid, reason: sent ? undefined : rUp.reason };
    }



    function normBuff(s) {
        return String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    }
    function resolveBuff(want) {
        var have = [];
        var map = {};
        try { if (typeof DM_refreshBuffInventory === "function") DM_refreshBuffInventory(); } catch (_) {}
        try {
            if (typeof DM_buffsAvailable === "object" && DM_buffsAvailable) {
                var k;
                for (k in DM_buffsAvailable) {
                    if (!DM_buffsAvailable.hasOwnProperty(k)) continue;
                    have.push(k + ":" + (DM_buffsAvailable[k].count || 0));
                    map[normBuff(k)] = { name: k, id: DM_buffsAvailable[k].id, count: DM_buffsAvailable[k].count };
                }
            }
        } catch (_) {}
        try {
            var vec = game.gi.mCurrentPlayer.getAvailableBuffs_vector();
            var i;
            for (i = 0; vec && i < vec.length; i++) {
                var def = vec[i].GetBuffDefinition && vec[i].GetBuffDefinition();
                var nm = def && def.GetName_string && def.GetName_string();
                if (!nm) continue;
                var uid = null;
                try { uid = vec[i].GetUniqueId(); } catch (_) {}
                var id = "";
                try { if (uid) id = uid.uniqueID1 + "_" + uid.uniqueID2; } catch (_) {}
                var amt = 0;
                try { amt = vec[i].GetAmount(); } catch (_) {}
                if (!map[normBuff(nm)]) {
                    have.push(nm + ":" + amt);
                    map[normBuff(nm)] = { name: nm, id: id, uid: uid, count: amt };
                } else if (uid && !map[normBuff(nm)].uid) {
                    map[normBuff(nm)].uid = uid;
                }
            }
        } catch (_) {}
        var w = normBuff(want);
        if (map[w]) return { id: map[w].id, uid: map[w].uid, name: map[w].name, count: map[w].count, have: have };
        var hit = null, nk, prod = null;
        for (nk in map) {
            if (!map.hasOwnProperty(nk)) continue;
            if ((w && nk.indexOf(w) >= 0) || (w && w.indexOf(nk) >= 0)) { hit = map[nk]; break; }
            if (w.indexOf("smoked") >= 0 || w.indexOf("fish") >= 0 || w === "smc") {
                if (nk.indexOf("smoked") >= 0 && nk.indexOf("fish") >= 0) { hit = map[nk]; break; }
                if (!prod && nk.indexOf("productivitybuff") >= 0 && map[nk].count > 0) prod = map[nk];
            }
        }
        if (!hit) hit = prod;
        if (hit) return { id: hit.id, uid: hit.uid, name: hit.name, count: hit.count, have: have };
        return { id: null, have: have };
    }

    var recentBuffLeft = {};
    function buffStockLeft(name, count) {
        var key = normBuff(name);
        var row = recentBuffLeft[key];
        if (!row || Date.now() > row.until) return Number(count) || 0;
        return Math.max(0, Number(count || 0) - row.used);
    }
    function noteBuffUsed(name) {
        var key = normBuff(name);
        var row = recentBuffLeft[key];
        if (!row || Date.now() > row.until) row = { used: 0, until: Date.now() + 20000 };
        row.used += 1;
        row.until = Date.now() + 20000;
        recentBuffLeft[key] = row;
    }
    function findBuffStack(want) {
        var w = normBuff(want);
        try {
            var vec = game.gi.mCurrentPlayer.getAvailableBuffs_vector();
            var i, best = null;
            for (i = 0; vec && i < vec.length; i++) {
                var item = vec[i];
                if (!item || (item.IsExhausted && item.IsExhausted())) continue;
                var def = item.GetBuffDefinition && item.GetBuffDefinition();
                var nm = def && def.GetName_string && def.GetName_string();
                if (!nm) continue;
                var n = normBuff(nm);
                if (n === w || (w && n.indexOf(w) >= 0) || (w && w.indexOf(n) >= 0)) {
                    if ((item.GetAmount && item.GetAmount() > 0) || !item.GetAmount) {
                        best = item;
                        break;
                    }
                }
            }
            return best;
        } catch (_) { return null; }
    }

    function zoneReady() {
        try {
            var gi = game.gi;
            var z = gi && gi.mCurrentPlayerZone;
            return !!(z && z.mStreetDataMap && z.GetBuildingFromGridPosition);
        } catch (_) { return false; }
    }

    function sendBuff(grid, buffName, fromBlue) {
        if (!sending && !fromBlue) return enqueue("buff", function () { sendBuff(grid, buffName, true); });
        var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
        var allowEx = false;
        try { allowEx = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        if (!allowEx) return { ok: false, error: "execute-off" };
        if (grid == null) return { ok: false, error: "no-grid" };
        grid = Number(grid);
        var gi = null;
        try { gi = game.gi; } catch (_) {}
        if (!gi || typeof gi.SendServerAction !== "function") return { ok: false, error: "no-gi" };
        var bld = null;
        try { bld = gi.mCurrentPlayerZone.GetBuildingFromGridPosition(grid); } catch (_) {}
        if (!bld) return { ok: false, fact: "dc", reason: "no-building" };
        if (bld.productionBuff != null) return { ok: false, fact: "dc", reason: "already-buffed" };

        var stack = null;
        var fallback = null;
        var tried = [];
        try {
            var menu = gi.mCurrentPlayer.getBuffsSortedForStarMenu() || [];
            var want = normBuff(buffName || "");
            var i, item, def, nm, n, bType, tType;
            for (i = 0; i < menu.length; i++) {
                item = menu[i];
                if (!item || item.IsExhausted || (item.GetWaitingForServer && item.GetWaitingForServer())) continue;
                def = item.GetBuffDefinition && item.GetBuffDefinition();
                if (!def) continue;
                try { bType = def.GetBuffType(); } catch (_) { bType = -1; }
                try { tType = def.GetTargetType(); } catch (_) { tType = -1; }
                nm = def.GetName_string && def.GetName_string();
                tried.push((nm || "?") + " b" + bType + " t" + tType);
                if (bType !== 0 || tType !== 0) continue;
                if (!nm || /Area|Adventure|Explorer|Bookbinder|Fertilizer|ChangeSkin|Flower|Effect|Bouquet|Ghostbuster|Halloween|Event/i.test(nm)) continue;
                n = normBuff(nm);
                var match = (want === "aut") || (want && (n.indexOf(want) >= 0 || want.indexOf(n) >= 0));
                if (!match && (want === "smc" || want.indexOf("smoked") >= 0 || want.indexOf("fish") >= 0)) {
                    match = n.indexOf("smoked") >= 0 && n.indexOf("fish") >= 0;
                }
                if (want && !match) continue;
                try {
                    var okApply = item.IsApplyable(gi.mCurrentPlayer, gi, grid);
                    tried[tried.length - 1] += " apply=" + (okApply === null ? "null" : typeof okApply);
                    if (okApply === null || typeof okApply !== "object") {
                        if (n.indexOf("smoked") >= 0 && n.indexOf("fish") >= 0) {
                            log("buff force " + nm + " despite apply=" + (okApply === null ? "null" : typeof okApply));
                        } else {
                            log("buff skip " + nm + " apply=" + (okApply === null ? "null" : typeof okApply));
                            continue;
                        }
                    }
                } catch (e) { tried[tried.length - 1] += " applyErr"; log("buff applyErr " + nm); continue; }
                if (typeof item.GetUniqueId !== "function") continue;
                stack = item;
                break;
            }
            if (!stack) return { ok: false, fact: "wait", reason: "no-production-buff", want: buffName || "(any)", tried: tried.slice(0, 5).join(",") };
        } catch (e) {
            return { ok: false, fact: "wait", reason: "buff-menu " + e };
        }
        var usedName = "";
        try { usedName = stack.GetBuffDefinition().GetName_string(); } catch (_) {}

        if (bld.productionBuff != null) return { ok: false, fact: "dc", reason: "already-buffed" };
        var rBf = viaAdapter("APPLY_BUFF", 0, grid, 0, stack.GetUniqueId(), { stack: stack }), sent = !!rBf.ok;   // 0.2.101 (ADR 0073)
        return { ok: sent, fact: sent ? "ex" : "dc", grid: grid, buff: usedName || buffName || "star", reason: sent ? undefined : rBf.reason };
    }


    function sendDemolish(grid, expect) {   // 0.2.78 (R4): expect = { name } of the building the caller decided on
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
        var allowEx = false;
        try { allowEx = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        if (!allowEx) return { ok: false, error: "execute-off" };
        if (grid == null) return { ok: false, error: "no-grid" };
        grid = Number(grid);
        var A = root.GCAF_GameInterface;   // 0.2.101 (ADR 0073): the adapter guards (verified kinds, the expected name) and sends
        if (!A || typeof A.sendDemolish !== "function") return { ok: false, fact: "dc", error: "no adapter", reason: "game interface adapter not loaded", grid: grid };
        var bldD = buildingAt(grid);
        if (!bldD) return { ok: false, error: "no-building", grid: grid };
        var whyX = guardDemolish(bldD);   // 0.2.15 safeguard: control's own reading stays the first lock
        if (!whyX && expect && expect.name && nameOf(bldD) !== String(expect.name)) whyX = "another building stands on " + grid + " (" + nameOf(bldD) + ", expected " + expect.name + ")";   // 0.2.78 (R4)
        if (whyX) { refuse("demolish", whyX); return { ok: false, fact: "dc", error: "safeguard", reason: whyX, grid: grid }; }
        var rDm; try { rDm = A.sendDemolish(grid, expect && expect.name ? { name: String(expect.name) } : null); } catch (e) { return { ok: false, error: String(e) }; }
        var ok = !!(rDm && rDm.ok);
        if (!ok) return { ok: false, fact: "dc", reason: (rDm && rDm.reason) || "no answer from the adapter", grid: grid };
        return { ok: ok, fact: ok ? "ex" : "dc", grid: grid };
    }

    /* ---------- 0.2.16 TRADE GATEWAY (Game Interface Adapter for the trade PBC, decision 0010) ----------
       Read from the client's own code (client.swf): friend/guild trades arrive as mails of MAIL_TYPE.TRADE (1);
       cMailWindow keeps headers in mMails and bodies in mMailCache; new cTradeObject(body, int(subject)) gives
       .offer / .costs (dResourceVO name_string + amount, or a buff). Accepting is
       mClientMessages.SendMessagetoServer(COMMAND.ACCEPT_TRADE_MAIL = 1050, playerId, dIntegerVO(mail.id)).
       SAFEGUARD: the only accept this adapter performs is acceptRoundTrade — two TRADE mails from one sender that are
       an EXACT mirror (resources only, equal amounts, within the cap) and both affordable. Anything else is refused. */
    var CMD = { ACCEPT_TRADE_MAIL: 1050, DECLINE_TRADE: 1053, GET_INBOX_HEADERS: 1175, GET_INBOX_BODY: 1177, DISMISS_MAILS: 1201, INITIATE_TRADE: 1049 };
    var MAIL_TRADE = 1;
    function sendMail(name, vo, zone) {   // 0.2.104 (ADR 0073): every mail / trade message goes through the Game Interface Adapter
        var A = root.GCAF_GameInterface;
        if (!A || typeof A.sendMessage !== "function") return { ok: false, refused: true, reason: "game interface adapter not loaded" };
        var r; try { r = A.sendMessage(name, vo, zone); } catch (e) { return { ok: false, refused: true, reason: "send " + e }; }
        if (r && r.ok !== true) refuse("trade", name + " refused: " + r.reason);
        return r;
    }
    function def(name) {
        try { if (typeof game !== "undefined" && typeof game.def === "function") { var c = game.def(name); if (c) return c; } } catch (_) {}
        try { if (typeof swmmo !== "undefined" && typeof swmmo.getDefinitionByName === "function") return swmmo.getDefinitionByName(name); } catch (_) {}
        return null;
    }
    function intVO(v) {
        var C = def("Communication.VO::dIntegerVO");
        if (typeof C !== "function") throw new Error("no dIntegerVO");
        var o = new C(); o.value = Number(v);
        try { var o2 = new C(Number(v)); if (o2 && o2.value === Number(v)) return o2; } catch (_) {}
        return o;
    }
    function mailWindow() {
        try { if (root.globalFlash && root.globalFlash.gui && root.globalFlash.gui.mMailWindow) return root.globalFlash.gui.mMailWindow; } catch (_) {}
        try { var g = game.gi.mQuestClientCallbacks && game.gi.mQuestClientCallbacks.mGameInterface; if (g && g.mMailWindow) return g.mMailWindow; } catch (_) {}
        return null;
    }
    function mailsList() {
        var w = mailWindow(), out = [], m = w && w.mMails, i, n, src;
        if (!m) { try { var pg = w && w.pager; m = pg && pg.source; } catch (_) {} }   // 0.2.21: the public route
        if (!m) { try { var pc = pagerControl(); m = pc && pc.pager && pc.pager.source; if (m) mailSourceUsed = "pager"; } catch (_) {} }   // 0.2.27: every page
        if (!m) { try { var mp = mailView(); m = mp && mp.mailsList && mp.mailsList.dataProvider; if (m) mailSourceUsed = "page"; } catch (_) {} }   // 0.2.22: the view
        if (!m) return out;
        // 0.2.18: an ArrayCollection may expose its items through source / toArray rather than length + getItemAt
        try { if (typeof m.toArray === "function") src = m.toArray(); } catch (_) {}
        if (!src) { try { if (m.source && typeof m.source.length === "number") src = m.source; } catch (_) {} }
        if (src) { for (i = 0; i < src.length; i++) out.push(src[i]); return out; }
        n = Number(m.length) || 0;
        for (i = 0; i < n; i++) { try { out.push(m.getItemAt ? m.getItemAt(i) : m[i]); } catch (_) {} }
        return out;
    }
    function cachedMail(id) {
        try {
            var w = mailWindow(), c = w && w.mMailCache, r = null;
            if (c) r = c[id] || c[String(id)] || null;
            if (!r && w && typeof w.getMailInCache === "function") { try { r = w.getMailInCache(Number(id)); } catch (_) {} }   // 0.2.21
            if (!r && w && typeof w.getMailFromList === "function") { try { var fl = w.getMailFromList(Number(id)); if (fl && fl.body) r = fl; } catch (_) {} }
            return r || null;
        } catch (_) { return null; }
    }
    /* 0.2.17: live 2026-10-25 — the client hands every header response to gui.mMailWindow.setMailHeaderResponse,
       which reads mPanel first; until the mail window has been opened once mPanel is null, the call fails and mMails
       stays empty. So the gateway opens the game's own mail window (gui.ToggleMailWindow) when it needs the inbox,
       and closes it again when it opened it. */
    var mailOpenedByUs = 0;
    /* 0.2.22: the MailWindow view (an MXML popup) on the Flex display list; its child mailsList is public */
    var mailViewSeen = null, mailViewPath = "";
    function kidsOf(c) {
        var out = [], n = 0, i;
        try { n = Number(c.numChildren) || 0; } catch (_) { n = 0; }
        for (i = 0; i < n && i < 200; i++) { try { out.push(c.getChildAt(i)); } catch (_) {} }
        return out;
    }
    function isMailView(o) {
        try { if (o && String(o.className) === "MailWindow") return true; } catch (_) {}
        try { return !!(o && o.mailsList && o.mailsList.dataProvider !== undefined && /mail/i.test(String(o.className || o.name || ""))); } catch (_) { return false; }
    }
    function mailView() {
        try { if (mailViewSeen && mailViewSeen.stage) return mailViewSeen; } catch (_) {}
        mailViewSeen = null;
        try { var w0 = mailWindow(), ue = w0 && w0.mUiElement; if (ue && (ue.mailsList || isMailView(ue))) { mailViewSeen = ue; mailViewPath = "mUiElement"; return ue; } } catch (_) {}
        try {
            var FG = def("mx.core::FlexGlobals"), app = FG && FG.topLevelApplication;
            if (!app) { var AP = def("mx.core::Application"); app = AP && AP.application; }
            var sm = app && app.systemManager;
            if (!sm) return null;
            var roots = [["sm", sm]];
            try { if (sm.popUpChildren) roots.push(["popUp", sm.popUpChildren]); } catch (_) {}
            try { if (sm.rawChildren) roots.push(["raw", sm.rawChildren]); } catch (_) {}
            var q = [], i, k, cur;
            for (i = 0; i < roots.length; i++) q.push([roots[i][0], roots[i][1], 0]);
            var visited = 0;
            while (q.length && visited < 3000) {
                cur = q.shift(); visited++;
                if (isMailView(cur[1])) { mailViewSeen = cur[1]; mailViewPath = cur[0]; return cur[1]; }
                if (cur[2] >= 5) continue;
                var ks = kidsOf(cur[1]);
                for (k = 0; k < ks.length; k++) if (ks[k]) q.push([cur[0] + "/" + k, ks[k], cur[2] + 1]);
            }
        } catch (e) { log("trade: mail view search " + e); }
        return null;
    }
    /* 0.2.27: the view's PagerControl (public pager model: source = the whole inbox) */
    var mailSourceUsed = "";
    function pagerControl() {
        var v = mailView(); if (!v) return null;
        var q = [[v, 0]], seen = 0, cur, ks, k;
        while (q.length && seen < 800) {
            cur = q.shift(); seen++;
            try { if (cur[0] !== v && String(cur[0].className) === "PagerControl") return cur[0]; } catch (_) {}
            if (cur[1] >= 6) continue;
            ks = kidsOf(cur[0]);
            for (k = 0; k < ks.length; k++) if (ks[k]) q.push([ks[k], cur[1] + 1]);
        }
        return null;
    }
    function mailPanelReady() {
        try { var w = mailWindow(); if (!w) return false; if (w.mPanel) return true; return mailsList().length > 0; } catch (_) { return false; }
    }
    function mailProbe() {                                      // 0.2.20: what the script can see of the mail window
        var p = { window: false };
        try {
            var w = mailWindow(); if (!w) return p;
            p.window = true; p.panelType = typeof w.mPanel; p.panel = !!w.mPanel; p.loading = w.mLoadingMailPanel; p.isInbox = w.isInbox;
            var m = w.mMails; p.mailsType = m == null ? String(m) : typeof m;
            try { var pg = w.pager; p.pager = pg == null ? String(pg) : typeof pg; var ps = pg && pg.source; p.pagerSource = ps == null ? String(ps) : typeof ps; p.pagerLength = ps && ps.length; } catch (e2) { p.pagerError = String(e2).slice(0, 80); }
            p.getMailInCache = typeof w.getMailInCache;
            try { var w1 = mailWindow(); p.uiElement = w1 ? typeof w1.mUiElement : "no window"; var AP1 = def("mx.core::Application"); p.flexApp = !!(AP1 && AP1.application); p.flexGlobals = !!def("mx.core::FlexGlobals"); } catch (e4) { p.rootError = String(e4).slice(0, 80); }
            try { var pc1 = pagerControl(); p.pagerControl = !!pc1; var src1 = pc1 && pc1.pager && pc1.pager.source; p.allLength = src1 && src1.length; p.source = mailSourceUsed; } catch (e5) { p.pagerControlError = String(e5).slice(0, 80); }
            try { var mv = mailView(); p.view = !!mv; p.viewPath = mailViewPath; if (mv) { var dp = mv.mailsList && mv.mailsList.dataProvider; p.viewDp = dp == null ? String(dp) : typeof dp; p.viewDpLength = dp && dp.length; } } catch (e3) { p.viewError = String(e3).slice(0, 80); }
            if (!m) { try { m = w.pager && w.pager.source; } catch (_) {} }
            try { p.mailsLength = m && m.length; } catch (_) {}
            try { p.sourceLength = m && m.source && m.source.length; } catch (_) {}
            try { p.toArray = !!(m && typeof m.toArray === "function"); } catch (_) {}
            p.listed = mailsList().length;
            try { var c = w.mMailCache, k, n = 0; if (c) for (k in c) n++; p.cache = n; } catch (_) {}
        } catch (e) { p.error = String(e).slice(0, 120); }
        return p;
    }
    var lastToggleAt = 0;
    function ensureMailPanel(by) {   // 0.2.56: never opens the window itself — the mail manager does, at a quiet moment
        if (mailPanelReady()) return true;
        try { if (root.DMA_Mail && typeof root.DMA_Mail.requestRound === "function") root.DMA_Mail.requestRound(by || "gateway"); } catch (_) {}
        return false;
    }
    var mailCloseMs = 15000;
    function openMailWindow(by, maxMs) {   // 0.2.56: the mail manager's own act
        if (visitHeld()) return { ok: false, reason: "hold" };
        if (mailOpenedByUs) return { ok: true, by: "us" };
        if (mailPanelReady()) return { ok: true, by: "player" };   // the player has it open: use it, never toggle it
        try {
            var g = root.globalFlash && root.globalFlash.gui;
            if (!g || typeof g.ToggleMailWindow !== "function") return { ok: false, reason: "no mail window" };
            g.ToggleMailWindow(null); lastToggleAt = mailOpenedByUs = Date.now(); mailCloseMs = Number(maxMs) > 0 ? Number(maxMs) : 15000;
            log("mail window opened by " + (by || "mail manager"));
            return { ok: true, by: "us" };
        } catch (e) { toggleSignature(); return { ok: false, reason: String(e).slice(0, 120) }; }
    }
    var signatureDone = false;
    function toggleSignature() {   // 0.2.57: read-only — which parameters does gui.ToggleMailWindow take?
        if (signatureDone) return; signatureDone = true;
        try {
            var g = root.globalFlash && root.globalFlash.gui, rt = root.runtime || (root.window && root.window.runtime);
            var dt = rt && rt.flash && rt.flash.utils && rt.flash.utils.describeType;
            var x = typeof dt === "function" && g ? String(dt(g)) : "";
            var m = /<method name="ToggleMailWindow"[\s\S]*?<\/method>|<method name="ToggleMailWindow"[^>]*\/>/.exec(x);
            var params = []; if (m) { var re = /<parameter index="(\d+)" type="([^"]+)" optional="([^"]+)"\/>/g, q; while ((q = re.exec(m[0])) !== null) params.push({ index: Number(q[1]), type: q[2], optional: q[3] === "true" }); }
            var ret = m ? (/returnType="([^"]+)"/.exec(m[0]) || [])[1] : null;
            if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { tk: "TK-MAIL", act: "toggle signature", found: !!m, params: params, returnType: ret || null });
        } catch (e) { log("toggle signature " + e); }
    }
    function closeMailWindow() { if (!mailOpenedByUs) return false; mailOpenedByUs = Date.now() - 8000; return closeMailPanelIfOurs(); }
    function mailWatchdog() {   // 0.2.55; 0.2.56: after the opener's maxMs
        if (mailOpenedByUs && Date.now() - mailOpenedByUs >= mailCloseMs) return closeMailPanelIfOurs();
        return false;
    }
    function mailWindowOpen() {                                // 0.2.60
        try { var w = mailWindow(), p = w && w.mPanel; if (!p) return false; if (p.visible === false) return false; return p.stage != null || p.parent != null; } catch (_) { return false; }
    }
    function closeMailPanel() {                                // 0.2.60: close it if it is open, whoever opened it
        if (!mailWindowOpen()) { mailOpenedByUs = 0; return false; }
        try { var g = root.globalFlash && root.globalFlash.gui; if (g && typeof g.ToggleMailWindow === "function") g.ToggleMailWindow(null); else return false; } catch (_) { return false; }
        mailOpenedByUs = 0; log("trade: mail window closed after the RT");
        return true;
    }
    function closeMailPanelIfOurs() {
        if (!mailOpenedByUs || Date.now() - mailOpenedByUs < 8000) return false;
        try { var g = root.globalFlash && root.globalFlash.gui; if (g && typeof g.ToggleMailWindow === "function") g.ToggleMailWindow(null); } catch (_) {}
        mailOpenedByUs = 0; log("trade: mail window closed again");
        return true;
    }
    function requestInboxHeaders() {
        if (visitHeld()) return false;   // 0.2.54
        return sendMail("GET_INBOX_HEADERS", intVO(5000), null).ok === true;
    }
    function requestMailBody(id) {
        return sendMail("GET_INBOX_BODY", intVO(id), null).ok === true;
    }
    function resOf(o) {
        if (!o) return null;
        var name = null, amount = null;
        try { name = o.name_string != null ? String(o.name_string) : (o.getName ? String(o.getName()) : null); } catch (_) {}
        try { amount = o.amount != null ? Number(o.amount) : (o.getAmount ? Number(o.getAmount()) : null); } catch (_) {}
        if (!name || !(amount > 0)) return null;           // a buff or anything else is not a resource
        return { name: name, amount: amount };
    }
    /* the trade inside a TRADE mail, or null (needs the body, see requestMailBody) */
    var tradeCache = {}, tradeCacheKeys = [];                                  // 0.2.40
    function tradeOfMail(mail) {
        if (!mail || Number(mail.type) !== MAIL_TRADE) return null;
        var full = cachedMail(mail.id) || mail;
        if (!full || full.body == null || full.body === "") return { id: Number(mail.id), sender: String(mail.senderName || ""), needsBody: true };
        var hit = tradeCache[String(mail.id)]; if (hit) return hit;                    // 0.2.40
        var T = def("ServerState::cTradeObject");
        if (typeof T !== "function") return { id: Number(mail.id), error: "no cTradeObject" };
        var t = new T(full.body, parseInt(String(full.subject || "0"), 10) || 0);
        var out = { id: Number(mail.id), sender: String(full.senderName || mail.senderName || ""), senderId: Number(full.senderId || 0),
                 offer: resOf(t.offer), costs: resOf(t.costs), lots: Number(t.totalLots || 1) || 1 };
        tradeCache[String(mail.id)] = out; tradeCacheKeys.push(String(mail.id)); if (tradeCacheKeys.length > 400) delete tradeCache[tradeCacheKeys.shift()];
        return out;
    }
    /* 0.2.66 (author: "zouden we de RT aan kunnen laten tijdens de adventures?" — "ja"): on an adventure the client's
       resources are the adventure's, so the home stock is a snapshot taken every minute at home (max 3 h old), kept up to
       date with the round trades accepted while away. RT runs away from home only while our own adventure run fights. */
    var homeStock = { at: 0, map: {} }, STOCK_MAX_AGE = 3 * 3600000;
    /* 0.2.68: the snapshot is kept in dma-home-stock.json, so a restart on the adventure still knows the home stock */
    function stockFile(obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("dma-home-stock.json").nativePath), st = new a.FileStream();
              if (obj) { st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return obj; }
              if (!f.exists) return null; st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function snapStock() { if (atHomeSafe() !== true) return; var m = {}; resourceList().forEach(function (r) { m[r.name] = r.amount; }); if (Object.keys(m).length) { homeStock = { at: Date.now(), map: m }; stockFile(homeStock); } }
    try { var hs0 = stockFile(); if (hs0 && hs0.at > 0 && hs0.map) homeStock = hs0; } catch (_) {}
    function stockFresh() { return homeStock.at > 0 && Date.now() - homeStock.at < STOCK_MAX_AGE; }
    function rtAwayOk() {
        if (atHomeSafe() !== false || !stockFresh()) return false;
        try { var A = root.DMA_Adventure, st = A && A.status ? A.status() : null;
              if (st && !st.stopped && st.state !== "DONE") return st.state === "FIGHT";   // our run: only while it fights
              return !!(A && typeof A.onOwnAdventure === "function" && A.onOwnAdventure()); } catch (_) { return false; }   // 0.2.70: the player on his own adventure
    }
    function have(name) {
        if (atHomeSafe() === false) return stockFresh() ? (Number(homeStock.map[name]) || 0) : 0;
        try { return Number(game.getResources().GetResourceAmount(name)) || 0; } catch (_) { return 0; }
    }
    function bookAway(trades) { if (atHomeSafe() !== false) return; trades.forEach(function (t) { homeStock.map[t.offer.name] = (Number(homeStock.map[t.offer.name]) || 0) + Number(t.offer.amount); homeStock.map[t.costs.name] = (Number(homeStock.map[t.costs.name]) || 0) - Number(t.costs.amount); }); stockFile(homeStock); }
    try { setTimeout(snapStock, 20000); setInterval(snapStock, 60000); } catch (_) {}
    try { setInterval(function () { try { if (Object.keys(allocations).length) recheck(); } catch (_) {} }, 60000); } catch (_) {}   // 0.2.98: the allocation tick
    /* "" when a and b may be accepted together, else the reason */
    function guardRoundTrade(a, b, cap) {
        if (!a || !b || a.id === b.id) return "two different trade mails needed";
        if (!a.offer || !a.costs || !b.offer || !b.costs) return "not a resource-for-resource trade";
        if (a.sender.toLowerCase() !== b.sender.toLowerCase()) return "different senders";
        if ((a.lots || 1) !== 1 || (b.lots || 1) !== 1) return "more than one lot";
        if (a.offer.name !== b.costs.name || a.offer.amount !== b.costs.amount || a.costs.name !== b.offer.name || a.costs.amount !== b.offer.amount)
            return "not an exact mirror";
        if (a.offer.name === a.costs.name) return "same resource on both sides";
        var c = Number(cap) || 100;
        if (a.offer.amount > c || a.costs.amount > c) return "above the cap of " + c;
        if (have(a.costs.name) < a.costs.amount || have(b.costs.name) < b.costs.amount) return "not enough stock for both sides";
        return "";
    }
    /* 0.2.29: a round trade of N trades = their net is zero for every resource */
    function netOf(trades) {
        var net = {}, i, t;
        for (i = 0; i < trades.length; i++) {
            t = trades[i];
            net[t.offer.name] = (net[t.offer.name] || 0) + Number(t.offer.amount);   // we get the offer
            net[t.costs.name] = (net[t.costs.name] || 0) - Number(t.costs.amount);   // we pay the costs
        }
        return net;
    }
    function guardRoundSet(trades, cap, marginPct) {
        trades = trades || [];
        if (trades.length < 2) return { why: "a round trade needs at least two trades" };
        if (trades.length > 8) return { why: "more than 8 trades" };
        var c = Number(cap) || 100, who = String(trades[0].sender || "").toLowerCase(), ids = {}, i, t;
        for (i = 0; i < trades.length; i++) {
            t = trades[i];
            if (!t || !t.offer || !t.costs) return { why: "not a resource-for-resource trade" };
            if (ids[t.id]) return { why: "the same trade twice" }; ids[t.id] = 1;
            if (String(t.sender || "").toLowerCase() !== who) return { why: "different senders" };
            if ((t.lots || 1) !== 1) return { why: "more than one lot" };
            if (t.offer.name === t.costs.name) return { why: "same resource on both sides" };
            if (t.offer.amount > c || t.costs.amount > c) return { why: "above the cap of " + c };
        }
        var net = netOf(trades), r, off = [];
        for (r in net) if (net.hasOwnProperty(r) && net[r] !== 0) off.push(r + " " + (net[r] > 0 ? "+" : "") + net[r]);
        if (off.length) return { why: "the trades do not net to zero (" + off.join(", ") + ")" };
        var m = marginPct == null ? 100 : Math.max(0, Number(marginPct) || 0), paid = {};   // 0.2.35: safety margin on what we pay
        trades.forEach(function (x) { paid[x.costs.name] = (paid[x.costs.name] || 0) + Number(x.costs.amount); });
        for (r in paid) if (paid.hasOwnProperty(r)) {
            var need = Math.ceil(paid[r] * (1 + m / 100)), h = have(r);
            if (h < need) return { why: "I have too little " + r + " to guarantee the round trade (" + h + " in stock, " + need + " needed for " + paid[r] + ")", margin: true };
        }
        var stock = {}, left = trades.slice(), order = [], k, progressed;
        trades.forEach(function (x) { stock[x.costs.name] = have(x.costs.name); stock[x.offer.name] = have(x.offer.name); });
        while (left.length) {
            progressed = false;
            for (k = 0; k < left.length; k++) {
                t = left[k];
                if (stock[t.costs.name] >= t.costs.amount) {
                    stock[t.costs.name] -= t.costs.amount; stock[t.offer.name] += t.offer.amount;
                    order.push(t); left.splice(k, 1); progressed = true; break;
                }
            }
            if (!progressed) return { why: "not enough stock to pay the trades in any order" };
        }
        return { why: "", order: order };
    }
    function acceptRoundSet(trades, cap, marginPct) {
        if (!atHome() && !rtAwayOk()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39; 0.2.66 own adventure fight
        var g = guardRoundSet(trades, cap, marginPct);
        if (g.why) { refuse("trade", g.why); return { ok: false, reason: g.why }; }
        var gi = game.gi, pid = gi.mCurrentPlayer.GetPlayerId(), w = mailWindow();
        var sentSet = [], noSet = null;
        g.order.forEach(function (t) { if (noSet) return; var r = sendMail("ACCEPT_TRADE_MAIL", intVO(t.id), pid); if (r.ok === true) sentSet.push(t); else noSet = r.reason; });
        if (noSet && !sentSet.length) return { ok: false, fact: "dc", reason: noSet };
        g.order = sentSet;   // 0.2.104: only what went out is removed and booked
        try { if (w && typeof w.removeMail === "function") g.order.forEach(function (t) { var m = cachedMail(t.id); if (m) w.removeMail(m); }); } catch (_) {}
        bookAway(g.order);   // 0.2.66
        log("trade: round trade of " + g.order.length + " accepted (" + g.order.map(function (t) { return t.id; }).join(", ") + ") from " + trades[0].sender);
        return { ok: true, ids: g.order.map(function (t) { return t.id; }) };
    }
    function acceptRoundTrade(a, b, cap) {
        if (!atHome() && !rtAwayOk()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39; 0.2.66 own adventure fight
        var why = guardRoundTrade(a, b, cap);
        if (why) { refuse("trade", why); return { ok: false, reason: why }; }
        var gi = game.gi, pid = gi.mCurrentPlayer.GetPlayerId();
        // the side whose costs we already hold first; the second is paid with what the first delivered
        var first = have(a.costs.name) >= a.costs.amount ? a : b, second = first === a ? b : a;
        var s1 = sendMail("ACCEPT_TRADE_MAIL", intVO(first.id), pid);
        if (s1.ok !== true) return { ok: false, fact: "dc", reason: s1.reason };   // 0.2.104: the first side did not go; the second must not
        var s2 = sendMail("ACCEPT_TRADE_MAIL", intVO(second.id), pid);
        try { var w = mailWindow(); if (w && typeof w.removeMail === "function") { [first, second].forEach(function (t) { var m = cachedMail(t.id); if (m) w.removeMail(m); }); } } catch (_) {}
        log("trade: round trade accepted " + first.id + " + " + second.id + " from " + a.sender);
        return { ok: true, first: first.id, second: second.id };
    }

    /* 0.2.33: guild help and star trades — friend trades we SEND, and their outcome mails */
    var MAIL_TRADE_ACCEPTED = 4, MAIL_TRADE_DECLINED = 5, SLOT_FRIEND_TO_FRIEND = 4;
    function friendsList() { try { return root.globalFlash && root.globalFlash.gui && root.globalFlash.gui.mFriendsList; } catch (_) { return null; } }
    function guildMember(name) {
        var fl = friendsList(), m = null, me = null;
        var want = String(name || "").toLowerCase();
        try { if (fl && typeof fl.GetGuildMemberByName_string === "function") m = fl.GetGuildMemberByName_string(want); } catch (_) {}   // 0.2.37: lowercase
        if (!m) {                                                   // 0.2.37: walk the guild's members ourselves
            try {
                var g = game.gi.GetCurrentPlayerGuild(), ms = g && g.members, arr = ms && (typeof ms.toArray === "function" ? ms.toArray() : ms.source || ms), i;
                for (i = 0; arr && i < (arr.length || 0); i++) { var x = arr[i] || (ms.getItemAt ? ms.getItemAt(i) : null); if (x && String(x.username || "").toLowerCase() === want) { m = x; break; } }
            } catch (_) {}
        }
        if (!m || !(Number(m.id) > 0)) return null;
        try { me = fl.GetGuildMemberById(game.gi.mCurrentPlayer.GetPlayerId()); } catch (_) {}
        var delay = null; try { delay = root.global && root.global.tradeFriendDelay != null ? Number(root.global.tradeFriendDelay) : null; } catch (_) {}
        var allowed = null;                                       // null = unknown: the game decides
        if (delay != null && !isNaN(delay)) { var lim = Date.now() - delay * 1000; allowed = Number(m.friendSince) < lim && (!me || Number(me.friendSince) < lim); }
        return { id: Number(m.id), name: String(m.username || name), level: Number(m.playerLevel) || 0, tradeAllowed: allowed };
    }
    function sendFriendTrade(toName, offer, costs, opts) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        opts = opts || {};
        var pol = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null, allowEx = false;
        try { allowEx = !!(pol && pol.get && pol.get("control.allowExecute")); } catch (_) {}
        if (!allowEx) return { ok: false, reason: "execute-off" };
        var mb = guildMember(toName);
        if (!mb) return { ok: false, reason: "not a guild member I can see: " + toName };
        if (mb.tradeAllowed === false) return { ok: false, reason: "the game's trade delay for new guild members has not passed" };
        if (!offer || !costs || !offer.name || !costs.name) return { ok: false, reason: "offer and costs needed" };
        if (offer.name === costs.name) return { ok: false, reason: "same resource on both sides" };
        var oa = Number(offer.amount), ca = Number(costs.amount);
        if (!(oa >= 1) || oa !== Math.floor(oa) || !(ca >= 1) || ca !== Math.floor(ca)) return { ok: false, reason: "whole amounts of at least 1" };
        var floor = Number(opts.floor) || 0;
        if (have(offer.name) - oa < floor) return { ok: false, reason: "would leave " + (have(offer.name) - oa) + " " + offer.name + " (floor " + floor + ")" };
        var V = def("Communication.VO::dTradeOfferVO"), RV = def("Communication.VO::dResourceVO");
        if (typeof V !== "function" || typeof RV !== "function") return { ok: false, reason: "no trade offer class" };
        function rvo(r) { var x = new RV(); x.name_string = String(r.name); x.amount = Number(r.amount); return x; }
        var vo = new V();
        vo.offerRes = rvo({ name: offer.name, amount: oa }); vo.offerBuff = null;
        vo.costsRes = rvo({ name: costs.name, amount: ca }); vo.costsBuff = null;
        vo.receipientId = mb.id; vo.lots = 0; vo.slotType = SLOT_FRIEND_TO_FRIEND; vo.slotPos = 0;
        var sI = sendMail("INITIATE_TRADE", vo, null);
        if (sI.ok !== true) return { ok: false, reason: sI.reason };
        log("trade: sent " + oa + " " + offer.name + " for " + ca + " " + costs.name + " to " + mb.name + (opts.tag ? " (" + opts.tag + ")" : ""));
        return { ok: true, to: mb.name, toId: mb.id, level: mb.level };
    }
    function storageOf(name) {                                    // 0.2.36
        var amount = have(name), max = null;
        try { var r = game.getResources().GetPlayerResource(name); if (r) { if (r.amount != null) amount = Number(r.amount); if (Number(r.maxLimit) > 0) max = Number(r.maxLimit); } } catch (_) {}
        if (!max) max = 1625500;                                    // observed storage limit, 2026-10-25
        return { name: name, amount: amount, max: max, full: amount >= max };
    }
    /* 0.2.38 (live 2026-10-25: "peter star trade 400k brew" answered "I have no Brew" while brew is full): every
       resource the player holds, with the game's own name, its amount, its storage limit and the name the game shows */
    function resourceList() {
        var out = [];
        try {
            var v = game.getResources().GetPlayerResources_vector(), i, r, n, lab;
            for (i = 0; v && i < v.length; i++) {
                r = v[i]; if (!r) continue;
                n = String(r.name_string != null ? r.name_string : (r.GetName_string ? r.GetName_string() : r.name || ""));
                if (!n) continue;
                lab = ""; try { if (typeof loca !== "undefined" && loca.GetText) lab = String(loca.GetText("RES", n) || ""); } catch (_) {}
                out.push({ name: n, amount: Number(r.amount) || 0, max: Number(r.maxLimit) || 0, label: lab });
            }
        } catch (_) {}
        return out;
    }
    function acceptOneTrade(t, maxCost) {                         // 0.2.36: one trade, nothing else
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        if (!t || !t.offer || !t.costs || !(Number(t.id) > 0)) return { ok: false, reason: "not a resource-for-resource trade" };
        if ((t.lots || 1) !== 1) return { ok: false, reason: "more than one lot" };
        if (maxCost != null && t.costs.amount > Number(maxCost)) return { ok: false, reason: "costs " + t.costs.amount + " " + t.costs.name };
        if (have(t.costs.name) < t.costs.amount) return { ok: false, reason: "not enough " + t.costs.name };
        var gi = game.gi;
        var sA = sendMail("ACCEPT_TRADE_MAIL", intVO(t.id), gi.mCurrentPlayer.GetPlayerId());
        if (sA.ok !== true) return { ok: false, fact: "dc", reason: sA.reason };   // 0.2.104
        try { var w = mailWindow(), m = cachedMail(t.id); if (w && m && typeof w.removeMail === "function") w.removeMail(m); } catch (_) {}
        log("trade: accepted " + t.id + " (" + t.offer.amount + " " + t.offer.name + " for " + t.costs.amount + " " + t.costs.name + ") from " + t.sender);
        return { ok: true, id: t.id };
    }
    var outcomeCache = {}, outcomeKeys = [];                                  // 0.2.40
    function tradeOutcomes(sender) {
        var who = String(sender || "").toLowerCase();
        return mailsList().filter(function (m) { try { var t = Number(m.type); return (t === MAIL_TRADE_ACCEPTED || t === MAIL_TRADE_DECLINED) && (!who || String(m.senderName || "").toLowerCase() === who); } catch (_) { return false; } })
            .map(function (m) {
                var o = { id: Number(m.id), sender: String(m.senderName || ""), outcome: Number(m.type) === MAIL_TRADE_ACCEPTED ? "accepted" : "declined" };
                try {   // the trade, when the body is cached and reads as a trade object (our offer / our costs); else needsBody
                    var full = cachedMail(m.id) || m, T = def("ServerState::cTradeObject");
                    var oc = outcomeCache[String(m.id)];                                                   // 0.2.40
                    if (oc) { o.offer = oc.offer; o.costs = oc.costs; }
                    else if (full && full.body && typeof T === "function") { var t = new T(full.body, parseInt(String(full.subject || "0"), 10) || 0); o.offer = resOf(t.offer); o.costs = resOf(t.costs); outcomeCache[String(m.id)] = { offer: o.offer, costs: o.costs }; outcomeKeys.push(String(m.id)); if (outcomeKeys.length > 400) delete outcomeCache[outcomeKeys.shift()]; }
                    else o.needsBody = true;
                } catch (_) { o.needsBody = true; }
                return o;
            });
    }
    function acceptReturnTrade(t, resource, maxCost) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        if (!t || !t.offer || !t.costs) return { ok: false, reason: "not a resource-for-resource trade" };
        if (t.offer.name !== resource) return { ok: false, reason: "returns " + t.offer.name + ", not " + resource };
        if ((t.lots || 1) !== 1) return { ok: false, reason: "more than one lot" };
        if (t.costs.amount > (Number(maxCost) || 10)) return { ok: false, reason: "costs " + t.costs.amount + " " + t.costs.name + " (more than " + (Number(maxCost) || 10) + ")" };
        if (have(t.costs.name) < t.costs.amount) return { ok: false, reason: "not enough " + t.costs.name };
        var gi = game.gi;
        var sA = sendMail("ACCEPT_TRADE_MAIL", intVO(t.id), gi.mCurrentPlayer.GetPlayerId());
        if (sA.ok !== true) return { ok: false, fact: "dc", reason: sA.reason };   // 0.2.104
        try { var w = mailWindow(), m = cachedMail(t.id); if (w && m && typeof w.removeMail === "function") w.removeMail(m); } catch (_) {}
        log("trade: star-trade return accepted " + t.id + " (" + t.offer.amount + " " + t.offer.name + ") from " + t.sender);
        return { ok: true, id: t.id, amount: t.offer.amount };
    }

    /* 0.2.31: explorer loot only; MAIL_TYPE values read from client.swf */
    var LOOT_TYPES = { 6: "treasure", 41: "treasure (skilled)", 44: "treasure (travelling erudite)", 45: "treasure (bean a colada)",
                       25: "adventure found", 42: "adventure found (skilled)", 27: "map fragment", 43: "map fragment (skilled)", 53: "expedition found", 19: "adventure won loot" };   // 0.2.89
    var LOOT_GROUP = { 6: "treasure", 41: "treasure", 44: "treasure", 45: "treasure", 25: "adventure", 42: "adventure", 27: "fragment", 43: "fragment", 53: "expedition", 19: "advloot" };   // 0.2.89
    function lootCounts() {
        var c = { treasure: 0, adventure: 0, fragment: 0, expedition: 0, advloot: 0 };   // 0.2.89
        lootMails().forEach(function (m) { var g = LOOT_GROUP[Number(m.type)]; if (g) c[g] += 1; });
        return c;
    }
    function lootMails() { return mailsList().filter(function (m) { try { return LOOT_TYPES.hasOwnProperty(Number(m.type)) && Number(m.id) > 0; } catch (_) { return false; } }); }
    function collectLootMails(opts) {
        if (!atHome()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39
        if (typeof opts !== "object" || opts === null) opts = { toStorage: opts === true };   // 0.2.31 signature still works
        var toStorage = opts.toStorage === true, groups = opts.groups || null;
        var list = lootMails().filter(function (m) { return !groups || groups[LOOT_GROUP[Number(m.type)]] === true; }).slice(0, 10);
        if (!list.length) return { ok: true, n: 0 };
        var R = def("Communication.VO.Mail::dDismissMailsRequestVO"), AC = def("mx.collections::ArrayCollection");
        if (typeof R !== "function" || typeof AC !== "function") return { ok: false, reason: "no dismiss request class" };
        var ids = list.map(function (m) { return Number(m.id) | 0; });
        var coll = new AC();                                             // 0.2.34: as the game does — empty, then addItem per id
        ids.forEach(function (id) { coll.addItem(id); });
        var vo = new R(); vo.mailsIDs_collection = coll; vo.claim = toStorage === true;
        var gi = game.gi;
        var sD = sendMail("DISMISS_MAILS", vo, null);
        if (sD.ok !== true) return { ok: false, reason: sD.reason };   // 0.2.104: not sent, so not removed from the window either
        try { var w = mailWindow(); if (w && typeof w.removeMail === "function") list.forEach(function (m) { try { w.removeMail(m); } catch (_) {} }); } catch (_) {}
        var kinds = {}; list.forEach(function (m) { var k = LOOT_GROUP[Number(m.type)] || "other"; kinds[k] = (kinds[k] || 0) + 1; });   // 0.2.32: per group
        log("loot: collected " + ids.length + " mails " + JSON.stringify(kinds) + (toStorage ? " into the storage" : " into the star menu"));
        return { ok: true, n: ids.length, ids: ids, kinds: kinds };
    }
    function declineTradeMails(trades) {                     // 0.2.28
        if (!atHome() && !rtAwayOk()) return { ok: false, fact: "dc", error: "away from home", reason: "away from home" };   // 0.2.39; 0.2.66 RT declines during our adventure fight
        trades = trades || [];
        if (!trades.length) return { ok: false, reason: "nothing to decline" };
        var who = String(trades[0].sender || "").toLowerCase(), i;
        for (i = 0; i < trades.length; i++) {
            if (!trades[i] || !(Number(trades[i].id) > 0)) { refuse("trade", "decline: not a trade mail"); return { ok: false, reason: "not a trade mail" }; }
            if (String(trades[i].sender || "").toLowerCase() !== who) { refuse("trade", "decline: different senders"); return { ok: false, reason: "different senders" }; }
        }
        var gi = game.gi, pid = gi.mCurrentPlayer.GetPlayerId(), w = mailWindow(), done = [];
        trades.forEach(function (t) {
            if (sendMail("DECLINE_TRADE", intVO(Number(t.id)), pid).ok !== true) return;   // 0.2.104
            try { var m = cachedMail(t.id); if (m && w && typeof w.removeMail === "function") w.removeMail(m); } catch (_) {}
            done.push(Number(t.id));
        });
        log("trade: declined " + done.join(", ") + " from " + who);
        return { ok: true, declined: done };
    }

    function permit(name, value, ctx) {
        if (!Object.prototype.hasOwnProperty.call(permits, name)) return false;
        permits[name] = value === true;
        permitCtx = value === true ? (ctx || null) : null;   // 0.2.103
        log("DMA Control permit " + name + "=" + permits[name]);
        return permits[name];
    }

    /* 0.2.24: the specialists' skill trees, read from the game (read only) */
    function callOr(o, fn, dflt) { try { if (o && typeof o[fn] === "function") return o[fn](); } catch (_) {} return dflt; }
    function vecToArray(v) {
        var out = [], i, n;
        if (!v) return out;
        try { if (typeof v.forEach === "function") { v.forEach(function (x) { out.push(x); }); return out; } } catch (_) {}
        n = Number(v.length) || 0;
        for (i = 0; i < n; i++) { try { out.push(v[i]); } catch (_) {} }
        return out;
    }
    function skillOf(sk) {
        var d = callOr(sk, "getDefinition", null) || {}, lv = null;
        try { lv = d.level_vector; } catch (_) {}
        var max = 0; try { max = Number(lv && lv.length) || 0; } catch (_) {}
        return { id: Number(callOr(sk, "getId", d.id)), name: String(callOr(sk, "getName", d.name_string) || d.name_string || ""),
                 level: Number(callOr(sk, "getLevel", 0)) || 0, position: callOr(sk, "getPosition", d.position),
                 max: max, pointType: String(d.skillPointType_string || callOr(sk, "getSkillPointType_string", "") || ""),
                 booksNeeded: Number(d.numPointsAccumulated) || 0, minimumLevel: Number(d.minimumLevel) || 0,
                 trait: !!callOr(sk, "isTrait", false), resource: String(d.concerningResource_string || "") };
    }
    var BASE_KIND = { 0: "general", 1: "explorer", 2: "geologist", 12: "transporter", 18: "admiral" };   // 0.2.26 (live)
    var skillsCache = { at: 0, list: [], byId: {} };
    function specialistSkills() {
        var out = [], zone = null;
        try { zone = game.gi.mCurrentPlayerZone; } catch (_) {}
        if (!zone) try { zone = game.zone; } catch (_) {}
        var list = [];
        try { if (zone && typeof zone.GetSpecialists_vector === "function") list = vecToArray(zone.GetSpecialists_vector()); } catch (_) {}
        list.forEach(function (it) {
            if (!it) return;
            var base = Number(callOr(it, "GetBaseType", 0)) || 0, tree = null;
            try { tree = typeof it.getSkillTree === "function" ? it.getSkillTree() : it.skillTree; } catch (_) {}
            var rec = { id: "", name: "", type: Number(callOr(it, "GetType", 0)) || 0, base: base, kind: BASE_KIND[base] || ("base " + base), skills: [] };
            try { rec.id = specDotId(it); } catch (_) {}
            try { rec.name = it.getName ? String(it.getName(false)) : String(specName(it)); } catch (_) {}
            if (tree) {
                var def = callOr(tree, "getDefinition", null);
                try { rec.tree = def ? { id: def.id, name: String(def.name_string || ""), maxPoints: Number(def.maxPoints) || 0 } : null; } catch (_) {}
                rec.points = Number(callOr(tree, "getSumPoints", 0)) || 0;
                rec.code = String(callOr(tree, "GetSkillsString", "") || "");
                vecToArray(callOr(tree, "getItems_vector", null)).forEach(function (sk) { try { rec.skills.push(skillOf(sk)); } catch (_) {} });
            } else rec.noTree = true;
            if (rec.tree && rec.tree.name) rec.kind = String(rec.tree.name);          // 0.2.26: the tree names the kind
            out.push(rec);
        });
        skillsCache = { at: Date.now(), list: out, byId: {} };
        out.forEach(function (r) { if (r.id) skillsCache.byId[r.id] = r; });
        return out;
    }
    function skillsList(maxAgeMs) {
        if (!skillsCache.list.length || Date.now() - skillsCache.at > (maxAgeMs || 60000)) { try { specialistSkills(); } catch (_) {} }
        return skillsCache.list;
    }
    function skillsOf(id) { skillsList(600000); return skillsCache.byId[String(id)] || null; }
    function hasSkill(id, name) {                                // null = unknown (no tree read), else true / false
        var r = skillsOf(id); if (!r || r.noTree) return null;
        for (var i = 0; i < r.skills.length; i++) if (r.skills[i].name === name) return r.skills[i].level > 0;
        return false;
    }
    function writeSkillsFile() {
        if (visitHeld()) return;   // 0.2.52 (ADR 0030)
        try {
            var a = (typeof air !== "undefined") ? air : root.air; if (!a) return false;
            var all = specialistSkills();
            var f = a.File.applicationDirectory.resolvePath("dma-skills.json"), file = new a.File(f.nativePath);
            var st = new a.FileStream(); st.open(file, a.FileMode.WRITE);
            st.writeUTFBytes(JSON.stringify({ format: "dma-skills/1", version: VERSION, at: new Date().toISOString(), specialists: all }, null, 1)); st.close();
            log("skills: " + all.length + " specialists written");
            return true;
        } catch (e) {
            log("skills: " + e);
            try { var a2 = (typeof air !== "undefined") ? air : root.air, f2 = a2.File.applicationDirectory.resolvePath("dma-skills.json"), fl2 = new a2.File(f2.nativePath), st2 = new a2.FileStream();
                  st2.open(fl2, a2.FileMode.WRITE); st2.writeUTFBytes(JSON.stringify({ format: "dma-skills/1", version: VERSION, at: new Date().toISOString(), error: String(e) })); st2.close(); } catch (_) {}
            return false;
        }
    }
    try { if (typeof setTimeout === "function") { setTimeout(writeSkillsFile, 60000); setInterval(writeSkillsFile, 600000); } } catch (_) {}   // 0.2.25

    /* 0.2.61: self-restart — the loader's own relaunch (index.html runNewApplication): a new client process with the
       session's flexid + authrandom, so no login and no PLAY; then this process exits. Requested by the console or by
       a remote session through dma-restart-request.json {at, reason}. */
    var LOADED_AT = Date.now(), RESTART_MIN_UPTIME = 5 * 60 * 1000, RESTART_MAX_AGE = 15 * 60 * 1000;
    function restartUrl(raw, flexid, auth, win) {
        var o = {}, k; for (k in (raw || {})) if (raw.hasOwnProperty(k) && k !== "zoneid") o[k] = raw[k];
        if (win && win !== "same") o.window = win;
        o.flexid = flexid; o.authrandom = auth;
        return "tso://?" + Object.keys(o).map(function (x) { return x + "=" + o[x]; }).join("&");
    }
    /* the client's WebKit may not parse ISO dates: read "YYYY-MM-DDTHH:MM:SS(.sss)Z" by hand */
    function parseIso(t) {
        var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?Z$/.exec(String(t || ""));
        return m ? Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6], m[7] ? +String(m[7] + "00").slice(0, 3) : 0) : NaN;
    }
    function restartStatus(obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("dma-restart-status.json").nativePath), st = new a.FileStream();
              st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (_) {}
    }
    /* 0.2.90: restart trace (F3/F4) */
    var RESTART_LOG = "dma-restart-log.jsonl";
    function appendLine(name, obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath), st = new a.FileStream();
              st.open(f, a.FileMode.APPEND != null ? a.FileMode.APPEND : a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj) + "\n"); st.close(); return true; } catch (_) { return false; }
    }
    function airId() {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("META-INF/AIR/application.xml").nativePath), st = new a.FileStream();
              st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); var m = /<id>([^<]+)<\/id>/.exec(String(t)); return m ? m[1] : null; } catch (_) { return null; }
    }
    function restartTrace(obj) { obj.at = obj.at || new Date().toISOString(); obj.version = VERSION; return appendLine(RESTART_LOG, obj); }
    try { var lastLoad = Date.now(); restartTrace({ phase: "loaded", at: new Date(lastLoad).toISOString(), id: airId() }); } catch (_) {}
    function restartClient(reason, now, by) {
        now = now || Date.now();
        if (now - LOADED_AT < RESTART_MIN_UPTIME) return { ok: false, reason: "client up less than 5 minutes" };
        if (blueTask.current) return { ok: false, reason: "blue work running: " + blueTask.current.kind };
        try { var hd0 = restartHold(now); if (hd0.active && (hd0.active.unreadable || !(by && hd0.active.by === String(by)))) return { ok: false, reason: "restart hold by " + hd0.active.by }; } catch (_) {}   // 0.2.87; 0.2.90 the owner passes
        try {
            var a = (typeof air !== "undefined") ? air : root.air, w = root.runtime || (typeof window !== "undefined" ? window.runtime : null), G = root.game;
            var flexid = G.def("mx.messaging::FlexClient").getInstance().id, auth = G.def("defines").CLIENT_AUTHRANDOM;
            var idBefore = airId(), renewErr = "";   // 0.2.90
            try { if (typeof root.updateApplication === "function") root.updateApplication(); else renewErr = "no updateApplication"; } catch (eU) { renewErr = String(eU); }   // the loader renews the AIR app id, as it does itself
            var idAfter = airId();
            var exe = w.flash.system.Capabilities.cpuAddressSize == 32 ? "client.exe" : "client64.exe";
            var info = new w.flash.desktop.NativeProcessStartupInfo(); info.executable = a.File.applicationDirectory.resolvePath(exe);
            var args = new w.Vector["<String>"](); args[0] = restartUrl(root.rawArgs, flexid, auth, root.mainSettings && root.mainSettings.mwWindowSize); info.arguments = args;
            restartStatus({ at: new Date(now).toISOString(), reason: String(reason || ""), version: VERSION, state: "restarting" });
            log("restart: " + reason);
            restartTrace({ phase: "restart", at: new Date(now).toISOString(), reason: String(reason || ""), by: by ? String(by) : "dma",
                           uptimeSec: Math.round((now - LOADED_AT) / 1000), idBefore: idBefore, idAfter: idAfter,
                           renewed: !!(idBefore && idAfter && idBefore !== idAfter), renewError: renewErr, exe: exe });   // 0.2.90
            new w.flash.desktop.NativeProcess().start(info);
            setTimeout(function () { try { w.flash.desktop.NativeApplication.nativeApplication.exit(0); } catch (_) {} }, 1000);
            return { ok: true };
        } catch (e) { restartStatus({ at: new Date(now).toISOString(), reason: String(reason || ""), version: VERSION, state: "failed", error: String(e) }); return { ok: false, reason: String(e) }; }
    }
    function restartWatch(now) {
        try { return restartWatch1(now); }
        catch (e) { restartStatus({ at: new Date().toISOString(), version: VERSION, state: "watch-error", error: String(e) }); log("restart watch: " + e); return null; }
    }
    /* 0.2.86: dma-restart-hold.json {holds: [{by, why, setAt, until}]} — the first active hold and when the last one ended */
    function restartHold(now) {
        var out = { active: null, lastEnd: 0 }, h = null, a, f;
        /* 0.2.94 (architect rule A6): a hold file that exists but cannot be read — empty (0 bytes, mid-write), not JSON,
           or without a holds list — counts as HELD, for one minute at a time, until it can be read again */
        function unreadable(why) { out.active = { by: "unreadable hold file", why: why, untilMs: now + 60000, unreadable: true }; out.lastEnd = now; return out; }
        try { a = (typeof air !== "undefined") ? air : root.air; f = new a.File(a.File.applicationDirectory.resolvePath("dma-restart-hold.json").nativePath); }
        catch (_) { return out; }   // no file API: no hold file can exist
        try { if (!f.exists) return out; } catch (eE) { return unreadable("cannot check the file: " + eE); }
        try { var st = new a.FileStream(); st.open(f, a.FileMode.READ); var txt = st.readUTFBytes(st.bytesAvailable); st.close();
              if (!/\S/.test(String(txt || ""))) return unreadable("the file is empty");
              h = JSON.parse(txt); } catch (eR) { return unreadable("not readable: " + String(eR).slice(0, 80)); }
        if (!h || typeof h !== "object" || Object.prototype.toString.call(h) === "[object Array]") return unreadable("no holds list");
        var list = h.holds;
        if (list == null) {   // 0.2.97: a single flat hold object is that hold; anything else without a list is held
            if (h.until != null || h.untilMs != null) list = [h];
            else return unreadable("no holds list");
        }
        if (Object.prototype.toString.call(list) !== "[object Array]") return unreadable("no holds list");
        list.forEach(function (x) {
            var until = Number(x && x.untilMs) || parseIso(x && x.until), set = Number(x && x.setAtMs) || parseIso(x && x.setAt) || 0;
            if (!(until > 0)) return;
            if (set > 0) until = Math.min(until, set + 6 * 3600 * 1000);
            if (until > now) { if (!out.active || until > out.active.untilMs) out.active = { by: String(x.by || "?"), why: String(x.why || ""), untilMs: until }; }
            else if (until > out.lastEnd) out.lastEnd = until;
        });
        return out;
    }
    function restartWatch1(now) {
        now = now || Date.now();
        var req = null;
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("dma-restart-request.json").nativePath);
              if (!f.exists) return null; var st = new a.FileStream(); st.open(f, a.FileMode.READ); req = JSON.parse(st.readUTFBytes(st.bytesAvailable)); st.close(); }
        catch (e) { restartStatus({ at: new Date(now).toISOString(), version: VERSION, state: "read-error", error: String(e) }); return null; }
        if (req && req.handled) return null;   // 0.2.64
        var at = Number(req && req.atMs) || parseIso(req && req.at);
        if (!(at > 0)) { restartStatus({ at: new Date(now).toISOString(), version: VERSION, state: "bad-request", why: "no at / atMs", got: String(req && req.at) }); return null; }
        var done = 0; try { done = Number(root.localStorage.getItem("dma.restart.handled")) || 0; } catch (_) {}
        var hold = restartHold(now);   // 0.2.86: another session asked not to be interrupted
        if (hold.active && (hold.active.unreadable || !(req.by && hold.active.by === String(req.by)))) { if (at > done) restartStatus({ at: new Date(now).toISOString(), reason: String(req.reason || ""), version: VERSION, state: "held", by: hold.active.by, why: hold.active.why, until: new Date(hold.active.untilMs).toISOString() }); return null; }
        if (at <= done || now - Math.max(at, hold.lastEnd) > RESTART_MAX_AGE) { if (at > done) restartStatus({ at: new Date(now).toISOString(), version: VERSION, state: "ignored", why: "request older than 15 min" }); return null; }
        /* 0.2.67 (live: "je was te vroeg de laatste generaals waren nog niet weggestuurd" — "als alle generaal weggestuurd
           zijn, kun je veilig rebooten"): wait while the adventure run sends generals or its attack queue runs */
        try { var AV = root.DMA_Adventure; if (AV && typeof AV.restartSafe === "function" && !AV.restartSafe()) { restartStatus({ at: new Date(now).toISOString(), reason: String(req.reason || ""), version: VERSION, state: "waiting", why: "the adventure is sending generals or attacks" }); return null; } } catch (_) {}
        /* 0.2.64: the loader gives every restart a new AIR id, so localStorage (dma.restart.handled) starts empty and the
           same request restarted the client again every 5 minutes until it was 15 minutes old. Mark the file handled
           before restarting. */
        try { var a2 = (typeof air !== "undefined") ? air : root.air, f2 = new a2.File(a2.File.applicationDirectory.resolvePath("dma-restart-request.json").nativePath), st2 = new a2.FileStream();
              var h = {}; for (var hk in req) if (req.hasOwnProperty(hk)) h[hk] = req[hk]; h.handled = true; h.handledAt = new Date(now).toISOString();
              if (now - LOADED_AT >= RESTART_MIN_UPTIME && !blueTask.current) { st2.open(f2, a2.FileMode.WRITE); st2.writeUTFBytes(JSON.stringify(h)); st2.close(); } } catch (_) {}
        var r = restartClient(req.reason || "remote request", now, req.by);
        if (r.ok) try { root.localStorage.setItem("dma.restart.handled", String(at)); } catch (_) {}
        else restartStatus({ at: new Date(now).toISOString(), reason: String(req.reason || ""), version: VERSION, state: "waiting", why: r.reason });
        return r;
    }
    /* 0.2.80 STALE WATCH — see the header: the game stops carrying anything out while the scripts run on */
    var STALE_FILE = "dma-stale.json", stale = { sum: null, since: 0, lastHeld: null };
    function stockChecksum() {
        try {
            var bag = game.getResources && game.getResources(); if (!bag || !bag.GetResourceAmount) return null;
            var s = 0; ["Stone", "Plank", "Tool", "Coal", "Iron", "Gold", "Bread", "Sausage"].forEach(function (r) { try { s += Number(bag.GetResourceAmount(r)) || 0; } catch (_) {} });
            return s;
        } catch (_) { return null; }
    }
    function staleFile(obj) {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath(STALE_FILE).nativePath), st = new a.FileStream();
              if (obj) { st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return obj; }
              if (!f.exists) return {}; st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t) || {}; } catch (_) { return obj ? null : {}; }
    }
    /* 0.2.111: is anything switched on that the game could fail to carry out? (unknown policy = yes, as before) */
    function automationOn() {
        try {
            var p = root.GCAF_PlayerPolicyInstance, PP = root.GCAF_PlayerPolicy, i, adv = ["ae", "ywc", "vlt", "ft", "own", "gp"];
            if (!p || !p.get || !PP || !PP.SWITCHES) return true;
            for (i = 0; i < PP.SWITCHES.length; i++) if (p.get(PP.SWITCHES[i].key) === true) return true;
            if (p.get("zombie.auto") === true) return true;
            var pr = p.get("premium.setting"); if (pr && pr !== "off") return true;
            for (i = 0; i < adv.length; i++) if (p.get("adv." + adv[i] + ".on") === true) return true;
            return false;
        } catch (_) { return true; }
    }
    function staleWatch(now) {
        now = now || Date.now();
        var min = Number(polVal("control.staleRestartMin", 10));
        if (!(min > 0)) { stale.sum = null; return { state: "off" }; }
        var self = polVal("control.selfRestart.on", false) === true;   // 0.2.113 (ADR 0083): the player's choice, off by default
        if (!automationOn()) { stale.sum = null; return { state: "no automation on" }; }   // 0.2.111
        if (!atHome()) { stale.sum = null; return { state: "away or visit hold" }; }   // atHome() is false during a visit hold
        var s = stockChecksum(); if (s == null) return { state: "no stock" };
        if (s !== stale.sum) { stale.sum = s; stale.since = now; stale.lastHeld = null; return { state: "moving" }; }
        var mins = (now - stale.since) / 60000;
        if (mins < min) return { state: "unchanged", minutes: Math.floor(mins) };
        if (!self) return { state: "unchanged, self-restart off", minutes: Math.floor(mins) };   // 0.2.113: counted (staleMinutes), never restarted
        var f = staleFile() || {}, last = Number(f.lastRestartAt) || 0;
        if (now - last < 60 * 60000) return { state: "held", why: "a stale restart less than an hour ago", minutes: Math.floor(mins) };
        try { var AV = root.DMA_Adventure; if (AV && typeof AV.restartSafe === "function" && !AV.restartSafe()) return { state: "held", why: "the adventure is sending generals or attacks" }; } catch (_) {}
        var why = "client stale: stock unchanged for " + Math.floor(mins) + " min";
        log(why);
        var r = restartClient(why, now);
        var result = r && r.ok ? "restarting" : "held", heldWhy = r && !r.ok ? String(r.reason || "restart failed") : "";
        if (result === "restarting" || heldWhy !== stale.lastHeld) {   // 0.2.90 (F5): once per outcome, with the real result
            stale.lastHeld = heldWhy;
            try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "client stale", minutes: Math.floor(mins), stock: s, result: result, why: heldWhy || undefined }); } catch (_) {}
        }
        if (result === "restarting") { staleFile({ lastRestartAt: now, minutes: Math.floor(mins), stock: s }); return { state: "restarting", minutes: Math.floor(mins) }; }
        return { state: "held", why: heldWhy };
    }
    /* 0.2.113: how long the stock has stood still (0 when it moves, away, or nothing is on) - a second signal for the agents' suspicion */
    function staleMinutes(now) { now = now || Date.now(); return stale.sum == null || !stale.since ? 0 : Math.floor((now - stale.since) / 60000); }
    try { if (!root.DMA_STALE_NO_TIMER) setInterval(function () { try { staleWatch(); } catch (_) {} }, 60000); } catch (_) {}
    /* 0.2.93 (review 2026-11-16 finding #1): the keep-awake, the alive file, the relaunch command and the Windows
       scheduled task left control for the opt-in tool src/tools/user_dma_watchdog.js (rules control.watchdog and
       control.keepAwake, default off). Control writes no login token to disk; a plain dma-relaunch.cmd that 0.2.92
       left next to the client holds this session's authrandom, so it is removed once at load. */
    function dropPlainRelaunch() {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("dma-relaunch.cmd").nativePath);
              if (!f.exists) return "none"; f.deleteFile(); return "removed"; } catch (e) { return "failed: " + e; }
    }
    var plainRelaunch = "none";
    try { plainRelaunch = dropPlainRelaunch(); if (plainRelaunch !== "none") log("0.2.93 plain dma-relaunch.cmd: " + plainRelaunch); } catch (_) {}
    var restartTicks = 0;
    try { setInterval(function () { if (restartTicks++ === 0) restartStatus({ at: new Date().toISOString(), version: VERSION, state: "watching" }); restartWatch(); }, 30000); } catch (e) { log("restart timer: " + e); }

    var api = {
        plainRelaunch: function () { return plainRelaunch; },   // 0.2.93: what happened to a 0.2.92 dma-relaunch.cmd at load
        onServerAction: function (fn) { if (typeof fn === "function" && actionWatchers.indexOf(fn) < 0) actionWatchers.push(fn); return actionWatchers.length; },   // 0.2.69
        version: VERSION,
        travel: function () { return JSON.parse(JSON.stringify(travel)); },   // 0.2.48
        quiet: function () { return quiet(); }, lastActionAt: function () { return lastActionAt; },   // 0.2.56
        blue: { submit: blueSubmit, tick: blueTick, list: function () { return blueTask.list.map(function (t) { return { kind: t.kind, by: t.by, at: t.at }; }); },
                current: function () { var c = blueTask.current; return c ? { kind: c.kind, by: c.by, startedAt: c.startedAt } : null; }, last: function () { return JSON.parse(JSON.stringify(blueTask.last)); } },   // 0.2.56
        visit: { request: requestVisit, close: releaseVisit, held: function () { return visitHeld(); }, state: function () { return JSON.parse(JSON.stringify(hold)); }, watch: travelWatch },   // 0.2.51; watch 0.2.53
        lastBlock: function () { return lastBlockInfo ? JSON.parse(JSON.stringify(lastBlockInfo)) : null; },   // 0.2.103
        wrapper: function () { return JSON.parse(JSON.stringify(wrapState)); },   // 0.2.102: is the wrapper really in the send path?
        atHome: atHome,                                                   // 0.2.39
        rtAwayOk: rtAwayOk, snapStock: snapStock, homeStock: function () { return { at: homeStock.at ? new Date(homeStock.at).toISOString() : null, n: Object.keys(homeStock.map).length }; },   // 0.2.66
        kinds: function () { return JSON.parse(JSON.stringify(KINDS)); },
        upgradableKind: function (name) { return kindOf(name); },
        maxLevel: function (name) { return maxLevelOf(String(name || ""), null); },   // 0.2.95 (ELS-33)
        maxLevelRegistered: function () { return JSON.parse(JSON.stringify(MAX_LEVEL_REGISTERED)); },   // 0.2.95: for the watcher test
        guardUpgrade: guardUpgrade,
        levelOf: realLevelOf,            // 0.2.19: the real level (never only the UI overwrite)
        refusals: function () { return refusals.slice(); },
        trade: { mailWindow: function () { return !!mailWindow(); }, mails: mailsList, tradeOfMail: tradeOfMail,
                 mailPanelReady: mailPanelReady, mailProbe: mailProbe, declineTradeMails: declineTradeMails, lootMails: lootMails, lootCounts: lootCounts, guildMember: guildMember, sendFriendTrade: sendFriendTrade, tradeOutcomes: tradeOutcomes, acceptReturnTrade: acceptReturnTrade, have: have, storageOf: storageOf, resourceList: resourceList, acceptOneTrade: acceptOneTrade, collectLootMails: collectLootMails, ensureMailPanel: ensureMailPanel, closeMailPanelIfOurs: closeMailPanelIfOurs, closeMailPanel: closeMailPanel, mailWindowOpen: mailWindowOpen, mailWatchdog: mailWatchdog, openMailWindow: openMailWindow, closeMailWindow: closeMailWindow, mailOpen: function () { return mailOpenedByUs ? "us" : (mailPanelReady() ? "player" : ""); },
                 requestInboxHeaders: requestInboxHeaders, requestMailBody: requestMailBody,
                 guardRoundTrade: guardRoundTrade, acceptRoundTrade: acceptRoundTrade, guardRoundSet: guardRoundSet, acceptRoundSet: acceptRoundSet, netOf: netOf, MAIL_TRADE: MAIL_TRADE },
        overall: OVERALL,
        suiteVersion: SUITE_VERSION,
        phase: PHASE,
        listPbcs: listPbcs,
        pbcStatus: pbcStatusText,
        maxLocations: DEFAULT_MAX,
        permit: permit,
        scan: scan,
        map: function () { return map; },
        finds: function () { return { scannedAt: lastFinds.scannedAt, at: lastFinds.at, home: lastFinds.home, collectibles: lastFinds.collectibles.slice(), triggers: lastFinds.triggers.slice(), pickups: (lastFinds.pickups || []).slice() }; },   // 0.2.42; 0.2.82 pickups
        summary: summary,
        blocked: function () { return clone(blocked); },
        wrapNow: function () {
            wrapSettings();
            return wrapCommits(true);
        },
        sendBronze: function () { return sendSearch("BronzeOre"); },
        sendSearch: sendSearch,
        verifySearch: verifySearch, searchHeld: searchHeld,   // 0.2.107 (ADR 0074 step 4)
        predictSearch: predictSearch,
        sendBuild: sendBuild,
        buildCosts: function (r) { var c0 = BUILD_COSTS[r], o = {}, k; if (c0) for (k in c0) if (c0.hasOwnProperty(k)) o[k] = c0[k]; return o; },   // 0.2.114 (ADR 0084)
        queueNow: queueNow,
        queuedBuildNeeds: queuedBuildNeeds,   // 0.2.45
        allocate: allocate,                                                       // 0.2.98 (v3.17): TK60 for a troop order
        allocation: { get: function (id) { return allocView(allocations[id]); }, recheck: recheck, release: releaseAlloc,
                      list: function () { return Object.keys(allocations).map(function (k) { return allocView(allocations[k]); }); },
                      batches: function () { var o = openBatches(); try { var S = root.DMA_SupplyManager; if (supplyReady() && typeof S.batches === "function") o = o.concat(S.batches()); } catch (_) {} return o; } },   // 0.2.98; 0.2.99: batches (the player's notice)
        promiseBuild: function (r) { var p = promiseBuildResources(r); if (p && p.release) p.release(); return p ? { fact: p.fact, reason: p.reason, missing: p.missing, via: p.via } : null; },   // 0.2.45: a dry run, released at once
        hasBuildOrder: function (grid) { return !!recentBuildGrids[String(grid)] || gridSkipped(grid); },   // 0.2.59: a skipped grid counts as busy
        buildOrder: buildOrder,
        retractBuild: retractBuild,
        allocateGeo: allocateGeo,
        allocatedFor: allocatedFor,
        releaseGeo: releaseGeo,
        isReserved: isReserved,
        sendUpgrade: sendUpgrade,
        sendBuff: sendBuff,
        sendDemolish: sendDemolish,
        searchNext: function () {
            var r = firstUnderCap();
            if (!r) return { ok: false, error: "none under cap or no idle geo" };
            return sendSearch(r);
        },
        assessAll: assessAllResources,
        idleGeologists: collectIdleGeologists,
        geologists: listGeologists,
        bronzeRoster: geoRosterText,
        specialistSkills: specialistSkills,     // 0.2.24
        pickGeoFor: function (r) { return pickGeoFor(r, false); },   // 0.2.41: read only (which geologist a search would take)
        skillsList: skillsList, skillsOf: skillsOf, hasSkill: hasSkill,   // 0.2.26
        writeSkillsFile: writeSkillsFile,
        restart: { now: restartClient, watch: restartWatch, url: restartUrl, parseIso: parseIso, staleWatch: staleWatch, staleMinutes: staleMinutes }   // 0.2.61; parseIso 0.2.63; staleWatch 0.2.80
    };

    /* 0.2.71 REPAIR (incident 2026-11-01) — RETIRED in 0.2.96 (CL-51a rejected; ELS-33): a verified mine above its
       maximum level that the game does not define is only NOTICED (fact "corrupt mine noticed", once per grid; status in
       dma-repair-status.json, state "notice only"). Nothing is demolished; control.repairCorrupt is not read. */
    var repairState = { at: null, state: "notice only", found: [], noticed: [], reason: "" }, repairNoticed = {};
    function repairWrite() {
        try { var a = (typeof air !== "undefined") ? air : root.air, f = new a.File(a.File.applicationDirectory.resolvePath("dma-repair-status.json").nativePath), st = new a.FileStream();
              st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(repairState, null, 1)); st.close(); } catch (_) {}
    }
    function corruptMines() {
        var out = [];
        try {
            var sd = game.gi.mCurrentPlayerZone.mStreetDataMap, v = sd.GetBuildings_vector(), i;
            for (i = 0; i < v.length; i++) {
                var b = v[i]; if (!b) continue;
                var nm = nameOf(b), k = kindOf(nm);
                if (!k || k.upgrade === false) continue;   // 0.2.95: was !(k.maxLevel > 0) (the endless mine)
                var mxC = maxLevelOf(nm, b); if (!(mxC > 0)) continue;
                var lv = null;                                   // 0.2.78 (R3): the real level only, never the UI level
                try { if (typeof b.GetUpgradeLevel === "function") lv = Number(b.GetUpgradeLevel()); } catch (_) { lv = null; }
                if (!(lv >= 0)) continue;
                if (!(lv > mxC)) continue;
                if (typeof b.GetUpgradeLevelBonusesForLevel !== "function") continue;           // the game cannot confirm: never demolish
                var def = null; try { def = b.GetUpgradeLevelBonusesForLevel(lv); } catch (_) { def = "unknown"; }
                if (def != null) continue;                                                     // the game defines this level: not corrupt
                var up = callBool(b, "IsUpgradeInProgress");
                out.push({ grid: Number(b.GetGrid()), name: nm, level: lv, max: mxC, upgrading: up !== false });   // unknown counts as running: wait
            }
        } catch (_) {}
        return out;
    }
    function repairTick(now) {   // 0.2.96: detection only — a notice, never an act
        now = now || Date.now();
        repairState.at = new Date(now).toISOString();
        if (!atHome()) { repairState.reason = "not at home / visit hold"; repairWrite(); return repairState; }
        var found = corruptMines();
        repairState.found = found; repairState.reason = found.length ? "corrupt mine(s) on the island: reported to the player, not demolished (CL-51a rejected)" : "no corrupt mines";
        found.forEach(function (c) {
            if (repairNoticed[c.grid]) return;
            repairNoticed[c.grid] = now;
            repairState.noticed.push({ at: repairState.at, grid: c.grid, name: c.name, level: c.level, max: c.max });
            if (repairState.noticed.length > 20) repairState.noticed.shift();
            try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { fact: "corrupt mine noticed", name: c.name, grid: c.grid, level: c.level, max: c.max, act: "none" }); } catch (_) {}
            log("DMA Control " + VERSION + " NOTICE corrupt mine " + c.name + " @" + c.grid + " level " + c.level + " > " + c.max + ": reported, not demolished");
        });
        repairWrite();
        return repairState;
    }
    api.upgradeWatch = upgradeWatch;   // 0.2.79
    api.releaseUpgradeOrder = function (grid) {   // 0.2.85: only an order the game never started
        try {
            var l = ledger(); if (!l) return { ok: false, reason: "upgrade ledger unreadable" };
            var led = l[String(grid)]; if (!led) return { ok: true, reason: "no order in the ledger" };
            var b = buildingAt(grid); if (!b) return { ok: false, reason: "no building on the grid" };
            var up = false; try { up = !!(typeof b.IsUpgradeInProgress === "function" && b.IsUpgradeInProgress()); } catch (_) { up = true; }
            var st = 0; try { st = typeof b.GetUpgradeStartTime === "function" ? Number(b.GetUpgradeStartTime()) || 0 : 0; } catch (_) { st = 1; }
            if (up || st > 0) return { ok: false, reason: "an upgrade is running" };
            var lv = levelOf(b);
            if (Number(lv) !== Number(led.level)) return { ok: false, reason: "the level changed (" + led.level + " -> " + lv + ")" };
            ledgerDrop(grid);
            return { ok: true, reason: "order released: the game never started it" };
        } catch (e) { return { ok: false, reason: String(e).slice(0, 120) }; }
    };
    try { setInterval(function () { try { if (atHome()) upgradeWatch(); } catch (_) {} }, 20000); } catch (_) {}
    api.repair = { tick: repairTick, corruptMines: corruptMines, status: function () { return JSON.parse(JSON.stringify(repairState)); } };
    try { setTimeout(function () { try { repairTick(); } catch (_) {} }, 240000); setInterval(function () { try { repairTick(); } catch (_) {} }, 120000); } catch (_) {}

    root.DMA_Control = api;
    wrapSettings();
    try { if (polVal("location.startup.holdSec", 180) > 0) requestVisit("startup", "the home island is loading"); } catch (_) {}   // 0.2.54

    var inBrowser = typeof document !== "undefined";
    if (inBrowser) {
        var tries = 0;
        var timer = setInterval(function () {
            tries += 1;
            wrapSettings();
            var ok = wrapCommits();
            if (ok || tries > 40) {
                if (ok) {
                    try { scan(); } catch (_) {}
                    log("DMA Control " + VERSION + " armed suite " + SUITE_VERSION);

                }
                if (ok || tries > 40) clearInterval(timer);
            }
        }, 500);

        setInterval(function () {
            try { scan(); } catch (_) {}
        }, SCAN_MS);

        /* 0.2.82: the events that change what is waiting to be picked up start a scan (at most one per 5 s) */
        var eventScanAt = 0, eventScanTimer = null, eventsHooked = false;
        function eventScan(why) {
            if (eventScanTimer) return;
            var wait = Math.max(0, eventScanAt + 5000 - Date.now());
            eventScanTimer = setTimeout(function () { eventScanTimer = null; eventScanAt = Date.now(); try { scan(); } catch (_) {} }, wait + 500);
        }
        function hookEvents() {
            if (eventsHooked) return true;
            try {
                var g = (typeof game !== "undefined") ? game : root.game;
                if (!g || !g.gi || !g.gi.channels || typeof g.getTracker !== "function") return false;
                [["TIMED_PRODUCTION", "timedProducedItems"], ["ZONE", "COLLECTIBLES_UPDATED"]].forEach(function (x) {
                    var c = g.gi.channels[x[0]];
                    if (c && typeof c.addPropertyObserver === "function") c.addPropertyObserver(x[1], g.getTracker("dmaControl_" + x[0] + "_" + x[1], function () { eventScan(x[1]); }));
                });
                eventsHooked = true; log("pickup events hooked");
                return true;
            } catch (e) { log("pickup events " + e); return false; }
        }
        var hookTries = 0, hookTimer = setInterval(function () { hookTries += 1; if (hookEvents() || hookTries > 60) clearInterval(hookTimer); }, 5000);

        setInterval(function () { try { travelWatch(); } catch (_) {} try { mailWatchdog(); } catch (_) {} try { blueTick(); } catch (_) {} }, 1000);   // 0.2.53: automatic visit hold; 0.2.55: close our mail window

        function managerTick() {
            try {
                if (visitHeld()) return;   // 0.2.51
                if (root.DMA_Demo && typeof root.DMA_Demo.tick === "function") root.DMA_Demo.tick();
            } catch (e) { log("manager tick " + e); }
        }
        if (!root.__DMA_MANAGER_TIMER) {
            root.__DMA_MANAGER_TIMER = setInterval(managerTick, 30000);
            setTimeout(managerTick, 8000);
            log("DMA manager loop 30s");
        }

        var pruneTries = 0;
        var pruneTimer = setInterval(function () {
            pruneTries += 1;
            pruneToolsMenu();
            if (pruneTries > 20) clearInterval(pruneTimer);
        }, 500);

        if (typeof addToolsMenuItem === "function") {
            try { addToolsMenuItem("DMA Console", function () { if (root.DMA_openConsole) root.DMA_openConsole(); }); } catch (_) {}
        }
    }

    log("DMA Control " + VERSION + " loaded suite " + SUITE_VERSION);
})(typeof window !== "undefined" ? window : this);
