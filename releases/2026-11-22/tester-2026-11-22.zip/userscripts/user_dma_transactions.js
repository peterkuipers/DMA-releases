/*
 * Stable client filename: user_dma_transactions.js
 * DMA Transactions 0.4.19 — GREEN remembers the coordination facts (C-facts) of every transaction; BLUE records them.
 * 0.4.20 (2026-11-17, UAT 2026-11-17 finding F6, the live checker's I6: "many TK41 cases in state declined for 13-19 h"): a declined instance is archived when it is not renewed within an hour (0.4.3), but the initiator that
 *   renews its request after every decline (the construction manager asks again every 10 minutes, the buff applier declines again: "no accepted buff in the star menu") refreshed tx.at each time, so "not renewed" never held and
 *   the one instance rested in "declined" for 13-19 hours with its first request as "since". Now the book keeps when the discussion began (tx.discAt: the first decline or reject since the instance last made progress; a promise or an
 *   accept ends the discussion) and archives a declined or rejected instance whose discussion has lasted an hour, whether it was renewed or not - archived: "declined again and again for 60 min" (no act is invented); the next request
 *   starts a new instance with its own "since". An instance restored from a book written before 0.4.20 has no mark: with more than one decline or reject in its history it counts from its first request, so a restored case closes
 *   at the first sweep too. A discussion shorter than an hour, a declined instance renewed and then promised (progress), and TK-specific limits are unchanged; the live limits of check_release_invariants.py I6 (TK41 2 h, TK61 2 h) are met.
 *   Unit: tests/unit/dma-transactions-declined-loop.test.js (a request renewed every 10 min and declined every time is archived after an hour with its reason and the next request is a new instance; a case that gets its promise is
 *   not; a book written before 0.4.20 with a declined loop closes at the first sweep). Integration: tests/integration/dma-tk41-declined-loop-closes.test.js (real policy, green and agents: a mine whose buff is declined and asked for again every 10 minutes for three hours never stays in the active document longer than 80 min).
 * 0.4.19 (2026-11-16, ADR 0077 / backbone v3.21; CLAUDE.md: a change to a transaction kind updates its live checks in the same PR; author 2026-11-16 "ja"): TK73 "search order completing" (product
 *   "[search order] is completed", executor AR73 the explorer manager, requested by AR71 the quest manager) gets its name in the book. Expected age 360 min (six hours: a search of a
 *   quest task is sent at once and the longest adventure search is out for hours); the live limit of tests/live/check_release_invariants.py I6 is 26 h, as for TK71. Nothing else changes.
 *   Unit: tests/unit/dma-transactions-overview.test.js (TK73 is named; an order open 7 h is flagged, one open 1 h is not). Integration: tests/integration/live-limits-v317.test.js (the checker
 *   fails a TK73 open 30 h and accepts it open 10 h; the book's expected age is below the limit).
 * 0.4.18 (2026-11-16, author "ja": the four technical known-failing defects; tester kf-tx-rejected-flag): IN_PROGRESS was declared twice (requested, promised, declared; and again with "rejected"); the later one won, so the overview
 *   flagged a REJECTED instance "waiting longer than usual — check the game" against its own comment (declined / rejected are discussion states, shown, not flagged) and inProgress() answered a rejected instance. The second declaration is
 *   removed: one IN_PROGRESS (requested, promised, declared). No transaction kind changes (tests/live/check_release_invariants.py unchanged).
 *   Unit: tests/unit/tx-rejected-flag.test.js (moved from tests/known-failing/kf-tx-rejected-flag.test.js: a TK18 rejected 9 h ago and a declined one carry no check flag; inProgress() answers neither). Integration: tests/integration/live-limits-v317.test.js (the checker's limits
 *   against the same memory) and the whole-pack test stay green.
 * 0.4.17 (2026-11-16, ADR 0075 / backbone v3.19; coordinator batch item 3.8; CLAUDE.md: a change to a transaction kind updates its live checks in the same PR): TK66 "resource supply managing" (product "resource supply managing for
 *   [period] is done", executor AR66, self-activating, one period an hour) gets its name in the book; expected age 120 min, the live limit of tests/live/check_release_invariants.py I6 is 3 h. TK64 (named since 0.4.16) is now requested
 *   by AR66 (supply manager), no longer by the material allocator: its 48 h limit is unchanged. Nothing else changes.
 *   Unit: tests/unit/dma-transactions-overview.test.js (TK66 is named; a period open 4 h is flagged). Integration: tests/integration/live-limits-v317.test.js (the checker fails a TK66 open 4 h, accepts 1 h; its limit matches the book).
 * 0.4.16 (2026-11-16, author-requested TX page row for TK64; coordinator): TK64 "resource producing" (product "[production batch] is produced", the executor is the
 *   player's resource producer role AR64) gets its name in the book. Control 0.2.98/0.2.99 records TK64 acts (request / accept by the material allocator), which the
 *   book showed as "TK64" without a name. Expected age 48 h, the live limit of tests/live/check_release_invariants.py I6. Nothing else changes.
 *   Unit: tests/unit/dma-transactions-overview.test.js (TK64 is named in the overview). Integration: tests/integration/live-limits-v317.test.js (the live checker's TK64 limit
 *   matches the book's expected age).
 * 0.4.15 (2026-11-16, backbone v3.16 — ADR 0071 D-5, confirmed by the author 2026-11-16; reconciliation R-13): TK-EV
 *   "event filling" leaves KINDS. TK-EV is retired in the backbone: a fill is TK41 buff applying with buff sort "deposit
 *   filler" (event 0.2.13), so every kind the book names is now a transaction kind of the model. TK-EV was never a C-fact
 *   kind (the event manager wrote it as P-facts), so no instance is lost. Nothing else changes.
 *   Unit: tests/unit/dma-transactions-kinds.test.js (no kind outside the model). Integration:
 *   tests/integration/dma-tx-no-tk-ev.test.js (a fill recorded as event 0.2.13 records it appears under TK41 "buff
 *   applying"; a legacy TK-EV P-fact opens no instance; nothing foreign).
 * 0.4.14 (2026-11-16, architecture review 2026-11-16 finding #3 (High); ADR 0070, which supersedes the "dc and rj
 *   are not revocable" part of ADR 0038's 2026-11-01 correction; METHOD CHANGE — needs the author's approval): the
 *   complete transaction pattern has SIX revocations (EO2 ch. 8 abstract and §8.2.6.3–9; demo-pm PM-7), not four.
 *   Added: revoke decline (executor; condition: declined; allowed -> requested, from where the executor can promise) and
 *   revoke reject (initiator; condition: rejected; allowed -> declared, from where the initiator can accept); each is
 *   answered by allow | refuse, a refused one leaves the state. Both are DEMO 4 acts (no longer counted foreign). A
 *   discussion state with a revocation pending is not archived after 1 h (unchanged rule: !t.revoking). Leaving forward
 *   (renewed request after declined, renewed declare after rejected) is unchanged. No module writes the two acts yet.
 *   Unit: tests/unit/dma-transactions.test.js (rv-dc allowed -> requested, then promise; refused -> declined; rv-rj
 *   allowed -> declared, then accept; neither foreign). Integration: tests/integration/dma-six-revocations.test.js
 *   (DMA_Demo.record hooked; all six revocations through the facts path; the overview and the history document).
 * 0.4.13 (2026-11-10, backbone v3.14 RM-TO): TK25 is trade completing, "[set of trade] is completed"; TK23 trade
 *   preparing (the trade office) joins the tree. Names only. Unit: dma-transactions-kinds.test.js.
 * 0.4.12 (2026-11-10, backbone v3.14, ADR 0056 — SET is generic, BUFF is the entity type): TK24 trade paying /
 *   TK25 trading are about [set of trade]; TK41 buff applying is about [buff]. Names only; no behaviour changes.
 *   Unit: dma-transactions-kinds.test.js (KINDS = the model); integration: the TX page groups TK24/25/29 under TRADE.
 * 0.4.11 (2026-11-10, backbone v3.13, ADR 0055 — the TPT reviewed with the DEMO lens): KINDS follows the new names
 *   and products (deposit finding, explore result finding, construction upgrading, buff applying, material allocating,
 *   collectible picking up, event item clearing, trade set trading/paying, loot spot earning; TK70 gone; TK05, TK81,
 *   TK82 added). Watcher: tests/unit/dma-transactions-kinds.test.js fails when a name or product differs from
 *   the generated rules catalogue (user_dma_rules.js, from dma-bundle.yaml). Integration: live, the TX page names
 *   the kinds as the model does.
 * 0.4.10 (2026-11-10, author: "1,2,3 en 5" — of the suggestions for the TX page): every overview row (open and closed)
 *   carries its full history (act, actor, time, reason, how often) for the page to unfold, and `reason`: the reason of
 *   the latest decline, reject or revoke — for a decline the truth clause that failed, as the actor role recorded it.
 *   Unit: tests/unit/dma-transactions-overview.test.js; integration: live, a declined instance on the TX page says why.
 * 0.4.9 (2026-11-09, author: "Maak nu een overzicht van alle transacties en hun status in een apart overzicht zodat de
 *   speler kan volgen wat de werkelijke status is"): red's query overview(now) — per transaction kind (name and product
 *   from the essential model, docs/05-ontology/dma/dma-bundle.yaml) the open instances by state and the oldest; per open
 *   instance its key, state, age, initiator, last act and actor, and a CHECK flag when it waits longer than its kind
 *   normally takes (KINDS[tk].expectMin; declined / rejected are shown, not flagged: the book archives them after 1 h);
 *   and the last closed ones
 *   with their end (accepted, voided, archived and why). It reads the memory only; nothing is changed or invented.
 *   The console's TX page (console 0.1.79) shows it. Unit: tests/unit/dma-transactions-overview.test.js; integration:
 *   live, the TX page lists the open instances of dma-transactions.json and flags the ones waiting too long.
 * 0.4.8 (2026-11-04, backbone v3.12, ADR 0041: constructing and upgrading are one transaction kind, TK21 construction
 *   composing, "[construction] is composed to [level]"): at load, an open TK31 (an upgrade, the old id) is carried over
 *   as the open TK21 of key "<grid>@<level>" (the level it is composed to: from + 1), with its history; nothing else
 *   changes. Unit expectation: dma-transactions.test.js (an open TK31 at from 2 becomes TK21 "<grid>@3").
 *   Integration expectation: after the restart the console shows the running upgrades under TK21.
 *
 * Author, 2026-11-01 22:12 local: "Je moet zeker weten dat de oplossing die je nu kiest demo compliant is en algeheel:
 * elke transactie kent coordinatiehandelingen en de feiten daarvan. Dit dient onthouden te worden door groen en als het
 * nodig is, kan rood dit opvragen. Een boek is een blauwe transactie om het vast te leggen. Het mag de gehele werking van
 * wat we tot nu toe gemaakt hebben niet wijzigen. Het is alleen dat je de feiten kunt gebruiken bij logische
 * bedrijfsregels." Decision: docs/decisions/0038-transaction-book.md (amended).
 *
 * GREEN — C-fact memory. Every coordination act any actor role records (DMA_Demo.record("c", { tk, act, ... })) is a
 *   C-fact. This module observes them (it wraps DMA_Demo.record and passes every call through unchanged) and remembers,
 *   per transaction instance (kind + key), its state and history. It never refuses, never sends, never changes what any
 *   actor role does: it only makes the facts available.
 *   The pattern is the complete transaction pattern (CTP) of DEMO 4, Enterprise Ontology 2nd ed. (Dietz & Mulder 2024),
 *   in its own terms (0.4.0, author 2026-11-01 22:32: "demo 4 second edition kent geen stop en quit, dus zorg dat je het
 *   juiste patroon gebruikt"):
 *     coordination acts  request, promise, decline, declare, accept, reject;
 *                        revoke request (initiator), revoke promise (executor), revoke declare (executor),
 *                        revoke accept (initiator), revoke decline (executor), revoke reject (initiator) — six
 *                        revocations (0.4.14, EO2 ch. 8), each answered by allow | refuse
 *     production act     execute (between promise and declare; not a process step, no coordination state)
 *   States (the C-fact last created): requested, promised, declined, declared, rejected, accepted.
 *   declined and rejected are discussion states: a transaction ends there unsuccessfully unless it is left FORWARD — a
 *   renewed request after declined, a renewed declare after rejected — or BACKWARD by revoking the decline / reject
 *   (0.4.14; 0.4.0–0.4.13 said they were not revocable, which EO2 ch. 8 contradicts).
 *   A revocation that is allowed rolls the main process back (reversion): revoke request -> initial (the transaction is
 *   void), revoke promise -> requested, revoke declare -> promised, revoke accept -> declared, revoke decline ->
 *   requested, revoke reject -> declared (EO2 §8.2.6.3). A refused revocation leaves
 *   the state as it is. A promise or declare that is skipped is taken as TACIT. Any act the pattern does not allow in the
 *   current state, and anything that is not a coordination or production act, stays in the history only.
 *   A request while an instance is in progress is kept as "repeated request".
 *   The key of an instance is the first field present of KEY_FIELDS for its kind (grid for mines, sender for trades,
 *   spec for explorers, resource for searches, ...).
 * RED — queries: DMA_Tx.state(tk, key), open(tk, key), list({ tk, open }), history(tk, key), summary(). Business rules
 *   (green) use the same queries, e.g. R-UPG: no new TK31 request while one is open (ADR 0037).
 * BLUE — recording: at most every RECORD_MS, when the memory changed, the recorder writes dma-transactions.json (all
 *   open instances and the last 200 closed ones). Each recording is a blue transaction TK-BLUE "c-fact record"
 *   (request, declare), which itself does not mark the memory as changed. At load the memory is read back from that file.
 *
 * 0.4.7 (2026-11-02, release test of pack 02c: TK61 round@1793603373631 stayed "promised" in the active document
 *   for hours although the facts log holds its declare and accept at 07:09:51 — the client restarted at 07:14, and the
 *   book is written at most every 5 min, so the acts of the last minutes before a restart or a crash were lost):
 *   at load, every C-fact the facts log (dma-facts-<day>.jsonl, appended per fact) holds AFTER the time of the
 *   recorded book is taken in again, in order, through the same pattern — and, for an instance the book still holds
 *   open, every act on it after its own last act (so an instance orphaned by an earlier restart is put right too). The facts log is the record of what was said;
 *   the book follows it, whenever the client stopped. The client's Date.parse does not read an ISO date, so times are
 *   read with an own parser. Behaviour of every actor role unchanged.
 *   Unit: dma-transactions.test.js (a book at T, declare + accept in the facts after T -> closed after the reload; a
 *   fact before T is not taken twice). Integration: after a restart the active document holds no instance whose
 *   closing act is in the facts log (tests/live/check_release_invariants.py I6).
 * 0.4.6 (2026-11-02, test of this version: an instance from before 0.4.4 without any key ("TK61@-", a mail round of
 *   yesterday) stayed in the active document): an instance whose key is "-" is moved to the history at load
 *   (archived: "no key (before 0.4.4)"). Unit: dma-transactions.test.js.
 * 0.4.5 (2026-11-02, live: the client did not load 0.4.4 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.4.4 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   - ONE INSTANCE PER CASE for every kind: a fact with a `case` field is keyed by it first (KEY_DEFAULT starts with
 *     "caseId"); trade, help, star ask, mail, quests and blue tasks give each case its own id.
 *   - RED sees what is outside the pattern: an act that is neither a DEMO 4 coordination act, nor execute, nor the
 *     initiator's assess is counted per kind and act (status().foreign), so a module that drifts from the ontology shows.
 *   - An instance without any act for STALE_MS (48 h), in whatever state, is no longer the current situation and moves
 *     to the history (archived: "no act for 48 h"), e.g. a star trade the player settled by hand.
 *   Unit: dma-transactions.test.js (case key; foreign acts counted; stale after 48 h); integration:
 *   tests/unit/dma-demo4-acts.test.js.
 * 0.4.3 (2026-11-02, author: "Voor de specialisten geldt hetzelfde ... als een zoekactie afgesloten is en een nieuwe
 *   zoekactie wordt gestart kan de oude transactie informatie naar het historie document voor enkel analyse"):
 *   - Every search is its own transaction: TK11 and TK16 are keyed by `search` (one id per send) before the resource /
 *     the explorer's name, so a search that closes goes to the history and the next one starts fresh.
 *   - The active document is the current situation: an instance resting in a discussion state (declined, rejected) that
 *     nobody left forward for ARCHIVE_MS (1 h) is no longer current and moves to the history (archived: "not renewed
 *     within 1 h"); TK11/TK16 instances of the old keying (by resource / by explorer name, no search id) move there at
 *     load (archived: "one transaction per search since 0.4.3"). No act is invented: the history keeps their last state.
 *   Unit: dma-transactions.test.js (keyed per search; a stale decline and an old TK11 go to the history).
 * 0.4.2 (2026-11-02, author: "je wil de huidige situatie van het eiland weten ... de informatie over de vorige bouw is
 *   oude informatie waar we niks meer mee kunnen behalve analyses. Dus die hoeft niet in het actieve document, maar
 *   bijvoorbeeld in een historie document"): the ACTIVE document dma-transactions.json holds only the transactions in
 *   progress or resting in a discussion state (the current situation). A transaction that closes (accepted, or void after
 *   an allowed revoke request) goes to the HISTORY document of its day, dma-transactions-history-YYYY-MM-DD.jsonl (UTC),
 *   one line per transaction, appended by the same blue recording. The memory keeps the last 200 closed for red's
 *   queries while the client runs; after a restart they are in the history files. A 0.4.0/0.4.1 file's closed list is
 *   moved to the history once.
 *   Unit: dma-transactions.test.js (closed ones in the history file, not in the active file; the active file after the
 *   live day holds only open instances); integration: dma-tk31/tk41/tk51 unchanged.
 * 0.4.1 (2026-11-02, check of the agreements; replay of the live day 2026-11-01: 4,370 C-facts gave 194 open instances
 *   and an 800 KB dma-transactions.json in one day — a TK16 explorer held 168 history entries, mostly repeated requests
 *   and "assess" rows, and TK11/TK16 never close until their migration step; the file is rewritten every 5 min):
 *   - BOUNDED HISTORY: a history entry equal to the previous one (same act, note, reason and outcome) is not added again;
 *     the previous entry counts it (n) and keeps the last time (last). An instance keeps at most HIST_MAX (40) entries:
 *     the first (the request that opened it) and the latest. The state is never derived from the history, so this
 *     changes no state and no business rule.
 *   - BLUE RECORDING CLOSES: a recording is request (the C-fact memory, green) -> declare (blue recorder) -> accept
 *     (the C-fact memory); it no longer rests "declared" (handover item 6). Closed TK-BLUE instances are not kept among
 *     the 200 closed transactions and TK-BLUE is not written to the file — the record is about the file itself.
 *   Unit: dma-transactions.test.js (repeats collapse; at most 60 entries; TK-BLUE accepted and not in the file);
 *   integration: the live day replays into a file under 250 KB (0.4.0: about 780 KB) with the same states as 0.4.0.
 *
 * Unit expectation:        request, promise, execute, declare, accept give requested, promised (execute in the history
 *                          only), declared, accepted; request -> declare takes promise as tacit; decline -> renewed
 *                          request; reject -> renewed declare; allowed revocations revert (rv-rq -> initial, rv-pm ->
 *                          requested, rv-da -> promised, rv-ac -> declared, rv-dc -> requested, rv-rj -> declared); a
 *                          refused one keeps the state; no quit, no
 *                          stop; a decline while promised and an "assess" are history only; a repeated request opens no
 *                          second instance; the record call passes through unchanged; blue records only on a change; the
 *                          memory is read back after a reload; legacy "cancel" is read as revoke request + tacit allow.
 * Integration expectation: a day of live facts is taken in without an error; green 0.8.7 R-UPG reads TK31 from here
 *                          (tests/integration/dma-tk31-transaction.test.js).
 */
(function (root) {
    "use strict";
    var VERSION = "0.4.20";
    var FILE = "dma-transactions.json", HIST_PREFIX = "dma-transactions-history-", PENDING_MAX = 2000, ARCHIVE_MS = 60 * 60000, STALE_MS = 48 * 3600000, SEARCH_KINDS = { TK11: 1, TK16: 1 }, KEEP_CLOSED = 200, RECORD_MS = 5 * 60000, HIST_MAX = 40;
    var STATE_AFTER = { request: "requested", promise: "promised", decline: "declined", declare: "declared", accept: "accepted", reject: "rejected" };
    var DONE = { accepted: 1, initial: 1 };                    // accepted: success; initial: voided by an allowed revoke request
    var ALLOWED = {                                            // CTP main pattern; arrays = acts taken as tacit on the way
        requested: { promise: 1, decline: 1, declare: ["promise"], accept: ["promise", "declare"] },
        promised:  { declare: 1, accept: ["declare"] },
        declined:  { request: 1 },                             // left forward only: a renewed request
        declared:  { accept: 1, reject: 1 },
        rejected:  { declare: 1 }                              // left forward only: a renewed declare
    };
    var REVOKE = {                                             // revocation: needs the revoked C-fact; allow reverts to
        "revoke request": { needs: ["requested", "promised", "declared", "rejected", "accepted"], back: "initial" },
        "revoke promise": { needs: ["promised", "declared", "rejected", "accepted"], back: "requested" },
        "revoke declare": { needs: ["declared", "rejected", "accepted"], back: "promised" },
        "revoke accept":  { needs: ["accepted"], back: "declared" },
        "revoke decline": { needs: ["declined"], back: "requested" },   // 0.4.14: EO2 §8.2.6.8 (condition dc; executor; -> rq)
        "revoke reject":  { needs: ["rejected"], back: "declared" }     // 0.4.14: EO2 §8.2.6.9 (condition rj; initiator; -> da)
    };
    var LEGACY = { cancel: "revoke request", revoke: "revoke request" };   // facts written by green 0.8.4/0.8.5 and trade before 0.3.0
    var KEY_FIELDS = { TK11: ["search", "resource"], TK16: ["search", "spec"], TK25: ["caseId", "sender"], TK28: ["caseId", "sender"], "TK-BLUE": ["caseId", "kind"] };
    var DEMO4 = { request: 1, promise: 1, decline: 1, declare: 1, accept: 1, reject: 1, "revoke request": 1, "revoke promise": 1, "revoke declare": 1, "revoke accept": 1, "revoke decline": 1, "revoke reject": 1, allow: 1, refuse: 1, execute: 1, assess: 1 };
    var foreign = {};                                          // 0.4.4: tk|act -> count, for red
    var KEY_DEFAULT = ["caseId", "key", "grid", "sender", "spec", "quest", "id", "kind", "resource"];
    var OWN = { tk: "TK-BLUE", kind: "c-fact record" };
    /* 0.4.9: the transaction kinds of the essential model (dma-bundle.yaml): name, product, and how long an instance
       normally stays in progress (minutes) before the overview asks the player to check it */
    var KINDS = {   // 0.4.12: names and products as the backbone v3.14 (watched by dma-transactions-kinds.test.js)
        TK01: { name: "policy establishing", product: "[policy] is established", expectMin: 10 },
        TK05: { name: "policy abolishing", product: "[policy] is abolished", expectMin: 10 },
        TK11: { name: "deposit finding", product: "[deposit] is found", expectMin: 12 * 60 },
        TK16: { name: "explore result finding", product: "[explore result] is found", expectMin: 30 * 60 },
        TK18: { name: "adventure completing", product: "[adventure] is completed", expectMin: 8 * 60 },
        TK19: { name: "loot spot earning", product: "[loot spot] is earned", expectMin: 120 },
        TK21: { name: "construction upgrading", product: "[construction] is upgraded to [level]", expectMin: 24 * 60 },
        TK24: { name: "trade paying", product: "[set of trade] is paid", expectMin: 60 },
        TK23: { name: "trade preparing", product: "[set of trade] is prepared", expectMin: 30 },
        TK25: { name: "trade completing", product: "[set of trade] is completed", expectMin: 120 },
        TK41: { name: "buff applying", product: "[buff] is applied", expectMin: 60 },
        TK51: { name: "construction demolishing", product: "[construction] is demolished", expectMin: 30 },
        TK60: { name: "material allocating", product: "[material] is allocated", expectMin: 60 },
        TK61: { name: "loot collecting", product: "[loot] is collected", expectMin: 60 },
        TK64: { name: "resource producing", product: "[production batch] is produced", expectMin: 2880 },   // 0.4.16: the player holds AR64; live limit 48 h (I6)
        TK66: { name: "resource supply managing", product: "resource supply managing for [period] is done", expectMin: 120 },   // 0.4.17: AR66, one period an hour; live limit 3 h (I6)
        TK71: { name: "quest completing", product: "[quest] is completed", expectMin: 60 },
        TK72: { name: "collectible picking up", product: "[collectible] is picked up", expectMin: 30 },
        TK73: { name: "search order completing", product: "[search order] is completed", expectMin: 360 },   // 0.4.19: AR73, the live limit is 26 h (I6)
        TK77: { name: "event item clearing", product: "[event item] is cleared", expectMin: 180 },
        TK82: { name: "location observing", product: "[location] is observed", expectMin: 30 }   // 0.4.15: TK-EV retired (backbone v3.16 D-5)
    };

    var IN_PROGRESS = { requested: 1, promised: 1, declared: 1 };

    function airF() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return null; } }
    function fileRead(name) {
        try { var a = airF(); if (!a || !a.File) return null; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function fileAppend(name, text) {                          // 0.4.2: the history document
        try { var a = airF(); if (!a || !a.File) return false; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.APPEND); st.writeUTFBytes(text); st.close(); return true; } catch (_) { return false; }
    }
    function fileWrite(name, obj) {
        try { var a = airF(); if (!a || !a.File) return false; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj)); st.close(); return true; } catch (_) { return false; }
    }
    function clone(o) { return o == null ? null : JSON.parse(JSON.stringify(o)); }
    function fileText(name) {                                  // 0.4.7: the facts log, as text
        try { var a = airF(); if (!a || !a.File) return null; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new a.FileStream(); st.open(f, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return t; } catch (_) { return null; }
    }
    /* 0.4.7: the client's Date.parse returns NaN for an ISO date */
    function parseIso(s) {
        var m = /^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.(\d{1,3})\d*)?Z$/.exec(String(s || ""));
        if (!m) { var p = Date.parse(s); return p > 0 ? p : NaN; }
        return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6], m[7] ? +((m[7] + "00").slice(0, 3)) : 0);
    }

    /* ---------- GREEN: the C-fact memory ---------- */
    var mem = { open: {}, closed: [] }, changed = false, observed = 0;
    function keyOf(d) {
        var fields = (KEY_FIELDS[d.tk] || []).concat(KEY_DEFAULT), i;
        for (i = 0; i < fields.length; i++) if (d[fields[i]] != null && d[fields[i]] !== "") return String(d[fields[i]]);
        return "-";
    }
    function id(tk, key) { return String(tk) + "@" + String(key); }
    function hist(d, act, extra) {
        var h = { act: act, at: d.t ? parseIso(d.t) || Date.now() : Date.now() }, k;
        ["reason", "level", "from", "result", "actor", "rule", "outcome"].forEach(function (f) { if (d[f] != null && d[f] !== "") h[f] = d[f]; });
        if (extra) for (k in extra) if (extra.hasOwnProperty(k)) h[k] = extra[k];
        return h;
    }
    function keepData(tx, d) {
        var k;
        for (k in d) if (d.hasOwnProperty(k) && k !== "t" && k !== "k" && k !== "tk" && k !== "act" && k !== "key" && typeof d[k] !== "object") tx.data[k] = d[k];
    }
    function close(tx, at) {
        delete mem.open[id(tx.tk, tx.key)]; tx.closedAt = at;
        if (tx.tk === OWN.tk) { lastBlue = tx; return; }          // 0.4.1: a recording is about the file, not kept among the closed
        mem.closed.unshift(tx); if (mem.closed.length > KEEP_CLOSED) mem.closed.length = KEEP_CLOSED;
        pending.push(tx); if (pending.length > PENDING_MAX) pending.splice(0, pending.length - PENDING_MAX);   // 0.4.2: to the history document
    }
    var pending = [];
    /* 0.4.3: what is no longer the current situation moves to the history without an invented act */
    function archive(tx, why, at) { tx.archived = why; delete mem.open[id(tx.tk, tx.key)]; tx.closedAt = at; mem.closed.unshift(tx); if (mem.closed.length > KEEP_CLOSED) mem.closed.length = KEEP_CLOSED; pending.push(tx); changed = true; }
    /* 0.4.20 (UAT 2026-11-17 F6): when the discussion about an instance began - the first decline / reject since the instance last made progress (a promise or an accept ends the discussion).
       A request that is renewed after every decline refreshes tx.at, so "not renewed" never held for it; an instance written before 0.4.20 has no mark: with more than one decline or reject in its history
       the discussion began at its first request, otherwise at its last act. */
    function discussionStart(t) {
        if (Number(t.discAt) > 0) return Number(t.discAt);
        var n = 0, i, h = t.history || [];
        for (i = 0; i < h.length; i++) if (h[i].act === "decline" || h[i].act === "reject") n += Number(h[i].n) || 1;
        return n > 1 ? (Number(t.since) || Number(t.at) || 0) : (Number(t.at) || 0);
    }
    function sweep(now) {
        Object.keys(mem.open).forEach(function (k) {
            var t = mem.open[k];
            if ((t.state === "declined" || t.state === "rejected") && !t.revoking && now - (Number(t.at) || 0) >= ARCHIVE_MS) archive(t, "not renewed within " + Math.round(ARCHIVE_MS / 60000) + " min", now);
            else if ((t.state === "declined" || t.state === "rejected") && !t.revoking && now - discussionStart(t) >= ARCHIVE_MS) archive(t, "declined again and again for " + Math.round(ARCHIVE_MS / 60000) + " min", now);   // 0.4.20 (UAT F6)
            else if (now - (Number(t.at) || 0) >= STALE_MS) archive(t, "no act for " + Math.round(STALE_MS / 3600000) + " h", now);   // 0.4.4: nothing current any more
        });
    }
    var lastBlue = null;
    /* 0.4.1: an entry equal to the previous one is counted, not added; at most HIST_MAX (40) entries (the first and the latest) */
    function push(tx, h) {
        var p = tx.history[tx.history.length - 1];
        if (p && p.act === h.act && p.note === h.note && p.reason === h.reason && p.outcome === h.outcome && !!p.tacit === !!h.tacit) { p.n = (p.n || 1) + 1; p.last = h.at; return; }
        tx.history.push(h);
        if (tx.history.length > HIST_MAX) tx.history.splice(1, tx.history.length - HIST_MAX);
    }
    function step(tx, d, act, at) { push(tx, hist(d, act)); tx.at = at; keepData(tx, d); }
    function settle(tx, at) {                                  // accepted or initial: out of the open set (kept for revoke accept)
        if (DONE[tx.state]) close(tx, at);
    }
    function reopenClosed(tk, key) {                           // revoke accept refers to an accepted, closed instance
        for (var j = 0; j < mem.closed.length; j++) if (mem.closed[j].tk === tk && mem.closed[j].key === key && mem.closed[j].state === "accepted") {
            var t = mem.closed.splice(j, 1)[0]; delete t.closedAt; mem.open[id(tk, key)] = t; return t;
        }
        return null;
    }
    function observe(d) {
        if (!d || !d.tk || !d.act) return;
        var own = d.tk === OWN.tk && d.kind === OWN.kind;
        var tk = String(d.tk), key = keyOf(d), i = id(tk, key), act = String(d.act), tx = mem.open[i];
        var at = d.t ? parseIso(d.t) || Date.now() : Date.now();
        observed += 1;
        if (!DEMO4[act] && !LEGACY[act]) foreign[tk + "|" + act] = (foreign[tk + "|" + act] || 0) + 1;   // 0.4.4
        if (!tx && act === "revoke accept") tx = reopenClosed(tk, key);
        if (LEGACY[act] && tx) {                               // an older "cancel"/"revoke": revoke request, allowed (tacit)
            step(tx, d, LEGACY[act], at); push(tx, { act: "allow", at: at, tacit: true, note: "legacy fact " + act });
            tx.state = "initial"; settle(tx, at); if (!own) changed = true; return;
        }
        if (act === "request") {
            if (tx && tx.state === "declined") { step(tx, d, "request", at); tx.state = "requested"; }
            else if (tx) { push(tx, hist(d, "request", { note: "repeated request" })); tx.at = at; }
            else { tx = mem.open[i] = { tk: tk, key: key, state: "requested", since: at, at: at, data: {}, history: [hist(d, "request")] }; keepData(tx, d); }
        } else if (!tx) {
            return;                                            // an act without an instance: the facts log keeps it
        } else if (act === "execute") {
            if (tx.state === "requested") { push(tx, { act: "promise", at: at, tacit: true }); tx.state = "promised"; }
            step(tx, d, "execute", at);                       // production act: the coordination state stays
        } else if (REVOKE[act] && REVOKE[act].needs.indexOf(tx.state) >= 0 && !tx.revoking) {
            step(tx, d, act, at); tx.revoking = act;
        } else if ((act === "allow" || act === "refuse") && tx.revoking) {
            step(tx, d, act, at);
            if (act === "allow") { tx.state = REVOKE[tx.revoking].back; }
            delete tx.revoking;
            settle(tx, at);
            if (!DONE[tx.state] && mem.open[i] !== tx) mem.open[i] = tx;
        } else if (ALLOWED[tx.state] && ALLOWED[tx.state][act]) {
            var tacit = ALLOWED[tx.state][act];
            if (tacit && tacit.length) tacit.forEach(function (a) { push(tx, { act: a, at: at, tacit: true }); });
            step(tx, d, act, at); tx.state = STATE_AFTER[act];
            if (act === "decline" || act === "reject") { if (!(Number(tx.discAt) > 0)) tx.discAt = at; }   // 0.4.20: the discussion begins
            else if (act === "promise" || act === "accept") delete tx.discAt;                                   // 0.4.20: progress ends it
            settle(tx, at);
        } else {
            push(tx, hist(d, act, { note: STATE_AFTER[act] || REVOKE[act] || act === "allow" || act === "refuse" ? "not after " + tx.state : "not a coordination act" }));
            if (DONE[tx.state] && mem.open[i] === tx) close(tx, at);
        }
        if (!own) changed = true;
    }
    function hook() {
        var D = root.DMA_Demo;
        if (!D || typeof D.record !== "function" || D.record.__cFactMemory) return !!(D && D.record && D.record.__cFactMemory);
        var orig = D.record;
        var wrapped = function (kind, data) {
            var out = orig.apply(this, arguments);              // pass through unchanged, first
            try { if (kind === "c" && data && data.tk) { var d = {}, k; for (k in data) if (data.hasOwnProperty(k)) d[k] = data[k]; d.t = new Date().toISOString(); observe(d); } } catch (_) {}
            return out;
        };
        wrapped.__cFactMemory = true;
        D.record = wrapped;
        return true;
    }

    /* ---------- BLUE: recording the memory (TK-BLUE "c-fact record") ---------- */
    var lastRecord = 0;
    function recordNow(now) {
        now = now || Date.now();
        if (!changed) return false;
        var rec = function (act, actor, extra) { try { if (root.DMA_Demo && root.DMA_Demo.record) { var o = { tk: OWN.tk, act: act, actor: actor, kind: OWN.kind }, k; for (k in (extra || {})) o[k] = extra[k]; root.DMA_Demo.record("c", o); } } catch (_) {} };
        rec("request", "c-fact memory");
        var open = {}, k;                                            // 0.4.1: the recording itself is not written
        for (k in mem.open) if (mem.open.hasOwnProperty(k) && mem.open[k].tk !== OWN.tk) open[k] = mem.open[k];
        var ok = fileWrite(FILE, { format: "dma-transactions/3", version: VERSION, at: new Date(now).toISOString(), open: open });   // 0.4.2: the current situation only
        if (ok && pending.length) {                                  // 0.4.2: closed ones to the history document of their day
            var byDay = {}, d, rest = [];
            pending.forEach(function (t) { var day = new Date(t.closedAt || now).toISOString().slice(0, 10); (byDay[day] = byDay[day] || []).push(JSON.stringify(t)); });
            for (d in byDay) if (byDay.hasOwnProperty(d) && !fileAppend(HIST_PREFIX + d + ".jsonl", byDay[d].join("\n") + "\n")) rest = rest.concat(pending.filter(function (t) { return new Date(t.closedAt || now).toISOString().slice(0, 10) === d; }));
            pending = rest;
        }
        if (ok) { changed = false; lastRecord = now; rec("declare", "blue recorder", { file: FILE, open: Object.keys(open).length }); rec("accept", "c-fact memory"); }   // 0.4.1: accept closes it
        else rec("decline", "blue recorder", { reason: "file not written; a renewed request follows at the next change" });
        return ok;
    }
    function tick(now) { now = now || Date.now(); hook(); sweep(now); if (changed && now - lastRecord >= RECORD_MS) recordNow(now); }

    /* 0.4.7: take in the C-facts the facts log holds after the recorded book (lost when the client stopped in between) */
    var replayed = 0;
    function replayFacts(atIso) {
        var from = parseIso(atIso); if (!(from > 0)) return 0;
        /* also what an open instance missed before the book: an act on it after its own last act (the book of a restart
           that lost the closing acts was recorded again with the instance still open) */
        var floor = from, k0;
        for (k0 in mem.open) if (mem.open.hasOwnProperty(k0) && Number(mem.open[k0].at) > 0 && Number(mem.open[k0].at) < floor) floor = Number(mem.open[k0].at);
        if (from - floor > 3 * 86400000) floor = from - 3 * 86400000;
        var days = [], dd, today = new Date().toISOString().slice(0, 10);
        for (dd = floor; ; dd += 86400000) { var day0 = new Date(dd).toISOString().slice(0, 10); if (days.indexOf(day0) < 0) days.push(day0); if (day0 >= today || days.length > 4) break; }
        var floorIso = new Date(floor).toISOString();
        days.forEach(function (day) {
            var txt = fileText("dma-facts-" + day + ".jsonl"); if (!txt) return;
            var lines = txt.split("\n"), i, j, d;
            for (j = lines.length - 1; j >= 0; j--) {                 // the facts that matter are at the end: find where they start
                var tj = /^\{"t":"([^"]+)"/.exec(lines[j]);
                if (tj && tj[1] < floorIso) break;
            }
            for (i = j + 1; i < lines.length; i++) {
                if (lines[i].indexOf('"k":"c"') < 0) continue;
                try { d = JSON.parse(lines[i]); } catch (_) { continue; }
                if (!d || d.k !== "c" || !d.tk || !d.act || (d.tk === OWN.tk && d.kind === OWN.kind)) continue;
                if (String(d.t) <= atIso) {                            // before the book: only for an instance still open
                    var tx = mem.open[id(String(d.tk), keyOf(d))], ft = parseIso(d.t);
                    if (!tx || !(ft >= Number(tx.at))) continue;
                    if (ft === Number(tx.at) && tx.history.some(function (h) { return h.act === String(d.act) && Number(h.last || h.at) === ft; })) continue;
                }
                observe(d); replayed += 1;
            }
        });
        if (replayed) changed = true;
        return replayed;
    }
    /* ---------- load: what blue recorded, and the TK31 memory of green 0.8.2 (dma-tk31.json) ---------- */
    (function load() {
        var b = fileRead(FILE);
        if (b && b.open) { mem.open = b.open; mem.closed = (b.closed || []).filter(function (t) { return t.tk !== OWN.tk; }); if (mem.closed.length) { pending = mem.closed.slice().reverse(); changed = true; } }   // 0.4.2: an older file's closed list goes to the history once
        Object.keys(mem.open).forEach(function (k) { var t0 = mem.open[k]; if (SEARCH_KINDS[t0.tk] && !(t0.data && t0.data.search)) { archive(t0, "one transaction per search since 0.4.3", Number(t0.at) || Date.now()); return; } if (t0.key === "-" && t0.tk !== OWN.tk) archive(t0, "no key (before 0.4.4)", Number(t0.at) || Date.now()); });   // 0.4.3, 0.4.6
        Object.keys(mem.open).forEach(function (k) { if (mem.open[k].tk === OWN.tk) delete mem.open[k]; else if (mem.open[k].history && mem.open[k].history.length > HIST_MAX) mem.open[k].history.splice(1, mem.open[k].history.length - HIST_MAX); });   // 0.4.1
        Object.keys(mem.open).forEach(function (k) { if (mem.open[k].state === "executing") mem.open[k].state = "promised"; });   // 0.3.0: execute is no coordination state
        var old = fileRead("dma-tk31.json"), g;
        if (old && old.open) for (g in old.open) if (old.open.hasOwnProperty(g) && !mem.open[id("TK31", g)]) {
            var t = old.open[g], at = Number(t.at) || Date.now();
            mem.open[id("TK31", g)] = { tk: "TK31", key: String(g), state: "promised", since: at, at: at,
                data: { grid: Number(g), resource: t.resource, name: t.name, from: t.fromLevel }, history: [{ act: "request", at: at, migrated: "dma-tk31.json" }, { act: "promise", at: at }] };
            changed = true;
        }
        if (b && b.at) replayFacts(String(b.at));                  // 0.4.7
        Object.keys(mem.open).forEach(function (k) {               // 0.4.8: TK31 -> TK21 <grid>@<level> (backbone v3.12)
            var t1 = mem.open[k]; if (t1.tk !== "TK31") return;
            var from = Number(t1.data && (t1.data.from != null ? t1.data.from : t1.data.fromLevel)) || 0, nk = String(t1.key) + "@" + (from + 1);
            delete mem.open[k];
            if (!mem.open[id("TK21", nk)]) { t1.tk = "TK21"; t1.key = nk; t1.data = t1.data || {}; t1.data.to = from + 1; (t1.history = t1.history || []).push({ act: "carried over", at: Date.now(), from: "TK31 (backbone v3.12)" }); mem.open[id("TK21", nk)] = t1; }
            changed = true;
        });
    })();
    hook();
    try { if (!root.DMA_TX_NO_TIMER && typeof root.setInterval === "function") root.setInterval(function () { try { tick(); } catch (_) {} }, 30000); } catch (_) {}

    /* ---------- RED: queries ---------- */
    function open(tk, key) { hook(); return clone(mem.open[id(tk, key)] || null); }   // a query also makes sure the memory listens
    /* the instance when it is in progress (not ended in a discussion state); a business rule's "is one open?" */
    function inProgress(tk, key) { var t = open(tk, key); return t && (IN_PROGRESS[t.state] || t.revoking) ? t : null; }
    function state(tk, key) { var t = mem.open[id(tk, key)]; if (t) return t.state; for (var i = 0; i < mem.closed.length; i++) if (mem.closed[i].tk === String(tk) && mem.closed[i].key === String(key)) return mem.closed[i].state; return null; }
    function list(f) {
        hook(); f = f || {};
        var out = [], k;
        if (f.open !== false) for (k in mem.open) if (mem.open.hasOwnProperty(k)) out.push(mem.open[k]);
        if (f.open !== true) out = out.concat(mem.closed);
        if (f.tk) out = out.filter(function (t) { return t.tk === String(f.tk); });
        if (f.key != null) out = out.filter(function (t) { return t.key === String(f.key); });
        out.sort(function (a, b) { return b.at - a.at; });
        return clone(out);
    }
    function history(tk, key) { return list({ tk: tk, key: key }); }
    function summary() {
        var s = {}, k, t;
        for (k in mem.open) if (mem.open.hasOwnProperty(k)) { t = mem.open[k]; s[t.tk] = s[t.tk] || {}; s[t.tk][t.state] = (s[t.tk][t.state] || 0) + 1; }
        return s;
    }

    /* 0.4.9: red's overview — per kind and per open instance, with a check flag; reads the memory only */
    function DMA_age(m) { return m < 120 ? m + " min" : m < 2880 ? Math.round(m / 60) + " h" : Math.round(m / 1440) + " d"; }
    function overview(now, src) {
        now = now || Date.now(); var m = src || mem, kinds = {}, rows = [], k;
        function last(t) { var h = t.history || [], x = h[h.length - 1] || {}; return { act: x.act || t.state, actor: x.actor || (t.data && (t.data.actor || t.data.by)) || "", at: Number(x.last || x.at) || Number(t.at) || 0 }; }
        function why(t) { var h = t.history || []; for (var i = h.length - 1; i >= 0; i--) if (/^(decline|reject|revoke)/.test(String(h[i].act)) && h[i].reason) return String(h[i].reason); return ""; }   // 0.4.10
        function hst(t) { return (t.history || []).map(function (x) { return { act: x.act, actor: x.actor || "", at: Number(x.at) || 0, last: Number(x.last) || 0, n: x.n || 1, reason: x.reason || "", outcome: x.outcome || "" }; }); }   // 0.4.10
        function init(t) { var h = t.history || []; for (var i = 0; i < h.length; i++) if (h[i].act === "request") return h[i].actor || ""; return (t.data && (t.data.initiator || t.data.actor)) || ""; }
        for (k in m.open) {
            if (!m.open.hasOwnProperty(k)) continue; var t = m.open[k]; if (t.tk === OWN.tk) continue;
            var K = KINDS[t.tk] || { name: "", product: "", expectMin: 6 * 60 }, since = Number(t.since) || Number(t.at) || now, ageMin = Math.max(0, Math.round((now - since) / 60000)), l = last(t);
            /* declined / rejected are discussion states the book archives itself after ARCHIVE_MS: shown, not flagged */
            var check = (IN_PROGRESS[t.state] && ageMin > K.expectMin) ? "waiting longer than usual (" + DMA_age(K.expectMin) + ") — check the game" : "";
            rows.push({ tk: t.tk, name: K.name, key: t.key, state: t.state, since: since, ageMin: ageMin, initiator: init(t), lastAct: l.act, lastActor: l.actor, lastAt: l.at, check: check, reason: why(t), history: hst(t) });
            var s = kinds[t.tk] || (kinds[t.tk] = { tk: t.tk, name: K.name, product: K.product, open: 0, states: {}, oldestMin: 0, checks: 0 });
            s.open += 1; s.states[t.state] = (s.states[t.state] || 0) + 1; if (ageMin > s.oldestMin) s.oldestMin = ageMin; if (check) s.checks += 1;
        }
        rows.sort(function (a, b) { return (a.tk < b.tk ? -1 : a.tk > b.tk ? 1 : 0) || (b.ageMin - a.ageMin); });
        var closed = (m.closed || []).filter(function (t) { return t.tk !== OWN.tk; }).slice(0, 50).map(function (t) {
            var K = KINDS[t.tk] || { name: "" };
            return { tk: t.tk, name: K.name, key: t.key, end: t.archived ? "archived: " + t.archived : t.state === "accepted" ? "accepted" : t.state === "initial" ? "voided (request revoked)" : t.state, closedAt: Number(t.closedAt) || Number(t.at) || 0, initiator: init(t), reason: why(t), history: hst(t) };
        });
        return { version: VERSION, at: now, kinds: Object.keys(kinds).sort().map(function (x) { return kinds[x]; }), open: rows, closed: closed,
                 checks: rows.filter(function (r) { return !!r.check; }).length, recordedAt: lastBlue ? Number(lastBlue.at) || null : null };
    }

    root.DMA_Tx = {
        overview: function (now) { hook(); return clone(overview(now)); },   // 0.4.9
        kinds: function () { return clone(KINDS); },                         // 0.4.9
        overviewOf: overview,                                                // 0.4.9: pure, for the unit expectation
        version: VERSION,
        state: state, open: open, get: open, inProgress: inProgress, list: list, history: history, summary: summary,
        observe: observe, hook: hook, tick: tick, record: recordNow,
        lastRecording: function () { return clone(lastBlue); },   // 0.4.1
        foreign: function () { return clone(foreign); },   // 0.4.4
        status: function () { return { version: VERSION, replayed: replayed, foreign: Object.keys(foreign).length, hooked: !!(root.DMA_Demo && root.DMA_Demo.record && root.DMA_Demo.record.__cFactMemory), observed: observed, open: Object.keys(mem.open).length, closed: mem.closed.length, changed: changed, lastRecord: lastRecord ? new Date(lastRecord).toISOString() : null }; }
    };
})(typeof window !== "undefined" ? window : this);
