/*
 * user_dma_mundane.js — Mundane template advisor (PBC adventure management, ADR 0033)
 * 0.1.6 (2026-11-21, live YWC 06:27Z): a general once seen as the player's stays the player's (dma-generals-known.json), so a
 *   template whose generals are away (on their way home from the last run) is not taken for another player's and left out of
 *   the run. Unit: tests/unit/dma-mundane-known-generals.test.js.
 * 0.1.5 (2026-11-21, ADR 0092, author: "8 landingsplekken is een instelling die jij algemeen hebt neergezet ... die zijn
 *   spelfeiten"): the landing spots of an adventure are a game fact the caller passes (ctx.landingSpots, with
 *   ctx.landingSource naming where the number comes from); with none passed the advisor assumes no number — it says
 *   "landing spots not known yet" (LANDING_UNKNOWN) instead of advising the star method on a guess. analyzeAir no longer
 *   defaults to 8. Unit: tests/unit/dma-mundane-landing.test.js.
 * 0.1.0 (2026-10-31, author: "ontdek een patroon dat je in alle mundane terug ziet, zodat de versie die we exporteren en
 *   door andere gebruikers met andere mundane gebruikt gaat worden, dat je die herkend en ook zelfstandig kunt volbrengen
 *   ... houd rekening dat nog niet alle mundane af zijn of fouten bevatten ... dat jij met verbetervoorstellen kwam. Kun je
 *   dat inbouwen voor een andere speler die alleen de scripts heeft?").
 *
 * Pure analysis, no game call: reads the text of a player's Mundane Warfare template files (one adventure folder),
 *   1. parses both formats (plain {specId: entry} and the export format {tree, content: {name: {...}}} with buff entries),
 *   2. classifies every template by CONTENT, not by file name (names differ per player: "load", "00", "-load", "attack 01"),
 *   3. orders the run (load first, then rounds by the number in the name),
 *   4. checks it and returns findings, each with a concrete improvement proposal,
 *   5. proposes the player's choices for that adventure (the console defaults).
 * Pattern found in 160 of the author's templates (40 adventures), 2026-10-31:
 *   LOAD        no targets, armies, usually a carrier (army >= 1000: Quartermaster / Bigheart) — loaded at home, sent.
 *   LOAD+ATTACK as LOAD, but with targets for the first round (AE01, VLT00).
 *   ATTACK      every general has a target.
 *   STAGE       some generals attack, the rest only move or park (FT03-05, VLT01-03, BC).
 *   MOVE        no targets, armies: positions on the island.
 *   STAR        no targets, every army empty: landing / moving from the star (TOK02 star landing, WM star move).
 *   PROBE       armies of 1 unit: single-recruit hits (HB, IotP, TS).
 * 0.1.3 (2026-10-31, author: "dan moet hij in deze mundane als eerste, want de aanval vertrekt niet als dat kamp niet
 *   weg is, dus het is als ywc"): a template with only buffs on camps is a round (role BUFF); a folder of buff and attack
 *   rounds gets the built load. Unit: TT "first boulder" (buff) + TT01 -> [load, first boulder, TT01].
 * 0.1.2 (2026-10-31, author: "binnen YWC een map Full ... alleen de attack van de eerste gen en de gehele attack YWC
 *   ... hij herkent ze niet als template"): a folder of attack templates only gets a load built from its rounds (every
 *   general once, army of its first attack, finding LOAD_BUILT); unnumbered rounds named first/eerste/ghost go first,
 *   last/final after. Unit: YWC\Full gives run [built load, "YWC first ghost", "YWC"], no NO_LOAD; integration: Run once.
 * 0.1.1 (2026-10-31, live FT run): when a pure LOAD exists, a LOAD+ATTACK template (a Quartermaster parked next to
 *   attackers, FT04) is a round (ATTACK / STAGE), not an alternative load.
 * 0.1.4 (2026-11-17, ADR 0079; author: "Je kunt ook mijn mundane ter beschikking stellen, waarbij je de analyse uitvoert
 *   of de speler dezelde generaals heeft, gelijk geskilled, of dat de speler alternatieven heeft om deze kampen te verslaan
 *   met eigen generaals" — "Redelijk eenvouwdige oplossing"): a shared Mundane folder carries generals.json
 *   ({format: "dma-shared-generals/1", generals: {<key>: {name, type, skills: {<skill>: level}}}}); it is not a template.
 *   With it the analysis compares every general of the templates with the player's own (dma-skills.json): SAME (same id),
 *   EQUAL (unused own general, same type, skills at least as high), SKILLS_DIFFER (same type, named skills lower),
 *   ALTERNATIVE (other type whose base capacity — the game's maxUnits, CAPS below — holds the template's largest army;
 *   not simulated), MISSING. Result: shared = {rows, camps: {covered, notCovered}, map}; finding SHARED_GENERALS
 *   (info all SAME/EQUAL, warn otherwise, error when a camp is not covered). Does not simulate a substitute's fight and
 *   does not count capacity skills (the battle simulator is a repository tool, not in the pack).
 *   Unit expectation:        tests/unit/dma-mundane-shared.test.js — one general of each outcome; the camp of the MISSING
 *                            general is named not covered; generals.json is not taken as a template.
 *   Integration expectation: ADVS ▶ New version "author's Mundane" on the shared Bonaberti folder shows the report.
 * Unit expectation:        analyzeAdventure() on the FT fixture: FT01 LOAD (carrier QM-Q), FT02 ATTACK, FT06 two-step
 *                          finding for GHOST1; a foreign template gets FOREIGN_GENERALS with a remap proposal by type.
 * Integration expectation: tests/integration/dma-mundane-advisor.test.js.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.6";
    var CARRIER_MIN = 1000;            // an army this large only carries troops for the others
    var CARRIER_TYPES = { 12: 1, 54: 1 };   // Quartermaster General, Quartermaster Bigheart
    var TOPUP = { Recruit: 1, Soldier: 1 };  // the only units that can be added on the adventure island (from the star); they are spent

    function strip(s) { return String(s || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim(); }
    function shortName(e, id) { var n = strip(e.name); var i = n.indexOf("("); return (i > 0 ? n.slice(0, i) : n).trim() || (typeName(e) || "general") + " #" + (id != null ? id : e.id); }
    function typeName(e) { var m = /\(([^)]*)\)/.exec(strip(e.name)); return m ? m[1] : ""; }
    function armyTotal(a) { var t = 0, k; for (k in (a || {})) if (a.hasOwnProperty(k)) t += Number(a[k]) || 0; return t; }
    function roundNo(file) { var m = /(\d+)(?!.*\d)/.exec(String(file)); return m ? Number(m[1]) : null; }

    /* ---------- 1. parse ---------- */
    function parse(file, text) {
        var d;
        if (!/^\s*[\[{]/.test(String(text || ""))) return { file: file, note: true, error: "a text note, not a template" };
        try { d = JSON.parse(String(text)); } catch (e) { return { file: file, error: "not a Mundane template (no JSON): " + String(e.message || e).slice(0, 80) }; }
        if (!d || typeof d !== "object" || Array.isArray(d)) return { file: file, error: "not a Mundane template" };
        var raw = [], fmt = "plain", k, c;
        if (d.content && d.tree) {
            fmt = "export";
            for (c in d.content) if (d.content.hasOwnProperty(c)) for (k in d.content[c]) if (d.content[c].hasOwnProperty(k)) raw.push([k, d.content[c][k]]);
        } else for (k in d) if (d.hasOwnProperty(k)) raw.push([k, d[k]]);
        var gens = [], buffs = [];
        raw.forEach(function (p) {
            var v = p[1];
            if (!v || typeof v !== "object") return;
            if (v.type === "buff") { buffs.push({ name: v.name, target: v.target, targetName: v.targetName, order: v.order }); return; }
            if (v.grid == null && v.army == null) return;
            gens.push({ id: p[0], name: shortName(v, p[0]), typeName: typeName(v), type: v.type, grid: v.grid, order: Number(v.order) || 0,
                        delay: Number(v.time) || 0, army: v.army || {}, total: armyTotal(v.army), target: v.target || null,
                        targetName: v.targetName || null, skills: v.skills || null, raw: v });
        });
        if (!gens.length && !buffs.length) return { file: file, error: "no generals in this file" };
        gens.sort(function (a, b) { return a.order - b.order; });
        return { file: file, format: fmt, generals: gens, buffs: buffs };
    }

    /* ---------- 2. classify ---------- */
    function isCarrier(g) { return CARRIER_TYPES[g.type] === 1 || g.total >= CARRIER_MIN; }
    var COOP = /\bplayer\s*[b-d]\b|_multi\b/i;              // a template for a co-op partner (TR player B, WW Player C)
    var LOADNAME = /load|\b0+\b|00\b|total|basis/i;
    function classify(t) {
        if (t.note) return "NOTE";
        if (t.error) return "BROKEN";
        if (COOP.test(t.file)) return "CO-OP";
        var g = t.generals, n = g.length, tg = g.filter(function (x) { return x.target; }).length;
        if (!n && t.buffs && t.buffs.length && t.buffs.every(function (b) { return b.target > 0; })) return "BUFF";   // 0.1.4: a round of buffs on camps only (TT: Rain of Flaming Arrows on the Suspicious Boulder first)
        var empty = g.filter(function (x) { return x.total === 0; }).length;
        var tiny = g.filter(function (x) { return x.total > 0 && x.total <= 2; }).length;
        var carrier = g.some(isCarrier);
        if (n && tiny === n) return "PROBE";
        if (n && empty === n && tg === 0) return "STAR";
        if (carrier && tg === 0) return "LOAD";
        if (carrier && tg > 0) return "LOAD+ATTACK";
        if (tg === 0 && LOADNAME.test(t.file)) return "LOAD";
        if (tg === 0) return "MOVE";
        if (tg === n) return "ATTACK";
        return "STAGE";
    }

    /* ---------- 3. order ---------- */
    var ORDER = { "LOAD": 0, "LOAD+ATTACK": 0 };
    var OLD = /\b(oud|old|kopie|copy|backup)\b/i;
    function sequence(ts) {
        var usable = ts.filter(function (t) { return t.role !== "BROKEN" && t.role !== "NOTE" && t.role !== "CO-OP" && !t.foreign && !t.duplicateOf && !OLD.test(t.file); });
        var loads = usable.filter(function (t) { return ORDER[t.role] === 0; });
        /* 0.1.1: a template with attacks that carries a Quartermaster (FT04: QM-Q parks, GHOST4 and ANS attack) is a
           round, not another load, when a pure load exists (live: FT04 was left out, its camps stood and FT05 could not
           take its positions) */
        if (loads.some(function (t) { return t.role === "LOAD"; })) loads.forEach(function (t) {
            if (t.role === "LOAD+ATTACK") t.role = t.generals.every(function (g) { return g.target; }) ? "ATTACK" : "STAGE";
        });
        loads = usable.filter(function (t) { return ORDER[t.role] === 0; });
        if (!loads.length) {                                     // no carrier, no "load" name: the largest template without targets
            var cand = usable.filter(function (t) { return t.role === "MOVE"; }).sort(function (a, b) { return b.generals.length - a.generals.length; });
            if (!cand.length) cand = usable.filter(function (t) { return t.role === "STAGE"; }).sort(function (a, b) { return b.generals.length - a.generals.length; });
            if (cand.length) { cand[0].role = cand[0].role === "STAGE" ? "LOAD+ATTACK" : "LOAD"; cand[0].guessed = true; loads = [cand[0]]; }
        }
        var rest = usable.filter(function (t) { return ORDER[t.role] !== 0; });
        // several loads: the one that brings most of the generals the rounds use; then the newest (army 1 / army 2, old versions)
        var used = {}; rest.forEach(function (t) { t.generals.forEach(function (g) { if (g.total > 0) used[g.id] = 1; }); });
        function cover(t) { return t.generals.filter(function (g) { return used[g.id]; }).length; }
        loads.sort(function (a, b) { return cover(b) - cover(a) || (b.mtime || 0) - (a.mtime || 0); });
        // a second load whose generals do not overlap the first is a second WAVE sent from home (RRH load 01/02/03), not an alternative
        var waves = [loads[0]].filter(Boolean), taken = {};
        if (loads[0]) loads[0].generals.forEach(function (g) { taken[g.id] = 1; });
        loads.slice(1).forEach(function (t) {
            if (t.generals.some(function (g) { return taken[g.id]; })) return;
            t.generals.forEach(function (g) { taken[g.id] = 1; }); t.wave = waves.length + 1; waves.push(t);
        });
        loads.forEach(function (t) { if (waves.indexOf(t) < 0) rest = rest.filter(function (x) { return x !== t; }); });
        loads = waves;
        // variants of one round ("BC03" and "BC03 new"): the newest file wins, the other is left out
        var byRound = {};
        rest.forEach(function (t) { var r = roundNo(t.file); if (r == null) return; var k = String(t.file).replace(/\s+(new|old|b|a|v\d)\s*$/i, "").replace(/\d+/g, "#") + "|" + r;
            if (!byRound[k] || (t.mtime || 0) > (byRound[k].mtime || 0)) byRound[k] = t; });
        rest = rest.filter(function (t) { var r = roundNo(t.file); if (r == null) return true; var k = String(t.file).replace(/\s+(new|old|b|a|v\d)\s*$/i, "").replace(/\d+/g, "#") + "|" + r; return byRound[k] === t; });
        rest.sort(function (a, b) {
            var fa = rank(a.file), fb = rank(b.file); if (fa !== fb) return fa - fb;   // 0.1.3: "first ..." goes before numbered rounds too (TT first boulder before TT01)
            var ra = roundNo(a.file), rb = roundNo(b.file);
            if (ra == null && rb == null) return rank(a.file) - rank(b.file) || (a.file < b.file ? -1 : 1);   // 0.1.2: "YWC first ghost" before "YWC"
            if (ra == null) return 1; if (rb == null) return -1;
            return ra - rb || (a.file < b.file ? -1 : 1);
        });
        /* 0.1.2 (author: YWC\Full holds only "YWC first ghost" and the whole attack "YWC"): attack templates without any
           load template; the load is built from the rounds — every general once, with the army of its first attack */
        if (!loads.length && rest.length && rest.every(function (t) { return t.role === "ATTACK" || t.role === "STAGE" || t.role === "BUFF"; }) && rest.some(function (t) { return t.role !== "BUFF"; })) loads = [builtLoad(rest)];
        return loads.concat(rest);
    }
    var FIRST = /\b(first|eerste|start|opening|ghost)\b/i, LAST = /\b(last|final|laatste|end|finish)\b/i;
    function rank(file) { var f = String(file); return FIRST.test(f) && !/\b(all|full|whole|alles)\b/i.test(f) ? (/\bfirst|eerste\b/i.test(f) ? -2 : -1) : LAST.test(f) ? 1 : 0; }
    var BUILT = "(load: all generals of the rounds)";
    function builtLoad(rounds) {
        var seen = {}, gens = [], pk = {}, n = 0;
        rounds.forEach(function (t) { t.generals.forEach(function (g) {
            if (seen[g.id]) return; seen[g.id] = 1;
            var e = {}, k, v = g.raw || {}; for (k in v) if (v.hasOwnProperty(k) && k !== "target" && k !== "targetName") e[k] = v[k];
            e.order = n; e.time = 0; pk[g.id] = e; n++;
            gens.push({ id: g.id, name: g.name, typeName: g.typeName, type: g.type, grid: g.grid, order: n - 1, delay: 0, army: g.army, total: g.total, target: null, targetName: null, skills: g.skills, raw: e });
        }); });
        return { file: BUILT, format: "plain", generals: gens, buffs: [], role: "LOAD", built: true, text: JSON.stringify(pk, null, 1) };
    }

    /* ---------- 4. check + propose ---------- */
    function finding(level, code, file, msg, fix) { return { level: level, code: code, file: file, msg: msg, fix: fix || "" }; }

    function remapProposal(t, mine) {
        // the TOK note of the author: "19858.0 is the id of Sizz his Resolute general, I have to change that into my id"
        var used = {}, out = [], missing = [];
        t.generals.forEach(function (g) { if (mine.byId[g.id]) used[g.id] = 1; });
        t.generals.forEach(function (g) {
            if (mine.byId[g.id]) return;
            var cand = mine.list.filter(function (m) { return Number(m.type) === Number(g.type) && !used[m.id]; });
            var same = cand.filter(function (m) { return strip(m.name).toLowerCase() === g.name.toLowerCase(); });
            var pick = (same[0] || cand[0]) || null;
            if (pick) { used[pick.id] = 1; out.push({ from: g.id, fromName: g.name, to: pick.id, toName: strip(pick.name), type: g.typeName }); }
            else missing.push(g.name + " (" + (g.typeName || "type " + g.type) + ")");
        });
        return { map: out, missing: missing };
    }

    function check(seq, all, ctx) {
        var F = [], mine = ctx && ctx.myGenerals ? { list: ctx.myGenerals, byId: {} } : null;
        if (mine) mine.list.forEach(function (m) { mine.byId[String(m.id)] = m; });
        all.forEach(function (t) { if (t.role === "BROKEN") F.push(finding("error", "BROKEN", t.file, t.error, "Leave it out of the run, or save it again from Mundane.")); });
        // duplicates (same generals, same armies, same targets)
        all.forEach(function (t) { if (t.duplicateOf) F.push(finding("info", "DUPLICATE", t.file, "same content as " + t.duplicateOf + ".", "Keep one of the two (move the other to Archive).")); });
        all.forEach(function (t) { if (t.role === "CO-OP") F.push(finding("info", "CO-OP", t.file, "a template for a co-op partner; not part of your own run.", "")); });
        all.forEach(function (t) { if (t.role === "NOTE") F.push(finding("info", "NOTE", t.file, "a text note, not a template; ignored.", "")); });
        var loadsAll = all.filter(function (t) { return ORDER[t.role] === 0 && !t.duplicateOf && !t.foreign && t.role !== "CO-OP" && seq.indexOf(t) < 0; });
        var loads = seq.filter(function (t) { return ORDER[t.role] === 0; });
        if (loads.length && loads[0].built) F.push(finding("info", "LOAD_BUILT", null, "no load template: the load is built from the rounds (" + loads[0].generals.length + " generals, each with the army of its first attack).",
            "Save a load template from Mundane if a general needs a different army at home."));
        if (loads.length && loads[0].guessed) F.push(finding("info", "LOAD_GUESSED", loads[0].file, "no carrier and no load name: taken as the load template because it has the most generals and no targets.",
            "Confirm it on the ADVS page, or rename it with \"load\" in the name."));
        var leftOut = all.filter(function (t) { return seq.indexOf(t) < 0 && t.role !== "BROKEN" && t.role !== "NOTE" && t.role !== "CO-OP" && !t.foreign && !t.duplicateOf; });
        if (leftOut.length) F.push(finding("info", "LEFT_OUT", null, "not in the run (alternative, older version or extra load): " + leftOut.map(function (t) { return t.file; }).join(", ") + ".",
            "Check the run order on the ADVS page; move what you no longer use to Archive."));
        if (!loads.length) F.push(finding("error", "NO_LOAD", null, "no load template: none has a carrier (Quartermaster / army of 1,000+) and no targets.",
            "Mark the template you load at home as the load template on the ADVS page, or save one from Mundane with all generals and the carrier."));
        if (loadsAll.length) F.push(finding("warn", "MANY_LOADS", null, "other load templates: " + loadsAll.map(function (t) { return t.file; }).join(", ") + "; used: " + (loads[0] ? loads[0].file : "") + " (brings most of the generals the rounds use).",
            "Choose one on the ADVS page; the others are alternatives (army 1 / army 2, or an older version)."));
        // foreign generals
        all.forEach(function (t) {
            if (!mine || t.error) return;
            var foreign = t.generals.filter(function (g) { return !mine.byId[g.id]; });
            if (!foreign.length) return;
            var rp = remapProposal(t, mine);
            F.push(finding(t.foreign ? "info" : foreign.length === t.generals.length ? "error" : "warn", "FOREIGN_GENERALS", t.file, (t.foreign ? "left out of the run: " : "") +
                foreign.length + " of " + t.generals.length + " generals are not yours (another player's template, or a general you no longer have): " +
                foreign.map(function (g) { return g.name; }).join(", ") + ".",
                rp.map.length ? "Replace them by your own general of the same type: " + rp.map.map(function (m) { return m.fromName + " → " + m.toName; }).join(", ") +
                    (rp.missing.length ? "; no general of your own for " + rp.missing.join(", ") : "") + ". The advisor can save this as a copy." :
                    "You have no general of the same type for " + rp.missing.join(", ") + "."));
            t.remap = rp;
        });
        if (!loads.length) return F;
        var load = { file: loads.map(function (t) { return t.file; }).join(" + "), generals: [] }, loaded = {};
        loads.forEach(function (t) { t.generals.forEach(function (g) { load.generals.push(g); }); });
        load.generals.forEach(function (g) { loaded[g.id] = g; });
        if (loads.length > 1) F.push(finding("info", "WAVES", null, loads.length + " waves sent from home: " + load.file + ".", "The second wave is sent when the first has landed."));
        // generals used later but never loaded/sent
        seq.forEach(function (t) {
            if (t.role === "STAR") return;
            if (ORDER[t.role] === 0) return;
            var miss = t.generals.filter(function (g) { return !loaded[g.id] && g.total > 0; });
            miss.forEach(function (g) { loaded[g.id] = g; });   // reported once, at their first round
            if (miss.length) F.push(finding("warn", "NOT_LOADED", t.file, miss.map(function (g) { return g.name; }).join(", ") + " is not in the load template " + load.file +
                ": they must be sent from home with this template (Load army at home, then Send) before this round, or the round fails.",
                "Add them to " + load.file + " so one send brings everybody, or keep the second send (rule: send-verify)."));
        });
        // troop flow: pool on the island after landing; Mundane does not count what a general gives back in the same load
        var cur = {}, pool = {}, carriers = load.generals.filter(isCarrier).map(function (g) { return g.id; });
        load.generals.forEach(function (g) { cur[g.id] = g.army; });
        var starMethod = !!(ctx && ctx.starMethod);
        var island = {}; load.generals.forEach(function (g) { add(island, g.army); });
        // after landing the carrier is emptied (Shortcuts > Unload all units, or it waits in the star): its troops are the pool
        carriers.forEach(function (id) { add(pool, cur[id]); cur[id] = {}; });
        seq.forEach(function (t) {
            if (ORDER[t.role] === 0 || t.role === "STAR") return;
            // a general sent later from home arrives with his own army
            t.generals.forEach(function (g) { if (!cur.hasOwnProperty(g.id)) { cur[g.id] = g.army; add(island, g.army); } });
            var need = {}, give = {};
            t.generals.forEach(function (g) {
                var have = cur[g.id] || {}, u;
                var units = union(have, g.army);
                for (u in units) { var d = (g.army[u] || 0) - (have[u] || 0); if (d > 0) need[u] = (need[u] || 0) + d; else if (d < 0) give[u] = (give[u] || 0) - d; }
            });
            var short = [], over = [], u, inRound = {};
            t.generals.forEach(function (g) { add(inRound, g.army); });
            var topUp = [];
            for (u in inRound) if ((inRound[u] || 0) > (island[u] || 0)) {
                var txt = u + " " + inRound[u] + " needed, " + (island[u] || 0) + " brought";
                if (TOPUP[u]) { topUp.push(txt); island[u] = inRound[u]; } else over.push(txt);
            }
            if (topUp.length) F.push(finding("info", "TOP_UP", t.file, "topped up from the star on the island (spent, not returned): " + topUp.join(", ") + ".",
                "Keep enough in the star; rule adv.topUp allows it."));
            for (u in need) { var avail = Math.max(0, pool[u] || 0); if (need[u] > avail) short.push({ unit: u, need: need[u], avail: avail, back: give[u] || 0 }); }
            if (over.length) F.push(finding("warn", "SHORT", t.file, "more troops in this round than the load template brings (unless the star on the island holds them): " + over.join(", ") + ".",
                    "Load more in " + load.file + " (the carrier), or top up Recruits / Soldiers from the star on the island."));
            else if (short.length) {
                var swap = short.filter(function (s) { return s.need <= s.avail + s.back; });
                if (swap.length === short.length) {
                    var who = t.generals.filter(function (g) { var h = cur[g.id] || {}; return swap.some(function (s) { return (h[s.unit] || 0) > (g.army[s.unit] || 0); }); });
                    F.push(finding("warn", "TWO_STEP", t.file, "Mundane will say FAIL for " + swap.map(function (s) { return s.unit + " (" + s.need + " needed, " + s.avail + " in the pool)"; }).join(", ") +
                        ": the units come from " + who.map(function (g) { return g.name; }).join(", ") + " in this same round, and Mundane does not count what a general gives back.",
                        "Let " + who.map(function (g) { return g.name; }).join(", ") + " give those units back one round earlier (where it only parks), or load " +
                        who.map(function (g) { return g.name; }).join(", ") + " alone first."));
                } else F.push(finding("warn", "POOL", t.file, "the free troops may not cover this round: " + short.map(function (s) { return s.unit + " " + s.need + " needed, about " + (s.avail + s.back) + " free"; }).join(", ") +
                    " (other generals still hold them; losses not counted).",
                    "Let generals that only park give their troops back in an earlier round, or top up Recruits / Soldiers from the star."));
            }
            // apply the round: generals in the template take their army; the difference goes to / comes from the pool
            t.generals.forEach(function (g) { var have = cur[g.id] || {}; sub(pool, g.army); add(pool, have); cur[g.id] = g.army; });
            for (u in pool) if (pool[u] < 0) pool[u] = 0;
            // carriers that stay idle in an attack round only block a landing spot
            var idleCarrier = t.generals.filter(function (g) { return carriers.indexOf(g.id) >= 0 && !g.target; });
            if (idleCarrier.length && (t.role === "ATTACK" || t.role === "STAGE")) F.push(finding("info", "CARRIER_IDLE", t.file,
                idleCarrier.map(function (g) { return g.name; }).join(", ") + " only stores troops in this round.",
                "Take the carrier out of " + t.file + " (it makes the check FAIL) or send it to the star; its troops stay in the pool."));
        });
        // landing spots
        var spots = ctx && Number(ctx.landingSpots) > 0 ? Number(ctx.landingSpots) : 0;   // 0.1.5 (ADR 0092): a game fact, never a guess
        var spotSrc = ctx && ctx.landingSource ? " (" + ctx.landingSource + ")" : "";
        if (!spots) F.push(finding("info", "LANDING_UNKNOWN", load.file, load.generals.length + " generals; the landing spots of this adventure are not known yet.",
            "They are read from the game on the first run, when the adventure is in view; until then no star method is advised."));
        if (spots && load.generals.length > spots) F.push(finding("info", "LANDING", load.file, load.generals.length + " generals for " + spots + " landing spots" + spotSrc + ": " + (load.generals.length - spots) + " land in the star.",
            "Use the star method (rule adv.starMethod): send all, return them to the star when the first have landed, and place only each round's attackers."));
        if (spots && load.generals.length <= spots) F.push(finding("info", "LANDING_FITS", load.file, load.generals.length + " generals for " + spots + " landing spots" + spotSrc + ": all land with their troops.",
            "No star method needed: the generals keep their armies on landing."));
        // first round's attackers should land first
        var first = seq.filter(function (t) { return ORDER[t.role] !== 0 && t.generals.some(function (g) { return g.target; }); })[0];
        if (first && spots && !starMethod) {
            var firstIds = first.generals.filter(function (g) { return g.target; }).map(function (g) { return g.id; });
            var late = load.generals.slice().sort(function (a, b) { return a.order - b.order; }).slice(spots).filter(function (g) { return firstIds.indexOf(g.id) >= 0; });
            if (late.length) F.push(finding("info", "FIRST_LATE", load.file, late.map(function (g) { return g.name; }).join(", ") + " (first round) may land in the star.",
                "Put them first in " + load.file + ", or use the star method."));
        }
        // skills differ from the general's own (when the client tells us his skills)
        if (ctx && ctx.skillsOf) seq.forEach(function (t) {
            t.generals.forEach(function (g) {
                if (!g.skills) return;
                var own = ctx.skillsOf(g.id); if (!own) return;
                var diff = Object.keys(g.skills).filter(function (k) { return Number(own[k] || 0) < Number(g.skills[k]); });
                if (diff.length) F.push(finding("warn", "SKILLS", t.file, g.name + " has fewer points than the template assumes in skill " + diff.join(", ") + ".",
                    "Skill him first, or expect more losses than the simulation behind this template."));
            });
        });
        return F;
    }
    function union(a, b) { var o = {}, k; for (k in a) o[k] = 1; for (k in b) o[k] = 1; return o; }
    function add(p, a) { for (var k in (a || {})) p[k] = (p[k] || 0) + (Number(a[k]) || 0); }
    function sub(p, a) { for (var k in (a || {})) p[k] = (p[k] || 0) - (Number(a[k]) || 0); }

    /* ---------- 5. the player's choices for this adventure (console defaults) ---------- */
    function choices(seq, all, ctx) {
        var load = seq.filter(function (t) { return ORDER[t.role] === 0; })[0] || null;
        var rounds = seq.filter(function (t) { return ORDER[t.role] !== 0; });
        var buffs = 0; all.forEach(function (t) { if (!t.error) buffs += t.buffs.length; });
        return {
            loadTemplate: load ? load.file : "",
            rounds: rounds.map(function (t) { return { file: t.file, role: t.role, attackers: t.generals.filter(function (g) { return g.target; }).map(function (g) { return g.name; }),
                                                       park: t.generals.filter(function (g) { return !g.target; }).map(function (g) { return g.name; }) }; }),
            leftOut: all.filter(function (t) { return seq.indexOf(t) < 0 && t.role !== "NOTE"; }).map(function (t) { return t.file; }),
            generals: load ? load.generals.length : 0,
            carrier: load ? load.generals.filter(isCarrier).map(function (g) { return g.name; }) : [],
            buffs: buffs,
            starMethod: !!(ctx && ctx.starMethod)
        };
    }

    /* a folder may hold several adventures (Evil Queen: HaG, RRH, SW, TFahW, TPPoH): group by the file's leading word */
    function prefixOf(name) { var m = /^([A-Za-z]+)[\s_-]*\d*/.exec(String(name).replace(/\.(txt|data)$/i, "")); return m ? m[1].toUpperCase() : ""; }
    function splitFolder(files) {
        var groups = {}, k;
        (files || []).forEach(function (f) { var p = prefixOf(f.name); (groups[p] = groups[p] || []).push(f); });
        var keys = Object.keys(groups).filter(function (p) { return groups[p].some(function (f) { return /load/i.test(f.name); }); });
        if (keys.length < 2) return [{ name: "", files: files }];
        var out = keys.map(function (p) { return { name: p, files: groups[p] }; });
        for (k in groups) if (keys.indexOf(k) < 0) out.push({ name: k || "other", files: groups[k] });
        return out;
    }

    /* ---------- 0.1.4 (ADR 0079): a shared Mundane checked against the player's generals ---------- */
    /* base capacity (maxUnits) per general type, from the client (docs/06-adventures/tactical/data/unit-stats.json,
       client 09eabb6, 2026-11-04); capacity skills are not counted */
    var CAPS = {"0":200,"3":200,"7":200,"8":200,"9":250,"11":220,"13":270,"14":270,"15":200,"16":220,"25":200,"29":180,"30":150,"31":165,"33":200,"36":200,"37":200,"43":180,"47":280,"50":140,"52":220,"56":200,"57":180,"60":160,"63":215,"64":190,"67":230,"72":170,"75":200,"77":200,"79":200,"85":180,"88":125,"96":10};
    function sharedSidecar(f) { try { var d = JSON.parse(String(f.text)); return d && d.format === "dma-shared-generals/1" && d.generals ? d.generals : null; } catch (_) { return null; } }
    function skillMap(x) { var o = {}; if (!x) return o;
        if (x.length != null) { for (var i = 0; i < x.length; i++) { var e = x[i]; if (e && Number(e.level) > 0) o[String(e.name || e.id)] = Number(e.level); } return o; }
        for (var k in x) if (x.hasOwnProperty(k) && Number(x[k]) > 0) o[k] = Number(x[k]); return o; }
    function lowerSkills(want, have) { return Object.keys(want).filter(function (k) { return Number(have[k] || 0) < Number(want[k]); }); }
    function sharedCheck(all, side, mine) {
        var gens = {}, camps = {}, used = {}, byId = {}, rows = [], map = [];
        mine.forEach(function (m) { byId[String(m.id)] = m; });
        all.forEach(function (t) { if (t.error || !t.generals) return; t.generals.forEach(function (g) {
            var o = gens[g.id] = gens[g.id] || { id: g.id, name: g.name, type: g.type, army: 0, camps: [] };
            o.army = Math.max(o.army, Number(g.total) || 0);
            if (g.target && o.camps.indexOf(g.target) < 0) o.camps.push(g.target);
            if (g.target) (camps[g.target] = camps[g.target] || []).push(g.id); }); });
        var ids = Object.keys(gens);
        ids.forEach(function (id) { if (byId[id]) used[id] = 1; });
        ids.forEach(function (id) {
            var g = gens[id], sc = side[id] || {}, type = Number(sc.type != null ? sc.type : g.type), want = skillMap(sc.skills), row = { id: id, name: strip(sc.name || g.name), type: type, army: g.army, camps: g.camps };
            if (byId[id]) { row.outcome = "SAME"; rows.push(row); return; }
            var free = mine.filter(function (m) { return !used[m.id] && m.kind !== "transporter"; });
            var same = free.filter(function (m) { return Number(m.type) === type; });
            var eq = same.filter(function (m) { return !lowerSkills(want, skillMap(m.skills)).length; })[0];
            var pick = eq || same[0], alt = null;
            if (!pick) alt = free.filter(function (m) { return (CAPS[String(m.type)] || 0) >= g.army && g.army > 0; })
                                .sort(function (a, b) { return (CAPS[String(a.type)] || 0) - (CAPS[String(b.type)] || 0); })[0] || null;
            if (eq) row.outcome = "EQUAL";
            else if (pick) { row.outcome = "SKILLS_DIFFER"; row.skills = lowerSkills(want, skillMap(pick.skills)); }
            else if (alt) { row.outcome = "ALTERNATIVE"; row.capacity = CAPS[String(alt.type)]; row.note = "not simulated"; pick = alt; }
            else row.outcome = "MISSING";
            if (pick) { used[pick.id] = 1; row.to = pick.id; row.toName = strip(pick.name); map.push({ from: id, fromName: row.name, to: pick.id, toName: row.toName }); }
            rows.push(row);
        });
        var out = {}; rows.forEach(function (r) { out[r.id] = r; });
        var covered = [], notCovered = [];
        Object.keys(camps).forEach(function (c) { (camps[c].some(function (id) { return out[id].outcome === "MISSING"; }) ? notCovered : covered).push(Number(c)); });
        return { rows: rows, map: map, camps: { covered: covered, notCovered: notCovered } };
    }
    function sharedFinding(sh) {
        var n = {}; sh.rows.forEach(function (r) { n[r.outcome] = (n[r.outcome] || 0) + 1; });
        var lvl = sh.camps.notCovered.length ? "error" : (n.SKILLS_DIFFER || n.ALTERNATIVE) ? "warn" : "info";
        var txt = sh.rows.map(function (r) { return r.name + ": " + r.outcome.toLowerCase().replace("_", " ") + (r.toName ? " → " + r.toName : "") + (r.skills && r.skills.length ? " (lower: " + r.skills.join(", ") + ")" : "") + (r.outcome === "ALTERNATIVE" ? " (capacity " + r.capacity + " for " + r.army + ", not simulated)" : ""); });
        return finding(lvl, "SHARED_GENERALS", null, "shared Mundane: " + Object.keys(n).map(function (k) { return n[k] + " " + k.toLowerCase().replace("_", " "); }).join(", ") + ". " + txt.join("; ") + ".",
            sh.camps.notCovered.length ? "Camps not covered by your generals: " + sh.camps.notCovered.join(", ") + ". Play them another way (camp by camp with your own generals) or leave this version." :
            (n.SKILLS_DIFFER || n.ALTERNATIVE) ? "Save my copy uses the generals proposed; expect other losses than the author's run where skills or generals differ." : "Your generals match: Save my copy and run it.");
    }
    function analyzeFolder(files, ctx) { return splitFolder(files).map(function (g) { var r = analyzeAdventure(g.files, ctx); r.adventure = g.name; return r; }); }

    function analyzeAdventure(files, ctx) {
        var side = null; files = (files || []).filter(function (f) { var sc = sharedSidecar(f); if (sc) { side = sc; return false; } return true; });   // 0.1.4
        var all = files.map(function (f) { var t = parse(f.name, f.text); t.mtime = f.mtime || 0; t.role = classify(t); return t; });
        var seenC = {};
        all.forEach(function (t) { if (t.error) return; var key = JSON.stringify(t.generals.map(function (g) { return [g.id, g.army, g.target, g.grid]; }));
            if (seenC[key]) t.duplicateOf = seenC[key]; else seenC[key] = t.file; });
        // a template that is mostly another player's, in a folder that is mostly yours, is a reference copy: not in the run
        var my = ctx && ctx.myGenerals, ids = {};
        if (my && my.length) {
            my.forEach(function (m) { ids[String(m.id)] = 1; });
            var share = function (t) { var n = t.generals.length; return n ? t.generals.filter(function (g) { return ids[g.id]; }).length / n : 1; };
            var real = all.filter(function (t) { return !t.error && t.generals.length; });
            if (real.some(function (t) { return share(t) >= 0.5; })) real.forEach(function (t) { if (share(t) < 0.5) t.foreign = true; });
        }
        var seq = sequence(all);
        var F = check(seq, all, ctx || {}), shared = null;
        if (side && my && my.length) { shared = sharedCheck(all.filter(function (t) { return seq.indexOf(t) >= 0; }), side, my); F.push(sharedFinding(shared)); }   // 0.1.4
        else if (side) F.push(finding("warn", "SHARED_GENERALS", null, "shared Mundane: your generals are not known yet (dma-skills.json), so they were not compared.", "Open the Specialists page once, then analyse again."));
        return { version: VERSION, shared: shared, templates: all.map(function (t) { return { file: t.file, role: t.role, generals: t.generals ? t.generals.length : 0,
                     targets: t.generals ? t.generals.filter(function (g) { return g.target; }).length : 0, buffs: t.buffs ? t.buffs.length : 0, remap: t.remap || null }; }),
                 run: seq.map(function (t) { return t.file; }), findings: F, choices: choices(seq, all, ctx || {}),
                 built: seq.filter(function (t) { return t.built; }).map(function (t) { return { file: t.file, text: t.text }; }) };
    }

    /* the remap as a new template text (the player's copy; the original stays) */
    function applyRemap(text, map) {
        var d = JSON.parse(String(text)), byFrom = {};
        (map || []).forEach(function (m) { byFrom[m.from] = m; });
        function fix(obj) { var o = {}, k; for (k in obj) if (obj.hasOwnProperty(k)) { var m = byFrom[k]; o[m ? m.to : k] = obj[k]; } return o; }
        if (d.content && d.tree) { var c; for (c in d.content) if (d.content.hasOwnProperty(c)) d.content[c] = fix(d.content[c]); return JSON.stringify(d); }
        return JSON.stringify(fix(d), null, 1);
    }

    /* ---------- client glue (AIR): only these touch files; the core above stays pure ---------- */
    function A() { return (typeof air !== "undefined") ? air : root.air; }
    function readText(file) { var a = A(), st = new a.FileStream(); st.open(file, a.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return t; }
    /* the files of a folder, or of the folder of the chosen template files (" / " between paths) */
    function readAir(pathOrList) {
        var a = A(); if (!a || !a.File) return { error: "no file access in this client" };
        var paths = String(pathOrList || "").split(" / ").map(function (x) { return x.trim(); }).filter(Boolean);
        if (!paths.length) return { error: "no folder or template files chosen" };
        var first = new a.File(paths[0]), dir = first.isDirectory ? first : first.parent, out = [];
        try {
            dir.getDirectoryListing().forEach(function (f) {
                if (f.isDirectory || f.isHidden || /\.(xlsx|png|jpg)$/i.test(f.name) || f.size > 2000000) return;
                out.push({ name: String(f.name).replace(/\.json$/i, ""), text: readText(f), mtime: f.modificationDate ? f.modificationDate.getTime() : 0 });
            });
        } catch (e) { return { error: "cannot read " + dir.nativePath + ": " + e }; }
        return { folder: String(dir.nativePath), files: out };
    }
    /* my generals (and transporters) from dma-skills.json, written by the control module */
    /* 0.1.6 (live YWC 2026-11-21 06:27Z; author: "dat de ghost er al is en de rest nog onderweg is dus normaal als je meerdere runs
       doet. Dus de controle erop moet kloppen en niet een run stoppen om de verkeerde redenen"): dma-skills.json lists only the
       generals the client sees now — 17 of YWC's 21 were on their way home, so the main attack counted as another player's
       template and was left out of the run. A general once seen as the player's stays the player's: the generals seen are
       registered in dma-generals-known.json ({id: {type, name, kind, firstSeen, lastSeen}}) and merged with the current list;
       knownGenerals(current, known, now) is the pure merge. */
    function knownGenerals(current, known, now) {
        var k = known || {}, out = [], seen = {};
        (current || []).forEach(function (g) { var id = String(g.id); seen[id] = 1; var o = k[id] || (k[id] = { firstSeen: now }); o.type = g.type; o.name = g.name; o.kind = g.kind; o.lastSeen = now; out.push(g); });
        Object.keys(k).forEach(function (id) { if (!seen[id]) out.push({ id: id, type: k[id].type, name: k[id].name, skills: null, kind: k[id].kind, away: true }); });
        return { list: out, known: k };
    }
    function myGeneralsAir() {
        try { var a = A(), f = new a.File(a.File.applicationDirectory.resolvePath("dma-skills.json").nativePath); if (!f.exists) return null;
              var d = JSON.parse(readText(f)), cur = (d.specialists || []).filter(function (s) { return s.kind === "general" || s.kind === "transporter"; })
                  .map(function (s) { return { id: s.id, type: s.type, name: s.name, skills: s.skills, kind: s.kind }; });
              var kf = new a.File(a.File.applicationDirectory.resolvePath("dma-generals-known.json").nativePath), known = {};
              try { if (kf.exists) known = JSON.parse(readText(kf)) || {}; } catch (_) { known = {}; }
              var m = knownGenerals(cur, known, new Date().toISOString());
              try { var st = new a.FileStream(); st.open(kf, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(m.known)); st.close(); } catch (_) {}
              return m.list; } catch (_) { return null; }
    }
    /* the player's own copy of a foreign template: "<name> (mine)" next to the original, never over it */
    function saveCopyAir(folder, file, text, map) {
        var a = A(), dir = new a.File(folder), name = String(file).replace(/\.(txt|data|json)$/i, "") + " (mine).txt", f = dir.resolvePath(name);
        if (f.exists) return { ok: false, reason: name + " already exists" };
        var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(applyRemap(text, map)); st.close();
        return { ok: true, file: name };
    }
    /* one call for the console: read, analyse with the player's rules, keep the texts for a remap copy */
    function analyzeAir(pathOrList, rules) {
        var r = readAir(pathOrList); if (r.error) return [{ error: r.error }];
        var mine = myGeneralsAir(), skillsBy = {};
        (mine || []).forEach(function (m) { skillsBy[String(m.id)] = m.skills; });
        var ctx = { myGenerals: mine, landingSpots: rules && rules.landingSpots != null ? rules.landingSpots : null, landingSource: rules && rules.landingSource || null,   // 0.1.5 (ADR 0092): no default starMethod: !!(rules && rules.starMethod),
                    skillsOf: mine ? function (id) { return skillsBy[String(id)] || null; } : null };
        return analyzeFolder(r.files, ctx).map(function (x) { x.folder = r.folder; x.texts = {}; r.files.forEach(function (f) { x.texts[f.name] = f.text; }); (x.built || []).forEach(function (b) { x.texts[b.file] = b.text; }); x.noGenerals = !mine; return x; });
    }

    var api = { version: VERSION, analyzeFolder: analyzeFolder, parse: parse, classify: classify, sequence: sequence, analyzeAdventure: analyzeAdventure, applyRemap: applyRemap, sharedCheck: sharedCheck, CAPS: CAPS,
                readAir: readAir, myGeneralsAir: myGeneralsAir, knownGenerals: knownGenerals, saveCopyAir: saveCopyAir, analyzeAir: analyzeAir };
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    root.DMA_Mundane = api;
})(typeof window !== "undefined" ? window : this);
