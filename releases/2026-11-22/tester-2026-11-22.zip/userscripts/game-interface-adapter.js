/*
 * Stable client filename: game-interface-adapter.js (sorts before pbc-* and user_*, so it loads before every PBC)
 * Game Interface Adapter 0.2.7 — the one place where DMA talks to the game's server (G-CAF layer "Platform Services").
 *
 * 0.2.7 (2026-11-16, author "ja": the four technical known-failing defects; tester kf-buff-wrapper-guard): the permit the adapter opens carries a mark that only the adapter writes,
 *   ctx.adapter === true (a copy of the caller's ctx; the caller's own `adapter` field is overwritten). Control's wrapper (control 0.2.110) is the BACKSTOP of ADR 0073 point 4:
 *   for a send that carries the mark it defers the kind / already-buffed check to this adapter (guardBuff, BUFF ACTION, the game's own check), which has already run; an
 *   action 61 without the mark (a direct permit("buff") by anything else) is guarded by the wrapper itself. WHERE THE BUFF GUARD LIVES: here, as before (ADR 0073 point 2);
 *   this change only lets the two guards agree. No other behaviour change.
 *   Unit: tests/unit/game-interface-adapter.test.js (the permit control receives carries adapter: true, also when the caller's ctx claims adapter: false or is absent).
 *   Integration: tests/integration/game-interface-adapter-control.test.js (real control + adapter: a buff the adapter lets through, a Treat on a buffed building, still reaches the game
 *   with the wrapper installed; control 0.2.110 and the moved tests/integration/buff-wrapper-guard.test.js).
 * 0.2.6 (2026-11-16, ADR 0075 R-2 / R-4, coordinator batch item 3.6): ACCEPT_TRADE_MARKET (1051, class "trade") is registered — accepting an offer on the Trade Office market, the sender being the trade office buyer
 *   (user_dma_trade_office.js). The client's accept message is dAcceptTradeVO { uniqueID, costs } (client.swf, 2026-11-16). Class "trade": no permit; the visit and start-up holds count (the market is the
 *   player's, but a send while the island is loading or visited is refused with retry, like a build). No other behaviour change.
 *   Unit: tests/unit/game-interface-adapter.test.js (a registered ACCEPT_TRADE_MARKET passes at home, is refused under the start-up hold and under a visit hold). Integration:
 *   tests/integration/game-interface-adapter-control.test.js (real control + adapter: the 1051 message reaches the game).
 * 0.2.5 (2026-11-16, tester round 2 on ADR 0073: kf-adapter-trusts-forged-ctx-stack): stackOf() no longer returns a caller's ctx.stack. The item is the
 *   star menu's own — found by the payload's unique id in getBuffsSortedForStarMenu, then getAvailableBuffs_vector. Only when the menu cannot be read at
 *   all does a claimed ctx.stack count, and then only when its own unique id equals the payload. So a PremiumAccount-looking stack unrelated to the payload
 *   unlocks neither ctx.zoneBuff on a buffed building nor a BUFF ACTION nor the game's own check. Unit: tests/unit/game-interface-adapter.test.js (a forged
 *   stack is ignored; the menu's item is used) and tests/unit/adapter-forged-ctx-stack.test.js. Integration: the same test with the real control
 *   loaded (the forged zone buff onto a buffed building is refused and nothing reaches the game).
 *
 * 0.2.4 (2026-11-16, coordinator, model v3.18 PR #431; ELS-32's exception is a property of the buff KIND): the game fact BUFF ACTION (acting kind, acted-on
 *   kind, replaces | stops). guardBuff / guardFill let a buff onto a buffed building only when the item's kind acts on the running buff's kind
 *   per the registered facts; ctx.replace and ctx.was are DROPPED (a caller's claim is no longer the exception). The item's kind is read from
 *   its definition name (ctx.stack or its unique id); an unknown item or an unregistered pair keeps "already buffed (ELS-32)". A use is recorded
 *   as the fact "buff action used". WHY HERE: the adapter already owns every buff guard and reads the game's definitions, a separate facts module
 *   would be a second reader of the same guard; the facts are exposed (buffActions(), buffAction()) so the event manager reads its pair from them.
 *   Registered copy: docs/05-ontology/dma/facts/buff-actions.yaml, mirrored as BUFF_ACTIONS_REGISTERED. Watcher (ADR 0042): verify() looks both kinds up
 *   in global.map_BuffName_BuffDefinition and records "buff action differs" / "buff actions not verified"; the game's own marker is still unread
 *   (probe src/tools/user_dma_probe_buffs.js, PR #432, to be run live), so the watcher checks that both kinds exist and reports their exclusivity groups.
 *   Needs green 0.8.28 not to send replace (harmless if it does: the flag is ignored). Unit: tests/unit/buff-actions-registered.test.js (mirror equals
 *   the file) and tests/unit/game-interface-adapter.test.js (acts-on passes, other kind / unknown item refused, watcher). Integration:
 *   tests/integration/dma-trick-treat.test.js and dma-tk41-transaction.test.js (the Treat replaces its trick through the adapter, no ctx.replace).
 *
 * 0.2.3 (2026-11-16, ADR 0073 migration, coordinator batch item 2): the remaining senders are registered. Seven messages: the mail and
 *   DISMISS_MAILS 1201 — class "mail": no permit, no pace, and only the start-up hold counts; control's own atHome / rtAwayOk reading
 *   stays the agenda and decides whether a trade is taken while away) and the quest pick-up (QUEST_PICKUP 141, class "pickup": a
 *   finished production's Pick-up button; no pace — the sender staggers its calls). Sources: control's CMD table and the client's
 *   Enums::COMMAND (none carries a game name yet, as ZONE_REFRESH does, so the table check skips them). Nothing else changes.
 *   Unit: tests/unit/game-interface-adapter.test.js (mail and pick-up register; the mail class passes under a visit hold and is
 *   refused under the start-up hold; an unregistered name is refused). Integration: tests/integration/dma-mail-round.test.js and
 *   dma-pickups.test.js run through the adapter in the migration PRs of control and quest.
 *
 * 0.2.2 (2026-11-16, architect review of #412–#422, decisions (a), (b), (c), (e)): a context flag is a CLAIM by the caller, and an exemption the
 *   caller declares for itself is not a guard. The adapter now checks each claim. (a) ctx.away is accepted only when the zone in view
 *   is not the home island (gi.isOnHomzone() is false, else the viewed zone id differs from the player's home zone id); otherwise
 *   the send is refused "away claimed at home" (not a retry) — and when it cannot be told, it is refused (fail closed). (c)
 *   ctx.zoneBuff exempts a STAR_ITEM from the building guard only when the item is a zone-sort buff: the star item found by
 *   ctx.stack or by its unique id is of a type that starts "PremiumAccount"; any other item runs the building guard. (b)
 *   ctx.replace passes only when ctx.was names the buff that runs on that building (green's order.was: a Treat replacing its trick)
 *   and the running buff is that one; otherwise "already buffed" stands. A passed replace is recorded as the fact "buff replaced"
 *   (was, by). (e) EVENT_FILL asks the game's IsApplyable when the fill stack offers it (the stack is found by ctx.stack or its unique
 *   id, in the star menu or the available buffs); only when it does not, the event's own list of fillable buildings
 *   (DMA_Event.match) decides; neither = refused. The tribute, already-buffed and buff-column refusals stay.
 *   Unit: tests/unit/game-interface-adapter.test.js (away claimed at home / away verified; zoneBuff with a premium item and with a
 *   building buff; replace with and without a matching was; EVENT_FILL by IsApplyable, by the event list, by neither).
 *   Integration: tests/integration/action61-guard-bypass.test.js (unchanged expectations still hold).
 * 0.2.1 (2026-11-16, tester batch on ADR 0073 (PR #423); coordinator): (1) ACTION 61 HAS NO BYPASS. The buff guard was keyed on the name
 *   APPLY_BUFF, so STAR_ITEM (guard none) and EVENT_FILL (amount only) carried the same action number unguarded. Now a STAR_ITEM that
 *   targets a building (a grid above 0 with a building there, at home, no ctx.away, no ctx.zoneBuff) runs the full buff guard; an
 *   island-wide zone buff (premium) says so with ctx.zoneBuff = true and stays exempt, as do the adventure's own away sends. An
 *   EVENT_FILL that finds a building at its grid refuses a tribute (*_Mini), a building that already carries a buff (ELS-32,
 *   ctx.replace excepted) and a kind whose buff column says no; a deposit/event building that is not on control's verified list
 *   goes (the game's own check is not asked for a fill). (2) The context travels to control: the permit is opened with it,
 *   permit(name, true, ctx), so control's wrapper can honour ctx.away; and when the game answers false the adapter reads control's
 *   lastBlock() (reason, retry: a visit or start-up hold) so that a hold refusal carries retry: true even when it came from the wrapper.
 *   Unit: tests/unit/game-interface-adapter.test.js (STAR_ITEM / EVENT_FILL guards, zoneBuff exemption, lastBlock retry).
 *   Integration: tests/integration/action61-guard-bypass.test.js (moved from tests/known-failing/kf-action61-guard-bypass).
 * 0.2.0 (2026-11-16, ADR 0073 THE SEND-OWNER RULE, approved by the author 2026-11-16, "ja"): the adapter is the only owner of
 *   every server send. Live finding (ADR 0064, Error #1037): control's SendServerAction wrapper is NOT in the send path — the
 *   ActionScript interface ignores the assignment — so nothing was guarded live. The adapter therefore decides itself, and
 *   works whether or not control's wrapper is installed:
 *   (1) the registry grows: BUILD 50, UPGRADE_BUILDING 60, APPLY_BUFF 61 (a building), STAR_ITEM 61 (a star item or a zone
 *       buff, no building), EVENT_FILL 61 (an event deposit fill), SPECIALIST_TASK 95, DEMOLISH (a zone call, sendDemolish);
 *       every command has a class (production, army, build, upgrade, buff, star, fill, specialist, demolish) and a guard kind.
 *   (2) GUARDS, one per command kind: APPLY_BUFF — the building must be readable, a tribute (*_Mini) never, a building that
 *       already carries a buff never (ELS-32; ctx.replace = true only for the construction manager's deliberate replace
 *       order), a kind on control's verified list (DMA_Control.kinds(), "buff" column: buff !== false) goes, any other kind only
 *       if the game's own check accepts (the buff stack's IsApplyable answers an object; the stack is ctx.stack or found by
 *       its unique id); UPGRADE_BUILDING — control's guardUpgrade (verified kind, never above the maximum level ELS-33, no
 *       upgrade running), no control = refused; DEMOLISH — verified kinds with demolish !== false, the expected name; EVENT_FILL
 *       — an amount above 0; every send — the START-UP hold and the VISIT hold of control (ctx.away = true: the sender's own
 *       run is on an adventure island; only the start-up hold applies then — ADR 0073 open point for the architect).
 *   (3) PACE per command class (setPace(ms, class)); the answer of a pace or hold refusal carries retry: true — a transient
 *       "not now", which an executor must not turn into a decline.
 *   (4) sendAction / sendMessage / sendDemolish answer { ok: true, result } or { ok: false, refused: true, reason, why,
 *       retry? }; why = reason (0.1.0 name). A game that answers false (control's wrapper, if installed, refusing) is a refusal.
 *   (5) control's permit is opened by the adapter internally for exactly the one call (class -> permit name) and closed in a
 *       finally; a module never calls DMA_Control.permit again. Refusals are recorded as the fact "send refused" (once a
 *       minute per command and reason).
 *   Unit: tests/unit/game-interface-adapter.test.js (registry, guards per kind, holds, pace per class, retry flag, permit
 *   opened for one call). Integration: tests/integration/game-interface-adapter-control.test.js (adapter + real control with
 *   its wrapper installed AND with the wrapper absent: a tribute, an already buffed building and an upgrade at maximum
 *   level are refused in both worlds; a verified mine goes; the permit is closed afterwards).
 *
 * 0.1.0 (2026-11-16, architecture review 2026-11-16 finding #2 (High) and #9 (ADR 0042), §5.10: "the single place to
 *   rate-limit and refuse sends"): replaces the one-line placeholder. First version, nothing uses it yet — application
 *   PBCs move behind it one module per change ([impl], ADR 0039), starting with the newest (troops, zombies, premium,
 *   event); see docs/proposals/structural-proposals-2026-11-16.md. What it offers:
 *   - COMMANDS, the registered command table: every server command a module may send, by NAME, with its number, the
 *     kind of call (message = mClientMessages.SendMessagetoServer, action = gi.SendServerAction), and its SOURCE (ADR
 *     0042: a fact the code uses but DMA does not create names its source). A command not in the table is refused.
 *   - verify(): the WATCHER of that table (ADR 0042, ADR 0064 §2: "re-read from Enums::COMMAND when the client version
 *     changes"): for every message command whose game name is known it reads Enums::COMMAND[name] from the client and
 *     reports a difference as a fact ("command table differs", P-fact, no TK); a name the client does not have is
 *     reported too. It runs once at start-up and on demand; it never changes the table itself.
 *   - sendMessage(name, vo [, zone]) / sendAction(name, a, grid, b, payload): pass the guard, keep the pace (one send
 *     per paceMs, default 300 ms; a send inside the pace is refused, not queued — the caller's executor decides), then
 *     call the game. Every result is { ok, refused?, why? }.
 *   - setGuard(fn): fn(name, command, args) -> true | "reason" — the refusal point (e.g. a tester whose client differs,
 *     a visit hold); default: refuse while the verified table reported a difference for that command.
 *   - newVO(className): a game value object by its class name (Communication.VO::…).
 *   - readers the modules use today: atHome(), buildingAt(grid), buildingsNamed(name), zoneId().
 *   Unit: tests/unit/game-interface-adapter.test.js (table, refusal of an unknown name, guard, pace, verify -> fact).
 *   Integration: tests/integration/game-interface-adapter-troops.test.js (the troop manager's two sends, expressed
 *   through the adapter, reach the game exactly as the troop manager's own gateway sends them today — the pattern for
 *   moving a PBC behind the adapter without changing what is sent).
 */
(function (root) {
    "use strict";
    if (root.GCAF_GameInterface && root.GCAF_GameInterface.version) return;
    var VERSION = "0.2.7";
    var SRC_0064 = "client.swf v1.6.0.1 Enums.COMMAND, decompiled 2026-11-13 (ADR 0064)";
    var COMMANDS = {
        START_TIMED_PRODUCTION:        { kind: "message", cls: "production", value: 91,   game: "START_TIMED_PRODUCTION", source: SRC_0064, users: ["troops", "event"] },
        PRODUCTION_MOVE_UP:            { kind: "message", cls: "production", value: 1025, game: null, source: SRC_0064 + " (move up; game name not recorded)" },
        PRODUCTION_MOVE_DOWN:          { kind: "message", cls: "production", value: 1026, game: null, source: SRC_0064 + " (move down; game name not recorded)" },
        PRODUCTION_REMOVE:             { kind: "message", cls: "production", value: 1027, game: "PRODUCTION_REMOVE", source: SRC_0064 },
        PRODUCTION_MOVE_TOP:           { kind: "message", cls: "production", value: 1028, game: null, source: SRC_0064 + " (move to top; the repository's name, game name not recorded)", users: ["troops"] },
        PRODUCTION_MOVE_BOTTOM:        { kind: "message", cls: "production", value: 1029, game: null, source: SRC_0064 + " (move to bottom; game name not recorded)" },
        PRODUCTION_CANCEL_ALL_WAITING: { kind: "message", cls: "production", value: 1030, game: "PRODUCTION_CANCEL_ALL_WAITING", source: SRC_0064 },
        RAISE_ARMY:                    { kind: "message", cls: "army", value: 1031, game: null, source: "dRaiseArmyVO load, user_dma_adventure.js / user_dma_zombies.js (probe 2026-11-02); game name not recorded", users: ["adventure", "zombies"] },
        ACCEPT_TRADE_MAIL:             { kind: "message", cls: "mail", value: 1050, game: null, source: "control CMD table; client COMMAND.ACCEPT_TRADE_MAIL (ADR 0010 trade gateway)", users: ["control"] },
        DECLINE_TRADE:                 { kind: "message", cls: "mail", value: 1053, game: null, source: "control CMD table (ADR 0010; game name not recorded)", users: ["control"] },
        INITIATE_TRADE:                { kind: "message", cls: "mail", value: 1049, game: null, source: "control CMD table (ADR 0010; game name not recorded)", users: ["control"] },
        GET_INBOX_HEADERS:             { kind: "message", cls: "mail", value: 1175, game: null, source: "control CMD table (mail window; game name not recorded)", users: ["control"] },
        GET_INBOX_BODY:                { kind: "message", cls: "mail", value: 1177, game: null, source: "control CMD table (mail window; game name not recorded)", users: ["control"] },
        DISMISS_MAILS:                 { kind: "message", cls: "mail", value: 1201, game: null, source: "control CMD table (mail window; loot collection)", users: ["control"] },
        ACCEPT_TRADE_MARKET:           { kind: "message", cls: "trade", value: 1051, game: null, source: "client.swf COMMAND.ACCEPT_TRADE_MARKET 1051 with dAcceptTradeVO { uniqueID, costs } (ADR 0075; game name not recorded)", users: ["trade office"] },
        QUEST_PICKUP:                  { kind: "message", cls: "pickup", value: 141, game: null, source: "quest 0.1.16: the Pick-up button's own call (zone, production type); game name not recorded", users: ["quest"] },
        ZONE_REFRESH:                  { kind: "message", cls: "army", value: 1037, game: null, source: "user_dma_adventure.js 0.2.45 (zone refresh); game name not recorded", users: ["adventure"] },
        BUILD:                         { kind: "action", cls: "build", guard: "none", value: 50, game: null, source: "control sendBuild (action 50, typeNr, grid); server action", users: ["control"] },
        UPGRADE_BUILDING:              { kind: "action", cls: "upgrade", guard: "upgrade", value: 60, game: null, source: "control sendUpgrade (action 60, grid); server action", users: ["control"] },
        APPLY_BUFF:                    { kind: "action", cls: "buff", guard: "buff", value: 61, game: null, source: "client.swf cPremiumAccountActivationWindow / cBuff (premium 0.1.0, 2026-10-26); server action: a buff on a BUILDING", users: ["control", "green", "premium", "buff manager", "building buffer"] },
        STAR_ITEM:                     { kind: "action", cls: "star", guard: "none", value: 61, game: null, source: "adventure executor: a star item or a zone buff (61, 0, grid or 0, id); no building of the home island", users: ["adventure"] },
        EVENT_FILL:                    { kind: "action", cls: "fill", guard: "fill", value: 61, game: null, source: "event fill (61, 0, deposit grid, amount, id); the amount is the 4th argument", users: ["event"] },
        SPECIALIST_TASK:               { kind: "action", cls: "specialist", guard: "none", value: 95, game: null, source: "adventure executor (ADR 0034): 95/4 move, 95/5 attack; server action", users: ["adventure", "zombies", "control"] },
        DEMOLISH:                      { kind: "demolish", cls: "demolish", guard: "demolish", value: null, game: null, source: "zone.SendDestructBuildingCommand(building, \"\") (control sendDemolish); a zone call, not a command number", users: ["control"] }
    };
    var PERMIT = { build: "build", upgrade: "upgrade", buff: "buff", star: "buff", fill: "buff", specialist: "specialist", demolish: "demolish" };
    var PACE0 = { production: 300, army: 0, build: 500, upgrade: 500, buff: 150, star: 0, fill: 1000, specialist: 0, demolish: 1000, mail: 0, pickup: 0 };
    var state = { paceMs: 300, pace: {}, lastAt: {}, lastSendAt: 0, sent: 0, refused: 0, differs: {}, verifiedAt: null, last: null };
    Object.keys(PACE0).forEach(function (k) { state.pace[k] = PACE0[k]; });
    var guard = null, seen = {};
    function game() { return root.game; }
    function gi() { var g = game(); return g && g.gi; }
    function fact(o) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", o); } catch (_) {} }
    function now() { return Date.now(); }
    function ctl() { return root.DMA_Control || null; }
    function refuse(name, why, retry) {
        state.refused += 1; state.last = { name: name, refused: true, why: why, at: now() };
        var k = name + "|" + String(why).slice(0, 60);
        if (!seen[k] || now() - seen[k] > 60000) { seen[k] = now(); fact({ fact: "send refused", command: name, reason: String(why), by: "game interface adapter " + VERSION }); }
        var r = { ok: false, refused: true, reason: why, why: why }; if (retry) r.retry = true; return r;
    }
    function nameOf(b) { try { return String(b.GetBuildingName_string()).replace(/^\s+|\s+$/g, ""); } catch (_) { return ""; } }
    function buildingAt(grid) {   // like control's reader: the zone the game holds, then the street data map
        try { var g = game(), z = (g && g.zone) || (g && g.gi && g.gi.mCurrentPlayerZone), b = z && z.GetBuildingFromGridPosition && z.GetBuildingFromGridPosition(Number(grid));
              if (!b && z && z.mStreetDataMap && z.mStreetDataMap.GetBuildingByGridPos) b = z.mStreetDataMap.GetBuildingByGridPos(Number(grid));
              return b || null; } catch (_) { return null; }
    }
    function verifiedKinds() { try { var C = ctl(); return C && typeof C.kinds === "function" ? C.kinds() : null; } catch (_) { return null; } }
    function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function activeBuff(b) {
        try { var pb = b.productionBuff; if (pb == null) return null; var def = (pb.GetBuffDefinition && pb.GetBuffDefinition()) || pb.buffDefinition || null;
              var n = def && def.GetName_string ? def.GetName_string() : ""; return n ? String(n) : "a buff"; } catch (_) { return "a buff"; }
    }
    function uidEq(x, y) { return x === y || !!(x && y && typeof x === "object" && x.uniqueID1 !== undefined && x.uniqueID1 === y.uniqueID1 && x.uniqueID2 === y.uniqueID2); }
    function stackOf(payload, ctx) {   // 0.2.5: the item is the star menu's own (by the payload's unique id); a caller's ctx.stack is never trusted
        var P; try { P = gi().mCurrentPlayer; } catch (_) { P = null; }
        var fns = ["getBuffsSortedForStarMenu", "getAvailableBuffs_vector"], readable = false;
        for (var f = 0; f < fns.length; f++) {
            try { if (!(P && typeof P[fns[f]] === "function")) continue; readable = true; var l = P[fns[f]]() || [];
                  for (var i = 0; i < l.length; i++) { try { if (l[i] && uidEq(l[i].GetUniqueId(), payload)) return l[i]; } catch (_) {} } } catch (_) {}
        }
        // the menu cannot be read at all: a claimed stack counts only when it carries the payload's own unique id
        if (!readable && ctx && ctx.stack) { try { if (uidEq(ctx.stack.GetUniqueId(), payload)) return ctx.stack; } catch (_) {} }
        return null;
    }
    function buffTypeOf(st) {   // the name of the star item's type: its definition's name, else GetType()
        var n = ""; try { var d = st.GetBuffDefinition && st.GetBuffDefinition(); n = d && d.GetName_string ? String(d.GetName_string()) : ""; } catch (_) {}
        if (!n) { try { n = st.GetType ? String(st.GetType()) : ""; } catch (_) {} }
        return n;
    }
    function isZoneBuff(st) { return !!st && /^PremiumAccount/.test(buffTypeOf(st)); }
    function trulyAway() {   // true / false, null when it cannot be told
        var G = gi();
        try { if (G && typeof G.isOnHomzone === "function") return G.isOnHomzone() === false; } catch (_) {}
        try { var h = G.mCurrentPlayer.GetHomeZoneId(), v = G.mCurrentViewedZoneID; if (h != null && v != null) return String(h) !== String(v); } catch (_) {}
        return null;
    }
    /* 0.2.4 (ELS-32, model v3.18, ADR 0042): the exception to "a buffed building gets no second buff" is a property of the buff KIND — the game fact
       BUFF ACTION (acting kind, acted-on kind, replaces | stops). The REGISTERED COPY is docs/05-ontology/dma/facts/buff-actions.yaml, mirrored here
       and held equal to the file by tests/unit/buff-actions-registered.test.js; the watcher (verify) reads the game. */
    var BUFF_ACTIONS_REGISTERED = [
        { acting: "Treat", acted_on: "HalloweenEvent_Horror", effect: "replaces", event: "halloween" }
    ];
    function kindIs(actual, kind) {   // the game's name contains the kind (case-insensitive) — an event prefix or suffix ("HalloweenTreatBuff", "HalloweenEvent_Horror") is the game's own
        var a = String(actual || "").toLowerCase(), k = String(kind || "").toLowerCase();
        return !!a && !!k && a.indexOf(k) >= 0;
    }
    function buffAction(acting, actedOn) {   // the registered action of the acting kind on the acted-on kind, or null
        for (var i = 0; i < BUFF_ACTIONS_REGISTERED.length; i++) { var x = BUFF_ACTIONS_REGISTERED[i];
            if (kindIs(acting, x.acting) && kindIs(actedOn, x.acted_on)) return x; }
        return null;
    }
    function actionOnRunning(on, payload, ctx, grid) {   // "" when the item's kind acts on the running buff's kind, else the refusal
        var st = stackOf(payload, ctx), act = st ? buffTypeOf(st) : "", x = act ? buffAction(act, on) : null;
        if (!x) return "already buffed: " + on + " (ELS-32; " + (act ? "'" + act + "' has no registered action on it" : "the item's kind is unknown") + ")";
        fact({ fact: "buff action used", grid: Number(grid), acting: act, acted_on: on, effect: x.effect, by: "game interface adapter " + VERSION });
        return "";
    }
    /* one guard per command kind; each answers "" (goes) or the reason it is refused */
    function guardBuff(grid, payload, ctx) {
        var b = buildingAt(grid); if (!b) return "no readable building at " + grid;
        var nm = nameOf(b); if (!nm) return "building not readable at " + grid;
        if (/_Mini$/i.test(nm)) return "tribute: " + nm;
        var on = activeBuff(b);
        if (on) { var why = actionOnRunning(on, payload, ctx, grid); if (why) return why; }
        var kinds = verifiedKinds();
        if (kinds && has(kinds, nm)) return kinds[nm].buff === false ? "no buff column for " + nm : "";
        var st = stackOf(payload, ctx);
        if (!st || typeof st.IsApplyable !== "function") return "not a verified kind and the game's own check is unavailable: " + nm;
        var r; try { r = st.IsApplyable(gi().mCurrentPlayer, gi(), Number(grid)); } catch (e) { return "the game's own check failed for " + nm; }
        return r !== null && typeof r === "object" ? "" : "the game's own check does not accept " + nm;
    }
    function guardUpgrade(grid) {
        var C = ctl(); if (!C || typeof C.guardUpgrade !== "function") return "upgrade guard unavailable (control not loaded)";
        var w; try { w = C.guardUpgrade(grid); } catch (e) { return "upgrade guard failed: " + e; }
        return w ? String(w) : "";
    }
    function guardDemolish(b, expect) {
        if (!b) return "no readable building"; var nm = nameOf(b), kinds = verifiedKinds();
        if (!kinds || !has(kinds, nm) || kinds[nm].demolish === false) return "kind not demolishable by DMA: " + (nm || "?");
        if (expect && expect.name && expect.name !== nm) return "a different building is there: " + nm + " (expected " + expect.name + ")";
        return "";
    }
    function holdRefusal(ctx, c) {
        var C = ctl(); if (!C || !C.visit || typeof C.visit.held !== "function") return "";
        var held = false, by = ""; try { held = !!C.visit.held(); by = (C.visit.state && C.visit.state().by) || ""; } catch (_) {}
        if (!held) return "";
        if (by === "startup") return "start-up hold (the home island is loading)";
        if (c && c.cls === "mail") return "";   // 0.2.3: the mail window does not depend on the island in view; control's own reading decides
        return ctx && ctx.away === true ? "" : "visit hold (" + (by || "visit") + ")";
    }
    function admit(name, args, ctx, want) {
        var c = COMMANDS[name];
        if (!c) return refuse(name, "not a registered command: " + name);
        if (c.kind !== want) return refuse(name, name + " is a " + (c.kind === "message" ? "message" : c.kind === "action" ? "server action" : "zone call") + ", not " + (want === "message" ? "a message" : want === "action" ? "a server action" : "a demolish"));
        if (state.differs[name]) return refuse(name, "the client's command table differs for " + name + " (" + state.differs[name] + ")");
        if (ctx && ctx.away === true && trulyAway() !== true) return refuse(name, "away claimed at home (the zone in view is the home island" + (trulyAway() === null ? " or unknown" : "") + ")");
        var h = holdRefusal(ctx, c); if (h) return refuse(name, h, true);
        if (guard) { var g; try { g = guard(name, c, args); } catch (e) { g = "guard failed: " + e; } if (g !== true) return refuse(name, String(g || "refused by the guard")); }
        var t = now(), pace = root.GCAF_GIA_NO_PACE ? 0 : (has(state.pace, c.cls) ? state.pace[c.cls] : state.paceMs), last = state.lastAt[c.cls] || 0;   // GCAF_GIA_NO_PACE: a test switch, like GCAF_GIA_NO_TIMER
        if (last && pace > 0 && t - last < pace) return refuse(name, "pace: " + pace + " ms between " + c.cls + " sends", true);
        return { ok: true, command: c, at: t };
    }
    function done(name, a, result) { state.lastAt[a.command.cls] = a.at; state.lastSendAt = a.at; state.sent += 1; state.last = { name: name, ok: true, at: a.at }; return { ok: true, result: result }; }
    function guardFill(grid, payload, ctx) {   // a fill that lands on a building is not a back door for a buff
        var b = buildingAt(grid); if (!b) return "";
        var nm = nameOf(b); if (/_Mini$/i.test(nm)) return "tribute: " + nm;
        var on = activeBuff(b); if (on) { var w0 = actionOnRunning(on, payload, ctx, grid); if (w0) return w0; }
        var kinds = verifiedKinds(); if (kinds && has(kinds, nm) && kinds[nm].buff === false) return "no buff column for " + nm;
        var st = stackOf(payload, ctx);   // 0.2.2: the game's own check when the stack offers it, else the event's list of fillable buildings
        if (st && typeof st.IsApplyable === "function") {
            var r; try { r = st.IsApplyable(gi().mCurrentPlayer, gi(), Number(grid)); } catch (e) { return "the game's own check failed for " + nm; }
            return r !== null && typeof r === "object" ? "" : "the game's own check does not accept the fill on " + nm;
        }
        try { var E = root.DMA_Event; if (E && typeof E.match === "function" && E.match(nm, now())) return ""; } catch (_) {}
        return "not a fillable building (the stack has no game check and the event does not list " + nm + ")";
    }
    function marked(ctx) {   // 0.2.7: a copy of the caller's context with the one mark only this adapter writes
        var o = {}, k; if (ctx && typeof ctx === "object") for (k in ctx) if (Object.prototype.hasOwnProperty.call(ctx, k)) o[k] = ctx[k];
        o.adapter = true; return o;
    }
    function withPermit(cls, fn, ctx) {
        var C = ctl(), p = PERMIT[cls], open = false;
        try { if (p && C && typeof C.permit === "function") { C.permit(p, true, marked(ctx)); open = true; } } catch (_) {}
        try { return fn(); } finally { if (open) { try { C.permit(p, false); } catch (_) {} } }
    }
    function sendMessage(name, vo, zone, ctx) {
        var a = admit(name, [vo, zone], ctx, "message"); if (!a.ok) return a;
        try { var G = gi(); G.mClientMessages.SendMessagetoServer(a.command.value, zone != null ? zone : G.mCurrentViewedZoneID, vo); }
        catch (e) { return refuse(name, "send failed: " + e); }
        return done(name, a);
    }
    function refusedByGame(name, since) {   // 0.2.1: the wrapper's own reason, with retry for a hold
        var C = ctl(), lb = null; try { lb = C && typeof C.lastBlock === "function" ? C.lastBlock() : null; } catch (_) {}
        if (lb && lb.at >= since) return refuse(name, "the game interface refused the send: " + lb.reason, lb.retry === true);
        return refuse(name, "the game interface refused the send (control's safeguard or the client)");
    }
    function sendAction(name, x, grid, y, payload, ctx) {
        var a = admit(name, [x, grid, y, payload], ctx, "action"); if (!a.ok) return a;
        var why = "", g = a.command.guard;
        if (g === "buff") why = guardBuff(grid, payload, ctx);
        else if (g === "upgrade") why = guardUpgrade(grid);
        else if (g === "fill") why = Number(y) > 0 ? guardFill(grid, payload, ctx) : "no amount to fill";
        else if (a.command.cls === "star" && !(ctx && ctx.away === true) && !(ctx && ctx.zoneBuff === true && isZoneBuff(stackOf(payload, ctx))) && Number(grid) > 0 && buildingAt(grid)) why = guardBuff(grid, payload, ctx);   // 0.2.1
        if (why) return refuse(name, why);
        var r;
        try { r = withPermit(a.command.cls, function () { return gi().SendServerAction(a.command.value, x, grid, y, payload); }, ctx); } catch (e) { return refuse(name, "send failed: " + e); }
        if (r === false) return refusedByGame(name, a.at);
        return done(name, a, r);
    }
    function sendDemolish(grid, expect, ctx) {
        var a = admit("DEMOLISH", [grid, expect], ctx, "demolish"); if (!a.ok) return a;
        var b = buildingAt(grid), why = guardDemolish(b, expect); if (why) return refuse("DEMOLISH", why);
        var r;
        try { r = withPermit("demolish", function () { return gi().mCurrentPlayerZone.SendDestructBuildingCommand(b, ""); }); } catch (e) { return refuse("DEMOLISH", "send failed: " + e); }
        if (r === false) return refuse("DEMOLISH", "the game interface refused the demolish");
        return done("DEMOLISH", a, r);
    }
    function watchBuffActions() {   // 0.2.4 (ADR 0042): the watcher of the registered BUFF ACTION facts — the game is the source
        var out = { checked: 0, differs: [], groups: {} }, map = null, g = null;
        try { g = root.swmmo.getDefinitionByName("global"); map = g && g.map_BuffName_BuffDefinition; } catch (_) {}
        if (!map) { fact({ fact: "buff actions not verified", why: "global.map_BuffName_BuffDefinition is not readable", by: "game interface adapter " + VERSION }); return out; }
        var names = []; try { for (var k in map) names.push(String(k)); } catch (_) {}
        BUFF_ACTIONS_REGISTERED.forEach(function (x) {
            out.checked += 1;
            [["acting", x.acting], ["acted_on", x.acted_on]].forEach(function (p) {
                var hit = names.filter(function (n) { return kindIs(n, p[1]); })[0];
                if (!hit) { out.differs.push(x.acting + " -> " + x.acted_on + ": the game has no buff " + p[1]); return; }
                try { var d = map[hit]; out.groups[hit] = d && typeof d.GetExclusivityGroup === "function" ? d.GetExclusivityGroup() : null; } catch (_) {}
            });
        });
        out.differs.forEach(function (w) { fact({ fact: "buff action differs", why: w, source: "docs/05-ontology/dma/facts/buff-actions.yaml", by: "game interface adapter " + VERSION }); });
        return out;
    }
    function verify() {
        var K = null, out = { at: now(), checked: 0, differs: {} };
        try { K = root.swmmo.getDefinitionByName("Enums::COMMAND"); } catch (e) { out.error = "Enums::COMMAND not readable: " + String(e).slice(0, 80); }
        Object.keys(COMMANDS).forEach(function (n) {
            var c = COMMANDS[n]; if (c.kind !== "message" || !c.game || !K) return;
            out.checked += 1;
            var v; try { v = K[c.game]; } catch (_) { v = undefined; }
            if (v === undefined) out.differs[n] = "the client has no " + c.game;
            else if (Number(v) !== c.value) out.differs[n] = "client " + v + ", table " + c.value;
        });
        state.differs = out.differs; state.verifiedAt = out.at;
        Object.keys(out.differs).forEach(function (n) { fact({ fact: "command table differs", command: n, value: COMMANDS[n].value, why: out.differs[n], source: COMMANDS[n].source, by: "game interface adapter " + VERSION }); });
        if (out.error) fact({ fact: "command table not verified", why: out.error, by: "game interface adapter " + VERSION });
        try { out.buffActions = watchBuffActions(); } catch (_) {}   // 0.2.4
        return out;
    }
    function newVO(cls) { return new (root.swmmo.getDefinitionByName("Communication.VO::" + cls))(); }
    function atHome() { try { var C = root.DMA_Control; if (C && typeof C.atHome === "function") return !!C.atHome(); } catch (_) {} return false; }
    function zoneId() { try { return gi().mCurrentViewedZoneID; } catch (_) { return null; } }
    function buildingsNamed(name) {
        var out = [];
        try { var v = gi().mCurrentPlayerZone.mStreetDataMap.GetBuildings_vector();
              for (var i = 0; v && i < v.length; i++) { try { if (v[i] && String(v[i].GetBuildingName_string()) === name) out.push(v[i]); } catch (_) {} } } catch (_) {}
        return out;
    }
    var api = {
        version: VERSION,
        buffActions: function () { return JSON.parse(JSON.stringify(BUFF_ACTIONS_REGISTERED)); },   // 0.2.4: the registered facts (event manager reads its counter pair here)
        buffAction: function (acting, actedOn) { var x = buffAction(acting, actedOn); return x ? JSON.parse(JSON.stringify(x)) : null; },
        commands: function () { return JSON.parse(JSON.stringify(COMMANDS)); },
        command: function (name) { return COMMANDS[name] ? COMMANDS[name].value : null; },
        sendMessage: sendMessage, sendAction: sendAction, sendDemolish: sendDemolish, verify: verify, newVO: newVO,
        setGuard: function (fn) { guard = typeof fn === "function" ? fn : null; },
        setPace: function (ms, cls) { var n = Number(ms); if (n >= 0 && n <= 60000) { if (cls) state.pace[cls] = n; else { state.paceMs = n; Object.keys(state.pace).forEach(function (k) { state.pace[k] = n; }); } } return cls ? state.pace[cls] : state.paceMs; },
        atHome: atHome, zoneId: zoneId, buildingAt: buildingAt, buildingsNamed: buildingsNamed,
        status: function () { return JSON.parse(JSON.stringify(state)); }
    };
    root.GCAF_GameInterface = api;
    try { if (!root.GCAF_GIA_NO_TIMER && typeof setTimeout === "function") setTimeout(function () { try { verify(); } catch (_) {} }, 15000); } catch (_) {}
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
