/*
 * user_dma_adventure_manager.js — actor role AR17 "adventure manager" (TK17 adventure managing, self-activating; it
 * requests TK18 adventure completing of the adventure completer, user_dma_adventure.js). ADR 0088 S-5.
 *
 * 0.1.1 (2026-11-20, author: "Settings als keep it running is typisch iets dat je boven alle settings wil"): the agenda is the Run setting
 *   — adv.keep.res (any adventure in the star, by its star name), adv.keep.version (empty = the book's default version) and adv.keep.runs
 *   (0 = until the player stops it). The manager counts the runs it requested for that setting; at the number it stops requesting and says
 *   "N of N runs done". Changing the adventure or the version starts the count again. adv.ft.keep / adv.ywc.keep are retired.
 *   Unit: tests/unit/adventure-manager.test.js. Integration: tests/integration/adventure-manager-keeps-ft.test.js.
 * 0.1.0 (2026-11-20, author: "het runnen van FT en op orde houden van alles zodat we hem kunnen blijven runnen"): NEW.
 *   AGENDA: an adventure is on the agenda while the player's rule adv.<id>.keep is on (ft, ywc). The manager does
 *     nothing itself (a manager wakes up and wakes someone else up): once a minute, while the Adventure switch
 *     (adv.auto) is on, it requests the next run of the first adventure on the agenda (TK18 request with
 *     by "adventure manager") through the completer's own API, DMA_Adventure.runOnce, with the book's default version.
 *   It requests only when (read, never scanned — ADR 0040):
 *     - no run is going (DMA_Adventure.status() is null, DONE or stopped) and the player is at home (DMA_Control.atHome);
 *     - the location manager's stock shows the adventure in the star above adv.<id>.minStock ("star:Adventure:<res>");
 *     - the last run did not stop less than adv.keep.retryMin minutes ago (default 30). A stopped run is a decline of
 *       the completer: the manager records it once as a help notice for the player ("always inform me"), and
 *       tries again after the pause — the completer checks its own truth clauses (troops, generals) when it acts.
 *   The troop plan (dma-troops-plan.json, ADR 0072) is set to the agenda's adventure when it names another adventure,
 *     with the losses the book recorded for its version, so the troop manager trains ahead.
 *   TK17 per period (one hour): request (itself) -> promise; declared and accepted at the end of the period.
 *   GLOBAL: DMA_AdventureManager = { version, owner, actor, agenda, tick, last }.
 * Unit expectation:        with adv.ft.keep on, FT 18 in the star and no run going, tick() requests runOnce("ft", folder of
 *                          the default version, its name, false, {by: "adventure manager"}); with a run going, an empty
 *                          star, the player away, the switch off, or a stop 10 min ago it requests nothing; a stop is
 *                          told to the player once.
 * Integration expectation: tests/integration/adventure-manager-keeps-ft.test.js — with the real policy, agents stock and
 *                          a fake completer, two runs follow each other and TK17/TK18 facts are in the book.
 */
(function (root) {
    "use strict";
    var VERSION = "0.1.1", ACTOR = "adventure manager", TK = "TK17", PERIOD_MS = 3600000, MIN_TICK_MS = 55000;
    var last = [], helps = [], count = { sig: "", n: 0 }, lastTickAt = 0, period = null, seq = 0, toldStop = {}, lastPlanSig = "";

    function pol(k, d) { try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); if (v != null && v !== "") return v; } } catch (_) {} return d; }
    function yes(k) { var v = pol(k, false); return v === true || String(v) === "true"; }
    function num(k, d) { var v = Number(pol(k, d)); return isNaN(v) ? d : v; }
    function record(kind, data) { try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record(kind, data); } catch (_) {} }
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function readJson(name) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath); if (!f.exists) return null;
              var st = new A.FileStream(); st.open(f, A.FileMode.READ); var t = st.readUTFBytes(st.bytesAvailable); st.close(); return JSON.parse(t); } catch (_) { return null; }
    }
    function writeJson(name, obj) {
        try { var A = air_(), f = new A.File(A.File.applicationDirectory.resolvePath(name).nativePath), st = new A.FileStream();
              st.open(f, A.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (_) {}
    }
    function A() { return root.DMA_Adventure || null; }
    function resOf(id) { try { return A().resOf ? A().resOf(id) : (A().RES || {})[id]; } catch (_) { return null; } }
    function inStar(res) { try { var s = root.DMA_Demo.stockNow() || {}; return Number(s["star:Adventure:" + res] || 0); } catch (_) { return 0; } }
    function atHome() { try { var C = root.DMA_Control; return !C || typeof C.atHome !== "function" || !!C.atHome(); } catch (_) { return false; } }
    function agenda() { var r = String(pol("adv.keep.res", "") || "").trim(); return r ? [r] : []; }   // 0.1.1: the Run setting
    function running() { try { var s = A().status(); return !!(s && s.state !== "DONE" && !s.stopped); } catch (_) { return false; } }
    function versionOf(res) {
        try { var e = (A().book() || {})[res]; if (!e || !e.versions || !e.versions.length) return null; var want = String(pol("adv.keep.version", "") || ""), v = null;
              if (want) e.versions.forEach(function (x) { if (x.name === want) v = x; });
              if (!v) v = e.versions[e.def || 0] || e.versions[0];
              return v && v.folder ? { name: v.name, folder: v.folder, mode: v.mode || "", runs: e.runs || [] } : null; } catch (_) { return null; }
    }
    function lastStop(v, now) {
        var r = (v.runs || []).filter(function (x) { return x.version === v.name; }).slice(-1)[0];
        if (!r || r.state !== "STOPPED") return null;
        var t = Date.parse(r.at) + (Number(r.min) || 0) * 60000; return { at: t, reason: r.reason || "", ago: now - t };
    }
    function help(text, key) {
        if (toldStop[key]) return; toldStop[key] = 1;
        helps.push({ at: new Date().toISOString(), text: text }); if (helps.length > 20) helps.shift();
        record("p", { fact: "the adventure manager asks the player for help", actor: ACTOR, text: text });
    }
    function c17(act, extra) { var d = { tk: TK, act: act, caseId: period.id, actor: ACTOR, period: period.id }, k; for (k in (extra || {})) d[k] = extra[k]; record("c", d); }
    function openPeriod(now) { seq += 1; period = { id: "advmgr@" + new Date(now).toISOString().slice(0, 13) + "#" + seq, at: now }; c17("request"); c17("promise"); }
    function closePeriod(why) { if (!period) return; c17("declare", { reason: why }); c17("accept"); period = null; }
    /* the troop manager plans for the agenda's adventure (ADR 0072): the plan file names it, with the book's losses when known */
    function planTroops(res, v) {
        var cur = readJson("dma-troops-plan.json") || {};
        if (cur.adventure === res) return false;
        var plan = { adventure: res, runs: Math.max(1, num("adv.keep.planRuns", 3)), losses: {}, source: ACTOR + " (agenda: adv keep)", at: new Date().toISOString() };
        var sig = JSON.stringify([plan.adventure, plan.runs]); if (sig === lastPlanSig) return false; lastPlanSig = sig;
        writeJson("dma-troops-plan.json", plan); record("p", { fact: "troop plan set by the adventure manager", adventure: res, runs: plan.runs, version: v.name });
        return true;
    }
    function tick(now) {
        now = now || Date.now();
        if (!yes("adv.auto")) return [];
        if (lastTickAt && now - lastTickAt < MIN_TICK_MS) return last;
        lastTickAt = now;
        var rows = [], ag = agenda();
        if (!period) openPeriod(now);
        if (!A()) { last = [{ rule: "R-ADV-KEEP", why: "the adventure completer is not loaded" }]; return last; }
        if (running()) { last = [{ rule: "R-ADV-KEEP", why: "a run is going" }]; if (now - period.at >= PERIOD_MS) closePeriod("end of the period"); return last; }
        for (var i = 0; i < ag.length; i++) {
            var id = ag[i], res = resOf(id), v = res ? versionOf(res) : null, n = res ? inStar(res) : 0, keep = num("adv." + id + ".minStock", 0);
            var sig = res + "|" + String(pol("adv.keep.version", "") || ""), max = num("adv.keep.runs", 0);
            if (count.sig !== sig) count = { sig: sig, n: 0 };
            if (max > 0 && count.n >= max) { rows.push({ rule: "R-ADV-KEEP", id: id, why: count.n + " of " + max + " runs done" }); continue; }
            if (!res) { rows.push({ rule: "R-ADV-KEEP", id: id, why: "no star name" }); continue; }
            if (!v) { rows.push({ rule: "R-ADV-KEEP", id: id, why: "no version in the book" }); help("Keep " + id.toUpperCase() + " running: no version of it in the adventure book - add one on the ADVS page.", "nov:" + id); continue; }
            if (n <= keep) { rows.push({ rule: "R-ADV-KEEP", id: id, why: "only " + n + " in the star (keep " + keep + ")" }); continue; }
            var ls = lastStop(v, now), retry = num("adv.keep.retryMin", 30) * 60000;
            if (ls && ls.ago < retry) {
                rows.push({ rule: "R-ADV-KEEP", id: id, why: "last run stopped " + Math.round(ls.ago / 60000) + " min ago: " + ls.reason });
                help(id.toUpperCase() + " stopped: " + ls.reason + ". I try again in " + Math.round((retry - ls.ago) / 60000) + " min; you may want to look.", "stop:" + id + ":" + ls.at);
                continue;
            }
            if (!atHome()) { rows.push({ rule: "R-ADV-KEEP", id: id, why: "away from home" }); break; }
            planTroops(res, v);
            var r = null; try { r = A().runOnce(id, v.folder, v.name, false, { by: ACTOR }); } catch (e) { r = { ok: false, reason: String(e) }; }
            if (r && r.ok) count.n += 1;
            c17("execute", { requested: "TK18", adventure: res, version: v.name, ok: !!(r && r.ok), reason: r && r.reason ? r.reason : "" });
            rows.push({ rule: "R-ADV-KEEP", id: id, res: res, version: v.name, inStar: n, requested: !!(r && r.ok), reason: r && r.reason ? r.reason : "" });
            break;   // one run at a time
        }
        if (period && now - period.at >= PERIOD_MS) closePeriod("end of the period");
        last = rows;
        writeJson("dma-adventure-manager.json", { format: "dma-adventure-manager/1", version: VERSION, at: new Date(now).toISOString(), agenda: ag, runs: { done: count.n, of: num("adv.keep.runs", 0) }, rows: rows, help: helps });
        return rows;
    }
    var api = { version: VERSION, owner: ACTOR, actor: ACTOR, agenda: agenda, tick: tick, runs: function () { return { done: count.n, of: num("adv.keep.runs", 0) }; }, last: function () { return last.slice(); } };
    root.DMA_AdventureManager = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    if (!root.DMA_ADVMGR_NO_TIMER && typeof root.setInterval === "function") { try { var t = root.setInterval(function () { try { tick(); } catch (_) {} }, 60000); if (t && t.unref) t.unref(); } catch (_) {} }
})(typeof window !== "undefined" ? window : this);
