/*
 * 0.1.119 (2026-11-21, ADR 0091): the ALL rules adv.aheadHome and adv.closeAtOnce are listed under Advanced; an adventure's own
 *   (YWC) shows in its row. Unit: tests/unit/adventure-ahead-home.test.js.
 * 0.1.118 (2026-11-21, ADR 0092): each adventure row shows its landing fields with their source and a colour — green "(game)"
 *   read from the game, blue "(online)" read online, grey "not seen yet"; Analyse passes that count (not the rule
 *   adv.mundane.landingSpots, which is gone). Unit: tests/unit/console-landing-source.test.js.
 * 0.1.117 (2026-11-21): the Run card's labels (Adventure, Version, How many) are light on the dark page — they were nearly invisible.
 * 0.1.116 (2026-11-20, tester feedback Zingu, #test-corner): ZG-01 the switch "Demo" is called "Demolish" (it was read as
 *   "demonstration"); ZG-05 the choice screen of a list rule (e.g. search.resourcesEnabled) has "Back to rules", which returns to the rules
 *   page it was opened from, not to the main page. Unit: tests/unit/console-tester-zg.test.js.
 * 0.1.115 (2026-11-20, author: "Als je een versie hebt gemaakt, dan moet je die versie kunnen selecteren op basis van het adventure je hebt
 *   gekozen, dus ook bovenaan. Als je de versie die je graag wil nog niet hebt, dan moet je naar het onderdeel waar je de versies kunt maken"):
 *   the Run card lists every adventure in the star (with or without a version) and, under Version, "+ make a new version…", which opens that
 *   adventure's row below, its group unfolded, scrolled into view; a version made there appears in the Run card at once. Start refuses
 *   without a version. Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.114 (2026-11-20, author: "waarom je alleen voor de speed settings een save button hebt, als je geselecteerd hebt als speler is het
 *   toch duidelijk dat je dat moet onthouden?"): Speed it up has no Save button any more — every tick is kept at once; a tick the policy
 *   refuses (two of one family) is undone with the reason. Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.113 (2026-11-20, author: "Zijn nog niet inklapbaar"): the client's engine does not fold <details>; each part now folds by a click on
 *   its header (▾ open, ▸ closed), Advanced too (closed at first); the state is kept per part. Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.112 (2026-11-20, author: "in de speed it up overzicht mis ik vortex en obs ... zorg dat je de verschillende onderdelen kunt
 *   dichtklappen als ze goed staan"): every part of ADVS folds (Run, Speed it up, All adventures, each adventure group), open or closed kept
 *   per part; Speed it up names the buffs (the game's text, else Black Vortex, Doggy Bag, the star charts, "horseshoe: …"), lists the
 *   Observatory's star charts with the Observatories ready and their cost (adventure 0.2.99), and greys out by the families of
 *   adv.travel.exclusive. Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.111 (2026-11-20, author: "Settings als keep it running is typisch iets dat je boven alle settings wil ... selecteer alle items die je wil
 *   inschakelen om het te versnellen, maar items die andere items uitschakelen worden greyed out ... Bij het avontuur kies je hoe een aanval wordt
 *   gedaan ... Het moet veel logischer en overzichtelijker worden ingedeeld"): ADVS reads top-down. RUN: adventure (those with a version; the
 *   star count shown), version, how many (once / keep running / number of runs), Start / Stop, the retreat choice. SPEED IT UP: the pre-staging
 *   tick and one tick per travel or speed buff in the star; a tick greys out the buffs of its exclusivity group; Save. Then the adventures with
 *   their versions, then Advanced (closed): as is, camp by camp, retry, troop plan, Mundane, loot spots, short stock. Replaces 0.1.109's blocks.
 *   Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.110 (2026-11-20, author: "the guide leads to a very old guide"): the ADVS "guide" link opens the adventure's guide on
 *   settlersonlinewiki.eu (catalogue 0.1.3 guide), the tsowiki page only when that has none. Unit: tests/unit/catalogue-guides.test.js.
 * 0.1.109 (2026-11-20, author: "I dont see keep it running"): the ADVS page's "All adventures" card shows at its top the KEEP RUNNING rules
 *   (adv.<id>.keep for every adventure that has one, adv.keep.retryMin, adv.keep.planRuns) and the ALL rules every run uses (adv.retreat.on,
 *   adv.prestage, adv.asIs, adv.campByCamp); before, a keep rule sat only inside its adventure's opened row. Unit: tests/unit/console-advs-keep.test.js.
 * 0.1.108 (2026-11-20, author: "selecties die elkaar uitsluiten kun je niet combineren"): the choice dialog of a set rule with pick
 *   "travelBuffs" lists the travel speed-ups in the star (DMA_Adventure.travelBuffs), grouped by the game's exclusivity group; a refused
 *   save shows its reason (e.g. "X and Y exclude each other"). Unit: tests/unit/adventure-travel-buffs.test.js (the dialog source).
 * 0.1.107 (2026-11-18, author: "Neem de labels over in dit overzicht zodat de speler weet welke hij geselecteerd heeft of moet
 *   selecteren"): in a resource's settings every spot shows the player's label in an editable field (placeholder: the spot's fixed
 *   number, "Copper 04"), saved to the same label store as the main table; picked spots and geologist types are green and bold; the
 *   settings table has a dark background (the light text was unreadable on white). Unit: tests/unit/console-workflows-page.test.js.
 *   Integration: tests/integration/dma-workflows-console-overview.test.js.
 * 0.1.106 (2026-11-18, author: "Kijk ook hoe we het overzicht kunnen verbeteren. Welke workflows hebben we, openklappen als we details
 *   willen zien"): the WORKFLOWS page opens as an overview — one line per workflow (on for which resources, spots, geologists allocated,
 *   cycles and searches out, the last act); a click opens it into one line per resource (every picked spot by label with its live
 *   state, geologists, cycles, what it does now); a click on a resource opens its settings and its rows of the last cycle. Spot states
 *   come from green's facts and live reading (the location manager's memory was still empty right after a restart: every spot read
 *   "empty"); geologist types show their number (#59), since the game gives two types the same name. Unit:
 *   tests/unit/console-workflows-page.test.js. Integration: tests/integration/dma-workflows-console-overview.test.js.
 * 0.1.105 (2026-11-18, ADR 0086; author: "alle mogelijke locaties bekend, ze zijn voor alle eilanden gelijk, vaste volgorde en
 *   de speler kan hem een label geven. Deze blijft dus ongeacht wat is gevonden of niet"): an opened resource lists EVERY
 *   registered spot (DMA_Spots, user_dma_spots.js) in its fixed order: a deposit or mine on it as before, an empty spot as
 *   "spot NN · empty"; every row has the label field, its placeholder the spot's number ("Iron 03"); the geologists searching
 *   come first; a deposit on a grid that is not registered follows the list. The anonymous "empty" rows and the "known" rows
 *   are gone (kept only for a resource without registered spots). Unit: tests/unit/console-workflows-page.test.js.
 *   Integration: tests/integration/dma-spots-console.test.js.
 * 0.1.104 (2026-11-18, author: "Ik dacht dat we de speler een label lieten definieren, dan kan hij bij de workflow gemakkelijker zien
 *   welke hij wil"): every spot row of a resource (deposit, mine, known spot) has a LABEL field again (location.label.grid.<grid>,
 *   the existing label store and change path, kept by the silent refresh while typing); the WORKFLOWS page shows that label at each
 *   spot; a spot picked by a workflow that is on shows "WF" beside its status. Unit: tests/unit/console-workflows-page.test.js.
 *   Integration: tests/integration/dma-console-version-line.test.js (the real console with the real policy).
 * 0.1.103 (2026-11-18, ADR 0084 Workflows / Deposit Cycling): a WORKFLOWS button and page. Per mine resource: on/off, the
 *   spots picked from the fixed list of locations (the location manager's spots, with the player's own labels), the
 *   geologist types and how many, the build-queue places kept free and the reserve; below, what the workflow decided in
 *   its last cycle; and the start: when the player's mine on a spot runs empty, or now. The RULES page groups the workflow.* rules under "Workflows". Every change goes through the player
 *   policy. Unit: tests/unit/console-workflows-page.test.js. Integration: tests/integration/dma-workflows-managers-skip-spots.test.js.
 * 0.1.102 (2026-11-18, author: "Nee de knop is het belangrijkste, maak dat nu eerst"): a FEEDBACK button and page: the
 *   player's own words plus DMA_Report (user_dma_report.js 0.1.0) make a short text on the clipboard for Discord and a full
 *   report file. Unit: tests/unit/console-feedback-page.test.js. Integration: tests/integration/dma-report-real-modules.test.js.
 * 0.1.101 (2026-11-18, ADR 0083 point 2 + addendum): a RULES page with every registered rule of the player policy,
 *   grouped and filterable, each with its control (tick, number with range, list, text, grouped filterable checklist
 *   for a set of resources). Unit: tests/unit/console-rules-page.test.js. Integration: tests/integration/dma-console-rules-real-policy.test.js.
 * DMA Console UI 0.1.5
 * Blue part only: show state and pass input on. No policy logic here.
 *
 * Runtime: Adobe AIR + jQuery + Bootstrap 3 (TSO client).
 * Load AFTER jQuery, Bootstrap 3, the client helpers (createModalWindow,
 * createSwitch, getImageTag), DrunkenMinerAuto_0.0.4.2.js (DM_assetsIconsOres),
 * dma-control-0.1.1.js, and the DMA/Grok modules this UI reads:
 *   GCAF_OperationsOverview.gather()
 *   GCAF_PlayerPolicyInstance.getPolicy() / requestChange(ruleId, value)
 *   GCAF_Console.cycleOnce()
 * Those three are resolved at call time, never at load time. When one is
 * missing the console still opens and the log line says which one.
 *
 * Icons: the Drunken Miner map DM_assetsIconsOres (getImageTag(name, w, h))
 * is used when loaded; DMA_ICON below carries the same names as fallback.
 *
 * SAVE/LOAD uses the game SaveLoadTemplate (same as ShortcutTrader).
 * No manual file placement required.
 * Opened through the existing DMA Tools item (DMA Control).
 * Compact version line under the toolbar only (0.1.2). Title stays "DMA Console".
 * 0.1.100 (2026-11-17, ADR 0079; author: "de speler heeft meerdere mogelijkheden bij het aanmaken van een nieuwe versie op
 *   een avontuur: block, zonder block, kamp voor kamp. Daarnaast kan hij een bestaande mundain gebruiken ... mijn mundane
 *   ter beschikking stellen" — "Het is een noodgreep, een modus die je altijd beschikbaar moet hebben om een avontuur te
 *   kunnen beeindigen" — "Wellicht zelfs het advies bij dit avontuur geen blocks te gebruiken"): ADVS page —
 *   (1) New version offers the kinds of the catalogue (blocks, without blocks (waves), camp by camp, own Mundane, author's
 *       Mundane) first, then the other modes; each kind with its hint as the option's title; a kind with templates asks
 *       for the folder.
 *   (2) Finish camp by camp (DMA_Adventure.finishCampByCamp) next to every Stop, and in the open adventure's row for an
 *       adventure with a version, whatever the version: the emergency mode that ends a running or stopped adventure.
 *   (3) The adventure's advice from the catalogue (Bonaberti: do not use blocks) in its open row, in orange; a version's
 *       analysis notes (NO_BLOCKS_ADVISED, BLOCKS_IN_WAVES) and the shared-Mundane camps not covered in its summary title.
 *   Unit: tests/unit/dma-console-adv-kinds.test.js. Integration: ADVS ▶ Bonaberti shows "Do not use blocks", the five
 *   kinds and Finish camp by camp; pressing it on a stopped run resumes the adventure camp by camp.
 * 0.1.99 (2026-11-17, UAT 2026-11-17 findings F2 and F3; a fix to what the main table shows, no new control): (F3) the header of the main table had nine columns over ten cells: "upg" stood above the geologist-type
 *   dropdown, the upgrade target had no header, and "geo" stood above an empty column. The headers now follow the cells: after "time" an empty one (the empty cell), "geo" over the geologist type, "upg" over the upgrade
 *   target. (F2) the upgrade target selector has a first entry "\u2014" (value 0, no target) and shows it when no target is stored (a fresh install; the policy default is 0 since 0.2.70) - it used to show the
 *   maximum level when nothing was stored, and a stored value above the type's maximum is shown as the maximum instead of an arbitrary entry. The levels offered still go up to the maximum of the construction type
 *   (6, quarries 7). Nothing else changes; the saved value of "\u2014" is 0, the same key as before.
 *   Unit: tests/unit/console-main-table-headers.test.js (ten headers over ten cells, "geo" over the geologist select, "upg" over the upgrade select; fresh policy: the upgrade select shows "\u2014" and offers 1..6, 1..7 for quarries;
 *   a stored 3 is shown as 3, a stored 9 as the maximum). Integration: tests/integration/dma-console-version-line.test.js (the console loads with the real policy and control).
 * 0.1.98 (2026-11-17, tester release, author: nothing may fit only his island; a TEXT change, no layout change): the examples in two help texts used the
 *   author's chat word "Peter": the tooltip of "Chat reply word" ("your own name, e.g. Peter") and the line on the HELP page ('"Peter help 5K stone"'). They now say
 *   "e.g. Joe" and '"Joe help 5K stone"', and the HELP page line names the player's own chat reply word when one is set. Nothing else changes.
 *   Unit: tests/unit/console-example-names.test.js (no "Peter" in the code of the console; the HELP page shows the player's own chat word, "Joe" in the example when none is set).
 *   Integration: tests/integration/dma-console-version-line.test.js (the console still loads with the real policy and control).
 * 0.1.97 (2026-11-16, UI change explicitly requested by the author: "the QUEST page shows the real task text and who does it"; ADR 0077, quest 0.1.31): a quest task that carries a display text (what its end condition really asks, e.g.
 *   "specialists: 2× Adventure Search (short)") is shown by that text alone, in the to-do list and in the quest table; before, the kind, the item name and the amount were printed one after the other ("... FindAdventureZoneShort 2").
 *   Tasks without a text are shown as before. The rest of the UI is unchanged. Unit: tests/unit/console-quest-task-text.test.js. Integration: tests/integration/dma-console-version-line.test.js (version line "ui 0.1.97").
 * 0.1.96 (2026-11-16, defect found live on the Specialists page; the coordinator): (1) "Skills from the game: none read yet for geologist,geo,Geologistss." — the page declared DMA_SPEC_KIND twice
 *   (a name per tab, then the skilling rules' array per tab), so the second hid the first and the lookup key became the whole array; the first is DMA_SPEC_KINDNAME now. dma-skills.json was never at fault.
 *   (2) The book stock is shown (Manuscript, Tome, Codex, from the location manager: DMA_Demo.stockNow()) and, per specialist, the books its next skill (the cheapest one below its maximum) needs against it:
 *   green when the stock covers it, red when not. The page also lists the books needed per skill with the stock beside it. The html is built by DMA_gameSkillsHtml (pure; exported as skillsHtml).
 *   Unit: tests/unit/console-specialists-skills.test.js (the game's own dma-skills.json shape: the lookup finds the 38 geologists, books needed against stock). Integration: tests/integration/console-specialists-books.test.js.
 * 0.1.95 (2026-11-16, ADR 0074 step 4; no UI change): the version line also names the deposit search manager (DMA_DepositSearchManager) when it is loaded.
 *   Unit: tests/unit/dma-console-ui.test.js. Integration: tests/integration/dma-console-version-line.test.js.
 * 0.1.94 (2026-11-16, ADR 0074 step 3; no UI change): the version line also names the construction manager (global DMA_ConstructionManager) when it is loaded.
 *   Unit: tests/unit/dma-console-ui.test.js. Integration: tests/integration/dma-console-version-line.test.js.
 * 0.1.93 (2026-11-16, ADR 0074 step 2; no UI change): the version line reads the buff applier (global DMA_Buffer) in place of the retired DMA_BuffManager.
 *   Unit: tests/unit/dma-console-ui.test.js. Integration: tests/integration/dma-console-version-line.test.js.
  * 0.1.92 (2026-11-16, UI change explicitly requested by the author; coordinator; the 0.1.91 toggles did not hold): (1) the group choice is kept in a module variable (the source of truth for
 *   the session) and persisted through the policy store — console.troops.<normal|elite|expedition>.show (player policy 0.2.65, dma-policy.json), like the BUFF screen since 0.1.9; localStorage,
 *   which the client does not keep, is no longer used. It is read from the policy once per module (a reload of the module finds the choice again). (2) The page is grouped: one section per
 *   group — Normal, Elite, Expedition — each with a header row that carries the group's toggle (shown / hidden; a hidden group keeps its header, so it can be switched on again), the
 *   units under their own group, and the units without a group in a last section "Other" (no toggle, always shown). Rows are ordered by section, then by name. The rest of the UI is unchanged.
 *   Unit: tests/unit/console-troops-groups.test.js (toggling twice shows and hides the rows with a localStorage that throws and one that drops writes; the sections). Integration:
 *   tests/integration/console-troops-groups-policy.test.js (the real policy: the choice survives a reload of the console module and of the policy).
 * 0.1.91 (2026-11-16, UI change explicitly requested by the author; coordinator; icons added on the coordinator's instruction): the TROOPS page gets (1) three toggle buttons — Normal, Elite, Expedition — that show or hide
 *   the rows of that unit group (all three on by default). The GROUP of a unit kind is read from the game through DMA_UnitInputs.group(unit) (unit inputs 0.1.1: the unit
 *   lists of the client, registered copy + watcher; ADR 0042) — the console holds no unit table; a kind the game does not group is always shown. The choice is a console VIEW setting, not a
 *   policy rule: it is kept in localStorage under "iso:dma.troopsGroups.v1" ({normal, elite, expedition: true|false}) and survives a restart. Expedition rows have no editable
 *   target (the policy has no training input for them and refuses unit.<Expedition…>.targetStrength). (2) The target cell is coloured per unit kind with the console's red/orange/green
 *   (#e88 / #e0a030 / #8f8): red = army below the target and nothing of that kind in training; orange = army below the target and units of that kind in training (any amount);
 *   green = army on or over the target; no colour without a target. (3) A unit icon in front of each unit kind: the client's own getImageTag(<unit name>, "24px") (the helper the buff and building rows use); the tag is shown when it returns a non-empty image, otherwise nothing (no drawn icons). A found icon is cached per unit; the page says how many of the shown kinds got one ("icons: n of m"), so one live look tells whether the unit names resolve. The rest of the UI is unchanged.
 *   Unit: tests/unit/console-troops-groups.test.js (grouping, the filter state and its storage, the three colours and no target, the icon with a stubbed getImageTag: hit, miss, cache). Integration: tests/integration/console-troops-groups-policy.test.js
 *   (the real policy, unit inputs and troops: groups on the page, a hidden group stays hidden after a re-read, an expedition row has no editable cell, a saved target gets its colour).
 * 0.1.90 (2026-11-16, UI change explicitly requested by the author; coordinator): (1) a TROOPS page (button TROOPS, built as the other rule pages): per unit
 *   kind the army (free units, the location manager's picture), what is in training (DMA_Troops.training) and the TARGET strength — an editable cell of the
 *   player's rule unit.<Kind>.targetStrength (AT79, saved through the policy like every other cell: one requestChange per change, a refusal is shown), with the
 *   shortfall beside it. (2) The TX page: the TK64 row shows the open production batches the player is asked to make (resource, amount, status) from control's
 *   allocation.batches() — the list dma-production-requests.json holds — in a row under the kind. The rest of the UI is unchanged. Unit:
 *   tests/unit/console-troops-page.test.js (troopsModel / troopsBody / txBatchHtml). Integration: tests/integration/console-troops-target-policy.test.js (the real
 *   policy and the real control: a typed target is saved and read back by the troop manager's targets(); a TK64 batch of control shows on the TX page).
 * 0.1.89 (2026-11-16, architect assessment #403 step 2; V-model plan follow-up): the version line no longer reads the
 *   retired rgb module (user_dma_rgb.js is in legacy-reference since #404), so "rgb" is gone from it even when an old
 *   copy of the file is still loaded on a client. The line's builder is exported as loadedVersions() for the tests.
 *   Nothing else changes.
 *   Unit: tests/unit/no-dma-rgb-in-src.test.js (no reader of the rgb global is left under src/). Integration:
 *   tests/integration/dma-console-version-line.test.js (the console with the real policy and the real control 0.2.100,
 *   and an old rgb global still present: the version line names control, policy and ui 0.1.89, and not "rgb").
 * 0.1.88 (2026-11-15, author: "Maak de test variant zo dat de speler de mogelijkheid heeft per avontuur meerdere varianten
 *   aan te maken met een naam en nummer. De folder waar het in vastgelegd wordt heeft dezelfde naam"): New version with
 *   mode "test" asks no folder: DMA_Adventure.addTest makes "test NN <name>" and its folder of the same name in the
 *   adventure's template folder (DMA_advTestBase). Unit: dma-console-ui.test.js renders data-base on Add.
 *   Integration: ADVS ▶ BB, mode test, name "blocks v6" -> row "test 01 blocks v6" and folder ...\BB\test 01 blocks v6.
 * 0.1.87 (2026-11-10, agents 0.4.24): template "Best" by search length (the same table as the agents' built-in one).
 * 0.1.86 (2026-11-10, agents 0.4.23): Explorers tab — template "Best" (every type on the search it is best at:
 *   adventures, treasure, artefacts, buffs); the Search list holds the real tasks of the loader's menu (treasure short …
 *   prolonged, Travelling Erudite, Bean a Collada, adventure short … very long). Daily's "artifact" entries are
 *   "advShort", the search they always were. Unit: dma-console-ui.test.js; integration: Apply "Best" on the Explorers tab.
 * 0.1.85 (2026-11-10, ADR 0058 addendum; author: "Kun je kiezen voor alles hernoemen?" — "Ja"): the Skilling and naming
 *   block has "Rename: new only / without an own name / all" per type. With "all" it shows the whole list "current
 *   name → new name" (DMA_Demo.namePlan, agents 0.4.22) and a Confirm button; the confirmation is stored as
 *   spec.<type>.renameAllConfirmedAt. Nothing is renamed until the game call is proven.
 *   Unit: tests/unit/dma-console-ui.test.js; integration: live, the preview lists every specialist of the type.
 * 0.1.84 (2026-11-10, ADR 0058, agents 0.4.21, control 0.2.91, policy 0.2.53; author: "waarom staat de keuze van de
 *   specialisten voor het skillen er nog niet?"): the Specialists screen has, on each tab (Geologists, Explorers,
 *   Generals), a "Skilling and naming" block — the player's settings for that type (skilling manual / automatic with
 *   "follow the online standard"; naming manual / automatic with his own prefix and suffix, the number makes it unique)
 *   and every specialist of that type that is not fully skilled, read from the game, with his choice "use until the
 *   books are there" / "skill first" and his state ("waiting for skilling" or "used meanwhile"). Applying books and
 *   renaming wait for the game calls (said in the block). The Explorers tab no longer says "Not sent" for explorers
 *   that are sent (wrong since agents 0.4.17).
 *   Unit: tests/unit/dma-console-ui.test.js; integration: live, a choice made in the block is in dma-policy.json
 *   (spec.use) and an explorer set to "skill first" stays home.
 * 0.1.83 (2026-11-10, author: "ik wil dat je het transactie overzicht automatisch refreshed waardoor je een soort levend
 *   bord krijgt met alles wat er op het eiland plaatsvindt"): the TX page is a live board. While it is open it redraws
 *   itself every 5 s (footer: "Live", on by default, and the time of the last redraw) from the transaction book in
 *   memory; the scroll position, the filter and every opened kind or transaction stay as they were; a transaction that
 *   is new or had an act since the previous redraw is highlighted for that redraw. The board pauses while the kind list
 *   is open (so it does not close under the mouse) and stops when the window closes or another page opens.
 * 0.1.82 (2026-11-10, author: "Wellicht kunnen we de TKs groeperen naar PBC en dus naar het Entiteit type die het
 *   behapt: LOCATION, BUILDING, etc"): the TX page groups the transaction kinds by the entity type they are about — one
 *   PBC = one entity type (DMA_Rules.entityOf, rules 0.1.2: the OFD entity type of the product; a manager follows the
 *   TK it manages): CONSTRUCTION, BUFF, LOCATION … Every kind of the model is listed, also the ones with
 *   nothing in progress (greyed), so each can be opened to its rules; kinds outside the model come last under
 *   "NOT IN THE MODEL". The kind filter and the list of transactions in progress follow the same grouping.
 * 0.1.81 (2026-11-10, author: "1,2,3 en 5" — of the suggestions for the TX page):
 *   (1) every transaction in progress shows who is to act NEXT and under which rule: the action rules of its kind that
 *       respond to its current state (DMA_Rules: ARS type and performer role) — requested: Type 02 by the executor;
 *       promised: Type 03 / 04 / 11 / 12 by the executor; declared: Type 05 by the initiator;
 *   (2) an opened transaction kind also lists the PLAYER'S SETTINGS its rules read (policy entries, policy 0.2.52, by
 *       the patterns of docs/05-ontology/dma/policy-by-tk.json) with their current values;
 *   (3) a declined / rejected / revoked transaction says WHY (the reason its actor role recorded, transactions 0.4.10);
 *   (5) every transaction (in progress and closed) unfolds to its HISTORY: each act with actor, time, how often, reason.
 *   Unit: tests/unit/dma-console-ui.test.js, dma-transactions-overview.test.js, player-policy-entries.test.js;
 *   integration: live, on the TX page a promised TK41 says "next: Type 04 · AR41 …" and unfolds to its acts.
 * 0.1.80 (2026-11-10, author: "Maak ik datzelfde overzicht de business rules zichtbaar als de betreffende tk wordt
 *   opengeklapt. Een lijst met ELs komt naar voren met vooraan het ARS type en de definitie"): on the TX page every
 *   transaction kind can be opened (the triangle in front). It then shows its business rules from the essential model
 *   (DMA_Rules, user_dma_rules.js — generated from dma-bundle.yaml): the product, the executor role, every action rule
 *   with its ARS type in front (number and name) and its definition — when / while / given, the assess part
 *   (rightness, sincerity, truth) and the response (then / else) — and the existence laws (ELS) on its product.
 *   A kind outside the model says so. Unit: tests/unit/dma-rules-catalogue.test.js; integration: live, opening TK41
 *   lists "Type 02 — requested: promise or decline" first.
 * 0.1.79 (2026-11-09, author: "Maak nu een overzicht van alle transacties en hun status in een apart overzicht zodat de
 *   speler kan volgen wat de werkelijke status is"): TX button and page — the transaction book's overview
 *   (DMA_Tx.overview, transactions 0.4.9): per kind (name, product) the open instances by state, the oldest and how many
 *   need a check; every open instance with its key, state, age, initiator, last act and actor, and the check (waiting
 *   longer than its kind normally takes, or declined / rejected); the last closed ones and how they ended. Filters:
 *   kind, "only what needs a check". Read-only.
 * 0.1.78 (2026-11-09, author: "Dan nu de quest manager met eigen knop en scherm waarbij alle onderdelen geselecteerd
 *   kunnen worden inclusief event quest, dat weer afhankelijk is van het aanwezig zijn van een quest en de auto selectie
 *   van quest"): the QUEST button opens the QUEST MANAGER screen. At the top one selection block of its own: the Quest
 *   switch (quest.auto); WHAT to do — every category of the quest book with the number of open quests (guild, dailies,
 *   weeklies, ghost ship, starfall, event, main, side, building-bonus loops); HOW — claim, start, pay guild quests,
 *   collectibles, icons over buildings, pick up productions, with the collectible interval and "Pick up now". The
 *   event-quest tick is greyed out with its reason unless the Quest switch is on and an event runs with the Event switch
 *   on (quest 0.1.24 eventGate); it shows how many event quests the book holds. Then what the manager watches, the
 *   to-do list and the quest table as before. Rules quest.pay.on / quest.pickup.on: policy 0.2.50.
 * 0.1.77 (2026-11-09, author: "ja en begin daarna aan de quest manager die ook een pagina heeft met allerlei onderdelen
 *   die hij actief in de gaten moet houden en dient te beleggen bij de juiste executor"):
 *   - EVENT page: per running event type the table of its PARTS (DMA_Event.parts, event 0.2.9) — a switch per part,
 *     the actor that executes it and its state: auto (green), off (grey), needs you (orange: no executor loaded).
 *   - QUEST page: "What the quest manager watches" (DMA_Quest.watch, quest 0.1.21) — per category on/off, open quests,
 *     rewards ready and tasks that need the player; per executor the task kinds routed to it, loaded or not, and the
 *     open tasks waiting for it. The selection block gains "building-bonus loops" (quest.do.building, policy 0.2.49).
 * 0.1.76 (2026-11-09, author: "adjust the console so event and quest book kan be selected, inclusding all
 *   subselections"): one selection block on the QUEST and EVENT pages — the Event switch (event.auto) with, per running
 *   event type, fill / buff its buildings / answer tricks and event quests; the Quest book switch (quest.auto) with the
 *   categories (guild, dailies, weeklies, ghost ship, starfall, main, side) and claim / start / collectibles / icons.
 * 0.1.75 (2026-11-09, ADR 0053, author: "make a to do list from urgent to have a long to ackomplish for"): QUEST page —
 *   the "Needs your help" box became the to-do list of the quest book (DMA_Quest.todo(), quest 0.1.19): reward ready,
 *   then the nearest end, then no end; each open task marked with its DMA executor or [needs you].
 * 0.1.74 (2026-11-09, ADR 0053): QUEST page — the player's choice per category (quest.do.*) and a "Needs your help" box
 *   with every open task of a chosen quest that no DMA executor can do (DMA_Quest.help(), quest 0.1.18), guild first.
 * 0.1.73 (2026-11-08, author: "laten we eerst de reeks aanmaken en opnemen in de ADVS tab"; ADR 0050, catalogue 0.1.1):
 *   the ADVS overview shows each adventure series as its own group above the types — all its adventures, in play order,
 *   numbered (1. At the Foot of the Mountain … 5. A Giant Battle), with the series note; versions and Run once as for
 *   any adventure. Unit: dma-console-ui.test.js still passes; integration: the ADVS page lists the Mountain Clan series.
 * 0.1.6: round status lamps. Adobe AIR's HTMLLoader runs an old WebKit that
 *   ignores unprefixed border-radius/box-shadow and supports neither SVG nor
 *   data: URIs, so the lamps use -webkit-border-radius in px plus
 *   -webkit-box-shadow (DMA_LAMP_MODE "css"). If that still renders square,
 *   set DMA_LAMP_MODE to "glyph": a coloured U+25CF text dot that needs no CSS.
 * 0.1.7 (2026-10-24): one switch per self-starting actor role, taken from the Player
 *   Policy (GCAF_PlayerPolicyInstance.switches()): Island, Geo, Expo, Build, Upgrade,
 *   Buff, Demo. Switches are written to the policy only (no "dma.switches" side store),
 *   so they persist with every other rule. An actor line under the switches shows per
 *   self-starter: off / blocked (and by which switch) / idle / acting, from DMA_Demo.actors().
 *   The explorer templates are exported as window.DMA_EXP_TEMPLATES for the specialist manager.
 * 0.1.8 (2026-10-24, from the live test of 0.1.7): searching geologists are listed once per
 *   resource (they were listed twice); the buffed lamp and BUFFED column take the live buff
 *   state from DMA_Demo's island facts by grid; the red "low" lamp uses the demolish threshold.
 * 0.1.9 (2026-10-24): BUFF screen choices are saved through DMA_Demo.setBuffPref into the
 *   policy (buff.prefs, persisted to dma-policy.json) instead of localStorage, which the client
 *   loses on restart. The CAP column shows green's capacity (learned spots / proven / seed) with
 *   the picture behind it as tooltip.
 * 0.1.10 (2026-10-25, author: "make sure the actor roles are reflected in the switches of our console: chat watch
 *   and trading"): the switch row shows Chat (chat watcher) and Trade (trade acceptor) from the policy (0.2.3);
 *   the actor line shows both: off / blocked by Chat / idle / acting (open RT cases, awaiting accept).
 * 0.1.11 (2026-10-25, another player will test): field "Chat words" next to the demolish threshold — the words in a
 *   guild message the chat watcher reacts to (comma separated, e.g. "Peter"); saved to the policy (chat.words).
 * 0.1.12 (2026-10-25, author: skills of geos, expos and gens per specialist): the SPEC screen has three tabs —
 *   Geologists, Explorers, Generals — each opening with the skills READ FROM THE GAME (control 0.2.26): one
 *   specialist by name, or "All of this type" (how many have each skill, how many maxed). Nothing to type in.
 *   The manual geo grid and the explorer search preferences stay below it.
 * 0.1.13 (2026-10-25, author: "het handmatig invoeren gedeelte van het scherm kan weg"): the manual geo skill grid and
 *   its Apply recommended / Reset geo buttons are removed — the skills come from the game. The explorer search
 *   preferences (which search to send) stay; they are a choice, not skill entry.
 * 0.1.14 (2026-10-25, author): the field is called "Chat reply word" (policy key chat.words unchanged).
 * 0.1.15 (2026-10-25, author: "all these values must be adjustable by the player in a screen — max number of RTs,
 *   waiting time, etc."): TRADE button and screen — every round-trade rule of the policy (0.2.6) as a number field
 *   with its range; a change goes through the policy (requestChange) and takes effect on the acceptor's next tick.
 *   Out-of-range values are refused and the field shows the stored value again.
 * 0.1.16 (2026-10-25, author: "RTs per uur slaat nergens op"): the per-hour limit is gone from the TRADE screen.
 * 0.1.45 (2026-10-29): the buff names on the EVENT page are counted over all buildings (control 0.2.47 counts.buff).
 * 0.1.44 (2026-10-29): the EVENT page lists the buff names the last island scan saw on buildings, with counts, so the
 *   player can see what a trick is called in the game and set the counter's "when" to it.
 * 0.1.49 (2026-10-30, author: "Volgende is het automatiseren van FT"): the ADVS page lists FT (Ali Baba and the First
 *   Thief) with its rules from policy 0.2.36.
 * 0.1.48 (2026-10-30, ADR 0030): the ADVS page shows the visit hold and offers "Hold blue work for a visit" / "Visit
 *   closed" (DMA_Control.visit.request / close).
 * 0.1.47 (2026-10-30, author: "Ja net als YWC want die stond er ook nog niet op"): the ADVS page lists YWC and VLT next to
 *   AE and GP, with their rules from policy 0.2.29 (templates by file chooser, as 0.1.46).
 * 0.1.72 (2026-11-05, ADR 0047, author: "Ja en wellicht voor de speler visueel inzichtelijk maken?"): VALUE button and
 *   page — every good with its own-cost value from the production chain (DMA_Value): a bar (log scale), the value in
 *   coins and building-minutes, the building that makes it and the finite deposits it draws on; click a good to open its
 *   chain (indented, each step with its share of the whole). Source (game or registered copy), read date and a notice
 *   when the game's definitions differ from the copy. Read only.
 *   Unit expectation:        DMA_valueBody() lists Coin with "1.00" coin and Cannon above Coin; DMA_valueChain("Coin")
 *                            shows Gold, GoldOre and Coal.
 *   Integration expectation: VALUE opens the page in the client; clicking Coin shows its chain.
 * 0.1.71 (2026-11-05, ADR 0048, author: "maak er maar een business rule van"): the ADVS page's "All adventures" card shows
 *   "Short stock -> adventure" — the adv.loot.* rules (R-ADV-LOOT, adventure manager) and green's last advice
 *   (DMA_Green.lootAdvice: resource, hours left, the adventure to play, the one to obtain). Nothing else changes.
 *   Unit expectation:        DMA_advLootHtml([advice]) contains the resource and the adventure; empty advice says so.
 *   Integration expectation: with a falling stock the line appears on the ADVS page within 10 minutes.
 * 0.1.70 (2026-11-02, ADR 0039 change A, class [impl]): the actor line of Help/Star named TK26 / TK27; help 0.1.16
 *   records both as TK25 trade set completing (kinds gift and star trade), so the line now says so. Text only.
 *   Unit: dma-console-ui.test.js (version); integration: the actor line on the console reads "TK25 trade sets".
 * 0.1.69 (2026-11-01, test-day proposals P3/P4/P5; author: "Voer alle verbeteringen maar door"):
 *   - P3: ADVS rule text fields are left-aligned and take the full column (the label 45%), the full text as tooltip;
 *     adv.ls.inviteMode is a choice (together / one by one);
 *   - P4: Run once on a version with ⚠ warnings asks once: the first press shows the count and "press again to run";
 *   - P5: before the first island scan after a start the table says "first scan…" instead of default caps / search.
 *   Unit: dma-console-ui.test.js (0.1.69 block); integration: ADVS page shows the choice and the confirm step.
 * 0.1.68 (2026-11-01, test day): BUFF -> Back returns to the console (it called a missing DMA_render and left the
 *   buff page with the console title); the buff page title is English ("Buffs").
 *   Unit: console-ui test checks Back calls DMA_closeGeo; integration: BUFF -> Back shows the console table.
 * 0.1.67 (2026-10-31, author: "voor alle ls adventures bepaal je bovenaan 1 keer ..."): the top card shows the
 *   loot-spot rules (adv.ls.*) once for every adventure. Unit: overview renders; integration: the rules save.
 * 0.1.66 (2026-10-31, author: "nee met ls uitnodiging en alles"): a learned version shows its loot spots (offer,
 *   spots, announcement) with the approval checkbox "post in the guild chat and invite". Unit: overview renders.
 * 0.1.65 (2026-10-31, author: learning by demonstration): per adventure "Start learning" (name, replace that
 *   version) and, while learning, "Stop and save" / "Cancel" with the count of actions and arrows. Unit: overview
 *   renders the learning row; integration: a GP demonstration becomes a version.
 * 0.1.64 (2026-10-31, author: "als je alleen arrows selecteert, hoeft hij niet naar een template te zoeken" — "per kamp
 *   aangeven hoe hij dat wil"): an "arrows only" version is added without a folder and analysed without Mundane; its rows
 *   list the camps to destroy with an editable plan per camp. Unit: overview shows the plan input; integration: GP.
 * 0.1.63 (2026-10-31, author: "het lijk me mooi als de knop die je geselecteerd hebt en loopt groen wordt qua text
 *   kleur"): while a run goes on, the button that started it reads "Running" in green (row and version), the other Run
 *   buttons of that adventure are hidden. Unit: the overview with a running status shows "Running"; integration: live.
 *
 * 0.1.62 (2026-10-31, author: "de buttons vallen buiten het scherm"): the version row's buttons share one wrapping cell
 *   with the last result (Analyse / Run / ✕ no longer clipped); the action column is wider.
 *   Unit: the page renders; integration: all buttons visible in the client.
 *
 * 0.1.61 (2026-10-31, author: "binnen het type ... alfabetische volgorde ... de analyse op adventure niveau ...
 *   automatisch ... een coop kent geen ls, maar spots ... lijn alles netjes uit ... ik begrijp full? nog niet"):
 *   rows alphabetical; fixed column widths; co-op shows spots; the version cell shows the version's own analysis
 *   ("6 templates · 17 gen ✓" or "⚠ n"), a folder found by name becomes version "full" automatically when its analysis
 *   finds a run ("folder found, no run" otherwise); the page runs the adventure watch when it opens and shows new star
 *   adventures and re-analysed templates.
 *   Unit expectation:        alphabetical rows; co-op header "spots"; an analysed version shows its template count.
 *   Integration expectation: FT shows "full 6 templates · 17 gen".
 *
 * 0.1.60 (2026-10-31, live look of 0.1.59): the client's WebKit has no flex gap: headers use margins and floats,
 *   gradients the -webkit- form. Unit: the page still renders; integration: titles and counts are spaced.
 *
 * 0.1.59 (2026-10-31, ADR 0035 step 2; author: "het scherm zo gaan indelen dat hij gelijk is opgebouwd aan het
 *   beginscherm met onze mijnen ... Het scherm moet er heel gelikt uitzien"): the ADVS page is an overview — a card
 *   with the rules for all adventures, then a block per type (DMA_AdvCatalogue) with a row per adventure (in the star,
 *   loot spots, default version, last run, Run once); ▶ opens its versions (way of playing + template folder, default
 *   radio, Analyse, Run, remove), "New version" (mode, name, Folder...), the advisor result and its rules. Without the
 *   catalogue module the old page is shown.
 *   Unit expectation:        with catalogue and adventure modules loaded the page renders group blocks and a Run once
 *                            for an adventure in the star that has a version.
 *   Integration expectation: the ADVS page shows the author's 75 adventures grouped by type; FT runs from its row.
 *
 * 0.1.58 (2026-10-31, author: "kun je ook een button maken, eenmalig uitvoeren?" — "ja"; ADR 0034): adventures with a
 *   known star item (FT, YWC) get "Run once" and "Stop" on the ADVS page and a live status line (state, template, reason,
 *   last steps) refreshed every 3 s; the run uses the chosen templates or the client's template folder.
 *   Unit expectation:        the ADVS page renders Run once / Stop for ft and calls DMA_Adventure.runOnce("ft", folder).
 *   Integration expectation: Run once on FT plays one First Thief from the star to home.
 *
 * 0.1.57 (2026-10-31, author: "Instellingen worden nog steeds niet onthouden"; live log: "adv change adv.ae.on=true
 *   -> null diag no policy"): the console had no policy instance, so no rule was ever saved and the switches showed off.
 *   policy() now makes the instance itself (create, load, start) when the boot script did not, once, and logs either
 *   that it did or the step and error where it failed.
 *   Unit expectation:        with GCAF_PlayerPolicy loaded and no instance, policy() returns a started instance.
 *   Integration expectation: the ADVS change log shows a result "ac" and dma-policy.json / dma-policy-changes.jsonl change.
 *
 * 0.1.56 (2026-10-31, author: "Instellingen worden nog steeds niet onthouden"): the ADVS change handler takes the
 *   current policy instance and logs every change (rule, value, result, policy diag) to the debug log.
 *   Unit expectation:        a change on .dma-adv-rule calls requestChange once and logs "adv change".
 *   Integration expectation: dma-debug-log.txt shows the result of each change made on the ADVS page.
 *
 * 0.1.55 (2026-10-31, live: the window stayed on the laptop screen, "on screen 0,0 1920x1032", and the guild tab was
 *   "not done" after 2 min): screens are compared by bounds (AIR returns new Screen objects each call), the largest
 *   non-main screen wins; the guild retry runs for 5 minutes.
 *   Unit expectation:        pickScreen with fresh objects of equal bounds still returns the other screen.
 *   Integration expectation: after a restart the game is maximised on the SyncMaster monitor.
 *
 * 0.1.54 (2026-10-31, author: "De client heeft al een standaard folder voor templates. dus die zou ik als basis nemen,
 *   waarbij mensen dit kunnen veranderen als dat nodig is"): the client's template folder (mainSettings.shortcutsDir,
 *   Settings) is the default: an adventure without its own choice uses <base>\<AE|FT|YWC|VLT|GP> when it exists, else
 *   the base; shown as placeholder; Files.../Folder... dialogs open there. A chosen file/folder still overrides it.
 *   Unit expectation:        with shortcutsDir "D:\SOL" and D:\SOL\FT present, the FT default is D:\SOL\FT; no shortcutsDir
 *                            and no air: "".
 *   Integration expectation: Analyse on FT without a choice analyses the client's FT folder.
 *
 * 0.1.53 (2026-10-31, author: "YWC stands for Young WoodCutter, however you should always check the online
 *   information"): YWC is "Ali Baba the Young Woodcutter" (official game news, adventure boost list), not "Your Wish Come".
 *   Unit expectation:        the ADVS list names ywc "Ali Baba the Young Woodcutter".
 *   Integration expectation: the ADVS page shows that title.
 *
 * 0.1.52 (2026-10-31, author: "make it standard to move the island to my monitor and open the guild chat"): 3 s after
 *   load the game window moves to the first screen that is not the main screen (the main one when alone) and is
 *   maximised; every 10 s for 2 minutes DMA_Chat.backToGuild() until the guild tab is in front.
 *   Unit expectation:        pickScreen([main, ext], main) = ext; pickScreen([main], main) = main.
 *   Integration expectation: after a (self-)restart the game is maximised on the author's monitor with guild chat in front.
 *
 * 0.1.51 (2026-10-31, from the author's screen video): a Files... rule also gets Folder... (the multi-file dialog
 *   cannot pick a folder: the author opened FT and nothing was saved); "Analyse my templates" with nothing chosen opens
 *   the folder chooser, keeps the folder in the rule and analyses it; it always shows what it does (analysing / error).
 *   Unit expectation:        a files rule renders Files... and Folder...; Analyse with an empty rule calls browseForDirectory.
 *   Integration expectation: tests/integration/dma-mundane-advisor.test.js (console part).
 *
 * 0.1.50 (2026-10-31, ADR 0033; author: "Kun je dat inbouwen voor een andere speler die alleen de scripts heeft?"): the ADVS
 *   page gets "Your own adventure (any)" (adv.own.*, folder chooser) and "All adventures: Mundane choices" (adv.mundane.*);
 *   every adventure with templates gets "Analyse my templates": DMA_Mundane.analyzeAir shows the run order, the load, and
 *   findings with improvement proposals; a foreign template gets "Save my copy" (remap by type, "<name> (mine).txt").
 *   Unit expectation:        the page renders the two new sections and an Analyse button where a files/folder rule exists.
 *   Integration expectation: tests/integration/dma-mundane-advisor.test.js (console part).
 *
 * 0.1.46 (2026-10-29, author: "voor de advs geldt dus dat ze hun eigen mundane templates moeten kunnen selecteren"): on the
 *   ADVS page a rule marked pick "files" (policy 0.2.28: adv.ae.templates) gets a "Choose..." button: the AIR file chooser
 *   opens in the player's Documents, takes one or more files, and the rule becomes their full paths joined by " / ".
 *   The text field stays, so the paths can also be typed.
 * 0.1.43 (2026-10-29, live: the log showed "expo Chummy Explorer prolonged (default)" after ADR 0025): the console
 *   exports its explorer templates as DMA_EXP_TEMPLATES, which the specialist manager reads BEFORE its own; the console's
 *   Event template still said "*": "prolonged", so agents 0.4.14's short searches never took effect. It now holds the
 *   ADR 0025 template: short for every type, Romantic and Blacktree long, Benevolent very long.
 * 0.1.42 (2026-10-29): EVENT page — per counter of the type (Halloween: a trick answered with a Treat) the switch
 *   event.<type>.<counter>.on and the names when / give.
 * 0.1.41 (2026-10-29, live): the EVENT page lets the player set which game event names count for a type
 *   (event.<type>.gameNames).
 * 0.1.40 (2026-10-29, ADR 0029, author: "Alles wat gerelateerd is aan het event plaats je bij het event. Alles wat in
 *   algemeenheid gerelateerd is aan buffen, plaats je bij de buff."): the "Event buildings" section moves from the BUFF
 *   page to the EVENT page, per event type: the rule event.<type>.buff.on, the buildings with green's options and
 *   exclude/allow (event.<type>.buff.exclude). The BUFF page stays generic.
 * 0.1.39 (2026-10-29, ADR 0028, author: "een event manager die constateert dat een event gestart of gestopt is van een
 *   bepaald type. Daardoor zijn bedrijfsregels geldig, die gespecificeerd kunnen worden door de speler op die betreffende
 *   pagina"): EVENT button and page — the events the game runs (observed or assumed), and per event type its rules:
 *   seconds per unit of its buildings (event.<type>.buffable), buff its buildings (buff.event.on), the explorer
 *   template during the event (expo.template) and picking up collectibles (quest.collect.on).
 * 0.1.38 (2026-10-29): every option green finds is listed (not only the top 5), with the buff's target group.
 * 0.1.37 (2026-10-29, live): with no event building found, the BUFF screen lists the scanned building names that look
 *   like one (green's eventCandidates), so a name mismatch shows itself.
 * 0.1.36 (2026-10-29, decision 0026, author: "settings in het betreffende scherm behorende bij de juiste knop van de
 *   gelieerde actor roles"): the BUFF screen (buff manager) opens with an "Event buildings" section: the switch
 *   buff.event.on, and per building the running event declares buffable (the pumpkin cemeteries) whether it is buffed
 *   and green's computed options (DMA_Green.eventPlan: buff, bonus, hours, in stock, extra pumpkins), best first. A buff
 *   can be excluded or allowed again (buff.event.exclude). The console computes nothing itself.
 * 0.1.35 (2026-10-27, decision 0022, policy 0.2.22): ADVS button and page — per adventure (Arctic Explosion, Gunpowder)
 *   the player's business rules adv.<id>.* (switch, runs, templates, loot spots, waits, words, guild texts) and the DEMO
 *   pattern it follows. Read and set only: the adventure manager that acts on these rules is not built yet.
 * 0.1.34 (2026-10-27, agents 0.4.13, author: "you can only send out expos that are fully skilled; if not, they must be
 *   presented on a list in the expo screen of our console"): the Explorers tab opens with a list "Not sent — not
 *   fully skilled": every explorer whose skill tree is not full (points/max) or whose skills could not be read,
 *   from DMA_Demo.explorerSkillState(). The explorer list marks the same explorers with ✗.
 * 0.1.33 (2026-10-26, agents 0.4.10): the Event template sends every explorer on a prolonged treasure search ("*") —
 *   guild chat: "12 per prolonged"; Apply also sets the active template (rule expo.template).
 * 0.1.32 (2026-10-26, quest 0.1.5): QUEST page tick "pick up icons over buildings" and the icons waiting now.
 * 0.1.31 (2026-10-25, quest 0.1.1): QUEST page ticks "finish completed quests" and "start new quests".
 * 0.1.30 (2026-10-25, ADR 0016 Q-1, quest 0.1.0): the Quest switch and the QUEST page — every open quest (guild first),
 *   its kind, state and tasks with whether the DMA can do each; rules quest.claim.on, quest.collect.on and the interval;
 *   "Pick up now" for collectibles (also with the switch off).
 * 0.1.29 (2026-10-25, help 0.1.9): a star trade still undetermined ("sent") gets the Settled button too, and one the
 *   helper flagged for the player is marked "check please" (Explained stays for an owed one only).
 * 0.1.28 (2026-10-25): field "plenty: storage at least ... % full — given without the level limits" (help.plentyPct).
 * 0.1.27 (2026-10-25): field "a small gift is always allowed: up to ... % of the stock" (help.smallPct).
 * 0.1.26 (2026-10-25, author: ask a star trade ourselves): fourth kind "Ask star trades when a storage is full"
 *   (trade.ask.on), the field "ask at most once per ... min" and the last asks with their state on the TRADE page.
 * 0.1.25 (2026-10-25, author: safety margin): the TRADE page has "Safety margin" (trade.marginPct).
 * 0.1.24 (2026-10-25, author: "star trade is part of trade, same as help trade"): no Help and Star switches and no HELP
 *   button; the TRADE page holds all trading — per kind a tick (round trades, help trades, star trades), the round-trade
 *   rules, the help rules per level, the star-trade rules, and the facts (gifts, star trades, Explained / Settled).
 * 0.1.23 (2026-10-25, live: lost connection after a collect): the MAIL page shows a suspended mail manager with its
 *   reason and a Resume button.
 * 0.1.22 (2026-10-25, author: "a button on the mail rules to run them once per line; settings for the waiting time"):
 *   per kind a "Collect now" button (mail manager collectNow, the player's own act, also with the switch off), and
 *   the field "collect every ... minutes" (mail.everyMin) with the next run.
 * 0.1.21 (2026-10-25, author: no maximum to a star trade but the stock): the star.max field is gone from HELP.
 * 0.1.20 (2026-10-25, author's screenshot): the console closed from a sub page reopened with that page's title ("Mail
 *   rules") over the main view; it now opens as "DMA Console" with the main view's refresh running.
 * 0.1.19 (2026-10-25, author: guild help by level and star trades): switches Help and Star in the fallback list; HELP
 *   button and page — the tier rules (times per day, per week, max per request), the floor and share of the stock,
 *   what the receiver pays, the star-trade rules; beside them the facts: recent gifts and the star trades with their
 *   state; an unreturned star trade can be marked Explained (a new one may follow) or Settled.
 * 0.1.18 (2026-10-25, author: "mail automation gets one general switch and a separate page with settings based on
 *   facts"): switch Loot -> Mail (mail.auto, policy 0.2.9); MAIL button and page: per kind of explorer loot a rule
 *   (collect or keep, e.g. save the loot during an event) with the facts beside it — waiting now, collected — the
 *   destination (star menu / storage) and the mail manager's last collection. Actor line "Mail".
 * 0.1.17 (2026-10-25): switch Loot (loot collector, policy 0.2.8) in the fallback list; the actor line shows how many
 *   loot mails wait and how many were collected.
 */
(function (root) {
    "use strict";

    var VERSION = "0.1.119";

    /* ---------- status lamps ---------- */
    var DMA_LAMP_MODE = "css";   // "css" | "glyph"
    function DMA_lamp(color, title) {
        if (DMA_LAMP_MODE === "glyph") {
            return '<font color="' + color + '"><span title="' + title + '" style="color:' + color
                 + ';font-size:16px;line-height:14px;margin:0 2px;text-shadow:0 0 6px ' + color + '">●</span></font>';
        }
        var glow = color === "#555555" ? "none" : ("0 0 6px " + color);
        return '<span title="' + title + '" style="display:inline-block;width:14px;height:14px;'
             + '-webkit-border-radius:7px;border-radius:7px;'
             + 'background-color:' + color + ';'
             + '-webkit-box-shadow:' + glow + ';box-shadow:' + glow + ';'
             + 'vertical-align:middle;margin:0 3px;overflow:hidden"></span>';
    }

    /* ---------- fixed tables ---------- */
    var DMA_RESOURCES = ["Stone", "BronzeOre", "Marble", "IronOre", "GoldOre", "Coal", "Granite", "TitaniumOre", "Salpeter"];

    /* Same names and keys as Drunken Miner DM_assetsIconsOres (0.0.4.1 + stabilization hotfix). */
    var DMA_ICON = {
        Stone: "ButtonIconStone", BronzeOre: "ButtonIconBronze", Marble: "ButtonIconMarble",
        IronOre: "ButtonIconIron", GoldOre: "ButtonIconGold", Coal: "ButtonIconCoal",
        Granite: "ButtonIconGranite", TitaniumOre: "ButtonIconTitanium", Salpeter: "ButtonIconSalpeter"
    };

    var DMA_SHORT = {
        Stone: "Stone", BronzeOre: "Bronze", Marble: "Marble", IronOre: "Iron", GoldOre: "Gold",
        Coal: "Coal", Granite: "Granite", TitaniumOre: "Titan", Salpeter: "Salp"
    };

    /* Self-starter switches. The Player Policy owns the list (switches()); this is the fallback
       used only when the policy is not loaded yet. DOM id = "DMA_sw_" + short. */
    var DMA_SWITCHES = [
        { id: "DMA_sw_island",  rule: "island.auto",  label: "Island",  title: "Location manager: observe the island" },
        { id: "DMA_sw_geo",     rule: "geo.auto",     label: "Geo",     title: "Specialist manager: send geologists" },
        { id: "DMA_sw_expo",    rule: "expo.auto",    label: "Expo",    title: "Specialist manager: send explorers" },
        { id: "DMA_sw_build",   rule: "build.auto",   label: "Build",   title: "Building manager: build mines" },
        { id: "DMA_sw_upgrade", rule: "upgrade.auto", label: "Upgrade", title: "Upgrade manager: upgrade mines" },
        { id: "DMA_sw_buff",    rule: "buff.auto",    label: "Buff",    title: "Buff manager: buff mines" },
        { id: "DMA_sw_demo",    rule: "demo.auto",    label: "Demolish", title: "Demolish manager: demolish low mines" },   // 0.1.116 (tester ZG-01: "Demo" read as demonstration)
        { id: "DMA_sw_chat",    rule: "chat.auto",    label: "Chat",    title: "Chat watcher: reply when your chat reply word is used, take in RT requests" },
        { id: "DMA_sw_mail",    rule: "mail.auto",    label: "Mail",    title: "Mail manager: handle mails by the rules on the MAIL page (loot collecting)" },
        { id: "DMA_sw_quest",   rule: "quest.auto",   label: "Quest",   title: "Quest manager: claim finished quests and pick up collectibles, by the rules on the QUEST page" },
        { id: "DMA_sw_trade",   rule: "trade.auto",   label: "Trade",   title: "Trade: round trades, help trades and star trades, by the rules on the TRADE page" }
    ];
    /* 0.1.10: the guild-facing actor roles, which are not DMA_Demo self-starters */
    function DMA_guildActors() {
        var out = [], chatOn = DMA_pol("chat.auto", true) !== false, tradeOn = DMA_pol("trade.auto", true) !== false;
        if (root.DMA_Chat) {
            var cs = {}; try { cs = root.DMA_Chat.status ? root.DMA_Chat.status() : {}; } catch (_) {}
            out.push({ label: "Chat", actor: "chat watcher", state: chatOn ? "idle" : "off", reason: chatOn ? (cs && cs.mentions ? cs.mentions + " mentions" : "") : "switch off" });
        }
        if (root.DMA_Trade) {
            var list = []; try { list = root.DMA_Trade.cases() || []; } catch (_) {}
            var open = list.filter(function (c) { return c.status === "promised"; }).length, wait = list.filter(function (c) { return c.status === "declared"; }).length;
            var st = !tradeOn ? "off" : !chatOn ? "blocked" : (open || wait) ? "acting" : "idle";
            var why = !tradeOn ? "switch off" : !chatOn ? "needs Chat" : (open ? open + " RT promised" : "") + (wait ? (open ? ", " : "") + wait + " awaiting accept" : "");
            out.push({ label: "Trade", actor: "trade acceptor (TK25)", state: st, reason: why });
        }
        var MM = root.DMA_Mail || root.DMA_Loot;                 // 0.1.18 (0.1.17: Loot)
        if (MM) {
            var ls = {}; try { ls = MM.status(); } catch (_) {}
            out.push({ label: "Mail", actor: "mail manager (TK61)", state: ls.switchedOn ? (ls.waiting ? "acting" : "idle") : "off", reason: ls.switchedOn ? ((ls.waiting || 0) + " waiting, " + (ls.collected || 0) + " collected") : "switch off" });
        }
        if (root.DMA_Help) {                                     // 0.1.19
            var hs = {}, st = []; try { hs = root.DMA_Help.status(); st = root.DMA_Help.stars(); } catch (_) {}
            var tOn = DMA_pol("trade.auto", false) === true, hOn = tOn && DMA_pol("trade.help.on", false) === true, sOn = tOn && DMA_pol("trade.star.on", false) === true;
            var owed = st.filter(function (c) { return c.status === "owed"; }).length, open = st.filter(function (c) { return c.status === "sent"; }).length;
            out.push({ label: "Help/Star", actor: "trade: help / star (TK25 trade sets: gift, star trade)", state: (hOn || sOn) ? (open || owed ? "acting" : "idle") : "off",
                reason: (hOn || sOn) ? ((hs.given || 0) + " given, " + open + " star open" + (owed ? ", " + owed + " owed" : "")) : "off on the TRADE page" });
        }
        return out;
    }
    function DMA_switches() {
        try {
            var p = (typeof GCAF_PlayerPolicyInstance !== "undefined") ? GCAF_PlayerPolicyInstance : null;
            if (p && typeof p.switches === "function") {
                return p.switches().map(function (s) {
                    return { id: "DMA_sw_" + s.short, rule: s.key, label: s.label, title: s.title, needs: s.needs || [] };
                });
            }
        } catch (_) {}
        return DMA_SWITCHES;
    }
    /* per-resource rules:  cap.<R>  buff.<R>  upg.<R>   -  global:  threshold  defaultBuff */
    var DMA_RULE_PREFIX = { cap: "cap.", buff: "buff.", upg: "upg." };
    var DMA_RULE_THRESHOLD = "threshold";
    var DMA_RULE_DEFAULT_BUFF = "defaultBuff";
    var DMA_BUFFS = ["","Fishplate","FishPlatter","SmokedFishSteak","FishDinner","SolidSandwich","GrilledSteak","Steak","RoastMeat","Bread","Sausage","WheatBeer","BirthdayCake","ChocolateBar","AuntIrmasGiftBasket","Stuffing"];
    var DMA_GEOS = ["","Geologist","Jolly Geologist","Sophisticated Geologist","Conscientious Geologist","Versed Geologist","Thorough Geologist","Iron-Willed Geologist","Stone Cold Geologist","Sooty Geologist","Gold-Hearted Geologist","Charming Geologist","Mummified Geologist","Chummy Geologist"];
    function DMA_buffChoices() {
        var out = DMA_BUFFS.slice();
        try {
            if (typeof DM_refreshBuffInventory === "function") DM_refreshBuffInventory();
            if (typeof DM_buffsAvailable === "object" && DM_buffsAvailable) {
                var k;
                for (k in DM_buffsAvailable) {
                    if (DM_buffsAvailable.hasOwnProperty(k) && out.indexOf(k) < 0) out.push(k);
                }
            }
        } catch (_) {}
        try {
            var vec = game.gi.mCurrentPlayer.getAvailableBuffs_vector();
            var bi;
            for (bi = 0; vec && bi < vec.length; bi++) {
                var def = vec[bi].GetBuffDefinition && vec[bi].GetBuffDefinition();
                var bn = def && def.GetName_string && def.GetName_string();
                if (bn && out.indexOf(bn) < 0) out.push(bn);
            }
        } catch (_) {}
        var head = out.length && out[0] === "" ? [out.shift()] : [];
        out.sort(function (a, b) { return String(a).toLowerCase().localeCompare(String(b).toLowerCase()); });
        return head.concat(out);
    }

    /* ---------- internal state ---------- */
    var DMA_MODAL = "#DMA_ConsoleModal";
    var DMA_BODY = DMA_MODAL + " .modal-body";
    var DMA_REFRESH_MS = 4000;
    var DMA_CYCLE_MS = 30000;
    var DMA_timer = null;
    var DMA_lastTableHtml = "";
    var DMA_lastIdle = null;
    var DMA_cycleTimer = null;
    var DMA_logLines = [];
    var DMA_lastCycleAt = 0;
    var DMA_openTypes = {};

    /* ---------- resolve client helpers and DMA/Grok modules at call time ---------- */
    function hasJQ() { return typeof $ === "function"; }
    /* 0.1.57: live, the console found no policy instance ("adv change ... diag no policy"): every rule the player set
       went nowhere and the switches showed off. If the boot script did not make the instance, make it here, once,
       and log why the boot could have failed. */
    var DMA_policyBootTried = false;
    function policy() {
        if (typeof GCAF_PlayerPolicyInstance !== "undefined" && GCAF_PlayerPolicyInstance) return GCAF_PlayerPolicyInstance;
        if (!DMA_policyBootTried && root.GCAF_PlayerPolicy && typeof root.GCAF_PlayerPolicy.create === "function") {
            DMA_policyBootTried = true;
            var step = "create";
            try {
                var pi = root.GCAF_PlayerPolicy.create(); step = "load"; pi.load(); step = "start"; pi.start();
                root.GCAF_PlayerPolicyInstance = pi;
                try { DMA_log("policy instance made by the console (" + (pi.version || "?") + "): the boot script had not made it"); } catch (_) {}
                return pi;
            } catch (e) { try { DMA_log("policy boot failed at " + step + ": " + e + (e && e.line ? " line " + e.line : "")); } catch (_) {} }
        }
        return null;
    }
    function overview() { return (typeof GCAF_OperationsOverview !== "undefined" && GCAF_OperationsOverview) ? GCAF_OperationsOverview : null; }
    function consoleMod() { return (typeof GCAF_Console !== "undefined" && GCAF_Console) ? GCAF_Console : null; }

    function DMA_pol(id, dflt) {
        var p = policy();
        if (/\.auto$/.test(String(id))) {
            try { if (p && p.get) return p.get(id) === true; } catch (_) {}
            return dflt;
        }
        var v = null;
        try { v = (p && typeof p.getPolicy === "function") ? p.getPolicy() : null; } catch (_) { v = null; }
        v = v || {};
        return (v[id] === undefined || v[id] === null) ? dflt : v[id];
    }
    function DMA_esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;"); }
    function DMA_opts(list, cur) {
        var i, v, h = "";
        cur = String(cur == null ? "" : cur);
        for (i = 0; i < list.length; i++) {
            v = list[i];
            h += '<option value="' + DMA_esc(v) + '"' + (v === cur ? " selected" : "") + ">" + DMA_esc(v || "(auto)") + "</option>";
        }
        return h;
    }
    function DMA_num(v, dflt) { var n = parseInt(v, 10); return isNaN(n) ? dflt : n; }

    /* Drunken Miner icon name for a resource: DM_assetsIconsOres when loaded, else the same names locally. */
    function DMA_iconName(R) {
        try {
            if (typeof DM_assetsIconsOres !== "undefined" && DM_assetsIconsOres && DM_assetsIconsOres[R]) return DM_assetsIconsOres[R];
        } catch (_) {}
        return DMA_ICON[R] || "";
    }
    function DMA_icon(R) {
        try {
            if (typeof getImageTag === "function") return getImageTag(DMA_iconName(R), "22px", "22px") || "";
        } catch (_) {}
        return "";
    }
    function DMA_switch(id, checked) {
        try {
            if (typeof createSwitch === "function") return createSwitch(id, !!checked);
        } catch (_) {}
        return '<input type="checkbox" id="' + id + '"' + (checked ? ' checked="checked"' : '') + ' />';
    }

    /* Single point where input leaves the UI: exactly one requestChange per call. */
    function DMA_change(rule, value) {
        var p = policy();
        if (!p || typeof p.requestChange !== "function") {
            DMA_log("policy not loaded: " + rule + " = " + value);
            return false;
        }
        var res = null;
        try {
            res = p.requestChange(rule, value);
        } catch (e) {
            DMA_log("policy: " + (e && e.message ? e.message : e));
            return false;
        }
        if (res && res.fact === "dc") {
            DMA_log("policy declined " + rule + " " + (res.reason || "") + " " + (res.ruleId || ""));
            return false;
        }
        DMA_log(rule + " = " + value);
        return true;
    }

    function DMA_cycleOnce() {
        return false;
    }

    /* 0.1.7: switches persist in the Player Policy; nothing to save or load here. */
    function DMA_saveSwitches() {}
    function DMA_loadSwitches() {}
    function DMA_cycleIsOn() {
        try { if (typeof localStorage !== "undefined" && localStorage.getItem("dma.cycleRunning") === "1") return true; } catch (_) {}
        if (DMA_cycleTimer) return true;
        try { if (typeof window !== "undefined" && window.__GCAF_CycleTimer) return true; } catch (_) {}
        try {
            var p = policy();
            if (p && p.get && p.get("control.cycleRunning") === true) return true;
        } catch (_) {}
        return false;
    }

    function DMA_syncCycleButton() {
        if (!hasJQ()) return;
        var on = DMA_cycleIsOn();
        var $b = $("#DMA_btn_cycle");
        if (!$b.length) return;
        $b.text(on ? "Stop cycle" : "Start cycle");
        if (on) $b.addClass("btn-success"); else $b.removeClass("btn-success");
    }

    /* ============================================================
     * renderToolbar()  ->  HTML string   (NOT replaced on refresh)
     * ============================================================ */
    function renderToolbar() {
        var h = '<div id="DMA_ConsoleToolbar" class="dma-toolbar">';
        h += '<div class="dma-switches">';
        var swl = DMA_switches();
        for (var i = 0; i < swl.length; i++) {
            var s = swl[i];
            h += '<label class="dma-sw" title="' + DMA_esc(s.title) + '">'
               +   DMA_switch(s.id, !!DMA_pol(s.rule, false))
               +   '<span>' + s.label + '</span>'
               + '</label>';
        }
        h += '</div>';
        h += '<div class="dma-globals">'
           +   '<span class="dma-idle">Idle geos <b id="DMA_idle">–</b></span>'
           +   '<label style="margin-left:12px;">Demolish Threshold <input type="number" id="DMA_thr" class="dma-in" min="0" value="20"></label>'
           +   '<label style="margin-left:12px;" title="The word in a guild message the chat watcher replies to - your own name, e.g. Joe (several: comma separated)">Chat reply word <input type="text" id="DMA_words" class="dma-in" style="width:120px" maxlength="120" value="' + DMA_esc(String(DMA_pol("chat.words", "") || "")) + '"></label>'
           + '</div>';
        h += '</div>';
        h += '<div id="DMA_actors" class="dma-actors">' + DMA_actorsHtml() + '</div>';
        return h;
    }

    /* one line per self-starter: what it is doing now, and why not when it is not */
    function DMA_actorsHtml() {
        var list = [];
        try { if (root.DMA_Demo && root.DMA_Demo.actors) list = root.DMA_Demo.actors() || []; } catch (_) {}
        try { list = list.concat(DMA_guildActors()); } catch (_) {}   // 0.1.10
        if (!list.length) return '<span class="dma-act-off">actors not loaded</span>';
        var colour = { off: "#777", blocked: "#e0a030", idle: "#9ab", acting: "#6c6", error: "#e55" };
        return list.map(function (a) {
            var c = colour[a.state] || "#9ab";
            return '<span class="dma-act" title="' + DMA_esc(a.actor + ": " + a.state + (a.reason ? " - " + a.reason : "")) + '">'
                 + '<b style="color:' + c + '">' + DMA_esc(a.label) + '</b> '
                 + DMA_esc(a.state + (a.reason ? ": " + a.reason : ""))
                 + '</span>';
        }).join("");
    }

    /* ============================================================
     * renderTable(gatherResult)  ->  HTML string   (only this part refreshes)
     * ============================================================ */
    function DMA_goTo(grid) {
        try { $(DMA_MODAL).modal("hide"); } catch (_) {}
        try {
            if (typeof _DM_GoTo === "function") { _DM_GoTo(grid); return; }
        } catch (_) {}
        try {
            swmmo.application.mGameInterface.mCurrentPlayerZone.ScrollToGrid(grid);
        } catch (_) {}
    }

    /* 0.1.104 (author 2026-11-18: "Ik dacht dat we de speler een label lieten definieren"): every spot row has the player's own label
       (location.label.grid.<grid>, the existing label store and change path); a spot picked by a workflow that is on shows "WF". */
    function DMA_locLabel(grid) {
        var v = ""; try { if (root.DMA_Labels && root.DMA_Labels.get) v = root.DMA_Labels.get("location.label.grid." + grid) || ""; } catch (_) {}
        if (!v) { try { var p = root.GCAF_PlayerPolicyInstance; v = (p && p.get && p.get("location.label.grid." + grid)) || ""; } catch (_) {} }
        return String(v || "");
    }
    function DMA_locLabelIn(grid, R) {
        if (grid == null || grid === "") return "";
        var ph = "label"; try { var nb = root.DMA_Spots && root.DMA_Spots.numberOf ? root.DMA_Spots.numberOf(grid) : null; if (nb) ph = (DMA_SHORT[nb.resource] || nb.resource) + " " + (nb.no < 10 ? "0" : "") + nb.no; } catch (_) {}   // 0.1.105: the spot's fixed number
        return '<input type="text" class="dma-in dma-label" data-rule="location.label.grid.' + DMA_esc(grid) + '" value="' + DMA_esc(DMA_locLabel(grid)) + '" placeholder="' + DMA_esc(ph) + '" style="width:110px">';
    }
    function DMA_wfTag(grid) {
        try {
            var W = root.DMA_Workflows; if (!W || !W.resources) return "";
            for (var i = 0; i < W.resources.length; i++) { var c = W.config(W.resources[i]); if (c.on && (c.grids || []).indexOf(String(grid)) >= 0) return ' <span title="picked by the workflow Deposit Cycling" style="color:#7fd3a8;font-weight:bold">WF</span>'; }
        } catch (_) {}
        return "";
    }
    function renderTable(g) {
        var byType = {};
        var list = (g && g.resources) || [];
        for (var i = 0; i < list.length; i++) byType[list[i].resourceType] = list[i];
        var buffs = DMA_buffChoices();
        var h = '<table id="DMA_ConsoleData" class="dma-table"><thead><tr>'
              + '<th></th><th>have</th><th>cap</th><th>status</th><th>free</th><th title="buffed mines / masons">buffed</th><th>time</th><th></th><th title="the geologist type that searches for this resource">geo</th><th title="the upgrade target level: mines of this resource are upgraded up to it; \u2014 = no target, nothing is upgraded">upg</th>'
              + '</tr></thead><tbody>';
        for (var r = 0; r < DMA_RESOURCES.length; r++) {
            var R = DMA_RESOURCES[r];
            var d = byType[R] || {};
            var locs = d.locations || [];
            if (!locs.length && typeof DMA_Demo !== "undefined" && DMA_Demo.memory) {
                try {
                    var mem = DMA_Demo.memory();
                    var slots = (mem && mem.slots) || [];
                    var si, s;
                    for (si = 0; si < slots.length; si++) {
                        s = slots[si];
                        if (s.resource !== R) continue;
                        locs.push({
                            grid: s.grid,
                            amount: s.amount,
                            level: s.level,
                            buffed: !!s.buffed,
                            reason: s.status || (s.mine ? "mine" : "deposit"),
                            label: s.name || "",
                            labelRule: "location.label.grid." + s.grid
                        });
                    }
                } catch (_) {}
            }
            /* live buff / level from the location manager's facts, by grid */
            try {
                var memB = (typeof DMA_Demo !== "undefined" && DMA_Demo.memory) ? DMA_Demo.memory() : null;
                var byGrid = {};
                ((memB && memB.slots) || []).forEach(function (sl) { if (sl && sl.grid != null) byGrid[String(sl.grid)] = sl; });
                locs.forEach(function (lc) {
                    var f = lc && lc.grid != null ? byGrid[String(lc.grid)] : null;
                    if (!f) return;
                    if (f.mine) { lc.buffed = !!f.buffed; if (!lc.level && f.level) lc.level = f.level; }
                });
            } catch (_) {}
            var nDep = 0, nMine = 0;
            var li0;
            for (li0 = 0; li0 < locs.length; li0++) {
                var rs = String(locs[li0].reason || "");
                if (rs.indexOf("mine") >= 0 || /mason|quarry/i.test(String(locs[li0].label || ""))) nMine += 1;
                else nDep += 1;
            }
            var QUARRY = { Stone: 1, Marble: 1, Granite: 1 };
            var nBuff = 0;
            for (li0 = 0; li0 < locs.length; li0++) {
                var rs2 = String(locs[li0].reason || "");
                var isM = rs2.indexOf("mine") >= 0 || /mason|quarry/i.test(String(locs[li0].label || ""));
                if (isM && (locs[li0].buffed || rs2.indexOf("buffed") >= 0) && rs2.indexOf("unbuffed") < 0) nBuff += 1;
            }
            var haveTxt = QUARRY[R] ? (nDep + "D/" + nMine + "M") : String(nMine || nDep);
            var have = QUARRY[R] ? nDep : (nMine || nDep);
            var cap  = DMA_pol(DMA_RULE_PREFIX.cap + R, d.cap == null ? 0 : d.cap);
            var capTip = "Managed from game limits";
            try {
                var tg = root.DMA_Green && root.DMA_Green.target && root.DMA_Green.target(R);
                if (tg) {
                    cap = tg.capacity;
                    capTip = "capacity " + tg.capacity + (tg.proven ? " (proven by a search)" : " (" + tg.spots + " spots seen, seed " + tg.seed + ")")
                           + "; occupied " + tg.occupied + ", empty " + tg.empty + ", due " + tg.due + ", searching " + tg.open;
                }
            } catch (_) {}
            var LUCKY_BASE = { Marble: 10, IronOre: 16 };
            var base = LUCKY_BASE[R];
            var freeN = QUARRY[R] ? nDep : nDep;
            var status = "ok";
            if (d.search) status = "geo";
            else if (base != null && have >= base && have < cap) status = "LF";
            else if (have < cap) status = "search";
            else if (!QUARRY[R] && freeN > 0) status = "build";
            if (have >= cap) status = "ok";
            try { var F5 = root.DMA_Control && root.DMA_Control.finds ? root.DMA_Control.finds() : null; if (F5 && !F5.scannedAt) status = "first scan…"; } catch (_) {}   // 0.1.69 (P5)
            var q    = "—";
            var tgeo = "—";
            var upg  = Number(DMA_pol(DMA_RULE_PREFIX.upg + R, 0) || 0);   // 0.1.99 (UAT F2): no target stored = 0 = "\u2014" (was 5, shown as the maximum)
            var upgMax = (R === "Stone" || R === "Marble" || R === "Granite") ? 7 : 6;
            var upgOpts = '<option value="0"' + (upg < 1 ? " selected" : "") + ">\u2014</option>";
            var ui;
            for (ui = 1; ui <= upgMax; ui++) upgOpts += '<option value="' + ui + '"' + (upg >= 1 && Math.min(upg, upgMax) === ui ? " selected" : "") + ">" + ui + "</option>";

            var geo  = DMA_pol("geo." + R, DMA_pol("search.preferredType", ""));
            var open = !!DMA_openTypes[R];
            var need = (status === "search" || status === "LF" || status === "build");
            h += '<tr class="dma-type' + (need ? " dma-short" : "") + (open ? " open" : "") + '" data-res="' + R + '">'
               +   '<td class="dma-ic dma-tog"><span class="dma-exp">' + (open ? "▼" : "▶") + "</span> " + DMA_icon(R) + '<span class="dma-rn">' + DMA_SHORT[R] + "</span></td>"
               +   '<td class="dma-n">' + haveTxt + "</td>"
               +   '<td><input type="number" min="0" class="dma-in dma-cap" id="DMA_cap_' + R + '" data-rule="' + DMA_RULE_PREFIX.cap + R + '" value="' + DMA_esc(cap) + '" readonly title="' + DMA_esc(capTip) + '"></td>'
               +   '<td class="dma-n' + (need ? " dma-warn" : "") + '" title="ok / search / LF / build / geo">' + status + "</td>"
               +   '<td class="dma-n">' + (freeN == null ? "—" : freeN) + "</td>"
               +   '<td class="dma-n">' + (nMine ? (nBuff + "/" + nMine) : "—") + "</td>"
               +   '<td class="dma-q' + (d.search ? " on" : "") + '">' + q + "</td>"
               +   '<td class="dma-n">' + tgeo + "</td>"
               +   '<td><select class="dma-in" data-rule="geo.' + R + '">' + DMA_opts(DMA_GEOS, geo) + "</select></td>"
               +   '<td><select class="dma-in dma-upg" id="DMA_upg_' + R + '" data-rule="' + DMA_RULE_PREFIX.upg + R + '">' + upgOpts + "</select></td>"
               + "</tr>";
            if (open) {
                h += '<tr class="dma-subh"><th></th><th>grid</th><th>status</th><th>time</th><th></th><th></th><th></th><th colspan="2" title="your own name for this spot; the WORKFLOWS page shows it">label</th><th>go</th></tr>';
                var li, loc, shown = {};
                var slots = [];
                for (li = 0; li < locs.length; li++) {
                    loc = locs[li];
                    shown[String(loc.grid)] = true;
                    slots.push(loc);
                }
                var searchGeos = [];
                try {
                    var allGeos = root.DMA_Control && root.DMA_Control.geologists && root.DMA_Control.geologists();
                    if (allGeos) {
                        for (var sgi = 0; sgi < allGeos.length; sgi++) {
                            if (!allGeos[sgi].idle && allGeos[sgi].taskResource === R) searchGeos.push(allGeos[sgi]);
                        }
                    }
                } catch (_) {}
                /* 0.1.105 (ADR 0086): every registered spot of the resource, in its fixed order, with its number and the player's label —
                   whether it holds a deposit, a mine or nothing; the anonymous "empty" rows and the "known" rows are gone */
                function slotRow(loc) {
                    var h = "";
                    var isMineRow = String(loc.reason || "").indexOf("mine") >= 0 || /mason|quarry/i.test(String(loc.label || ""));
                    var isBuffed = isMineRow && (loc.buffed || (String(loc.reason || "").indexOf("buffed") >= 0 && String(loc.reason || "").indexOf("unbuffed") < 0));
                    var low = isMineRow && loc.amount != null && Number(loc.amount) > 0 && Number(loc.amount) <= (Number(DMA_pol("demolish.threshold", 20)) || 20);
                    var alertDot = low ? DMA_lamp("#ff2020", "low") : "";
                    var buffDot = isMineRow ? (isBuffed ? DMA_lamp("#00ff44", "buffed") : DMA_lamp("#555555", "not buffed")) : "";
                    var locStatus = isMineRow ? (isBuffed ? "buffed" : ("lvl" + (loc.level || 0))) : (/^building|^promised|^upgrade/.test(String(loc.reason || "")) ? String(loc.reason) : "deposit");
                    var locTime = "—";
                    var cycle = 6, out = Math.max(1, loc.level || 1), mult = isBuffed ? 2 : 1;
                    var perHour = (out * mult * 60) / cycle;
                    if (loc.amount != null && loc.amount > 0 && perHour > 0) {
                        var hrs = loc.amount / perHour;
                        locTime = hrs < 1 ? Math.round(hrs * 60) + "m" : Math.round(hrs) + "h";
                    } else if (!isMineRow && loc.amount != null) {
                        locTime = loc.amount + " rem";
                    }
                    var typeLabel = isMineRow ? (/mason/i.test(String(loc.label || loc.name || "")) ? "Mason" : "Mine") : "Deposit";
                    h += '<tr class="dma-loc" data-grid="' + DMA_esc(loc.grid || "") + '">'
                       +   '<td class="dma-ic">' + typeLabel + '</td>'
                       +   '<td class="dma-n">' + (loc.grid != null && loc.grid !== "" ? loc.grid : "—") + "</td>"
                       +   '<td class="dma-n">' + locStatus + DMA_wfTag(loc.grid) + "</td>"
                       +   '<td class="dma-n"></td>'
                       +   '<td class="dma-n">' + alertDot + "</td>"
                       +   '<td class="dma-n">' + buffDot + "</td>"
                       +   '<td class="dma-n">' + locTime + "</td>"
                       +   '<td colspan="2">' + DMA_locLabelIn(loc.grid, R) + "</td>"
                       +   '<td>' + (loc.grid ? '<button type="button" class="btn btn-default btn-xs dma-goto" data-grid="' + DMA_esc(loc.grid) + '">⌖</button>' : "") + "</td>"
                       + "</tr>";
                    return h;
                }
                for (var sgi2 = 0; sgi2 < searchGeos.length; sgi2++) {
                    var sg = searchGeos[sgi2];
                    h += '<tr class="dma-loc">'
                       +   '<td class="dma-ic">' + DMA_esc(sg.typeName || sg.name || "geo") + "</td>"
                       +   '<td class="dma-n">—</td>'
                       +   '<td class="dma-n" style="color:#8cf;">searching</td>'
                       +   '<td></td><td></td><td></td>'
                       +   '<td class="dma-n">' + DMA_esc(sg.remaining || "—") + "</td>"
                       +   '<td></td><td></td><td></td>'
                       + "</tr>";
                }
                var spotList = []; try { spotList = root.DMA_Spots && root.DMA_Spots.list ? root.DMA_Spots.list(R) || [] : []; } catch (_) { spotList = []; }
                var byGrid = {}; for (li = 0; li < locs.length; li++) byGrid[String(locs[li].grid)] = locs[li];
                for (var spi = 0; spi < spotList.length; spi++) {
                    var sp = spotList[spi], gs = String(sp.grid);
                    if (byGrid[gs]) { h += slotRow(byGrid[gs]); delete byGrid[gs]; continue; }
                    h += '<tr class="dma-loc" data-grid="' + DMA_esc(gs) + '">'
                       +   '<td class="dma-ic dma-dim">' + (sp.registered ? "spot " + (sp.no < 10 ? "0" : "") + sp.no : "new spot") + '</td>'
                       +   '<td class="dma-n">' + DMA_esc(gs) + "</td>"
                       +   '<td class="dma-n" style="color:#888;">empty' + DMA_wfTag(gs) + "</td>"
                       +   '<td class="dma-n"></td><td class="dma-n"></td><td class="dma-n"></td><td class="dma-n"></td>'
                       +   '<td colspan="2">' + DMA_locLabelIn(gs, R) + "</td>"
                       +   '<td><button type="button" class="btn btn-default btn-xs dma-goto" data-grid="' + DMA_esc(gs) + '" title="Go to location">⌖</button></td>'
                       + "</tr>";
                }
                for (li = 0; li < locs.length; li++) if (byGrid[String(locs[li].grid)]) h += slotRow(locs[li]);   // not registered (yet): after the list
                if (!spotList.length) {   // no registered spots for this resource: the empty places as before
                    var emptySlots = Math.max(0, cap - slots.length - searchGeos.length);
                    for (var ei = 0; ei < emptySlots; ei++) h += '<tr class="dma-loc"><td class="dma-ic" style="color:#666;">—</td><td class="dma-n" style="color:#666;">—</td><td class="dma-n" style="color:#666;">empty</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
                }
            }
        }
        h += "</tbody></table>";
        return h;
    }

    function DMA_loadedVersions() {
        var bits = [];
        function v(obj, name) {
            if (!obj) return;
            var ver = obj.version || obj.VERSION || "";
            bits.push(name + " " + (ver || "on"));
        }
        var overall = (root.DMA_Control && root.DMA_Control.overall) || "0.4.0";
        bits.push("DMA " + overall);
        v(root.DMA_Control, "control");
        v(root.DMA_Green, "green");
        bits.push("ui " + VERSION);
        v(root.DMA_Demo, "demo");
        v(root.DMA_Buffer, "buff");
        v(root.DMA_ConstructionManager, "construction");
        v(root.DMA_DepositSearchManager, "search");
        v(root.DMA_Workflows, "workflows");   // 0.1.103
        v(root.GCAF_OperationsOverview, "overview");
        v(root.GCAF_App || root.GCAF_Console, "app");
        v(root.GCAF_PlayerPolicyInstance, "policy");
        v(root.DMA_Labels, "labels");
        v(root.DMA_GeoSkills, "geo");
        return bits;
    }
    function DMA_versionTitle() {
        var bits = DMA_loadedVersions();
        return "DMA Console  ·  " + bits.join("  ·  ");
    }
    function renderVersionBar() {
        var bits = DMA_loadedVersions();
        return '<div id="DMA_versionBar" class="dma-ver" title="loaded modules">'
             + DMA_esc(bits.join("  ·  "))
             + "</div>";
    }

    /* ============================================================
     * Body / footer / log
     * ============================================================ */
    function renderBodyShell() {
        return renderToolbar()
             + renderVersionBar()
             + '<div id="DMA_ConsoleDataWrap" class="dma-wrap"></div>'
             + '<pre id="DMA_log" class="dma-log"></pre>';
    }

    function renderFooter() {
        return '<button type="button" class="btn btn-sm" id="DMA_btn_spec" title="Specialist skills" style="background:#3a6ea5;color:#fff;width:70px;">SPEC</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_buff" title="Buff manager" style="background:#5a8f3a;color:#fff;width:70px;">BUFF</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_trade" title="Round trade rules" style="background:#8a5a2a;color:#fff;width:70px;">TRADE</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_mail" title="Mail rules" style="background:#6a4a8a;color:#fff;width:70px;">MAIL</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_quest" title="Quest manager: what it does in the quest book, what it watches, who executes" style="background:#2a7a7a;color:#fff;width:70px;">QUEST</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_advs" title="Adventures and their rules" style="background:#7a2a2a;color:#fff;width:70px;">ADVS</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_event" title="Event manager: running events and their rules" style="background:#8a5a1a;color:#fff;width:70px;">EVENT</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_value" title="Value of every good through its production chain" style="background:#4a6a2a;color:#fff;width:70px;">VALUE</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_troops" title="Troops: the target strength per unit kind, beside the army and what is in training" style="background:#6a5a3a;color:#fff;width:70px;margin-right:12px;">TROOPS</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_tx" title="Transactions: every transaction and its real status" style="background:#5a3a6a;color:#fff;width:70px;margin-right:12px;">TX</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_rules" title="Every business rule: switch it on or off and set its value" style="background:#2a4a7a;color:#fff;width:70px;margin-right:12px;">RULES</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_workflows" title="Workflows: switchable sets of existing roles and rules on spots you pick (Deposit Cycling)" style="background:#3a7a5a;color:#fff;width:90px;margin-right:12px;">WORKFLOWS</button>'
             + '<button type="button" class="btn btn-sm" id="DMA_btn_feedback" title="Make a feedback report: a short text to paste in Discord and a full report file" style="background:#b05a10;color:#fff;width:90px;margin-right:12px;">FEEDBACK</button>'
             + '<button type="button" class="btn btn-default btn-sm" id="DMA_btn_refresh" style="margin-right:12px;">Refresh</button>'
             + '<button type="button" class="btn btn-default btn-sm" id="DMA_btn_copylog" style="margin-right:12px;">Copy log</button>'
             + '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal" style="float:right;">Close</button>';
    }

    function DMA_log(msg) {
        DMA_logLines.unshift(String(msg));
        if (DMA_logLines.length > 200) DMA_logLines.pop();
        if (hasJQ()) { try { $("#DMA_log").text(DMA_logLines.join("\n")); } catch (_) {} }
        DMA_writeDebugLog();
    }

    function DMA_debugPath() {
        var stand = DMA_standPath();
        if (!stand) return "dma-debug-log.txt";
        var i = Math.max(stand.lastIndexOf("/"), stand.lastIndexOf("\\"));
        if (i < 0) return "dma-debug-log.txt";
        return stand.slice(0, i + 1) + "dma-debug-log.txt";
    }

    var DMA_lastLogWrite = 0;
    function DMA_writeDebugLog() {
        var now = Date.now();
        if (now - DMA_lastLogWrite < 2000) return;
        DMA_lastLogWrite = now;
        if (typeof air === "undefined" || !air.File || !air.FileStream) return;
        try {
            var extra = [];
            try { extra = (window.__DMA_CYCLE_LOG || []).slice(-80); } catch (_) {}
            var text = DMA_logLines.concat(["--- cycle ---"], extra).join("\n");
            var file = new air.File(DMA_debugPath());
            var stream = new air.FileStream();
            stream.open(file, air.FileMode.WRITE);
            stream.writeUTFBytes(text);
            stream.close();
        } catch (_) {}
    }

    /* ============================================================
     * Silent refresh: only #DMA_ConsoleDataWrap and the idle number
     * ============================================================ */
    function DMA_refreshTable(force) {
        if (DMA_geoOpen) return;
        if (!hasJQ() || !$(DMA_MODAL).is(":visible")) return;
        var g = null;
        var o = overview();
        if (!o || typeof o.gather !== "function") { DMA_log("GCAF_OperationsOverview not loaded"); }
        else {
            try { g = o.gather(); } catch (e) { DMA_log("gather: " + (e && e.message ? e.message : e)); return; }
        }

        /* idle: change the text only, the toolbar stays */
        try {
            if (typeof window !== "undefined" && window.__DMA_CYCLE_LOG && window.__DMA_CYCLE_AT !== DMA_lastCycleAt) {
                DMA_lastCycleAt = window.__DMA_CYCLE_AT;
                var ci, chunk = window.__DMA_CYCLE_LOG || [];
                for (ci = 0; ci < chunk.length; ci++) DMA_log(String(chunk[ci]));
            }
        } catch (_) {}
        var idle = g && g.idleGeologists != null ? g.idleGeologists : "–";
        if (idle !== DMA_lastIdle) { DMA_lastIdle = idle; $("#DMA_idle").text(idle); }
        try { $("#DMA_versionBar").text(DMA_loadedVersions().join("  ·  ")); } catch (_) {}
        try { $("#DMA_actors").html(DMA_actorsHtml()); } catch (_) {}
        try {
            var ctrl = (typeof DMA_Control !== "undefined") ? DMA_Control : null;
            var geos = (ctrl && ctrl.geologists) ? ctrl.geologists() : [];
            var idleN = 0, lfIdle = 0, lfOut = 0, lfFor = [];
            var gi;
            for (gi = 0; gi < geos.length; gi++) {
                var gg = geos[gi];
                if (gg.idle) idleN += 1;
                var hasLF = false;
                try {
                    hasLF = !!(root.DMA_GeoSkills && root.DMA_GeoSkills.luckyFind && root.DMA_GeoSkills.luckyFind(gg));
                    if (!hasLF) hasLF = /Sophisticated/i.test(gg.typeName || gg.name || "");
                    if (!hasLF) hasLF = !!(gg.extraDeposit && (gg.extraDeposit.kind === "chance15" || /Iron|Marble/.test(String((gg.extraDeposit.resources || []).join(",")))));
                } catch (_) {}
                if (hasLF) {
                    if (gg.idle) lfIdle += 1;
                    else { lfOut += 1; if (gg.taskResource) lfFor.push(gg.taskResource); }
                }
            }
            if ($("#DMA_geoInfo").length) $("#DMA_geoInfo").text("idle " + idleN + " · LF free " + lfIdle);
        } catch (_) {}

        var html = renderTable(g);
        if (!force && html === DMA_lastTableHtml) return;

        var $focus = $(document.activeElement);
        if ($focus.hasClass("dma-label")) return;

        var kept = {};
        $("#DMA_ConsoleDataWrap .dma-label").each(function () {
            var rule = $(this).data("rule");
            if (rule) kept[String(rule)] = $(this).val();
        });

        var focusId = $focus.attr("id") || "";
        var inTable = $focus.closest("#DMA_ConsoleDataWrap").length > 0;
        var focusVal = inTable && ($focus.is("input") || $focus.is("select")) ? ($focus.is(":checkbox") ? $focus.prop("checked") : $focus.val()) : null;
        var selStart = null, selEnd = null;
        if (inTable && focusVal !== null && !$focus.is(":checkbox")) {
            try { selStart = $focus[0].selectionStart; selEnd = $focus[0].selectionEnd; } catch (_) {}
        }

        var $scroll = $("#DMA_ConsoleDataWrap");
        var y = $scroll.scrollTop() || 0;
        DMA_lastTableHtml = html;
        $scroll.html(html);
        $scroll.scrollTop(y);

        $("#DMA_ConsoleDataWrap .dma-label").each(function () {
            var rule = $(this).data("rule");
            if (rule && Object.prototype.hasOwnProperty.call(kept, String(rule))) $(this).val(kept[String(rule)]);
        });

        if (inTable && $("#" + focusId).length) {
            var $f = $("#" + focusId);
            if ($f.is(":checkbox")) $f.prop("checked", focusVal); else $f.val(focusVal);
            $f.focus();
            if (selStart != null) { try { $f[0].setSelectionRange(selStart, selEnd); } catch (_) {} }
        }
    }

    function startSilentRefresh(ms) {
        stopSilentRefresh();
        DMA_refreshTable(true);
        DMA_timer = setInterval(function () { DMA_refreshTable(false); }, ms || DMA_REFRESH_MS);
    }
    function stopSilentRefresh() {
        if (DMA_timer) { clearInterval(DMA_timer); DMA_timer = null; }
    }

    /* ============================================================
     * Event binding (delegated: survives replacing the table)
     * ============================================================ */
    /* ---------- Fixed-path stand file (air.File, auto-load on start) ---------- */
    var DMA_STAND_KEY = "dma.standPath";
    var DMA_STAND_NAME = "dma-stand.json";

    function DMA_defaultPath() {
        try {
            if (typeof air !== "undefined" && air.File) {
                var dir = air.File.applicationDirectory;
                if (dir && dir.exists) return dir.resolvePath(DMA_STAND_NAME).nativePath;
            }
        } catch (_) {}
        return DMA_STAND_NAME;
    }

    function DMA_standPath() {
        try {
            var p = localStorage.getItem(DMA_STAND_KEY);
            if (p && String(p).trim()) return String(p).trim();
        } catch (_) {}
        return DMA_defaultPath();
    }

    function DMA_setStandPath(p) {
        if (!p) return;
        try { localStorage.setItem(DMA_STAND_KEY, String(p)); } catch (_) {}
        DMA_log("stand path = " + p);
    }

    function DMA_writeStand(stand) {
        var path = DMA_standPath();
        if (typeof air === "undefined" || !air.File || !air.FileStream) {
            DMA_log("air.File not available");
            return false;
        }
        try {
            var file = new air.File(path);
            var stream = new air.FileStream();
            stream.open(file, air.FileMode.WRITE);
            stream.writeUTFBytes(JSON.stringify(stand, null, 2));
            stream.close();
            DMA_log("saved → " + path);
            return true;
        } catch (e) {
            DMA_log("save failed: " + e);
            return false;
        }
    }

    function DMA_readStand() {
        var path = DMA_standPath();
        if (typeof air === "undefined" || !air.File || !air.FileStream) return null;
        try {
            var file = new air.File(path);
            if (!file.exists) { DMA_log("no stand file at " + path); return null; }
            var stream = new air.FileStream();
            stream.open(file, air.FileMode.READ);
            var txt = stream.readUTFBytes(stream.bytesAvailable);
            stream.close();
            var data = JSON.parse(txt);
            DMA_log("loaded ← " + path);
            return data;
        } catch (e) {
            DMA_log("load failed: " + e);
            return null;
        }
    }

    function DMA_collectStand() {
        var policyPayload = {};
        try {
            var p = policy();
            policyPayload = (p && p.getPolicy) ? (p.getPolicy() || {}) : {};
        } catch (_) {}
        DMA_switches().forEach(function (s) { policyPayload[s.rule] = DMA_pol(s.rule, false) === true; });
        if ($("#DMA_thr").length) policyPayload["demolish.threshold"] = DMA_num($("#DMA_thr").val(), 20);
        if ($("#DMA_words").length) policyPayload["chat.words"] = String($("#DMA_words").val() || "");
        if ($("#DMA_defbuff").length) policyPayload["buff.defaultName"] = $("#DMA_defbuff").val() || "";
        if ($("#DMA_prefgeo").length) policyPayload["search.preferredType"] = $("#DMA_prefgeo").val() || "";
        var ri, R;
        for (ri = 0; ri < DMA_RESOURCES.length; ri++) {
            R = DMA_RESOURCES[ri];
            var $cap = $("#DMA_cap_" + R);
            var $upg = $("#DMA_upg_" + R);
            var $buff = $("#DMA_buff_" + R);
            var $geo = $("select[data-rule='geo." + R + "']");
            if ($cap.length) policyPayload["location.caps." + R] = DMA_num($cap.val(), 0);
            if ($upg.length) {
                policyPayload["building.upgradeLevel." + R] = DMA_num($upg.val(), 0);
                policyPayload["upg." + R] = DMA_num($upg.val(), 0);
            }
            if ($buff.length) policyPayload["buff.name." + R] = $buff.val() || "";
            if ($geo.length) policyPayload["geo." + R] = $geo.val() || "";
        }
        var labelsPayload = {};
        try { if (typeof DMA_Labels !== "undefined" && DMA_Labels.all) labelsPayload = DMA_Labels.all() || {}; } catch (_) {}
        $(".dma-label").each(function () {
            var rule = $(this).data("rule");
            var val = $(this).val();
            var grid = $(this).closest("tr").attr("data-grid");
            if (rule && val != null) {
                labelsPayload[String(rule)] = val;
                policyPayload[String(rule)] = val;
            }
            if (grid && val != null) {
                labelsPayload["location.label.grid." + grid] = val;
                policyPayload["location.label.grid." + grid] = val;
            }
        });
        return { policy: policyPayload, labels: labelsPayload, managedCaps: DMA_managedCaps, savedAt: new Date().toISOString() };
    }

    var DMA_managedCaps = null;
    function DMA_applyStand(data) {
        if (!data) return;
        var payload = data.policy || data;
        var labels = data.labels || {};
        var k, v;
        for (k in payload) {
            if (!payload.hasOwnProperty(k)) continue;
            v = payload[k];
            try { DMA_change(k, v); } catch (_) {}
            if (String(k).indexOf("building.upgradeLevel.") === 0) {
                try { DMA_change("upg." + k.slice(22), v); } catch (_) {}
            }
            if (String(k).indexOf("location.caps.") === 0) {
                try { DMA_change("cap." + k.slice(15), v); } catch (_) {}
            }
        }
        try {
            if (typeof DMA_Labels !== "undefined" && DMA_Labels.set) {
                for (k in labels) if (labels.hasOwnProperty(k)) DMA_Labels.set(k, labels[k]);
            }
        } catch (_) {}
        DMA_log("stand applied (" + Object.keys(payload).length + " policy, " + Object.keys(labels).length + " labels)");
        /* caps: managed parameter in the stand file */
        var managed = data.managedCaps || DMA_managedCaps;
        if (!managed) {
            managed = {};
            var mr2, pk;
            for (pk in data.policy) {
                if (String(pk).indexOf("location.caps.") === 0) {
                    managed[pk.slice(15)] = data.policy[pk];
                }
            }
        }
        DMA_managedCaps = managed;
        var mr;
        for (mr in managed) {
            if (!managed.hasOwnProperty(mr)) continue;
            try { DMA_change("location.caps." + mr, managed[mr]); } catch (_) {}
            try { DMA_change("cap." + mr, managed[mr]); } catch (_) {}
        }
        if (hasJQ() && $(DMA_MODAL).is(":visible")) DMA_refreshTable(true);
    }

    var DMA_pendingStand = null;
    function DMA_autoLoadStand() {
        if (!DMA_pendingStand) DMA_pendingStand = DMA_readStand();
        if (!DMA_pendingStand) return;
        var p = policy();
        if (!p || typeof p.requestChange !== "function") {
            setTimeout(DMA_autoLoadStand, 500);
            return;
        }
        DMA_applyStand(DMA_pendingStand);
        DMA_pendingStand = null;
    }

    function DMA_bind() {
        var $m = $(DMA_MODAL);
        $m.off(".dma");

        /* switches -> policy */
        $m.on("change.dma", "[id^='DMA_sw_']", function () {
            var id = this.id;
            var swl = DMA_switches();
            for (var i = 0; i < swl.length; i++) if (swl[i].id === id) {
                var v = $(this).is(":checkbox") ? $(this).prop("checked") : !!$(this).val();
                DMA_change(swl[i].rule, v);
                try { $("#DMA_actors").html(DMA_actorsHtml()); } catch (_) {}
            }
        });

        /* global inputs */
        $m.on("change.dma", "#DMA_words",   function () { DMA_change("chat.words", String(this.value || "")); });   // 0.1.11
        $m.on("change.dma", "#DMA_thr",     function () { DMA_change(DMA_RULE_THRESHOLD,    DMA_num(this.value, 0)); });
        $m.on("change.dma", "#DMA_defbuff", function () { DMA_change(DMA_RULE_DEFAULT_BUFF, this.value); });
        $m.on("change.dma", "#DMA_prefgeo", function () { DMA_change("search.preferredType", this.value); });

        /* per-resource inputs (cap / buff / upg) */
        $m.on("change.dma", "#DMA_ConsoleDataWrap input[data-rule], #DMA_ConsoleDataWrap select[data-rule]", function () {
            var rule = $(this).data("rule");
            var raw = $(this).val();
            var v;
            if ($(this).is(":checkbox")) v = $(this).prop("checked");
            else if ($(this).is("select") || String(rule || "").indexOf("location.label.") === 0 || String(rule || "").indexOf("geo.") === 0 || String(rule || "").indexOf("buff.") === 0)
                v = raw;
            else v = (raw === "" ? null : DMA_num(raw, 0));
            if (String(rule || "").indexOf("location.label.") === 0) {
                var grid = $(this).closest("tr").attr("data-grid");
                if (typeof DMA_Labels !== "undefined" && DMA_Labels.set) DMA_Labels.set(rule, v);
                DMA_change(rule, v);
                if (grid) {
                    if (typeof DMA_Labels !== "undefined" && DMA_Labels.set) DMA_Labels.set("location.label.grid." + grid, v);
                    DMA_change("location.label.grid." + grid, v);
                }
                DMA_log(rule + " = " + v);
                return;
            }
            DMA_change(rule, v);
            DMA_lastTableHtml = "";
        });

        /* enter in a field = fire change, do not close the modal */
        $m.on("keydown.dma", "input.dma-in", function (e) { if (e.which === 13) { e.preventDefault(); $(this).trigger("change").blur(); } });

        /* footer */
        $m.on("click.dma", "#DMA_btn_refresh", function () { DMA_refreshTable(true); DMA_log("refreshed"); });
        $m.on("click.dma", "#DMA_btn_spec", function () { DMA_openSpec(); });
        $m.on("click.dma", "#DMA_btn_trade", function () { DMA_openTrade(); });   // 0.1.15
        $m.on("click.dma", "#DMA_btn_rules", function () { DMA_openRules(); });   // 0.1.101
        $m.on("click.dma", "#DMA_btn_feedback", function () { DMA_openFeedback(); });   // 0.1.102
        $m.on("click.dma", "#DMA_btn_workflows", function () { DMA_openWorkflows(); });   // 0.1.103
        $m.on("click.dma", "#DMA_btn_mail", function () { DMA_openMail(); });     // 0.1.18
        $m.on("click.dma", "#DMA_btn_quest", function () { DMA_openQuest(); });   // 0.1.30
        $m.on("click.dma", "#DMA_btn_advs", function () { DMA_openAdvs(); });     // 0.1.35
        $m.on("click.dma", "#DMA_btn_event", function () { DMA_openEvent(); });   // 0.1.39
        $m.on("click.dma", "#DMA_btn_value", function () { DMA_openValue(); });   // 0.1.72
        $m.on("click.dma", "#DMA_btn_tx", function () { DMA_openTx(); });   // 0.1.79
        $m.on("click.dma", "#DMA_btn_troops", function () { DMA_openTroops(); });   // 0.1.90
        $m.on("click.dma", "#DMA_btn_buff", function () { DMA_openBuff(); });
        $m.on("click.dma", "#DMA_geoBack", function () { DMA_closeGeo(); });
        $m.on("change.dma", "#DMA_geoPick", function () {
            DMA_geoId = $(this).val();
            $(DMA_BODY).html(DMA_geoBody());
        });
        $m.on("change.dma", "input.dma-tpl", function () { DMA_saveTemplate(); });
        $m.on("click.dma", "#DMA_tplLock", function () {
            var skills = root.DMA_GeoSkills;
            if (!skills) return;
            skills.setLocked(!skills.locked());
            $(DMA_BODY).html(DMA_geoBody());
        });
        $m.on("click.dma", ".dma-spin", function () {
            DMA_geoSpin(Number($(this).attr("data-i")), $(this).attr("data-dir") === "up" ? 1 : -1);
        });
        $m.on("click.dma", "tr.dma-type", function (e) {
            if ($(e.target).closest("input,select,button,a").length) return;
            var R = $(this).attr("data-res");
            if (!R) return;
            DMA_openTypes[R] = !DMA_openTypes[R];
            DMA_lastTableHtml = "";
            DMA_refreshTable(true);
        });
        $m.on("click.dma", ".dma-goto", function (e) {
            e.preventDefault();
            e.stopPropagation();
            var grid = $(this).attr("data-grid");
            if (grid != null && grid !== "") DMA_goTo(grid);
        });
        $m.on("click.dma", "#DMA_btn_copylog", function () {
            DMA_lastLogWrite = 0;
            DMA_writeDebugLog();
            var extra = [];
            try { extra = (window.__DMA_CYCLE_LOG || []).slice(); } catch (_) {}
            var text = DMA_logLines.concat(["--- cycle ---"], extra).join("\n");
            try {
                if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text);
            } catch (_) {}
            try {
                var blob = new Blob([text], { type: "text/plain" });
                var a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "dma-debug-log.txt";
                document.body.appendChild(a);
                a.click();
                setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (_) {} }, 1500);
            } catch (e) { DMA_log("copy log failed " + e); }
            DMA_log("log written to " + DMA_debugPath());
        });
        $m.on("click.dma", "#DMA_btn_once",    function () {
            DMA_refreshTable(true);
        });

        /* lifecycle */
        $m.on("shown.bs.modal.dma",  function () { startSilentRefresh(DMA_REFRESH_MS); });
        $m.on("hidden.bs.modal.dma", function () { stopSilentRefresh(); });
    }

    /* ---------- CSS (injected once, on first open) ---------- */
    function DMA_injectCss() {
        $("#DMA_ConsoleCss").remove();
        $("head").append('<style id="DMA_ConsoleCss">'
        + '.dma-dialog{width:860px;max-width:96vw}'
        + '#DMA_ConsoleModal .modal-body{padding:8px 10px;overflow:auto;max-height:70vh;color:#fff}'
        + '.dma-toolbar,.dma-sw,.dma-globals,.dma-globals label{color:#fff}'
        + '.dma-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 14px;padding:4px 0 8px;border-bottom:1px solid rgba(255,255,255,.28)}'
        + '.dma-switches{display:flex;flex-wrap:nowrap;gap:12px;align-items:center}'
        + '.dma-actors{display:flex;flex-wrap:wrap;gap:4px 14px;padding:4px 0;font-size:11px;color:#ccc;border-bottom:1px solid rgba(255,255,255,.18)}'
        + '.dma-act{white-space:nowrap}'
        + '.dma-act-off{color:#777}'
        + '.dma-sw{display:inline-flex;align-items:center;gap:4px;margin:0;font-weight:normal;white-space:nowrap}'
        + '.dma-globals{display:flex;align-items:center;gap:14px;margin-left:auto;white-space:nowrap}'
        + '.dma-globals label{margin:0;font-weight:normal}'
        + '.dma-idle b{font-size:16px;margin-left:2px;color:#fff}'
        + '.dma-in{width:56px;height:24px;padding:1px 4px;font-size:12px;text-align:right;border:1px solid #999;border-radius:3px;background:#fff;color:#111}'
        + '.dma-wrap{overflow:auto;max-height:46vh;margin-top:6px}'
        + '.dma-table{width:100%;border-collapse:collapse;font-size:12px;color:#fff}'
        + '.dma-table th{font-weight:600;font-size:10px;text-transform:uppercase;letter-spacing:.03em;text-align:center;padding:3px 4px;color:#fff;border-bottom:1px solid rgba(255,255,255,.35)}'
        + '.dma-table td{padding:2px 4px;border-bottom:1px solid rgba(255,255,255,.12);white-space:nowrap;vertical-align:middle;text-align:center;color:#fff}'
        + '.dma-table td.dma-ic,.dma-table th:first-child{text-align:left;width:1%}'
        + '.dma-table .dma-n{text-align:center}'
        + '.dma-exp{display:inline-block;width:14px;text-align:center;font-size:11px;color:#9cf;cursor:pointer}'
        + '.dma-tog{cursor:pointer}'
        + '.dma-dot{display:inline-block;width:14px;height:14px;-webkit-border-radius:7px;border-radius:7px;background:#555;vertical-align:middle;margin:0 3px}'+ '.dma-dot.on{background:#00ff44;-webkit-box-shadow:0 0 6px #00ff44;box-shadow:0 0 6px #00ff44}'+ '.dma-dot.alert{background:#ff2020;-webkit-box-shadow:0 0 6px #ff2020;box-shadow:0 0 6px #ff2020}'
        + '.dma-table td input.dma-in,.dma-table td select.dma-in{margin:0;background:#fff;color:#111;text-align:center;width:52px;padding:1px 2px}'
        + '.dma-table .dma-cap{width:40px}'
        + '.dma-table .dma-label{width:78px;text-align:left}'
        + '.dma-ic img{vertical-align:middle;width:22px;height:22px}'
        + '.dma-rn{margin-left:4px;font-size:11px;color:#fff}'
        + '.dma-n{font-variant-numeric:tabular-nums;color:#fff}'
        + '.dma-dim{color:#fff;opacity:.75;margin-left:1px}'
        + '.dma-warn{color:#ffb347;font-weight:600}'
        + '.dma-q{text-align:center;color:#fff;opacity:.55}.dma-q.on{opacity:1;color:#9fd4ff;font-weight:700}'
        + '.dma-log{margin:6px 0 0;padding:4px 6px;font-size:11px;line-height:1.35;max-height:28vh;height:28vh;overflow:auto;background:rgba(0,0,0,.18);border:0;color:#fff;white-space:pre}'
        + '.dma-ver{font-size:11px;color:#cfe8ff;opacity:.9;padding:2px 6px 4px;letter-spacing:.2px}'
        + '.dma-geo-head{display:flex;align-items:center;gap:6px;padding:2px 0 6px}'
        + '.dma-geo-head select{max-width:420px}'
        + '.dma-geo-total{margin-left:auto;font-size:14px}'
        + '.dma-skillgrid{display:flex;flex-direction:column;gap:3px}'
        + '.dma-skillrow{display:flex;gap:4px;justify-content:flex-start}'
        + '.dma-skill{width:108px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.18);border-radius:3px;padding:3px 4px;text-align:center}'
        + '.dma-skill-locked{opacity:.5}'
        + '.dma-skill .dma-tpl{width:100%;margin:0 0 2px;padding:1px 2px;font-size:10px;text-align:center;height:20px}'
        + '.dma-spinbox{display:flex;align-items:center;justify-content:center;gap:2px}'
        + '.dma-spin{width:18px;height:18px;padding:0;line-height:16px;font-size:12px}'
        + '.dma-spin-n{min-width:28px;font-size:12px;font-variant-numeric:tabular-nums}'
        + '.dma-skill-why{font-size:9px;color:#ffb347;line-height:1.1;margin-top:1px}'
        + '#DMA_ConsoleModal .modal-footer{padding:8px 10px}'
        + '#DMA_ConsoleModal .modal-footer .btn{margin-left:4px}'
        + '</style>');
    }

    var DMA_geoId = "";
    var DMA_geoOpen = false;
    function DMA_openBuff() {
        if (!hasJQ()) return false;
        $(DMA_MODAL + " .modal-title").text("Buffs");
        var html = '<div style="padding:8px;">'
            + '<div class="checkbox" style="margin:0 0 4px;"><label style="color:#ccc;"><input type="checkbox" id="DMA_buffRainbow" checked> Use Bag of Rainbow Snow only on endless mines</label></div>'
            + '<div style="margin:0 0 4px;"><label style="color:#ccc;margin-right:8px;">Filter:</label><input type="text" id="DMA_buffFilter" class="form-control input-sm" style="width:120px;display:inline-block;" placeholder="name..."><select id="DMA_buffCat" class="form-control input-sm" style="width:auto;display:inline-block;margin-left:4px;"><option value="">All</option><option value="mine">Mines</option><option value="mason">Masons</option><option value="production">Production</option><option value="residence">Residence</option></select><label style="color:#ccc;margin-left:12px;margin-right:8px;">Apply to all:</label><select id="DMA_buffApplyAll" class="form-control input-sm" style="width:auto;display:inline-block;"><option value="-1">—</option></select><button type="button" class="btn btn-default btn-sm" id="DMA_buffApplyAllBtn" style="margin-left:4px;">Set</button><button type="button" class="btn btn-default btn-sm" id="DMA_buffSelectUnbuffed" style="margin-left:4px;">Select unbuffed</button></div>'
            + '<div id="DMA_buffSummary" style="max-height:180px;overflow-y:auto;"></div>'
            + '<div id="DMA_buffList"></div>'
            + '</div>';
        $(DMA_BODY).html(html);
        $(DMA_MODAL + " .modal-footer").html(
            '<button type="button" class="btn btn-default btn-sm" id="DMA_buffBack">Back</button>'
          + '<button type="button" class="btn btn-primary btn-sm" id="DMA_buffSuggest">Suggest</button>'
          + '<button type="button" class="btn btn-default btn-sm" id="DMA_buffCurrent">Take current</button>'
          + '<button type="button" class="btn btn-success btn-sm" id="DMA_buffApply">Apply</button>'
          + '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>'
        );
        $(DMA_MODAL).off("click.buffback").on("click.buffback", "#DMA_buffBack", function (e) {
            e.preventDefault();
            e.stopPropagation();
            DMA_closeGeo();   // 0.1.68: DMA_render did not exist; Back threw and left the buff page in place
            return false;
        });
        $(DMA_MODAL).off("click.buffcurrent").on("click.buffcurrent", "#DMA_buffCurrent", function () {
            DMA_buffTakeCurrent();
        });
        $(DMA_MODAL).off("click.buffapply").on("click.buffapply", "#DMA_buffApply", function () {
            DMA_buffApply();
        });
        DMA_buffLoad();
        return true;
    }
    /* 0.1.40: the event's buildings and green's buff options, per event type (ADR 0029) — shown on the EVENT page */
    function DMA_evExcluded(type) {
        var x = DMA_pol("event." + type + ".buff.exclude", null);
        return Array.isArray(x) ? x.slice() : [];
    }
    function DMA_evBuffBlock(type, unit) {
        var G = root.DMA_Green, plan = [];
        try { plan = (G && G.eventPlan) ? G.eventPlan().filter(function (b) { return b.event === type; }) : []; } catch (_) { plan = []; }
        var ex = DMA_evExcluded(type);
        var h = '<label style="font-weight:normal;color:#ccc;margin-right:12px;"><input type="checkbox" class="dma-ev-rule" data-rule="event.' + DMA_esc(type) + '.buff.on" data-type="bool"' + (DMA_pol("event." + type + ".buff.on", false) === true ? " checked" : "") + '> buff its buildings (the event manager orders the buffer; green picks the buff)</label>';
        if (!plan.length) return h + '<div style="color:#999;font-size:11px;">No building of this event in the last island scan.</div>';
        h += '<table class="table table-condensed" style="font-size:11px;margin:4px 0;color:#ccc;"><thead><tr><th>Building</th><th>Grid</th><th>Buffed</th><th>Options (green: extra ' + DMA_esc(unit || "output") + ')</th></tr></thead><tbody>';
        plan.forEach(function (b) {
            var opts = (b.options || []).map(function (o, k) {
                return (k === 0 ? '<b>' : '') + DMA_esc(o.buff) + ' +' + o.extra + ' (' + o.percent + '%, ' + o.hours + ' h, ' + o.available + ' in stock' + (o.target ? ', target ' + DMA_esc(o.target) : '') + ')' + (k === 0 ? '</b>' : '')
                     + ' <a href="#" class="DMA_evEx" data-evtype="' + DMA_esc(type) + '" data-buff="' + DMA_esc(o.def) + '">exclude</a>';
            }).join('<br>');
            h += '<tr><td>' + DMA_esc(b.label) + '</td><td>' + DMA_esc(String(b.grid)) + '</td><td>' + (b.buffed ? DMA_lamp("#00ff44", "buffed") : DMA_lamp("#555555", "not buffed")) + '</td><td>' + (opts || '<span style="color:#999;">no buff in stock for it</span>') + '</td></tr>';
        });
        h += '</tbody></table>';
        if (ex.length) h += '<div style="font-size:11px;color:#ccc;">Not to use: ' + ex.map(function (e) { return DMA_esc(e) + ' <a href="#" class="DMA_evIn" data-evtype="' + DMA_esc(type) + '" data-buff="' + DMA_esc(e) + '">allow</a>'; }).join(', ') + '</div>';
        return h;
    }
    var DMA_buffData = { buildings: [], groups: [] };
    function DMA_buffLoad() {
        DMA_buffData.buildings = [];
        DMA_buffData.groups = [];
        DMA_buffData.types = {};
        try {
            var menu = game.gi.mCurrentPlayer.getBuffsSortedForStarMenu() || [];
            var groups = {};
            menu.forEach(function (buff) {
                if (!buff || buff.IsExhausted) return;
                var def = buff.GetBuffDefinition && buff.GetBuffDefinition();
                if (!def) return;
                try { if (def.GetBuffType() !== 0) return; } catch (_) { return; }
                try { if (def.GetTargetType() !== 0) return; } catch (_) { return; }
                var nm = def.GetName_string && def.GetName_string();
                if (!nm || nm.indexOf("Area") >= 0) return;
                var loc = "";
                try { loc = loca.GetText("RES", nm) || nm; } catch (_) { loc = nm; }
                var icon = null;
                try { icon = buff.GetBuffIconData && buff.GetBuffIconData(); } catch (_) {}
                var percent = 0, duration = 0;
                try { percent = def.getProductivityOutputPercent && def.getProductivityOutputPercent() || 0; } catch (_) {}
                try { duration = def.getDuration && def.getDuration(0) || 0; } catch (_) {}
                if (!groups[nm]) groups[nm] = { name: loc, stacks: [], available: 0, icon: icon, percent: percent, duration: duration };
                groups[nm].stacks.push(buff);
                groups[nm].available += (buff.GetAmount && buff.GetAmount()) || 1;
            });
            DMA_buffData.groups = Object.keys(groups).map(function (k) { return groups[k]; })
                .sort(function (a, b) { return ((b.percent || 0) * (b.duration || 1)) - ((a.percent || 0) * (a.duration || 1)) || a.name.localeCompare(b.name); });
        } catch (_) {}
        try {
            var sd = game.gi.mCurrentPlayerZone.mStreetDataMap;
            var bldVec = sd.GetBuildings_vector && sd.GetBuildings_vector();
            if (bldVec && typeof bldVec.forEach === "function") {
                bldVec.forEach(function (b) {
                    if (!b) return;
                    var nm = "";
                    try { nm = b.GetBuildingName_string && b.GetBuildingName_string(); } catch (_) {}
                    if (!nm) return;
                    var grid = null;
                    try { grid = b.GetGrid && b.GetGrid(); } catch (_) {}
                    var level = 1;
                    try { level = b.GetUpgradeLevel && b.GetUpgradeLevel() || 1; } catch (_) {}
                    var locName = nm;
                    try { locName = loca.GetText("BUI", nm) || nm; } catch (_) {}
                    DMA_buffData.buildings.push({
                        grid: grid,
                        name: nm,
                        locName: locName,
                        level: level,
                        choice: -1,
                        type: nm
                    });
                    DMA_buffData.types[nm] = (DMA_buffData.types[nm] || 0) + 1;
                });
            }
        } catch (_) {}
        var prefs = (root.DMA_Demo && root.DMA_Demo.getBuffPrefs && root.DMA_Demo.getBuffPrefs()) || {};
        DMA_log("buff prefs loaded " + Object.keys(prefs).length);
        DMA_buffData.buildings.forEach(function (b) {
            var pref = prefs[b.name];
            if (pref) {
                var buffName = (typeof pref === "object") ? pref.buff : pref;
                for (var i = 0; i < DMA_buffData.groups.length; i++) {
                    if (DMA_buffData.groups[i].name === buffName) { b.choice = i; break; }
                }
            }
        });
        DMA_buffRender();
        var $aa = $("#DMA_buffApplyAll").empty().append('<option value="-1">—</option>');
        DMA_buffData.groups.map(function (g, i) { return { i: i, name: g.name, avail: g.available }; })
            .sort(function (a, b) { return a.name.localeCompare(b.name); })
            .forEach(function (g) {
                $aa.append('<option value="' + g.i + '">' + DMA_esc(g.name) + ' (' + g.avail + ')</option>');
            });
        $("#DMA_buffFilter").off("input.bufffilter").on("input.bufffilter", function () { DMA_buffRender(); });
        $("#DMA_buffCat").off("change.buffcat").on("change.buffcat", function () { DMA_buffRender(); });
        $("#DMA_buffSelectUnbuffed").off("click.buffunbuffed").on("click.buffunbuffed", function () {
            var filter = ($("#DMA_buffFilter").val() || "").toLowerCase();
            var cat = ($("#DMA_buffCat").val() || "").toLowerCase();
            DMA_buffData.buildings.forEach(function (b) {
                if (filter && (b.locName || b.name).toLowerCase().indexOf(filter) < 0) return;
                if (cat && (b.name || "").toLowerCase().indexOf(cat) < 0) return;
                var isBuffed = false;
                try {
                    var bld = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(b.grid));
                    isBuffed = bld && bld.productionBuff != null;
                } catch (_) {}
                if (!isBuffed && b.choice < 0) b.choice = 0;
            });
            DMA_buffRender();
        });
        $("#DMA_buffApplyAllBtn").off("click.buffapplyall").on("click.buffapplyall", function () {
            var idx = Number($("#DMA_buffApplyAll").val());
            if (idx < 0) return;
            var filter = ($("#DMA_buffFilter").val() || "").toLowerCase();
            var grp = DMA_buffData.groups[idx];
            if (!grp) return;
            var prefs = {};
            try { prefs = JSON.parse(JSON.stringify((root.DMA_Demo && root.DMA_Demo.getBuffPrefs && root.DMA_Demo.getBuffPrefs()) || {})); } catch (_) {}
            DMA_buffData.buildings.forEach(function (b) {
                if (!filter || (b.locName || b.name).toLowerCase().indexOf(filter) >= 0) {
                    b.choice = idx;
                    if (root.DMA_Demo && root.DMA_Demo.setBuffPref) root.DMA_Demo.setBuffPref(b.name, grp.name, 0);
                }
            });
            DMA_log("buff prefs saved via green");
            DMA_buffRender();
        });
    }
    function DMA_buffRender() {
        var g = DMA_buffData.groups;
        var filter = ($("#DMA_buffFilter").val() || "").toLowerCase();
        var cat = ($("#DMA_buffCat").val() || "").toLowerCase();
        var b = DMA_buffData.buildings.filter(function (x) {
            if (filter && (x.locName || x.name).toLowerCase().indexOf(filter) < 0) return false;
            if (cat && (x.name || "").toLowerCase().indexOf(cat) < 0) return false;
            return true;
        }).sort(function (a, b) { return (a.locName || a.name).localeCompare(b.locName || b.name); });
        var assigned = {};
        b.forEach(function (bld) { if (bld.choice >= 0) assigned[bld.choice] = (assigned[bld.choice] || 0) + 1; });
        var sum = '<h5 style="margin:0 0 4px;color:#ddd;">Buffs</h5><table class="table table-condensed" style="font-size:11px;margin:0;color:#ccc;table-layout:fixed;width:100%;"><thead><tr style="background:rgb(178,165,137);"><th style="width:40%;color:#333;">Buff</th><th style="width:15%;color:#333;">Bonus</th><th style="width:15%;color:#333;">Duration</th><th style="width:15%;color:#333;">Avail</th><th style="width:15%;color:#333;">Used</th></tr></thead></table><div style="max-height:140px;overflow-y:auto;"><table class="table table-condensed" style="font-size:11px;margin:0;color:#ccc;table-layout:fixed;width:100%;"><tbody>';
        g.forEach(function (grp, i) {
            var icon = "";
            try { if (grp.icon) icon = getImageByModule(grp.icon[0], grp.icon[1], 20, 20) + "&nbsp;"; } catch (_) {}
            var used = assigned[i] || 0;
            var over = used > grp.available ? "color:#c44;" : "";
            var bg = i % 2 ? "background:rgb(89,82,65);" : "background:rgb(77,71,55);";
            sum += "<tr style=\"" + bg + over + "\"><td style=\"width:40%;\">" + icon + DMA_esc(grp.name) + "</td><td style=\"width:15%;\">" + (grp.percent ? "+" + grp.percent + "%" : "—") + "</td><td style=\"width:15%;\">" + (grp.duration ? Math.round(grp.duration / 3600000) + "h" : "—") + "</td><td style=\"width:15%;\">" + grp.available + "</td><td style=\"width:15%;\">" + used + "</td></tr>";
        });
        sum += "</tbody></table></div>";
        $("#DMA_buffSummary").html(sum);
        var selected = b.filter(function (x) { return x.choice >= 0; }).length;
        var status = b.length + " unbuffed, " + selected + " selected.";
        $("#DMA_buffList").html("<p style=\"margin:4px 0;color:#ccc;\">" + status + "</p>");
        var list = '<table class="table table-condensed" style="font-size:12px;margin:0;color:#ccc;table-layout:fixed;width:100%;"><thead><tr style="background:rgb(178,165,137);"><th style="width:50%;color:#333;">Building</th><th style="width:15%;color:#333;">Level</th><th style="width:35%;color:#333;">Buff</th></tr></thead></table>'
            + '<div style="max-height:280px;overflow-y:auto;"><table class="table table-condensed" style="font-size:12px;margin:0;color:#ccc;table-layout:fixed;width:100%;"><tbody>';
        b.forEach(function (bld, i) {
            var icon = "";
            try { icon = getImageTag(bld.name, "24px") + "&nbsp;"; } catch (_) {}
            var locName = bld.locName || bld.name;
            try { if (!bld.locName) locName = loca.GetText("BUI", bld.name) || bld.name; } catch (_) {}
            var opts = '<option value="-1">—</option>';
            g.forEach(function (grp, gi) {
                opts += '<option value="' + gi + '"' + (bld.choice === gi ? " selected" : "") + ">" + DMA_esc(grp.name) + " (" + grp.available + ")</option>";
            });
            var bg = i % 2 ? "background:rgb(89,82,65);" : "background:rgb(77,71,55);";
            list += "<tr class=\"dma-buff-row\" data-grid=\"" + bld.grid + "\" style=\"" + bg + "\"><td style=\"width:50%;vertical-align:middle;\">" + icon + DMA_esc(locName) + "</td><td style=\"width:15%;vertical-align:middle;\">" + bld.level + "</td><td style=\"width:35%;vertical-align:middle;\"><select class=\"form-control input-sm dma-buff-sel\" data-i=\"" + i + "\">" + opts + "</select></td></tr>";
        });
        list += "</tbody></table></div>";
        $("#DMA_buffList").append(list);
        $("#DMA_buffList").off("change.buffsel").on("change.buffsel", ".dma-buff-sel", function () {
            var i = Number($(this).data("i"));
            DMA_buffData.buildings[i].choice = Number($(this).val());
            DMA_buffRender();
        });
        $("#DMA_buffList").off("mouseenter.buffrow mouseleave.buffrow click.buffrow")
            .on("mouseenter.buffrow", ".dma-buff-row", function () { $(this).css("background", "rgb(96,67,45)"); })
            .on("mouseleave.buffrow", ".dma-buff-row", function () { var i = $(this).index(); $(this).css("background", i % 2 ? "rgb(89,82,65)" : "rgb(77,71,55)"); })
            .on("click.buffrow", ".dma-buff-row", function (e) {
                if ($(e.target).is("select, option")) return;
                var grid = $(this).data("grid");
                if (grid) DMA_goTo(grid);
            });
    }
    function DMA_buffTakeCurrent() {
        var filter = ($("#DMA_buffFilter").val() || "").toLowerCase();
        var prefs = {};
        try { prefs = JSON.parse(JSON.stringify((root.DMA_Demo && root.DMA_Demo.getBuffPrefs && root.DMA_Demo.getBuffPrefs()) || {})); } catch (_) {}
        var taken = 0;
        DMA_buffData.buildings.forEach(function (b) {
            if (filter && b.name.toLowerCase().indexOf(filter) < 0) return;
            var buffName = null;
            try {
                var bld = game.gi.mCurrentPlayerZone.GetBuildingFromGridPosition(Number(b.grid));
                if (bld && bld.productionBuff) {
                    var def = bld.productionBuff.GetBuffDefinition && bld.productionBuff.GetBuffDefinition();
                    if (def) {
                        var nm = def.GetName_string && def.GetName_string();
                        try { buffName = loca.GetText("RES", nm) || nm; } catch (_) { buffName = nm; }
                    }
                }
            } catch (e) { DMA_log("take err " + b.grid + " " + e); }
            if (buffName) {
                for (var i = 0; i < DMA_buffData.groups.length; i++) {
                    if (DMA_buffData.groups[i].name === buffName) {
                        b.choice = i;
                        prefs[b.name] = buffName;
                        taken++;
                        break;
                    }
                }
            }
        });
        Object.keys(prefs).forEach(function (k) {
            try { if (root.DMA_Demo && root.DMA_Demo.setBuffPref) root.DMA_Demo.setBuffPref(k, prefs[k], 0); } catch (_) {}
        });
        DMA_log("buff current taken " + taken + " filter=" + filter);
        DMA_buffRender();
    }
    function DMA_buffSuggest() {
        var rainbowOnly = $("#DMA_buffRainbow").is(":checked");
        var filter = ($("#DMA_buffFilter").val() || "").toLowerCase();
        var left = DMA_buffData.groups.map(function (g) { return g.available; });
        var targets = DMA_buffData.buildings.filter(function (x) { return !filter || x.name.toLowerCase().indexOf(filter) >= 0; });
        targets.forEach(function (b) {
            b.choice = -1;
            b.options = [];
            var isEndless = /endless/i.test(b.name);
            DMA_buffData.groups.forEach(function (grp, i) {
                if (rainbowOnly && /rainbow/i.test(grp.name) && !isEndless) return;
                var can = false;
                try {
                    var stack = grp.stacks[0];
                    if (stack) {
                        var r = stack.IsApplyable(game.gi.mCurrentPlayer, game.gi, Number(b.grid));
                        can = r !== null && typeof r === "object";
                    }
                } catch (_) {}
                if (can) b.options.push(i);
            });
        });
        targets.slice().sort(function (a, b) { return b.level - a.level; }).forEach(function (b) {
            for (var i = 0; i < b.options.length; i++) {
                var idx = b.options[i];
                if (left[idx] > 0) { b.choice = idx; left[idx]--; return; }
            }
        });
        DMA_buffRender();
    }
    function DMA_buffApply() {
        var prefs = {};
        try { prefs = JSON.parse(JSON.stringify((root.DMA_Demo && root.DMA_Demo.getBuffPrefs && root.DMA_Demo.getBuffPrefs()) || {})); } catch (_) {}
        var requests = [];
        DMA_buffData.buildings.forEach(function (b) {
            if (b.choice < 0) return;
            var grp = DMA_buffData.groups[b.choice];
            if (!grp) return;
            if (prefs[b.name] !== grp.name) {
                prefs[b.name] = grp.name;
                try { if (root.DMA_Demo && root.DMA_Demo.setBuffPref) root.DMA_Demo.setBuffPref(b.name, grp.name, 0); } catch (_) {}
            }
            requests.push({ grid: b.grid, name: b.name, buff: grp.name });
        });
        try { localStorage.setItem("dma.buffRequests.v1", JSON.stringify(requests)); } catch (_) {}
        DMA_log("buff requests queued " + requests.length);
        DMA_buffRender();
    }
    function DMA_openSpec() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        DMA_injectGeoCss();
        $(DMA_BODY).html(
            '<div id="specTabs" style="margin-bottom:6px;">'
          + '<button type="button" class="btn btn-sm btn-primary" id="specTabGeo" style="background:#3a6ea5;color:#fff;">Geologists</button>'
          + '<button type="button" class="btn btn-sm" id="specTabExp" style="background:#555;color:#ccc;">Explorers</button>'
          + '<button type="button" class="btn btn-sm" id="specTabGen" style="background:#555;color:#ccc;">Generals</button>'
          + '</div>'
          + '<div id="specGame" style="margin-bottom:8px;"></div>'
          + '<div id="specSkillRules" style="margin-bottom:8px;"></div>'   // 0.1.84 (ADR 0058)
          + '<div id="geoSkills"><div class="gs-bar" style="margin-bottom:4px;"><span id="DMA_geoInfo" style="color:#ccc;">idle – · LF free –</span></div></div>'   // 0.1.13: manual skill entry removed
          + '<div id="expSkills" style="display:none;"></div>'
        );
        $(DMA_MODAL + " .modal-footer").html(
            '<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
          + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>'
        );
        $(DMA_MODAL + " .modal-title").text("Specialists");
        $("#specTabGeo").off("click.spectab").on("click.spectab", function () { DMA_specTab("geo"); });
        $("#specTabExp").off("click.spectab").on("click.spectab", function () { DMA_specTab("exp"); });
        $("#specTabGen").off("click.spectab").on("click.spectab", function () { DMA_specTab("gen"); });
        DMA_specTab("geo");
        DMA_log("spec screen");
        return true;
    }
    /* 0.1.12: the skills as the game holds them, per specialist (read only) */
    var DMA_SPEC_KINDNAME = { geo: "geologist", exp: "explorer", gen: "general" };   // 0.1.96: was DMA_SPEC_KIND, which the skilling rules below declare again (an array): "geologist,geo,Geologistss"
    function DMA_skillLabel(n) {
        return String(n || "").replace(/^Skill_/, "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2").replace(/^./, function (c) { return c.toUpperCase(); });
    }
    function DMA_specName(n) { return String(n || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
    /* 0.1.96: the skills of one kind as HTML — pure, so a test can give it the game's own list. stock = { Manuscript: n, Tome: n, Codex: n } from the location manager; books needed by a skill are of the type
       the skill's resource names; the skill a specialist can learn next is the cheapest one that is not at its maximum. */
    function DMA_gameSkillsHtml(tab, all, sel, stock) {
        var kind = DMA_SPEC_KINDNAME[tab], list = (all || []).filter(function (r) { return r.kind === kind && !r.noTree; });
        stock = stock || {};
        if (!list.length) return '<div style="color:#ccc;">Skills from the game: none read yet for ' + DMA_esc(kind) + 's.</div>';
        list.sort(function (a, b) { return DMA_specName(a.name).localeCompare(DMA_specName(b.name)); });
        sel = sel || "all";
        function open(r) { return r.skills.filter(function (x) { return !x.trait && x.level < x.max; }); }
        function nextOf(r) { var o = open(r).sort(function (a, b) { return (a.booksNeeded - b.booksNeeded) || (a.id - b.id); }); return o[0] || null; }
        function bookCell(sk) { if (!sk) return "-"; var have = stock[sk.resource]; var ok = have != null && have >= sk.booksNeeded; return '<span style="color:' + (ok ? "#9c9" : "#f99") + ';">' + sk.booksNeeded + " " + DMA_esc(sk.resource) + (have != null ? " (stock " + have + ")" : " (stock unknown)") + '</span>'; }
        var h = '<div style="color:#ccc;margin-bottom:4px;">Skills from the game · ' + list.length + ' ' + DMA_esc(kind) + 's '
              + '<select id="specGamePick" class="form-control input-sm" style="width:auto;display:inline-block;margin-left:6px;">'
              + '<option value="all">All of this type (' + list.length + ')</option>';
        list.forEach(function (r) { h += '<option value="' + DMA_esc(r.id) + '"' + (sel === r.id ? " selected" : "") + '>' + DMA_esc(DMA_specName(r.name)) + ' · ' + r.points + ' pts</option>'; });
        h += '</select></div>';
        h += '<div style="color:#ccc;margin-bottom:4px;">Books in stock: ' + ["Manuscript", "Tome", "Codex"].map(function (b) { return b + " " + (stock[b] != null ? stock[b] : "?"); }).join(" · ") + '</div>';
        var one = sel !== "all" ? list.filter(function (r) { return r.id === sel; })[0] : null;
        var ref = one || list[0], skills = ref.skills.slice();
        skills.sort(function (a, b) { return (a.booksNeeded - b.booksNeeded) || (a.id - b.id); });
        var colour = { bronze: "#c98a4b", silver: "#c0c0c0", gold: "#e0b84a" };
        h += '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:0;"><tr><th>Skill</th><th>Books needed</th><th>' + (one ? "Level" : "Have it · maxed") + '</th></tr>';
        skills.forEach(function (sk) {
            var cell;
            if (one) cell = sk.level + " / " + sk.max;
            else {
                var have = 0, maxed = 0;
                list.forEach(function (r) { r.skills.forEach(function (x) { if (x.id === sk.id) { if (x.level > 0) have++; if (x.level >= x.max && x.max > 0) maxed++; } }); });
                cell = have + " · " + maxed;
            }
            h += '<tr><td style="color:' + (colour[sk.pointType] || "#ddd") + '">' + DMA_esc(DMA_skillLabel(sk.name)) + '</td><td>' + bookCell(sk) + '</td><td>' + cell + '</td></tr>';
        });
        h += '</table>';
        h += '<div style="margin-top:6px;color:#ccc;"><b>Next skill per ' + DMA_esc(kind) + '</b> (the cheapest one below its maximum)</div><table class="table table-condensed" style="font-size:11px;color:#ddd;margin:0;"><tr><th>' + DMA_esc(kind) + '</th><th>Skill</th><th>Books needed</th></tr>';
        (one ? [one] : list).forEach(function (r) {
            var nx = nextOf(r);
            h += '<tr><td>' + DMA_esc(DMA_specName(r.name)) + '</td><td>' + (nx ? DMA_esc(DMA_skillLabel(nx.name)) + ' ' + nx.level + '/' + nx.max : "fully skilled") + '</td><td>' + bookCell(nx) + '</td></tr>';
        });
        h += '</table>';
        return h;
    }
    function DMA_renderGameSkills(tab) {
        var list = [], stock = {};
        try { if (root.DMA_Control && root.DMA_Control.skillsList) list = root.DMA_Control.skillsList(60000) || []; } catch (_) {}
        try { if (root.DMA_Demo && root.DMA_Demo.stockNow) stock = root.DMA_Demo.stockNow() || {}; } catch (_) {}
        $("#specGame").html(DMA_gameSkillsHtml(tab, list, $("#specGamePick").val() || "all", stock));
        $("#specGamePick").off("change.sg").on("change.sg", function () { DMA_renderGameSkills(tab); });
    }
    /* 0.1.84 (ADR 0058): skilling and naming — the player's settings per type and his choice per specialist */
    var DMA_SPEC_KIND = { geo: ["geologist", "geo", "Geologists"], exp: ["explorer", "expo", "Explorers"], gen: ["general", "gen", "Generals"] };
    function DMA_namePreview(kind, scope, confirmedAt) {           // 0.1.85
        var D = root.DMA_Demo, plan = null; try { if (D && D.namePlan) plan = D.namePlan(kind); } catch (_) {}
        if (!plan) return '';
        if (scope !== "all") return '<span style="color:#888;">' + plan.changes + ' would get a new name now</span><br>';
        var h = '<div style="margin:4px 0;padding:4px;background:#3a2a2a;border-radius:4px;max-height:140px;overflow-y:auto;">'
              + '<b>All ' + plan.rows.length + ' get a new name — own names are lost:</b><br>';
        plan.rows.forEach(function (r) { h += DMA_esc(r.from) + (r.to ? ' → <b>' + DMA_esc(r.to) + '</b>' : ' (stays)') + '<br>'; });
        h += '</div>' + (confirmedAt ? '<span style="color:#9c9;">confirmed ' + DMA_esc(String(confirmedAt).slice(0, 16).replace("T", " ")) + ' UTC — carried out once the rename call is proven</span><br>'
                                     : '<button type="button" class="btn btn-danger btn-sm" id="ssConfirmAll">Confirm: rename all</button><br>');
        return h;
    }
    function DMA_renderSkillRules(tab) {
        var k = DMA_SPEC_KIND[tab]; if (!k || !$("#specSkillRules").length) return;
        var P = policy(), D = root.DMA_Demo, key = k[1];
        function pv(n, d) { try { var v = P && P.get ? P.get("spec." + key + "." + n) : null; return v == null || v === "" ? d : v; } catch (_) { return d; } }
        var skill = pv("skill", "manual"), name = pv("name", "manual"), std = pv("skillStandard", false) === true, pre = pv("prefix", ""), suf = pv("suffix", ""), scope = pv("renameScope", "unnamed");
        var h = '<div style="background:#2a2f38;border-radius:4px;padding:6px;color:#ccc;font-size:11px;">'
              + '<b>Skilling and naming — ' + k[2] + '</b> <span style="color:#888;">(ADR 0058)</span><br>'
              + 'Skilling: <select id="ssSkill" class="input-sm"><option value="manual"' + (skill !== "auto" ? " selected" : "") + '>manual (I skill)</option>'
              + '<option value="auto"' + (skill === "auto" ? " selected" : "") + '>automatic</option></select> '
              + '<label style="font-weight:normal;"><input type="checkbox" id="ssStd"' + (std ? " checked" : "") + '> follow the online standard (settlersonlinewiki.eu)</label><br>'
              + 'Naming: <select id="ssName" class="input-sm"><option value="manual"' + (name !== "auto" ? " selected" : "") + '>manual (my own nickname)</option>'
              + '<option value="auto"' + (name === "auto" ? " selected" : "") + '>automatic</option></select> '
              + 'prefix <input id="ssPre" class="input-sm" style="width:70px;" value="' + DMA_esc(pre) + '"> '
              + 'suffix <input id="ssSuf" class="input-sm" style="width:70px;" value="' + DMA_esc(suf) + '"> '
              + '<span style="color:#888;">+ number (makes the name unique)</span><br>'
              + 'Rename: <select id="ssScope" class="input-sm"><option value="new"' + (scope === "new" ? " selected" : "") + '>new only</option>'
              + '<option value="unnamed"' + (scope !== "new" && scope !== "all" ? " selected" : "") + '>new + those without an own name</option>'
              + '<option value="all"' + (scope === "all" ? " selected" : "") + '>all (also my own names)</option></select><br>'
              + DMA_namePreview(k[0], scope, pv("renameAllConfirmedAt", ""))
              + '<span style="color:#c96;">Automatic skilling with books and automatic naming start once the game calls are proven; until then only the choice below acts.</span>';
        var list = []; try { if (D && D.specialistSkillState) list = D.specialistSkillState(k[0]) || []; } catch (_) {}
        var open = list.filter(function (e) { return !e.full; });
        open.sort(function (a, b) { return (a.points == null) - (b.points == null) || (a.points || 0) - (b.points || 0) || String(a.name).localeCompare(String(b.name)); });
        h += '<div style="margin-top:6px;"><b>Not fully skilled (' + open.length + ' of ' + list.length + ')</b> — checked again before every use<br>';
        if (!list.length) h += '<span style="color:#888;">no ' + k[0] + 's read</span>';
        else if (!open.length) h += 'none: every ' + k[0] + ' is fully skilled';
        open.forEach(function (e) {
            h += '<div class="ss-row" data-id="' + DMA_esc(e.id) + '">' + DMA_esc(e.name) + ' · ' + (e.points == null ? "skills unknown" : e.points + " / " + e.max) + ' · '
               + '<select class="ssUse input-sm"><option value="use"' + (e.mode !== "first" ? " selected" : "") + '>use until the books are there</option>'
               + '<option value="first"' + (e.mode === "first" ? " selected" : "") + '>skill first</option></select> '
               + (e.held ? '<span style="color:#f99;">waiting for skilling</span>' : '<span style="color:#9c9;">used meanwhile</span>') + '</div>';
        });
        h += '</div></div>';
        $("#specSkillRules").html(h);
        function set(n, v) { try { if (P && P.requestChange) P.requestChange("spec." + key + "." + n, v); } catch (_) {} }
        $("#ssSkill").off("change").on("change", function () { set("skill", $(this).val()); });
        $("#ssStd").off("change").on("change", function () { set("skillStandard", !!$(this).prop("checked")); });
        $("#ssName").off("change").on("change", function () { set("name", $(this).val()); });
        $("#ssPre").off("change").on("change", function () { set("prefix", String($(this).val() || "")); });
        $("#ssSuf").off("change").on("change", function () { set("suffix", String($(this).val() || "")); DMA_renderSkillRules(tab); });
        $("#ssPre").off("change.pv").on("change.pv", function () { DMA_renderSkillRules(tab); });
        $("#ssScope").off("change").on("change", function () { set("renameScope", $(this).val()); set("renameAllConfirmedAt", ""); DMA_renderSkillRules(tab); });
        $("#ssConfirmAll").off("click").on("click", function () { set("renameAllConfirmedAt", new Date().toISOString()); DMA_log("rename all confirmed: " + key); DMA_renderSkillRules(tab); });
        $("#specSkillRules .ssUse").off("change").on("change", function () {
            var id = $(this).closest(".ss-row").attr("data-id"), v = $(this).val();
            try { if (D && D.setUseMode) D.setUseMode(id, v); } catch (_) {}
            DMA_log("spec use " + id + " = " + v);
            DMA_renderSkillRules(tab);
        });
    }
    function DMA_specTab(tab) {
        $("#specTabGen").css({"background": tab === "gen" ? "#3a6ea5" : "#555", "color": tab === "gen" ? "#fff" : "#ccc"});
        $("#specGamePick").remove();
        DMA_renderGameSkills(tab);                                   // 0.1.12
        DMA_renderSkillRules(tab);                                   // 0.1.84
        if (tab === "gen") {
            $("#specTabGeo, #specTabExp").css({"background": "#555", "color": "#ccc"});
            $("#geoSkills, #expSkills").hide();
            $("#gsApply, #gsReset").hide();
            DMA_log("spec tab gen");
            return;
        }
        if (tab === "geo") {
            $("#specTabGeo").css({"background": "#3a6ea5", "color": "#fff"});
            $("#specTabExp").css({"background": "#555", "color": "#ccc"});
            $("#geoSkills").show();
            $("#expSkills").hide();
            $("#DMA_geoInfo").text("idle – · LF free –");
            $("#gsApply, #gsReset").show();
            DMA_log("spec tab geo");
        } else {
            $("#specTabExp").css({"background": "#3a6ea5", "color": "#fff"});
            $("#specTabGeo").css({"background": "#555", "color": "#ccc"});
            $("#geoSkills").hide();
            $("#expSkills").show();
            $("#DMA_geoInfo").text("idle – · event –");
            $("#gsApply, #gsReset").hide();
            DMA_renderExpPrefs();
            DMA_log("spec tab exp");
        }
    }
    function DMA_renderExpPrefs() {
        var prefs = (root.DMA_Demo && root.DMA_Demo.getSpecPrefs && root.DMA_Demo.getSpecPrefs()) || {};
        var templates = DMA_EXP_TEMPLATES || {};
        var h = '<div style="margin:6px 0;color:#ccc;">';
        h += '<label style="margin-right:8px;">Template:</label>';
        h += '<select id="expTemplate" class="form-control input-sm" style="width:auto;display:inline-block;margin-right:8px;">';
        Object.keys(templates).forEach(function (t) { h += '<option value="' + t + '">' + t + '</option>'; });
        h += '</select>';
        h += '<button type="button" class="btn btn-primary btn-sm" id="expApplyTpl">Apply</button> ';
        h += '<button type="button" class="btn btn-default btn-sm" id="expSaveTpl">Save as</button>';
        h += '</div>';
        h += '<div style="margin:6px 0;color:#ccc;">';
        h += '<label style="margin-right:8px;">Type:</label>';
        h += '<select id="expType" class="form-control input-sm" style="width:auto;display:inline-block;margin-right:8px;">';
        Object.keys(DMA_EXP_TYPES).forEach(function (t) { h += '<option value="' + t + '">' + t + '</option>'; });
        h += '</select>';
        h += '<label style="margin-right:8px;">Search:</label>';
        h += '<select id="expSearch" class="form-control input-sm" style="width:auto;display:inline-block;margin-right:8px;">';
        h += '<option value="short">Short</option><option value="medium">Medium</option><option value="long">Long</option>';
        h += '<option value="veryLong">Very Long</option><option value="prolonged">Prolonged (longest)</option>'
           + '<option value="erudite">Artefacts (Travelling Erudite)</option><option value="bean">Rarity (Bean a Collada)</option>'
           + '<option value="advShort">Adventure short</option><option value="advMedium">Adventure medium</option>'
           + '<option value="advLong">Adventure long</option><option value="advVeryLong">Adventure very long</option>';   // 0.1.86
        h += '</select>';
        h += '<button type="button" class="btn btn-default btn-sm" id="expSetType">Set for type</button>';
        h += '</div>';
        h += '<div id="expHeld" style="font-size:11px;color:#f99;margin:8px 0;padding:6px;background:#3a2a2a;border-radius:4px;max-height:160px;overflow-y:auto;"></div>';   // 0.1.34
        h += '<div id="expList" style="font-size:11px;color:#ccc;margin:8px 0;padding:6px;background:#2a2a2a;border-radius:4px;max-height:200px;overflow-y:auto;"></div>';
        h += '<div id="expActive" style="font-size:11px;color:#8f8;margin:4px 0;padding:6px;background:#333;border-radius:4px;"></div>';
        $("#expSkills").html(h);
        $("#expApplyTpl").off("click.exp").on("click.exp", function () {
            try {
                var tpl = $("#expTemplate").val();
                DMA_log("apply click tpl=" + tpl);
                var settings = DMA_EXP_TEMPLATES[tpl];
                if (!settings) { DMA_log("no settings for " + tpl); return; }
                DMA_log("settings keys " + Object.keys(settings).join(","));
                if (!root.DMA_Demo || !root.DMA_Demo.setSpecPref) { DMA_log("no DMA_Demo"); return; }
                Object.keys(settings).forEach(function (k) { if (k !== "*") root.DMA_Demo.setSpecPref(k, settings[k]); });
                try { var pT = policy(); if (pT && pT.requestChange) pT.requestChange("expo.template", tpl); } catch (_) {}   // 0.1.33
                DMA_log("template applied " + tpl);
                DMA_renderExpPrefs();
            } catch (e) { DMA_log("apply err " + e); }
        });
        $("#expSetType").off("click.exp").on("click.exp", function () {
            var type = $("#expType").val();
            var search = $("#expSearch").val();
            if (root.DMA_Demo && root.DMA_Demo.setSpecPref) {
                root.DMA_Demo.setSpecPref(type, search);
                DMA_log("set " + type + " = " + search);
                DMA_renderExpPrefs();
            }
        });
        var active = "<b>Active:</b> ";
        Object.keys(prefs).forEach(function (k) { active += k + "=" + prefs[k] + " · "; });
        $("#expActive").html(active || "No preferences set");
        DMA_renderExpList();
    }
    function DMA_renderExpHeld() {                                   // 0.1.34
        var st = [];
        try { if (root.DMA_Demo && root.DMA_Demo.explorerSkillState) st = root.DMA_Demo.explorerSkillState() || []; } catch (_) {}
        var held = st.filter(function (e) { return !e.full; });
        held.sort(function (a, b) { return (a.points == null) - (b.points == null) || (a.points || 0) - (b.points || 0) || a.name.localeCompare(b.name); });
        var h = '<b>Not fully skilled (' + held.length + ' of ' + st.length + ') — see Skilling and naming above:</b><br>';   // 0.1.84: they are sent unless set to "skill first"
        if (!st.length) h += 'Skills not read yet.';
        else if (!held.length) h += 'None: every explorer is fully skilled.';
        held.forEach(function (e) { h += '✗ ' + DMA_esc(e.name) + ' · ' + DMA_esc(e.points == null ? "skills unknown" : e.points + " / " + e.max + " points") + '<br>'; });
        $("#expHeld").html(h);
        var map = {}; held.forEach(function (e) { map[e.name] = (map[e.name] || 0) + 1; });
        return map;
    }
    function DMA_renderExpList() {
        var heldByName = DMA_renderExpHeld();                       // 0.1.34
        var list = "<b>Explorers:</b><br>";
        var count = 0;
        try {
            var specs = game.getSpecialists && game.getSpecialists();
            if (specs && specs.length) {
                specs.forEach(function (s) {
                    if (!s) return;
                    var baseType = 0;
                    try { baseType = s.GetBaseType && s.GetBaseType(); } catch (_) {}
                    if (baseType != 1) return;
                    var name = "";
                    try { if (s.getName) name = s.getName(false) || s.getName(true) || ""; } catch (_) {}
                    if (!name) try { if (s.GetTypeName) name = s.GetTypeName(); } catch (_) {}
                    if (!name) name = "Explorer";
                    var idle = true;
                    try { idle = s.GetTask && s.GetTask() == null; } catch (_) {}
                    var clean = String(name).replace(/<[^>]*>/g, "").trim();
                    var isHeld = heldByName[clean] > 0; if (isHeld) heldByName[clean] -= 1;   // 0.1.34
                    list += (isHeld ? "✗ " : (idle ? "✓ " : "○ ")) + name + "<br>";
                    count++;
                });
            }
        } catch (e) { list += "Error: " + e; }
        if (!count) list += "No explorers found";
        $("#expList").html(list);
    }
    var DMA_EXP_SKILLS = [
        { key: "0-0", label: "Bean-A-Colada", tier: 5, max: 1 },
        { key: "0-1", label: "Travelling Erudite", tier: 5, max: 1 },
        { key: "0-2", label: "Streetwise Negotiator", tier: 5, max: 1 },
        { key: "0-3", label: "Sophisticated Pillager", tier: 5, max: 1 },
        { key: "1-0", label: "Pathfinder", tier: 4, max: 3, time: { all: [5, 10, 15] } },
        { key: "1-1", label: "Sabbatical", tier: 4, max: 3, time: { veryLong: [5, 10, 15] } },
        { key: "1-2", label: "Trouble-seeker", tier: 4, max: 3 },
        { key: "1-3", label: "Hero Ore", tier: 4, max: 3 },
        { key: "2-0", label: "Travel Expenses", tier: 3, max: 3 },
        { key: "2-1", label: "Mistwalker", tier: 3, max: 3 },
        { key: "2-2", label: "Sturdy Shovel", tier: 3, max: 3 },
        { key: "2-3", label: "Loot Wagon", tier: 3, max: 3 },
        { key: "3-0", label: "Extended Weekend", tier: 2, max: 3, time: { medium: [5, 10, 15] } },
        { key: "3-1", label: "Wild Determination", tier: 2, max: 3 },
        { key: "3-2", label: "Offbeat Roads", tier: 2, max: 3 },
        { key: "3-3", label: "Deforestation", tier: 2, max: 3 },
        { key: "4-0", label: "Mountain Boots", tier: 1, max: 3, time: { treasure: [3, 6, 9] } },
        { key: "4-1", label: "Pilgrimage", tier: 1, max: 3, time: { long: [5, 10, 15] } },
        { key: "4-2", label: "Lucky Detour", tier: 1, max: 3 },
        { key: "4-3", label: "Fearless Hiker", tier: 1, max: 3, time: { adventure: [5, 10, 15] } }
    ];
    var DMA_EXP_TEMPLATES = {
        "Daily": {
            "Romantic Explorer": "long",
            "Humble Explorer": "short",
            "Blacktree Explorer": "long",
            "Lucky Explorer": "advShort",
            "Savage Scout": "medium",
            "Explorer": "advShort"
        },
        "Event": { "*": "short", "Romantic Explorer": "long", "Blacktree Explorer": "long", "Benevolent Explorer": "veryLong" },   // 0.1.43: ADR 0025 (was "*": "prolonged", which overrode agents 0.4.14)
        "Best": { "*": "short",
            "Intrepid Explorer": "advVeryLong", "Keener Explorer": "advVeryLong", "Adventurous Explorer": "advShort", "Royal Explorer": "advShort",
            "Love Struck Explorer": "advShort", "Princess Zoe": "advShort", "Bold Explorer": "advShort", "Nora the Explorer": "advVeryLong",
            "Explorer": "advShort", "Experienced Explorer": "advShort", "Savage Scout": "advShort",
            "Candid Explorer": "prolonged", "Emphatic Explorer": "prolonged", "Courageous Explorer": "veryLong", "Bewitching Explorer": "veryLong",
            "Lovely Explorer": "veryLong", "Pirate Explorer": "veryLong", "Humble Explorer": "medium", "Romantic Explorer": "long", "Scared Explorer": "short",
            "Snowy Explorer": "erudite", "Motherly Explorer": "erudite", "Lucky Explorer": "erudite",
            "Benevolent Explorer": "prolonged", "Blacktree Explorer": "long", "Chummy Explorer": "veryLong", "Ghost Explorer": "short",
            "Fluffy Butte Explorer": "short", "Rina the Explorer": "short" },   // 0.1.86 (agents 0.4.23)
        "Adventure": {
            "Romantic Explorer": "short",
            "Lucky Explorer": "advShort",
            "Savage Scout": "short",
            "Explorer": "short"
        }
    };
    var DMA_EXP_TYPES = {
        "Explorer": { speed: 1 },
        "Savage Scout": { speed: 2 },
        "Experienced Explorer": { speed: 2 },
        "Lucky Explorer": { speed: 3 },
        "Romantic Explorer": { speed: 0.5, longMod: 12 },
        "Blacktree Explorer": { speed: 1 },
        "Courageous Explorer": { speed: 2 },
        "Candid Explorer": { speed: 1 }
    };
    var DMA_geoType = "";
    var DMA_KNOWN_TYPES = [
        "Geologist", "Jolly Geologist", "Sophisticated Geologist", "Conscientious Geologist",
        "Versed Geologist", "Thorough Geologist", "Mummified Geologist", "Iron-Willed Geologist",
        "Stone Cold Geologist", "Sooty Geologist", "Gold-Hearted Geologist", "Charming Geologist",
        "Chummy Geologist", "Archeological Geologist", "Gingerbread Geologist", "Diligent Geologist",
        "Geologist on Vacation", "Balanced Geologist", "Marathon Geologist", "Vesy, the Clueless Digger",
        "Stargazing Geologist", "Titanic Geologist", "Alchemical Geologist", "Tendentious Geologist"
    ];
    function DMA_geoTypes() {
        var seen = {}, out = [], i, t;
        for (i = 0; i < DMA_KNOWN_TYPES.length; i++) {
            t = DMA_KNOWN_TYPES[i];
            if (!seen[t]) { seen[t] = 1; out.push(t); }
        }
        for (i = 0; i < DMA_geoAll.length; i++) {
            t = DMA_geoAll[i].type || "Geologist";
            if (!seen[t]) { seen[t] = 1; out.push(t); }
        }
        out.sort();
        return out;
    }
    function DMA_geoOfType(type) {
        var out = [], i;
        for (i = 0; i < DMA_geoAll.length; i++) {
            if ((DMA_geoAll[i].type || "Geologist") === type) out.push(DMA_geoAll[i]);
        }
        return out;
    }
    function DMA_typeIcon(name) {
        var map = (typeof DMA_GEO_TYPE_ICONS !== "undefined") ? DMA_GEO_TYPE_ICONS : {};
        return map[name] || "";
    }
    function DMA_setTypeBtn(name) {
        var src = DMA_typeIcon(name);
        $("#gsTypeName").text(name || "Type");
        if (src) $("#gsTypeIco").attr("src", src).show();
        else $("#gsTypeIco").hide();
    }
    function DMA_fillTypeList() {
        var types = DMA_geoTypes();
        var h = "", i, t, src;
        for (i = 0; i < types.length; i++) {
            t = types[i];
            src = DMA_typeIcon(t);
            h += '<div class="gs-typeitem" data-type="' + DMA_esc(t) + '">';
            if (src) h += '<img class="gs-typeico" src="' + src + '" alt="">';
            h += '<span>' + DMA_esc(t) + '</span></div>';
        }
        $("#gsTypeList").html(h);
        DMA_setTypeBtn(DMA_geoType);
    }
    function DMA_fillGeoSelect(type) {
        var list = DMA_geoOfType(type);
        var h = '<option value="*">All of this type (' + list.length + ')</option>';
        var i, g;
        for (i = 0; i < list.length; i++) {
            g = list[i];
            h += '<option value="' + DMA_esc(g.id) + '">' + DMA_esc(g.nick) + ' · ' + DMA_esc(g.type) + '</option>';
        }
        $("#gsGeo").html(h).val("*").trigger("change");
    }
    function DMA_geoInit() {
        if (typeof GeoSkills === "undefined") { DMA_log("GeoSkills not loaded"); return; }
        var ctrl = root.DMA_Control;
        var list = (ctrl && ctrl.geologists) ? ctrl.geologists() : [];
        DMA_geoAll = [];
        var i, g;
        for (i = 0; i < list.length; i++) {
            g = list[i];
            DMA_geoAll.push({ id: g.id, nick: g.name || "—", type: g.typeName || "Geologist" });
            if (g.typeDump) DMA_log("geo " + g.typeDump);
        }
        DMA_log("geos " + DMA_geoAll.length + " types " + DMA_geoTypes().join(", "));
        var types = DMA_geoTypes();
        DMA_geoType = types[0] || "";
        DMA_fillTypeList();
        DMA_fillGeoSelect(DMA_geoType);
        var saved = {};
        try { saved = JSON.parse(localStorage.getItem("iso:dma.geoSkills.v1") || "{}"); } catch (_) {}
        GeoSkills.init({
            root: "#geoSkills",
            geos: DMA_geoOfType(DMA_geoType),
            values: saved.values || {},
            icons: (typeof DMA_GEO_ICONS !== "undefined") ? DMA_GEO_ICONS : {},
            onChange: function (s) { DMA_geoSave(s); }
        });
        DMA_fillGeoSelect(DMA_geoType);
        $("#gsTypeBtn").off("click.gst").on("click.gst", function (e) {
            e.stopPropagation();
            $("#gsTypeList").toggle();
        });
        $("#gsTypeList").off("click.gst").on("click.gst", ".gs-typeitem", function () {
            DMA_geoType = $(this).attr("data-type");
            DMA_setTypeBtn(DMA_geoType);
            $("#gsTypeList").hide();
            if (GeoSkills.setGeos) GeoSkills.setGeos(DMA_geoOfType(DMA_geoType));
            DMA_fillGeoSelect(DMA_geoType);
        });
        $(document).off("click.gstclose").on("click.gstclose", function () { $("#gsTypeList").hide(); });
        $("#gsApply").off("click.gsap").on("click.gsap", function () { DMA_applyBuild(); });
        $("#gsReset").off("click.gsall").on("click.gsall", function () { DMA_resetAllOfType(); });
        try { GeoSkills.fit(); } catch (_) {}
    }
    function DMA_resetAllOfType() {
        if ($("#gsGeo").val() !== "*") return;
        var st = GeoSkills.getState();
        var values = st.values || {};
        var list = DMA_geoOfType(DMA_geoType);
        var i;
        values["*"] = {};
        values["type:" + DMA_geoType] = {};
        for (i = 0; i < list.length; i++) values[list[i].id] = {};
        try {
            var cur = {};
            try { cur = JSON.parse(localStorage.getItem("iso:dma.geoSkills.v1") || "{}"); } catch (_) {}
            cur.values = cur.values || {};
            cur.values["type:" + DMA_geoType] = {};
            for (i = 0; i < list.length; i++) cur.values[list[i].id] = {};
            localStorage.setItem("iso:dma.geoSkills.v1", JSON.stringify(cur));
        } catch (_) {}
        DMA_log("reset all " + DMA_geoType + " (" + list.length + ")");
    }
    function DMA_applyBuild() {
        var builds = (typeof DMA_GEO_BUILDS !== "undefined") ? DMA_GEO_BUILDS : {};
        var b = builds[DMA_geoType];
        if (!b) { DMA_log("no recommended build for " + DMA_geoType); return; }
        var list = DMA_geoOfType(DMA_geoType);
        var st = GeoSkills.getState();
        var values = st.values || {};
        var pick = $("#gsGeo").val();
        var fresh = {};
        var k;
        for (k in b.values) { if (b.values.hasOwnProperty(k)) fresh[k] = b.values[k]; }
        var targets = (pick === "*") ? list : $.grep(list, function (g) { return g.id === st.geoId; });
        var i;
        for (i = 0; i < targets.length; i++) values[targets[i].id] = fresh;
        if (pick === "*") values["type:" + DMA_geoType] = fresh;
        GeoSkills.init({
            root: "#geoSkills",
            geos: list,
            geoId: pick === "*" ? "*" : st.geoId,
            values: values,
            icons: (typeof DMA_GEO_ICONS !== "undefined") ? DMA_GEO_ICONS : {},
            onChange: function (s) { DMA_geoSave(s); }
        });
        DMA_fillGeoSelect(DMA_geoType);
        if (pick !== "*") $("#gsGeo").val(pick).trigger("change");
        DMA_geoSave({ geoId: pick === "*" ? "*" : st.geoId, values: fresh });
        DMA_log("applied " + DMA_geoType + " to " + targets.length + " geo" + (targets.length === 1 ? "" : "s") + " (" + (b.focus || "recommended") + ")");
    }
    function DMA_geoSave(s) {
        try {
            var cur = {};
            try { cur = JSON.parse(localStorage.getItem("iso:dma.geoSkills.v1") || "{}"); } catch (_) {}
            cur.values = cur.values || {};
            var pick = $("#gsGeo").val();
            if (pick === "*") {
                var list = DMA_geoOfType(DMA_geoType);
                var i, copy = {};
                var k;
                for (k in s.values) { if (s.values.hasOwnProperty(k)) copy[k] = s.values[k]; }
                for (i = 0; i < list.length; i++) cur.values[list[i].id] = copy;
                cur.values["type:" + DMA_geoType] = copy;
            } else if (s.geoId && s.geoId !== "*") {
                cur.values[s.geoId] = s.values;
            }
            localStorage.setItem("iso:dma.geoSkills.v1", JSON.stringify(cur));
        } catch (_) {}
    }
    function DMA_injectGeoCss() {
        if ($("#geoSkillsCss").length) return;
        $("head").append(
            '<style id="geoSkillsCss">'
          + '#geoSkills{font-size:11px;color:#222}'
          + '#geoSkills .gs-bar{margin:0 0 6px 0}'
          + '#geoSkills .gs-bar:after{content:"";display:block;clear:both}'
          + '#geoSkills .gs-bar select{display:inline-block;width:auto;max-width:260px;height:24px;line-height:22px;padding:0 4px;font-size:11px;vertical-align:middle}'
          + '#geoSkills .gs-typepick{display:inline-block;position:relative;vertical-align:middle}'
          + '#geoSkills .gs-typebtn{height:24px;padding:1px 6px;font-size:11px;background:#fff;border:1px solid #ccc;border-radius:3px;color:#222}'
          + '#geoSkills .gs-typeico{width:18px;height:18px;vertical-align:middle;margin-right:4px}'
          + '#geoSkills .gs-typelist{display:none;position:absolute;z-index:20;left:0;top:26px;min-width:220px;max-height:240px;overflow:auto;background:#fff;border:1px solid #ccc;border-radius:3px}'
          + '#geoSkills .gs-typeitem{padding:3px 6px;cursor:pointer;color:#222;font-size:11px;white-space:nowrap}'
          + '#geoSkills .gs-typeitem:hover{background:#f2ead0}'
          + '#geoSkills .gs-total{float:right;line-height:24px;font-weight:bold;font-size:12px;color:#fff}'
          + '#geoSkills .gs-total.gs-full{color:#ffb347}'
          + '#geoSkills table.gs-grid{width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed}'
          + '#geoSkills .gs-grid td{padding:2px 3px;vertical-align:middle}'
          + '#geoSkills tr.gs-band-gold td{background:#f2ead0}'
          + '#geoSkills tr.gs-band-stone td{background:#e4e7ea}'
          + '#geoSkills tr.gs-band-earth td{background:#ecdfd2}'
          + '#geoSkills tr.gs-band-first td{border-top:2px solid #fff}'
          + '#geoSkills .gs-tier{width:74px;color:#6b5d45;font-size:10px;white-space:nowrap;overflow:hidden}'
          + '#geoSkills .gs-tier b{display:block;font-size:10px;color:#4a4030}'
          + '#geoSkills .gs-cell{position:relative;height:46px;padding:3px 4px;border:1px solid rgba(0,0,0,.12);border-radius:3px;background:rgba(255,255,255,.55);white-space:nowrap;vertical-align:middle}'
          + '#geoSkills .gs-cell.gs-empty{border-color:transparent;background:transparent}'
          + '#geoSkills .gs-cell.gs-closed{opacity:.38}'
          + '#geoSkills .gs-cell.gs-has{background:#fff;border-color:#b08d3a}'
          + '#geoSkills .gs-cell.gs-warn{border-color:#c9302c;opacity:1}'
          + '#geoSkills .gs-icon{display:inline-block;width:22px;height:22px;vertical-align:middle;margin-right:4px}'
          + '#geoSkills .gs-icon img{width:22px;height:22px;display:block}'
          + '#geoSkills .gs-ph{display:block;width:22px;height:22px;line-height:22px;text-align:center;font-size:9px;color:#888;background:#ddd;border-radius:2px}'
          + '#geoSkills .gs-body{display:inline-block;vertical-align:middle;width:76%;width:calc(100% - 28px);width:-webkit-calc(100% - 28px)}'
          + '#geoSkills .gs-label{display:block;height:20px;line-height:20px;overflow:hidden;white-space:nowrap;font-size:10px;color:#333;vertical-align:middle}'
          + '#geoSkills .gs-label.gs-wrap{white-space:normal;line-height:1.1;word-wrap:break-word}'
          + '#geoSkills .gs-spin{display:block;margin-top:2px;height:18px}'
          + '#geoSkills .gs-spin button{width:18px;height:18px;padding:0;line-height:16px;font-size:12px;font-weight:bold;border:1px solid #aaa;border-radius:2px;background:#f7f7f7;color:#333;vertical-align:middle}'
          + '#geoSkills .gs-spin button:disabled{color:#bbb;border-color:#ddd}'
          + '#geoSkills .gs-val{display:inline-block;min-width:26px;text-align:center;font-weight:bold;font-size:11px;vertical-align:middle;color:#222}'
          + '#geoSkills .gs-legend{margin-top:6px;color:#ccc;font-size:10px}'
          + '</style>'
        );
    }
    /* 0.1.15: the round-trade rules, editable */
    var DMA_TRADE_RULES = [
        { id: "trade.cap", label: "Max per item", unit: "" },
        { id: "trade.marginPct", label: "Safety margin: hold what an RT pays plus", unit: "%" },
        { id: "trade.ask.everyMin", label: "Ask a star trade at most once per", unit: "min" },
        { id: "trade.perSenderHour", label: "Max requests per player per hour", unit: "" },
        { id: "trade.waitMin", label: "Waiting time for the trades", unit: "min" },
        { id: "trade.graceMin", label: "After 'time is up', decline after", unit: "min" },
        { id: "trade.extensions", label: "'More time' allowed", unit: "times" },
        { id: "trade.expireMin", label: "A promise stays open", unit: "min" },
        { id: "trade.acceptMin", label: "Silence after 'RT done' counts as accepted after", unit: "min" }
    ];
    function DMA_openTrade() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy(), meta = {};
        try { (p && p.getRulesFor ? p.getRulesFor("trade-acceptor") : []).forEach(function (r) { meta[r.ruleId] = r; }); } catch (_) {}
        var tOn = DMA_pol("trade.auto", false) === true;
        var h = '<div style="color:#ccc;margin-bottom:6px;">Trade switch: <b style="color:' + (tOn ? "#8f8" : "#e88") + '">' + (tOn ? "ON" : "OFF") + '</b> — the kinds of trade ticked here run while it is on.</div>'
              + '<div style="color:#ddd;font-size:12px;margin-bottom:6px;">'
              + [["trade.rt.on", "Round trades", true], ["trade.help.on", "Help trades", false], ["trade.star.on", "Star trades", false], ["trade.ask.on", "Ask star trades when a storage is full", false]].map(function (k) {
                    return '<label style="font-weight:normal;margin-right:14px;"><input type="checkbox" class="dma-trade-kind" data-rule="' + k[0] + '"' + (DMA_pol(k[0], k[2]) === true ? " checked" : "") + '> ' + k[1] + '</label>'; }).join("")
              + '</div><div style="color:#ccc;margin-bottom:4px;">Round trade rules</div>'
              + '<table class="table table-condensed" style="font-size:12px;color:#ddd;"><tbody>';
        DMA_TRADE_RULES.forEach(function (r) {
            var v = DMA_pol(r.id, "");
            h += '<tr><td>' + DMA_esc(r.label) + '</td><td><input type="number" class="dma-in dma-trade-rule" data-rule="' + DMA_esc(r.id) + '" value="' + DMA_esc(String(v == null ? "" : v)) + '" style="width:90px"> ' + DMA_esc(r.unit) + '</td></tr>';
        });
        h += '</tbody></table><div id="DMA_tradeMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>' + DMA_helpBody();   // 0.1.24
        $(DMA_BODY).html(h);
        DMA_bindHelp(p);
        $(".dma-trade-kind").off("change.tk").on("change.tk", function () {
            var rule = $(this).data("rule"), res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, !!this.checked) : null; } catch (_) {}
            if (res && res.fact === "ac") $("#DMA_tradeMsg").css("color", "#8f8").text(rule + " = " + this.checked + " saved");
            else { $("#DMA_tradeMsg").css("color", "#e88").text(rule + ": refused"); this.checked = !this.checked; }
        });
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Trade rules");
        $(".dma-trade-rule").off("change.tr").on("change.tr", function () {
            var rule = $(this).data("rule"), val = Number(this.value), res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") $("#DMA_tradeMsg").css("color", "#8f8").text(rule + " = " + val + " saved");
            else { $("#DMA_tradeMsg").css("color", "#e88").text(rule + ": " + val + " refused (" + ((res && res.reason) || "policy not loaded") + ")"); this.value = DMA_pol(rule, ""); }
        });
        DMA_log("trade rules screen");
        return true;
    }
    /* 0.1.18: the MAIL page — rules next to the facts they decide about */
    var DMA_MAIL_GROUPS = [
        { k: "treasure",   label: "Treasure loot" },
        { k: "adventure",  label: "Adventure finds" },
        { k: "fragment",   label: "Map fragments" },
        { k: "expedition", label: "Expedition loot" }
    ];
    function DMA_mailBody() {
        var G = root.DMA_Control && root.DMA_Control.trade, MM = root.DMA_Mail || root.DMA_Loot, st = {}, wait = null;
        try { st = MM ? MM.status() : {}; } catch (_) {}
        try { wait = G && G.lootCounts ? G.lootCounts() : null; } catch (_) {}
        if (!wait) wait = st.waitingBy || {};
        var on = DMA_pol("mail.auto", false) === true, by = st.collectedBy || {};
        var h = '<div style="color:#ccc;margin-bottom:6px;">Mail switch: <b style="color:' + (on ? "#8f8" : "#e88") + '">' + (on ? "ON" : "OFF") + '</b>'
              + ' — the mail manager collects only the kinds ticked here. Untick a kind to save it (e.g. during an event).</div>'
              + '<table class="table table-condensed" style="font-size:12px;color:#ddd;"><thead><tr><th>Explorer loot</th><th>Collect</th><th>Waiting now</th><th>Collected</th><th></th></tr></thead><tbody>';
        DMA_MAIL_GROUPS.forEach(function (g) {
            var c = DMA_pol("mail.loot." + g.k, true) !== false;
            h += '<tr><td>' + DMA_esc(g.label) + '</td><td><input type="checkbox" class="dma-mail-rule" data-rule="mail.loot.' + g.k + '"' + (c ? " checked" : "") + '></td>'
               + '<td>' + (wait[g.k] == null ? "?" : wait[g.k]) + '</td><td>' + (by[g.k] || 0) + '</td>'
               + '<td><button type="button" class="btn btn-default btn-xs dma-mail-now" data-kind="' + g.k + '"' + ((wait[g.k] || 0) ? "" : " disabled") + ' title="Collect this kind once, now (also when the switch is off)">Collect now</button></td></tr>';
        });
        var toS = DMA_pol("mail.loot.toStorage", false) === true;
        var every = DMA_pol("mail.everyMin", 1);
        h += '</tbody></table>'
           + '<div style="color:#ddd;font-size:12px;margin-bottom:6px;">Collect every <input type="number" class="dma-in" id="DMA_mailEvery" value="' + DMA_esc(String(every)) + '" style="width:60px"> minutes'
           + (on && st.nextRunAt ? ' · next run ' + DMA_esc(String(st.nextRunAt).slice(11, 16)) + ' UTC' : '') + '</div>'
           + '<div style="color:#ddd;font-size:12px;margin-bottom:6px;">Destination: '
           + '<label style="font-weight:normal;margin-right:10px;"><input type="radio" name="dma_mail_dest" class="dma-mail-dest" value="star"' + (toS ? "" : " checked") + '> star menu</label>'
           + '<label style="font-weight:normal;"><input type="radio" name="dma_mail_dest" class="dma-mail-dest" value="storage"' + (toS ? " checked" : "") + '> storage</label></div>'
           + '<div style="color:#aaa;font-size:11px;">Last collection: ' + DMA_esc(st.last ? (st.last.at || "") + " · " + (st.last.n || 0) + " mails" : "none yet")
           + ' · runs ' + (st.runs || 0) + ' · total ' + (st.collected || 0) + (st.lastError ? ' · <span style="color:#e88">' + DMA_esc(st.lastError) + '</span>' : '') + '</div>'
           + (st.suspended ? '<div style="color:#e88;font-size:12px;margin-top:4px;">Suspended: ' + DMA_esc(st.suspended) + ' <button type="button" class="btn btn-default btn-xs" id="DMA_mailResume">Resume</button></div>' : '')
           + (MM ? '' : '<div style="color:#e88;font-size:11px;">user_dma_mail.js not loaded</div>')
           + '<div id="DMA_mailMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        return h;
    }
    function DMA_openMail() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy();
        function save(rule, val) {
            var res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") { $("#DMA_mailMsg").css("color", "#8f8").text(rule + " = " + val + " saved"); return true; }
            $("#DMA_mailMsg").css("color", "#e88").text(rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")"); return false;
        }
        $(DMA_BODY).html(DMA_mailBody());
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Mail rules");
        $(DMA_BODY).off("change.ml").on("change.ml", ".dma-mail-rule", function () {
            if (!save($(this).data("rule"), !!this.checked)) this.checked = !this.checked;
        }).on("change.ml", ".dma-mail-dest", function () { save("mail.loot.toStorage", this.value === "storage"); })
          .on("change.ml", "#DMA_mailEvery", function () { if (!save("mail.everyMin", Number(this.value))) this.value = DMA_pol("mail.everyMin", 1); })
          .off("click.ml").on("click.ml", "#DMA_mailResume", function () { try { root.DMA_Mail.resume(); } catch (_) {} $(DMA_BODY).html(DMA_mailBody()); })
          .on("click.ml", ".dma-mail-now", function () {
            var MM = root.DMA_Mail, kind = String($(this).data("kind")), btn = this;
            if (!MM || typeof MM.collectNow !== "function") { $("#DMA_mailMsg").css("color", "#e88").text("mail manager not loaded"); return; }
            btn.disabled = true; $("#DMA_mailMsg").css("color", "#8f8").text(kind + ": collecting ...");
            MM.collectNow(kind, function (r) {
                try { $(DMA_BODY).html(DMA_mailBody()); } catch (_) {}
                $("#DMA_mailMsg").css("color", r && r.ok ? "#8f8" : "#e88").text(kind + ": " + (r && r.n ? r.n + " collected" : "nothing collected") + (r && r.reason && !r.n ? " (" + r.reason + ")" : ""));
            });
        });
        DMA_log("mail rules screen");
        return true;
    }
    /* 0.1.35: the ADVS page (decision 0022) — adventures as DEMO transactions, their business rules owned by the player */
    var DMA_ADVS = [
        { id: "ae", title: "Arctic Explosion", note: "army adventure · Mundane Warfare templates, armies alternate · procedure docs/06-adventures/arctic-explosion.md" },
        { id: "gp", title: "Gunpowder", note: "arrows on the castle · loot spots for the guild · procedure docs/06-adventures/gunpowder-loot-spots.md" },
        { id: "ywc", title: "Ali Baba the Young Woodcutter", note: "army adventure (Ali Baba series) · Mundane Warfare: first ghost, then the main attack" },   // 0.1.47; name 0.1.53
        { id: "vlt", title: "The Valiant Little Tailor", note: "army adventure · Magic Beans (800-1,000) · procedure docs/06-adventures/valiant-little-tailor.md" },
        { id: "ft", title: "Ali Baba and the First Thief", note: "army adventure · Magic Beans (1,400-1,900 per bean slot) · procedure docs/06-adventures/ali-baba-first-thief.md" },   // 0.1.49
        { id: "own", title: "Your own adventure (any)", note: "choose the folder with your Mundane templates; Analyse finds the load, the run order and what to improve (ADR 0033)" },   // 0.1.50
        { id: "mundane", title: "All adventures: Mundane choices", note: "how every adventure is loaded, sent and played (ADR 0033)" }   // 0.1.50
    ];
    /* 0.1.50 (ADR 0033): the Mundane template advisor on the ADVS page */
    var DMA_advLast = {};
    /* 0.1.54 (author: "De client heeft al een standaard folder voor templates. dus die zou ik als basis nemen, waarbij
       mensen dit kunnen veranderen"): the client's own template folder (Settings: shortcutsDir) is the base; an adventure
       without a chosen folder uses <base>\<its abbreviation> when that folder exists, else the base itself. */
    var DMA_ADV_DIR = { ae: "AE", ft: "FT", ywc: "YWC", vlt: "VLT", gp: "GP" };
    function DMA_templatesBase() {
        var b = "";
        try { b = (root.mainSettings && root.mainSettings.shortcutsDir) || ""; } catch (_) {}
        try { if (!b && root.settings && root.settings.read) b = root.settings.read("shortcutsDir") || ""; } catch (_) {}
        try { if (!b && root.air) b = root.air.File.documentsDirectory.nativePath; } catch (_) {}
        return String(b || "");
    }
    function DMA_advDefaultFolder(id) {
        var base = DMA_templatesBase(); if (!base) return "";
        var sub = DMA_ADV_DIR[id];
        try { if (sub && root.air) { var f = new root.air.File(base + "\\" + sub); if (f.exists && f.isDirectory) return f.nativePath; } } catch (_) {}
        return base;
    }
    function DMA_advRunStatus(id) {
        var AX = root.DMA_Adventure, st = null; try { st = AX && AX.status ? AX.status() : null; } catch (_) {}
        if (!st || st.id !== id) return '';
        var col = st.stopped ? "#e88" : st.state === "DONE" ? "#8f8" : "#8cf";
        return '<span style="color:' + col + '"><b>' + DMA_esc(st.state) + '</b>' + (st.names && st.names[st.round] ? " · " + DMA_esc(st.names[st.round]) : "") + (st.reason ? " · " + DMA_esc(st.reason) : "") + '</span>'
             + '<div style="color:#999;font-size:10px;">' + (st.log || []).slice(-4).map(DMA_esc).join("<br>") + '</div>';
    }
    function DMA_startDir() { try { var b = DMA_templatesBase(), f = b ? new air.File(b) : null; return f && f.exists ? f : air.File.documentsDirectory; } catch (_) { return air.File.documentsDirectory; } }
    function DMA_advSrcRule(id) { var r = DMA_advRules(id).filter(function (d) { return d.pick === "files" || d.pick === "folder"; })[0]; return r ? r.ruleId : ""; }
    function DMA_advResult(id) {
        var res = DMA_advLast[id]; if (!res) return "";
        var advice = DMA_pol("adv.mundane.advice", true) !== false, col = { error: "#e88", warn: "#e0a030", info: "#8cf" }, h = "";
        res.forEach(function (r, ri) {
            if (r.error) { h += '<div style="color:#e88">' + DMA_esc(r.error) + '</div>'; return; }
            var c = r.choices || {};
            h += '<div style="margin-top:4px;border-top:1px solid #444;padding-top:3px;"><b>' + DMA_esc(r.adventure || "this folder") + '</b>: run <span style="color:#fc6">' + DMA_esc((r.run || []).join("  →  ") || "none found") + '</span>'
               + '<div style="color:#999;font-size:10px;">load: ' + DMA_esc(c.loadTemplate || "?") + ' · ' + (c.generals || 0) + ' generals · carrier ' + DMA_esc((c.carrier || []).join(", ") || "none") + ' · buffs ' + (c.buffs || 0)
               + (r.noGenerals ? ' · your generals are not known yet (dma-skills.json): foreign generals not checked' : '') + '</div>';
            if (!advice) { h += '<div style="color:#999;font-size:10px;">improvement proposals are off (rule ALL: show improvement proposals)</div></div>'; return; }
            (r.findings || []).forEach(function (f) {
                var t = (r.templates || []).filter(function (x) { return x.file === f.file; })[0];
                var mineBtn = f.code === "FOREIGN_GENERALS" && t && t.remap && t.remap.map && t.remap.map.length
                    ? ' <button type="button" class="btn btn-default btn-xs dma-adv-mine" data-adv="' + DMA_esc(id) + '" data-res="' + ri + '" data-file="' + DMA_esc(f.file) + '">Save my copy</button>' : '';
                h += '<div style="font-size:11px;margin:2px 0;"><span style="color:' + (col[f.level] || "#ccc") + '">' + DMA_esc(f.code) + '</span>' + (f.file ? ' <i>' + DMA_esc(f.file) + '</i>' : '') + ': ' + DMA_esc(f.msg)
                   + (f.fix ? '<div style="color:#8f8;margin-left:12px;">→ ' + DMA_esc(f.fix) + mineBtn + '</div>' : '') + '</div>';
            });
            h += '</div>';
        });
        return h;
    }
    /* 0.1.111 (author 2026-11-20: "Settings als keep it running is typisch iets dat je boven alle settings wil ... selecteer alle items die je
       wil inschakelen om het te versnellen, maar items die andere items uitschakelen worden greyed out ... Bij het avontuur kies je hoe een
       aanval wordt gedaan ... Het moet veel logischer en overzichtelijker"): the page reads top-down — RUN (which adventure, which version,
       how many runs, Start/Stop), SPEED IT UP (every speed-up in the star, one tick each; a tick greys out the ones it excludes), then the
       adventures with their versions (how an attack is done), then Advanced. */
    /* 0.1.112 (author: "zorg dat je de verschillende onderdelen kunt dichtklappen als ze goed staan en je iets anders wil doen"): every part of
       ADVS folds; open or closed is remembered per part (localStorage, a viewer convenience) */
    function DMA_foldOpen(key, dflt) { try { var v = root.localStorage ? root.localStorage.getItem("dma.fold." + key) : null; return v == null ? dflt !== false : v === "1"; } catch (_) { return dflt !== false; } }
    function DMA_fold(key, title, body, dflt) {   // 0.1.113: a click on the header folds (the client's engine has no <details>)
        var op = DMA_foldOpen(key, dflt);
        return '<div class="dma-av-card dma-fold" data-fold="' + DMA_esc(key) + '"><div class="dma-av-h dma-fold-h" style="cursor:pointer"><span class="dma-fold-ar" style="color:#fc6;width:12px;display:inline-block">' + (op ? '▾' : '▸') + '</span> ' + title + '</div>'
             + '<div class="dma-fold-b"' + (op ? '' : ' style="display:none"') + '>' + body + '</div></div>';
    }
    var DMA_advRunPick = null;
    function DMA_advPlayable(star, book) {
        var C = root.DMA_AdvCatalogue, out = [];
        var keys = {}; Object.keys(book || {}).forEach(function (r) { var e = book[r]; if (e && e.versions && e.versions.length) keys[r] = 1; });
        Object.keys(star || {}).forEach(function (r) { if (Number(star[r]) > 0 && (!C || !C.byRes || C.byRes(r))) keys[r] = 1; });   // 0.1.115: an adventure in the star without a version is listed too
        Object.keys(keys).forEach(function (r) { var e = (book || {})[r] || { versions: [] }, a = C && C.byRes ? C.byRes(r) : null;
            out.push({ res: r, name: a ? a.name : r, inStar: Number((star || {})[r] || 0), versions: (e.versions || []).map(function (v, i) { return { name: v.name, def: i === (e.def || 0) }; }) }); });
        out.sort(function (x, y) { return (y.inStar > 0) - (x.inStar > 0) || x.name.localeCompare(y.name); });
        return out;
    }
    function DMA_advRunCard(star, book) {
        var list = DMA_advPlayable(star, book), keep = String(DMA_pol("adv.keep.res", "") || ""), pick = DMA_advRunPick || keep || (list[0] && list[0].res) || "";
        var cur = list.filter(function (x) { return x.res === pick; })[0] || list[0] || null, kv = String(DMA_pol("adv.keep.version", "") || ""), runs = Number(DMA_pol("adv.keep.runs", 0)) || 0;
        var on = DMA_pol("adv.auto", false) === true && !!keep, mgr = null; try { mgr = root.DMA_AdventureManager && root.DMA_AdventureManager.runs ? root.DMA_AdventureManager.runs() : null; } catch (_) {}
        var title = '<b>Run</b><span class="dma-av-sub">' + (on ? 'keeps running: ' + DMA_esc(keep) : 'set it once: which adventure, which version, how many times') + '</span>', h = '';
        if (!list.length) return DMA_fold("run", title, '<div class="dma-av-sub">No adventure has a version yet: open one below (▶) and make a version first.</div>');
        h += '<table style="color:#e8dcc0"><tr><td style="width:22%">Adventure</td><td><select class="dma-in" id="DMA_runRes" style="width:100%;text-align:left">'
           + list.map(function (x) { return '<option value="' + DMA_esc(x.res) + '"' + (cur && x.res === cur.res ? ' selected' : '') + '>' + DMA_esc(x.name) + ' (' + x.inStar + ' in the star)</option>'; }).join('') + '</select></td></tr>'
           + '<tr><td>Version (how it is played)</td><td><select class="dma-in" id="DMA_runVer" style="width:100%;text-align:left">'
           + (cur ? cur.versions.map(function (v) { var sel = (keep === cur.res && kv) ? v.name === kv : v.def; return '<option value="' + DMA_esc(v.name) + '"' + (sel ? ' selected' : '') + '>' + DMA_esc(v.name) + (v.def ? ' (default)' : '') + '</option>'; }).join('') : '')
           + '<option value="__new__"' + (cur && !cur.versions.length ? ' selected' : '') + '>+ make a new version…</option></select></td></tr>'
           + '<tr><td>How many</td><td><select class="dma-in" id="DMA_runMode" style="width:150px"><option value="once">once</option><option value="keep"' + (on && !runs ? ' selected' : '') + '>keep running</option><option value="n"' + (on && runs ? ' selected' : '') + '>number of runs</option></select> '
           + '<input type="number" class="dma-in" id="DMA_runN" min="1" max="500" value="' + (runs || 5) + '" style="width:60px"></td></tr></table>'
           + '<button type="button" class="btn btn-success btn-xs" id="DMA_runStart">Start</button> <button type="button" class="btn btn-default btn-xs" id="DMA_runStop">Stop</button> '
           + '<span id="DMA_runMsg" class="dma-av-sub">' + (on ? 'keeps running: ' + DMA_esc(keep) + (runs ? ' — ' + (mgr ? mgr.done : 0) + ' of ' + runs + ' runs' : ' until you stop it') : 'nothing kept running') + '</span>'
           + '<div class="dma-adv-runstat" data-adv="' + DMA_esc(DMA_advKey(cur ? cur.res : "")) + '" style="font-size:11px;color:#8cf;"></div>'
           + '<div class="dma-av-sub" style="margin-top:4px">When one is intercepted: ' + DMA_advRuleRows(DMA_advRulesById(["adv.retreat.on"])).replace(/^<table>|<\/table>$/g, "") + '</div>';
        return DMA_fold("run", title, h);
    }
    function DMA_advBuffLabel(n) {
        var o = /^Observatory:(.+)$/.exec(String(n)), core = o ? o[1] : String(n);
        try { if (typeof loca !== "undefined" && loca.GetText) { var t = String(loca.GetText("BUF", core) || ""); if (t && t.indexOf("undefined") < 0 && t !== core) return (o ? "Observatory: " : "") + t; } } catch (_) {}
        var nick = { PropagationBuff_AdventureZoneTravelBoost_BlackTree: "Black Vortex (Blacktree)", PropagationBuff_AdventureZoneTravelBoost_DoggyBag: "Doggy Bag",
                     PropagationBuff_AdventureZoneTravelBoostLow: "Rough Star Chart", PropagationBuff_AdventureZoneTravelBoostMedium: "Normal Star Chart", PropagationBuff_AdventureZoneTravelBoostHigh: "Detailed Star Chart" }[core];   // display only, when the game gives no text
        return (o ? "Observatory: " : "") + (nick || core.replace(/^PropagationBuff_AdventureZoneTravelBoost_?/, "travel boost ").replace(/^GeneralSpeedBuff_/, "horseshoe: ").replace(/_/g, " "));
    }
    function DMA_advSpeedCard() {
        var tb = []; try { tb = root.DMA_Adventure && root.DMA_Adventure.travelBuffs ? root.DMA_Adventure.travelBuffs() : []; } catch (_) {}
        var chosen = DMA_pol("adv.travel", []) || [], on = {}; (typeof chosen === "string" ? chosen.split(",") : chosen).forEach(function (n) { on[String(n).trim()] = 1; });
        var taken = {}; tb.forEach(function (b) { if (on[b.name] && b.group != null) taken[b.group] = b.name; });
        var nOn = Object.keys(on).filter(Boolean).length, h = '';
        h += '<label style="font-weight:normal;color:#ddd;display:block"><input type="checkbox" class="dma-spd-pre"' + (DMA_pol("adv.prestage", true) !== false ? ' checked' : '') + '> make the next round ready while one fights (place from the star and load)</label>';
        if (!tb.length) h += '<div class="dma-av-sub">no travel or speed buffs in your star</div>';
        tb.forEach(function (b) { var g = b.group == null ? "" : String(b.group), dis = g !== "" && taken[g] && taken[g] !== b.name;
            h += '<label style="font-weight:normal;display:block;color:' + (dis ? '#666' : '#ddd') + '"><input type="checkbox" class="dma-spd" value="' + DMA_esc(b.name) + '" data-group="' + DMA_esc(g) + '"' + (on[b.name] ? ' checked' : '') + (dis ? ' disabled' : '') + '> '
               + DMA_esc(DMA_advBuffLabel(b.name)) + ' <span class="dma-av-mut">(' + (b.observatory ? b.count + ' Observatory ready' + (b.costs ? ' · ' + b.costs.map(function (c) { return c[1] + ' ' + c[0]; }).join(' + ') : '') : b.count + ' in the star') + ')</span></label>'; });
        h += '<span id="DMA_spdMsg" class="dma-av-sub"></span>';   // 0.1.114: every tick is kept at once, no Save
        return DMA_fold("speed", '<b>Speed it up</b><span class="dma-av-sub">' + nOn + ' chosen — tick what you want for every run; a tick greys out what it excludes</span>', h);
    }
    function DMA_advRulesById(ids) { try { var P = root.GCAF_PlayerPolicy; return (P && P.RULES ? P.RULES : []).filter(function (d) { return ids.indexOf(d.ruleId) >= 0; }); } catch (_) { return []; } }
    function DMA_advAdvancedRules() { return DMA_advRulesById(["adv.asIs", "adv.campByCamp", "adv.aheadHome", "adv.closeAtOnce", "adv.keep.retryMin", "adv.keep.planRuns"]); }
    /* greying: a ticked speed-up disables the others of its exclusivity group (the game's) */
    function DMA_advSpeedGrey() {
        var taken = {}; $(".dma-spd:checked").each(function () { var g = String($(this).data("group")); if (g !== "") taken[g] = this.value; });
        $(".dma-spd").each(function () { var g = String($(this).data("group")), dis = g !== "" && taken[g] && taken[g] !== this.value; this.disabled = !!dis; $(this).parent().css("color", dis ? "#666" : "#ddd"); });
    }
    function DMA_advRules(id) {
        var out = [];
        try { var P = root.GCAF_PlayerPolicy, defs = P && P.RULES ? P.RULES : null;
              (defs || []).forEach(function (d) { if (String(d.ruleId).indexOf("adv." + id + ".") === 0) out.push(d); }); } catch (_) {}
        return out;
    }
    function DMA_advsBodyClassic() {   // 0.1.59: the 0.1.35-0.1.58 page, kept for its rule rows
        var h = '<div style="color:#aaa;font-size:11px;margin-bottom:6px;">Every value is your business rule (decision 0022). The adventure manager that acts on them is not built yet: this page only reads and sets them.</div>';
        /* 0.1.48 (ADR 0030): the visit hold — request it before visiting another island, close it when the visit is over */
        var vh = null; try { vh = root.DMA_Control && root.DMA_Control.visit ? root.DMA_Control.visit.state() : null; } catch (_) {}
        h += '<div style="background:#2a2a2a;border-radius:4px;padding:6px;margin-bottom:8px;"><b style="color:#fc6">Visit another island</b> '
           + (vh && vh.on ? '<span style="color:#e0a030">HOLD ON since ' + new Date(vh.at).toISOString().slice(11, 16) + ' UTC (' + DMA_esc(vh.by) + '): scan, queue and self-starters wait</span> <button type="button" class="btn btn-default btn-xs" id="DMA_visitClose">Visit closed</button>'
                          : '<span style="color:#999">no hold</span> <button type="button" class="btn btn-primary btn-xs" id="DMA_visitReq">Hold blue work for a visit</button>')
           + '<div style="color:#999;font-size:10px;">Press before Visit: all blue work on the home island waits until the visit is closed, or 60 s after you are home again.</div></div>';
        DMA_ADVS.forEach(function (a) {
            var rules = DMA_advRules(a.id);
            h += '<div style="background:#2a2a2a;border-radius:4px;padding:6px;margin-bottom:8px;"><b style="color:#fc6">' + DMA_esc(a.title) + '</b> <span style="color:#999;font-size:11px;">' + DMA_esc(a.note) + '</span>'
               + '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:4px 0 0 0;">';
            if (!rules.length) h += '<tr><td style="color:#e88">rules not loaded (policy older than 0.2.22)</td></tr>';
            rules.forEach(function (d) {
                var v = DMA_pol(d.ruleId, d.value), inp;
                if (d.valueType === "bool") inp = '<input type="checkbox" class="dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="bool"' + (v === true ? " checked" : "") + '>';
                else if (d.valueType === "number") inp = '<input type="number" class="dma-in dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="number" value="' + DMA_esc(String(v)) + '" style="width:70px">';
                else inp = '<input type="text" class="dma-in dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="text" value="' + DMA_esc(String(v)) + '" style="width:340px"'
                         + (d.pick ? ' placeholder="' + DMA_esc(DMA_advDefaultFolder(a.id)) + '"' : '') + '>'
                         + (d.pick === "files" || d.pick === "folder" ? ' <button type="button" class="btn btn-default btn-xs dma-adv-pick" data-rule="' + DMA_esc(d.ruleId) + '" data-pick="' + DMA_esc(d.pick) + '">' + (d.pick === "folder" ? "Folder..." : "Files...") + '</button>' : '')
                         + (d.pick === "files" ? ' <button type="button" class="btn btn-default btn-xs dma-adv-pick" data-rule="' + DMA_esc(d.ruleId) + '" data-pick="folder">Folder...</button>' : '');   // 0.1.46; 0.1.50 folder; 0.1.51 a whole folder for a files rule too
                h += '<tr><td style="width:45%">' + DMA_esc(String(d.label).replace(/^[A-Z]+: /, "")) + '</td><td>' + inp + '</td></tr>';
            });
            h += '</table>';
            var AX = root.DMA_Adventure;   // 0.1.58 (ADR 0034): run once / stop / status
            if (AX && AX.RES && AX.RES[a.id]) h += '<button type="button" class="btn btn-success btn-xs dma-adv-run" data-adv="' + DMA_esc(a.id) + '">Run once</button> '
                + '<button type="button" class="btn btn-danger btn-xs dma-adv-stop">Stop</button> ' + DMA_advFinishBtn(a.id, "", "") + ' '
                + '<div id="DMA_advRun_' + DMA_esc(a.id) + '" class="dma-adv-runstat" data-adv="' + DMA_esc(a.id) + '" style="font-size:11px;color:#8cf;">' + DMA_advRunStatus(a.id) + '</div>';
            if (DMA_advSrcRule(a.id)) h += '<button type="button" class="btn btn-info btn-xs dma-adv-analyse" data-adv="' + DMA_esc(a.id) + '">Analyse my templates</button>'   // 0.1.50
                + '<div id="DMA_advRes_' + DMA_esc(a.id) + '">' + DMA_advResult(a.id) + '</div>';
            if (a.id === "gp") h += '<div style="color:#999;font-size:10px;margin-top:4px;">DEMO per loot spot: request = a request word after the offer · promise = invitation + promise text · execute = green check + kill · declare = a declare word in the adventure chat · accept = you close · revoke before the green check = cancel the invitation, revoke text, invite the next · after the green check = not undone, close without that kill.</div>';
            h += '</div>';
        });
        h += '<div id="DMA_advMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        return h;
    }

    /* 0.1.59 (ADR 0035, author 2026-10-31: "het scherm zo gaan indelen dat hij gelijk is opgebouwd aan het beginscherm met
       onze mijnen ... per groep een lijn met avonturen ... bovenaan voor alles ... per type ... per avontuur ... elk
       avontuur kan op meerdere manieren gespeeld worden" — "Het scherm moet er heel gelikt uitzien"):
       the ADVS overview. Top: rules for every adventure. Then one block per type (missions, mini missions, ventures,
       scenarios, co-op, events) with a row per adventure (in the star, loot spots, default version, last run, Run once);
       ▶ opens its versions (one per way of playing, each a template folder) and its own rules. */
    var DMA_ADV_LEGACY = { MiadArcticExplosion: "ae", Gunpowder: "gp", "1001NightsWoodcutter": "ywc", TheValiantLittleTailor: "vlt", "1001NightsFirstThief": "ft" };
    var DMA_advOpen = {}, DMA_advShowAll = false, DMA_advWatched = false;
    var DMA_ADV_CSS = '<style>'
        + '.dma-av-card{background:-webkit-linear-gradient(top,#30302c,#262622);border:1px solid rgba(255,204,102,.18);border-radius:6px;padding:6px 8px;margin:0 0 8px 0;box-shadow:0 1px 3px rgba(0,0,0,.4)}'
        + '.dma-av-h{margin:0 0 4px 0;overflow:hidden}.dma-av-h b{color:#fc6;font-size:13px;letter-spacing:.02em;margin-right:10px}.dma-av-h label{float:right}'
        + '.dma-av-sub{color:#9a9a90;font-size:10px}'
        + '.dma-av-grp{margin:10px 0 2px 0;padding:3px 8px;border-radius:4px;background:-webkit-linear-gradient(left,rgba(255,204,102,.25),rgba(255,204,102,0));color:#fc6;font-weight:600;font-size:12px;overflow:hidden}'
        + '.dma-av-grp span{float:right;color:#cfc6a8;font-weight:400;font-size:11px}'
        + '.dma-av .dma-table{table-layout:fixed}.dma-av .dma-table th,.dma-av .dma-table td{overflow:hidden;text-overflow:ellipsis}'
        + '.dma-av .dma-table td.dma-av-acts{white-space:normal!important;text-align:right;overflow:visible}.dma-av-acts .dma-av-btn{display:inline-block;margin:1px}'
        + '.dma-av-btn.dma-av-running{color:#3f3!important;font-weight:bold}'
        + '.dma-av .dma-table td{padding:3px 5px}.dma-av .dma-table tr.dma-type:hover td{background:rgba(255,255,255,.05)}'
        + '.dma-av-name{text-align:left!important;white-space:nowrap;cursor:pointer}.dma-av-name .dma-exp{color:#fc6;font-size:9px;margin-right:3px}'
        + '.dma-av-badge{display:inline-block;min-width:22px;padding:0 6px;border-radius:9px;background:#3d5a2a;color:#e6ffd0;font-size:11px}'
        + '.dma-av-badge.zero{background:#444;color:#999}'
        + '.dma-av-pill{display:inline-block;padding:0 6px;border-radius:9px;background:#2e4258;color:#d6e8ff;font-size:10px}'
        + '.dma-av-pill.none{background:transparent;color:#777;border:1px dashed #555}.dma-av-pill.found{background:transparent;color:#e0c070;border:1px dashed #a08040}'
        + '.dma-av-new{background:#3a2f12;border:1px solid #806020;border-radius:4px;padding:3px 8px;color:#fc6;font-size:11px;margin:0 0 6px 0}'
        + '.dma-av-ok{color:#9f9}.dma-av-bad{color:#f99}.dma-av-mut{color:#888;font-size:10px}'
        + '.dma-av-in{background:rgba(0,0,0,.25)!important}.dma-av-in td{border-bottom:1px solid rgba(255,255,255,.06)!important}'
        + '.dma-av-btn{padding:0 6px!important;font-size:10px!important;line-height:16px!important;margin:0 1px}'
        + '.dma-av-rules table{width:100%;font-size:11px;color:#ddd}.dma-av-rules td{padding:1px 4px;text-align:left!important;white-space:normal!important}'
        + '</style>';
    function DMA_advKey(res) { return DMA_ADV_LEGACY[res] || res; }
    function DMA_advRuleRows(rules, folderFor) {
        var h = '<table>';
        rules.forEach(function (d) {
            var v = DMA_pol(d.ruleId, d.value), inp;
            if (d.valueType === "bool") inp = '<input type="checkbox" class="dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="bool"' + (v === true ? " checked" : "") + '>';
            else if (d.valueType === "number") inp = '<input type="number" class="dma-in dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="number" value="' + DMA_esc(String(v)) + '" style="width:60px">';
            else if (d.pick) return;   // template files are versions now
            else if (/\.inviteMode$/.test(d.ruleId)) inp = '<select class="dma-in dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="text" style="width:auto;text-align:left">'   // 0.1.69 (P3)
                + ["together", "one by one"].map(function (o) { return '<option value="' + o + '"' + (String(v) === o ? " selected" : "") + '>' + o + '</option>'; }).join("") + '</select>';
            else inp = '<input type="text" class="dma-in dma-adv-rule" data-rule="' + DMA_esc(d.ruleId) + '" data-type="text" value="' + DMA_esc(String(v)) + '" title="' + DMA_esc(String(v)) + '" style="width:100%;text-align:left">';   // 0.1.69 (P3)
            h += '<tr><td style="width:45%">' + DMA_esc(String(d.label).replace(/^[A-Z]+: /, "")) + '</td><td>' + inp + '</td></tr>';
        });
        return h + '</table>';
    }
    function DMA_advGuessFolder(a) {
        var base = DMA_templatesBase(), C = root.DMA_AdvCatalogue, sub = DMA_ADV_DIR[DMA_ADV_LEGACY[a.res]] || (C ? C.abbr(a.name) : "");
        try { if (base && sub && root.air) { var f = new root.air.File(base + "\\" + sub); if (f.exists && f.isDirectory) return f.nativePath; } } catch (_) {}
        return "";
    }
    /* 0.1.88: where test variants of an adventure go — its own template folder, else <base>\<abbreviation> (made on Add) */
    function DMA_advTestBase(a) {
        var g = DMA_advGuessFolder(a); if (g) return g;
        var base = DMA_templatesBase(), C = root.DMA_AdvCatalogue, sub = DMA_ADV_DIR[DMA_ADV_LEGACY[a.res]] || (C ? C.abbr(a.name) : "");
        return base ? base.replace(/[\\\/]+$/, "") + (sub ? "\\" + sub : "") : "";
    }
    function DMA_advWarn(an) { try { var f = (an && an.findings) || {}; return an && !an.arrows ? (f.error || 0) + (f.warn || 0) : 0; } catch (_) { return 0; } }   // 0.1.69 (P4)
    function DMA_advSum(an) {   // 0.1.61: the version's own analysis, short
        if (!an) return '<span class="dma-av-mut">not analysed</span>';
        if (an.arrows) return an.ok ? '<span class="dma-av-mut" title="' + DMA_esc((an.names || []).join(", ")) + '">' + (an.targets || []).length + ' camp(s) to destroy · arrows</span> <span class="dma-av-ok">✓</span>'
                                    : '<span class="dma-av-bad" title="' + DMA_esc(an.error || "") + '">camps not known yet</span>';   // 0.1.64
        if (!an.ok) return '<span class="dma-av-bad" title="' + DMA_esc(an.error || "no load template or rounds found") + '">no run found</span>';
        var f = an.findings || {}, warn = (f.error || 0) + (f.warn || 0);
        var notes = (an.notes || []).map(function (x) { return x.code + ": " + x.msg; }).concat(an.shared && an.shared.notCovered && an.shared.notCovered.length ? ["shared Mundane: camps not covered by your generals " + an.shared.notCovered.join(", ")] : []);   // 0.1.100
        return '<span class="dma-av-mut" title="' + DMA_esc(an.run.join(" → ") + (notes.length ? " | " + notes.join(" | ") : "")) + '">' + an.run.length + ' templates · ' + an.generals + ' gen</span> ' + (warn ? '<span class="dma-av-bad" title="open ▶ and press Analyse for the proposals">⚠ ' + warn + '</span>' : '<span class="dma-av-ok">✓</span>');
    }
    /* 0.1.64 (author: "per kamp aangeven hoe hij dat wil" — "als je alleen arrows selecteert, hoeft hij niet naar een
       template te zoeken"): an arrows-only version lists the camps to destroy with the plan per camp as text,
       e.g. "Rain of Flaming Arrows x1 > Cupid's Arrow x5"; "general" or "skip" leave the camp out of the arrows */
    function DMA_planText(p) { return (p || []).map(function (x) { return x.arrow + ((x.arrow === "general" || x.arrow === "skip") ? "" : " x" + (x.max || 1)); }).join(" > "); }
    function DMA_planParse(t) {
        return String(t || "").split(/\s*(?:>|→|,|;)\s*/).filter(Boolean).map(function (x) { var m = /^(.*?)(?:\s*x\s*(\d+))?$/i.exec(x.trim()); return { arrow: m[1].trim(), max: Number(m[2] || 1) }; }).filter(function (x) { return x.arrow; });
    }
    function DMA_advPlanRows(res, v, e) {
        var AX = root.DMA_Adventure, an = v.analysis || {}, names = (an.names && an.names.length) ? an.names : [], h = '';
        var rows = names.length ? names : ["*"];
        var arrows = {}; try { arrows = AX.arrowsInStar ? AX.arrowsInStar() : {}; } catch (_) {}
        rows.forEach(function (n) {
            var plan = (v.plan && v.plan[n]) || (AX && AX.planFor ? AX.planFor(v, n) : []);
            h += '<tr class="dma-av-in"><td style="text-align:left;padding-left:34px" class="dma-av-mut">' + (n === "*" ? "every camp (camps not known yet)" : DMA_esc(n)) + '</td>'
               + '<td colspan="5" style="text-align:left"><input type="text" class="dma-in dma-adv-plan" data-res="' + DMA_esc(res) + '" data-version="' + DMA_esc(v.name) + '" data-camp="' + DMA_esc(n) + '" value="' + DMA_esc(DMA_planText(plan)) + '" style="width:96%" title="arrows in order, each with xN = at most N times; after each arrow the script waits for the result; general / skip = no arrows for this camp"></td></tr>';
        });
        if (v.ls) h += '<tr class="dma-av-in"><td style="text-align:left;padding-left:34px" class="dma-av-mut">loot spots (learned)</td><td colspan="5" style="text-align:left;color:#ccc">'   // 0.1.66
            + 'offer "' + DMA_esc((v.ls.offer && v.ls.offer.text) || "") + '" · ' + (v.ls.spots || 0) + ' spots · announce "' + DMA_esc((v.ls.announce && v.ls.announce.text) || "") + '" '
            + '<label style="font-weight:normal;color:' + (v.ls.approved ? "#3f3" : "#ccc") + '"><input type="checkbox" class="dma-adv-lsok" data-res="' + DMA_esc(res) + '" data-version="' + DMA_esc(v.name) + '"' + (v.ls.approved ? " checked" : "") + '> post in the guild chat and invite</label></td></tr>';
        var stock = Object.keys(arrows).map(function (k) { return arrows[k].name + " " + arrows[k].count; });
        if (stock.length) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:34px" class="dma-av-mut">in the star: ' + DMA_esc(stock.join(" · ")) + '</td></tr>';
        if (!names.length) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:34px" class="dma-av-mut">The camps to destroy are learned on the adventure (first visit or run); until then this plan holds for every camp.</td></tr>';
        return h;
    }
    /* 0.1.100 (ADR 0079): the version kinds first (catalogue KINDS), then the other modes of the executor */
    function DMA_advKindOpts(AX) {
        var C = root.DMA_AdvCatalogue, kinds = (C && C.KINDS) || [], modes = (AX && AX.MODES) || ["full"], seen = {}, h = "";
        kinds.forEach(function (k) { if (modes.indexOf(k.mode) < 0) return; seen[k.mode] = 1; h += '<option value="' + DMA_esc(k.mode) + '" title="' + DMA_esc(k.hint) + '"' + (k.mode === "without blocks" ? " selected" : "") + '>' + DMA_esc(k.label) + '</option>'; });
        modes.forEach(function (m) { if (!seen[m]) h += '<option value="' + DMA_esc(m) + '">' + DMA_esc(m) + '</option>'; });
        return h;
    }
/* 0.1.118 (ADR 0092, author 2026-11-21: "laat de speler zien of het een vastgesteld aantal is uit de praktijk, of dat je het
   ergens online hebt kunnen lezen (misschien met een kleurcode?)"): the landing fields of an adventure with their source —
   green = read from the game (seen in practice), blue = read online, grey = not known yet (read on the first run). */
function DMA_landInfo(res) { try { return root.DMA_Adventure && root.DMA_Adventure.landing ? root.DMA_Adventure.landing(res) : { n: null, source: null }; } catch (_) { return { n: null, source: null }; } }
function DMA_landHtml(res) {
    var l = DMA_landInfo(res);
    if (l.source === "game") return '<span style="color:#9c6" title="read from the game on ' + DMA_esc(String(l.at || "").slice(0, 10)) + ' (seen in practice)">landing ' + l.n + ' (game)</span>';
    if (l.source === "online") return '<span style="color:#8cf" title="read online' + (l.url ? ': ' + DMA_esc(l.url) : '') + '">landing ' + l.n + ' (online)</span>';
    return '<span style="color:#999" title="read from the game on the first run">landing ? (not seen yet)</span>';
}
function DMA_landRules(res) { var r = { landingSpots: null, landingSource: null }; try { if (root.DMA_Adventure && root.DMA_Adventure.landingRules) r = root.DMA_Adventure.landingRules(res); } catch (_) {}
    r.starMethod = DMA_pol("adv.mundane.starMethod", true) === true; return r; }
    function DMA_advAdviceHtml(res) {
        var C = root.DMA_AdvCatalogue, ad = C && C.advice ? C.advice(res) : [];
        return ad.map(function (x) { return '<div class="dma-adv-advice" style="color:#e0a030;font-size:11px;">advice: ' + DMA_esc(x.text) + '</div>'; }).join("");
    }
    function DMA_advFinishBtn(res, folder, version) {
        return '<button type="button" class="btn btn-warning btn-xs dma-av-btn dma-adv-finish" data-res="' + DMA_esc(res) + '" data-folder="' + DMA_esc(folder || "") + '" data-version="' + DMA_esc(version || "") + '" title="emergency mode: play the remaining camps one at a time with automatic retreat, whatever the version">Finish camp by camp</button>';
    }
    function DMA_advSpots(a) { return a.type === "coop" ? (a.players ? a.players + " spots" : "—") : (a.lootSpots == null ? "—" : String(a.lootSpots)); }
    function DMA_advRow(a, star, book) {
        var AX = root.DMA_Adventure, e = book[a.res] || { versions: [], def: 0, runs: [] }, key = DMA_advKey(a.res);
        var vs = e.versions || [], dv = vs[e.def] || vs[0], found = e.found, last = (e.runs || [])[(e.runs || []).length - 1], open = !!DMA_advOpen[a.res];
        var lastTxt = last ? '<span class="' + (last.state === "DONE" ? "dma-av-ok" : "dma-av-bad") + '">' + (last.state === "DONE" ? "✓ " + last.min + " min" : "✗ " + DMA_esc(last.state)) + '</span> <span class="dma-av-mut">' + DMA_esc(String(last.at).slice(5, 10)) + '</span>' : '<span class="dma-av-mut">—</span>';
        var verTxt = dv ? '<span class="dma-av-pill" title="' + DMA_esc(dv.folder) + '">' + DMA_esc(dv.name) + '</span> ' + DMA_advSum(dv.analysis)
                   : found ? '<span class="dma-av-pill found" title="folder ' + DMA_esc(found.folder) + ': its analysis found no load template and rounds; open ▶ to choose another folder">folder found, no run</span>'
                   : '<span class="dma-av-pill none" title="no template folder yet: open ▶ and add a version with Folder...">no templates</span>';
        var runnable = dv && star && dv.analysis && dv.analysis.ok;
        var st0 = null; try { st0 = AX && AX.status ? AX.status() : null; } catch (_) {}
        var running = st0 && st0.res === a.res && !st0.stopped && st0.state !== "DONE";   // 0.1.63: the pressed button turns green while its run goes on
        var runVer = running ? (st0.version || (AX.runVersion ? AX.runVersion() : "")) : null;
        var h = '<tr class="dma-type' + (open ? " open" : "") + '"><td class="dma-av-name dma-adv-tog" data-res="' + DMA_esc(a.res) + '"><span class="dma-exp">' + (open ? "▼" : "▶") + '</span>' + (a.step ? a.step + ". " : "") + DMA_esc(a.name) + '</td>'
              + '<td><span class="dma-av-badge' + (star ? "" : " zero") + '">' + (star || 0) + '</span></td>'
              + '<td class="dma-n">' + DMA_advSpots(a) + '</td>'
              + '<td style="text-align:left">' + verTxt + '</td>'
              + '<td>' + lastTxt + '</td>'
              + '<td>' + (running ? '<button type="button" class="btn btn-success btn-xs dma-av-btn dma-av-running" disabled>Running</button>'
                          : runnable ? '<button type="button" class="btn btn-success btn-xs dma-av-btn dma-adv-vrun" data-res="' + DMA_esc(a.res) + '" data-folder="' + DMA_esc(dv.folder) + '" data-version="' + DMA_esc(dv.name) + '" data-warn="' + DMA_advWarn(dv.analysis) + '">Run once</button>' : '') + '</td></tr>';
        var st = null; try { st = AX && AX.status ? AX.status() : null; } catch (_) {}
        if (st && (st.res === a.res)) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left"><div class="dma-adv-runstat" data-adv="' + DMA_esc(st.id) + '">' + DMA_advRunStatus(st.id) + '</div> <button type="button" class="btn btn-danger btn-xs dma-av-btn dma-adv-stop">Stop</button>' + DMA_advFinishBtn(a.res, dv ? dv.folder : "", dv ? dv.name : "") + '</td></tr>';
        if (!open) return h;
        h += DMA_advAdviceHtml(a.res) ? '<tr class="dma-av-in"><td colspan="6" style="text-align:left">' + DMA_advAdviceHtml(a.res) + '</td></tr>' : '';   // 0.1.100
        if (dv && !(st && st.res === a.res)) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left" class="dma-av-mut">Emergency, for an open adventure of this kind: ' + DMA_advFinishBtn(a.res, dv.folder, dv.name) + '</td></tr>';   // 0.1.100
        h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left"><span class="dma-av-mut">' + DMA_esc(a.type) + ' · ' + (a.players || "?") + ' player(s)' + (a.level ? ' · level ' + a.level + '+' : '') + ((a.guide || a.url) ? ' · <a href="#" class="dma-av-wiki" data-url="' + DMA_esc(a.guide || a.url) + '" style="color:#8cf">guide</a>' : '') + ' · ' + DMA_landHtml(a.res) + '</span></td></tr>';   // 0.1.118 (ADR 0092)
        vs.forEach(function (v) {
            var vr = (e.runs || []).filter(function (r) { return r.version === v.name; }).slice(-1)[0];
            h += '<tr class="dma-av-in"><td style="text-align:left;padding-left:16px"><input type="radio" name="dma_def_' + DMA_esc(a.res) + '" class="dma-adv-vdef" data-res="' + DMA_esc(a.res) + '" data-version="' + DMA_esc(v.name) + '"' + (v === dv ? " checked" : "") + ' title="default version"> <b>' + DMA_esc(v.name) + '</b> <span class="dma-av-pill">' + DMA_esc(v.mode) + '</span></td>'
               + '<td colspan="2" class="dma-av-mut" title="' + DMA_esc(v.folder) + '">' + (v.mode === "arrows only" ? "no templates needed" : DMA_esc(String(v.folder).split("\\").slice(-2).join("\\")) + (v.auto ? " (found)" : "")) + '</td>'
               + '<td style="text-align:left">' + DMA_advSum(v.analysis) + '</td>'
               + '<td colspan="2" class="dma-av-acts">' + (vr ? (vr.state === "DONE" ? '<span class="dma-av-ok">✓ ' + vr.min + ' min</span> ' : '<span class="dma-av-bad">✗</span> ') : '')
               + '<button type="button" class="btn btn-info btn-xs dma-av-btn dma-adv-van" data-res="' + DMA_esc(a.res) + '" data-folder="' + DMA_esc(v.folder) + '" data-version="' + DMA_esc(v.name) + '" data-mode="' + DMA_esc(v.mode) + '">Analyse</button>'
               + (running && (runVer === v.name || (!runVer && v === dv)) ? '<button type="button" class="btn btn-success btn-xs dma-av-btn dma-av-running" disabled>Running</button>'
                  : star && v.analysis && v.analysis.ok && !running ? '<button type="button" class="btn btn-success btn-xs dma-av-btn dma-adv-vrun" data-res="' + DMA_esc(a.res) + '" data-folder="' + DMA_esc(v.folder) + '" data-version="' + DMA_esc(v.name) + '">Run</button>' : '')
               + '<button type="button" class="btn btn-default btn-xs dma-av-btn dma-adv-vdel" data-res="' + DMA_esc(a.res) + '" data-version="' + DMA_esc(v.name) + '" title="remove this version (the files stay)">✕</button></td></tr>';
            if (v.mode === "arrows only") h += DMA_advPlanRows(a.res, v, e);   // 0.1.64
        });
        if (!vs.length && found) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:16px" class="dma-av-mut">Folder found by its name: ' + DMA_esc(found.folder) + ' — ' + DMA_esc((found.analysis && found.analysis.error) || "its analysis found no load template and rounds") + '.</td></tr>';
        /* 0.1.65 (author: "een leerfunctie ... eerst voorgedaan ... opgeslagen en nagedaan ... vervangen, of ... een
           tweede versie"): learn a version by playing it once */
        var lrn = null; try { lrn = AX && AX.learning ? AX.learning() : null; } catch (_) {}
        if (lrn && lrn.res === a.res) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:16px"><span class="dma-av-running" style="color:#3f3">● learning "' + DMA_esc(lrn.name) + '"' + (lrn.replace ? " (replaces)" : "") + '</span> · ' + lrn.steps + ' actions, ' + lrn.arrows + ' arrows — play the adventure now '
            + '<button type="button" class="btn btn-success btn-xs dma-av-btn dma-adv-lstop" data-save="1">Stop and save</button><button type="button" class="btn btn-default btn-xs dma-av-btn dma-adv-lstop" data-save="0">Cancel</button></td></tr>';
        else if (!lrn) h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:16px">Learn by playing it once: <input type="text" class="dma-in dma-av-lname" data-res="' + DMA_esc(a.res) + '" value="learned" style="width:90px"> '
            + '<label style="color:#ccc;font-weight:normal"><input type="checkbox" class="dma-av-lrep" data-res="' + DMA_esc(a.res) + '"> replace that version</label> '
            + '<button type="button" class="btn btn-warning btn-xs dma-av-btn dma-adv-lstart" data-res="' + DMA_esc(a.res) + '" title="start; then play the adventure yourself (start it, arrows, attacks); Stop and save turns it into a version">Start learning</button></td></tr>';
        h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left;padding-left:16px">New version: <select class="dma-in dma-av-mode" data-res="' + DMA_esc(a.res) + '" style="width:150px">' + DMA_advKindOpts(AX) + '</select> '
           + '<input type="text" class="dma-in dma-av-vname" data-res="' + DMA_esc(a.res) + '" placeholder="name, e.g. quick loot" style="width:110px"> '
           + '<button type="button" class="btn btn-primary btn-xs dma-av-btn dma-adv-vadd" data-res="' + DMA_esc(a.res) + '" data-base="' + DMA_esc(DMA_advTestBase(a)) + '" title="test: makes the folder test NN &lt;name&gt; in ' + DMA_esc(DMA_advTestBase(a)) + '">Add (Folder... unless arrows only or test)</button></td></tr>';
        h += '<tr class="dma-av-in"><td colspan="6" style="text-align:left"><div id="DMA_advRes_' + DMA_esc(a.res) + '">' + DMA_advResult(a.res) + '</div></td></tr>';
        var lid = DMA_ADV_LEGACY[a.res], rules = DMA_advRules(lid || "own").filter(function (d) { return !/\.(on|name|folder|load|order|templates)$/.test(d.ruleId); });
        if (rules.length) h += '<tr class="dma-av-in"><td colspan="6" class="dma-av-rules"><div class="dma-av-sub">' + (lid ? "rules for this adventure" : "rules shared by adventures without their own (OWN)") + '</div>' + DMA_advRuleRows(rules) + '</td></tr>';
        return h;
    }
    root.DMA_advGuessFolderByRes = function (res) { var C = root.DMA_AdvCatalogue, a = C && C.byRes(res); return a ? DMA_advGuessFolder(a) : ""; };   // 0.1.61: for the adventure watch
    /* 0.1.71: green's last advice of R-ADV-LOOT (ADR 0048) */
    function DMA_advLootHtml(list) {
        var L = root.DMA_AdvLoot;
        if (!list) { try { list = root.DMA_Green && root.DMA_Green.lootAdvice ? root.DMA_Green.lootAdvice() : []; } catch (_) { list = []; } }
        if (!L) return '<div class="dma-av-sub">adventure loot facts not loaded (user_dma_adv_loot.js)</div>';
        if (!list.length) return '<div class="dma-av-sub">no stock runs out within the horizon</div>';
        return list.map(function (a) { return '<div class="dma-av-new">' + DMA_esc(L.text(a)) + '</div>'; }).join("");
    }
    root.DMA_advLootHtml = DMA_advLootHtml;
    function DMA_advsBody() {
        var C = root.DMA_AdvCatalogue, AX = root.DMA_Adventure;
        if (!C) return DMA_advsBodyClassic();
        var star = {}, book = {}, ws = null; try { star = AX && AX.starCounts ? AX.starCounts() : {}; } catch (_) {}
        try { if (AX && AX.watch && !DMA_advWatched) { DMA_advWatched = true; ws = AX.watch({ limit: 40, guess: root.DMA_advGuessFolderByRes }); } else if (AX && AX.watchState) ws = AX.watchState(); } catch (_) {}
        try { book = AX && AX.book ? AX.book() : {}; } catch (_) {}
        var h = DMA_ADV_CSS + '<div class="dma-av">';
        var vh = null; try { vh = root.DMA_Control && root.DMA_Control.visit ? root.DMA_Control.visit.state() : null; } catch (_) {}
        var totalStar = 0; Object.keys(star).forEach(function (k) { totalStar += star[k]; });
        h += DMA_advRunCard(star, book) + DMA_advSpeedCard();   // 0.1.111: what you set for one moment, above everything else
        var allBody = '<label class="dma-av-sub"><input type="checkbox" id="DMA_advShowAll"' + (DMA_advShowAll ? " checked" : "") + '> show all ' + C.list().length + '</label>'
           + (ws && ws.unknown && ws.unknown.length ? '<div class="dma-av-new">New in your star, not in the catalogue yet: ' + ws.unknown.map(DMA_esc).join(", ") + '</div>' : '')
           + (ws && ws.changed && ws.changed.length ? '<div class="dma-av-new">Templates changed, analysed again: ' + ws.changed.map(DMA_esc).join(", ") + '</div>' : '')
           + '<div class="dma-fold" data-fold="advanced" style="margin-top:6px"><div class="dma-av-sub dma-fold-h" style="cursor:pointer"><span class="dma-fold-ar" style="color:#fc6;width:12px;display:inline-block">' + (DMA_foldOpen("advanced", false) ? '▾' : '▸') + '</span> <b>Advanced</b> — how DMA plays, loot spots, short stock</div><div class="dma-fold-b"' + (DMA_foldOpen("advanced", false) ? '' : ' style="display:none"') + '>'
           + '<div class="dma-av-rules">' + DMA_advRuleRows(DMA_advAdvancedRules()) + '</div>'
           + '<div class="dma-av-rules">' + DMA_advRuleRows(DMA_advRules("mundane")) + '</div>'
           + '<div class="dma-av-sub" style="margin-top:6px">loot spots — for every adventure with ls (0.1.67)</div><div class="dma-av-rules">' + DMA_advRuleRows(DMA_advRules("ls")) + '</div>'
           + '<div class="dma-av-sub" style="margin-top:6px">short stock -> adventure (R-ADV-LOOT, 0.1.71)</div><div class="dma-av-rules">' + DMA_advRuleRows(DMA_advRules("loot")) + '</div>' + DMA_advLootHtml() + '</div></div>'
           + '<div class="dma-av-sub" style="margin-top:4px">Visit another island: ' + (vh && vh.on ? '<span style="color:#e0a030">hold on since ' + new Date(vh.at).toISOString().slice(11, 16) + ' UTC</span> <button type="button" class="btn btn-default btn-xs dma-av-btn" id="DMA_visitClose">Visit closed</button>'
                     : 'no hold <button type="button" class="btn btn-primary btn-xs dma-av-btn" id="DMA_visitReq">Hold blue work for a visit</button>') + '</div>';
        h += DMA_fold("all", '<b>All adventures</b><span class="dma-av-sub">' + totalStar + ' adventures in the star · ' + Object.keys(star).length + ' kinds</span>', allBody);
        C.groups().forEach(function (g) {
            var isSeries = g.type === "series";   // 0.1.73: a series shows all its adventures, in play order, numbered
            var items = g.items.filter(function (a) { return a.res && (isSeries || DMA_advShowAll || star[a.res] || (book[a.res] && book[a.res].versions.length)); });
            if (!items.length) return;
            var n = 0; items.forEach(function (a) { n += star[a.res] || 0; });
            if (!isSeries) items.sort(function (x, y) { return x.name.toLowerCase() < y.name.toLowerCase() ? -1 : 1; });   // 0.1.61: alphabetical
            var gb = (isSeries && g.note ? '<div class="dma-av-sub" style="margin:0 0 2px 8px">' + DMA_esc(g.note) + '</div>' : '')
               + '<table class="dma-table"><colgroup><col style="width:29%"><col style="width:7%"><col style="width:8%"><col style="width:28%"><col style="width:13%"><col style="width:15%"></colgroup>'
               + '<thead><tr><th style="text-align:left">adventure</th><th>star</th><th>' + (g.type === "coop" ? "spots" : "LS") + '</th><th style="text-align:left">version</th><th>last run</th><th></th></tr></thead><tbody>';
            items.forEach(function (a) { gb += DMA_advRow(a, star[a.res] || 0, book); });
            gb += '</tbody></table>';
            h += DMA_fold("grp:" + (g.id || g.type), '<b>' + DMA_esc(g.title) + '</b><span class="dma-av-sub">' + items.length + ' adventures · ' + n + ' in the star</span>', gb);
        });
        h += '<div id="DMA_advMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div></div>';
        return h;
    }
    function DMA_openAdvs() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy();
        $(DMA_BODY).html(DMA_advsBody());
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Adventures");
        $(DMA_BODY).off("click.visit").on("click.visit", "#DMA_visitReq, #DMA_visitClose", function () {   // 0.1.48
            try { var V = root.DMA_Control && root.DMA_Control.visit; if (V) { if (this.id === "DMA_visitReq") V.request("player", "visit from the ADVS page"); else V.close("closed on the ADVS page"); } } catch (_) {}
            $(DMA_BODY).html(DMA_advsBody());
        });
        /* 0.1.59: the overview's own controls */
        var reAdv = function () { $(DMA_BODY).html(DMA_advsBody()); };
        $(DMA_BODY).off("click.av").on("click.av", ".dma-adv-tog", function () { var r = String($(this).data("res")); DMA_advOpen[r] = !DMA_advOpen[r]; reAdv(); })
            .on("change.av", "#DMA_advShowAll", function () { DMA_advShowAll = !!this.checked; reAdv(); })
            .on("click.av", ".dma-adv-vdef", function () { try { root.DMA_Adventure.setDefault(String($(this).data("res")), String($(this).data("version"))); } catch (_) {} reAdv(); })
            .on("click.av", ".dma-adv-vdel", function () { try { root.DMA_Adventure.removeVersion(String($(this).data("res")), String($(this).data("version"))); } catch (_) {} reAdv(); })
            .on("click.av", ".dma-adv-vkeep-unused", function () { try { root.DMA_Adventure.saveVersion(String($(this).data("res")), { name: "full", mode: "full", folder: String($(this).data("folder")) }); } catch (_) {} reAdv(); })
            .on("click.av", ".dma-av-wiki", function (e) { e.preventDefault(); try { root.air.navigateToURL(new root.air.URLRequest(String($(this).data("url")))); } catch (_) {} })
            .on("click.av", ".dma-adv-vrun", function () {
                var warnN = Number($(this).data("warn")) || 0;   // 0.1.69 (P4): a version with warnings asks once
                if (warnN && !$(this).data("armed")) {
                    $(this).data("armed", 1).removeClass("btn-success").addClass("btn-warning").text("Run anyway");
                    $("#DMA_advMsg").css("color", "#e0a030").text("this version has " + warnN + " warning(s) — open ▶ and press Analyse to see them; press Run anyway to start");
                    return;
                }
                var res = String($(this).data("res")), key = DMA_advKey(res), r = null;
                try { r = root.DMA_Adventure.runOnce(key, String($(this).data("folder")), String($(this).data("version"))); } catch (e) { r = { ok: false, reason: String(e) }; }
                DMA_log("adv run once " + key + ": " + JSON.stringify(r));
                if (!(r && r.ok)) $("#DMA_advMsg").css("color", "#e88").text("not started: " + ((r && r.reason) || "?")); else reAdv();
            })
            .on("click.av", ".dma-adv-van", function () {
                var res = String($(this).data("res")), M = root.DMA_Mundane;
                if (String($(this).data("mode")) === "arrows only") { delete DMA_advLast[res]; try { root.DMA_Adventure.saveVersion(res, { name: String($(this).data("version")), mode: "arrows only" }); } catch (_) {} reAdv(); return; }   // 0.1.64
                try { DMA_advLast[res] = M.analyzeAir(String($(this).data("folder")), DMA_landRules(res)); } catch (e) { DMA_advLast[res] = [{ error: "advisor failed: " + e }]; }
                try { if ($(this).data("version")) root.DMA_Adventure.saveVersion(res, { name: String($(this).data("version")), mode: String($(this).data("mode") || "full"), folder: String($(this).data("folder")) }); } catch (_) {}   // 0.1.61: keep the summary current
                reAdv();
            })
            .on("click.av", ".dma-adv-vadd", function () {
                var res = String($(this).data("res")), mode = String($('.dma-av-mode[data-res="' + res + '"]').val() || "full"), name = String($('.dma-av-vname[data-res="' + res + '"]').val() || mode).trim() || mode;
                if (mode === "arrows only") { try { root.DMA_Adventure.saveVersion(res, { name: name, mode: mode }); } catch (_) {} reAdv(); return; }   // 0.1.64: no folder
                if (mode === "test") {   // 0.1.88: "test NN <name>" in a folder of that name inside the adventure folder
                    var tn = String($('.dma-av-vname[data-res="' + res + '"]').val() || "").trim(), base = String($(this).data("base") || ""), rt = null;
                    try { rt = root.DMA_Adventure.addTest(res, tn, base); } catch (e) { rt = { ok: false, error: String(e) }; }
                    $("#DMA_advMsg").css("color", rt && rt.ok ? "#8f8" : "#e88").text(rt && rt.ok ? "test variant " + rt.name + " — put its templates in " + rt.folder : "test variant not made: " + ((rt && rt.error) || "?"));
                    reAdv(); return; }
                try {
                    var d = DMA_startDir();
                    d.addEventListener("select", function (ev) { try { root.DMA_Adventure.saveVersion(res, { name: name, mode: mode, folder: String((ev.target || d).nativePath) }); } catch (_) {} reAdv(); });
                    d.browseForDirectory("Choose the folder with the templates for this version");
                } catch (e) { $("#DMA_advMsg").css("color", "#e88").text("folder chooser failed: " + e); }
            });
        $(DMA_BODY).off("click.advlearn").on("click.advlearn", ".dma-adv-lstart", function () {   // 0.1.65
            var res = String($(this).data("res")), nm = String($('.dma-av-lname[data-res="' + res + '"]').val() || "learned").trim() || "learned", rep = $('.dma-av-lrep[data-res="' + res + '"]').is(":checked");
            try { root.DMA_Adventure.startLearning(res, nm, rep); $("#DMA_advMsg").css("color", "#8f8").text("learning " + nm + ": play the adventure now"); } catch (e) { $("#DMA_advMsg").css("color", "#e88").text("learning failed: " + e); }
            reAdv();
        }).on("click.advlearn", ".dma-adv-lstop", function () {
            var r = null; try { r = root.DMA_Adventure.stopLearning(String($(this).data("save")) === "1"); } catch (e) { r = { ok: false, error: String(e) }; }
            $("#DMA_advMsg").css("color", r && r.ok ? "#8f8" : "#e88").text(r && r.saved ? "saved as version " + r.name + " (" + r.arrows + " arrows" + (r.other ? ", " + r.other + " other actions" : "") + ")" : r && r.ok ? "learning cancelled" : "not saved: " + ((r && r.error) || "?"));
            reAdv();
        });
        $(DMA_BODY).off("change.advls").on("change.advls", ".dma-adv-lsok", function () {   // 0.1.66
            var ok = false; try { ok = root.DMA_Adventure.setLsApproved(String($(this).data("res")), String($(this).data("version")), this.checked); } catch (_) {}
            $("#DMA_advMsg").css("color", ok ? "#8f8" : "#e88").text(ok ? (this.checked ? "loot spots: the script posts and invites" : "loot spots: you do them yourself") : "not saved");
        });
        $(DMA_BODY).off("change.advplan").on("change.advplan", ".dma-adv-plan", function () {   // 0.1.64
            var ok = false; try { ok = root.DMA_Adventure.setPlan(String($(this).data("res")), String($(this).data("version")), String($(this).data("camp")), DMA_planParse(this.value)); } catch (_) {}
            $("#DMA_advMsg").css("color", ok ? "#8f8" : "#e88").text(ok ? "plan saved for " + $(this).data("camp") : "plan not saved");
        });
        $(DMA_BODY).off("change.adv").on("change.adv", ".dma-adv-rule", function () {
            var rule = String($(this).data("rule")), type = String($(this).data("type"));
            var val = type === "bool" ? !!this.checked : type === "number" ? Number(this.value) : String(this.value);
            p = policy() || p;   // 0.1.56: the instance as it is now, not as it was when the page opened
            var res = null, err = ""; try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (e) { err = String(e); }
            try { DMA_log("adv change " + rule + "=" + JSON.stringify(val) + " -> " + JSON.stringify(res) + (err ? " error " + err : "") + " diag " + JSON.stringify(p && p.diag ? p.diag() : (p ? "no diag" : "no policy"))); } catch (_) {}
            if (res && res.fact === "ac") { $("#DMA_advMsg").css("color", "#8f8").text(rule + " = " + val + " saved"); return; }
            $("#DMA_advMsg").css("color", "#e88").text(rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")");
            if (type === "bool") this.checked = !this.checked; else this.value = DMA_pol(rule, "");
        });
        $(DMA_BODY).off("click.fold").on("click.fold", ".dma-fold-h", function (e) {   // 0.1.113: fold by click; open or closed is kept
            if ($(e.target).is("input,select,button,a,label")) return;
            var box = $(this).closest(".dma-fold"), b = box.children(".dma-fold-b"), op = b.css("display") === "none";
            b.css("display", op ? "" : "none"); $(this).find(".dma-fold-ar").first().text(op ? "▾" : "▸");
            try { if (root.localStorage) root.localStorage.setItem("dma.fold." + box.data("fold"), op ? "1" : "0"); } catch (_) {}
        });
        /* 0.1.111: the Run and Speed cards */
        $(DMA_BODY).off("change.runres").on("change.runres", "#DMA_runRes", function () { DMA_advRunPick = this.value; try { DMA_openAdvs(); } catch (_) {} });
        /* 0.1.114 (author: "als je geselecteerd hebt als speler is het toch duidelijk dat je dat moet onthouden"): a tick is kept at once */
        /* 0.1.115 (author: "Als je de versie die je graag wil nog niet hebt, dan moet je naar het onderdeel waar je de versies kunt maken. Is hij
           daar gemaakt wordt hij vanzelf boven beschikbaar"): "+ make a new version…" opens that adventure's row below (its group unfolded) and
           scrolls to it; a version made there is in the Run card at once (the page is drawn again after every version change) */
        $(DMA_BODY).off("change.runver").on("change.runver", "#DMA_runVer", function () {
            if (this.value !== "__new__") return;
            var res = String($("#DMA_runRes").val() || ""), C0 = root.DMA_AdvCatalogue, a0 = C0 && C0.byRes ? C0.byRes(res) : null, sr = C0 && C0.seriesOf ? C0.seriesOf(res) : null;
            DMA_advRunPick = res; DMA_advOpen[res] = true;
            try { if (root.localStorage) { root.localStorage.setItem("dma.fold.grp:" + (sr ? sr.id : a0 ? a0.type : ""), "1"); root.localStorage.setItem("dma.fold.all", "1"); } } catch (_) {}
            $(DMA_BODY).html(DMA_advsBody());
            try { var row = $(DMA_BODY).find('.dma-adv-tog[data-res="' + res + '"]').first(); if (row.length) { var box = $(DMA_BODY), top = row.offset().top - box.offset().top + box.scrollTop() - 40; box.scrollTop(top); row.closest("tr").css("outline", "1px solid #fc6"); } } catch (_) {}
            $("#DMA_advMsg").css("color", "#8cf").text("make the version in the open row below: New version, a name, then Add (Folder...)");
        });
        $(DMA_BODY).off("change.spd").on("change.spd", ".dma-spd, .dma-spd-pre", function () {
            var p0 = policy(), el = this, r = null, sel = [];
            if ($(el).hasClass("dma-spd-pre")) { try { r = p0.requestChange("adv.prestage", !!el.checked); } catch (_) {} }
            else { $(".dma-spd:checked").each(function () { sel.push(this.value); }); try { r = p0.requestChange("adv.travel", sel); } catch (_) {} }
            if (!(r && r.fact === "ac")) { el.checked = !el.checked; $("#DMA_spdMsg").css("color", "#e88").text("not kept" + (r && r.why ? ": " + r.why : r && r.reason ? ": " + r.reason : "")); }
            else $("#DMA_spdMsg").css("color", "#8f8").text("kept");
            DMA_advSpeedGrey();
        });
        $(DMA_BODY).off("click.runstart").on("click.runstart", "#DMA_runStart", function () {
            var p0 = policy(), res = String($("#DMA_runRes").val() || ""), ver = String($("#DMA_runVer").val() || ""), mode = String($("#DMA_runMode").val()), n = Number($("#DMA_runN").val()) || 1, AX = root.DMA_Adventure, msg = "";
            if (!res) return;
            if (!ver || ver === "__new__") { $("#DMA_runMsg").css("color", "#e88").text("choose a version first, or make one"); return; }
            if (mode === "once") {
                var e = {}; try { e = (AX.book() || {})[res] || {}; } catch (_) {} var v = (e.versions || []).filter(function (x) { return x.name === ver; })[0];
                var r = null; try { r = AX.runOnce(res, v ? v.folder : "", ver); } catch (er) { r = { ok: false, reason: String(er) }; }
                msg = r && r.ok ? "started once" : "not started: " + ((r && r.reason) || "?");
            } else {
                var ok = [p0.requestChange("adv.keep.res", res), p0.requestChange("adv.keep.version", ver), p0.requestChange("adv.keep.runs", mode === "n" ? n : 0), p0.requestChange("adv.auto", true)].every(function (x) { return x && x.fact === "ac"; });
                msg = ok ? (mode === "n" ? n + " runs" : "keeps running until you stop it") + " — the adventure manager starts the next run within a minute" : "refused";
            }
            $("#DMA_runMsg").css("color", /refused|not started/.test(msg) ? "#e88" : "#8f8").text(msg);
        });
        $(DMA_BODY).off("click.runstop").on("click.runstop", "#DMA_runStop", function () {
            var p0 = policy(); try { p0.requestChange("adv.keep.res", ""); p0.requestChange("adv.auto", false); } catch (_) {}
            try { root.DMA_Adventure.stop(); } catch (_) {}
            $("#DMA_runMsg").css("color", "#8f8").text("stopped: nothing kept running, the run going stops at its next step");
        });
        /* 0.1.58 (ADR 0034): Run once plays the adventure from the star to home; Stop ends it at the next step */
        $(DMA_BODY).off("click.advrun").on("click.advrun", ".dma-adv-run", function () {
            var id = String($(this).data("adv")), AX = root.DMA_Adventure, src = String(DMA_pol(DMA_advSrcRule(id), "") || "") || DMA_advDefaultFolder(id);
            var r = null; try { r = AX.runOnce(id, src); } catch (e) { r = { ok: false, reason: String(e) }; }
            DMA_log("adv run once " + id + ": " + JSON.stringify(r));
            $("#DMA_advRun_" + id).html(r && r.ok ? DMA_advRunStatus(id) : '<span style="color:#e88">not started: ' + DMA_esc((r && r.reason) || "?") + '</span>');
        });
        $(DMA_BODY).off("click.advfin").on("click.advfin", ".dma-adv-finish", function () {   // 0.1.100 (ADR 0079): the emergency mode
            var res = String($(this).data("res")), r = null;
            try { r = root.DMA_Adventure.finishCampByCamp(DMA_advKey(res), String($(this).data("folder") || "") || undefined, $(this).data("version") != null && String($(this).data("version")) !== "" ? String($(this).data("version")) : undefined); } catch (e) { r = { ok: false, reason: String(e) }; }
            $("#DMA_advMsg").css("color", r && r.ok ? "#8f8" : "#e88").text(r && r.ok ? (r.running ? "the run goes on camp by camp from its next step" : "finishing the open adventure camp by camp") : "not started: " + ((r && r.reason) || "?"));
            $(".dma-adv-runstat").each(function () { $(this).html(DMA_advRunStatus(String($(this).data("adv")))); });
        });
        $(DMA_BODY).off("click.advstop").on("click.advstop", ".dma-adv-stop", function () { try { root.DMA_Adventure.stop(); } catch (_) {} $(".dma-adv-runstat").each(function () { $(this).html(DMA_advRunStatus(String($(this).data("adv")))); }); });
        try { if (root.__DMA_ADV_RUN_TIMER) clearInterval(root.__DMA_ADV_RUN_TIMER); root.__DMA_ADV_RUN_TIMER = setInterval(function () {
            try { $(".dma-adv-runstat").each(function () { $(this).html(DMA_advRunStatus(String($(this).data("adv")))); }); } catch (_) {}
        }, 3000); } catch (_) {}
        /* 0.1.50 (ADR 0033): Analyse = the Mundane advisor on the chosen files' folder; Save my copy = the remap, after the player's click */
        $(DMA_BODY).off("click.advan").on("click.advan", ".dma-adv-analyse", function () {
            var id = String($(this).data("adv")), M = root.DMA_Mundane, rule = DMA_advSrcRule(id), src = String(DMA_pol(rule, "") || "");
            var out = $("#DMA_advRes_" + id);
            if (!M || !M.analyzeAir) { out.html('<div style="color:#e88">user_dma_mundane.js not loaded</div>'); return; }
            function run(path) {
                out.html('<div style="color:#8cf">analysing ' + DMA_esc(path) + ' ...</div>');
                try { DMA_advLast[id] = M.analyzeAir(path, DMA_landRules(id)); }
                catch (e) { DMA_advLast[id] = [{ error: "advisor failed: " + e }]; }
                out.html(DMA_advResult(id));
            }
            if (src.trim()) { run(src); return; }
            var dflt = DMA_advDefaultFolder(id);   // 0.1.54: the client's template folder
            if (dflt) { run(dflt); out.prepend('<div style="color:#999;font-size:10px;">folder: ' + DMA_esc(dflt) + ' (the client\'s template folder; change it with Folder...)</div>'); return; }
            /* 0.1.51: nothing chosen yet -> choose the folder with this adventure's templates, keep it in the rule, analyse */
            try {
                if (typeof air === "undefined" || !air.File) { out.html('<div style="color:#e88">choose your templates first (Files... or Folder...)</div>'); return; }
                var d = DMA_startDir();
                d.addEventListener("select", function (ev) {
                    var path = String((ev.target || d).nativePath);
                    try { if (p && p.requestChange) p.requestChange(rule, path); } catch (_) {}
                    $('.dma-adv-rule[data-rule="' + rule + '"]').val(path);
                    run(path);
                });
                d.browseForDirectory("Choose the folder with your templates for this adventure");
            } catch (e) { out.html('<div style="color:#e88">folder chooser failed: ' + DMA_esc(String(e)) + '</div>'); }
        });
        $(DMA_BODY).off("click.advmine").on("click.advmine", ".dma-adv-mine", function () {
            var id = String($(this).data("adv")), r = (DMA_advLast[id] || [])[Number($(this).data("res"))], file = String($(this).data("file")), M = root.DMA_Mundane;
            var t = r && (r.templates || []).filter(function (x) { return x.file === file; })[0], out = null;
            try { out = t && M.saveCopyAir(r.folder, file, r.texts[file], t.remap.map); } catch (e) { out = { ok: false, reason: String(e) }; }
            $("#DMA_advMsg").css("color", out && out.ok ? "#8f8" : "#e88").text(out && out.ok ? "saved " + out.file + " (the original is unchanged)" : "not saved: " + ((out && out.reason) || "?"));
        });
        /* 0.1.46: the player's own Mundane Warfare template files (one or more, in the order chosen; " / " between) */
        $(DMA_BODY).off("click.advpick").on("click.advpick", ".dma-adv-pick", function () {
            var rule = String($(this).data("rule"));
            var msg = function (c, t) { $("#DMA_advMsg").css("color", c).text(t); };
            if (String($(this).data("pick")) === "folder") {   // 0.1.50
                try {
                    if (typeof air === "undefined" || !air.File) { msg("#e88", "no folder chooser in this client: type the path"); return; }
                    var d = DMA_startDir();
                    d.addEventListener("select", function (ev) {
                        var val = String((ev.target || d).nativePath), res = null;
                        try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
                        if (res && res.fact === "ac") { $('.dma-adv-rule[data-rule="' + rule + '"]').val(val); msg("#8f8", rule + " saved"); } else msg("#e88", rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")");
                    });
                    d.browseForDirectory("Choose the folder with your Mundane Warfare templates");
                } catch (e) { msg("#e88", "folder chooser failed: " + e); }
                return;
            }
            try {
                if (typeof air === "undefined" || !air.File) { msg("#e88", "no file chooser in this client: type the paths"); return; }
                var f = DMA_startDir();
                f.addEventListener("selectMultiple", function (ev) {
                    var paths = []; try { (ev.files || []).forEach(function (x) { paths.push(String(x.nativePath)); }); } catch (_) {}
                    if (!paths.length) return;
                    var val = paths.join(" / ");
                    var res = null; try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
                    if (res && res.fact === "ac") { $('.dma-adv-rule[data-rule="' + rule + '"]').val(val); msg("#8f8", rule + ": " + paths.length + " template(s) saved"); }
                    else msg("#e88", rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")");
                });
                var filt = []; try { filt = [new air.FileFilter("Mundane Warfare templates", "*.json;*.txt;*.*")]; } catch (_) {}
                f.browseForOpenMultiple("Choose your Mundane Warfare template file(s)", filt);
            } catch (e) { msg("#e88", "file chooser failed: " + e); }
        });
        DMA_log("adventures screen");
        return true;
    }
    /* 0.1.39: the EVENT page (ADR 0028) — the event manager's observation and the rules of each event type */
    function DMA_eventBody() {
        var E = root.DMA_Event, st = null;
        try { st = E && E.observe ? E.observe() : null; } catch (_) {}
        if (!st) return '<div style="color:#e88">user_dma_event.js 0.2.0 not loaded</div>';
        function fmt(ms) { if (!ms) return "?"; var d = new Date(ms); return d.toISOString ? d.toISOString().slice(0, 16).replace("T", " ") + " UTC" : String(d); }
        var h = DMA_selBlock() + '<div style="color:#ccc;margin-bottom:6px;">Event manager: <b>' + DMA_esc(st.how) + '</b>'
              + (st.gameEvents.length ? ' · the game runs: ' + DMA_esc(st.gameEvents.join(", ")) : '') + '</div>';
        st.types.forEach(function (ty) {
            h += '<div style="border:1px solid #555;padding:6px;margin-bottom:8px;">'
               + '<div style="color:#ddd;font-weight:bold;">' + DMA_esc(ty.label) + ' — '
               + (ty.running ? '<span style="color:#8f8">running</span>' + (ty.observed ? '' : ' <span style="color:#fc6">(assumed)</span>') : '<span style="color:#e88">not running</span>')
               + (ty.running ? ' · ' + DMA_esc(ty.name) + ' · ' + fmt(ty.start) + ' → ' + fmt(ty.stop) : '') + '</div>'
               + '<div style="color:#aaa;font-size:11px;margin:2px 0 4px;">These rules are valid only while the event runs. Game event names that count (start with): '
               + '<input type="text" class="dma-in dma-ev-rule" data-rule="event.' + DMA_esc(ty.type) + '.gameNames" data-type="text" value="' + DMA_esc(ty.gameNames || "") + '" style="width:160px"></div>';
            h += DMA_evPartsBlock(E, ty);   // 0.1.77
            h += '<label style="font-weight:normal;color:#ccc;margin-right:12px;"><input type="checkbox" class="dma-ev-rule" data-rule="quest.collect.on" data-type="bool"' + (DMA_pol("quest.collect.on", true) !== false ? " checked" : "") + '> pick up collectibles (buff ingredients)</label>'
               + '<label style="font-weight:normal;color:#ccc;">explorer template <select class="dma-ev-rule" data-rule="expo.template" data-type="text">'
               + ["Daily", "Event", "Adventure"].map(function (t) { return '<option' + (String(DMA_pol("expo.template", "Daily")) === t ? " selected" : "") + '>' + t + '</option>'; }).join("") + '</select></label>';
            h += '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin-top:4px;"><thead><tr><th>Building</th><th>Name in the game</th><th>Seconds per ' + DMA_esc((ty.rules && Object.keys(ty.rules).length && ty.rules[Object.keys(ty.rules)[0]].unit) || "unit") + '</th><th>Default</th></tr></thead><tbody>';
            Object.keys(ty.rules || {}).forEach(function (n) {
                var r = ty.rules[n];
                h += '<tr><td>' + DMA_esc(r.label) + '</td><td>' + DMA_esc(n) + '</td><td><input type="number" class="dma-in dma-ev-spu" data-evtype="' + DMA_esc(ty.type) + '" data-bld="' + DMA_esc(n) + '" value="' + DMA_esc(String(r.secondsPerUnit)) + '" style="width:80px"></td><td>' + r.defaultSecondsPerUnit + '</td></tr>';
            });
            h += '</tbody></table>';
            if (ty.type === "halloween") {   // 0.1.42: counters (rules of the type; defaults in DMA_Event)
                var cb = "event.halloween.trick.";
                h += '<div style="color:#ccc;margin:2px 0 6px;"><label style="font-weight:normal;margin-right:8px;"><input type="checkbox" class="dma-ev-rule" data-rule="' + cb + 'on" data-type="bool"' + (DMA_pol(cb + "on", true) !== false ? " checked" : "") + '> answer a buff named</label>'
                   + '<input type="text" class="dma-in dma-ev-rule" data-rule="' + cb + 'when" data-type="text" value="' + DMA_esc(String(DMA_pol(cb + "when", "trick"))) + '" style="width:70px"> on a building with '
                   + '<input type="text" class="dma-in dma-ev-rule" data-rule="' + cb + 'give" data-type="text" value="' + DMA_esc(String(DMA_pol(cb + "give", "Treat"))) + '" style="width:70px"></div>';
                var seenB = {}, mB = null;
                try { mB = root.DMA_Control && root.DMA_Control.map ? root.DMA_Control.map() : null; } catch (_) {}
                if (mB && mB.counts && mB.counts.buff) seenB = mB.counts.buff;   // 0.1.45: over all buildings
                else ((mB && mB.buildings) || []).forEach(function (b) { if (b.buffName) seenB[b.buffName] = (seenB[b.buffName] || 0) + 1; });
                h += '<div style="color:#aaa;font-size:11px;margin:-4px 0 6px;">Buffs on buildings in the last scan: ' + (Object.keys(seenB).length ? DMA_esc(Object.keys(seenB).sort().map(function (k) { return k + " ×" + seenB[k]; }).join(", ")) : "none read") + '</div>';
            }
            h += DMA_evBuffBlock(ty.type, (ty.rules && Object.keys(ty.rules).length && ty.rules[Object.keys(ty.rules)[0]].unit) || "") + '</div>';
        });
        h += '<div id="DMA_evMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        return h;
    }
    function DMA_openEvent() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy();
        function save(rule, val) {
            var res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") { $("#DMA_evMsg").css("color", "#8f8").text(rule + " saved"); return true; }
            $("#DMA_evMsg").css("color", "#e88").text(rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")"); return false;
        }
        $(DMA_BODY).html(DMA_eventBody());
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Events");
        $(DMA_BODY).off("change.evsel").on("change.evsel", ".dma-sel-rule", function () { if (!save(String($(this).data("rule")), !!this.checked)) this.checked = !this.checked; else $(DMA_BODY).html(DMA_eventBody()); });   // 0.1.76
        $(DMA_BODY).off("change.ev").on("change.ev", ".dma-ev-rule", function () {
            var rule = String($(this).data("rule")), type = String($(this).data("type"));
            var val = type === "bool" ? !!this.checked : String(this.value);
            if (!save(rule, val) && type === "bool") this.checked = !this.checked;
        }).on("change.ev", ".dma-ev-spu", function () {
            var t = String($(this).data("evtype")), b = String($(this).data("bld")), cur = {};
            try { cur = JSON.parse(JSON.stringify(DMA_pol("event." + t + ".buffable", {}) || {})); } catch (_) { cur = {}; }
            var v = Number(this.value);
            if (v > 0) cur[b] = v; else delete cur[b];
            save("event." + t + ".buffable", cur);
        }).off("click.ev").on("click.ev", ".DMA_evEx, .DMA_evIn", function (e) {
            e.preventDefault();
            var t = String($(this).data("evtype")), b = String($(this).data("buff")), list = DMA_evExcluded(t);
            if ($(this).hasClass("DMA_evEx")) { if (list.indexOf(b) < 0) list.push(b); } else list = list.filter(function (x) { return x !== b; });
            save("event." + t + ".buff.exclude", list);
            $(DMA_BODY).html(DMA_eventBody());
            return false;
        });
        DMA_log("event screen");
        return true;
    }
    /* 0.1.77: the parts of an event type (event 0.2.9) — switch, executor, state */
    function DMA_evPartsBlock(E, ty) {
        var ps = []; try { ps = E && E.parts ? E.parts(ty.type) : []; } catch (_) {}
        if (!ps.length) return '';
        var col = { auto: "#8f8", off: "#888", "needs you": "#fc9" }, need = ps.filter(function (p) { return p.state === "needs you"; }).length;
        return '<div style="margin:2px 0 6px;"><b style="color:#fc9">Parts of the event</b>' + (need ? ' <span style="color:#fc9">— ' + need + ' need you (no executor)</span>' : '')
             + '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:2px 0 0;"><thead><tr><th>On</th><th>Part</th><th>Executor</th><th>State</th></tr></thead><tbody>'
             + ps.map(function (p) { return '<tr><td><input type="checkbox" class="dma-sel-rule" data-rule="' + DMA_esc(p.rule) + '"' + (p.on ? " checked" : "") + '></td><td>' + DMA_esc(p.label) + '</td><td>' + DMA_esc(p.actor)
                 + '</td><td><b style="color:' + (col[p.state] || "#ddd") + '">' + DMA_esc(p.state) + '</b></td></tr>'; }).join("")
             + '</tbody></table></div>';
    }
    /* 0.1.77: what the quest manager watches (quest 0.1.21) — categories and executors */
    function DMA_questWatchBlock(Q) {
        var w = null; try { w = Q && Q.watch ? Q.watch() : null; } catch (_) {}
        if (!w) return '';
        var h = '<div style="margin-bottom:6px;"><b style="color:#fc9">What the quest manager watches</b>'
              + '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:2px 0 4px;"><thead><tr><th>Category</th><th>On</th><th>Open</th><th>Rewards ready</th><th>Need you</th></tr></thead><tbody>'
              + w.categories.map(function (c) { return '<tr><td>' + DMA_esc(c.category) + '</td><td>' + (c.on ? '<span style="color:#8f8">on</span>' : '<span style="color:#888">off</span>') + '</td><td>' + c.open + '</td><td>' + (c.rewards || "") + '</td><td>' + (c.needsYou ? '<b style="color:#fc9">' + c.needsYou + '</b>' : '') + '</td></tr>'; }).join("")
              + '</tbody></table><table class="table table-condensed" style="font-size:11px;color:#ddd;margin:0;"><thead><tr><th>Executor</th><th>Task kinds</th><th>Loaded</th><th>Open tasks</th></tr></thead><tbody>'
              + w.executors.map(function (e) { return '<tr><td>' + DMA_esc(e.actor) + '</td><td>' + DMA_esc(e.kinds.join(", ")) + '</td><td>' + (e.watch ? '<span style="color:#8cf">watched</span>' : e.loaded ? '<span style="color:#8f8">yes</span>' : '<b style="color:#fc9">no</b>') + '</td><td>' + (e.open || "") + '</td></tr>'; }).join("")
              + '</tbody></table></div>';
        return h;
    }
    /* 0.1.76: one place to select the Event switch and the quest book, with every sub-selection (QUEST and EVENT pages) */
    function DMA_selBlock() {
        function tk(id, label, dflt) { return '<label style="font-weight:normal;margin-right:10px;"><input type="checkbox" class="dma-sel-rule" data-rule="' + id + '"' + (DMA_pol(id, dflt) === true || (dflt === true && DMA_pol(id, dflt) !== false) ? " checked" : "") + '> ' + DMA_esc(label) + '</label>'; }
        var E = root.DMA_Event, st = null; try { st = E && E.observe ? E.observe() : null; } catch (_) {}
        var evOn = DMA_pol("event.auto", true) !== false, qOn = DMA_pol("quest.auto", false) === true;
        var h = '<div style="border:1px solid #555;padding:4px 6px;margin-bottom:6px;color:#ccc;">'
              + '<div><b>' + tk("event.auto", "Event", true) + '</b>' + (evOn ? '' : '<span style="color:#e88">off — no event filling, buffs, counters or event quests</span>');
        ((st && st.types) || []).forEach(function (ty) {
            if (!ty.running) return;
            h += '<span style="margin-left:6px;color:#aaa">' + DMA_esc(ty.label) + ':</span> ' + tk("event." + ty.type + ".fill.on", "fill", true) + tk("event." + ty.type + ".buff.on", "buff its buildings", false)
               + (ty.type === "halloween" ? tk("event.halloween.trick.on", "answer tricks", true) : '');
        });
        h += tk("quest.do.event", "event quests (first in the to-do list)", true) + '</div>'
           + '<div style="margin-top:3px;"><b>' + tk("quest.auto", "Quest book", false) + '</b>' + (qOn ? '' : '<span style="color:#e88">off — nothing is claimed, paid or listed</span>')
           + tk("quest.do.guild", "guild quest", true) + tk("quest.do.daily", "dailies", true) + tk("quest.do.weekly", "weeklies", true) + tk("quest.do.ghostship", "ghost ship", true)
           + tk("quest.do.starfall", "starfall", true) + tk("quest.do.main", "main quests", true) + tk("quest.do.side", "side quests", true) + tk("quest.do.building", "building-bonus loops", true)
           + '<span style="color:#888">· </span>' + tk("quest.claim.on", "claim", true) + tk("quest.start.on", "start", true) + tk("quest.collect.on", "collectibles", true) + tk("quest.select.on", "icons", true) + '</div></div>';
        return h;
    }
    /* 0.1.78: the quest manager's own selection block — switch, what, how; event quests gated (quest 0.1.24) */
    function DMA_questSelBlock(Q, n) {
        var on = DMA_pol("quest.auto", false) === true, w = null, gate = null, cnt = {};
        try { w = Q && Q.watch ? Q.watch() : null; } catch (_) {}
        try { gate = Q && Q.eventGate ? Q.eventGate() : null; } catch (_) {}
        ((w && w.categories) || []).forEach(function (c) { cnt[c.category] = c.open; });
        function tk(id, label, dflt, dis, why) {
            var v = DMA_pol(id, dflt), chk = dflt ? v !== false : v === true;
            return '<label style="font-weight:normal;margin-right:12px;' + (dis ? 'color:#777;' : '') + '"' + (why ? ' title="' + DMA_esc(why) + '"' : '') + '><input type="checkbox" class="dma-sel-rule" data-rule="' + id + '"' + (chk ? " checked" : "") + (dis ? " disabled" : "") + '> ' + DMA_esc(label) + '</label>';
        }
        function cat(id, label) { var k = cnt[id]; return tk("quest.do." + id, label + (k != null ? " (" + k + ")" : ""), true, !on, on ? "" : "Quest switch off"); }
        var evDis = !on || !gate || !gate.selectable, evWhy = gate ? gate.reason : "quest manager not loaded";
        var ev = tk("quest.do.event", "event quests" + (gate ? " (" + gate.present + ")" : ""), true, evDis, evWhy)
               + (gate && gate.reason && gate.reason !== "event quests not selected" ? '<span style="color:#fc9;margin-right:12px;">— ' + DMA_esc(gate.reason) + '</span>' : '');
        return '<div style="border:1px solid #2a7a7a;padding:6px;margin-bottom:8px;color:#ccc;">'
             + '<div style="margin-bottom:4px;"><b>' + tk("quest.auto", "Quest manager on (auto)", false) + '</b>'
             + (on ? '<span style="color:#8f8">on — it does what is ticked below</span>' : '<span style="color:#e88">off — nothing is claimed, started, paid or picked up; the book is only read</span>') + '</div>'
             + '<div><span style="color:#aaa;margin-right:6px;">What:</span>' + cat("guild", "guild quest") + cat("daily", "dailies") + cat("weekly", "weeklies") + cat("ghostship", "ghost ship")
             + cat("starfall", "starfall") + ev + cat("main", "main quests") + cat("side", "side quests") + cat("building", "building-bonus loops") + '</div>'
             + '<div style="margin-top:3px;"><span style="color:#aaa;margin-right:6px;">How:</span>' + tk("quest.claim.on", "claim finished quests", true, !on) + tk("quest.start.on", "start new quests", true, !on)
             + tk("quest.pay.on", "pay guild quests from storage", true, !on) + tk("quest.collect.on", "collectibles", true, !on) + tk("quest.select.on", "icons over buildings", true, !on)
             + tk("quest.pickup.on", "pick up productions", true, !on)
             + 'every <input type="number" class="dma-in" id="DMA_questEvery" value="' + DMA_esc(String(DMA_pol("quest.collectEveryMin", 10))) + '" style="width:50px"> min · '
             + 'collectibles now: ' + (n == null ? "?" : n) + ' <button type="button" class="btn btn-default btn-xs" id="DMA_questCollect"' + (n ? "" : " disabled") + '>Pick up now</button></div></div>';
    }
    /* 0.1.30: the QUEST page (ADR 0016 Q-1) — the quest book as facts, the rules beside them */
    function DMA_questBody() {
        var Q = root.DMA_Quest, qs = [], st = {}, n = null;
        var sel = []; try { qs = Q ? Q.quests() : []; st = Q ? Q.status() : {}; n = Q && Q.collectibles ? Q.collectibles() : null; sel = Q && Q.selectables ? Q.selectables() : []; } catch (_) {}
        if (n != null) n += sel.length;   // 0.1.32: icons over buildings count as things to pick up
        var h = DMA_questSelBlock(Q, n)   // 0.1.78: the quest manager's own selection block
              + DMA_questWatchBlock(Q)   // 0.1.77
              + (function () { var td = []; try { td = Q && Q.todo ? Q.todo() : []; } catch (_) {} if (!td.length) return '';   // 0.1.75: the to-do list, urgent first (quest 0.1.19)
                  function left(m) { if (m == null) return 'no end'; if (m < 0) return 'ended'; if (m < 120) return m + ' min'; if (m < 2880) return Math.round(m / 60) + ' h'; return Math.round(m / 1440) + ' d'; }
                  return '<div style="margin-bottom:6px;"><b style="color:#fc9">To do — urgent first (' + td.length + ')</b><table class="table table-condensed" style="font-size:11px;color:#ddd;margin:2px 0 0;"><thead><tr><th>Time left</th><th>Kind</th><th>Quest</th><th>Open tasks</th></tr></thead><tbody>'
                       + td.slice(0, 30).map(function (x) { return '<tr' + (x.needsYou ? ' style="background:#3a2a1a"' : '') + '><td>' + (x.rewardReady ? '<b style="color:#fc6">reward ready</b>' : DMA_esc(left(x.minutesLeft))) + '</td><td>' + DMA_esc(x.category) + '</td><td>' + DMA_esc(x.quest) + '</td><td>'
                           + (x.open || []).map(function (t) { return '<div>' + (t.text ? DMA_esc(t.text) : DMA_esc(t.task) + (t.what ? ' ' + DMA_esc(t.what) : '') + (t.amount ? ' ' + DMA_esc(String(t.amount)) : '')) + (t.by === "needs you" ? ' <b style="color:#fc9">[needs you]</b>' : ' <span style="color:#8cf">[' + DMA_esc(t.by) + ']</span>') + '</div>'; }).join("") + '</td></tr>'; }).join("")
                       + '</tbody></table>' + (td.length > 30 ? '<div style="color:#999;font-size:11px">… ' + (td.length - 30) + ' more</div>' : '') + '</div>'; })()
              + '<div style="color:#aaa;font-size:11px;margin-bottom:4px;">The DMA never finishes a quest with gems. Claimed ' + (st.claimed || 0) + ' · failed ' + (st.failed || 0) + ' · collectibles picked up ' + (st.collectSent || 0)
              + (st.lastError ? ' · <span style="color:#e88">' + DMA_esc(st.lastError) + '</span>' : '') + '</div>'
              + '<table class="table table-condensed" style="font-size:11px;color:#ddd;"><thead><tr><th>Quest</th><th>Kind</th><th>State</th><th>Tasks (✓ done · DMA can do it)</th></tr></thead><tbody>';
        if (!qs.length) h += '<tr><td colspan="4" style="color:#999">' + (Q ? "no quests read yet" : "user_dma_quest.js not loaded") + '</td></tr>';
        qs.forEach(function (q) {
            var tasks = (q.tasks || []).map(function (t) {
                return '<div>' + (t.done ? '<span style="color:#8f8">✓</span> ' : '· ') + (t.text ? DMA_esc(t.text) : DMA_esc(t.kind) + (t.what ? ' ' + DMA_esc(t.what) : '') + (t.amount ? ' ' + DMA_esc(String(t.amount)) : ''))
                     + (t.done ? '' : (t.can ? ' <span style="color:#8cf">[' + DMA_esc(t.can) + ']</span>' : ' <span style="color:#999">[by hand]</span>')) + '</div>';
            }).join("");
            h += '<tr' + (q.kind === "Guild" ? ' style="background:#2a3a2a"' : '') + '><td>' + DMA_esc(q.title || q.name) + '</td><td>' + DMA_esc(q.kind) + '</td><td>'
               + (q.reward ? '<b style="color:#fc6">reward ready</b>' : DMA_esc(q.state)) + '</td><td>' + tasks + '</td></tr>';
        });
        h += '</tbody></table><div id="DMA_questMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        return h;
    }
    /* 0.1.72 (ADR 0047): the VALUE page — own cost of every good through its production chain */
    var DMA_valueOpen = {}, DMA_valueSort = "value", DMA_valueFilter = "";
    function DMA_valueFmt(n) { if (n == null) return "?"; if (n >= 100) return String(Math.round(n)); if (n >= 10) return n.toFixed(1); if (n >= 1) return n.toFixed(2); return n.toFixed(3); }
    function DMA_valueChain(res) {
        var V = root.DMA_Value, st = V && V.state(), r = st && st.result; if (!r) return "";
        var rows = V.chain(r, res), top = rows.length ? rows[0].seconds : 1, h = '<div class="dma-vl-chain">';
        rows.forEach(function (c) {
            var share = top ? Math.max(1, Math.round(100 * (c.seconds || 0) / top)) : 0;
            h += '<div class="dma-vl-crow" style="padding-left:' + (8 + c.depth * 16) + 'px">'
               + '<span class="dma-vl-camt">' + DMA_valueFmt(c.amount) + ' x</span> <b>' + DMA_esc(V.label(c.resource)) + '</b>'
               + (c.finite ? ' <span class="dma-vl-fin">finite</span>' : '')
               + '<span class="dma-vl-cmin">' + (c.seconds == null ? "unknown" : DMA_valueFmt(c.seconds / 60) + ' min' + (c.building ? ' · ' + DMA_esc(c.building) : '')) + '</span>'
               + '<div class="dma-vl-cbar"><div style="width:' + share + '%"></div></div></div>';
        });
        return h + '</div>';
    }
    function DMA_valueBody() {
        var V = root.DMA_Value;
        var css = '<style>.dma-vl{font-size:12px;color:#ddd}.dma-vl-h{margin:4px 0 8px;color:#aaa}.dma-vl-note{color:#e0a030;margin:4px 0}'
            + '.dma-vl-row{cursor:pointer;padding:3px 4px;border-bottom:1px solid #333}.dma-vl-row:hover{background:#2a2f36}'
            + '.dma-vl-name{display:inline-block;width:150px}.dma-vl-bar{display:inline-block;width:230px;height:9px;background:#2a2a2a;vertical-align:middle;margin:0 8px}'
            + '.dma-vl-bar div{height:9px;background:#7aa83a}.dma-vl-coin{display:inline-block;width:70px;text-align:right;color:#f0c040}'
            + '.dma-vl-min{display:inline-block;width:90px;text-align:right;color:#9cf}.dma-vl-bld{display:inline-block;width:150px;color:#999;padding-left:8px}'
            + '.dma-vl-fin{color:#e88;font-size:11px}.dma-vl-chain{background:#1e2226;margin:2px 0 6px 18px;padding:4px 0}'
            + '.dma-vl-crow{padding:1px 0}.dma-vl-camt{display:inline-block;width:60px;text-align:right;color:#aaa}.dma-vl-cmin{color:#9cf;margin-left:8px}'
            + '.dma-vl-cbar{display:inline-block;width:120px;height:6px;background:#2a2a2a;margin-left:8px;vertical-align:middle}.dma-vl-cbar div{height:6px;background:#f0c040}</style>';
        if (!V) return css + '<div class="dma-vl">The value module is not loaded (user_dma_value.js).</div>';
        var st = V.state(), r = st.result, list = r.list.slice();
        if (DMA_valueSort === "name") list.sort(function (a, b) { return V.label(a.resource) < V.label(b.resource) ? -1 : 1; });
        if (DMA_valueFilter) { var f = DMA_valueFilter.toLowerCase(); list = list.filter(function (x) { return V.label(x.resource).toLowerCase().indexOf(f) >= 0 || x.resource.toLowerCase().indexOf(f) >= 0; }); }
        var max = Math.log(1 + r.list[0].seconds), h = css + '<div class="dma-vl">';
        h += '<div class="dma-vl-h">Own cost through the whole production chain, at level 1, standard buildings. 1 coin = '
           + DMA_valueFmt(r.coinSeconds / 60) + ' building-minutes. Source: ' + (st.source === "game" ? 'the game (read now)' : 'registered copy of ' + DMA_esc(st.read)) + '.</div>';
        if (st.diff && st.diff.length) h += '<div class="dma-vl-note">The game\'s definitions differ from the registered copy in ' + st.diff.length + ' buildings (' + DMA_esc(st.diff.slice(0, 4).map(function (d) { return d.building + " " + d.change; }).join(", ")) + '). The values follow the game.</div>';
        if (r.unknown.length) h += '<div class="dma-vl-h">No standard way to make: ' + DMA_esc(r.unknown.join(", ")) + '.</div>';
        h += '<div style="margin-bottom:6px">Sort <select id="DMA_valueSort"><option value="value"' + (DMA_valueSort === "value" ? " selected" : "") + '>value</option><option value="name"' + (DMA_valueSort === "name" ? " selected" : "") + '>name</option></select>'
           + ' Find <input id="DMA_valueFind" class="dma-in" style="width:140px" value="' + DMA_esc(DMA_valueFilter) + '"> <span style="color:#888">click a good for its chain</span></div>';
        h += '<div style="color:#888;padding:0 4px"><span class="dma-vl-name">good</span><span class="dma-vl-bar" style="background:none;height:auto">value (log scale)</span><span class="dma-vl-coin">coins</span><span class="dma-vl-min">minutes</span><span class="dma-vl-bld">made in</span></div>';
        list.forEach(function (x) {
            var w = Math.max(1, Math.round(100 * Math.log(1 + x.seconds) / max)), fin = Object.keys(x.finite);
            h += '<div class="dma-vl-row" data-res="' + DMA_esc(x.resource) + '"><span class="dma-vl-name">' + (DMA_valueOpen[x.resource] ? '▾ ' : '▸ ') + DMA_esc(V.label(x.resource)) + '</span>'
               + '<span class="dma-vl-bar"><div style="width:' + w + '%"></div></span><span class="dma-vl-coin">' + DMA_valueFmt(x.coins) + '</span>'
               + '<span class="dma-vl-min">' + DMA_valueFmt(x.minutes) + '</span><span class="dma-vl-bld">' + DMA_esc(x.building) + '</span>'
               + (fin.length ? ' <span class="dma-vl-fin">finite: ' + DMA_esc(fin.map(function (k) { return DMA_valueFmt(x.finite[k]) + " " + V.label(k); }).join(", ")) + '</span>' : '') + '</div>';
            if (DMA_valueOpen[x.resource]) h += DMA_valueChain(x.resource);
        });
        return h + '</div>';
    }
    /* 0.1.79: the TX page — every transaction and its real status (transactions 0.4.9) */
    var DMA_txKind = "", DMA_txOnlyCheck = false, DMA_txOpenKinds = {}, DMA_txOpenRows = {};
    var DMA_txLive = true, DMA_txTimer = null, DMA_txSeen = null, DMA_TX_LIVE_MS = 5000;   // 0.1.83: the live board   // 0.1.80: opened kinds; 0.1.81: opened transactions
    /* 0.1.81 (1): who acts next and under which rule */
    function DMA_txNext(tk, state) {
        if (state === "declined" || state === "rejected") return '<span style="color:#888">none — ends unless renewed</span>';
        var R = root.DMA_Rules, t = null; try { t = R && R.of ? R.of(tk) : null; } catch (_) {}
        if (!t) return '<span style="color:#888">not in the model</span>';
        var rs = t.rules.filter(function (a) { return a.onState === state; }); if (!rs.length) return '<span style="color:#888">no rule</span>';
        var types = [], who = [];
        rs.forEach(function (a) { if (types.indexOf(a.type) < 0) types.push(a.type); if (who.indexOf(a.performer) < 0) who.push(a.performer); });
        return '<span title="' + DMA_esc(rs.map(function (a) { return a.id + ": " + a.typeName; }).join(" | ")) + '"><b style="color:#fc9">Type ' + DMA_esc(types.join(" / ")) + '</b> · ' + DMA_esc(who.join(", ")) + '</span>';
    }
    /* 0.1.81 (5): the history of one transaction */
    function DMA_txHistory(r) {
        return '<div style="font-size:11px;">' + (r.history || []).map(function (x) {
            return '<div><span style="color:#888">' + DMA_txTime(x.at) + (x.n > 1 ? ' … ' + DMA_txTime(x.last) : '') + '</span> <b>' + DMA_esc(x.act) + '</b>' + (x.n > 1 ? ' ×' + x.n : '')
                 + (x.actor ? ' <span style="color:#aaa">(' + DMA_esc(x.actor) + ')</span>' : '') + (x.reason ? ' — <span style="color:#fc9">' + DMA_esc(x.reason) + '</span>' : '') + (x.outcome ? ' — ' + DMA_esc(x.outcome) : '') + '</div>';
        }).join("") + '</div>';
    }
    /* 0.1.81 (2): the player's settings the rules of a kind read */
    function DMA_txSettings(t) {
        var P = root.GCAF_PlayerPolicyInstance, es = []; try { es = P && P.entries ? P.entries(t.params || []) : []; } catch (_) {}
        if (!(t.params || []).length) return '';
        return '<div style="margin-top:4px;"><b style="color:#8f8">Player settings these rules read</b>' + (es.length ? es.map(function (e) {
            var v = e.value; v = v === true ? "on" : v === false ? "off" : (v == null || v === "") ? "—" : String(v);
            return '<div><code style="color:#ddd;background:none;">' + DMA_esc(e.ruleId) + '</code> = <b>' + DMA_esc(v) + '</b>' + (e.label ? ' <span style="color:#aaa">' + DMA_esc(e.label) + '</span>' : '') + '</div>';
        }).join("") : '<div style="color:#888">none set</div>') + '</div>';
    }
    /* 0.1.80: the business rules of one transaction kind (DMA_Rules from the essential model) */
    function DMA_txRules(tk) {
        var R = root.DMA_Rules, t = null; try { t = R && R.of ? R.of(tk) : null; } catch (_) {}
        if (!R) return '<div style="color:#e88">The rules catalogue (user_dma_rules.js) is not loaded.</div>';
        if (!t) return '<div style="color:#aaa">' + DMA_esc(tk) + ' is not in the essential model (dma-bundle.yaml) yet: no business rules to show.</div>';
        function part(label, xs) { return xs && xs.length ? '<div><span style="color:#aaa">' + label + ':</span> ' + xs.map(DMA_esc).join("; ") + '</div>' : ''; }
        var h = '<div style="color:#ccc;margin-bottom:4px;"><b>' + DMA_esc(tk + " " + t.name) + '</b> — product <i>' + DMA_esc(t.pk + " " + t.product) + '</i> — executor ' + DMA_esc(t.executor) + '</div>';
        h += t.rules.map(function (a) {
            return '<div style="border-left:3px solid #5a3a6a;padding:2px 6px;margin:3px 0;">'
                 + '<div><b style="color:#fc9">Type ' + DMA_esc(a.type) + '</b> <span style="color:#fc9">' + DMA_esc(a.typeName) + '</span> — ' + DMA_esc(a.id) + ' · on ' + DMA_esc(a.on) + ' (' + DMA_esc(a.onState) + ') · performer ' + DMA_esc(a.performer) + '</div>'
                 + part("when", [a.when]) + part("while", a["while"]) + part("given", a.given)
                 + part("rightness", a.rightness) + part("sincerity", a.sincerity) + part("truth", a.truth)
                 + part("then", a.then) + part("else", a["else"]) + '</div>';
        }).join("") || '<div style="color:#aaa">no action rules in the model</div>';
        h += DMA_txSettings(t);   // 0.1.81 (2)
        if (t.laws.length) h += '<div style="margin-top:4px;"><b style="color:#8cf">Existence laws on ' + DMA_esc(t.pk) + '</b>' + t.laws.map(function (l) { return '<div><b>' + DMA_esc(l.id) + '</b> <span style="color:#aaa">(' + DMA_esc(l.kind) + ')</span> ' + DMA_esc(l.statement) + (l.formal ? ' <span style="color:#888">' + DMA_esc(l.formal) + '</span>' : '') + '</div>'; }).join("") + '</div>';
        return '<div style="font-size:11px;">' + h + '<div style="color:#777;margin-top:2px;">Source: ' + DMA_esc(R.source.bundle) + ' · ARS types: ' + DMA_esc(R.source.types) + '</div></div>';
    }
    function DMA_txAge(m) { if (m == null) return "?"; if (m < 60) return m + " min"; if (m < 2880) return (Math.round(m / 6) / 10) + " h"; return Math.round(m / 1440) + " d"; }
    function DMA_txTime(ms) { if (!ms) return ""; var d = new Date(ms); return d.toISOString ? d.toISOString().slice(5, 16).replace("T", " ") : String(d); }
    function DMA_txBody() {
        var T = root.DMA_Tx, o = null; try { o = T && T.overview ? T.overview() : null; } catch (_) {}
        if (!o) return '<div style="color:#e88">The transaction book (user_dma_transactions.js 0.4.9) is not loaded.</div>';
        var col = { requested: "#fc9", promised: "#8cf", declared: "#cf8", declined: "#e88", rejected: "#e88", accepted: "#8f8" };
        /* 0.1.82: every kind of the model and every kind in the book, grouped by entity type (PBC) */
        var RR = root.DMA_Rules, NIM = "NOT IN THE MODEL", byTk = {}, groups = {}, gOrder = [];
        o.kinds.forEach(function (k) { byTk[k.tk] = k; });
        var all = (RR && RR.kinds ? RR.kinds() : []).slice(); o.kinds.forEach(function (k) { if (all.indexOf(k.tk) < 0) all.push(k.tk); });
        function entOf(tk) { var e = ""; try { e = RR && RR.entityOf ? RR.entityOf(tk) : ""; } catch (_) {} return e || NIM; }
        all.forEach(function (tk) { var e = entOf(tk); if (!groups[e]) { groups[e] = []; gOrder.push(e); } groups[e].push(tk); });
        gOrder.sort(function (a, b) { return a === NIM ? 1 : b === NIM ? -1 : 0; });
        function info(tk) { var k = byTk[tk]; if (k) return k; var t = null; try { t = RR.of(tk); } catch (_) {} return { tk: tk, name: t ? t.name : "", product: t ? t.pk + " " + t.product : "", open: 0, states: {}, oldestMin: 0, checks: 0 }; }
        function st(s) { return '<b style="color:' + (col[s] || "#ddd") + '">' + DMA_esc(s) + '</b>'; }
        var h = '<div style="color:#ccc;margin-bottom:6px;">Every transaction the DMA keeps, from its coordination facts (C-facts). ' + o.open.length + ' in progress'
              + (o.checks ? ' · <b style="color:#fc9">' + o.checks + ' need a check</b>' : ' · none needs a check') + ' · ' + o.closed.length + ' recently closed. '
              + 'Kind <select id="DMA_txKind"><option value="">all</option>' + gOrder.map(function (g) { return '<optgroup label="' + DMA_esc(g) + '">' + groups[g].map(function (tk) { var k = info(tk); return '<option value="' + DMA_esc(tk) + '"' + (DMA_txKind === tk ? " selected" : "") + '>' + DMA_esc(tk + " " + k.name) + (k.open ? " (" + k.open + ")" : "") + '</option>'; }).join("") + '</optgroup>'; }).join("") + '</select> '
              + '<label style="font-weight:normal"><input type="checkbox" id="DMA_txOnly"' + (DMA_txOnlyCheck ? " checked" : "") + '> only what needs a check</label></div>';
        h += '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin-bottom:6px;"><thead><tr><th>Kind</th><th>Transaction</th><th>Product</th><th>In progress</th><th>By state</th><th>Oldest</th><th>Check</th></tr></thead><tbody>'
           + gOrder.map(function (g) {
               var ks = groups[g].map(info), n = 0, c = 0; ks.forEach(function (k) { n += k.open; c += k.checks; });
               return '<tr style="background:#2a2a3a;"><td colspan="7"><b style="color:#cdf">' + DMA_esc(g) + '</b> <span style="color:#aaa">' + ks.length + ' kind' + (ks.length === 1 ? "" : "s") + ' · ' + n + ' in progress' + (c ? ' · <b style="color:#fc9">' + c + ' to check</b>' : '') + '</span></td></tr>'
               + ks.map(function (k) { var op = !!DMA_txOpenKinds[k.tk]; return '<tr' + (k.open ? '' : ' style="color:#888"') + '><td><a href="#" class="dma-tx-toggle" data-tk="' + DMA_esc(k.tk) + '" style="color:#fc9;text-decoration:none;" title="show the business rules">' + (op ? "&#9662;" : "&#9656;") + '</a> ' + DMA_esc(k.tk) + '</td><td>' + DMA_esc(k.name) + '</td><td style="color:#aaa">' + DMA_esc(k.product) + '</td><td>' + k.open + '</td><td>'
               + Object.keys(k.states).map(function (s) { return st(s) + ' ' + k.states[s]; }).join(" · ") + '</td><td>' + DMA_txAge(k.oldestMin) + '</td><td>' + (k.checks ? '<b style="color:#fc9">' + k.checks + '</b>' : '') + '</td></tr>'
               + (k.tk === "TK64" ? DMA_txBatchRow() : "")   // 0.1.90: the open production batches asked of the player
               + (op ? '<tr><td colspan="7" style="background:#221a2a;">' + DMA_txRules(k.tk) + '</td></tr>' : ''); }).join(""); }).join("")
           + '</tbody></table>';
        var gi = {}; gOrder.forEach(function (g, i) { groups[g].forEach(function (tk) { gi[tk] = i; }); });
        var seen = {};   // 0.1.83
        var rows = o.open.filter(function (r) { return (!DMA_txKind || r.tk === DMA_txKind) && (!DMA_txOnlyCheck || r.check); })
            .sort(function (a, b) { return ((gi[a.tk] || 0) - (gi[b.tk] || 0)) || (a.tk < b.tk ? -1 : a.tk > b.tk ? 1 : 0) || (b.ageMin - a.ageMin); });   // 0.1.82
        h += '<b style="color:#fc9">In progress (' + rows.length + ')</b><table class="table table-condensed" style="font-size:11px;color:#ddd;margin:2px 0 6px;"><thead><tr><th>Kind</th><th>Instance</th><th>State</th><th>For</th><th>Initiator</th><th>Last act</th><th>Next: rule · who</th><th>Check / why</th></tr></thead><tbody>'
           + rows.slice(0, 150).map(function (r) { var id = "o:" + r.tk + "@" + r.key, op = !!DMA_txOpenRows[id];
               var fresh = DMA_txSeen && DMA_txSeen[id] !== r.lastAt; seen[id] = r.lastAt;   // 0.1.83: new or acted since the last redraw
               return '<tr' + (fresh ? ' style="background:#3a3a10"' : r.check ? ' style="background:#3a2a1a"' : '') + '><td title="' + DMA_esc(entOf(r.tk) + " · " + r.name) + '"><a href="#" class="dma-tx-row" data-id="' + DMA_esc(id) + '" style="color:#fc9;text-decoration:none;" title="show its history">' + (op ? "&#9662;" : "&#9656;") + '</a> ' + DMA_esc(r.tk) + '</td><td>' + DMA_esc(r.key) + '</td><td>' + st(r.state) + '</td><td>' + DMA_txAge(r.ageMin)
               + '</td><td>' + DMA_esc(r.initiator) + '</td><td>' + DMA_esc(r.lastAct) + (r.lastActor ? ' <span style="color:#aaa">(' + DMA_esc(r.lastActor) + ')</span>' : '') + ' <span style="color:#888">' + DMA_txTime(r.lastAt) + '</span></td><td>' + DMA_txNext(r.tk, r.state)
               + '</td><td style="color:#fc9">' + DMA_esc(r.check || (r.reason ? "why: " + r.reason : "")) + '</td></tr>'
               + (op ? '<tr><td colspan="8" style="background:#221a2a;">' + DMA_txHistory(r) + '</td></tr>' : ''); }).join("")
           + (rows.length ? '' : '<tr><td colspan="8" style="color:#999">none</td></tr>') + '</tbody></table>';
        o.open.forEach(function (r) { var id = "o:" + r.tk + "@" + r.key; if (!(id in seen)) seen[id] = r.lastAt; });
        DMA_txSeen = seen;   // 0.1.83: the base for the next redraw
        var cl = o.closed.filter(function (r) { return !DMA_txKind || r.tk === DMA_txKind; });
        h += '<b style="color:#aaa">Recently closed (' + cl.length + ')</b><table class="table table-condensed" style="font-size:11px;color:#bbb;margin:2px 0 0;"><thead><tr><th>Kind</th><th>Instance</th><th>Ended</th><th>At</th><th>Initiator</th><th>Why</th></tr></thead><tbody>'
           + cl.slice(0, 50).map(function (r) { var id = "c:" + r.tk + "@" + r.key + "@" + r.closedAt, op = !!DMA_txOpenRows[id];
               return '<tr><td title="' + DMA_esc(r.name) + '"><a href="#" class="dma-tx-row" data-id="' + DMA_esc(id) + '" style="color:#aaa;text-decoration:none;" title="show its history">' + (op ? "&#9662;" : "&#9656;") + '</a> ' + DMA_esc(r.tk) + '</td><td>' + DMA_esc(r.key) + '</td><td>' + (r.end === "accepted" ? st("accepted") : DMA_esc(r.end)) + '</td><td>' + DMA_txTime(r.closedAt) + '</td><td>' + DMA_esc(r.initiator) + '</td><td style="color:#fc9">' + DMA_esc(r.reason || "") + '</td></tr>'
               + (op ? '<tr><td colspan="6" style="background:#1e1e1e;">' + DMA_txHistory(r) + '</td></tr>' : ''); }).join("")
           + '</tbody></table><div style="color:#888;font-size:11px;margin-top:4px;">States follow the DEMO transaction pattern: requested → promised → declared → accepted; declined and rejected end it unless renewed. Times UTC. Read-only.</div>';
        return h;
    }
    function DMA_openTx() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        DMA_txSeen = null;
        var re = function () {   // 0.1.83: keep the scroll position; stamp the redraw
            var $b = $(DMA_BODY), top = $b.scrollTop(), $sc = $b.closest(".modal-body"), top2 = $sc.length ? $sc.scrollTop() : 0;
            $b.html(DMA_txBody());
            $b.scrollTop(top); if ($sc.length) $sc.scrollTop(top2);
            var d = new Date(); $("#DMA_txUpdated").text("updated " + (d.toISOString ? d.toISOString().slice(11, 19) : String(d)) + " UTC");
        };
        function stopLive() { if (DMA_txTimer) { clearInterval(DMA_txTimer); DMA_txTimer = null; } }
        function startLive() {
            stopLive(); if (!DMA_txLive) return;
            DMA_txTimer = setInterval(function () {
                try {
                    if (!$(DMA_MODAL).is(":visible") || $(DMA_MODAL + " .modal-title").text() !== "Transactions") { stopLive(); return; }
                    if ($("#DMA_txKind").is(":focus")) return;   // the kind list is open: do not close it under the mouse
                    re();
                } catch (_) { stopLive(); }
            }, DMA_TX_LIVE_MS);
        }
        re();
        $(DMA_MODAL + " .modal-footer").html('<span style="float:left;color:#ccc;font-size:11px;margin-top:6px;"><label style="font-weight:normal;margin-right:8px;"><input type="checkbox" id="DMA_txLive"' + (DMA_txLive ? " checked" : "") + '> Live (every ' + (DMA_TX_LIVE_MS / 1000) + ' s)</label><span id="DMA_txUpdated"></span></span>'
            + '<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-default btn-sm" id="DMA_txRefresh">Refresh</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Transactions");
        re(); startLive();
        $(DMA_MODAL).off("hidden.bs.modal.tx").on("hidden.bs.modal.tx", function () { stopLive(); });
        $(DMA_BODY).off("change.tx").on("change.tx", "#DMA_txKind", function () { DMA_txKind = String(this.value || ""); re(); })
            .on("change.tx", "#DMA_txOnly", function () { DMA_txOnlyCheck = !!this.checked; re(); })
            .off("click.tx").on("click.tx", ".dma-tx-toggle", function (ev) { ev.preventDefault(); var tk = String($(this).attr("data-tk") || ""); if (DMA_txOpenKinds[tk]) delete DMA_txOpenKinds[tk]; else DMA_txOpenKinds[tk] = true; re(); })   // 0.1.80
            .on("click.tx", ".dma-tx-row", function (ev) { ev.preventDefault(); var id = String($(this).attr("data-id") || ""); if (DMA_txOpenRows[id]) delete DMA_txOpenRows[id]; else DMA_txOpenRows[id] = true; re(); });   // 0.1.81
        $(DMA_MODAL + " .modal-footer").off("click.tx").on("click.tx", "#DMA_txRefresh", function () { re(); })
            .on("click.tx", "#DMA_geoBack", function () { stopLive(); })
            .off("change.tx").on("change.tx", "#DMA_txLive", function () { DMA_txLive = !!this.checked; if (DMA_txLive) startLive(); else stopLive(); });   // 0.1.83
        DMA_log("transactions screen");
        return true;
    }
    /* 0.1.90 (author-requested): the TROOPS page — per unit kind the army, what is in training and the player's TARGET strength (unit.<Kind>.targetStrength, AT79) */
    var DMA_TROOP_GROUPS = [["normal", "Normal"], ["elite", "Elite"], ["expedition", "Expedition"]];   // labels of the three groups (the group of a unit comes from the game)
    /* 0.1.92: the choice lives in this variable (the source of truth for the session) and is persisted through the policy store (console.troops.<group>.show,
       dma-policy.json: survives a restart), like the BUFF screen since 0.1.9. localStorage is NOT used: the client's does not hold. */
    var DMA_troopsView = { normal: true, elite: true, expedition: true }, DMA_troopsViewLoaded = false;
    function DMA_troopsViewLoad() {   // once per module: what the policy store remembers; retried while the policy is not loaded
        if (DMA_troopsViewLoaded) return;
        var p = policy(); if (!p || typeof p.get !== "function") return;
        DMA_TROOP_GROUPS.forEach(function (g) { try { if (p.get("console.troops." + g[0] + ".show") === false) DMA_troopsView[g[0]] = false; } catch (_) {} });
        DMA_troopsViewLoaded = true;
    }
    function DMA_troopsFilter(given) {   // { normal, elite, expedition: bool }, all on by default
        if (given && typeof given === "object") { var f = { normal: true, elite: true, expedition: true }; DMA_TROOP_GROUPS.forEach(function (g) { if (given[g[0]] === false) f[g[0]] = false; }); return f; }
        DMA_troopsViewLoad();
        return { normal: DMA_troopsView.normal, elite: DMA_troopsView.elite, expedition: DMA_troopsView.expedition };
    }
    function DMA_troopsToggle(group) {   // flip one group, keep it in the variable, write it to the policy store; returns the new filter
        DMA_troopsViewLoad(); if (!DMA_troopsView.hasOwnProperty(group)) return DMA_troopsFilter();
        DMA_troopsView[group] = !DMA_troopsView[group];
        try { var p = policy(); if (p && typeof p.requestChange === "function") p.requestChange("console.troops." + group + ".show", DMA_troopsView[group]); } catch (_) {}
        return DMA_troopsFilter();
    }
    function DMA_troopState(army, training, target) {   // "short" (red) | "producing" (orange) | "ok" (green) | null (no target)
        if (target == null) return null;
        if (army >= target) return "ok";
        return training > 0 ? "producing" : "short";
    }
    var DMA_TROOP_COLOUR = { short: "#e88", producing: "#e0a030", ok: "#8f8" };
    var DMA_unitIconCache = {};
    function DMA_unitIcon(unit, getTag) {   // 0.1.91: the client's own icon for a unit name, or "" (never drawn here); a hit is cached per unit
        if (DMA_unitIconCache.hasOwnProperty(unit)) return DMA_unitIconCache[unit];
        var tag = ""; try { var f = getTag || (typeof getImageTag === "function" ? getImageTag : null); if (f) tag = f(unit, "24px"); } catch (_) { tag = ""; }
        tag = typeof tag === "string" ? tag : (tag ? String(tag) : "");
        if (tag.replace(/\s+/g, "") === "") return "";
        DMA_unitIconCache[unit] = tag; return tag;
    }
    function DMA_troopsModel(src) {   // pure: { rows: [{ unit, army, training, target, editable }], read: bool, note }
        src = src || {};
        var pic = src.pic !== undefined ? src.pic : (function () { try { return root.DMA_Demo && root.DMA_Demo.troops ? root.DMA_Demo.troops() : null; } catch (_) { return null; } })();
        var T = root.DMA_Troops, tr = {}; try { tr = src.training || (T && T.training ? T.training(pic) : {}); } catch (_) { tr = {}; }
        var army = (pic && pic.free) || src.army || {}, targets = src.targets, kinds = {}, k;
        if (!targets) { targets = {}; var p = policy();
            try { if (p && typeof p.entries === "function") p.entries(["^unit\\.[A-Za-z0-9_]+\\.targetStrength$"]).forEach(function (e) { var kk = String(e.ruleId).split(".")[1]; if (e.value !== "" && e.value != null && !isNaN(Number(e.value))) targets[kk] = Number(e.value); }); } catch (_) {} }
        var known = src.kinds; if (!known) { try { var U = root.DMA_UnitInputs; known = U && typeof U.all === "function" ? Object.keys(U.all()) : []; } catch (_) { known = []; } }
        [army, tr, targets].forEach(function (m) { for (k in m) if (Object.prototype.hasOwnProperty.call(m, k)) kinds[k] = true; });
        known.forEach(function (u) { kinds[u] = true; });
        var groupOf = src.group || function (u) { try { var UI_ = root.DMA_UnitInputs; return UI_ && typeof UI_.group === "function" ? UI_.group(u) : null; } catch (_) { return null; } };
        var filter = DMA_troopsFilter(src.filter);
        var rows = Object.keys(kinds).sort().map(function (u) {
            var g = groupOf(u) || null, a = Number(army[u]) || 0, t = Number(tr[u]) || 0, tg = targets[u] != null ? Number(targets[u]) : null;
            return { unit: u, group: g, army: a, training: t, target: tg, state: DMA_troopState(a, t, tg), editable: /^[A-Za-z0-9_]+$/.test(u) && g !== "expedition", icon: DMA_unitIcon(u, src.getImageTag) };
        });
        var order = ["normal", "elite", "expedition"], rank = function (r) { var i = order.indexOf(r.group); return i < 0 ? 3 : i; };
        rows.sort(function (x, y) { return rank(x) - rank(y) || (x.unit < y.unit ? -1 : x.unit > y.unit ? 1 : 0); });   // 0.1.92: the rows follow the sections Normal, Elite, Expedition, Other
        var sections = DMA_TROOP_GROUPS.map(function (g) { return { group: g[0], label: g[1], toggle: true }; }).concat([{ group: null, label: "Other", toggle: false }]).map(function (sec) {
            var own = rows.filter(function (r) { return (r.group || null) === sec.group || (sec.group === null && order.indexOf(r.group) < 0); });
            sec.total = own.length; sec.shown = sec.group === null || filter[sec.group] !== false; sec.rows = sec.shown ? own : []; return sec; }).filter(function (sec) { return sec.total > 0; });
        var all = rows.length; rows = rows.filter(function (r) { return !r.group || filter[r.group] !== false; });   // 0.1.91: a deselected group is hidden; a kind without a group is always shown
        return { sections: sections, rows: rows, icons: rows.filter(function (r) { return r.icon; }).length, hidden: all - rows.length, filter: filter, read: !!pic, note: pic ? "" : "the location manager has not read the army yet" };
    }
    function DMA_troopsBody(src) {
        var m = DMA_troopsModel(src);
        var h = '<div style="color:#ccc;margin-bottom:6px;">The troop manager trains each unit kind up to its <b>target strength</b> (plus what the next planned adventure will lose). '
              + 'Army = free units now · In training = the row in production and every waiting row · Target = your rule <code>unit.&lt;Kind&gt;.targetStrength</code> (empty = no target). <span id="DMA_troopsMsg" style="margin-left:6px;"></span></div>'
              + (m.note ? '<div style="color:#fc9;margin-bottom:4px;">' + DMA_esc(m.note) + '</div>' : '')
              + '<div style="margin-bottom:6px;color:#999;font-size:11px;">' + (m.hidden ? m.hidden + ' hidden · ' : '') + '<span id="DMA_troopsIcons">icons: ' + m.icons + ' of ' + m.rows.length + '</span></div>'
              + '<table class="table table-condensed" style="font-size:11px;color:#ddd;"><thead><tr><th>Unit kind</th><th>Army</th><th>In training</th><th>Target</th><th>Short</th></tr></thead><tbody>';
        if (!m.sections.length) h += '<tr><td colspan="5" style="color:#999">no unit kinds known yet</td></tr>';
        m.sections.forEach(function (sec) {   // 0.1.92: one section per group, a header row with the group's toggle, the units under it
            h += '<tr class="dma-troops-sec" data-section="' + (sec.group || "other") + '"><td colspan="5" style="background:#2a2a2a;color:#fff;padding:3px 6px;"><b>' + sec.label + '</b> <span style="color:#999">(' + sec.total + ')</span>'
               + (sec.toggle ? ' <button type="button" class="btn btn-xs dma-troops-grp" data-group="' + sec.group + '" title="Show or hide the ' + sec.label.toLowerCase() + ' troops" style="margin-left:8px;background:' + (sec.shown ? "#3a6ea5" : "#444") + ';color:' + (sec.shown ? "#fff" : "#999") + ';">' + (sec.shown ? "shown" : "hidden") + '</button>' : '') + '</td></tr>';
            sec.rows.forEach(function (r) {
                var short = r.target != null ? Math.max(0, r.target - r.army - r.training) : null;
                h += '<tr><td>' + (r.icon ? r.icon + '&nbsp;' : '') + DMA_esc(r.unit) + '</td><td>' + r.army + '</td><td>' + r.training + '</td><td>'
                   + (r.editable ? '<input type="number" min="0" class="dma-troops-target" data-rule="unit.' + DMA_esc(r.unit) + '.targetStrength" value="' + (r.target != null ? r.target : "") + '" style="width:80px;color:#000;' + (r.state ? 'background:' + DMA_TROOP_COLOUR[r.state] + ';' : '') + '" data-state="' + (r.state || "") + '">' : (r.target != null ? '<span data-state="' + (r.state || "") + '"' + (r.state ? ' style="color:' + DMA_TROOP_COLOUR[r.state] + '"' : '') + '>' + r.target + '</span>' : ""))
                   + '</td><td>' + (short ? '<b style="color:#fc9">' + short + '</b>' : (short === 0 ? '<span style="color:#8f8">at strength</span>' : '')) + '</td></tr>';
            });
        });
        return h + '</tbody></table>';
    }
    function DMA_openTroops() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy();
        function save(rule, val) {
            var res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") { $("#DMA_troopsMsg").css("color", "#8f8").text(rule + " = " + (val === "" ? "none" : val) + " saved"); return true; }
            $("#DMA_troopsMsg").css("color", "#e88").text(rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")"); return false;
        }
        $(DMA_BODY).html(DMA_troopsBody());
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-default btn-sm" id="DMA_troopsRefresh">Refresh</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Troops");
        $(DMA_BODY).off("change.tp").on("change.tp", ".dma-troops-target", function () {
            var rule = String($(this).data("rule")), v = String(this.value).trim();
            if (!save(rule, v === "" ? 0 : Number(v))) $(DMA_BODY).html(DMA_troopsBody()); else if (v === "") this.value = "";
        });
        $(DMA_BODY).off("click.tg").on("click.tg", ".dma-troops-grp", function () { DMA_troopsToggle(String($(this).data("group"))); $(DMA_BODY).html(DMA_troopsBody()); });   // 0.1.91
        $(DMA_MODAL + " .modal-footer").off("click.tp").on("click.tp", "#DMA_troopsRefresh", function () { $(DMA_BODY).html(DMA_troopsBody()); });
        DMA_log("troops screen");
        return true;
    }
    /* 0.1.90 (author-requested): the TK64 row of the TX page shows the open production batches the player is asked to make (control 0.2.99:
       allocation.batches(), the list that dma-production-requests.json holds) */
    function DMA_txBatches() {
        try { var C = root.DMA_Control; return C && C.allocation && typeof C.allocation.batches === "function" ? (C.allocation.batches() || []) : null; } catch (_) { return null; }
    }
    function DMA_txBatchHtml(list) {
        if (list == null) return '<span style="color:#888">production requests not readable (control not loaded)</span>';
        if (!list.length) return '<span style="color:#888">no open production batch</span>';
        return '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:0;"><thead><tr><th>Resource</th><th>Amount</th><th>Status</th></tr></thead><tbody>'
            + list.map(function (b) { var since = Date.parse(b.since); var min = isNaN(since) ? null : Math.max(0, Math.round((Date.now() - since) / 60000));
                return '<tr><td>' + DMA_esc(b.resource) + '</td><td>' + DMA_esc(String(b.amount)) + '</td><td><b style="color:#fc9">asked of you (AR64)</b>' + (min != null ? ' <span style="color:#aaa">' + DMA_esc(DMA_txAge(min)) + '</span>' : '') + '</td></tr>'; }).join("") + '</tbody></table>';
    }
    function DMA_txBatchRow() {
        var l = DMA_txBatches(); if (l != null && !l.length) return "";   // nothing open: the kind row says it already
        return '<tr><td colspan="7" style="background:#2a2a1a;"><b style="color:#fc9">Open production batches</b> ' + DMA_txBatchHtml(l) + '</td></tr>';
    }
    function DMA_openValue() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var re = function () { $(DMA_BODY).html(DMA_valueBody()); };
        re();
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Value of goods");
        $(DMA_BODY).off("click.vl").on("click.vl", ".dma-vl-row", function () { var r = String($(this).data("res")); DMA_valueOpen[r] = !DMA_valueOpen[r]; re(); })
            .off("change.vl").on("change.vl", "#DMA_valueSort", function () { DMA_valueSort = String(this.value); re(); })
            .on("change.vl", "#DMA_valueFind", function () { DMA_valueFilter = String(this.value || ""); re(); });
        DMA_log("value screen");
        return true;
    }
    root.DMA_valueBody = DMA_valueBody; root.DMA_valueChain = DMA_valueChain;
    function DMA_openQuest() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true;
        stopSilentRefresh();
        var p = policy();
        function save(rule, val) {
            var res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") { $("#DMA_questMsg").css("color", "#8f8").text(rule + " = " + val + " saved"); return true; }
            $("#DMA_questMsg").css("color", "#e88").text(rule + ": refused (" + ((res && res.reason) || "policy not loaded") + ")"); return false;
        }
        $(DMA_BODY).html(DMA_questBody());
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>'
            + '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $(DMA_MODAL + " .modal-title").text("Quest manager");
        $(DMA_BODY).off("change.qsel").on("change.qsel", ".dma-sel-rule", function () { if (!save(String($(this).data("rule")), !!this.checked)) this.checked = !this.checked; else $(DMA_BODY).html(DMA_questBody()); });   // 0.1.76
        $(DMA_BODY).off("change.qs").on("change.qs", ".dma-quest-rule", function () { if (!save($(this).data("rule"), !!this.checked)) this.checked = !this.checked; })
          .on("change.qs", "#DMA_questEvery", function () { if (!save("quest.collectEveryMin", Number(this.value))) this.value = DMA_pol("quest.collectEveryMin", 10); })
          .off("click.qs").on("click.qs", "#DMA_questCollect", function () {
            var Q = root.DMA_Quest, k = 0; try { k = Q && Q.collectNow ? Q.collectNow() : 0; } catch (_) {}
            $("#DMA_questMsg").css("color", k ? "#8f8" : "#e88").text(k ? k + " collectibles: picking up, one per second" : "no collectibles found");
          });
        DMA_log("quest book screen");
        return true;
    }
    /* 0.1.19: the HELP page — guild help by level and star trades; rules beside the facts */
    var DMA_HELP_TIERS = [{ t: "t1", label: "below 30" }, { t: "t2", label: "30 - 59" }, { t: "t3", label: "60 - 79" }, { t: "t4", label: "80 and up" }];
    var DMA_HELP_RULES = [
        { id: "help.perHourPlayer", label: "Requests per player per hour", type: "number" },
        { id: "help.floor", label: "Keep at least this much in stock", type: "number" },
        { id: "help.floorPct", label: "Never more than this % of the stock in one gift", type: "number" },
        { id: "help.smallPct", label: "A small gift is always allowed: up to this % of the stock", type: "number" },
        { id: "help.plentyPct", label: "Plenty: storage at least this % full — given without the level limits", type: "number" },
        { id: "help.costRes", label: "The receiver pays (resource)", type: "text" },
        { id: "help.costAmount", label: "The receiver pays (amount)", type: "number" },
        { id: "star.perDay", label: "Star trades per player per day", type: "number" },
        { id: "star.waitHours", label: "Hours to accept both star trades", type: "number" },
        { id: "star.returnCostMax", label: "Accept a return that costs at most", type: "number" }
    ];
    function DMA_helpBody() {
        var H = root.DMA_Help, gifts = [], stars = [];
        try { gifts = H ? H.gifts() : []; stars = H ? H.stars() : []; } catch (_) {}
        function inp(id, type) { var v = DMA_pol(id, ""); return '<input type="' + (type || "number") + '" class="dma-in dma-help-rule" data-rule="' + DMA_esc(id) + '" data-type="' + (type || "number") + '" value="' + DMA_esc(String(v == null ? "" : v)) + '" style="width:80px">'; }
        var cw = String(DMA_pol("chat.words", "") || "").split(",")[0].replace(/^\s+|\s+$/g, "") || "Joe";   // 0.1.98: the player's own chat word
        var h = '<div style="color:#ccc;margin:8px 0 4px;">Help trades by player level — a guild member asks with your chat reply word, e.g. "' + DMA_esc(cw) + ' help 5K stone"; a star trade "' + DMA_esc(cw) + ' star trade 20K plank".</div>'
              + '<table class="table table-condensed" style="font-size:12px;color:#ddd;margin-bottom:6px;"><thead><tr><th>Player level</th><th>Times per day</th><th>Times per week</th><th>Max per request</th></tr></thead><tbody>';
        DMA_HELP_TIERS.forEach(function (x) { h += '<tr><td>' + x.label + '</td><td>' + inp("help." + x.t + ".perDay") + '</td><td>' + inp("help." + x.t + ".perWeek") + '</td><td>' + inp("help." + x.t + ".max") + '</td></tr>'; });
        h += '</tbody></table><table class="table table-condensed" style="font-size:12px;color:#ddd;margin-bottom:6px;"><tbody>';
        DMA_HELP_RULES.forEach(function (r) { h += '<tr><td>' + DMA_esc(r.label) + '</td><td>' + inp(r.id, r.type) + '</td></tr>'; });
        h += '</tbody></table><div style="color:#ccc;font-size:12px;">Star trades</div><table class="table table-condensed" style="font-size:11px;color:#ddd;margin-bottom:6px;"><tbody>';
        if (!stars.length) h += '<tr><td style="color:#999">none yet</td></tr>';
        stars.slice(-8).reverse().forEach(function (c) {
            var open = c.status === "owed" || c.status === "check" || c.status === "sent";   // 0.1.29: sent too
            h += '<tr><td>' + DMA_esc(new Date(c.at).toISOString().slice(5, 16).replace("T", " ")) + '</td><td>' + DMA_esc(c.to) + '</td><td>' + DMA_esc(String(c.amount)) + ' ' + DMA_esc(c.res) + '</td><td>'
               + DMA_esc(c.status + (c.status === "sent" ? " (" + (c.t1 || "?") + "/" + (c.t2 || "?") + ")" : "") + (c.status === "owed" ? " " + c.debt + (c.explained ? " (explained)" : "") : ""))
               + (c.peter ? ' <span style="color:#f0ad4e;font-weight:bold">check please</span>' : '') + '</td><td>'
               + (c.status === "owed" ? '<button type="button" class="btn btn-default btn-xs dma-help-act" data-act="explain" data-who="' + DMA_esc(c.to) + '">Explained</button> ' : '')
               + (open ? '<button type="button" class="btn btn-default btn-xs dma-help-act" data-act="settle" data-who="' + DMA_esc(c.to) + '">Settled</button>' : '') + '</td></tr>';
        });
        var asks = []; try { asks = H && H.asks ? H.asks() : []; } catch (_) {}
        h += '</tbody></table><div style="color:#ccc;font-size:12px;">Star trades I asked for</div><div style="color:#aaa;font-size:11px;margin-bottom:6px;">'
           + (asks.length ? asks.slice(-5).reverse().map(function (a) { return DMA_esc(new Date(a.at).toISOString().slice(5, 16).replace("T", " ") + " " + a.res + " " + a.n + " · " + a.status + (a.from ? " · " + a.from + " " + (a.amount || "") + (a.mode ? " (" + a.mode + " trade" + (a.mode === "two" ? "s" : "") + ")" : "") : "")); }).join("<br>") : "none yet") + '</div>';
        h += '<div style="color:#ccc;font-size:12px;">Recent gifts</div><div style="color:#aaa;font-size:11px;">'
           + (gifts.length ? gifts.slice(-8).reverse().map(function (g) { return DMA_esc(new Date(g.at).toISOString().slice(5, 16).replace("T", " ") + " " + g.to + " (lvl " + g.level + ") " + g.amount + " " + g.res); }).join("<br>") : "none yet") + '</div>'
           + (H ? '' : '<div style="color:#e88;font-size:11px;">user_dma_help.js not loaded</div>')
           + '<div id="DMA_helpMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        return h;
    }

    /* 0.1.101 (ADR 0083 point 2 + addendum, author: "Alles wat we willen dat een speler moet kunnen moet hij de middelen voor
       hebben, dus of een switch, of een vinkje, of zelfs een bedrijfsregel"): the RULES page lists EVERY rule the player policy
       registers, grouped and filterable, each with its own control: bool = a tick, number = a field with its range, choice =
       a list, text = a field, set = a grouped, filterable checklist. Nothing is typed here: the rules come from the policy,
       the resource groups from the value list (DMA_Value.copy: a good made from inputs is "made", one without inputs "raw")
       plus the stock. A change goes through policy.requestChange (request -> ac / dc), as on every other page. */
    var DMA_RULE_AREAS = [   // presentation only: the order of the groups on the page (as build/gen-settings-reference.js)
        ["Switches", /^(island|geo|expo|build|upgrade|buff|demo|chat|mail|quest|event|trade|troops|supply)\.auto$/], ["Island scan and visits", /^location\./],
        ["Geologists and deposit search", /^(search|demolish)\./], ["Client and mines", /^(resource|buff|control)\./], ["Explorers", /^(expo|spec)\./],
        ["Quest book", /^quest\./], ["Event", /^event\./], ["Mail", /^mail\./], ["Chat and round trades", /^(chat|trade)\./], ["Help and star trades", /^(help|star)\./],
        ["Short resources: supply and the trade office", /^supply\./], ["Premium and zombie hunt", /^(premium|zombie)\./], ["Workflows", /^workflow\./], ["Adventures", /^adv\./], ["Troops", /^(troops|unit)\./], ["Safety", /^safety\./]
    ];
    function DMA_ruleGroups(rules, filter) {
        var f = String(filter || "").toLowerCase().trim(), used = {}, out = [];
        function hit(r) { return !f || String(r.ruleId).toLowerCase().indexOf(f) >= 0 || String(r.label || "").toLowerCase().indexOf(f) >= 0; }
        DMA_RULE_AREAS.concat([["Other", /./]]).forEach(function (a) {
            var list = (rules || []).filter(function (r) { return !used[r.ruleId] && a[1].test(r.ruleId); });
            list.forEach(function (r) { used[r.ruleId] = 1; });
            list = list.filter(hit);
            if (list.length) out.push({ title: a[0], rules: list });
        });
        return out;
    }
    function DMA_resourceGroups(copy, stockNames) {
        var made = {}, raw = {}, seen = {}, out = [];
        (copy || []).forEach(function (c) {
            var good = c && c[1], ins = (c && c[2]) || []; if (!good) return;
            if (ins.length) made[good] = 1; else if (!made[good]) raw[good] = 1;
            ins.forEach(function (i) { if (i && i[0] && !made[i[0]]) raw[i[0]] = raw[i[0]] || 1; });
        });
        Object.keys(made).forEach(function (k) { delete raw[k]; });
        function list(o) { return Object.keys(o).sort(); }
        var m = list(made), r = list(raw); m.concat(r).forEach(function (k) { seen[k] = 1; });
        var other = (stockNames || []).filter(function (n) { return n && !seen[n]; }).sort();
        if (r.length) out.push({ title: "Raw (no inputs)", items: r });
        if (m.length) out.push({ title: "Made (from inputs)", items: m });
        if (other.length) out.push({ title: "Other goods in your storage", items: other });
        return out;
    }
    function DMA_ruleInput(r, v) {
        var id = DMA_esc(r.ruleId);
        if (r.valueType === "bool") return '<input type="checkbox" class="dma-rule-in" data-rule="' + id + '" data-type="bool"' + (v === true ? " checked" : "") + '>';
        if (r.valueType === "number") return '<input type="number" class="dma-in dma-rule-in" data-rule="' + id + '" data-type="number" value="' + DMA_esc(String(v == null ? "" : v)) + '" style="width:90px"'
            + (r.allowedRange ? ' min="' + r.allowedRange.min + '" max="' + r.allowedRange.max + '"> <span style="color:#999">' + r.allowedRange.min + ' to ' + r.allowedRange.max + '</span>' : '>');
        if (r.valueType === "choice" || r.allowed) return '<select class="dma-rule-in" data-rule="' + id + '" data-type="choice">' + (r.allowed || []).map(function (a) {
            return '<option' + (String(a) === String(v) ? ' selected' : '') + '>' + DMA_esc(a) + '</option>'; }).join("") + '</select>';
        if (r.valueType === "set") { var n = (v && v.length) || 0; return '<button type="button" class="btn btn-default btn-xs dma-rule-set" data-rule="' + id + '">' + n + ' chosen — choose…</button>'; }
        if (r.valueType === "object") return '<span style="color:#999">(set on its own page)</span>';
        return '<input type="text" class="dma-in dma-rule-in" data-rule="' + id + '" data-type="text" value="' + DMA_esc(String(v == null ? "" : v)) + '" style="width:260px">';
    }
    function DMA_rulesHtml(rules, filter, get) {
        var h = '<div style="color:#ccc;margin-bottom:6px;">Every business rule DMA follows. Switch a rule on or off and set its value; a change is checked by the rules (its range) and saved at once.</div>'
              + '<input type="text" class="dma-in" id="DMA_rulesFilter" placeholder="filter: a word of the rule or its key" value="' + DMA_esc(filter || "") + '" style="width:320px;margin-bottom:6px;">'
              + '<div id="DMA_rulesMsg" style="color:#8f8;font-size:11px;min-height:14px;"></div>';
        DMA_ruleGroups(rules, filter).forEach(function (g) {
            h += '<div style="background:#2a2a2a;border-radius:4px;padding:6px;margin-bottom:8px;"><b style="color:#fc6">' + DMA_esc(g.title) + '</b>'
               + '<table class="table table-condensed" style="font-size:11px;color:#ddd;margin:4px 0 0 0;"><tbody>';
            g.rules.forEach(function (r) { h += '<tr><td style="width:55%">' + DMA_esc(r.label || r.ruleId) + '<div style="color:#777;font-size:10px">' + DMA_esc(r.ruleId) + '</div></td><td>' + DMA_ruleInput(r, get(r.ruleId, r.value)) + '</td></tr>'; });
            h += '</tbody></table></div>';
        });
        return h;
    }
    function DMA_setHtml(rule, chosen, groups, filter) {
        var f = String(filter || "").toLowerCase(), c = {}; (chosen || []).forEach(function (x) { c[String(x).toLowerCase()] = 1; });
        var h = '<div style="color:#ccc;margin-bottom:6px;">' + DMA_esc(rule.label || rule.ruleId) + '</div>'
              + '<input type="text" class="dma-in" id="DMA_setFilter" placeholder="filter" value="' + DMA_esc(filter || "") + '" style="width:220px;margin-bottom:6px;"> '
              + '<button type="button" class="btn btn-primary btn-xs" id="DMA_setSave" data-rule="' + DMA_esc(rule.ruleId) + '">Save</button> <span id="DMA_setMsg" style="color:#8f8;font-size:11px;"></span>';
        groups.forEach(function (g) {
            var items = g.items.filter(function (n) { return !f || n.toLowerCase().indexOf(f) >= 0; }); if (!items.length) return;
            h += '<div style="background:#2a2a2a;border-radius:4px;padding:6px;margin:6px 0;"><b style="color:#fc6">' + DMA_esc(g.title) + '</b> '
               + '<a href="#" class="dma-set-all" data-on="1" style="font-size:10px">all</a> <a href="#" class="dma-set-all" data-on="0" style="font-size:10px">none</a><div>';
            items.forEach(function (n) { h += '<label style="font-weight:normal;display:inline-block;width:160px;color:#ddd;font-size:11px;"><input type="checkbox" class="dma-set-item" value="' + DMA_esc(n) + '"' + (c[n.toLowerCase()] ? ' checked' : '') + '> ' + DMA_esc(n) + '</label>'; });
            h += '</div></div>';
        });
        return h;
    }
    function DMA_stockNames() { try { var v = game.getResources().GetPlayerResources_vector(), out = []; for (var i = 0; i < v.length; i++) { var n = v[i] && (v[i].name_string || (v[i].GetName_string && v[i].GetName_string())); if (n) out.push(String(n)); } return out; } catch (_) { return []; } }
    function DMA_openRules(filter) {
        if (!hasJQ()) return false;
        DMA_geoOpen = true; stopSilentRefresh();
        var p = policy(), P = root.GCAF_PlayerPolicy, rules = P && P.RULES ? P.RULES : [];
        $(DMA_BODY).html(DMA_rulesHtml(rules, filter, DMA_pol));
        $(DMA_MODAL + " .modal-title").text("Rules");
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button><button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $("#DMA_rulesFilter").off("change.rf").on("change.rf", function () { DMA_openRules(this.value); });
        $(".dma-rule-in").off("change.ri").on("change.ri", function () {
            var rule = $(this).data("rule"), t = $(this).data("type"), val = t === "bool" ? !!this.checked : this.value, res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") $("#DMA_rulesMsg").css("color", "#8f8").text(rule + " = " + JSON.stringify(res.value) + " saved");
            else $("#DMA_rulesMsg").css("color", "#e88").text(rule + ": refused (" + (res && res.reason || "no policy") + ")");
        });
        $(".dma-rule-set").off("click.rs").on("click.rs", function () {
            var rule = $(this).data("rule"), r = rules.filter(function (x) { return x.ruleId === rule; })[0]; if (!r) return;
            var copy = []; try { copy = root.DMA_Value && root.DMA_Value.copy ? root.DMA_Value.copy() : []; } catch (_) {}
            var groups = DMA_resourceGroups(copy, DMA_stockNames());
            if (r.pick === "travelBuffs") {   // 0.1.108: the travel speed-ups in the star, one group per exclusivity group of the game
                var tb = []; try { tb = root.DMA_Adventure && root.DMA_Adventure.travelBuffs ? root.DMA_Adventure.travelBuffs() : []; } catch (_) {}
                var byG = {}; tb.forEach(function (b) { var k = b.group == null ? "?" : String(b.group); (byG[k] = byG[k] || []).push(b.name); });
                groups = Object.keys(byG).map(function (k) { return { title: (byG[k].length > 1 ? "Choose one of these (they exclude each other)" : "Travel buff") + (k === "?" ? "" : " — group " + k), items: byG[k] }; });
            }
            /* 0.1.116 (tester ZG-05: Back on this screen went to the main page): Back returns to the rules page it came from */
            $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_setBack">Back to rules</button><button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
            $("#DMA_setBack").off("click.sb").on("click.sb", function () { DMA_openRules(filter); });
            function draw(ff) {
                var cur = []; $(".dma-set-item:checked").each(function () { cur.push(this.value); });
                var chosen = ff === undefined ? DMA_pol(rule, r.value) : cur;
                $(DMA_BODY).html(DMA_setHtml(r, chosen, groups, ff));
                $("#DMA_setFilter").off("change.sf").on("change.sf", function () { draw(this.value); });
                $(".dma-set-all").off("click.sa").on("click.sa", function (e) { e.preventDefault(); var on = $(this).data("on") === 1; $(".dma-set-item", $(this).parent()).prop("checked", on); });
                $("#DMA_setSave").off("click.ss").on("click.ss", function () {
                    var sel = []; $(".dma-set-item:checked").each(function () { sel.push(this.value); });
                    var res = null; try { res = p && p.requestChange ? p.requestChange(rule, sel) : null; } catch (_) {}
                    $("#DMA_setMsg").css("color", res && res.fact === "ac" ? "#8f8" : "#e88").text(res && res.fact === "ac" ? sel.length + " saved" : "refused" + (res && res.why ? ": " + res.why : ""));   // 0.1.108: the reason
                });
            }
            draw();
        });
        return true;
    }

    /* 0.1.102 (author 2026-11-18: "Nee de knop is het belangrijkste, maak dat nu eerst"): FEEDBACK. The player writes in
       his own words what he was doing, what he expected and what happened; "Make report" asks DMA_Report for a short text
       (on the clipboard, under 2000 characters: one Discord message) and a full report file next to the client. */
    function DMA_feedbackHtml(res) {
        var h = '<div style="color:#ccc;margin-bottom:6px;">Tell what you saw, press <b>Make report</b>, then paste in Discord (<b>Ctrl+V</b>) in <b>#test-corner</b> and attach the report file. Nothing is sent by DMA itself.</div>'
              + '<table class="table table-condensed" style="font-size:12px;color:#ddd;"><tbody>'
              + '<tr><td style="width:150px">Title (one line)</td><td><input type="text" class="dma-in" id="DMA_fbTitle" style="width:95%" placeholder="e.g. Round trade accepted twice"></td></tr>'
              + '<tr><td>What were you doing?</td><td><textarea id="DMA_fbDoing" rows="2" style="width:95%;color:#111"></textarea></td></tr>'
              + '<tr><td>What did you expect?</td><td><textarea id="DMA_fbExpected" rows="2" style="width:95%;color:#111"></textarea></td></tr>'
              + '<tr><td>What happened?</td><td><textarea id="DMA_fbHappened" rows="3" style="width:95%;color:#111"></textarea></td></tr>'
              + '</tbody></table>'
              + '<button type="button" class="btn btn-primary btn-sm" id="DMA_fbMake">Make report</button> '
              + '<button type="button" class="btn btn-default btn-sm" id="DMA_fbCopy"' + (res ? '' : ' disabled') + '>Copy the text again</button>'
              + '<div id="DMA_fbMsg" style="margin-top:6px;font-size:12px;color:#8f8;">';
        if (res) h += (res.copied ? 'The text is on the clipboard (' + res.length + ' characters): paste it in Discord. ' : '<span style="color:#e88">Could not copy: select the text below and copy it yourself. </span>')
                   + (res.file ? 'Attach the file <b>' + DMA_esc(res.file) + '</b> from the client folder' + (res.path ? ' (' + DMA_esc(res.path) + ')' : '') + '.' : '<span style="color:#e88">The report file could not be written.</span>');
        h += '</div>';
        if (res) h += '<textarea id="DMA_fbText" rows="12" readonly style="width:100%;margin-top:6px;font-family:monospace;font-size:11px;color:#111">' + DMA_esc(res.summary) + '</textarea>';
        return h;
    }
    var DMA_fbLast = null;
    function DMA_openFeedback(res) {
        if (!hasJQ()) return false;
        DMA_geoOpen = true; stopSilentRefresh();
        $(DMA_BODY).html(DMA_feedbackHtml(res || null));
        $(DMA_MODAL + " .modal-title").text("Feedback");
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button><button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        $("#DMA_fbMake").off("click.fb").on("click.fb", function () {
            var R = root.DMA_Report, notes = { title: $("#DMA_fbTitle").val(), doing: $("#DMA_fbDoing").val(), expected: $("#DMA_fbExpected").val(), happened: $("#DMA_fbHappened").val() };
            if (!R || typeof R.make !== "function") { $("#DMA_fbMsg").css("color", "#e88").text("The report module (user_dma_report.js) is not loaded."); return; }
            var r = null; try { r = R.make(notes); } catch (e) { $("#DMA_fbMsg").css("color", "#e88").text("Report failed: " + e); return; }
            DMA_fbLast = r; DMA_log("feedback report " + (r.file || "(no file)") + ", " + r.length + " characters" + (r.copied ? " copied" : ""));
            DMA_openFeedback(r);
            $("#DMA_fbTitle").val(notes.title); $("#DMA_fbDoing").val(notes.doing); $("#DMA_fbExpected").val(notes.expected); $("#DMA_fbHappened").val(notes.happened);
        });
        $("#DMA_fbCopy").off("click.fc").on("click.fc", function () { var R = root.DMA_Report; if (DMA_fbLast && R && R.copy) $("#DMA_fbMsg").text(R.copy(DMA_fbLast.summary) ? "Copied again." : "Could not copy."); });
        return true;
    }
    /* 0.1.103 (ADR 0084): WORKFLOWS. data = { resources: [{ r, name, cfg, spots: [{ grid, label, state }], types: [{ id, name, count }] }], rows: [...] } */
    var DMA_WF_NAMES = { BronzeOre: "Copper", IronOre: "Iron", GoldOre: "Gold", Coal: "Coal", TitaniumOre: "Titanium", Salpeter: "Saltpetre" };
    /* 0.1.106 (author 2026-11-18: "Welke workflows hebben we, openklappen als we details willen zien"): an overview first — one line per
       workflow (on for which resources, spots, geologists, cycles, searches out, last act); opened: one line per resource (state of every
       picked spot by its label, geologists, cycles, what it does now); a resource opened: its settings and its rows of the last cycle.
       data = { workflows: [{ id, label, by, about }], resources: [{ r, name, wf, cfg, spots: [{ grid, label, state }], types: [{ id, name, count }], stats }],
                rows: [...], open: { "<wf>": true, "<wf>|<r>": true } } */
    var DMA_WF_NAMES = { BronzeOre: "Copper", IronOre: "Iron", GoldOre: "Gold", Coal: "Coal", TitaniumOre: "Titanium", Salpeter: "Saltpetre" };
    var DMA_wfOpen = {};
    function DMA_wfTime(ms) { if (!ms) return "—"; var d = new Date(ms); function z(n) { return (n < 10 ? "0" : "") + n; } return z(d.getHours()) + ":" + z(d.getMinutes()); }
    function DMA_wfSettings(x) {
        var c = x.cfg || {}, R = DMA_esc(x.r), sel = (c.grids || []).map(String), ty = (c.geoTypes || []).map(String), h = "";
        h += '<table class="table table-condensed" style="font-size:12px;color:#ddd;margin:2px 0 6px 18px;width:97%;background:#2b2620"><tbody>'
           + '<tr><td style="width:150px;color:#ddd">On</td><td><label><input type="checkbox" class="dma-wf-in" data-rule="workflow.dc.' + R + '.on" data-type="bool"' + (c.on ? " checked" : "") + '> on</label></td></tr>'
           + '<tr><td>Spots</td><td>';
        if (!(x.spots || []).length) h += '<span style="color:#aaa">no spot of this resource known</span>';
        (x.spots || []).forEach(function (s) {   // 0.1.107: the player's label, editable here; the fixed number when there is none
            var g = String(s.grid), on = sel.indexOf(g) >= 0;
            h += '<div style="display:inline-block;margin:0 14px 4px 0;white-space:nowrap;' + (on ? "color:#7fd3a8;font-weight:bold" : "color:#ddd") + '">'
               + '<input type="checkbox" class="dma-wf-set" data-rule="workflow.dc.' + R + '.grids" value="' + DMA_esc(g) + '"' + (on ? " checked" : "") + '> '
               + '<input type="text" class="dma-wf-label" data-grid="' + DMA_esc(g) + '" value="' + DMA_esc(s.label || "") + '" placeholder="' + DMA_esc(s.no || ("spot " + g)) + '" title="your label for this spot" style="width:110px;color:#111;font-weight:' + (on ? "bold" : "normal") + '">'
               + ' <span style="color:#aaa;font-weight:normal">' + DMA_esc(g) + (s.state ? " · " + DMA_esc(s.state) : "") + '</span></div>';
        });
        h += '</td></tr><tr><td>Geologists</td><td>';
        if (!(x.types || []).length) h += '<span style="color:#aaa">no geologists read</span>';
        (x.types || []).forEach(function (t) {
            var id = String(t.id);
            h += '<label style="margin-right:12px;white-space:nowrap;' + (ty.indexOf(id) >= 0 ? "color:#7fd3a8;font-weight:bold" : "color:#ddd;font-weight:normal") + '"><input type="checkbox" class="dma-wf-set" data-rule="workflow.dc.' + R + '.geoTypes" value="' + DMA_esc(id) + '"' + (ty.indexOf(id) >= 0 ? " checked" : "") + '> '
               + DMA_esc(t.name || ("type " + id)) + ' <span style="color:#888">#' + DMA_esc(id) + ' (' + DMA_esc(String(t.count || 0)) + ')</span></label>';
        });
        h += '</td></tr>'
           + '<tr><td>Start</td><td><select class="dma-wf-in" data-rule="workflow.dc.' + R + '.start" data-type="choice" style="color:#111">'
           + '<option value="empty"' + (c.start !== "now" ? " selected" : "") + '>when your mine on the spot runs empty or is demolished</option>'
           + '<option value="now"' + (c.start === "now" ? " selected" : "") + '>now: demolish your basic mine on the spot at once</option></select></td></tr>'
           + '<tr><td>How many</td><td><input type="number" class="dma-in dma-wf-in" data-rule="workflow.dc.' + R + '.geoCount" data-type="number" value="' + DMA_esc(String(c.geoCount || 0)) + '" style="width:70px"> geologists of those types (0 = all)</td></tr>'
           + '<tr><td>Build queue</td><td>keep <input type="number" class="dma-in dma-wf-in" data-rule="workflow.dc.' + R + '.keepFree" data-type="number" value="' + DMA_esc(String(c.keepFree == null ? 1 : c.keepFree)) + '" style="width:60px"> place(s) free for regular building</td></tr>'
           + '<tr><td>Reserve</td><td><label><input type="checkbox" class="dma-wf-in" data-rule="workflow.dc.' + R + '.reserve.on" data-type="bool"' + (c.reserveOn !== false ? " checked" : "") + '> stop while a good of the build cost is below</label> '
           + '<input type="number" class="dma-in dma-wf-in" data-rule="workflow.dc.' + R + '.reserve" data-type="number" value="' + DMA_esc(String(c.reserve == null ? 1000 : c.reserve)) + '" style="width:90px"></td></tr>'
           + '</tbody></table>';
        return h;
    }
    function DMA_wfRows(rows) {
        if (!rows.length) return "";
        var h = '<table class="table table-condensed" style="font-size:11px;color:#ccc;margin:0 0 6px 18px;width:97%"><tbody><tr><td colspan="4" style="color:#aaa">Last cycle</td></tr>';
        rows.forEach(function (w) { h += '<tr><td>' + DMA_esc(w.rule) + '</td><td>' + DMA_esc(w.label || w.grid || "") + '</td><td style="color:' + (w.fact === "pm" ? "#8f8" : "#ccc") + '">' + DMA_esc(w.fact === "pm" ? "acts" : "not now") + '</td><td>' + DMA_esc(w.reason) + '</td></tr>'; });
        return h + "</tbody></table>";
    }
    function DMA_workflowsHtml(data) {
        data = data || {}; var res = data.resources || [], rows = data.rows || [], open = data.open || DMA_wfOpen;
        var wfs = data.workflows || [{ id: "deposit-cycling", label: "Deposit Cycling", by: "Zingu", about: "on the spots you pick, a found deposit is built on and the new mine demolished at once, so your chosen geologists keep searching there for the extra loot. Only a basic mine is ever demolished." }];
        var h = '<div id="DMA_wfMsg" style="font-size:12px;color:#8f8;min-height:16px;"></div>';
        if (!res.length) return h + '<div style="color:#e88">No spots known yet: switch on Island so the location manager can see the island.</div>';
        h += '<table class="table table-condensed" style="font-size:12px;color:#ddd;"><tbody>';
        wfs.forEach(function (wf) {
            var mine = res.filter(function (x) { return (x.wf || "deposit-cycling") === wf.id; }), on = mine.filter(function (x) { return x.cfg && x.cfg.on; });
            var tot = { spots: 0, geos: 0, cycles: 0, out: 0, lastAt: 0, last: "" };
            on.forEach(function (x) { var st = x.stats || {}; tot.spots += (x.cfg.grids || []).length; tot.geos += st.allocated || 0; tot.cycles += st.cycles || 0; tot.out += st.out || 0; if ((st.lastAt || 0) > tot.lastAt) { tot.lastAt = st.lastAt; tot.last = (DMA_WF_NAMES[x.r] || x.r) + ": " + (st.last || ""); } });
            var wOpen = !!open[wf.id];
            h += '<tr class="dma-wf-tog" data-k="' + DMA_esc(wf.id) + '" style="cursor:pointer;background:#2f2a20"><td style="width:18px">' + (wOpen ? "▼" : "▶") + '</td>'
               + '<td><b>' + DMA_esc(wf.label) + '</b> <span style="color:#888">by ' + DMA_esc(wf.by || "") + '</span></td>'
               + '<td>' + (on.length ? '<span style="color:#7fd3a8">on: ' + DMA_esc(on.map(function (x) { return DMA_WF_NAMES[x.r] || x.r; }).join(", ")) + '</span>' : '<span style="color:#888">off</span>') + '</td>'
               + '<td title="picked spots / geologists allocated">' + tot.spots + ' spots · ' + tot.geos + ' geologists</td>'
               + '<td title="own mines demolished since the client started / searches out now">cycles ' + tot.cycles + ' · out ' + tot.out + '</td>'
               + '<td title="the last act">' + DMA_esc(tot.lastAt ? DMA_wfTime(tot.lastAt) + " " + tot.last : "—") + '</td></tr>';
            if (!wOpen) return;
            h += '<tr><td></td><td colspan="5" style="color:#aaa;font-size:11px">' + DMA_esc(wf.about || "") + '</td></tr>';
            mine.forEach(function (x) {
                var k = wf.id + "|" + x.r, rOpen = !!open[k], c = x.cfg || {}, st = x.stats || {}, picked = (c.grids || []).map(String);
                var spotsTxt = (x.spots || []).filter(function (s) { return picked.indexOf(String(s.grid)) >= 0; }).map(function (s) { return '<span style="white-space:nowrap">' + DMA_esc(s.label || ("spot " + s.grid)) + ': <i>' + DMA_esc(s.state || "?") + '</i></span>'; }).join(" · ");
                var mineRows = rows.filter(function (w) { return w.resource === x.r && (w.workflow || "deposit-cycling") === wf.id; });
                var nowRow = mineRows.filter(function (w) { return w.fact === "pm"; })[0] || mineRows[0];
                h += '<tr class="dma-wf-tog" data-k="' + DMA_esc(k) + '" style="cursor:pointer' + (c.on ? "" : ";color:#888") + '"><td></td>'
                   + '<td style="padding-left:14px">' + (rOpen ? "▼ " : "▶ ") + DMA_esc(x.name || x.r) + '</td>'
                   + '<td>' + (c.on ? '<span style="color:#7fd3a8">on</span>' + (c.start === "now" ? " (now)" : "") : "off") + '</td>'
                   + '<td>' + (spotsTxt || '<span style="color:#888">no spots picked</span>') + '</td>'
                   + '<td>' + (c.on ? (st.allocated || 0) + ' geologists · cycles ' + (st.cycles || 0) + ' · out ' + (st.out || 0) : "") + '</td>'
                   + '<td style="font-size:11px">' + (c.on && nowRow ? DMA_esc((nowRow.fact === "pm" ? "acts: " : "") + nowRow.reason) : "") + '</td></tr>';
                if (rOpen) h += '<tr><td></td><td colspan="5">' + DMA_wfSettings(x) + DMA_wfRows(mineRows) + '</td></tr>';
            });
        });
        return h + '</tbody></table><div style="color:#888;font-size:11px">Click a line to open or close it. Counts are since the client started.</div>';
    }
    function DMA_workflowsData() {
        var W = root.DMA_Workflows, D = root.DMA_Demo, C = root.DMA_Control, Gr = root.DMA_Green, out = { resources: [], rows: [], open: DMA_wfOpen };
        if (!W) return out;
        var isl = null; try { isl = D && D.island ? D.island() : null; } catch (_) {}
        var slots = []; try { slots = Gr && Gr.facts ? Gr.facts() || [] : []; } catch (_) {}
        if (!slots.length) { try { var mem = D && D.memory ? D.memory() : null; slots = (mem && mem.slots) || []; } catch (_) {} }
        var geos = []; try { geos = (C && C.geologists && C.geologists()) || []; } catch (_) {}
        var types = {}; geos.forEach(function (g) { if (!g || g.typeId == null) return; var k = String(g.typeId); if (!types[k]) types[k] = { id: k, name: g.typeName || "", count: 0 }; types[k].count += 1; });
        var typeList = Object.keys(types).sort(function (a, b) { return Number(a) - Number(b); }).map(function (k) { return types[k]; });
        function state(g) {
            var lv = null; try { lv = Gr && Gr.live ? Gr.live(g) : null; } catch (_) {}
            if (lv && lv.name) return /Mine$/.test(lv.name) ? "mine lvl" + (lv.level || 0) : String(lv.name);
            for (var i = 0; i < slots.length; i++) if (String(slots[i].grid) === String(g)) return slots[i].mine ? "mine" : (slots[i].depleted ? "depleted" : "deposit");
            return "empty";
        }
        (W.resources || []).forEach(function (r) {
            var cfg = W.config(r), grids = [];
            try { grids = root.DMA_Spots && root.DMA_Spots.list ? root.DMA_Spots.list(r).map(function (s) { return String(s.grid); }) : []; } catch (_) { grids = []; }
            if (!grids.length) { try { grids = isl && isl.spotGrids ? isl.spotGrids(r) || [] : []; } catch (_) { grids = []; } }
            (cfg.grids || []).forEach(function (g) { if (grids.indexOf(String(g)) < 0) grids.push(String(g)); });
            if (!grids.length && !cfg.on) return;
            var stats = {}; try { stats = W.stats ? W.stats("deposit-cycling", r) : {}; } catch (_) {}
            out.resources.push({ r: r, name: DMA_WF_NAMES[r] || r, wf: "deposit-cycling", cfg: cfg, spots: grids.map(function (g) { var nb = null; try { nb = root.DMA_Spots && root.DMA_Spots.numberOf ? root.DMA_Spots.numberOf(g) : null; } catch (_) {} return { grid: g, label: DMA_locLabel(g), state: state(g), no: nb ? (DMA_SHORT[nb.resource] || nb.resource) + " " + (nb.no < 10 ? "0" : "") + nb.no : "" }; }), types: typeList, stats: stats });
        });
        try { out.rows = (W.last() || []).map(function (w) { var o = {}, k; for (k in w) if (w.hasOwnProperty(k)) o[k] = w[k]; o.label = w.grid ? (DMA_locLabel(w.grid) || w.grid) : ""; return o; }); } catch (_) {}
        return out;
    }
    function DMA_openWorkflows() {
        if (!hasJQ()) return false;
        DMA_geoOpen = true; stopSilentRefresh();
        var p = root.GCAF_PlayerPolicyInstance;
        $(DMA_BODY).html(DMA_workflowsHtml(DMA_workflowsData()));
        $(DMA_MODAL + " .modal-title").text("Workflows");
        $(DMA_MODAL + " .modal-footer").html('<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button><button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>');
        function said(rule, res, v) { $("#DMA_wfMsg").css("color", res && res.fact === "ac" ? "#8f8" : "#e88").text(res && res.fact === "ac" ? rule + " saved" : rule + " refused" + (res && res.reason ? ": " + res.reason : "")); }
        $(DMA_BODY).off("click.wft").on("click.wft", ".dma-wf-tog", function () {   // 0.1.106: open or close a line
            var k = String($(this).data("k")); DMA_wfOpen[k] = !DMA_wfOpen[k];
            var top = $(DMA_BODY).scrollTop(); $(DMA_BODY).html(DMA_workflowsHtml(DMA_workflowsData())); $(DMA_BODY).scrollTop(top);
        });
        $(DMA_BODY).off("change.wfl").on("change.wfl", ".dma-wf-label", function () {   // 0.1.107: the spot label, the same store as the main table
            var g = String($(this).data("grid")), v = String(this.value || ""), rule = "location.label.grid." + g, res = null;
            try { if (root.DMA_Labels && root.DMA_Labels.set) root.DMA_Labels.set(rule, v); } catch (_) {}
            try { res = p && p.requestChange ? p.requestChange(rule, v) : null; } catch (_) {}
            said(rule, res, v);
        });
        $(DMA_BODY).off("change.wf").on("change.wf", ".dma-wf-in", function () {
            var rule = $(this).data("rule"), v = $(this).data("type") === "bool" ? this.checked : this.value, res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, v) : null; } catch (_) {}
            said(rule, res, v);
        }).on("change.wf", ".dma-wf-set", function () {
            var rule = $(this).data("rule"), sel = [], res = null;
            $('.dma-wf-set[data-rule="' + rule + '"]:checked').each(function () { sel.push(this.value); });
            try { res = p && p.requestChange ? p.requestChange(rule, sel) : null; } catch (_) {}
            said(rule, res, sel);
        });
        return true;
    }
    function DMA_openHelp() { return DMA_openTrade(); }   // 0.1.24: help and star trades live on the TRADE page
    function DMA_bindHelp(p) {
        $(DMA_BODY).off("change.hl click.hl").on("change.hl", ".dma-help-rule", function () {
            var rule = $(this).data("rule"), val = $(this).data("type") === "text" ? String(this.value) : Number(this.value), res = null;
            try { res = p && p.requestChange ? p.requestChange(rule, val) : null; } catch (_) {}
            if (res && res.fact === "ac") $("#DMA_helpMsg").css("color", "#8f8").text(rule + " = " + val + " saved");
            else { $("#DMA_helpMsg").css("color", "#e88").text(rule + ": " + val + " refused (" + ((res && res.reason) || "policy not loaded") + ")"); this.value = DMA_pol(rule, ""); }
        }).on("click.hl", ".dma-help-act", function () {
            var H = root.DMA_Help, act = $(this).data("act"), who = String($(this).data("who"));
            if (H && typeof H[act] === "function") { H[act](who); DMA_openTrade(); $("#DMA_helpMsg").text(who + ": " + act); }
        });
    }
    function DMA_closeGeo() {
        DMA_geoOpen = false;
        $(DMA_MODAL + " .modal-title").text("DMA Console");
        $(DMA_BODY).html(renderBodyShell());
        $(DMA_MODAL + " .modal-footer").html(renderFooter());
        DMA_bind();
        DMA_refreshTable(true);
        startSilentRefresh(DMA_REFRESH_MS);
    }
    function DMA_saveTemplate() {
        var skills = root.DMA_GeoSkills;
        if (!skills || !skills.setLabels || skills.locked()) return;
        var list = [];
        $(DMA_BODY + " input.dma-tpl").each(function () { list.push($(this).val()); });
        skills.setLabels(list);
    }
    function DMA_geoSpin(index, delta) {
        var skills = root.DMA_GeoSkills;
        if (!skills || !DMA_geoId) { DMA_log("geo spin: no skills module or no geo"); return; }
        var row = skills.get(DMA_geoId) || { levels: skills.parse("") };
        var levels = (row.levels || skills.parse("")).slice();
        var cur = levels[index] || 0;
        if (delta > 0) {
            var gate = skills.canRaise(levels, index);
            if (!gate.ok) { DMA_log("geo spin blocked " + gate.reason); return; }
            levels[index] = cur + 1;
        } else if (cur > 0) {
            levels[index] = cur - 1;
        } else return;
        skills.setString(DMA_geoId, levels.join(""));
        $(DMA_BODY).html(DMA_geoBody());
    }
    function DMA_geoBody() {
        var skills = root.DMA_GeoSkills;
        var ctrl = root.DMA_Control;
        var geos = (ctrl && ctrl.geologists) ? ctrl.geologists() : [];
        if (!DMA_geoId && geos.length) DMA_geoId = geos[0].id;
        var lab = skills && skills.labels ? skills.labels() : [];
        var lock = skills && skills.locked && skills.locked();
        var maxes = (skills && skills.maxes) ? skills.maxes : [];
        var row = (skills && DMA_geoId) ? skills.get(DMA_geoId) : null;
        var levels = row && row.levels ? row.levels : (skills ? skills.parse("") : []);
        var pts = 0, i;
        for (i = 0; i < levels.length; i++) pts += levels[i] || 0;
        var ids = [];
        for (i = 0; i < geos.length; i++) ids.push(geos[i].id);
        var sum = skills && skills.summary ? skills.summary(ids) : { total: geos.length, determined: 0, full: 0, open: geos.length };
        var h = '<div class="dma-geo">';
        if (!skills) h += '<div class="dma-ver dma-warn">user_dma_geo_skills.js niet geladen</div>';
        h += '<div class="dma-ver">geos ' + sum.total + ' · bepaald ' + sum.determined + ' · volledig ' + sum.full + ' · open ' + sum.open + '</div>';
        h += '<div class="dma-geo-head">';
        h += '<button type="button" class="btn btn-default btn-sm" id="DMA_geoBack">Back</button>';
        h += '<select id="DMA_geoPick" class="dma-in">';
        for (i = 0; i < geos.length; i++) {
            var g = geos[i];
            h += '<option value="' + DMA_esc(g.id) + '"' + (g.id === DMA_geoId ? " selected" : "") + '>'
               + DMA_esc((g.name || "—") + " · " + (g.typeName || g.id)) + '</option>';
        }
        if (!geos.length) h += '<option value="">no geologists</option>';
        h += '</select>';
        h += '<button type="button" class="btn btn-default btn-sm" id="DMA_tplLock">' + (lock ? "Unlock labels" : "Lock labels") + '</button>';
        h += '<b class="dma-geo-total">' + pts + '/31</b></div>';
        h += '<div class="dma-skillgrid">';
        var idx = 0, r, c, cols, open, why, mx;
        var rowCols = [3, 3, 3, 3, 3, 3, 2];
        for (r = 0; r < rowCols.length; r++) {
            cols = rowCols[r];
            h += '<div class="dma-skillrow">';
            for (c = 0; c < cols; c++) {
                mx = maxes[idx] || 3;
                open = skills && skills.canRaise ? skills.canRaise(levels, idx) : { ok: false, reason: "no skills" };
                why = (!open.ok && (levels[idx] || 0) < mx) ? open.reason : "";
                h += '<div class="dma-skill' + (why ? " dma-skill-locked" : "") + '">';
                h += '<input class="dma-in dma-tpl" data-pos="' + idx + '" value="' + DMA_esc(lab[idx] || ("pos " + (idx + 1))) + '"' + (lock ? " disabled" : "") + '>';
                h += '<div class="dma-spinbox">';
                h += '<button type="button" class="dma-spin" data-dir="down" data-i="' + idx + '">−</button>';
                h += '<span class="dma-spin-n">' + (levels[idx] || 0) + '/' + mx + '</span>';
                h += '<button type="button" class="dma-spin" data-dir="up" data-i="' + idx + '"' + (open.ok ? "" : " disabled") + '>+</button>';
                h += '</div>';
                if (why) h += '<div class="dma-skill-why">' + DMA_esc(why) + '</div>';
                h += '</div>';
                idx += 1;
            }
            h += '</div>';
        }
        h += '</div></div>';
        return h;
    }

    function DMA_openConsole() {
        DMA_log("console open");
        if (!hasJQ() || typeof createModalWindow !== "function") {
            DMA_log("client helpers not loaded");
            return false;
        }
        DMA_loadSwitches();
        DMA_injectCss();
        if ($(DMA_MODAL).length === 0) {
            createModalWindow("DMA_ConsoleModal", "DMA Console");
            $(DMA_MODAL + " .modal-dialog").addClass("dma-dialog");
            if ($(DMA_MODAL + " .modal-footer").length === 0) $(DMA_MODAL + " .modal-content").append('<div class="modal-footer"></div>');
            DMA_bind();
        }
        DMA_lastTableHtml = ""; DMA_lastIdle = null;
        DMA_geoOpen = false;                                      // 0.1.20: closed from a sub page (MAIL, TRADE, HELP ...) — open on the main view
        $(DMA_MODAL + " .modal-title").text("DMA Console");
        $(DMA_BODY).html(renderBodyShell());
        $(DMA_MODAL + " .modal-footer").html(renderFooter());
        if (!policy()) DMA_log("GCAF_PlayerPolicyInstance not loaded");
        DMA_syncCycleButton();
        if (DMA_cycleIsOn() && !DMA_cycleTimer) {
            DMA_cycleTimer = setInterval(function () { DMA_cycleOnce(); }, DMA_CYCLE_MS);
            DMA_log("cycle auto-started from storage");
        } else {
            DMA_log("cycle not auto-started, isOn=" + DMA_cycleIsOn());
        }
        if ($(DMA_MODAL).is(":visible")) startSilentRefresh(DMA_REFRESH_MS); else $(DMA_MODAL).modal("show");
        return true;
    }

    /* ---------- exports: the names the brief fixes, plus a module object ---------- */
    var api = {
        version: VERSION,
        loadedVersions: function () { return DMA_loadedVersions(); },   // 0.1.89: for the tests
        policy: function () { return policy(); },   // 0.1.57
        advsBody: function () { return DMA_advsBody(); },   // 0.1.59
        troopsModel: DMA_troopsModel, troopsBody: DMA_troopsBody, troopsFilter: DMA_troopsFilter, troopsToggle: DMA_troopsToggle, troopState: DMA_troopState, unitIcon: DMA_unitIcon, txBatchHtml: DMA_txBatchHtml, questBody: DMA_questBody,   // 0.1.90: for the tests
        resources: DMA_RESOURCES,
        icons: DMA_ICON,
        switches: DMA_switches,
        actorsHtml: DMA_actorsHtml,
        rulePrefix: DMA_RULE_PREFIX,
        iconName: DMA_iconName,
        renderToolbar: renderToolbar,
        renderTable: renderTable,
        renderFooter: renderFooter,
        startSilentRefresh: startSilentRefresh,
        stopSilentRefresh: stopSilentRefresh,
        change: DMA_change,
        cycleOnce: DMA_cycleOnce,
        bind: DMA_bind,
        open: DMA_openConsole,
        log: DMA_log,
        logLines: function () { return DMA_logLines.slice(); }
    };

    root.DMA_RESOURCES = DMA_RESOURCES;
    root.DMA_ICON = DMA_ICON;
    root.DMA_SWITCHES = DMA_SWITCHES;
    root.DMA_EXP_TEMPLATES = DMA_EXP_TEMPLATES;
    root.renderToolbar = renderToolbar;
    root.renderTable = renderTable;
    root.startSilentRefresh = startSilentRefresh;
    root.stopSilentRefresh = stopSilentRefresh;
    root.DMA_bind = DMA_bind;
    root.DMA_openConsole = DMA_openConsole;
    api.skillsHtml = DMA_gameSkillsHtml;   // 0.1.96 (tests)
    api.helpBody = DMA_helpBody;   // 0.1.98 (tests)
    api.tableHtml = renderTable;   // 0.1.99 (tests)
    api.openType = function (r, on) { DMA_openTypes[r] = on !== false; };   // 0.1.104 (tests)
    api.feedbackHtml = DMA_feedbackHtml;   // 0.1.102 (tests)
    api.workflowsHtml = DMA_workflowsHtml; api.workflowsData = DMA_workflowsData;   // 0.1.103 (tests)
    api.ruleGroups = DMA_ruleGroups; api.resourceGroups = DMA_resourceGroups; api.rulesHtml = DMA_rulesHtml; api.setHtml = DMA_setHtml;   // 0.1.101 (tests)
    api.advKindOpts = DMA_advKindOpts; api.advAdviceHtml = DMA_advAdviceHtml; api.advFinishBtn = DMA_advFinishBtn;   // 0.1.100 (tests)
    api.advRunCard = DMA_advRunCard; api.advSpeedCard = DMA_advSpeedCard; api.advPlayable = DMA_advPlayable; api.advRuleRows = DMA_advRuleRows;   // 0.1.111 (tests)
    root.DMA_ConsoleUI = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;

    try { if (typeof debug === "function") debug("DMA Console UI " + VERSION + " loaded"); } catch (_) {}
    try { setTimeout(function () { DMA_log("stand not auto-loaded"); }, 800); } catch (_) {}

    /* 0.1.52 (author: "make it standard to move the island to my monitor and open the guild chat"): at start the game
       window goes to the player's monitor (the first screen that is not the main one; the main one when there is only
       one), is maximised, and the guild chat tab is put in front (retried for 2 minutes until the chat is ready). */
    /* 0.1.55: AIR hands out new Screen objects on every call, so "!== mainScreen" matched every screen and the window
       stayed on the laptop (log: "on screen 0,0 1920x1032"). Compare by bounds; the main screen is the one at 0,0. */
    function DMA_sameScreen(a, b) { try { return a.bounds.x === b.bounds.x && a.bounds.y === b.bounds.y && a.bounds.width === b.bounds.width; } catch (_) { return a === b; } }
    function DMA_pickScreen(screens, main) {
        var list = [], i; for (i = 0; i < (screens ? screens.length : 0); i++) list.push(screens[i]);
        var other = list.filter(function (sc) { return main ? !DMA_sameScreen(sc, main) : !(sc.bounds && sc.bounds.x === 0 && sc.bounds.y === 0); });
        other.sort(function (a, b) { try { return b.bounds.width * b.bounds.height - a.bounds.width * a.bounds.height; } catch (_) { return 0; } });
        return other.length ? other[0] : (main || list[0] || null);
    }
    function DMA_placeWindow() {
        try {
            var A = root.air || (typeof air !== "undefined" ? air : null), w = root.nativeWindow || (typeof window !== "undefined" ? window.nativeWindow : null);
            if (!A || !A.Screen || !w) return "no window access";
            var sc = DMA_pickScreen(A.Screen.screens, A.Screen.mainScreen); if (!sc) return "no screen";
            var b = sc.visibleBounds;
            if (w.displayState === "maximized") w.restore();
            w.x = b.x + 20; w.y = b.y + 20;
            w.maximize();
            return "on screen " + b.x + "," + b.y + " " + b.width + "x" + b.height;
        } catch (e) { return "failed: " + e; }
    }
    try {
        setTimeout(function () { DMA_log("window: " + DMA_placeWindow()); }, 3000);
        var DMA_guildTries = 0, DMA_guildTimer = setInterval(function () {
            var ok = false; try { ok = root.DMA_Chat && root.DMA_Chat.backToGuild ? root.DMA_Chat.backToGuild() : false; } catch (_) {}
            if (ok || ++DMA_guildTries >= 30) { clearInterval(DMA_guildTimer); DMA_log("guild chat at start: " + (ok ? "in front" : "not done")); }
        }, 10000);   // 0.1.55: up to 5 minutes
    } catch (_) {}
    api.pickScreen = DMA_pickScreen; api.placeWindow = DMA_placeWindow; api.advDefaultFolder = DMA_advDefaultFolder;   // 0.1.54
})(typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this));
