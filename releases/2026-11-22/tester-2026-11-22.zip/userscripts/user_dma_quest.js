/*
 * user_dma_quest.js — Quest manager (PBC Quest Management; DEMO TK71 "quest reward claiming") 0.1.0
 * 0.1.33 (2026-11-16, live finding 2026-11-16 20:52 UTC: two TK73 cases declared by the old explorer manager 0.4.33, search:4434616.0#2 (2x advLong, game count 0/2) and search:4448052.0#0 (4x advVeryLong, 0/4), stayed
 *   "declared": nothing accepted or rejected them, so nothing more was sent): DEMO declare -> reject when the product does not hold. A TK73 in state "declared" whose task the game counts below the amount (deltaStart, or no count at
 *   all, and status not 1) is REJECTED; the explorer manager 0.4.35 then resumes the order (needed = amount - progress, in flight, send, declare only at the game's count). It is read from the book every tick, so a case
 *   restored from the persisted book in "declared" is rejected the same way. A "rejected" order is treated like a promised one for the withdrawal (revoke request when the task is done, unticked, quest gone). Nothing else changes.
 *   Unit: tests/unit/dma-quest-reject-declared.test.js (declared with count 0/2 is rejected once; count at the amount with status 1 is accepted; restored case; a rejected order is withdrawn when the game counts done).
 *   Integration: tests/integration/dma-quest-explorer-orders.test.js (the restored "declared" 0/2 case is rejected and the explorer manager sends again).
 * 0.1.32 (2026-11-16, live finding 2026-11-16 on "Finding New Routes", uid 4434616.0; author: "Ja hij heeft een tussenstand"): the game keeps a progress count per trigger. q.mQuestTriggersFinished_vector items are
 *   Communication.VO::dQuestTriggerVO { status, deltaStart }; live 20:37 UTC: short (amount 2) = { status: 1, deltaStart: 2 }, medium and long = { status: 0, deltaStart: 0 }. So progress = Number(deltaStart) per trigger and
 *   done = status === 1 (the status stays authoritative: a count short of the amount is NOT done unless the game says status 1, and a count at the amount without status 1 is not done either). (1) A task carries progress
 *   (null when the game gives none) and the display text of a search task shows it ("specialists: 2\u00d7 Adventure Search (short): 1/2", in the status, the to-do list and the Console). (2) The TK73 order asks for amount - progress
 *   (searches), carries done = progress and asked = amount, and no longer subtracts the explorer manager's own sends (the old orderSeen guess is gone: the game's count is the truth). (3) searchProgress(key) answers the explorer
 *   manager with the last reading { progress, amount, done, at } of the order's task (the explorer manager does not read the quest book itself, ADR 0040). Nothing else changes.
 *   Unit: tests/unit/dma-quest-progress.test.js (live-shaped dQuestTriggerVO { status, deltaStart }: progress, done by status only, text, todo, the order's numbers, searchProgress).
 *   Integration: tests/integration/dma-quest-explorer-orders.test.js (quest manager + explorer manager over one fake game; the counter rises with finished searches; no declare before the game counts them).
 * 0.1.31 (2026-11-16, ADR 0077 / backbone v3.21, author 2026-11-16 "ja"; live probe user_dma_probe_quest 0.1.1: every trigger of "Finding New Routes" is type 45 with every field empty, so 99 of 107 tasks
 *   were named "finish another quest"): (1) a task is read from what it REALLY asks: the quest definition's endConditions_vector (an ArrayCollection, read with toArray / source / list), one TriggerVO per
 *   trigger matched by triggerIdx or position; a task carries action, item and amount (the end condition's, when it has one) and a text for display: specialisttaskfinished + FindAdventureZone{Short,Medium,
 *   Long,VeryLong} = "specialists: N× Adventure Search (short | medium | long | very long)", questcomplete = "finish quest <title>", any other action shows its action name (and item); "finish another quest" is
 *   shown only for questcomplete (the client's type 45 is now named "quest condition"). (2) The adventure searches of a ticked quest are routed to the explorer manager: the quest manager REQUESTS TK73 "search order
 *   completing" (AR71 -> AR73; case search:<quest uid>#<task index>; task advShort | advMedium | advLong | advVeryLong, searches = the amount still to send), WITHDRAWS it (revoke request) when the game marks the task
 *   done before all are sent, when the category is unticked, the Quest switch is off or the quest left the book, and ACCEPTS it when the game marks the task done (the game's finished flag, mQuestTriggersFinished_vector;
 *   no progress count was found: the order counts the explorer manager's own sends). The other specialisttaskfinished tasks are the player's ("needs you"); a quest with an unfinished search task is not paid early.
 *   Unit: tests/unit/dma-quest-end-conditions.test.js (live-shaped definition, tests/fixtures/quest-finding-new-routes.json). Integration: tests/integration/dma-quest-explorer-orders.test.js (quest manager + explorer
 *   manager + policy over one fake game: Finding New Routes ticked sends 2 short, 2 medium, 2 long, none beyond; withdrawn when done or unticked; an unticked category sends nothing).
 * 0.1.30 (2026-11-16, tester on #470, tests/known-failing/kf-quest-pay-unreadable-and-race.test.js): (1) the client's remaining value is read strictly: null, "" or anything not a finite number is
 *   UNREADABLE and never counts as covered (Number(null) and Number("") are 0). (2) While a payment is pending, no other payment is started on the same storage resource (not only the same quest):
 *   until the quest's payment is seen done / the quest gone, the remembered stock of that resource is seen to drop, or 10 minutes pass. Unit: tests/unit/dma-quest-pay-any-category.test.js (+ unreadable
 *   cases) and the moved test tests/unit/kf-quest-pay-unreadable-and-race.test.js. Integration: tests/integration/dma-quest-pay-flow.test.js.
 * 0.1.29 (2026-11-16, author decisions 2026-11-16: "alle pay from storage die ik in storage heb mag je uitvoeren ... actiever gaan kijken wat je zonder mij zou kunnen
 *   uitvoeren"): pay from storage is the quest manager's in EVERY category (not only guild) whenever the whole amount is in storage (the client's
 *   remaining value <= 0, else the remembered stock); the per-category ticks of the Quest page decide which categories act, there is no other limit.
 *   A payment the storage does not cover is shown "needs you". A quest whose other open tasks are only type 45 (the game counts it) is paid too.
 *   Live finding (dma-quest-todo.json 2026-11-16 14:01): the 81 "finish another quest" tasks are the client's real trigger type 45 (not an unknown-type
 *   fallback); the client names no target quest (name "", amount 0), so they stay "the game counts it" -- the only silent kind besides daily time/login.
 *   Every other task kind is routed or shown "needs you". Unit: tests/unit/dma-quest-pay-any-category.test.js (client-shaped tasks from the live
 *   files). Integration: tests/integration/dma-quest-pay-flow.test.js (a weekly and a starfall quest paid through the tick, short storage left to the player).
 * 0.1.28 (2026-11-16, tester round 2 on ADR 0073: kf-quest-refused-pickup-counts-as-miss): a pick-up the adapter REFUSED (start-up or visit hold, pace —
 *   retry: true) asked nothing of the game, so it is no round of the game: the first refusal ends the round at once — no TK72 request / execute /
 *   declare / reject, nothing added to pickedUp, no miss (so pickupStopped is never set by a hold), the pick-up marks are forgotten and the next
 *   tick tries again. A refusal later in a round only keeps its own building out of pickedUp. Unit: tests/unit/dma-pickups.test.js and
 *   tests/unit/quest-refused-pickup-waits.test.js (four refused rounds, then the hold ends: sent, not stopped). Integration:
 *   tests/integration/quest-pickup-with-control.test.js (real control + adapter: the start-up hold records nothing).
 * 0.1.27 (2026-11-16, ADR 0073 migration, coordinator batch item 2; needs adapter 0.2.3): the Pick-up call (message 141, DELIVER_PRODUCTION)
 *   goes through the Game Interface Adapter as the registered command QUEST_PICKUP; the quest manager no longer calls
 *   SendMessagetoServer. The production is marked as waiting for the server only after the adapter sent; a refusal (start-up or visit
 *   hold, adapter missing) forgets the pick-up mark so the next tick tries again, and is noted. No other behaviour change.
 *   Unit: tests/unit/dma-pickups.test.js (the 141 call reaches the game through the adapter; with the start-up hold on nothing is sent and
 *   the building is picked up on the next tick). Integration: tests/integration/quest-pickup-with-control.test.js (real control + adapter + quest: refused under the start-up hold, sent after).
 * 0.1.26 (2026-11-16, architecture review 2026-11-16 finding #12 / §5.2 "every automation switch defaults off", tester
 *   report 2026-11-16 (PR #373)): the quest manager's own reading of the Event switch fell back to ON when no policy
 *   answered (pol("event.auto", true) !== false). It now falls back to OFF; only true / "true" / "on" is on — the same
 *   as the event manager's (event 0.2.12, proposal #368). With the policy loaded nothing changes. No other behaviour change.
 *   Unit: tests/unit/dma-quest-event-gate.test.js (no policy -> the event gate is closed "event switch off"; the player's
 *   switch on -> open). Integration: tests/integration/dma-quest-event-default.test.js (quest manager + event manager
 *   with no policy and with the real policy: event quests are chosen only once the player switched Event on).
 * 0.1.25 (2026-11-11, author: "de zombies dienen zo snel mogelijk plaats te vinden nadat het mogelijk is"; live: after
 *   "They Will be Back" (HW2017plus_ZombieInvaders_Repeatable_Timer, 1 h) the next wave came only ~5 h 45 later, both
 *   times when the author was in the game): the zombie timer quest is claimed as soon as the game calls it finished,
 *   also in mode 10 (wait for finish) — the 0.1.4 rule against a second claim stays for every other quest. Every mode
 *   change of a zombie quest is a fact ("zombie quest mode", TK71) so the cycle can be read back.
 *   Unit: tests/unit/dma-quest-zombie-timer.test.js; integration: live, the next wave starts within a minute of the
 *   timer's hour.
 * 0.1.24 (2026-11-09, author: "de quest manager met eigen knop en scherm waarbij alle onderdelen geselecteerd kunnen
 *   worden inclusief event quest, dat weer afhankelijk is van het aanwezig zijn van een quest en de auto selectie van
 *   quest"): event quests are chosen only while (1) the Quest switch is on (quest.auto), (2) an event runs (the event
 *   manager observes one) and its switch is on (event.auto), and (3) quest.do.event is on. eventGate() says which of
 *   these holds and how many event quests the book holds now, for the quest manager's screen.
 *   Unit: tests/unit/dma-quest-event-gate.test.js; integration: live, with no event running the QUEST screen greys out
 *   "event quests" and names the reason.
 * 0.1.23 (2026-11-09, author: "Green onthoudt alleen en doet berekeningen. Een rode transactor role bufft"): a buff task
 *   routes to the buffer (TK41, root.DMA_Buffer); a building / production task to the build and upgrade roles, which
 *   green's computation initiates (green itself executes nothing).
 * 0.1.22 (2026-11-09, live 0.1.21: "buff manager" not loaded): the buffer on the client is green; a buff task routes to
 *   "buffer (green)".
 * 0.1.21 (2026-11-09, author: "begin daarna aan de quest manager die ook een pagina heeft met allerlei onderdelen die hij
 *   actief in de gaten moet houden en dient te beleggen bij de juiste executor"; live 0.1.20: 88 help items, mostly false):
 *   - ROUTES: every task kind is assigned to its executor — an actor role and the module(s) it needs (root globals).
 *     A task counts as covered only when that executor is loaded; otherwise it is declined to the player (Q-5).
 *     Kinds the game counts on its own (type 45 — the building-bonus and event progress, see
 *     docs/05-ontology/dma-implementation/event-notes.md — daily time, daily login, production time) are WATCHED, not
 *     asked: they no longer fill the help list. "Pay from storage" stays the guild quest's alone (Q-3); in another
 *     category it is the player's choice.
 *   - categories: the game's "Story" holds more than the story. specialType regularDailyQuestList and DailyLogin* are
 *     daily; BuiBonus_* quests (building-bonus loops: Depositorium, Witch Coven, Harbour ...) get their own category
 *     "building" (rule quest.do.building, policy 0.2.49), except where the game types them GhostShip / Event / Guild.
 *   - watch(): what the manager keeps an eye on, for the QUEST page and dma-quest-watch.json — per category: on,
 *     open quests, rewards ready, tasks that need the player; per executor: the kinds routed to it, loaded or not, and
 *     how many open tasks wait for it.
 *   Unit: tests/unit/dma-quest-routes.test.js; integration: live, dma-quest-help.json drops from 88 items to the tasks
 *   with no loaded executor, and dma-quest-watch.json lists the executors.
 * 0.1.20 (2026-11-09, author: "event quest have a high priority if auto is selected"): an event quest is chosen only
 *   while both quest.do.event and the Event switch (event.auto, event 0.2.8) are on; then the to-do list puts the event
 *   quests first, right after the rewards that are ready, each group by time left.
 *   Unit: tests/unit/dma-quest-categories.test.js; integration: live, with Event on the Halloween quests lead the list.
 * 0.1.19 (2026-11-09, ADR 0053, author: "the probe will check the whole quest book and make a to do list from urgent to have a
 *   long to ackomplish for"): todo() — every open quest of a chosen category (running, new or with its reward ready) as one
 *   to-do item: category, open tasks (DMA executor or "needs you"), time left; sorted by time left (a reward ready first,
 *   then the nearest end, quests without an end time last, guild before daily before weekly ...). Written to
 *   dma-quest-todo.json every status interval. The game's time fields per quest (zero-argument getters of the quest
 *   and its definition whose names speak of time, end, expiry or duration) are kept as times{} so the end time is read
 *   from the game, not guessed; endsAt comes from the first that is a date or a remaining time.
 *   Unit: tests/unit/dma-quest-categories.test.js (to-do order); integration: live, dma-quest-todo.json lists the guild
 *   quest with its time left.
 * 0.1.18 (2026-11-09, ADR 0053, author: "in general goes for the guild quest: it should be part of the quest manager. If that
 *   knob is set to auto, all quest of the quest book will be read. Within the quest book the player can choose what to do
 *   and what not to do: guild quest, dailys, weeklys, ghost ship, starfall, event quest (condition quest must be on auto
 *   too), main quests and side quests. If this manager has no available executor he must notify the player"):
 *   - every quest gets a category (guild, daily, weekly, ghostship, starfall, event, main, side, other) from the game's
 *     quest type; rule quest.do.<category> (default on) decides whether the manager starts, pays and claims it;
 *   - Q-5 (help): for every chosen quest that runs, each open task whose kind has no executor (CAN "") is a TK71 decline
 *     "no executor — the player's help is asked", recorded once per quest and task, listed in state.help, in
 *     dma-quest-status.json and in dma-quest-help.json (read by the console and by sessions), with the quest's end time
 *     when the game gives one. The guild quest comes first.
 *   Unit: tests/unit/dma-quest-categories.test.js; integration: live, the open "buff on a friend" task of a guild quest
 *   appears in dma-quest-help.json within one tick.
 * 0.1.17 (2026-11-08, merged onto 0.1.16; first written as 0.1.13 on a branch; author after a guild-chat reminder about an unfinished guild quest: "it is something you easily
 *   could have done yourself ... improve your program that it wont happen again"): Q-3 is switched on for guild quests.
 *   A Guild quest that is running, whose only open tasks are "pay from storage" (trigger type 18), and whose payment the
 *   storage covers (the client's own GetRemainingValuesForQuestTrigger <= 0 for every such task) is paid the way the
 *   Quest Book's pay button does it (QuestClientCallbacks.InitiatePayForQuestFinish(quest uid)); DEMO TK71 case
 *   pay:<uid>: request -> execute -> declare (observed: the task done / the quest left the book) -> accept. At most one
 *   payment per quest per 30 minutes. Policy quest.pay.on (default on), under quest.auto. The guild quest is always
 *   handled first. Nothing else changes.
 *   Unit expectation: dma-quest-pay.test.js — a guild quest with only an unpaid type-18 task and remaining <= 0 is paid
 *   once; remaining > 0 or another open task: not paid. Integration expectation: the next guild quest with a storage
 *   delivery is completed by the quest manager without the player.
 * 0.1.16 (2026-11-04, live: handleSelectBuilding picked nothing up either; decompiled client.swf, cSkillProductionPanel
 *   .pickUpHandler and cMayorhouseInfoPanel.handlePickUpCollection — the game's own pickup): a pickup marks the first
 *   production as waiting for the server and sends COMMAND.DELIVER_PRODUCTION (141) with the viewed (home) zone and the
 *   building's productionType — exactly what the Pick-up button does. Only for a production that is readyForDeliver
 *   (control 0.2.83). The two-misses safeguard of 0.1.15 stays.
 *   Unit expectation: dma-pickups.test.js (SendMessagetoServer(141, zone, productionType) once per ready building).
 *   Integration expectation: the icon disappears and TIMED_PRODUCTION.timedProducedItems fires.
 * 0.1.15 (2026-11-04, probe 0.2.1: the building's own click handler is handleSelectBuilding():Boolean; the queue's
 *   deliver / finishProduction take ServerState::cPlayerData — they apply the server's answer and are never called):
 *   a pickup calls building.handleSelectBuilding() (what the player's click runs), falling back to nothing. Pickups are
 *   on again (quest.pickup.on default true) with a safeguard: two rounds in a row that picked nothing up switch Q-4c off
 *   for the session and record why (state.pickupStopped), so a wrong call can never repeat every two minutes.
 *   Unit expectation: dma-pickups.test.js (handleSelectBuilding is called; two rejected rounds -> stopped).
 *   Integration expectation: the Mayorhouse/Bookbinder queue stops waiting and timedProducedItems fires.
 * 0.1.14 (2026-11-04, live test of 0.1.13: SelectBuilding selects Mayorhouse and Bookbinder but picks nothing up —
 *   declare "picked 0, left 2", every 2 minutes): pickups are OFF by default (quest.pickup.on false) until the game's
 *   own pickup call is known (probe user_dma_probe_pickups 0.2.1); a round that picked nothing up is rejected by the
 *   quest manager instead of accepted (DEMO 4: the initiator rejects a declared result that is not the product).
 *   Unit expectation: dma-pickups.test.js (switch off by default -> nothing; picked 0 -> reject).
 *   Integration expectation: no buildingSelected events from DMA while the switch is off.
 * 0.1.13 (2026-11-04, author: "de hartjes zijn er weer, de verrekijker en de kadootjes, hadden we dat niet
 *   geautomatiseerd?"; live: the select round Q-4b never fired on 2026-11-01..04 — those icons are no quest triggers):
 *   Q-4c PICKUPS. The icons are timed productions waiting to be picked up (productionQueue.waitForPickup, noted by the
 *   location manager's scan as finds().pickups, control 0.2.82). The quest manager picks them up the way a click does
 *   (SelectBuilding), one per second, behind quest.auto and quest.pickup.on (default on); quest.pickup.skip (names,
 *   comma separated) leaves buildings to the player. It acts on the picture as it is — no 10-minute wait —, but never
 *   on the same building twice within 2 minutes (the picture may still show it until the next scan). Fact TK72 with
 *   what="pickup" and the names.
 *   Unit expectation: finds().pickups [Mayorhouse, LoveTree], skip "LoveTree" -> SelectBuilding(Mayorhouse) only; the
 *   same building again within 2 min -> nothing. Integration expectation: Mayorhouse/Bookbinder icons disappear and
 *   TIMED_PRODUCTION.timedProducedItems fires after the round.
 * 0.1.12 (2026-11-02, test of this version: claim:4282733.0 (DailyLoginBonusAdv2) stayed "promised" for over three
 *   hours — it was claimed at 00:00 UTC, the client restarted, and the memory of the claim (claimTried) did not survive
 *   the restart): an open claim:/start: instance in the transaction book (DMA_Tx) that is older than one cycle and whose
 *   quest left the quest book is declared (the game, observed) and accepted; an open start: whose quest is listed and no
 *   longer new likewise. Only when the quest book is read (not empty). Behaviour otherwise unchanged.
 *   Unit/integration expectation: dma-quest.test.js (open claim in the book after a restart, quest gone -> declare + accept).
 * 0.1.11 (2026-11-02, test of this version: a claimed Guild quest left the quest book and its TK71 stayed "promised"
 *   for over an hour — the declare only looked at quests still listed): a claim whose quest is no longer in the book is
 *   declared (the game, observed: the quest left the quest book) and accepted once. Behaviour unchanged.
 *   Unit/integration expectation: dma-quest.test.js (claim, quest gone -> declare + accept).
 * 0.1.10 (2026-11-02, live: the client did not load 0.1.9 — the field `case` is a JavaScript keyword, which the client's old
 *   engine refuses as a property name although Node accepts it): the case field is now `caseId`. Nothing else changes.
 *   Unit: tests/unit/dma-es3-keywords.test.js; integration: the module loads in the client (DMA Console in Tools).
 * 0.1.9 (2026-11-02, author: "Deze demo gedachte moet dus consequent worden doorgevoerd voor alle transactiesoorten"):
 *   only DEMO 4 acts, one instance per case (claim:<quest uid>, start:<quest uid>, select@time, collect@time):
 *   request (quest manager) -> execute (the click; promise tacit) -> declare (the game, observed: the quest left the
 *   reward window / is no longer new / the clicks are done) -> accept (quest manager). A claim still in the reward window
 *   two cycles later is revoke request + allow (tacit) (was "failed"); a click that throws is a decline by the game
 *   (was "failed"). Behaviour unchanged.
 *   Unit/integration expectation: dma-quest.test.js; tests/unit/dma-demo4-acts.test.js.
 * 0.1.8 (2026-11-01, test day P6; author: "Voer alle verbeteringen maar door"): the QUEST page showed "type 45"; every
 *   trigger type of the client now has a name (QuestManagerStatic TYPE_1..46). Unit: dma-quest.test.js (45 named).
 * 0.1.3 (2026-10-25, author: "when I go to another island the orders carry on; they must stop"): no tick while the
 *   player is on another island (DMA_Control.atHome() false); requests wait until he is home.
 *
 * 0.1.7 (2026-10-28, author: "there is only one scan, initiated by the location manager, for everyone"): the quest
 *   manager no longer walks the island. Collectibles and buildings with a quest trigger come from the location
 *   manager's scan (DMA_Control.finds(), control 0.2.42). A scan older than quest.collectEveryMin is not acted on: the
 *   quest manager waits for the next one. "Pick up now" asks the location manager for a fresh scan first.
 * 0.1.6 (2026-10-26, event preparation; author: "event quests you can do, do them without asking"): (1) the status file
 *   and the QUEST page hold only quests still open (not collected, not deactivated) — the pool holds 1,123 quests, the
 *   file had grown to 541 KB written every 2 min; (2) every task also carries the trigger's action / resource type /
 *   time / index fields (type 45 "new trigger" is most of the event quests' tasks: its meaning is in those fields).
 * 0.1.5 (2026-10-26, author: four groups of collectables the player clicks — collectibles, the hearts on the Balloon
 *   Market, the gifts in the Gift Christmas Tree, the Celebrative Outlook with a telescope; "when we have the rule engine
 *   collectables can be added" — ADR 0016 amendment). Read from client.swf: the icons over buildings are QUEST TRIGGERS of
 *   type 1 (building) / condition 9 (selected); clicking the building runs SelectBuilding → mQuestClientCallbacks
 *   .BuildingSelectedGui(b), which sends QUEST_TRIGGER{type 2, data grid} when mClientQuestPool.ContainsTriggerCondition(1, 9,
 *   name, "buildingselected", name, null). Q-4b: every home-zone building whose name carries such a trigger is "selected"
 *   that way — once per building name, 1 s apart, no info panel — behind quest.auto and quest.select.on, at the
 *   collectibles interval; quest.select.names (empty = every name with a trigger) is the list the player (and later the
 *   rule engine) narrows or extends. The finished quest is then claimed by Q-2. Fact TK72 with what="select".
 * 0.1.4 (2026-10-25, live after the 19:05 restart: the guild reward "Retirement Plan Reward" in mode 10 — wait for
 *   finish, the guild timer — was claimed again because the record of the claim did not survive the restart): a quest
 *   in mode 10 (wait for finish) or 1 (claim sent) is never claimed; it waits for the game.
 * 0.1.2 (2026-10-25, live: the collection quest "Collect all" was finished but not in the list the DMA read; the
 *   Quest Book showed it and closing it — CloseQuestImpl → RewardOkButtonPressedFromGui — finished it): the quests are
 *   read from EVERY pool the client keeps — mNewQuestManager.GetQuestPool(), mQuestClientCallbacks.GetQuestPool() and
 *   GetClientQuestPool() — once each (by unique id), so collection and event quests are finished too.
 * 0.1.1 (2026-10-25, author: "a completed quest must also be selected to finish it"): read from client.swf — the
 *   quest modes are QuestManagerStatic.QUEST_MODE_* (0 failed, 2 start window waiting for the button, 3 running,
 *   4 init reward window, 5 reward window waiting for the button, 8 press reward button, 10 wait for finish,
 *   12 reward collected). Selecting a quest in the Quest Book (cQuestBook.DisplayQuest) does two things the DMA now
 *   does too: a quest in mode 2 is started (QuestOkButtonPressedFromGui — rule quest.start.on), and a finished quest
 *   (dQuestElementVO.isFinished(): mode 4 or 5) shows the close button whose press is CloseQuestImpl →
 *   RewardOkButtonPressedFromGui (the claim, Q-2). "Finished" is now the game's own isFinished(), not a mode list.
 *
 * 0.1.0 (2026-10-25, author: "the quest book is every assignment that is open, the guild quest the most important;
 *   analyse which ones you can carry out automatically and what that needs" — ADR 0016; approved: Q-1 and Q-2):
 *   - Q-1 READ: every quest of the game's quest pool (game.gi.mQuestClientCallbacks.GetQuestPool().GetQuest_vector()),
 *     with its kind (Guild / Daily / Story / Optional / Event), its mode and its tasks (questTriggers_vector: type,
 *     condition, what, amount, done), and per task whether the DMA can do it (by trigger type). Guild first. Read only;
 *     written to dma-quest-status.json for the console QUEST page and for analysis.
 *   - Q-2 CLAIM: a quest in the reward window (mode 4 / 5 / 8, reward not collected) gets its reward claimed with the
 *     game's own call RewardOkButtonPressedFromGui(quest) (QUEST_TRIGGER 100, type 1) — behind the Quest switch
 *     (quest.auto) and the rule quest.claim.on. One claim per cycle; a quest still in the reward window two cycles
 *     after a claim is recorded as failed and not tried again this session (fail closed).
 *   - Q-4a COLLECTIBLES (author 2026-10-25 18:30: "there are collectables on the island now; they are in the quest book
 *     too; the solution is already in the client — it only needs to be activated"): the client's own Shortcuts →
 *     Collectibles (scripts/8-shortcuts.js shortcutsPickupAll) selects every building on the home zone that
 *     Collections::CollectionsManager.getBuildingIsCollectible says is a collectible, one per second. The quest manager
 *     does the same on the home zone, behind quest.auto and quest.collect.on, every quest.collectEveryMin minutes, and
 *     only when there is one (no "No collectibles found" alert). Fact TK72 execute with the count.
 *   - The quest pool is read from game.gi.mNewQuestManager (what the client's own scripts use), else
 *     mQuestClientCallbacks; the claim call is looked up on both.
 *   - NEVER the gem finish (BUY_ONE_CLICK_SHOP_ITEM / questWinGemCosts): this module has no path to it.
 *
 * DEMO: the quest manager (an agent for the player) is the executor of TK71 for quests the game declares finished;
 * the player stays accountable. A quest is the case; this PBC remembers quest facts only.
 */
(function (root) {
    "use strict";
    if (root.DMA_Quest && root.DMA_Quest.version) return;
    var VERSION = "0.1.33", TICK_MS = 30000, STATUS_MS = 120000;
    var ZOMBIE_TIMER = /ZombieInvaders_Repeatable_Timer/, zombieModes = {};   // 0.1.25
    function zombieWatch(list) { list.forEach(function (x) { if (!/ZombieInvaders/.test(x.name) || zombieModes[x.uid] === x.mode) return; zombieModes[x.uid] = x.mode;
        try { if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("p", { tk: "TK71", fact: "zombie quest mode", quest: x.name, uid: x.uid, mode: x.mode, state: x.state, finished: !!x.reward }); } catch (_) {} }); }
    root.DMA_QuestZombieRule = function (name, mode, fin) { return fin && mode !== 1 && (mode !== 10 || ZOMBIE_TIMER.test(String(name))); };
    var MODE = { 0: "failed", 1: "claim sent", 2: "new, not started", 3: "running", 4: "finished", 5: "finished", 6: "start delay", 7: "description", 8: "reward button", 9: "next daily pending", 10: "waiting for finish", 11: "deactivated", 12: "collected" };
    var REWARD = { 4: 1, 5: 1 };   // 0.1.1: isFinished() in the game
    /* 0.1.8 (test day P6): every trigger type of the client (QuestManagerStatic.TYPE_*), never a bare "type N" */
    var KIND = { 1: "building", 2: "resource", 3: "experience", 4: "player level", 5: "sector", 6: "specialist", 7: "military unit",
                 8: "buff", 9: "buildings with units", 10: "adventure", 11: "loot", 12: "daily time", 13: "daily login",
                 14: "start a quest", 15: "random quest", 16: "buff on a friend", 17: "buff by a friend", 18: "pay from storage",
                 19: "friends", 20: "guild daily time", 21: "guild size", 22: "finish percentage", 23: "open a window",
                 24: "press a key", 25: "complete a quest", 26: "win a battle", 27: "check storage", 28: "check population",
                 29: "check army", 30: "play an adventure", 31: "move a building", 32: "refill a deposit", 33: "shop item",
                 34: "specialist task", 35: "production time", 36: "bandits", 37: "visit a friend", 38: "production value",
                 39: "refill buff", 40: "collection", 41: "skill level", 42: "bronze skill points", 43: "silver skill points",
                 44: "gold skill points", 45: "quest condition", 46: "event collection",   // 0.1.31: type 45 is the client's generic trigger; what it asks is in the end condition
                 search: "specialist searches (asked of the explorer manager)" };
    // what the DMA can do per trigger type (ADR 0016); "" = not automatable
    var CAN = { 18: "pay (Q-3: every category)", 1: "build / upgrade managers", 2: "production", 6: "geologists",
                34: "specialist managers", 8: "buff manager", 27: "storage", 32: "refill (needs refill buffs)", 12: "time", 20: "time", 35: "time" };
    /* 0.1.21: the executor of each task kind — actor role and the modules it needs; watch: the game counts it itself */
    var ROUTES = {
        1: { actor: "builder / upgrader (initiated by green)", uses: ["DMA_Green"] },
        2: { actor: "producer (initiated by green)", uses: ["DMA_Green"] },
        6: { actor: "geologists (agents)", uses: ["DMA_Demo"] },
        8: { actor: "buffer (TK41)", uses: ["DMA_Buffer"] },
        18: { actor: "pay (quest manager)", uses: ["DMA_Quest"], storage: true },   // 0.1.29: every category, when the whole amount is in storage
        27: { actor: "storage (watched)", watch: true },
        32: { actor: "refill (event manager)", uses: ["DMA_Event"] },
        34: { actor: "specialists (agents)", uses: ["DMA_Demo"] },
        46: { actor: "collectibles (quest manager)", uses: ["DMA_Quest"] },
        12: { actor: "the game (time)", watch: true }, 13: { actor: "the game (daily login)", watch: true },
        20: { actor: "the game (time)", watch: true }, 35: { actor: "the game (time)", watch: true },
        45: { actor: "the game counts it", watch: true },
        search: { actor: "explorer manager (TK73)", uses: ["DMA_Demo", "DMA_Tx"], needsSwitch: "expo.auto" }   // 0.1.31 (ADR 0077): adventure searches the quest asks for
    };
    function loaded(uses, g) { g = g || root; return !!uses && uses.length > 0 && uses.every(function (n) { try { return !!g[n]; } catch (_) { return false; } }); }
    /* who does this task here: the actor when its executor is loaded (or it is watched), else "" (the player) */
    function executorOf(type, cat, g) {
        var r = ROUTES[type]; if (!r) return "";
        if (r.watch) return r.actor;
        if (r.only && r.only !== cat) return "";
        if (r.needsSwitch && pol(r.needsSwitch, false) !== true) return "";   // 0.1.31: the executor acts only while the player's switch is on (Expo)
        return loaded(r.uses, g) ? r.actor : "";
    }
    var ORDER = { Guild: 0, Daily: 1, Story: 2, Optional: 3, Event: 4 };
    /* 0.1.18 (ADR 0053): the player's choice per category of the quest book */
    var CATS = ["guild", "daily", "weekly", "ghostship", "starfall", "event", "main", "side", "building"];   // 0.1.21: building
    function category(x) {
        var k = String(x && x.kind || ""), sp = String(x && x.special || ""), nm = String(x && x.name || "");
        if (k === "Guild" || sp === "guildQuest" || /Guild/.test(k)) return "guild";
        if (k === "Daily" || sp === "regularDailyQuestList" || /^DailyLogin/.test(nm)) return "daily";   // 0.1.21
        if (/Weekly/i.test(k)) return "weekly";
        if (/GhostShip/i.test(k)) return "ghostship";
        if (/Starfall/i.test(k)) return "starfall";
        if (k === "Event") return "event";
        if (/^BuiBonus_/.test(nm)) return "building";   // 0.1.21: building-bonus loops
        if (k === "Story") return "main";
        if (k === "Side" || k === "Optional") return "side";
        return "other";
    }
    function eventOn() { var v = pol("event.auto", false); return v === true || v === "true" || v === "on"; }   // 0.1.20: the Event switch; 0.1.26: default off
    /* 0.1.24: an event runs (null: the event manager is not loaded — not known) */
    function eventRunning() { try { var E = root.DMA_Event; if (!E || typeof E.events !== "function") return null; return E.events().length > 0; } catch (_) { return null; } }
    function chosen(x) { var c = category(x); if (c === "other") return false; if (c === "event" && (!eventOn() || eventRunning() === false)) return false; return pol("quest.do." + c, true) !== false; }
    /* 0.1.24: may the quest manager do event quests now, and why not */
    function eventGate(list) {
        var auto = pol("quest.auto", false) === true, ev = eventOn(), run = eventRunning(), want = pol("quest.do.event", true) !== false;
        var present = (list || []).filter(function (x) { return x.category === "event" && x.mode !== 12 && x.mode !== 11 && !x.collected; }).length;
        var why = !auto ? "Quest switch off" : run === false ? "no event running" : !ev ? "Event switch off" : !want ? "event quests not selected" : "";
        return { selectable: auto && run !== false && ev, on: !why, reason: why, eventRunning: run, present: present };
    }
    var state = { startedAt: null, ticks: 0, lastError: "", claimed: 0, failed: 0, quests: 0 };
    var claimTried = {}, gaveUp = {}, startTried = {}, payTried = {}, lastStatusAt = 0, timer = null, last = [], lastReadAt = 0;

    function note(s) { state.lastError = String(s).slice(0, 300); }
    function record(act, d) { try { var o = d || {}; o.tk = (o.what === "collectibles" || o.what === "select" || o.what === "pickup") ? "TK72" : o.what === "search" ? "TK73" : "TK71"; o.act = act; if (!o.actor) o.actor = "quest manager"; if (root.DMA_Demo && root.DMA_Demo.record) root.DMA_Demo.record("c", o); } catch (_) {} }
    function pol(k, dflt) { try { var p = root.GCAF_PlayerPolicyInstance; if (p && p.get) { var v = p.get(k); return v == null ? dflt : v; } } catch (_) {} return dflt; }
    function air_() { try { return (typeof air !== "undefined") ? air : root.air; } catch (_) { return root.air || null; } }
    function writeJson(name, obj) {
        try { var a = air_(); if (!a) return; var f = new a.File(a.File.applicationDirectory.resolvePath(name).nativePath);
              var st = new a.FileStream(); st.open(f, a.FileMode.WRITE); st.writeUTFBytes(JSON.stringify(obj, null, 1)); st.close(); } catch (e) { note("write " + e); }
    }
    function gi() { try { return (root.game && root.game.gi) || null; } catch (_) { return null; } }
    function callbacks() { var g = gi(); if (!g) return null; return g.mNewQuestManager || g.mQuestClientCallbacks || null; }
    function claimer() { var g = gi(); if (!g) return null; var a = [g.mQuestClientCallbacks, g.mNewQuestManager], i; for (i = 0; i < a.length; i++) if (a[i] && typeof a[i].RewardOkButtonPressedFromGui === "function") return a[i]; return null; }
    function vec(v) { var out = [], i; if (!v) return out; try { for (i = 0; i < v.length; i++) out.push(v[i]); } catch (_) {} return out; }
    function uidOf(q) { try { var u = q.mUniqueID; if (u == null) return ""; if (typeof u === "object") return String(u.uniqueID1 != null ? u.uniqueID1 + "." + u.uniqueID2 : (u.toString ? u.toString() : JSON.stringify(u))); return String(u); } catch (_) { return ""; } }
    function title(name) { var t = ""; try { if (typeof loca !== "undefined" && loca.GetText) t = String(loca.GetText("QUL", name) || ""); } catch (_) {} if (!t || /^\[|undefined|missing/i.test(t) || t === name) t = String(name || "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/_/g, " "); return t; }
    function triggerProgress(q, i) {   // 0.1.32: the game's own count of the trigger (dQuestTriggerVO.deltaStart), null when it gives none
        try { var f = vec(q.mQuestTriggersFinished_vector)[i]; if (f && f.deltaStart != null && f.deltaStart !== "") { var n = Number(f.deltaStart); if (isFinite(n) && n >= 0) return n; } } catch (_) {}
        return null;
    }
    function triggerDone(q, i) {
        try { var f = vec(q.mQuestTriggersFinished_vector)[i]; if (f && f.status != null) return Number(f.status) === 1; } catch (_) {}
        try { var s = q.GetTriggerStatus(i); if (s != null && typeof s !== "object") return Number(s) === 1; if (s && s.status != null) return Number(s.status) === 1; } catch (_) {}
        return false;
    }
    /* pure: classify one trigger (exported for the unit expectation) */
    function classify(t) {
        var type = Number(t && t.type);
        return { type: type, kind: KIND[type] || ("type " + type), can: CAN[type] || "" };
    }
    /* 0.1.19: readable time fields of a quest and its definition */
    function timeFields(q, def) {
        var out = {}, re = /time|end|expir|dead|durat|until|valid|remain|left|start/i;
        [[q, "q."], [def, "def."]].forEach(function (pr) {
            var o = pr[0]; if (!o) return; var seen = {}, k;
            try { for (k in o) seen[k] = 1; } catch (_) {}
            try { var pt = Object.getPrototypeOf(o); while (pt && pt !== Object.prototype) { Object.getOwnPropertyNames(pt).forEach(function (n) { seen[n] = 1; }); pt = Object.getPrototypeOf(pt); } } catch (_) {}
            Object.keys(seen).forEach(function (n) { if (!re.test(n) || /^set|Set/.test(n)) return;
                try { var v = o[n]; if (typeof v === "function") { if (v.length !== 0 || !/^(get|Get|is|Is)/.test(n)) return; v = v.call(o); }
                      if (typeof v === "number" || (typeof v === "string" && v.length < 40) || typeof v === "boolean") out[pr[1] + n] = v; } catch (_) {} });
        });
        return out;
    }
    /* 0.1.31 (ADR 0077): what a task REALLY asks is in the quest definition's endConditions_vector (an mx ArrayCollection of Communication.VO::TriggerVO), not in questTriggers_vector */
    function endVec(def) {
        var v = null; try { v = def && def.endConditions_vector; } catch (_) {}
        if (!v) return [];
        try { if (typeof v.toArray === "function") { var a = v.toArray(); if (a && a.length != null) return vec(a); } } catch (_) {}
        try { if (v.source && v.source.length != null) return vec(v.source); } catch (_) {}
        try { if (v.list && v.list.source && v.list.source.length != null) return vec(v.list.source); } catch (_) {}
        try { if (v.length != null) return vec(v); } catch (_) {}
        return [];
    }
    /* the end condition of trigger i: the entry that names it by triggerIdx, else the entry at position i when that names no other trigger */
    function endFor(ends, i) {
        var k, e;
        for (k = 0; k < ends.length; k++) { e = ends[k]; if (e && e.triggerIdx != null && e.triggerIdx !== "" && Number(e.triggerIdx) === i) return e; }
        e = ends[i];
        return (e && (e.triggerIdx == null || e.triggerIdx === "" || Number(e.triggerIdx) === i)) ? e : null;
    }
    var ADV_SEARCH = { FindAdventureZoneShort: ["advShort", "short"], FindAdventureZoneMedium: ["advMedium", "medium"], FindAdventureZoneLong: ["advLong", "long"], FindAdventureZoneVeryLong: ["advVeryLong", "very long"] };
    /* pure: the display text and the route of one end condition (exported as endText for the unit expectation) */
    function endText(action, item, amount) {
        var act = String(action || "").toLowerCase(), it = String(item || ""), n = Number(amount) > 0 ? Number(amount) : 0, per = n ? n + "\u00d7 " : "";
        if (!act) return null;
        if (act === "specialisttaskfinished") {
            var adv = ADV_SEARCH[it];
            if (adv) return { text: "specialists: " + per + "Adventure Search (" + adv[1] + ")", search: adv[0], route: "search" };
            return { text: "specialists: " + per + (it ? title(it) : "task"), route: "none" };   // a specialist task no manager does: the player's
        }
        if (act === "questcomplete") return { text: "finish quest " + (it ? title(it) : "?") };
        if (act === "questactive") return { text: "have quest " + (it ? title(it) : "?") + " active" };
        return { text: act + (it ? " " + it : "") + (n ? " \u00d7" + n : "") };
    }
    function read() {
        var g = gi(); if (!g) return null;
        var pools = [], qs = [], seenUid = {};                                         // 0.1.2: every pool
        [[g.mNewQuestManager, "GetQuestPool"], [g.mQuestClientCallbacks, "GetQuestPool"], [g.mQuestClientCallbacks, "GetClientQuestPool"]].forEach(function (x) {
            try { if (x[0] && typeof x[0][x[1]] === "function") { var pl = x[0][x[1]](); if (pl && pools.indexOf(pl) < 0) pools.push(pl); } } catch (_) {}
        });
        if (!pools.length) return null;
        pools.forEach(function (pl) { try { vec(pl.GetQuest_vector()).forEach(function (q) { var u = uidOf(q); if (!q || (u && seenUid[u])) return; if (u) seenUid[u] = 1; qs.push(q); }); } catch (e) { note("pool " + e); } });
        var out = [];
        qs.forEach(function (q) {
            try {
                var def = q.mQuestDefinition || {}, mode = -1; try { mode = Number(q.GetQuestMode()); } catch (_) {}
                var kind = String(def.type_string || ""), special = String(def.specialType_string || "");
                if (special === "guildQuest") kind = "Guild";
                var tasks = vec(def.questTriggers_vector).map(function (t, i) {
                    var c = classify(t);
                    var o = { type: c.type, kind: c.kind, can: "", condition: Number(t.condition), what: String(t.name_string || ""), amount: Number(t.amount) || 0, done: triggerDone(q, i) };
                    try { if (t.actionName_string) o.action = String(t.actionName_string); if (t.resourceType_string) o.resType = String(t.resourceType_string); if (t.time) o.time = Number(t.time); if (t.triggerIdx != null) o.idx = Number(t.triggerIdx); } catch (_) {}   // 0.1.6
                    return o;
                });
                var ends = endVec(def);   // 0.1.31 (ADR 0077): what each task really asks
                tasks.forEach(function (o, i) {
                    var e = endFor(ends, i); if (!e) return;
                    var act = String(e.action_string || "").toLowerCase(), item = String(e.item_string || ""), n = Number(e.amount) > 0 ? Number(e.amount) : 0;
                    if (!act && !item) return;
                    o.action = act; o.item = item; if (n) o.amount = n;
                    var nm = (o.type === 45 || act === "specialisttaskfinished" || act === "questcomplete") ? endText(act, item, o.amount) : null;
                    if (nm) { o.kind = nm.text; o.text = nm.text; if (nm.route) o.route = nm.route; if (nm.search) o.search = nm.search; }
                    if (nm && nm.search) { o.progress = triggerProgress(q, i); if (o.progress != null && o.amount > 0) o.text = nm.text + ": " + o.progress + "/" + o.amount; }   // 0.1.32
                });
                var collected = false; try { collected = !!q.IsRewardCollected(); } catch (_) {}
                var fin = !!REWARD[mode]; try { if (typeof q.isFinished === "function") fin = !!q.isFinished(); } catch (_) {}   // 0.1.1
                var ends = null, times = timeFields(q, def);   // 0.1.19: the game's own time fields
                Object.keys(times).forEach(function (k) { if (ends != null) return; var v = Number(times[k]); if (!(v > 0)) return;
                    if (/end|expir|dead|until|valid/i.test(k) && v > 1.5e12) ends = v;                                          // a date in ms
                    else if (/end|expir|dead|until|valid/i.test(k) && v > 1.5e9 && v < 4e9) ends = v * 1000;                  // a date in s
                    else if (/remain|left/i.test(k)) ends = Date.now() + (v > 1e7 ? v : v * 1000); });                       // a remaining time
                var o0 = { uid: uidOf(q), name: String(def.questName_string || ""), title: title(def.questName_string), kind: kind || "?", special: special,
                           mode: mode, state: MODE[mode] || ("mode " + mode), reward: fin && !collected && mode !== 1 && (mode !== 10 || ZOMBIE_TIMER.test(String(def.questName_string || ""))), isNew: mode === 2, collected: collected, tasks: tasks, _q: q };
                o0.category = category(o0);
                o0.tasks.forEach(function (t, i) { t.can = executorOf(t.route || t.type, o0.category); t.watch = !!(ROUTES[t.route || t.type] && ROUTES[t.route || t.type].watch);   // 0.1.21; 0.1.31: route = the end condition's own
                    if (ROUTES[t.type] && ROUTES[t.type].storage && !t.done) { t.stored = inStorage(t, q, i); if (!t.stored) t.can = ""; } });   // 0.1.29: a payment nobody can make from storage stays the player's
                if (ends) o0.endsAt = new Date(ends).toISOString(); if (Object.keys(times).length) o0.times = times;
                out.push(o0);
            } catch (e) { note("quest " + e); }
        });
        out.sort(function (a, b) { return ((ORDER[a.kind] != null ? ORDER[a.kind] : 9) - (ORDER[b.kind] != null ? ORDER[b.kind] : 9)) || (a.title < b.title ? -1 : 1); });
        return out;
    }
    /* 0.1.6: open quests only (not collected, not deactivated) */
    function plain(list) { return (list || []).filter(function (x) { return x.mode !== 12 && x.mode !== 11; }).map(function (x) { var o = {}; Object.keys(x).forEach(function (k) { if (k !== "_q") o[k] = x[k]; }); return o; }); }

    function claimTick(list, now) {
        try { zombieWatch(list); } catch (_) {}
        if (!(pol("quest.auto", false) === true && pol("quest.claim.on", true) !== false)) return;
        var cb = claimer(); if (!cb) return;
        // 0.1.11: a claimed quest that left the quest book was carried out: declare + accept once
        var listed = {}; list.forEach(function (x) { listed[x.uid] = true; });
        Object.keys(claimTried).forEach(function (uid) { var t0 = claimTried[uid]; if (t0 && !t0.declared && !gaveUp[uid] && !listed[uid] && now - t0.at >= TICK_MS) { t0.declared = true; state.claimed += 1; record("declare", { caseId: "claim:" + uid, actor: "game (observed)", reason: "the quest left the quest book" }); record("accept", { caseId: "claim:" + uid }); } });
        // 0.1.12: after a client restart the in-memory claim/start is gone; the transaction book still has the case open
        try {
            var txm = root.DMA_Tx, byUid = {};
            list.forEach(function (x) { byUid[x.uid] = x; });
            if (txm && txm.list && list.length) txm.list({ tk: "TK71", open: true }).forEach(function (t) {
                var m = /^(claim|start):(.+)$/.exec(String(t.key || "")); if (!m) return;
                var uid = m[2], mem0 = m[1] === "claim" ? claimTried : startTried;
                if (mem0[uid] || gaveUp[uid] || t.state !== "promised" || now - Number(t.at || 0) < TICK_MS) return;
                var x0 = byUid[uid];
                if (x0 && (m[1] === "claim" || x0.isNew)) return;   // still listed: a claim waits for the reward window; a start for "not new"
                mem0[uid] = { at: Number(t.at || 0), ok: true, declared: true };
                if (m[1] === "claim") state.claimed += 1;
                record("declare", { caseId: t.key, actor: "game (observed)", what: m[1] === "start" ? "start" : undefined, reason: x0 ? "the quest is no longer new (seen after a restart)" : "the quest left the quest book (seen after a restart)" });
                record("accept", { caseId: t.key, what: m[1] === "start" ? "start" : undefined });
            });
        } catch (eTx) { note("quest book " + eTx); }
        // a claim two cycles ago whose quest is still in the reward window: failed, fail closed
        list.forEach(function (x) {
            var t = claimTried[x.uid];
            if (t && x.reward && now - t.at >= 2 * TICK_MS && !gaveUp[x.uid]) { gaveUp[x.uid] = true; state.failed += 1; record("revoke request", { caseId: "claim:" + x.uid, quest: x.name, kind: x.kind, reason: "still in the reward window after the claim" }); record("allow", { caseId: "claim:" + x.uid, actor: "game (tacit)" }); }   // 0.1.9: was "failed"
            if (t && !x.reward && !t.declared) { t.declared = true; state.claimed += 1; record("declare", { caseId: "claim:" + x.uid, actor: "game (observed)", quest: x.name, kind: x.kind, mode: x.mode }); record("accept", { caseId: "claim:" + x.uid, quest: x.name }); }
            var st0 = startTried[x.uid];   // 0.1.9: a started quest that is no longer new is declared and accepted once
            if (st0 && typeof st0 === "object" && st0.ok && !st0.declared && !x.isNew) { st0.declared = true; record("declare", { caseId: "start:" + x.uid, actor: "game (observed)", what: "start", quest: x.name }); record("accept", { caseId: "start:" + x.uid, what: "start", quest: x.name }); }
        });
        // 0.1.1: a new quest waits to be selected — start it as the Quest Book does when it is displayed
        if (pol("quest.start.on", true) !== false && typeof cb.QuestOkButtonPressedFromGui === "function") {
            var n = list.filter(function (x) { return x.isNew && !startTried[x.uid] && chosen(x); })[0];   // 0.1.18: chosen categories only
            if (n) { startTried[n.uid] = { at: now }; record("request", { caseId: "start:" + n.uid, what: "start", quest: n.name, kind: n.kind });
                     try { cb.QuestOkButtonPressedFromGui(n._q); startTried[n.uid].ok = true; record("execute", { caseId: "start:" + n.uid, what: "start", quest: n.name, kind: n.kind }); }
                     catch (e) { record("decline", { caseId: "start:" + n.uid, actor: "game", what: "start", quest: n.name, reason: String(e).slice(0, 200) }); } }   // 0.1.9: was "failed"
        }
        var c = list.filter(function (x) { return x.reward && !claimTried[x.uid] && !gaveUp[x.uid] && chosen(x); })[0];   // 0.1.18
        if (!c) return;
        record("request", { caseId: "claim:" + c.uid, quest: c.name, kind: c.kind, mode: c.mode });
        try { cb.RewardOkButtonPressedFromGui(c._q); claimTried[c.uid] = { at: now }; record("execute", { caseId: "claim:" + c.uid, quest: c.name, kind: c.kind }); }
        catch (e) { gaveUp[c.uid] = true; state.failed += 1; record("decline", { caseId: "claim:" + c.uid, actor: "game", quest: c.name, reason: String(e).slice(0, 200) }); }   // 0.1.9: was "failed"
    }
    /* 0.1.17 Q-3: pay a guild quest from storage when that is all it still needs */
    /* 0.1.30: the client's remaining value; null, "" or anything not a finite number is UNREADABLE (NaN), never 0 */
    function remOf(cbq, player, q, i) {
        var v; try { v = cbq.GetRemainingValuesForQuestTrigger(player, q, i); } catch (_) { return NaN; }
        if (v == null || (typeof v === "string" && /^\s*$/.test(v)) || typeof v === "boolean" || typeof v === "object") return NaN;
        var n = Number(v); return isFinite(n) ? n : NaN;
    }
    /* 0.1.29: is the whole amount of one payment task in storage — the client's own remaining value <= 0, else the stock the agents remember */
    function inStorage(t, q, i) {
        var g = gi(), cbq = g && g.mQuestClientCallbacks, rem = NaN;
        if (cbq && typeof cbq.GetRemainingValuesForQuestTrigger === "function") rem = remOf(cbq, g.mCurrentPlayer, q, i);
        if (!isNaN(rem)) return rem <= 0;
        if (cbq && typeof cbq.GetRemainingValuesForQuestTrigger === "function") return false;   // 0.1.30: the client answered but unreadably: no payment
        try { var st = root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow(); if (st && t.what && t.amount > 0) return Number(st[t.what]) >= t.amount; } catch (_) {}
        return false;
    }
    /* 0.1.29: any category; the open tasks are payments the storage covers, and tasks the game counts itself (type 45) */
    function payable(x, cbq, player) {
        if (x.mode !== 3 || x.reward) return false;
        var open18 = 0, ok = true;
        x.tasks.forEach(function (t, i) {
            if (t.done) return;
            if (t.type === 45 && !t.route) return;   // 0.1.31: the game counts it - except a search the explorers still have to do
            if (t.type !== 18) { ok = false; return; }
            open18 += 1;
            var rem = remOf(cbq, player, x._q, i);   // 0.1.30: unreadable (NaN) is not covered
            if (!(rem <= 0)) ok = false;
        });
        return ok && open18 > 0;
    }
    /* 0.1.30: one pending payment per storage resource (not only per quest) until it is seen booked (the quest's payment done / gone), the stock dropped, or a timeout */
    var PAY_PENDING_MS = 10 * 60000, payRes = {};
    function payResources(x) { var out = []; x.tasks.forEach(function (t) { if (!t.done && t.type === 18 && t.what && out.indexOf(t.what) < 0) out.push(t.what); }); return out; }
    function resBlocked(x, now) {
        var st = null; try { st = root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow(); } catch (_) {}
        return payResources(x).some(function (r) {
            var p = payRes[r]; if (!p) return false;
            if (now - p.at >= PAY_PENDING_MS) { delete payRes[r]; return false; }
            if (st && p.stock != null && Number(st[r]) < p.stock) { delete payRes[r]; return false; }   // the stock was seen to drop: booked
            return true; });
    }
    function payTick(list, now) {
        if (!(pol("quest.auto", false) === true && pol("quest.pay.on", true) !== false)) return;
        var g = gi(); if (!g) return; var cbq = g.mQuestClientCallbacks; if (!cbq || typeof cbq.InitiatePayForQuestFinish !== "function") return;
        var listed = {}; list.forEach(function (x) { listed[x.uid] = x; });
        Object.keys(payTried).forEach(function (uid) { var t0 = payTried[uid], x0 = listed[uid];
            if (t0.declared || now - t0.at < TICK_MS) return;
            var done = !x0 || x0.tasks.every(function (t) { return t.type !== 18 || t.done; });
            if (done) { Object.keys(payRes).forEach(function (r) { if (payRes[r].uid === uid) delete payRes[r]; }); t0.declared = true; record("declare", { caseId: "pay:" + uid, actor: "game (observed)", what: "pay", reason: x0 ? "the payment task is done" : "the quest left the quest book" }); record("accept", { caseId: "pay:" + uid, what: "pay" }); } });
        var x = list.filter(function (q) { var t = payTried[q.uid]; return (!t || (!t.declared && now - t.at >= 30 * 60000)) && chosen(q) && payable(q, cbq, g.mCurrentPlayer) && !resBlocked(q, now); })[0];   // 0.1.18: chosen; 0.1.30: no shared storage in flight
        if (!x) return;
        payTried[x.uid] = { at: now };
        var stNow = null; try { stNow = root.DMA_Demo && root.DMA_Demo.stockNow && root.DMA_Demo.stockNow(); } catch (_) {}
        payResources(x).forEach(function (r) { payRes[r] = { uid: x.uid, at: now, stock: stNow && stNow[r] != null ? Number(stNow[r]) : null }; });
        record("request", { caseId: "pay:" + x.uid, what: "pay", quest: x.name, kind: x.kind });
        try { cbq.InitiatePayForQuestFinish(x._q.mUniqueID); record("execute", { caseId: "pay:" + x.uid, what: "pay", quest: x.name, kind: x.kind }); }
        catch (e) { record("decline", { caseId: "pay:" + x.uid, actor: "game", what: "pay", quest: x.name, reason: String(e).slice(0, 200) }); }
    }
    /* 0.1.31 (ADR 0077): TK73 "search order completing" - the quest manager (AR71) asks the explorer manager (AR73) for the adventure searches a chosen quest's task names.
       One case per task: search:<quest uid>#<task index>. The game's finished flag of the trigger ends it; no progress count of the game is known, the explorer manager counts its own sends. */
    function searchKey(uid, idx) { return "search:" + uid + "#" + idx; }
    /* 0.1.32: what the game counts for the task of an order (the explorer manager reads this, not the quest book) */
    function searchProgress(key) {
        var m = /^search:(.+)#(\d+)$/.exec(String(key)), q = null, t, i;
        if (!m) return null;
        for (i = 0; i < last.length; i++) if (last[i].uid === m[1]) q = last[i];
        t = q && q.tasks ? q.tasks[Number(m[2])] : null;
        if (!t || !t.search) return null;
        return { progress: t.progress != null ? Number(t.progress) : null, amount: Number(t.amount) || 0, done: !!t.done, at: lastReadAt };
    }
    function searchTick(list, now) {
        var M = root.DMA_Tx; if (!M || typeof M.list !== "function") return 0;
        var auto = pol("quest.auto", false) === true, wanted = {}, byUid = {}, acted = 0;
        list.forEach(function (x) { byUid[x.uid] = x; });
        list.forEach(function (x) {
            if (x.mode !== 3 || x.reward || !chosen(x)) return;
            (x.tasks || []).forEach(function (t, i) { if (t.route === "search" && t.search && !t.done && Number(t.amount) > 0) wanted[searchKey(x.uid, i)] = { x: x, t: t, i: i }; });
        });
        var open = {}; try { M.list({ tk: "TK73", open: true }).forEach(function (b) { if (/^search:/.test(String(b.key))) open[b.key] = b; }); } catch (_) { return 0; }
        Object.keys(open).forEach(function (key) {
            var b = open[key], d = b.data || {}, sent = Number(d.sent) || 0, asked = Number(d.searches) || 0, m = /^search:(.+)#(\d+)$/.exec(key), q = m ? byUid[m[1]] : null, tk0 = q && q.tasks ? q.tasks[Number(m[2])] : null;
            if (b.revoking) return;
            if (b.state === "declared") {   // the explorer manager has declared: accepted when the game counts the task done (or the quest is gone)
                if (!q || (tk0 && tk0.done)) { record("accept", { caseId: key, what: "search", actor: "quest manager", reason: q ? "the game counts the task done" : "the quest left the quest book" }); acted += 1; }
                else if (tk0 && Number(tk0.amount) > 0 && (tk0.progress == null || Number(tk0.progress) < Number(tk0.amount))) {   // 0.1.33: the product does not hold (the game's count is below the amount): reject; the explorer manager goes on (also a case restored in "declared")
                    record("reject", { caseId: key, what: "search", actor: "quest manager", reason: "the game counts " + (tk0.progress == null ? "no" : tk0.progress) + " of " + tk0.amount + " searches done", progress: tk0.progress == null ? "" : Number(tk0.progress), amount: Number(tk0.amount) }); acted += 1;
                }
                return;
            }
            var done = !!(tk0 && tk0.done);
            if (b.state === "promised" && done && asked > 0 && sent >= asked) { record("accept", { caseId: key, what: "search", actor: "quest manager", reason: "the game counts the task done" }); acted += 1; return; }   // the declare of the explorer manager is tacit
            if (b.state !== "requested" && b.state !== "promised" && b.state !== "rejected") return;   // 0.1.33: a rejected order is still the explorer manager's to finish, and can still be withdrawn
            if (!wanted[key]) {
                var why = !q ? "the quest left the quest book" : done ? "the game counts the task done" : !chosen(q) ? "the category is unticked" : !auto ? "the Quest switch is off" : "the quest is no longer running";
                record("revoke request", { caseId: key, what: "search", actor: "quest manager", quest: q ? q.name : "", reason: why }); acted += 1;
            }
        });
        if (!auto) return acted;
        Object.keys(wanted).forEach(function (key) {
            if (open[key]) return;
            var w = wanted[key], prog = w.t.progress != null ? Number(w.t.progress) : 0, n = Number(w.t.amount) - prog;   // 0.1.32: the game's count, not our guess
            if (!(n > 0)) return;
            record("request", { caseId: key, what: "search", actor: "quest manager", quest: w.x.name, uid: w.x.uid, idx: w.i, task: w.t.search, searches: n, asked: Number(w.t.amount), done: prog, item: w.t.item });
            acted += 1;
        });
        return acted;
    }
    /* 0.1.18 Q-5 (ADR 0053): a task no executor can do is declined and the player's help is asked */
    var helpAsked = {};
    function helpList(list) {
        var out = [];
        list.forEach(function (x) {
            if (x.mode !== 3 || x.reward || !chosen(x)) return;
            (x.tasks || []).forEach(function (t, i) { if (!t.done && !t.can) out.push({ uid: x.uid, quest: x.title || x.name, name: x.name, category: x.category, task: t.kind, what: t.what || t.item || "", amount: t.amount, idx: i, endsAt: x.endsAt || null }); });
        });
        out.sort(function (a, b) { return (a.category === "guild" ? 0 : 1) - (b.category === "guild" ? 0 : 1); });
        return out;
    }
    /* 0.1.19: the to-do list — urgent first */
    var CAT_ORDER = { guild: 0, daily: 1, weekly: 2, event: 3, ghostship: 4, starfall: 5, main: 6, side: 7, building: 8, other: 9 };
    function todoList(list, now) {
        now = now || Date.now();
        var out = [];
        (list || []).forEach(function (x) {
            if (x.mode === 12 || x.mode === 11 || x.collected || !chosen(x)) return;
            var open = (x.tasks || []).filter(function (t) { return !t.done; }).map(function (t) { var r = { task: t.kind, what: t.what || t.item || "", amount: t.amount, by: t.can || "needs you" }; if (t.text) r.text = t.text; if (t.progress != null) r.progress = t.progress; return r; });
            var endMs = x.endsAt ? Date.parse(x.endsAt) : null;
            out.push({ uid: x.uid, quest: x.title || x.name, name: x.name, category: x.category, state: x.reward ? "reward ready" : x.state, endsAt: x.endsAt || null,
                       minutesLeft: endMs ? Math.round((endMs - now) / 60000) : null, needsYou: open.filter(function (t) { return t.by === "needs you"; }).length, open: open, rewardReady: !!x.reward });
        });
        out.sort(function (a, b) {
            if (a.rewardReady !== b.rewardReady) return a.rewardReady ? -1 : 1;
            var va = a.category === "event" ? 0 : 1, vb = b.category === "event" ? 0 : 1;   // 0.1.20: event quests first while Event is on
            if (va !== vb) return va - vb;
            var ea = a.minutesLeft == null ? Infinity : a.minutesLeft, eb = b.minutesLeft == null ? Infinity : b.minutesLeft;
            if (ea !== eb) return ea - eb;
            return (CAT_ORDER[a.category] || 9) - (CAT_ORDER[b.category] || 9) || (b.needsYou - a.needsYou);
        });
        return out;
    }
    /* 0.1.21: what the quest manager keeps an eye on, and who carries each kind of task */
    function watch(list, g) {
        var cats = CATS.map(function (c) { return { category: c, on: pol("quest.do." + c, true) !== false && (c !== "event" || eventOn()), open: 0, rewards: 0, needsYou: 0 }; });
        var byCat = {}; cats.forEach(function (c) { byCat[c.category] = c; });
        var ex = {}; Object.keys(ROUTES).forEach(function (t) { var r = ROUTES[t]; var e = ex[r.actor] || (ex[r.actor] = { actor: r.actor, kinds: [], loaded: r.watch ? true : loaded(r.uses, g), watch: !!r.watch, open: 0 }); e.kinds.push(KIND[t] || ("type " + t)); });
        var none = ex["the player (no executor)"] = { actor: "the player (no executor)", kinds: [], loaded: false, watch: false, open: 0 };
        (list || []).forEach(function (x) {
            if (x.mode === 12 || x.mode === 11 || x.collected) return;
            var c = byCat[x.category]; if (!c) return;
            c.open += 1; if (x.reward) c.rewards += 1;
            if (!c.on) return;
            (x.tasks || []).forEach(function (t) {
                if (t.done) return;
                var r = ROUTES[t.route || t.type], e = r ? ex[r.actor] : null;
                if (t.can && e) e.open += 1;
                else { c.needsYou += 1; none.open += 1; var k = t.kind; if (none.kinds.indexOf(k) < 0) none.kinds.push(k); }
            });
        });
        return { categories: cats, executors: Object.keys(ex).map(function (k) { return ex[k]; }) };
    }
    function helpTick(list, now) {
        if (pol("quest.auto", false) !== true) return;
        var h = helpList(list); state.help = h.length; state.helpGuild = h.filter(function (x) { return x.category === "guild"; }).length;
        h.forEach(function (x) {
            var key = x.uid + "#" + x.idx; if (helpAsked[key]) return; helpAsked[key] = now;
            record("decline", { caseId: "task:" + key, quest: x.name, category: x.category, task: x.task, what: x.what, amount: x.amount, reason: "no executor — the player's help is asked", endsAt: x.endsAt });
        });
        writeJson("dma-quest-help.json", { format: "dma-quest-help/1", version: VERSION, at: new Date(now).toISOString(), help: h });
    }
    /* Q-4a: collectibles on the home zone, the way the client's Shortcuts -> Collectibles does it */
    var lastCollectAt = 0, collectBusy = false;
    function finds(fresh) {
        var C = root.DMA_Control; if (!C || typeof C.finds !== "function") return null;
        if (fresh && typeof C.scan === "function") { try { C.scan(); } catch (_) {} }   // a request to the location manager
        var f = null; try { f = C.finds(); } catch (_) { return null; }
        if (!f || !f.home) return null;
        if (Date.now() - Number(f.at || 0) > Number(pol("quest.collectEveryMin", 10)) * 60000) return null;   // too old: wait for the next scan
        return f;
    }
    function collectibles(fresh) {
        var g = gi(); if (!g) return [];
        try { if (g.isOnHomzone && !g.isOnHomzone()) return []; } catch (_) {}
        var f = finds(fresh); return f ? f.collectibles : [];
    }
    /* Q-4b (0.1.5): buildings with a "select this building" quest trigger (hearts, gifts, telescope ...) */
    function selectables(fresh) {
        var g = gi(); if (!g) return [];
        try { if (g.isOnHomzone && !g.isOnHomzone()) return []; } catch (_) {}
        var f = finds(fresh); if (!f) return [];
        var only = String(pol("quest.select.names", "") || "").split(/[,;]/).map(function (x) { return x.replace(/^\s+|\s+$/g, ""); }).filter(Boolean);
        var seen = {}, out = [];
        f.triggers.forEach(function (b) {
            try { var n = String(b.GetBuildingName_string()); if (seen[n]) return; if (only.length && only.indexOf(n) < 0) return; seen[n] = 1; out.push(b); } catch (_) {}
        });
        return out;
    }
    var lastSelectAt = 0;
    function selectTick(now, force) {
        if (!force && !(pol("quest.auto", false) === true && pol("quest.select.on", true) !== false)) return 0;
        if (!force && now - lastSelectAt < Number(pol("quest.collectEveryMin", 10)) * 60000) return 0;
        lastSelectAt = now;
        var items = selectables(); if (!items.length) return 0;
        var cb = gi().mQuestClientCallbacks, names = items.map(function (b) { try { return String(b.GetBuildingName_string()); } catch (_) { return "?"; } });
        var sc = "select@" + now;   // 0.1.9: one instance per round of selections
        record("request", { caseId: sc, what: "select", names: names });
        items.forEach(function (b, k) {
            root.setTimeout(function () { try { cb.BuildingSelectedGui(b); } catch (e) { note("select " + e); } if (k === items.length - 1) { state.selected = (state.selected || 0) + items.length; record("execute", { caseId: sc, what: "select", names: names }); record("declare", { caseId: sc, what: "select", actor: "game (observed: selected)" }); record("accept", { caseId: sc, what: "select" }); } }, k * 1000);
        });
        return items.length;
    }
    function collectTick(now, force) {
        if (collectBusy) return 0;
        if (!force && !(pol("quest.auto", false) === true && pol("quest.collect.on", true) !== false)) return 0;
        if (!force && now - lastCollectAt < Number(pol("quest.collectEveryMin", 10)) * 60000) return 0;
        lastCollectAt = now;
        var items = collectibles(); if (!items.length) return 0;
        collectBusy = true; state.collectSent = (state.collectSent || 0) + items.length;
        var cc = "collect@" + now;   // 0.1.9: one instance per round of collecting
        record("request", { caseId: cc, what: "collectibles", count: items.length });
        items.forEach(function (b, k) {
            root.setTimeout(function () { try { gi().SelectBuilding(b); } catch (e) { note("collect " + e); } if (k === items.length - 1) { collectBusy = false; record("execute", { caseId: cc, what: "collectibles", count: items.length }); record("declare", { caseId: cc, what: "collectibles", actor: "game (observed: collected)" }); record("accept", { caseId: cc, what: "collectibles" }); } }, k * 1000);
        });
        return items.length;
    }
    /* Q-4c (0.1.13): timed productions waiting to be picked up — the location manager's picture */
    var pickedAt = {}, pickupBusy = false, pickupMisses = 0;
    function pickups() {
        var g = gi(); if (!g) return [];
        try { if (g.isOnHomzone && !g.isOnHomzone()) return []; } catch (_) {}
        var f = finds(false); if (!f || !f.pickups) return [];
        var skip = String(pol("quest.pickup.skip", "") || "").split(/[,;]/).map(function (x) { return x.replace(/^\s+|\s+$/g, ""); }).filter(Boolean), now = Date.now();
        return f.pickups.filter(function (b) {
            try { var n = String(b.GetBuildingName_string()), gr = String(b.GetGrid()); if (skip.indexOf(n) >= 0) return false; if (pickedAt[gr] && now - pickedAt[gr] < 120000) return false;
                  var q = b.productionQueue, v = q && q.mTimedProductions_vector; return !!(q && q.waitForPickup === true && v && v.length > 0 && v[0].readyForDeliver === true); } catch (_) { return false; }   // still ready right now (0.1.16)
        });
    }
    function pickupTick(now, force) {
        if (pickupBusy) return 0;
        if (!force && !(pol("quest.auto", false) === true && pol("quest.pickup.on", true) !== false && !state.pickupStopped)) return 0;
        var items = pickups(); if (!items.length) return 0;
        pickupBusy = true;
        var names = items.map(function (b) { try { return String(b.GetBuildingName_string()) + "@" + b.GetGrid(); } catch (_) { return "?"; } }), pc = "pickup@" + now;
        items.forEach(function (b) { try { pickedAt[String(b.GetGrid())] = now; } catch (_) {} });
        var refusedN = 0, aborted = false;   // 0.1.28: an adapter refusal (hold, pace) is not a round of the game: nothing recorded, no miss, retried next tick
        function giveUp(why) { aborted = true; pickupBusy = false; items.forEach(function (x) { try { delete pickedAt[String(x.GetGrid())]; } catch (_) {} }); note("pickup round waits: " + why); }
        items.forEach(function (b, k) {
            root.setTimeout(function () {
                if (aborted) return;
                try { var g2 = gi(), q0 = b.productionQueue.mTimedProductions_vector[0];   // 0.1.16: the Pick-up button's own call
                      if (q0 && q0.readyForDeliver === true) {
                          var GA = root.GCAF_GameInterface, sr = GA && typeof GA.sendMessage === "function" ? GA.sendMessage("QUEST_PICKUP", b.productionType, null) : { ok: false, reason: "game interface adapter not loaded" };   // 0.1.27 (ADR 0073)
                          if (sr.ok === true) { if (typeof q0.SetWaitingForServer === "function") q0.SetWaitingForServer(true); }
                          else { refusedN += 1; delete pickedAt[String(b.GetGrid())]; note("pickup refused: " + sr.reason); } } } catch (e) { note("pickup " + e); }
                if (k === 0 && refusedN > 0) { giveUp("the adapter refused the first pick-up"); return; }
                if (k === 0) record("request", { caseId: pc, what: "pickup", names: names });
                if (k === items.length - 1) {
                    pickupBusy = false; state.pickedUp = (state.pickedUp || 0) + items.length - refusedN;
                    record("execute", { caseId: pc, what: "pickup", names: names });
                    root.setTimeout(function () {   // declare what the game shows: the queue no longer waits
                        var left = items.filter(function (x) { try { var v = x.productionQueue.mTimedProductions_vector; return !!(v && v.length > 0 && v[0].readyForDeliver === true && !(v[0].GetWaitingForServer && v[0].GetWaitingForServer())); } catch (_) { return false; } }).length;
                        record("declare", { caseId: pc, what: "pickup", actor: "game (observed)", picked: items.length - left, left: left });
                        record(left === items.length ? "reject" : "accept", { caseId: pc, what: "pickup", left: left });   // 0.1.14
                        pickupMisses = left === items.length ? pickupMisses + 1 : 0;   // 0.1.15 safeguard
                        if (pickupMisses >= 2) { state.pickupStopped = "two rounds picked nothing up (" + new Date().toISOString() + ")"; note("pickups stopped: " + state.pickupStopped); }
                    }, 3000);
                }
            }, k * 1000);
        });
        return items.length;
    }
    function away() { try { var C = root.DMA_Control; return !!(C && typeof C.atHome === "function" && !C.atHome()); } catch (_) { return false; } }   // 0.1.3
    function tick(now) {
        if (away()) return;
        now = now || Date.now();
        state.ticks += 1;
        try {
            collectTick(now);                                              // Q-4a
            selectTick(now);                                               // Q-4b (0.1.5)
            pickupTick(now);                                               // Q-4c (0.1.13)
            var list = read();
            if (!list) return;
            last = list; lastReadAt = now || Date.now(); state.quests = list.length;
            payTick(list, now);                                            // 0.1.17 Q-3 (guild quest first)
            claimTick(list, now);
            helpTick(list, now);                                           // 0.1.18 Q-5
            try { searchTick(list, now); } catch (eS) { note("search " + eS); }   // 0.1.31 (ADR 0077) TK73
            if (now - lastStatusAt >= STATUS_MS) {
                lastStatusAt = now;
                writeJson("dma-quest-status.json", { format: "dma-quest-status/1", version: VERSION, at: new Date(now).toISOString(), state: state, quests: plain(list) });
                writeJson("dma-quest-watch.json", { format: "dma-quest-watch/1", version: VERSION, at: new Date(now).toISOString(), watch: watch(list) });   // 0.1.21
                writeJson("dma-quest-todo.json", { format: "dma-quest-todo/1", version: VERSION, at: new Date(now).toISOString(), todo: todoList(list, now) });   // 0.1.19
            }
        } catch (e) { note("tick " + e); }
    }
    function start() {
        if (timer) return;
        state.startedAt = new Date().toISOString();
        if (root.DMA_QUEST_NO_TIMER) return;
        timer = root.setInterval(function () { try { tick(); } catch (e) { note("tick " + e); } }, TICK_MS);
    }
    root.DMA_Quest = {
        version: VERSION,
        tick: tick,
        classify: classify,
        payable: payable,
        category: category,                                                // 0.1.18
        eventGate: function () { return eventGate(last.length ? last : (read() || [])); },   // 0.1.24
        watch: function (g) { return watch(last.length ? last : (read() || []), g); },   // 0.1.21
        routes: function () { return JSON.parse(JSON.stringify(ROUTES)); },  // 0.1.21
        todo: function () { return todoList(last.length ? last : (read() || []), Date.now()); },   // 0.1.19
        help: function () { return helpList(last.length ? last : (read() || [])).map(function (x) { return x; }); },   // 0.1.18
        quests: function () { if (!last.length) { var l = read(); if (l) { last = l; lastReadAt = Date.now(); } } return plain(last); },
        status: function () { return JSON.parse(JSON.stringify(state)); },
        collectibles: function () { return collectibles().length; },
        pickups: function () { return pickups().map(function (b) { try { return String(b.GetBuildingName_string()); } catch (_) { return "?"; } }); },   // 0.1.13
        pickupNow: function () { return pickupTick(Date.now(), true); },   // 0.1.13
        collectNow: function () { finds(true); return collectTick(Date.now(), true) + selectTick(Date.now(), true); },   // the console button: also when the switch is off; 0.1.7: one fresh scan by the location manager first
        searchTick: function (now) { return searchTick(last.length ? last : (read() || []), now || Date.now()); },   // 0.1.31 (ADR 0077)
        endText: endText,                                                  // 0.1.31
        searchProgress: searchProgress,                                    // 0.1.32
        refresh: function () { var l = read(); if (l) { last = l; lastReadAt = Date.now(); } return plain(last); },   // 0.1.31: read the quest book now
        selectables: function () { return selectables().map(function (b) { try { return String(b.GetBuildingName_string()); } catch (_) { return "?"; } }); }
    };
    start();
})(typeof window !== "undefined" ? window : this);
